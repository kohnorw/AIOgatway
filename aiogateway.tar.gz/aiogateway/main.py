"""
main.py — AIOGateway FastAPI application

Endpoints:
  POST /api/add              — add media, query AIOStreams, create stubs
  GET  /api/stubs            — list all stubs and their state
  GET  /api/stubs/{stub_id}  — single stub detail
  DELETE /api/stubs/{stub_id} — remove stub and file

  POST /webhook/plex         — Plex webhook receiver (multipart/form-data)

  GET  /proxy/{stub_id}      — HTTP proxy for Plex playback (streams bytes)
  HEAD /proxy/{stub_id}      — HEAD for Plex pre-flight

  GET  /                     — web UI (served from ui/)
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Request, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from gateway.aiostreams_client import AIOStreamsClient
from gateway.models import MediaItem, MediaType, Quality, StubState
from gateway.proxy import StreamProxy
from gateway.stub_manager import StubManager
from webhook.handler import PlexWebhookHandler

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
logger = logging.getLogger("aiogateway")

# ---------------------------------------------------------------------------
# Global singletons (shared across requests)
# ---------------------------------------------------------------------------
stub_manager    = StubManager()
stream_proxy    = StreamProxy()
aio_client      = AIOStreamsClient()
webhook_handler: PlexWebhookHandler | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global webhook_handler
    # Restore stubs from previous run
    count = await stub_manager.restore_from_disk()
    logger.info("Restored %d stubs from disk", count)

    # Open long-lived sessions
    await stream_proxy.__aenter__()
    await aio_client.__aenter__()

    webhook_handler = PlexWebhookHandler(stub_manager, aio_client)
    yield

    await stream_proxy.__aexit__(None, None, None)
    await aio_client.__aexit__(None, None, None)


app = FastAPI(title="AIOGateway", version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

class AddMediaRequest(BaseModel):
    imdb_id: str                    # e.g. "tt1375666"
    title: str
    year: Optional[int] = None
    media_type: str = "movie"       # "movie" | "series"
    season: Optional[int] = None
    episode: Optional[int] = None

class AddMediaResponse(BaseModel):
    media_id: str
    title: str
    stubs_created: list[dict]
    streams_found: int
    has_4k: bool


# ---------------------------------------------------------------------------
# API: Add media
# ---------------------------------------------------------------------------

@app.post("/api/add", response_model=AddMediaResponse)
async def add_media(req: AddMediaRequest):
    """
    1. Query AIOStreams for available streams
    2. Detect HD + 4K availability
    3. Create placeholder .mkv files in the right library folders
    """
    media_id = f"{req.imdb_id}_{req.season or ''}_{req.episode or ''}".strip("_")
    media_type = MediaType.MOVIE if req.media_type == "movie" else MediaType.SERIES

    item = MediaItem(
        id=media_id,
        imdb_id=req.imdb_id,
        title=req.title,
        year=req.year,
        media_type=media_type,
        season=req.season,
        episode=req.episode,
    )

    # Query AIOStreams
    try:
        item.streams = await aio_client.resolve_all(item)
    except Exception as exc:
        logger.error("AIOStreams query failed: %s", exc)
        raise HTTPException(status_code=502, detail=f"AIOStreams error: {exc}")

    if not item.streams:
        raise HTTPException(
            status_code=404,
            detail="No streams found with a direct URL. Check AIOStreams config."
        )

    # Create stubs
    stubs = await stub_manager.create_stubs(item)

    return AddMediaResponse(
        media_id=media_id,
        title=item.title,
        stubs_created=[
            {"stub_id": s.stub_id, "quality": s.quality.value, "path": s.abs_path}
            for s in stubs
        ],
        streams_found=len(item.streams),
        has_4k=item.has_4k,
    )


# ---------------------------------------------------------------------------
# API: List / inspect stubs
# ---------------------------------------------------------------------------

@app.get("/api/stubs")
async def list_stubs():
    stubs = stub_manager.all_stubs()
    return {
        "count": len(stubs),
        "stubs": [
            {
                "stub_id": s.stub_id,
                "media_id": s.media_id,
                "quality": s.quality.value,
                "state": s.state.value,
                "path": s.abs_path,
                "stream_url": (s.stream_url[:60] + "...") if s.stream_url else None,
            }
            for s in stubs
        ],
    }


@app.get("/api/stubs/{stub_id}")
async def get_stub(stub_id: str):
    stub = stub_manager.get_by_id(stub_id)
    if not stub:
        raise HTTPException(status_code=404, detail="Stub not found")
    return {
        "stub_id": stub.stub_id,
        "media_id": stub.media_id,
        "quality": stub.quality.value,
        "state": stub.state.value,
        "path": stub.abs_path,
        "imdb_id": stub.imdb_id,
        "aiostreams_id": stub.aiostreams_id,
        "stream_url": stub.stream_url,
        "resolved_at": stub.resolved_at,
        "created_at": stub.created_at,
    }


@app.delete("/api/stubs/{stub_id}")
async def delete_stub(stub_id: str):
    stub = stub_manager.get_by_id(stub_id)
    if not stub:
        raise HTTPException(status_code=404, detail="Stub not found")
    try:
        path = Path(stub.abs_path)
        if path.exists():
            path.unlink()
        sidecar = path.with_suffix("").with_suffix(".aiogateway.json")
        if sidecar.exists():
            sidecar.unlink()
    except Exception as exc:
        logger.warning("Error deleting stub file: %s", exc)
    return {"deleted": stub_id}


# ---------------------------------------------------------------------------
# Webhook: Plex
# ---------------------------------------------------------------------------

@app.post("/webhook/plex")
async def plex_webhook(request: Request):
    """
    Receives Plex webhook events (multipart/form-data).
    Plex sends the payload as a form field called "payload".
    """
    content_type = request.headers.get("content-type", "")

    if "multipart/form-data" in content_type:
        form = await request.form()
        payload_str = form.get("payload", "{}")
    else:
        # Some Plex versions send JSON directly
        payload_str = (await request.body()).decode("utf-8")

    result = await webhook_handler.handle(payload_str)
    return JSONResponse(result)


# ---------------------------------------------------------------------------
# Proxy: stream to Plex
# ---------------------------------------------------------------------------

@app.get("/proxy/{stub_id}")
async def proxy_get(stub_id: str, request: Request):
    stub = stub_manager.get_by_id(stub_id)
    if not stub:
        raise HTTPException(status_code=404, detail="Stub not found")

    if stub.state == StubState.PLACEHOLDER:
        raise HTTPException(
            status_code=503,
            detail="Stream not yet resolved. Plex webhook not received."
        )
    if stub.state == StubState.ERROR:
        raise HTTPException(status_code=502, detail="Stream resolution failed")
    if not stub.stream_url:
        raise HTTPException(status_code=503, detail="Stream URL pending")

    range_header = request.headers.get("Range")
    status, headers, byte_iter = await stream_proxy.proxy_stream(stub, range_header)

    return StreamingResponse(
        byte_iter,
        status_code=status,
        headers=headers,
        media_type=headers.get("Content-Type", "video/x-matroska"),
    )


@app.head("/proxy/{stub_id}")
async def proxy_head(stub_id: str):
    stub = stub_manager.get_by_id(stub_id)
    if not stub or not stub.stream_url:
        raise HTTPException(status_code=404)
    status, headers = await stream_proxy.head_stream(stub)
    return StreamingResponse(b"", status_code=status, headers=headers)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    stubs = stub_manager.all_stubs()
    return {
        "status": "ok",
        "stubs": len(stubs),
        "active": sum(1 for s in stubs if s.state == StubState.ACTIVE),
    }
