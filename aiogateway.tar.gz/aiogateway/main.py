"""
AIOGateway — FastAPI + NuvioWeb-style UI using Cinemeta for metadata.

Cinemeta (v3-cinemeta.strem.io) is the same free metadata source used by
NuvioWeb/NuvioTV. No API key needed. Returns IMDb IDs, posters/backdrops
from TMDB CDN. Endpoints:
  /catalog/movie/top.json  → popular movies
  /catalog/series/top.json → popular series
  /meta/{type}/{imdb_id}.json → single item detail

Endpoints
---------
GET  /                           NuvioWeb-style browse UI
GET  /api/config                 Env config
GET  /api/test                   AIOStreams connectivity test
GET  /api/cinemeta/{path}        Cinemeta proxy (no CORS issues from browser)
POST /api/add                    Add media → AIOStreams → stub files
GET  /api/stubs                  List stubs
DELETE /api/stubs/{id}           Delete stub + file

POST /webhook/plex               Plex play event
GET  /proxy/{stub_id}            Stream proxy → Plex
HEAD /proxy/{stub_id}            HEAD pre-flight
GET  /health                     Health
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

import aiohttp
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from pydantic import BaseModel

from gateway.aiostreams_client import AIOStreamsClient
from gateway.fuse_fs import mount as fuse_mount, unmount as fuse_unmount, FUSE_AVAILABLE
from gateway.models import MediaItem, MediaType, Quality, StubState
from gateway.proxy import StreamProxy
from gateway.stub_manager import StubManager
from webhook.handler import PlexWebhookHandler

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s — %(message)s")
logger = logging.getLogger("aiogateway")

_stubs   = StubManager()
_proxy   = StreamProxy()
_client  = AIOStreamsClient()
_webhook: PlexWebhookHandler | None = None
_http:    aiohttp.ClientSession | None = None

CINEMETA = "https://v3-cinemeta.strem.io"


def _emergency_unmount():
    if not FUSE_AVAILABLE:
        return
    mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    try:
        logger.info("Emergency unmount: %s", mountpoint)
        fuse_unmount(mountpoint)
    except Exception as exc:
        logger.warning("Emergency unmount error: %s", exc)


import atexit
import signal as _signal

# Register atexit so normal Python exit always unmounts
atexit.register(_emergency_unmount)


def _signal_handler(signum, frame):
    logger.info("Signal %d received — unmounting FUSE and exiting", signum)
    _emergency_unmount()
    # Re-raise default handler so the process exits with the right code
    _signal.signal(signum, _signal.SIG_DFL)
    os.kill(os.getpid(), signum)


# Catch SIGTERM (docker stop) and SIGINT (Ctrl-C)
for _sig in (_signal.SIGTERM, _signal.SIGINT):
    try:
        _signal.signal(_sig, _signal_handler)
    except (OSError, ValueError):
        pass   # may fail in non-main thread contexts


_ttl_sweep_task: Optional[asyncio.Task] = None
_TTL_SWEEP_INTERVAL = 600   # 10 minutes — fine-grained enough for a day-scale TTL

async def _ttl_sweep_loop():
    """
    Periodically reverts ACTIVE stubs whose active_ttl_days setting has
    elapsed back to PLACEHOLDER. The setting is re-read each cycle so
    changes from the UI take effect without a restart.
    """
    from gateway import settings as _settings
    while True:
        try:
            await asyncio.sleep(_TTL_SWEEP_INTERVAL)
            ttl = _settings.get("active_ttl_days", 0)
            if ttl and ttl > 0:
                reverted = _stubs.sweep_expired(ttl)
                if reverted:
                    logger.info("TTL sweep: reverted %d stub(s) to placeholder (ttl=%g days)",
                               reverted, ttl)
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("TTL sweep error: %s", exc)


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _webhook, _http, _ttl_sweep_task
    await _proxy.open()
    await _client.open()
    _http    = aiohttp.ClientSession(headers={"User-Agent": "AIOGateway/0.3"})
    _webhook = PlexWebhookHandler(_stubs, _client)
    restored = await _stubs.restore()
    logger.info("AIOGateway started — %d stubs restored", restored)

    from gateway import settings as _settings
    _settings.load()

    # Mount virtual FUSE filesystem
    mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    if FUSE_AVAILABLE:
        fuse_mount(_stubs, _client, mountpoint)
        logger.info("FUSE mounted at %s", mountpoint)
    else:
        logger.warning("FUSE unavailable — stub files will be served directly (no seeking)")

    _ttl_sweep_task = asyncio.create_task(_ttl_sweep_loop())

    try:
        yield
    finally:
        # Clean shutdown path — also covered by atexit but explicit is better
        if _ttl_sweep_task:
            _ttl_sweep_task.cancel()
        if FUSE_AVAILABLE:
            fuse_unmount(mountpoint)
        await _proxy.close()
        await _client.close()
        if _http: await _http.close()


app = FastAPI(title="AIOGateway", version="0.3.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ---------------------------------------------------------------------------
# Cinemeta proxy  —  /api/cinemeta/{path}
# ---------------------------------------------------------------------------

@app.get("/api/cinemeta/{path:path}")
async def cinemeta_proxy(path: str):
    """Proxy Cinemeta requests from the browser to avoid any CORS issues."""
    assert _http
    url = f"{CINEMETA}/{path}"
    try:
        async with _http.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
            data = await resp.json(content_type=None)
            return JSONResponse(data, status_code=resp.status)
    except Exception as exc:
        logger.error("Cinemeta proxy error %s: %s", url, exc)
        raise HTTPException(502, f"Cinemeta unreachable: {exc}")


# ---------------------------------------------------------------------------
# Embedded NuvioWeb-style UI
# ---------------------------------------------------------------------------

UI_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>AIOGateway</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet"/>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#080810;--sur:#10101a;--card:#14141f;--card2:#1a1a28;
  --bor:rgba(255,255,255,.08);--bor2:rgba(255,255,255,.14);
  --txt:#f0f0f8;--mut:#7878a0;--acc:#e8a020;--acc2:#f5b840;
  --blue:#4a9eff;--grn:#3dd68c;--red:#ff5555;
  --navh:64px;--f:'Inter',system-ui,sans-serif;
}
html,body{height:100%;background:var(--bg);color:var(--txt);font-family:var(--f);font-size:15px;line-height:1.5;-webkit-font-smoothing:antialiased;overflow-x:hidden;scroll-behavior:smooth}

/* ── Nav pill ───────────────────────────────────────────────── */
.nav{
  position:fixed;top:18px;left:50%;transform:translateX(-50%);z-index:100;
  display:flex;align-items:center;gap:2px;
  background:rgba(8,8,16,.85);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);
  border:1px solid var(--bor2);border-radius:50px;padding:5px 6px;
}
.ni{
  display:flex;align-items:center;gap:6px;padding:8px 20px;
  border-radius:40px;font-size:14px;font-weight:600;cursor:pointer;
  border:none;background:none;color:var(--mut);font-family:var(--f);
  transition:all 150ms;white-space:nowrap;
}
.ni:hover{color:var(--txt);background:rgba(255,255,255,.07)}
.ni.on{background:rgba(255,255,255,.12);color:var(--txt)}

/* ── Hero ───────────────────────────────────────────────────── */
.hero{position:relative;height:100vh;max-height:600px;min-height:420px;overflow:hidden;display:flex;align-items:flex-end}
.hero-bg{
  position:absolute;inset:0;
  background-size:cover;background-position:center 20%;
  transition:background-image .5s ease;
}
.hero-ov{
  position:absolute;inset:0;
  background:linear-gradient(to bottom,
    rgba(8,8,16,.2) 0%,
    rgba(8,8,16,.0) 20%,
    rgba(8,8,16,.5) 55%,
    rgba(8,8,16,.95) 85%,
    var(--bg) 100%);
}
.hero-body{position:relative;z-index:2;padding:0 56px 48px;max-width:620px}
.hero-logo{max-height:64px;max-width:280px;margin-bottom:14px;object-fit:contain;filter:drop-shadow(0 2px 12px rgba(0,0,0,.8));display:none}
.hero-title{font-size:56px;font-weight:900;letter-spacing:-2px;line-height:1;margin-bottom:10px;text-shadow:0 2px 20px rgba(0,0,0,.9)}
.hero-meta{display:flex;align-items:center;gap:10px;font-size:14px;color:rgba(255,255,255,.7);font-weight:500;margin-bottom:10px}
.hero-sep{opacity:.4}
.hero-rating{background:rgba(255,255,255,.15);border-radius:5px;padding:2px 8px;font-size:12px;font-weight:700;color:var(--acc2)}
.hero-desc{font-size:14px;color:rgba(255,255,255,.65);line-height:1.6;margin-bottom:20px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.hero-dots{display:flex;gap:5px;margin-bottom:22px}
.hero-dot{width:24px;height:3px;border-radius:2px;background:rgba(255,255,255,.25);cursor:pointer;transition:all 200ms}
.hero-dot.on{background:#fff;width:32px}
.hero-acts{display:flex;gap:10px}
.btn-hero{
  display:flex;align-items:center;gap:8px;padding:12px 28px;border-radius:8px;
  font-family:var(--f);font-size:14px;font-weight:700;cursor:pointer;border:none;transition:all 150ms;
}
.btn-add{background:var(--acc);color:#000}
.btn-add:hover{background:var(--acc2);transform:translateY(-1px)}
.btn-add.added{background:var(--grn);color:#000}
.btn-info{background:rgba(255,255,255,.16);color:#fff;backdrop-filter:blur(8px)}
.btn-info:hover{background:rgba(255,255,255,.26)}

/* ── Content rows ───────────────────────────────────────────── */
.rows{padding-bottom:48px}
.sec{margin-bottom:8px}
.sec-hd{display:flex;align-items:center;justify-content:space-between;padding:0 56px;margin-bottom:16px}
.sec-title{font-size:18px;font-weight:700;letter-spacing:-.3px;border-left:3px solid var(--acc);padding-left:12px}
.view-all{font-size:13px;font-weight:600;color:var(--mut);cursor:pointer;background:none;border:none;font-family:var(--f);display:flex;align-items:center;gap:3px}
.view-all:hover{color:var(--txt)}
.row{display:flex;gap:14px;overflow-x:auto;overflow-y:visible;padding:4px 56px 14px;scrollbar-width:none}
.row::-webkit-scrollbar{display:none}

/* ── Card ───────────────────────────────────────────────────── */
.card{flex:0 0 138px;cursor:pointer;position:relative;transition:transform 200ms}
.card:hover{transform:scale(1.07) translateY(-2px)}
.cposter{width:138px;height:207px;border-radius:10px;overflow:hidden;background:var(--card2);position:relative;box-shadow:0 4px 16px rgba(0,0,0,.4)}
.card.inlib .cposter{box-shadow:0 0 0 2px var(--grn),0 4px 16px rgba(0,0,0,.4)}
.cposter img{width:100%;height:100%;object-fit:cover;display:block;opacity:0;transition:opacity .3s}
.cposter img.loaded{opacity:1}
.crating{position:absolute;top:7px;right:7px;background:rgba(0,0,0,.78);backdrop-filter:blur(4px);border-radius:5px;padding:2px 7px;font-size:11px;font-weight:700;color:var(--acc2)}
.ccheck{position:absolute;top:7px;right:7px;width:22px;height:22px;border-radius:50%;background:var(--grn);display:none;align-items:center;justify-content:center;font-size:12px;color:#000;font-weight:800}
.card.inlib .ccheck{display:flex}
.card.inlib .crating{display:none}
.cname{font-size:12px;font-weight:600;margin-top:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cyear{font-size:11px;color:var(--mut);margin-top:2px}

/* ── Search page ─────────────────────────────────────────────── */
/* Same padding rhythm and surface tokens as Library/Config pages */
.srchpage{padding:calc(var(--navh) + 28px) 56px 48px}
.srch-hd{margin-bottom:28px}
.srch-bar-wrap{
  display:flex;align-items:center;gap:10px;
  background:var(--card2);border:1px solid var(--bor2);
  border-radius:10px;padding:12px 16px;
  transition:border-color 180ms;
}
.srch-bar-wrap:focus-within{border-color:var(--acc)}
.srch-icon{font-size:17px;color:var(--mut);flex-shrink:0}
.srch-input{
  background:none;border:none;outline:none;font-family:var(--f);
  font-size:15px;color:var(--txt);width:100%;font-weight:500;
}
.srch-input::placeholder{color:var(--mut)}
.srch-clear{
  background:var(--card);border:1px solid var(--bor2);border-radius:7px;
  color:var(--mut);font-size:12px;padding:5px 11px;cursor:pointer;
  font-family:var(--f);font-weight:600;white-space:nowrap;flex-shrink:0;
  transition:all 150ms;display:none;
}
.srch-clear:hover{color:var(--txt);border-color:var(--acc)}
.srch-tabs{display:flex;gap:6px;margin-top:14px}
.srch-tab{
  padding:7px 18px;border-radius:30px;font-size:13px;font-weight:600;
  cursor:pointer;border:1px solid var(--bor2);background:none;
  color:var(--mut);font-family:var(--f);transition:all 150ms;
}
.srch-tab:hover{color:var(--txt)}
.srch-tab.on{background:var(--acc);color:#000;border-color:var(--acc)}
.srch-status{font-size:13px;color:var(--mut);margin-bottom:18px;min-height:20px}
.srch-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(138px,1fr));
  gap:22px 14px;
}
.srch-empty{
  grid-column:1/-1;text-align:center;padding:60px 20px;
  color:var(--mut);
}
.srch-empty-icon{font-size:36px;margin-bottom:12px;opacity:.3}
.srch-empty-title{font-size:14px;font-weight:600;margin-bottom:4px}
.srch-empty-sub{font-size:12px;opacity:.7}

/* ── View All overlay ───────────────────────────────────────── */
.va-overlay{
  position:fixed;inset:0;background:var(--bg);z-index:150;
  overflow-y:auto;scrollbar-width:none;
  opacity:0;pointer-events:none;transition:opacity 200ms;
}
.va-overlay::-webkit-scrollbar{display:none}
.va-overlay.open{opacity:1;pointer-events:all}
.va-inner{padding:calc(var(--navh) + 28px) 56px 48px}
.va-header{display:flex;align-items:center;gap:18px;margin-bottom:28px}
.va-back{
  display:flex;align-items:center;gap:6px;
  background:var(--card2);border:1px solid var(--bor2);border-radius:8px;
  padding:8px 16px;font-family:var(--f);font-size:13px;font-weight:600;
  color:var(--mut);cursor:pointer;transition:all 150ms;flex-shrink:0;
}
.va-back:hover{color:var(--txt);border-color:var(--acc)}
.va-title{font-size:22px;font-weight:800;letter-spacing:-.4px}
.va-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(138px,1fr));
  gap:22px 14px;
}

/* ── Season picker ──────────────────────────────────────────── */
.season-picker{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px}
.season-btn{
  padding:5px 14px;border-radius:6px;font-size:12px;font-weight:700;
  cursor:pointer;border:1px solid var(--bor2);background:var(--card2);
  color:var(--mut);font-family:var(--f);transition:all 140ms;
}
.season-btn:hover{border-color:var(--acc);color:var(--txt)}
.season-btn.on{background:var(--acc);color:#000;border-color:var(--acc)}
.season-btn.all-btn{background:var(--card2);color:var(--txt);border-color:var(--bor2)}
.season-btn.all-btn.on{background:var(--acc);color:#000}

/* ── Skeleton ───────────────────────────────────────────────── */
.skel{background:linear-gradient(90deg,var(--card) 25%,var(--card2) 50%,var(--card) 75%);background-size:200% 100%;animation:shim 1.5s infinite;border-radius:10px}
@keyframes shim{0%{background-position:200% 0}100%{background-position:-200% 0}}

/* ── Modal ──────────────────────────────────────────────────── */
.mbg{position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);z-index:200;display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;transition:opacity 180ms}
.mbg.open{opacity:1;pointer-events:all}
.modal{background:var(--card);border:1px solid var(--bor2);border-radius:18px;width:92%;max-width:520px;overflow:hidden;transform:scale(.94) translateY(12px);transition:transform 180ms}
.mbg.open .modal{transform:scale(1) translateY(0)}
.mhero{height:220px;background-size:cover;background-position:center;position:relative}
.mhero-ov{position:absolute;inset:0;background:linear-gradient(to bottom,rgba(20,20,31,.2) 0%,var(--card) 100%)}
.mbody{padding:20px 24px 26px}
.mtitle{font-size:22px;font-weight:800;letter-spacing:-.5px;margin-bottom:6px}
.mmeta{display:flex;gap:9px;font-size:13px;color:var(--mut);margin-bottom:10px;flex-wrap:wrap;align-items:center}
.mrating{background:var(--card2);border:1px solid var(--bor);padding:2px 8px;border-radius:5px;font-size:11px;font-weight:700;color:var(--acc2)}
.mpills{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:14px}
.mpill{background:var(--card2);border:1px solid var(--bor);padding:3px 11px;border-radius:20px;font-size:12px;font-weight:500}
.moverview{font-size:13px;color:var(--mut);line-height:1.7;margin-bottom:22px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.macts{display:flex;gap:10px}
.mbtn{flex:1;display:flex;align-items:center;justify-content:center;gap:7px;padding:12px;border-radius:9px;font-family:var(--f);font-size:13px;font-weight:700;cursor:pointer;border:none;transition:all 150ms}
.mbtn-add{background:var(--acc);color:#000}
.mbtn-add:hover{background:var(--acc2)}
.mbtn-add.added{background:var(--grn);color:#000}
.mbtn-close{background:var(--card2);color:var(--mut);border:1px solid var(--bor2)}
.mbtn-close:hover{color:var(--txt)}
.mclose{position:absolute;top:14px;right:14px;z-index:10;width:30px;height:30px;border-radius:50%;background:rgba(0,0,0,.6);border:none;color:#fff;font-size:15px;cursor:pointer;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px)}
.mclose:hover{background:rgba(0,0,0,.9)}

/* ── Library page ───────────────────────────────────────────── */
.libpage{padding:calc(var(--navh) + 28px) 56px 48px}
.libhd{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px}
.libtitle{font-size:28px;font-weight:800;letter-spacing:-.5px}
.libgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(138px,1fr));gap:22px 14px}
.stub-state{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;margin-top:5px}
.ss-ph{background:#2a2a14;color:#c8a030}
.ss-ac{background:#0d2a18;color:var(--grn)}
.ss-er{background:#2a0d0d;color:var(--red)}
.ss-rs{background:#141e2e;color:var(--blue);animation:sblink 1.1s infinite}
@keyframes sblink{0%,100%{opacity:1}50%{opacity:.35}}
.del-btn{width:26px;height:26px;border-radius:50%;background:rgba(0,0,0,.7);border:none;color:#888;font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all 130ms}
.del-btn:hover{background:var(--red);color:#fff}

/* ── Search ─────────────────────────────────────────────────── */
.searchbar{display:flex;align-items:center;gap:9px;background:var(--card2);border:1px solid var(--bor2);border-radius:10px;padding:9px 15px}
.searchbar input{background:none;border:none;outline:none;font-family:var(--f);font-size:14px;color:var(--txt);width:100%}
.searchbar input::placeholder{color:var(--mut)}

/* ── Config page ─────────────────────────────────────────────── */
.cfgpage{padding:calc(var(--navh) + 28px) 56px 48px}
.cfgsec{background:var(--card);border:1px solid var(--bor);border-radius:14px;padding:22px;margin-bottom:16px}
.cfgsec h3{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--mut);margin-bottom:16px}
.cfgtabs{display:flex;gap:4px;margin-bottom:24px;border-bottom:1px solid var(--bor);padding-bottom:0}
.cfgtab{
  display:flex;align-items:center;gap:7px;padding:10px 18px;
  font-size:14px;font-weight:600;cursor:pointer;
  border:none;background:none;color:var(--mut);font-family:var(--f);
  border-bottom:2px solid transparent;margin-bottom:-1px;
  transition:all 150ms;white-space:nowrap;
}
.cfgtab:hover{color:var(--txt)}
.cfgtab.on{color:var(--acc);border-bottom-color:var(--acc)}
.cfgpanel{display:none}
.cfgpanel.on{display:block}
.chips{display:flex;flex-wrap:wrap;gap:8px}
.chip{background:var(--card2);border:1px solid var(--bor);border-radius:8px;padding:7px 14px;font-size:12px;display:flex;gap:8px}
.cl{color:var(--mut);font-weight:600}
.cv{font-family:monospace;color:var(--txt)}
.cv.ok{color:var(--grn)}
.cv.er{color:var(--red)}
.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 20px;border-radius:8px;font-family:var(--f);font-size:13px;font-weight:700;cursor:pointer;border:none;transition:all 150ms}
.bp{background:var(--acc);color:#000}.bp:hover{background:var(--acc2)}
.bg2{background:var(--card2);color:var(--mut);border:1px solid var(--bor2)}.bg2:hover{color:var(--txt)}
.tresult{font-size:13px;color:var(--mut);margin-bottom:14px;min-height:20px}
.checklist{font-size:13px;color:var(--mut);line-height:2.2}
.checklist code{background:var(--card2);color:var(--acc2);padding:1px 7px;border-radius:5px;font-size:12px}

/* ── Toast ───────────────────────────────────────────────────── */
.toast{position:fixed;bottom:26px;right:26px;z-index:500;background:var(--card);border:1px solid var(--bor2);border-radius:12px;padding:12px 18px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;animation:tin .2s ease}
@keyframes tin{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.toast.ok{border-color:var(--grn);color:var(--grn)}
.toast.er{border-color:var(--red);color:var(--red)}
.toast.in{border-color:var(--blue);color:var(--blue)}
</style>
</head>
<body>

<!-- Nav -->
<nav class="nav">
  <button class="ni on" onclick="nav('home',this)">Home</button>
  <button class="ni"    onclick="nav('search',this)">Search</button>
  <button class="ni"    onclick="nav('library',this)">Library</button>
  <button class="ni"    onclick="nav('config',this)">Config</button>
</nav>

<!-- SEARCH -->
<div id="pSearch" style="display:none">
  <div class="srchpage">
    <div class="srch-hd">
      <div class="srch-bar-wrap">
        <input class="srch-input" id="srchInput" placeholder="Search movies and series…"
               oninput="onSrchInput(this.value)" onkeydown="if(event.key==='Enter')doSearch()"/>
        <button class="srch-clear" id="srchClear" onclick="clearSearch()">Clear</button>
      </div>
      <div class="srch-tabs">
        <button class="srch-tab on" id="tabAll"    onclick="setTab('all',this)">All</button>
        <button class="srch-tab"    id="tabMovies" onclick="setTab('movie',this)">Movies</button>
        <button class="srch-tab"    id="tabSeries" onclick="setTab('series',this)">Series</button>
      </div>
    </div>
    <div class="srch-status" id="srchStatus"></div>
    <div class="srch-grid" id="srchGrid">
      <div class="srch-empty">
        
        <div class="srch-empty-title">Search for movies and series</div>
        <div class="srch-empty-sub">Powered by Cinemeta — the same source as Stremio</div>
      </div>
    </div>
  </div>
</div>

<!-- HOME -->
<div id="pHome">
  <div class="hero" id="hero">
    <div class="hero-bg" id="heroBg"></div>
    <div class="hero-ov"></div>
    <div class="hero-body">
      <img class="hero-logo" id="heroLogo" alt=""/>
      <div class="hero-title" id="heroTitle">…</div>
      <div class="hero-meta" id="heroMeta"></div>
      <div class="hero-desc" id="heroDesc"></div>
      <div class="hero-dots" id="heroDots"></div>
      <div class="hero-acts">
        <button class="btn-hero btn-add" id="heroBtn" onclick="heroAdd()">Add to Plex</button>
        <button class="btn-hero btn-info" onclick="heroInfo()">More Info</button>
      </div>
    </div>
  </div>

  <div class="rows">
    <div class="sec">
      <div class="sec-hd">
        <span class="sec-title">Popular — Movie</span>
        <button class="view-all" onclick="viewAll('Popular — Movie','catalog/movie/top.json','movie')">View All ›</button>
      </div>
      <div class="row" id="rowM">
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
      </div>
    </div>
    <div class="sec">
      <div class="sec-hd">
        <span class="sec-title">Popular — Series</span>
        <button class="view-all" onclick="viewAll('Popular — Series','catalog/series/top.json','series')">View All ›</button>
      </div>
      <div class="row" id="rowS">
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
      </div>
    </div>
  </div>
</div>

<!-- LIBRARY -->
<div id="pLibrary" style="display:none">
  <div class="libpage">
    <div class="libhd">
      <span class="libtitle">My Library</span>
      <div class="searchbar" style="max-width:300px">
                <input placeholder="Filter…" oninput="filterLib(this.value)" id="libFilter"/>
      </div>
    </div>
    <div id="libGrid">
      <div style="color:var(--mut);font-size:14px;padding:40px 0">Loading…</div>
    </div>
  </div>
</div>

<!-- CONFIG -->
<div id="pConfig" style="display:none">
  <div class="cfgpage">
    <h2 style="font-size:26px;font-weight:800;margin-bottom:24px;letter-spacing:-.5px">Config</h2>

    <div class="cfgtabs">
      <button class="cfgtab on" id="cfgtab-connections" onclick="switchCfgTab('connections')">Connections</button>
      <button class="cfgtab" id="cfgtab-fuse" onclick="switchCfgTab('fuse')">FUSE</button>
      <button class="cfgtab" id="cfgtab-streams" onclick="switchCfgTab('streams')">Streams</button>
      <button class="cfgtab" id="cfgtab-backup" onclick="switchCfgTab('backup')">Backup/Restore</button>
    </div>

    <!-- ── Connections ──────────────────────────────────────────── -->
    <div class="cfgpanel on" id="cfgpanel-connections">
      <div class="cfgsec">
        <h3>AIOStreams connection</h3>
        <div class="chips" id="cfgChips">…</div>
        <div class="tresult" id="tresult" style="margin-top:14px"></div>
        <button class="btn bp" onclick="runTest()">Test connection</button>
      </div>
      <div class="cfgsec">
        <h3>Plex setup</h3>
        <div class="checklist">
          <div>1. Add library folders in Plex:<br>
            <code>/library/Movies</code>&nbsp;&nbsp;<code>/library/Movies4K</code>&nbsp;&nbsp;<code>/library/Series</code>&nbsp;&nbsp;<code>/library/Series4K</code>
          </div>
          <div>2. Plex → Settings → Webhooks → Add:<br>
            <code id="wurl">http://&lt;host&gt;:8001/webhook/plex</code>
          </div>
          <div>3. AIOStreams debrid credentials must return direct stream <code>url</code> fields.</div>
        </div>
      </div>
    </div>

    <!-- ── FUSE ─────────────────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-fuse">
      <div class="cfgsec">
        <h3>Active file TTL</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          After a stub resolves to a real stream, it stays active so re-watching
          seeks instantly without re-resolving. Set a TTL to automatically
          revert resolved files back to lightweight stubs after a period of
          inactivity — useful for reclaiming debrid sessions / CDN links you're
          no longer watching. 0 disables this (stays active indefinitely).
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <input type="number" id="ttlInput" min="0" step="0.5" placeholder="0"
                 style="width:100px;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          <span style="color:var(--mut);font-size:13px">days</span>
          <button class="btn bp" onclick="saveTtl()">Save</button>
          <span id="ttlSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
      </div>
      <div class="cfgsec">
        <h3>FUSE tuning</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          These control the virtual filesystem's read/cache/prefetch behaviour.
          They're set via environment variables in <code>docker-compose.yml</code>
          and require a container restart to change — shown here read-only for
          reference.
        </div>
        <div class="chips" id="fuseChips">…</div>
      </div>
    </div>

    <!-- ── Streams ──────────────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-streams">
      <div class="cfgsec">
        <h3>Stream preferences</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          Applied on top of whatever AIOStreams itself returns (your AIOStreams
          instance's own filters/sort order, configured at <code>/stremio/configure</code>,
          still run first). These preferences re-rank and filter the results
          aiogateway picks from — they don't replace your AIOStreams config.
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Preferred language</div>
            <input type="text" id="prefLanguage" placeholder="e.g. English"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Preferred audio (comma-separated)</div>
            <input type="text" id="prefAudio" placeholder="e.g. Atmos, TrueHD"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer" onclick="document.getElementById('reqSubs').click()">
          <input type="checkbox" id="reqSubs" style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Prefer streams with subtitles available</span>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Min size (GB, 0 = no limit)</div>
            <input type="number" id="minSizeGb" min="0" step="0.5" placeholder="0"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Max size (GB, 0 = no limit)</div>
            <input type="number" id="maxSizeGb" min="0" step="0.5" placeholder="0"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>

        <button class="btn bp" onclick="saveStreamPrefs()">Save</button>
        <span id="streamPrefsSaved" style="color:var(--grn);font-size:13px;display:none;margin-left:10px">Saved</span>
      </div>
    </div>

    <!-- ── Backup/Restore ───────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-backup">
      <div class="cfgsec">
        <h3>Backup &amp; restore</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          Download a backup of your settings and library (every added movie/
          series, including which seasons and quality tiers — not the actual
          streams, which always re-resolve fresh on next play). Restoring
          merges into your current library by default; check "Replace" to
          wipe the current library first.
        </div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <button class="btn bp" onclick="downloadBackup()">Download backup</button>
          <button class="btn" onclick="document.getElementById('restoreFile').click()">Restore from file…</button>
          <input type="file" id="restoreFile" accept="application/json" style="display:none" onchange="restoreFromFile(event)">
          <label style="display:flex;align-items:center;gap:6px;color:var(--mut);font-size:13px;cursor:pointer">
            <input type="checkbox" id="restoreReplace" style="cursor:pointer">
            Replace (wipe current library first)
          </label>
        </div>
        <div id="restoreResult" style="margin-top:12px;font-size:13px"></div>
      </div>
    </div>

  </div>
</div>

<!-- MODAL -->
<div class="mbg" id="modal" onclick="bgClose(event)">
  <div class="modal">
    <div class="mhero" id="mhero" style="position:relative">
      <div class="mhero-ov"></div>
      <button class="mclose" onclick="closeModal()">✕</button>
    </div>
    <div class="mbody">
      <div class="mtitle" id="mtitle"></div>
      <div class="mmeta" id="mmeta"></div>
      <div class="mpills" id="mpills"></div>
      <div class="moverview" id="moverview"></div>
      <!-- Season picker — shown for series only -->
      <div id="seasonPickerWrap" style="display:none;margin-bottom:14px">
        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:8px">Season</div>
        <div class="season-picker" id="seasonPicker"></div>
      </div>
      <div class="macts">
        <button class="mbtn mbtn-add" id="maddBtn" onclick="modalAdd()">Add to Plex</button>
        <button class="mbtn mbtn-close" onclick="closeModal()">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
// ── State ──────────────────────────────────────────────────────
let heroItems = [], heroIdx = 0, heroTimer = null;
let stubs = [], allStubs = [], libImdb = new Set();
let modalItem = null;
const C = '/api/cinemeta';

// ── Nav ────────────────────────────────────────────────────────
function nav(page, el) {
  ['Home','Search','Library','Config'].forEach(p => {
    document.getElementById('p'+p).style.display = 'none';
  });
  document.querySelectorAll('.ni').forEach(n => n.classList.remove('on'));
  document.getElementById('p'+page.charAt(0).toUpperCase()+page.slice(1)).style.display = '';
  el.classList.add('on');
  if (page === 'search')  { document.getElementById('srchInput').focus(); }
  if (page === 'library') loadLib();
  if (page === 'config')  loadCfg();
}

// ── Cinemeta fetch ─────────────────────────────────────────────
async function cmFetch(path) {
  const r = await fetch(`${C}/${path}`);
  if (!r.ok) throw new Error(`Cinemeta ${r.status}: ${path}`);
  return r.json();
}

// ── Hero ───────────────────────────────────────────────────────
async function loadHero() {
  const data = await cmFetch('catalog/movie/top.json');
  const items = (data.metas || []).filter(m => m.background || m.poster).slice(0, 9);
  if (!items.length) return;
  heroItems = items;
  buildDots();
  setHero(0);
  heroTimer = setInterval(() => setHero((heroIdx+1) % heroItems.length), 7000);
}

function buildDots() {
  document.getElementById('heroDots').innerHTML =
    heroItems.map((_,i) => `<div class="hero-dot${i===0?' on':''}" onclick="setHero(${i})"></div>`).join('');
}

function setHero(i) {
  heroIdx = i;
  const m = heroItems[i];
  if (!m) return;

  // Backdrop
  const bg = m.background || m.poster || '';
  document.getElementById('heroBg').style.backgroundImage = bg ? `url(${bg})` : 'none';

  // Logo
  const logoEl = document.getElementById('heroLogo');
  if (m.logo) {
    logoEl.src = m.logo;
    logoEl.style.display = 'block';
    document.getElementById('heroTitle').style.display = 'none';
  } else {
    logoEl.style.display = 'none';
    document.getElementById('heroTitle').style.display = 'block';
    document.getElementById('heroTitle').textContent = m.name || '';
  }

  // Meta
  const year = m.releaseInfo ? m.releaseInfo.split('–')[0] : '';
  const rating = m.imdbRating ? `${m.imdbRating}` : '';
  const genres = (m.genres || []).slice(0,2).join(' · ');
  const metaParts = [year, genres].filter(Boolean);
  document.getElementById('heroMeta').innerHTML =
    metaParts.map(p=>`<span>${p}</span>`).join('<span class="hero-sep">•</span>') +
    (rating ? `<span class="hero-sep">•</span><span class="hero-rating">${rating}</span>` : '');

  document.getElementById('heroDesc').textContent = m.description || '';

  // Dots
  document.querySelectorAll('.hero-dot').forEach((d,j) => d.classList.toggle('on', j===i));

  // Add button state
  const btn = document.getElementById('heroBtn');
  const inLib = libImdb.has(m.id);
  btn.textContent = inLib ? 'In Library' : 'Add to Plex';
  btn.className = 'btn-hero btn-add' + (inLib ? ' added' : '');
}

function heroAdd()  { if (heroItems[heroIdx]) openModal(heroItems[heroIdx], 'movie'); }
function heroInfo() { if (heroItems[heroIdx]) openModal(heroItems[heroIdx], 'movie'); }

// ── Item store — avoids embedding raw JSON in onclick attrs ───
const _items = {};
function _store(m, type) { _items[m.id] = { m, type }; }
function _click(id) { const e = _items[id]; if (e) openModal(e.m, e.type); }

// ── Card rows ──────────────────────────────────────────────────
function card(m, type) {
  _store(m, type);
  const inLib = libImdb.has(m.id);
  const year = (m.releaseInfo || '').split(/[-–]/)[0].trim();
  const rating = m.imdbRating || '';
  const name = (m.name || '').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const sid = CSS.escape(m.id);
  return `<div class="card${inLib?' inlib':''}" id="c${sid}" onclick="_click('${m.id.replace(/'/g,"\\'")}')">
    <div class="cposter">
      ${m.poster ? `<img src="${m.poster}" loading="lazy" onload="this.classList.add('loaded')" onerror="this.parentNode.style.background='#1a1a28'"/>` : ''}
      ${rating ? `<div class="crating">${rating}</div>` : ''}
      <div class="ccheck">✓</div>
    </div>
    <div class="cname">${name}</div>
    <div class="cyear">${year}</div>
  </div>`;
}

async function loadRow(elId, path, type) {
  try {
    const data = await cmFetch(path);
    const items = (data.metas || []).slice(0, 20);
    _rowCache[path] = data.metas || [];   // cache full list for View All
    document.getElementById(elId).innerHTML = items.map(m => card(m, type)).join('');
    return items;
  } catch(e) {
    document.getElementById(elId).innerHTML = `<div style="color:var(--red);font-size:13px;padding:20px">Failed: ${e.message}</div>`;
    return [];
  }
}

// ── Modal ──────────────────────────────────────────────────────
// Selected season: null = all, number = specific season
let _selectedSeason = null;

async function openModal(item, type) {
  modalItem = { ...item, _type: type };
  _selectedSeason = null;

  // Try to get full meta if we only have preview
  if (!item.description && item.id) {
    try {
      const full = await cmFetch(`meta/${type}/${item.id}.json`);
      if (full.meta) { modalItem = { ...full.meta, _type: type }; item = modalItem; }
    } catch {}
  }

  document.getElementById('mtitle').textContent = item.name || '';
  const year = item.releaseInfo ? item.releaseInfo.split('–')[0] : '';
  const rating = item.imdbRating ? `<span class="mrating">${item.imdbRating}</span>` : '';
  document.getElementById('mmeta').innerHTML =
    `<span>${type==='series'?'Series':'Movie'}</span>` +
    (year ? `<span>•</span><span>${year}</span>` : '') +
    rating;
  document.getElementById('mpills').innerHTML = (item.genres||[]).slice(0,4).map(g=>`<span class="mpill">${g}</span>`).join('');
  document.getElementById('moverview').textContent = item.description || '';
  document.getElementById('mhero').style.backgroundImage =
    `url(${item.background || item.poster || ''})`;

  const inLib = libImdb.has(item.id);
  const btn = document.getElementById('maddBtn');
  btn.textContent = inLib ? 'In Library' : 'Add to Plex';
  btn.className = 'mbtn mbtn-add' + (inLib ? ' added' : '');
  btn.disabled = false;

  // Season picker for series
  const wrap = document.getElementById('seasonPickerWrap');
  const picker = document.getElementById('seasonPicker');
  if (type === 'series') {
    wrap.style.display = 'block';
    picker.innerHTML = '<div style="color:var(--mut);font-size:12px">Loading seasons…</div>';
    buildSeasonPicker(item.id, picker);
  } else {
    wrap.style.display = 'none';
    picker.innerHTML = '';
  }

  document.getElementById('modal').classList.add('open');
}

async function buildSeasonPicker(imdbId, picker) {
  try {
    const r = await fetch(`/api/series/${imdbId}/episodes`);
    const d = await r.json();
    const episodes = d.episodes || [];

    // Get unique aired season numbers
    const seasons = [...new Set(
      episodes.filter(e => e.aired).map(e => e.season)
    )].filter(Boolean).sort((a,b)=>a-b);

    if (!seasons.length) {
      picker.innerHTML = '<div style="color:var(--mut);font-size:12px">No aired seasons found</div>';
      return;
    }

    // All button + season buttons
    const allBtn = `<button class="season-btn all-btn on" id="sbAll" onclick="selectSeason(null)">All</button>`;
    const seasonBtns = seasons.map(s =>
      `<button class="season-btn" id="sb${s}" onclick="selectSeason(${s})">S${String(s).padStart(2,'0')}</button>`
    ).join('');
    picker.innerHTML = allBtn + seasonBtns;
  } catch {
    picker.innerHTML = '<div style="color:var(--mut);font-size:12px">Could not load seasons</div>';
  }
}

function selectSeason(season) {
  _selectedSeason = season;
  // Update button styles
  document.querySelectorAll('.season-btn').forEach(b => b.classList.remove('on'));
  const target = season === null
    ? document.getElementById('sbAll')
    : document.getElementById('sb' + season);
  if (target) target.classList.add('on');
}

function closeModal() { document.getElementById('modal').classList.remove('open'); }
function bgClose(e) { if (e.target === document.getElementById('modal')) closeModal(); }

async function modalAdd() {
  if (!modalItem) return;
  const btn = document.getElementById('maddBtn');
  const imdbId = modalItem.id;

  if (!imdbId || !imdbId.startsWith('tt')) {
    toast('No IMDb ID for this title', 'er'); return;
  }
  if (libImdb.has(imdbId)) { toast('Already in library', 'in'); return; }

  btn.textContent = 'Loading streams…';
  btn.disabled = true;

  const title = modalItem.name || '';
  const year  = parseInt((modalItem.releaseInfo||'').slice(0,4)) || null;
  const type  = modalItem._type === 'series' ? 'series' : 'movie';

  try {
    const poster = modalItem.poster || '';
    const body = { imdb_id:imdbId, title, year, media_type:type, poster };
    if (type === 'series' && _selectedSeason !== null) {
      body.season = _selectedSeason;
    }
    const r = await fetch('/api/add', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify(body),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || JSON.stringify(d));

    libImdb.add(imdbId);
    btn.textContent = 'In Library'; btn.className = 'mbtn mbtn-add added'; btn.disabled = false;

    // Update hero button
    const hm = heroItems[heroIdx];
    if (hm && hm.id === imdbId) {
      const hb = document.getElementById('heroBtn');
      hb.textContent = 'In Library'; hb.className = 'btn-hero btn-add added';
    }

    // Mark card
    const c = document.getElementById('c'+modalItem.id);
    if (c) c.classList.add('inlib');

    if (type === 'series') {
      const seasonLabel = _selectedSeason !== null ? ` (Season ${_selectedSeason})` : '';
      toast(`Added "${title}"${seasonLabel} — scanning in background…`, 'ok');
      pollScan(imdbId, title);
    } else {
      toast(`Added "${title}" — ${d.streams_found} streams${d.has_4k?' (HD+4K)':''}`, 'ok');
    }
    await syncStubs();
  } catch(e) {
    btn.textContent = 'Add to Plex'; btn.disabled = false;
    // Surface the full AIOStreams diagnostic in the toast
    const msg = e.message || 'Unknown error';
    toast(msg.length > 120 ? msg.slice(0, 117) + '…' : msg, 'er');
    console.error('Add to Plex error:', e.message);
  }
}

// ── Stubs / Library ────────────────────────────────────────────
async function syncStubs() {
  try {
    const r = await fetch('/api/stubs');
    const d = await r.json();
    stubs = d.stubs || [];
    libImdb = new Set(stubs.map(s => s.media_id.split('_')[0]));
  } catch {}
}

async function loadLib() {
  await syncStubs();
  allStubs = [...stubs];
  renderLib(stubs);
}

function filterLib(q) {
  const f = q ? allStubs.filter(s=>(s.title||s.media_id).toLowerCase().includes(q.toLowerCase())) : allStubs;
  renderLib(f);
}

// ── Library: group stubs by base IMDb ID (one card per title) ─
function groupStubs(items) {
  const map = {};
  items.forEach(s => {
    const base = s.media_id.split('_')[0];
    if (!map[base]) map[base] = {
      title: s.title || base,
      imdb: base,
      poster: s.poster || '',
      media_type: s.media_type || 'movie',
      stubs: []
    };
    if (s.poster && !map[base].poster) map[base].poster = s.poster;
    map[base].stubs.push(s);
  });
  return Object.values(map);
}

function libGroupCard(g) {
  const has4k = g.stubs.some(s => s.quality === '4k');
  const hasHd = g.stubs.some(s => s.quality === 'hd');
  const states = g.stubs.map(s => s.state);
  const state = states.includes('error') ? 'error'
              : states.includes('resolving') ? 'resolving'
              : states.includes('active') ? 'active' : 'placeholder';
  const sc = {placeholder:'ss-ph',active:'ss-ac',error:'ss-er',resolving:'ss-rs'}[state]||'ss-ph';
  const safeId = g.imdb.replace(/[^a-z0-9]/gi,'');
  const badges = [
    hasHd ? `<span style="background:rgba(0,0,0,.88);color:var(--blue);border-radius:5px;padding:2px 7px;font-size:10px;font-weight:700;display:block">HD</span>` : '',
    has4k ? `<span style="background:rgba(0,0,0,.88);color:var(--acc2);border-radius:5px;padding:2px 7px;font-size:10px;font-weight:700;display:block">4K</span>` : ''
  ].filter(Boolean).join('');
  const posterHtml = g.poster
    ? `<img src="${g.poster}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:10px;opacity:0;transition:opacity .3s" onload="this.style.opacity=1" onerror="this.style.display='none'"/>`
    : '';
  const cardClick = g.media_type === 'series'
    ? `openSeriesDetail('${safeId}')`
    : `openDelModal('${safeId}')`;
  const alertBadge = (g.media_type === 'series' && g._hasMissing)
    ? `<div style="position:absolute;bottom:8px;left:50%;transform:translateX(-50%);background:var(--red);border-radius:5px;padding:2px 8px;font-size:9px;font-weight:700;color:#fff;white-space:nowrap">missing eps</div>`
    : '';
  return `<div style="cursor:pointer" onclick="${cardClick}">
    <div class="cposter" style="position:relative">
      ${posterHtml}
      <div style="position:absolute;top:8px;right:8px;display:flex;flex-direction:column;gap:4px;align-items:flex-end">${badges}</div>
      <button class="del-btn" style="position:absolute;top:8px;left:8px" onclick="event.stopPropagation();openDelModal('${safeId}')" title="Remove">✕</button>
      ${alertBadge}
    </div>
    <div class="cname" style="margin-top:8px">${g.title}</div>
    <span class="stub-state ${sc}">${state}</span>
  </div>`;
}

function renderLib(items) {
  const el = document.getElementById('libGrid');
  el.style.display = 'block';
  if (!items.length) {
    el.innerHTML = `<div style="color:var(--mut);font-size:14px;padding:40px 0">
      No stubs yet. Browse Home or Search and click Add to Plex.
    </div>`; return;
  }
  const groups = groupStubs(items);
  window._libGroups = {};
  groups.forEach(g => { window._libGroups[g.imdb.replace(/[^a-z0-9]/gi,'')] = g; });

  const movies = groups.filter(g => g.media_type !== 'series');
  const series = groups.filter(g => g.media_type === 'series');

  let html = '';
  if (movies.length) {
    html += `<div style="margin-bottom:36px">
      <div class="sec-title" style="margin-bottom:18px">Movies</div>
      <div class="libgrid">${movies.map(libGroupCard).join('')}</div>
    </div>`;
  }
  if (series.length) {
    html += `<div>
      <div class="sec-title" style="margin-bottom:18px">TV Shows</div>
      <div class="libgrid">${series.map(libGroupCard).join('')}</div>
    </div>`;
  }
  el.innerHTML = html;
}


// ── Series detail modal ────────────────────────────────────────
const _bg_scans_ui = new Set();

async function openSeriesDetail(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;

  // Show loading immediately
  const dlg = document.createElement('div');
  dlg.id = 'seriesDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.82);backdrop-filter:blur(16px);z-index:300;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `<div style="color:var(--mut);font-size:14px">Loading…</div>`;
  dlg.addEventListener('click', e => { if (e.target===dlg) dlg.remove(); });
  document.body.appendChild(dlg);

  let epData;
  try {
    const r = await fetch(`/api/series/${g.imdb}/episodes`);
    epData = await r.json();
  } catch(e) {
    dlg.querySelector('div').innerHTML = '<span style="color:var(--red)">Failed to load</span>';
    return;
  }

  const episodes   = epData.episodes || [];
  const isScanning = _bg_scans_ui.has(g.imdb) || epData.scanning;

  // Group ALL episodes by season — including seasons with zero stubs
  // ("not yet requested") and unaired ones, not just aired+stubbed ones.
  const seasonMap = {};
  episodes.forEach(ep => {
    seasonMap[ep.season] = seasonMap[ep.season] || [];
    seasonMap[ep.season].push(ep);
  });
  const seasons = Object.keys(seasonMap).map(Number).sort((a,b)=>a-b);

  // A season is "requested" if at least one of its episodes has a stub
  // (HD or 4K) — distinct from "fully downloaded", since a requested
  // season can still have missing episodes.
  const seasonRequested = {};
  seasons.forEach(sn => {
    seasonRequested[sn] = seasonMap[sn].some(e => e.has_hd || e.has_4k);
  });
  const unrequestedSeasons = seasons.filter(sn => !seasonRequested[sn]);

  const totalAired   = episodes.filter(e=>e.aired).length;
  const totalStubbed = episodes.filter(e=>e.aired && e.has_hd).length;
  const totalMissing = totalAired - totalStubbed;

  // Store on group for alert badge
  if (window._libGroups && window._libGroups[safeId]) {
    window._libGroups[safeId]._hasMissing = totalMissing > 0;
  }

  const escTitle = g.title.replace(/\\/g,'\\\\').replace(/'/g,"\\'");
  const escPoster = (g.poster||'').replace(/'/g,"\\'");

  const seasonRows = seasons.map(sn => {
    const eps = seasonMap[sn].sort((a,b)=>a.episode-b.episode);
    const requested = seasonRequested[sn];
    const airedEps = eps.filter(e=>e.aired);
    const missing = airedEps.filter(e=>!e.has_hd).length;

    // Unrequested season: show a single "Request season" row instead of
    // per-episode chips (there's nothing to show per-episode yet).
    if (!requested) {
      const airedCount = airedEps.length;
      const futureCount = eps.length - airedCount;
      const countLabel = airedCount > 0
        ? `${airedCount} ep${airedCount!==1?'s':''}${futureCount>0?` &middot; ${futureCount} upcoming`:''}`
        : `${futureCount} upcoming ep${futureCount!==1?'s':''}`;
      return `<div style="margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;gap:10px;background:var(--card2);border:1px solid var(--bor);border-radius:10px;padding:12px 14px">
        <div>
          <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:3px">
            Season ${sn} <span style="color:var(--txt);font-weight:600">${countLabel}</span>
          </div>
          <div style="font-size:11px;color:var(--mut)">Not requested yet</div>
        </div>
        <button id="reqSeasonBtn_${sn}" class="mbtn mbtn-add" style="padding:8px 16px;font-size:12px;flex-shrink:0;width:auto"
          onclick="requestSeason('${safeId}','${g.imdb}','${escTitle}','${escPoster}',${sn},'${g.year||''}')"
          ${airedCount===0 ? 'disabled title="No aired episodes yet"' : ''}>
          ${airedCount===0 ? 'Not aired' : 'Request season'}
        </button>
      </div>`;
    }

    const chips = airedEps.map(ep => {
      const eStr = String(ep.episode).padStart(2,'0');
      if (ep.has_hd) {
        const col = ep.has_4k ? 'var(--acc2)' : 'var(--blue)';
        const lbl = ep.has_4k ? 'HD+4K' : 'HD';
        return `<span style="background:var(--card2);border:1px solid var(--bor);border-radius:5px;padding:3px 7px;font-size:10px;font-weight:700;color:${col};white-space:nowrap">E${eStr} <span style="color:var(--mut);font-weight:400">${lbl}</span></span>`;
      } else {
        const sid   = `ep_${sn}_${ep.episode}`;
        return `<span id="${sid}"
          onclick="searchMissingEp('${safeId}','${g.imdb}','${escTitle}',${sn},${ep.episode},'${escPoster}','${g.year||''}')"
          title="Click to search for S${String(sn).padStart(2,'0')}E${eStr}"
          style="background:transparent;border:1px dashed rgba(255,255,255,.18);border-radius:5px;padding:3px 7px;font-size:10px;font-weight:700;color:rgba(255,255,255,.35);cursor:pointer;white-space:nowrap;transition:all 140ms"
          onmouseover="this.style.borderColor='var(--acc)';this.style.color='var(--txt)'"
          onmouseout="this.style.borderColor='rgba(255,255,255,.18)';this.style.color='rgba(255,255,255,.35)'">E${eStr} <span style="font-weight:400">missing</span></span>`;
      }
    }).join('');

    const mbadge = missing > 0
      ? `<span style="color:var(--red);font-size:10px;font-weight:600;margin-left:6px">${missing} missing</span>` : '';
    const reqBadge = `<span style="color:var(--grn);font-size:10px;font-weight:600;margin-left:6px">requested</span>`;

    return `<div style="margin-bottom:16px">
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:8px">
        Season ${sn} <span style="color:var(--txt);font-weight:600">${airedEps.length} ep${airedEps.length!==1?'s':''}</span>${reqBadge}${mbadge}
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:5px">${chips}</div>
    </div>`;
  }).join('');

  const posterEl = g.poster
    ? `<img src="${g.poster}" style="width:52px;height:78px;object-fit:cover;border-radius:7px;flex-shrink:0"/>`
    : '';
  const scanBadge = isScanning
    ? `<div style="font-size:11px;color:var(--blue);margin-top:4px;display:flex;align-items:center;gap:5px"><span style="width:6px;height:6px;border-radius:50%;background:var(--blue);display:inline-block;animation:sblink 1s infinite"></span> Scanning…</div>` : '';
  const missingNote = totalMissing > 0 && !isScanning
    ? `<div style="font-size:11px;color:var(--red);margin-top:3px">${totalMissing} ep${totalMissing!==1?'s':''} missing</div>` : '';

  // Only seasons with at least one aired episode can actually be
  // requested right now — an unaired season would just 404.
  const requestableSeasons = unrequestedSeasons.filter(
    sn => seasonMap[sn].some(e => e.aired)
  );
  const requestAllBtn = requestableSeasons.length > 0
    ? `<button id="reqAllBtn" onclick='requestAllSeasons("${safeId}","${g.imdb}","${escTitle}","${escPoster}","${g.year||''}",${JSON.stringify(requestableSeasons)})'
        style="background:none;border:1px solid var(--acc);color:var(--acc);border-radius:6px;padding:3px 10px;font-size:11px;font-weight:700;cursor:pointer;margin-left:8px;white-space:nowrap">
        Request all (${requestableSeasons.length})
      </button>`
    : '';

  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:18px;width:100%;max-width:520px;max-height:82vh;display:flex;flex-direction:column;overflow:hidden">
      <div style="padding:20px 22px 16px;border-bottom:1px solid var(--bor);display:flex;align-items:flex-start;gap:14px;flex-shrink:0">
        ${posterEl}
        <div style="flex:1;min-width:0">
          <div style="font-size:17px;font-weight:800;letter-spacing:-.3px;margin-bottom:3px">${g.title}</div>
          <div style="font-size:12px;color:var(--mut);display:flex;align-items:center;flex-wrap:wrap;row-gap:6px">
            <span>${seasons.length} season${seasons.length!==1?'s':''} &middot; ${totalStubbed}/${totalAired} episodes</span>${requestAllBtn}
          </div>
          ${scanBadge}${missingNote}
        </div>
        <button onclick="document.getElementById('seriesDlg').remove()" style="background:var(--card2);border:1px solid var(--bor);border-radius:8px;color:var(--mut);width:30px;height:30px;cursor:pointer;font-size:14px;flex-shrink:0">✕</button>
      </div>
      <div style="padding:18px 22px;overflow-y:auto;flex:1">
        ${seasons.length ? seasonRows : '<div style="color:var(--mut);font-size:13px">No episodes found yet.</div>'}
      </div>
      <div style="padding:14px 22px;border-top:1px solid var(--bor);display:flex;gap:10px;flex-shrink:0">
        <button id="rescanBtn" class="mbtn mbtn-add"
          onclick="rescanSeries('${safeId}','${g.imdb}','${escTitle}','${escPoster}','${g.year||''}')"
          style="${isScanning?'opacity:.5;pointer-events:none':''}">
          ${isScanning ? 'Scanning…' : 'Rescan all'}
        </button>
        <button class="mbtn mbtn-add" onclick="document.getElementById('seriesDlg').remove();openDelModal('${safeId}')" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)">Remove</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('seriesDlg').remove()">Close</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target===dlg) dlg.remove(); });
}

async function requestSeason(safeId, imdbId, title, poster, season, year) {
  const btn = document.getElementById(`reqSeasonBtn_${season}`);
  if (btn) { btn.textContent = 'Requesting…'; btn.disabled = true; }
  _bg_scans_ui.add(imdbId);
  toast(`Requesting Season ${season} of "${title}"`, 'in');
  try {
    const r = await fetch('/api/add', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ imdb_id:imdbId, title, media_type:'series', poster, season, year: year ? parseInt(year) : null }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail||'Error');
    document.getElementById('seriesDlg')?.remove();
    pollScan(imdbId, title);
  } catch(e) {
    _bg_scans_ui.delete(imdbId);
    if (btn) { btn.textContent = 'Request season'; btn.disabled = false; }
    toast(e.message, 'er');
  }
}

async function requestAllSeasons(safeId, imdbId, title, poster, year, unrequestedSeasons) {
  const btn = document.getElementById('reqAllBtn');
  if (btn) { btn.textContent = 'Requesting…'; btn.style.pointerEvents = 'none'; btn.style.opacity = '.6'; }
  _bg_scans_ui.add(imdbId);
  toast(`Requesting ${unrequestedSeasons.length} season${unrequestedSeasons.length!==1?'s':''} of "${title}"`, 'in');
  try {
    // One targeted request per unrequested season (not a blanket whole-
    // series rescan) — avoids re-querying AIOStreams for episodes that
    // are already stubbed, which create_stubs() would just no-op on
    // anyway but wastes API calls/rate-limit budget at series-add scale.
    for (const sn of unrequestedSeasons) {
      const r = await fetch('/api/add', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ imdb_id:imdbId, title, media_type:'series', poster, season: sn, year: year ? parseInt(year) : null }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.detail||'Error');
    }
    document.getElementById('seriesDlg')?.remove();
    pollScan(imdbId, title);
  } catch(e) {
    _bg_scans_ui.delete(imdbId);
    if (btn) { btn.textContent = `Request all`; btn.style.pointerEvents = 'auto'; btn.style.opacity = '1'; }
    toast(e.message, 'er');
  }
}

async function searchMissingEp(safeId, imdbId, title, season, episode, poster, year) {
  const chipId = `ep_${season}_${episode}`;
  const chip   = document.getElementById(chipId);
  const eStr   = String(episode).padStart(2,'0');
  const sStr   = String(season).padStart(2,'0');
  if (chip) {
    chip.textContent = `E${eStr} searching…`;
    chip.style.color = 'var(--blue)';
    chip.style.borderColor = 'var(--blue)';
    chip.style.borderStyle = 'solid';
    chip.style.pointerEvents = 'none';
    chip.onmouseover = chip.onmouseout = null;
  }
  try {
    const r = await fetch(`/api/series/${imdbId}/episode/${season}/${episode}`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({imdb_id:imdbId, title, media_type:'series', poster, year:year?parseInt(year):null}),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail||'No streams found');
    if (chip) {
      const lbl = d.has_4k ? 'HD+4K' : 'HD';
      const col = d.has_4k ? 'var(--acc2)' : 'var(--blue)';
      chip.style.background = 'var(--card2)';
      chip.style.borderColor = 'var(--bor)';
      chip.style.color = col;
      chip.innerHTML = `E${eStr} <span style="color:var(--mut);font-weight:400">${lbl}</span>`;
      chip.style.cursor = 'default';
      chip.onclick = null;
    }
    toast(`Found S${sStr}E${eStr}`, 'ok');
    await syncStubs();
  } catch(e) {
    if (chip) {
      chip.textContent = `E${eStr} not found`;
      chip.style.color = 'var(--red)';
      chip.style.borderColor = 'var(--red)';
      chip.style.pointerEvents = 'auto';
    }
    toast(`S${sStr}E${eStr}: ${e.message}`, 'er');
  }
}


async function rescanSeries(safeId, imdbId, title, poster, year) {
  const btn = document.getElementById('rescanBtn');
  if (btn) { btn.textContent='Scanning…'; btn.style.opacity='.5'; btn.style.pointerEvents='none'; }
  _bg_scans_ui.add(imdbId);
  document.getElementById('seriesDlg')?.remove();
  toast(`Rescanning "${title}"`, 'in');
  try {
    const r = await fetch('/api/add', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ imdb_id:imdbId, title, media_type:'series', poster, year: year ? parseInt(year) : null }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail||'Error');
    pollScan(imdbId, title);
  } catch(e) {
    _bg_scans_ui.delete(imdbId);
    toast(e.message, 'er');
  }
}

// ── Delete options modal ────────────────────────────────────────
function openDelModal(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;
  const hasHd = g.stubs.some(s => s.quality === 'hd');
  const has4k = g.stubs.some(s => s.quality === '4k');
  const both  = hasHd && has4k;

  const dlg = document.createElement('div');
  dlg.id = 'delDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:300;display:flex;align-items:center;justify-content:center';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px 28px 24px;max-width:360px;width:90%">
      <div style="font-size:17px;font-weight:800;margin-bottom:6px">Remove from Plex</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:22px">${g.title}</div>
      <div style="display:flex;flex-direction:column;gap:10px">
        ${hasHd ? `<button class="mbtn mbtn-add" style="background:#1a2e40;color:var(--blue);border:1px solid rgba(74,158,255,.3)" onclick="delQuality('${safeId}','hd')">Delete HD stub</button>` : ''}
        ${has4k ? `<button class="mbtn mbtn-add" style="background:#2e1e00;color:var(--acc2);border:1px solid rgba(232,160,32,.3)" onclick="delQuality('${safeId}','4k')">Delete 4K stub</button>` : ''}
        ${both  ? `<button class="mbtn mbtn-add" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)" onclick="delQuality('${safeId}','both')">Delete both (HD + 4K)</button>` : ''}
        <button class="mbtn mbtn-close" onclick="document.getElementById('delDlg').remove()" style="margin-top:4px">Cancel</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

async function delQuality(safeId, quality) {
  document.getElementById('delDlg')?.remove();
  document.getElementById('seriesDlg')?.remove();
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;

  if (quality === 'both') {
    // Use series delete endpoint — cancels scan + removes everything atomically
    await fetch(`/api/series/${g.imdb}`, { method: 'DELETE' });
    toast('Series removed', 'ok');
  } else {
    const toDelete = quality === 'hd'
      ? g.stubs.filter(s => s.quality === 'hd')
      : g.stubs.filter(s => s.quality === '4k');
    for (const s of toDelete) {
      await fetch(`/api/stubs/${s.stub_id}`, { method: 'DELETE' });
    }
    toast(`Removed ${quality.toUpperCase()} stubs`, 'ok');
  }
  loadLib();
}

async function delStub(id) {
  await fetch(`/api/stubs/${id}`, { method: 'DELETE' });
  toast('Stub deleted', 'ok');
  loadLib();
}

// ── Config ────────────────────────────────────────────────────
function switchCfgTab(name) {
  document.querySelectorAll('.cfgtab').forEach(el => el.classList.remove('on'));
  document.querySelectorAll('.cfgpanel').forEach(el => el.classList.remove('on'));
  document.getElementById(`cfgtab-${name}`).classList.add('on');
  document.getElementById(`cfgpanel-${name}`).classList.add('on');
}

async function loadCfg() {
  try {
    const d = await (await fetch('/api/config')).json();
    document.getElementById('cfgChips').innerHTML =
      chip('AIOSTREAMS_URL', d.aiostreams_url, true) +
      chip('UUID',           d.uuid_set ? 'Set' : 'Not set', d.uuid_set) +
      chip('PASSWORD',       d.password_set ? 'Set' : 'Not set', d.password_set);
    document.getElementById('wurl').textContent = `http://${location.hostname}:8001/webhook/plex`;

    const f = d.fuse || {};
    document.getElementById('fuseChips').innerHTML =
      chip('FUSE_MOUNTPOINT',        f.mountpoint, true) +
      chip('FUSE_BLOCK_MB',          f.block_mb, true) +
      chip('FUSE_CACHE_BLOCKS',      f.cache_blocks, true) +
      chip('FUSE_PREFETCH_AHEAD',    f.prefetch_ahead, true) +
      chip('FUSE_READ_TIMEOUT',      f.read_timeout, true) +
      chip('FUSE_RESOLVE_TIMEOUT',   f.resolve_timeout, true) +
      chip('FUSE_MAX_INFLIGHT',      f.max_inflight, true) +
      chip('FUSE_POOL_CONNECTIONS',  f.pool_connections, true) +
      chip('FUSE_POOL_MAXSIZE',      f.pool_maxsize, true);
  } catch {}
  try {
    const s = await (await fetch('/api/settings')).json();
    document.getElementById('ttlInput').value = s.active_ttl_days ?? 0;
    document.getElementById('prefLanguage').value = s.preferred_language ?? '';
    document.getElementById('prefAudio').value = (s.preferred_audio ?? []).join(', ');
    document.getElementById('reqSubs').checked = !!s.require_subtitles;
    document.getElementById('minSizeGb').value = s.min_size_gb ?? 0;
    document.getElementById('maxSizeGb').value = s.max_size_gb ?? 0;
  } catch {}
}
function chip(l,v,ok){return`<div class="chip"><span class="cl">${l}</span><span class="cv ${ok?'ok':'er'}">${v}</span></div>`}

async function saveTtl() {
  const input = document.getElementById('ttlInput');
  const val = parseFloat(input.value);
  if (isNaN(val) || val < 0) {
    toast('Enter a number ≥ 0', 'er');
    return;
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active_ttl_days: val })
    });
    if (!r.ok) throw new Error('save failed');
    const saved = document.getElementById('ttlSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch {
    toast('Could not save setting', 'er');
  }
}

async function saveStreamPrefs() {
  const minGb = parseFloat(document.getElementById('minSizeGb').value) || 0;
  const maxGb = parseFloat(document.getElementById('maxSizeGb').value) || 0;
  if (minGb < 0 || maxGb < 0) {
    toast('Sizes must be ≥ 0', 'er');
    return;
  }
  if (minGb && maxGb && minGb > maxGb) {
    toast('Min size cannot be greater than max size', 'er');
    return;
  }
  const audio = document.getElementById('prefAudio').value
    .split(',').map(s => s.trim()).filter(Boolean);

  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        preferred_language: document.getElementById('prefLanguage').value.trim(),
        preferred_audio: audio,
        require_subtitles: document.getElementById('reqSubs').checked,
        min_size_gb: minGb,
        max_size_gb: maxGb,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('streamPrefsSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save preferences', 'er');
  }
}

function downloadBackup() {
  // Plain navigation triggers the browser's normal file-download flow and
  // picks up the Content-Disposition filename from the server response.
  window.location.href = '/api/backup';
}

async function restoreFromFile(event) {
  const file = event.target.files[0];
  event.target.value = '';   // allow re-selecting the same file later
  if (!file) return;

  const resultEl = document.getElementById('restoreResult');
  resultEl.innerHTML = '<span style="color:var(--mut)">Restoring…</span>';

  let bundle;
  try {
    const text = await file.text();
    bundle = JSON.parse(text);
  } catch {
    resultEl.innerHTML = '<span style="color:var(--red)">✕ Not a valid JSON file</span>';
    return;
  }

  const replace = document.getElementById('restoreReplace').checked;
  if (replace && !confirm('This will WIPE your current library before restoring. Continue?')) {
    resultEl.innerHTML = '';
    return;
  }

  try {
    const r = await fetch('/api/restore', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ bundle, replace })
    });
    const d = await r.json();
    if (!r.ok) {
      resultEl.innerHTML = `<span style="color:var(--red)">✕ ${d.detail || 'Restore failed'}</span>`;
      return;
    }
    const lib = d.library;
    let msg = d.settings_restored ? 'Settings restored. ' : '';
    if (lib) {
      msg += `Library: ${lib.imported} imported`;
      if (lib.skipped) msg += `, ${lib.skipped} skipped (already present)`;
      if (lib.errors && lib.errors.length) msg += `, ${lib.errors.length} error(s)`;
    }
    resultEl.innerHTML = `<span style="color:var(--grn)">✓ ${msg}</span>`;
    toast('Restore complete', 'ok');
    loadCfg();
    if (typeof loadLib === 'function') loadLib();
  } catch (exc) {
    resultEl.innerHTML = '<span style="color:var(--red)">✕ Restore request failed</span>';
  }
}

async function runTest() {
  const el = document.getElementById('tresult');
  el.innerHTML = '<span style="color:var(--mut)">Testing…</span>';
  try {
    const d = await (await fetch('/api/test')).json();

    if (d.diagnosis === 'stub') {
      el.innerHTML = `<span style="color:var(--blue)">ℹ Stub mode — AIOSTREAMS_UUID not set. Set it in docker-compose.yml to connect to your AIOStreams instance.</span>`;
      return;
    }

    if (d.ok) {
      el.innerHTML = `<span style="color:var(--grn)">✓ Connected to ${d.url}</span>
        <span style="color:var(--mut);font-size:12px;margin-left:8px">${d.direct_urls} direct streams from ${d.total_results} results</span>`;
    } else {
      const diag = {
        bad_auth:    '🔑 Wrong UUID or password — check AIOSTREAMS_UUID / AIOSTREAMS_PASSWORD',
        no_addons:   '📦 No addons installed — open AIOStreams and install Torrentio or similar',
        no_debrid:   '💳 No debrid service configured — add Real-Debrid/AllDebrid in AIOStreams Services tab',
        unreachable: '🔌 Cannot reach AIOStreams — check AIOSTREAMS_URL and that the container is running',
      }[d.diagnosis] || '';
      el.innerHTML = `<div style="color:var(--red);margin-bottom:6px">✗ ${d.error || 'Connection failed'}</div>`
        + (diag ? `<div style="color:var(--acc2);font-size:12px">${diag}</div>` : '')
        + (d.url ? `<div style="color:var(--mut);font-size:11px;margin-top:4px;font-family:monospace">${d.url}</div>` : '');
    }
  } catch(e) {
    el.innerHTML = `<span style="color:var(--red)">✗ ${e.message}</span>`;
  }
}

// ── Search ────────────────────────────────────────────────────
let srchTab = 'all', srchTimer = null, lastQuery = '';

function onSrchInput(val) {
  document.getElementById('srchClear').style.display = val ? 'block' : 'none';
  clearTimeout(srchTimer);
  if (!val.trim()) {
    showSearchEmpty();
    lastQuery = '';
    return;
  }
  srchTimer = setTimeout(() => doSearch(), 420);
}

function setTab(tab, el) {
  srchTab = tab;
  document.querySelectorAll('.srch-tab').forEach(t => t.classList.remove('on'));
  el.classList.add('on');
  if (lastQuery) doSearch();
}

function clearSearch() {
  document.getElementById('srchInput').value = '';
  document.getElementById('srchClear').style.display = 'none';
  lastQuery = '';
  showSearchEmpty();
}

function showSearchEmpty() {
  document.getElementById('srchStatus').textContent = '';
  document.getElementById('srchGrid').innerHTML = `
    <div class="srch-empty">
      
      <div class="srch-empty-title">Search for movies and series</div>
      <div class="srch-empty-sub">Powered by Cinemeta — the same source as Stremio</div>
    </div>`;
}

async function doSearch() {
  const q = document.getElementById('srchInput').value.trim();
  if (!q) return;
  lastQuery = q;

  const grid = document.getElementById('srchGrid');
  const status = document.getElementById('srchStatus');
  status.textContent = 'Searching…';

  // Skeleton placeholders matching card() dimensions
  grid.innerHTML = Array(8).fill(0).map(() =>
    `<div class="card" style="pointer-events:none">
       <div class="skel cposter"></div>
       <div class="skel cname" style="height:12px;margin-top:8px;width:80%"></div>
       <div class="skel cyear" style="height:11px;margin-top:5px;width:45%"></div>
     </div>`
  ).join('');

  // Cinemeta search: /catalog/{type}/top/search={query}.json
  const encode = encodeURIComponent(q);
  const types = srchTab === 'all'    ? ['movie','series']
              : srchTab === 'movie'  ? ['movie']
              :                        ['series'];

  try {
    const results = await Promise.all(
      types.map(t => cmFetch(`catalog/${t}/top/search=${encode}.json`)
        .then(d => (d.metas || []).map(m => ({ ...m, _type: t })))
        .catch(() => []))
    );

    // Interleave movie + series results so they mix naturally
    const merged = [];
    const arrs = results;
    const maxLen = Math.max(...arrs.map(a => a.length));
    for (let i = 0; i < maxLen; i++) {
      arrs.forEach(a => { if (a[i]) merged.push(a[i]); });
    }

    if (!merged.length) {
      status.textContent = `No results for "${q}"`;
      grid.innerHTML = `
        <div class="srch-empty">
          
          <div class="srch-empty-title">No results for "${q}"</div>
          <div class="srch-empty-sub">Try a different title or check spelling</div>
        </div>`;
      return;
    }

    const typeLabel = srchTab === 'all' ? 'movies & series'
                    : srchTab === 'movie' ? 'movies' : 'series';
    status.textContent = `${merged.length} result${merged.length !== 1 ? 's' : ''} for "${q}"`;
    grid.innerHTML = merged.map(m => card(m, m._type || 'movie')).join('');
  } catch(e) {
    status.textContent = '';
    grid.innerHTML = `<div class="srch-empty">
      <div class="srch-empty-icon">⚠️</div>
      <div class="srch-empty-title">Search failed</div>
      <div class="srch-empty-sub">${e.message}</div>
    </div>`;
    status.textContent = '';
  }
}

// ── Background scan polling ───────────────────────────────────
function pollScan(imdbId, title) {
  _bg_scans_ui.add(imdbId);
  let lastCount = 0;
  const iv = setInterval(async () => {
    try {
      const r = await fetch(`/api/scan/${imdbId}`);
      const d = await r.json();
      if (d.stubs !== lastCount) {
        lastCount = d.stubs;
        await syncStubs();
        await loadLib();
      }
      if (!d.scanning) {
        clearInterval(iv);
        _bg_scans_ui.delete(imdbId);
        toast(`"${title}" — ${d.stubs} stub${d.stubs!==1?'s':''} ready in Plex`, 'ok');
        await syncStubs();
        await loadLib();
      }
    } catch { clearInterval(iv); _bg_scans_ui.delete(imdbId); }
  }, 4000);
}

// ── Toast ─────────────────────────────────────────────────────
function toast(msg, type='ok') {
  const el=document.createElement('div');
  el.className=`toast ${type}`;
  el.textContent=msg;
  document.body.appendChild(el);
  setTimeout(()=>el.remove(), 3500);
}

// ── Init ─────────────────────────────────────────────────────
(async()=>{
  await syncStubs();
  await Promise.all([
    loadHero(),
    loadRow('rowM','catalog/movie/top.json','movie'),
    loadRow('rowS','catalog/series/top.json','series'),
  ]);
})();
setInterval(syncStubs, 5000);

// ── View All ───────────────────────────────────────────────────
// _rowCache stores items already fetched by loadRow keyed by cmPath
const _rowCache = {};

async function viewAll(title, cmPath, type) {
  // Open overlay immediately
  const ov = document.getElementById('vaOverlay');
  document.getElementById('vaTitle').textContent = title;
  document.getElementById('vaGrid').innerHTML = Array(20).fill(0).map(()=>
    `<div class="card" style="pointer-events:none">
       <div class="skel cposter"></div>
       <div class="skel cname" style="height:12px;margin-top:8px;width:80%"></div>
       <div class="skel cyear" style="height:11px;margin-top:5px;width:45%"></div>
     </div>`
  ).join('');
  ov.classList.add('open');
  ov.scrollTop = 0;

  // Fetch (or use cached) items
  let items = _rowCache[cmPath];
  if (!items) {
    try {
      const data = await cmFetch(cmPath);
      items = (data.metas || []);
      _rowCache[cmPath] = items;
    } catch(e) {
      document.getElementById('vaGrid').innerHTML =
        `<div style="color:var(--red);grid-column:1/-1;padding:20px;font-size:13px">Failed to load: ${e.message}</div>`;
      return;
    }
  }
  document.getElementById('vaGrid').innerHTML = items.map(m => card(m, type)).join('');
}

function closeViewAll() {
  document.getElementById('vaOverlay').classList.remove('open');
}

</script>

<!-- View All overlay -->
<div class="va-overlay" id="vaOverlay">
  <div class="va-inner">
    <div class="va-header">
      <button class="va-back" onclick="closeViewAll()">Back</button>
      <span class="va-title" id="vaTitle"></span>
    </div>
    <div class="va-grid" id="vaGrid"></div>
  </div>
</div>

</body>
</html>"""


@app.get("/", response_class=HTMLResponse)
async def ui():
    return HTMLResponse(UI_HTML)


# ---------------------------------------------------------------------------
# Config + test
# ---------------------------------------------------------------------------

@app.get("/api/config")
async def get_config():
    return {
        "aiostreams_url":  os.environ.get("AIOSTREAMS_URL", "http://localhost:3001"),
        "uuid_set":        bool(os.environ.get("AIOSTREAMS_UUID")),
        "password_set":    bool(os.environ.get("AIOSTREAMS_PASSWORD")),
        "library_root":    os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt"),
        "fuse": {
            "mountpoint":         os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt"),
            "block_mb":           os.environ.get("FUSE_BLOCK_MB", "8"),
            "cache_blocks":       os.environ.get("FUSE_CACHE_BLOCKS", "64"),
            "prefetch_ahead":     os.environ.get("FUSE_PREFETCH_AHEAD", "4"),
            "read_timeout":       os.environ.get("FUSE_READ_TIMEOUT", "15"),
            "max_inflight":       os.environ.get("FUSE_MAX_INFLIGHT", "12"),
            "pool_connections":   os.environ.get("FUSE_POOL_CONNECTIONS", "10"),
            "pool_maxsize":       os.environ.get("FUSE_POOL_MAXSIZE", "20"),
            "resolve_timeout":    os.environ.get("FUSE_RESOLVE_TIMEOUT", "15"),
        },
    }


@app.get("/api/settings")
async def get_settings():
    from gateway import settings as _settings
    return _settings.get_all()


class SettingsPatch(BaseModel):
    active_ttl_days:    Optional[float] = None
    preferred_language: Optional[str] = None
    preferred_audio:    Optional[list[str]] = None
    require_subtitles:  Optional[bool] = None
    min_size_gb:        Optional[float] = None
    max_size_gb:        Optional[float] = None


@app.post("/api/settings")
async def update_settings(patch: SettingsPatch):
    from gateway import settings as _settings
    data = {k: v for k, v in patch.dict().items() if v is not None}
    try:
        updated = _settings.update(data)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    logger.info("Settings updated: %s", data)
    return updated


# ---------------------------------------------------------------------------
# Backup / restore — settings + library (stub metadata)
# ---------------------------------------------------------------------------

import datetime as _dt

BACKUP_FORMAT_VERSION = 1

@app.get("/api/backup")
async def create_backup():
    """
    Returns a single JSON bundle containing current settings and every
    stub's metadata (title, quality, IMDb id, season/episode, etc).
    Deliberately excludes live resolve state (stream_url/headers/size) —
    a restored backup comes back as fresh stubs that re-resolve on next
    play, since old CDN links would likely be expired anyway.
    """
    from gateway import settings as _settings
    bundle = {
        "format_version": BACKUP_FORMAT_VERSION,
        "created_at":     _dt.datetime.now(_dt.timezone.utc).isoformat(),
        "settings":       _settings.get_all(),
        "library":        _stubs.export_all(),
    }
    filename = f"aiogateway-backup-{_dt.datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    return JSONResponse(
        content=bundle,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


class RestoreReq(BaseModel):
    bundle:  dict
    replace: bool = False   # False = merge (skip existing), True = wipe library first


@app.post("/api/restore")
async def restore_backup(req: RestoreReq):
    """
    Restore settings and/or library from a previously downloaded backup
    bundle. Settings are always applied if present (last-write-wins on
    each key). Library stubs are imported as fresh PLACEHOLDERs — replace
    controls whether the current library is wiped first or merged into.
    """
    from gateway import settings as _settings
    bundle = req.bundle

    if not isinstance(bundle, dict) or "format_version" not in bundle:
        raise HTTPException(400, "Not a valid AIOGateway backup file")

    results = {"settings_restored": False, "library": None}

    settings_data = bundle.get("settings")
    if isinstance(settings_data, dict) and settings_data:
        try:
            _settings.update(settings_data)
            results["settings_restored"] = True
        except ValueError as exc:
            raise HTTPException(400, f"Invalid settings in backup: {exc}")

    library_data = bundle.get("library")
    if isinstance(library_data, list):
        import_result = await _stubs.import_all(library_data, replace=req.replace)
        results["library"] = import_result
        logger.info("Restore: %s", import_result)

    return results


@app.get("/api/test")
async def test_connection():
    return await _client.connection_test()


# ---------------------------------------------------------------------------
# Add media — movies and series (series only stubs aired episodes with streams)
# ---------------------------------------------------------------------------

import asyncio as _asyncio
from datetime import datetime, timezone as _tz

class AddReq(BaseModel):
    imdb_id:    str
    title:      str
    year:       Optional[int] = None
    media_type: str = "movie"
    season:     Optional[int] = None   # None = all seasons
    episode:    Optional[int] = None   # None = all episodes
    poster:     Optional[str] = None


def _is_aired(released: Optional[str]) -> bool:
    """True if episode released date exists and is in the past."""
    if not released:
        return False
    try:
        dt = datetime.fromisoformat(released.replace("Z", "+00:00"))
        return dt <= datetime.now(_tz.utc)
    except Exception:
        return False


async def _add_movie(req: AddReq) -> dict:
    item = MediaItem(
        id=req.imdb_id, imdb_id=req.imdb_id, title=req.title,
        year=req.year, media_type=MediaType.MOVIE,
    )
    item._poster = req.poster or ""
    item.streams = await _client.resolve_all(item)
    if not item.streams:
        raise HTTPException(404, "AIOStreams returned no results with a direct URL. Check debrid config.")
    stubs = await _stubs.create_stubs(item)
    return {
        "media_id": item.id, "title": item.title, "media_type": "movie",
        "streams_found": len(item.streams), "has_4k": item.has_4k,
        "episodes_with_streams": 0, "episodes_no_streams": 0,
        "episodes_future": 0, "episodes_skipped": 0,
        "stubs_created": [{"stub_id": s.stub_id, "quality": s.quality.value, "path": s.abs_path} for s in stubs],
    }


# Active background scans: imdb_id → asyncio.Task
_bg_scans: dict = {}

# Set briefly whenever a play-triggered resolve is in flight, so the
# background series-add scan (which shares the same AIOStreams rate budget)
# can pause for a moment rather than racing it and causing a 429 right when
# a real user is waiting on the result. The scan checks this before each
# per-episode query; it isn't a hard lock, just a "let the real request go
# first" courtesy pause.
_play_priority_active = False

async def _yield_to_play_priority():
    """Called by the background scan loop before each AIOStreams query.
    Pauses briefly if a play-triggered resolve is currently in flight."""
    if _play_priority_active:
        await _asyncio.sleep(1.5)


async def _query_episode(
    imdb_id: str, show_title: str, year, poster: str,
    v: dict, sem: "_asyncio.Semaphore"
) -> tuple:
    """Query AIOStreams for one episode. Returns (stubbed, has_4k)."""
    s_num = v.get("season")
    e_num = v.get("number")
    if s_num is None or e_num is None:
        return False, False

    async with sem:
        item = MediaItem(
            id=f"{imdb_id}_s{s_num}e{e_num}", imdb_id=imdb_id,
            title=show_title, show_title=show_title, episode_title="",
            year=year, media_type=MediaType.SERIES,
            season=s_num, episode=e_num,
        )
        streams = []
        for attempt in range(1, 5):
            try:
                streams = await _client.resolve_all(item)
                break
            except Exception as exc:
                exc_str = str(exc)
                is_429  = "429" in exc_str
                if attempt < 4:
                    wait = (attempt * 5) if is_429 else (attempt * 2)
                    logger.warning(
                        "S%02dE%02d attempt %d/4 — %s — retrying in %ds",
                        s_num, e_num, attempt,
                        "rate limited (429)" if is_429 else exc_str[:60], wait
                    )
                    await _asyncio.sleep(wait)
                else:
                    logger.warning("S%02dE%02d all 4 attempts failed", s_num, e_num)
                    return False, False

        if not streams:
            return False, False

        item.streams = streams
        item._poster = poster
        stubs = await _stubs.create_stubs(item)
        q = " +4K" if item.has_4k else ""
        logger.info("S%02dE%02d: stubbed%s", s_num, e_num, q)
        return True, item.has_4k


async def _scan_series_bg(
    imdb_id: str, show_title: str, year, poster: str,
    candidates: list, skip_keys: set
) -> None:
    """
    Background task — sequential scan with 1s delay, repeated up to 3 passes
    until no new episodes are found. Each pass only retries episodes that
    previously returned no streams, ensuring all cached episodes are captured
    even when AIOStreams is inconsistent.
    """
    # Track which episodes already have stubs
    def _already_stubbed(v: dict) -> bool:
        s = v.get("season"); e = v.get("number")
        return (s, e) in skip_keys or any(
            st.imdb_id == imdb_id and
            st.aiostreams_id == f"{imdb_id}:{s}:{e}"
            for st in _stubs.all()
        )

    remaining = [v for v in candidates if not _already_stubbed(v)]
    if not remaining:
        logger.info("BG scan %s: nothing to do", imdb_id)
        _bg_scans.pop(imdb_id, None)
        return

    logger.info("BG scan %s: %d episodes to check", imdb_id, len(remaining))
    sem        = _asyncio.Semaphore(1)
    total_found = 0

    for pass_num in range(1, 4):   # up to 3 passes
        no_stream_this_pass = []
        found_this_pass     = 0

        logger.info("BG scan %s pass %d/%d: checking %d episodes",
                    imdb_id, pass_num, 3, len(remaining))

        for v in remaining:
            await _yield_to_play_priority()
            try:
                stubbed, _ = await _query_episode(
                    imdb_id, show_title, year, poster, v, sem
                )
                if stubbed:
                    found_this_pass += 1
                    total_found     += 1
                else:
                    no_stream_this_pass.append(v)
            except Exception as exc:
                logger.warning("BG scan episode error: %s", exc)
                no_stream_this_pass.append(v)
            await _asyncio.sleep(1.0)   # 1s between each query

        logger.info("BG scan %s pass %d done: %d new stubs, %d still missing",
                    imdb_id, pass_num, found_this_pass, len(no_stream_this_pass))

        if not no_stream_this_pass:
            break   # everything found — no need for another pass

        remaining = no_stream_this_pass

        if pass_num < 3:
            # Wait a bit longer before the next pass
            wait = pass_num * 5
            logger.info("BG scan %s: waiting %ds before pass %d",
                        imdb_id, wait, pass_num + 1)
            await _asyncio.sleep(wait)

    if remaining:
        logger.info("BG scan %s: %d episode(s) had no streams after 3 passes: %s",
                    imdb_id, len(remaining),
                    [f"S{v.get('season'):02d}E{v.get('number'):02d}" for v in remaining])

    logger.info("BG scan %s complete: %d total episodes stubbed", imdb_id, total_found)
    _bg_scans.pop(imdb_id, None)


async def _add_series(req: AddReq) -> dict:
    """
    Fast path: query E01 immediately, return as soon as stub is created.
    Background task scans all remaining episodes concurrently.
    """
    try:
        async with _http.get(
            f"https://v3-cinemeta.strem.io/meta/series/{req.imdb_id}.json",
            headers={"User-Agent": "AIOGateway/0.3"},
            timeout=aiohttp.ClientTimeout(total=20),
        ) as resp:
            data = await resp.json(content_type=None)
    except Exception as exc:
        raise HTTPException(502, f"Cinemeta fetch failed: {exc}")

    meta   = data.get("meta") or {}
    videos = meta.get("videos") or []
    if not videos:
        raise HTTPException(404, f"No episode data found for {req.imdb_id}")

    poster     = req.poster or meta.get("poster") or ""
    show_title = req.title

    # Always resolve a year server-side rather than trusting the request to
    # supply one consistently. A missing/None year produces a folder name
    # with no "(Year)" suffix — and since the same show gets re-added via
    # several different UI flows (initial add, rescan, per-season request),
    # any one of them omitting the year fragments the show into two
    # differently-named folders for the same series. Cinemeta's meta
    # endpoint returns "year" directly; releaseInfo is a fallback for
    # older/alternate response shapes.
    year = req.year
    if not year:
        year = meta.get("year")
        if not year:
            release_info = meta.get("releaseInfo") or ""
            m = re.match(r"(\d{4})", str(release_info))
            if m:
                year = int(m.group(1))
        if year:
            logger.info("Series %s: request had no year, using Cinemeta's %s",
                       req.imdb_id, year)

    aired_all  = [v for v in videos if _is_aired(v.get("released"))]
    future_cnt = len(videos) - len(aired_all)

    candidates = aired_all
    if req.season is not None:
        candidates = [v for v in candidates if v.get("season") == req.season]
    if req.episode is not None:
        candidates = [v for v in candidates if v.get("number") == req.episode]

    if not candidates:
        raise HTTPException(404, f"No aired episodes found. {future_cnt} not yet released.")

    # Sort so E01 of lowest season is first
    candidates.sort(key=lambda v: (v.get("season") or 0, v.get("number") or 0))

    logger.info("Series %s '%s': fast E01 + bg scan %d eps",
                req.imdb_id, show_title, len(candidates))

    # Query first episode immediately
    sem_one = _asyncio.Semaphore(1)
    stubbed, has_4k = await _query_episode(
        req.imdb_id, show_title, year, poster, candidates[0], sem_one
    )
    fast_key = (candidates[0].get("season"), candidates[0].get("number"))

    # Only skip E01 in the background scan if it was actually stubbed
    skip_keys = {fast_key} if stubbed else set()

    # Cancel any existing scan and start a new one for all remaining episodes
    if req.imdb_id in _bg_scans:
        _bg_scans[req.imdb_id].cancel()
    task = _asyncio.create_task(
        _scan_series_bg(req.imdb_id, show_title, year, poster, candidates, skip_keys)
    )
    _bg_scans[req.imdb_id] = task

    return {
        "media_id":    req.imdb_id,
        "title":       req.title,
        "media_type":  "series",
        "streams_found": 1 if stubbed else 0,
        "has_4k":      has_4k,
        "scanning":    True,
        "total_candidates": len(candidates),
        "stubs_created": [],
    }


@app.post("/api/add")
async def add_media(req: AddReq):
    try:
        if req.media_type == "movie":
            return await _add_movie(req)
        else:
            return await _add_series(req)
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Add failed: %s", exc)
        raise HTTPException(502, str(exc))

# ---------------------------------------------------------------------------
# Stubs
# ---------------------------------------------------------------------------

@app.get("/api/scan/{imdb_id}")
async def scan_status(imdb_id: str):
    running = imdb_id in _bg_scans and not _bg_scans[imdb_id].done()
    count   = sum(1 for s in _stubs.all() if s.imdb_id == imdb_id)
    return {"imdb_id": imdb_id, "scanning": running, "stubs": count}


@app.get("/api/series/{imdb_id}/episodes")
async def series_episodes(imdb_id: str):
    """Full aired episode list from Cinemeta with stub status."""
    import re as _re
    try:
        async with _http.get(
            f"https://v3-cinemeta.strem.io/meta/series/{imdb_id}.json",
            headers={"User-Agent": "AIOGateway/0.3"},
            timeout=aiohttp.ClientTimeout(total=15),
        ) as resp:
            data = await resp.json(content_type=None)
    except Exception as exc:
        raise HTTPException(502, f"Cinemeta fetch failed: {exc}")

    videos = (data.get("meta") or {}).get("videos") or []

    # Build stubbed sets from aiostreams_id pattern "imdb:season:episode"
    stubbed_hd, stubbed_4k = set(), set()
    for s in _stubs.all():
        if s.imdb_id != imdb_id:
            continue
        m = _re.search(r':(\d+):(\d+)$', s.aiostreams_id)
        if m:
            key = (int(m.group(1)), int(m.group(2)))
            (stubbed_4k if s.quality == Quality.UHD else stubbed_hd).add(key)

    episodes = []
    for v in videos:
        sn = v.get("season"); ep = v.get("number")
        if sn is None or ep is None or sn == 0:
            continue
        key = (sn, ep)
        episodes.append({
            "season":  sn, "episode": ep,
            "name":    v.get("name") or f"S{sn:02d}E{ep:02d}",
            "aired":   _is_aired(v.get("released")),
            "has_hd":  key in stubbed_hd,
            "has_4k":  key in stubbed_4k,
        })
    return {
        "imdb_id":  imdb_id,
        "episodes": episodes,
        "scanning": imdb_id in _bg_scans and not _bg_scans[imdb_id].done(),
    }


@app.post("/api/series/{imdb_id}/episode/{season}/{episode}")
async def add_single_episode(imdb_id: str, season: int, episode: int, req: AddReq):
    """Search for and stub a single missing episode."""
    year = req.year
    if not year:
        # Defense in depth: if the caller didn't supply a year, fetch it
        # from Cinemeta rather than stubbing this one episode with no year
        # — a year-less stub fragments the show into a second, differently
        # named folder alongside any correctly-year-suffixed episodes.
        try:
            async with _http.get(
                f"https://v3-cinemeta.strem.io/meta/series/{imdb_id}.json",
                headers={"User-Agent": "AIOGateway/0.3"},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                cm_meta = (await resp.json(content_type=None)).get("meta") or {}
            year = cm_meta.get("year")
            if not year:
                m = re.match(r"(\d{4})", str(cm_meta.get("releaseInfo") or ""))
                if m:
                    year = int(m.group(1))
            if year:
                logger.info("Episode S%02dE%02d (%s): request had no year, using Cinemeta's %s",
                           season, episode, imdb_id, year)
        except Exception as exc:
            logger.warning("Could not fetch fallback year from Cinemeta for %s: %s", imdb_id, exc)

    sem = _asyncio.Semaphore(1)
    v = {"season": season, "number": episode}
    stubbed, has_4k = await _query_episode(
        imdb_id, req.title, year, req.poster or "", v, sem
    )
    if not stubbed:
        raise HTTPException(404, f"No streams found for S{season:02d}E{episode:02d}")
    return {"stubbed": True, "has_4k": has_4k, "season": season, "episode": episode}


@app.get("/api/stubs")
async def list_stubs():
    all_s = _stubs.all()
    return {"count": len(all_s), "stubs": [
        {"stub_id": s.stub_id, "media_id": s.media_id, "title": s.title,
         "quality": s.quality.value, "state": s.state.value, "path": s.abs_path,
         "poster": getattr(s, "_poster", ""),
         "media_type": s.aiostreams_type,
         "stream_url": (s.stream_url[:80]+"…") if s.stream_url else None}
        for s in all_s
    ]}


@app.get("/api/stubs/{stub_id}")
async def get_stub(stub_id: str):
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Not found")
    return {"stub_id": s.stub_id, "media_id": s.media_id, "title": s.title,
            "quality": s.quality.value, "state": s.state.value, "path": s.abs_path,
            "imdb_id": s.imdb_id, "aiostreams_id": s.aiostreams_id,
            "stream_url": s.stream_url, "created_at": s.created_at, "resolved_at": s.resolved_at}


@app.delete("/api/stubs/{stub_id}")
async def delete_stub(stub_id: str):
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Not found")
    p = Path(s.abs_path)
    for f in (p, p.with_suffix(".aiogateway.json")):
        try:
            if f.exists(): f.unlink()
        except Exception: pass
    _stubs._stubs.pop(stub_id, None)
    _stubs._path_index.pop(s.abs_path, None)
    return {"deleted": stub_id}


@app.delete("/api/series/{imdb_id}")
async def delete_series(imdb_id: str):
    """Delete ALL stubs for a series and cancel any active background scan."""
    # Cancel background scan first
    if imdb_id in _bg_scans:
        task = _bg_scans.pop(imdb_id)
        task.cancel()
        try:
            await task
        except Exception:
            pass
        logger.info("Cancelled background scan for %s", imdb_id)

    # Delete all stubs for this series
    deleted = 0
    for s in list(_stubs.all()):
        if s.imdb_id != imdb_id:
            continue
        p = Path(s.abs_path)
        for f in (p, p.with_suffix(".aiogateway.json")):
            try:
                if f.exists(): f.unlink()
            except Exception: pass
        _stubs._stubs.pop(s.stub_id, None)
        _stubs._path_index.pop(s.abs_path, None)
        deleted += 1

    logger.info("Deleted %d stubs for series %s", deleted, imdb_id)
    return {"deleted": deleted, "imdb_id": imdb_id}


# ---------------------------------------------------------------------------
# Plex webhook
# ---------------------------------------------------------------------------

@app.post("/webhook/plex")
async def plex_webhook(request: Request):
    global _play_priority_active
    ct = request.headers.get("content-type", "")
    if "multipart/form-data" in ct:
        form = await request.form()
        raw = form.get("payload", "{}")
    else:
        raw = (await request.body()).decode()
    _play_priority_active = True
    try:
        result = await _webhook.handle(raw)
    finally:
        _play_priority_active = False
    logger.info("Webhook: %s", result)
    return JSONResponse(result)


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

@app.get("/proxy/{stub_id}")
async def proxy_get(stub_id: str, request: Request):
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Stub not found")

    # If not yet resolved, resolve now (webhook may have been missed)
    if s.state == StubState.PLACEHOLDER or (not s.stream_url and s.state != StubState.ERROR):
        logger.info("Proxy resolving stub %s on-demand (webhook not received)", s.stub_id)
        _stubs.set_resolving(s.stub_id)
        try:
            from gateway.models import MediaItem, MediaType
            media_type = MediaType.MOVIE if s.aiostreams_type == "movie" else MediaType.SERIES
            parts = s.aiostreams_id.split(":")
            item = MediaItem(
                id=s.media_id, imdb_id=s.imdb_id, title=s.title,
                year=None, media_type=media_type,
                season=int(parts[1]) if len(parts) >= 3 else None,
                episode=int(parts[2]) if len(parts) >= 3 else None,
            )
            stream_obj = await _client.best_working_for_quality(item, s.quality)
            if stream_obj and stream_obj.url:
                _stubs.set_active(s.stub_id, stream_obj.url, stream_obj.request_headers,
                                  size=stream_obj.size)
                logger.info("On-demand resolved stub %s → %s…", s.stub_id, stream_obj.url[:60])
            else:
                _stubs.set_error(s.stub_id)
                raise HTTPException(502, "No stream URL returned from AIOStreams")
        except HTTPException:
            raise
        except Exception as exc:
            _stubs.set_error(s.stub_id)
            raise HTTPException(502, f"Stream resolution failed: {exc}")

    if s.state == StubState.ERROR or not s.stream_url:
        raise HTTPException(502, "Stream resolution failed")

    status, headers, body = await _proxy.proxy(s, request.headers.get("Range"))
    return StreamingResponse(body, status_code=status, headers=headers,
                             media_type=headers.get("Content-Type", "video/x-matroska"))


@app.head("/proxy/{stub_id}")
async def proxy_head(stub_id: str):
    s = _stubs.get(stub_id)
    if not s or not s.stream_url: raise HTTPException(404)
    status, headers = await _proxy.head(s)
    return StreamingResponse(b"", status_code=status, headers=headers)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    all_s = _stubs.all()
    return {"status": "ok", "stubs": len(all_s),
            "active": sum(1 for s in all_s if s.state == StubState.ACTIVE),
            "aiostreams_url": os.environ.get("AIOSTREAMS_URL", "not set")}
