"""
AIOGateway — FastAPI + NuvioWeb-style library UI.

Endpoints
---------
GET  /                        NuvioWeb-style browse UI
GET  /api/config              Current env config
GET  /api/test                Test AIOStreams connectivity
GET  /api/tmdb/{path}         TMDB proxy (avoids CORS)
POST /api/add                 Add media → AIOStreams → stub files
GET  /api/stubs               List all stubs
DELETE /api/stubs/{id}        Delete stub + file

POST /webhook/plex            Plex play event
GET  /proxy/{stub_id}         Byte-range stream proxy
HEAD /proxy/{stub_id}         HEAD pre-flight
GET  /health                  Health check
"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

import aiohttp
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, Response, StreamingResponse
from pydantic import BaseModel

from gateway.aiostreams_client import AIOStreamsClient
from gateway.models import MediaItem, MediaType, Quality, StubState
from gateway.proxy import StreamProxy
from gateway.stub_manager import StubManager
from webhook.handler import PlexWebhookHandler

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s — %(message)s")
logger = logging.getLogger("aiogateway")

_stubs   = StubManager()
_proxy   = StreamProxy()
_client  = AIOStreamsClient()
_webhook: PlexWebhookHandler | None = None
_http:    aiohttp.ClientSession | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _webhook, _http
    await _proxy.open()
    await _client.open()
    _http    = aiohttp.ClientSession()
    _webhook = PlexWebhookHandler(_stubs, _client)
    restored = await _stubs.restore()
    logger.info("AIOGateway started — %d stubs restored", restored)
    yield
    await _proxy.close()
    await _client.close()
    if _http: await _http.close()


app = FastAPI(title="AIOGateway", version="0.3.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ---------------------------------------------------------------------------
# NuvioWeb-style UI — embedded HTML
# ---------------------------------------------------------------------------

UI_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>AIOGateway</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet"/>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#0a0a0f;
  --surface:#111118;
  --card:#16161e;
  --card2:#1c1c26;
  --border:#ffffff12;
  --border2:#ffffff1e;
  --text:#f0f0f5;
  --muted:#8888a8;
  --accent:#e8a020;
  --accent2:#f0b840;
  --blue:#4a9eff;
  --green:#3dd68c;
  --red:#ff5555;
  --nav-h:64px;
  --font:'Inter',system-ui,sans-serif;
}
html,body{height:100%;background:var(--bg);color:var(--text);font-family:var(--font);font-size:15px;line-height:1.5;-webkit-font-smoothing:antialiased;overflow-x:hidden}

/* ── Topnav ─────────────────────────────────────────────────── */
.nav{
  position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:100;
  display:flex;align-items:center;gap:4px;
  background:rgba(10,10,15,0.82);backdrop-filter:blur(20px);
  border:1px solid var(--border2);border-radius:50px;
  padding:6px 8px;
}
.nav-item{
  display:flex;align-items:center;gap:7px;padding:8px 18px;border-radius:40px;
  font-size:14px;font-weight:600;cursor:pointer;border:none;background:none;
  color:var(--muted);font-family:var(--font);transition:all 160ms;
}
.nav-item:hover{color:var(--text);background:rgba(255,255,255,0.07)}
.nav-item.active{background:rgba(255,255,255,0.13);color:var(--text)}
.nav-icon{font-size:16px}

/* ── Hero ───────────────────────────────────────────────────── */
.hero{
  position:relative;height:520px;overflow:hidden;
  display:flex;align-items:flex-end;
}
.hero-bg{
  position:absolute;inset:0;
  background-size:cover;background-position:center top;
  transition:opacity 800ms;
}
.hero-overlay{
  position:absolute;inset:0;
  background:linear-gradient(to bottom,
    rgba(10,10,15,0.15) 0%,
    rgba(10,10,15,0.0) 30%,
    rgba(10,10,15,0.7) 65%,
    rgba(10,10,15,1.0) 100%
  );
}
.hero-content{
  position:relative;z-index:2;padding:0 60px 44px;max-width:580px;
}
.hero-title{
  font-size:52px;font-weight:800;letter-spacing:-1.5px;
  line-height:1.0;margin-bottom:10px;
  text-shadow:0 2px 20px rgba(0,0,0,0.8);
}
.hero-meta{
  display:flex;align-items:center;gap:10px;font-size:14px;
  color:rgba(255,255,255,0.75);margin-bottom:20px;font-weight:500;
}
.hero-meta-sep{opacity:0.5}
.hero-dots{
  display:flex;gap:6px;margin-bottom:28px;
}
.hero-dot{
  width:28px;height:4px;border-radius:2px;background:rgba(255,255,255,0.3);
  cursor:pointer;transition:all 200ms;
}
.hero-dot.active{background:#fff;width:36px}
.hero-actions{display:flex;gap:10px}
.btn-hero{
  display:flex;align-items:center;gap:8px;padding:12px 26px;border-radius:8px;
  font-family:var(--font);font-size:14px;font-weight:700;cursor:pointer;border:none;
  transition:all 160ms;
}
.btn-add{background:var(--accent);color:#000}
.btn-add:hover{background:var(--accent2);transform:scale(1.03)}
.btn-add.added{background:var(--green);color:#000}
.btn-info{background:rgba(255,255,255,0.18);color:#fff;backdrop-filter:blur(8px)}
.btn-info:hover{background:rgba(255,255,255,0.28)}

/* ── Page sections ──────────────────────────────────────────── */
.page{padding-top:0}
.section{padding:0 0 36px}
.section-header{
  display:flex;align-items:center;justify-content:space-between;
  padding:0 60px;margin-bottom:18px;
}
.section-title{
  font-size:19px;font-weight:700;letter-spacing:-.3px;
  border-left:3px solid var(--accent);padding-left:12px;
}
.view-all{
  font-size:13px;font-weight:600;color:var(--muted);cursor:pointer;
  display:flex;align-items:center;gap:4px;background:none;border:none;
  font-family:var(--font);
}
.view-all:hover{color:var(--text)}

/* ── Horizontal scroll row ──────────────────────────────────── */
.row{
  display:flex;gap:14px;overflow-x:auto;overflow-y:visible;
  padding:4px 60px 12px;scrollbar-width:none;
}
.row::-webkit-scrollbar{display:none}

/* ── Poster card ────────────────────────────────────────────── */
.card{
  flex:0 0 140px;cursor:pointer;position:relative;
  transition:transform 200ms;
}
.card:hover{transform:scale(1.06)}
.card.in-library{outline:2px solid var(--green);border-radius:10px}
.card-poster{
  width:140px;height:210px;border-radius:10px;overflow:hidden;
  background:var(--card2);position:relative;
}
.card-poster img{
  width:100%;height:100%;object-fit:cover;display:block;
  transition:opacity 300ms;
}
.card-poster img.loading{opacity:0}
.card-badge{
  position:absolute;top:7px;right:7px;
  background:rgba(0,0,0,0.75);backdrop-filter:blur(6px);
  border-radius:5px;padding:3px 7px;font-size:11px;font-weight:700;
  color:var(--accent2);
}
.card-check{
  position:absolute;top:7px;right:7px;
  width:24px;height:24px;border-radius:50%;
  background:var(--green);display:none;align-items:center;justify-content:center;
  font-size:13px;color:#000;font-weight:700;
}
.card.in-library .card-check{display:flex}
.card.in-library .card-badge{display:none}
.card-info{padding:8px 2px 0}
.card-name{font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.card-year{font-size:11px;color:var(--muted);margin-top:2px}

/* ── Modal ──────────────────────────────────────────────────── */
.modal-bg{
  position:fixed;inset:0;background:rgba(0,0,0,0.75);backdrop-filter:blur(12px);
  z-index:200;display:flex;align-items:center;justify-content:center;
  opacity:0;pointer-events:none;transition:opacity 200ms;
}
.modal-bg.open{opacity:1;pointer-events:all}
.modal{
  background:var(--card);border:1px solid var(--border2);border-radius:18px;
  width:92%;max-width:540px;overflow:hidden;
  transform:scale(0.94);transition:transform 200ms;
}
.modal-bg.open .modal{transform:scale(1)}
.modal-hero{
  height:200px;background-size:cover;background-position:center;
  position:relative;
}
.modal-hero-overlay{
  position:absolute;inset:0;
  background:linear-gradient(to bottom,transparent 30%,var(--card) 100%);
}
.modal-body{padding:20px 24px 24px}
.modal-title{font-size:22px;font-weight:800;letter-spacing:-.5px;margin-bottom:6px}
.modal-meta{display:flex;gap:10px;font-size:13px;color:var(--muted);margin-bottom:12px;flex-wrap:wrap}
.modal-pill{
  background:var(--card2);border:1px solid var(--border);
  padding:3px 10px;border-radius:20px;font-size:12px;font-weight:500;color:var(--text);
}
.modal-overview{font-size:13px;color:var(--muted);line-height:1.7;margin-bottom:20px;max-height:80px;overflow:hidden}
.modal-actions{display:flex;gap:10px}
.btn-modal{
  flex:1;display:flex;align-items:center;justify-content:center;gap:8px;
  padding:12px;border-radius:9px;font-family:var(--font);font-size:13px;font-weight:700;
  cursor:pointer;border:none;transition:all 160ms;
}
.btn-modal-add{background:var(--accent);color:#000}
.btn-modal-add:hover{background:var(--accent2)}
.btn-modal-add.added{background:var(--green)}
.btn-modal-close{background:var(--card2);color:var(--muted);border:1px solid var(--border2)}
.btn-modal-close:hover{color:var(--text)}

/* ── Library view ───────────────────────────────────────────── */
.library-page{padding:calc(var(--nav-h) + 30px) 60px 40px}
.library-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px}
.library-title{font-size:26px;font-weight:800;letter-spacing:-.5px}
.library-grid{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:22px 16px;
}
.stub-state{
  display:inline-flex;align-items:center;gap:4px;
  font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;margin-top:4px;
}
.st-placeholder{background:#2a2a1a;color:#c0a040}
.st-active{background:#0d2a1a;color:var(--green)}
.st-error{background:#2a0d0d;color:var(--red)}
.st-resolving{background:#1a2a3a;color:var(--blue);animation:sblink 1s infinite}
@keyframes sblink{0%,100%{opacity:1}50%{opacity:.4}}

/* ── Search bar ─────────────────────────────────────────────── */
.search-bar{
  display:flex;align-items:center;gap:10px;
  background:var(--card2);border:1px solid var(--border2);border-radius:10px;
  padding:10px 16px;max-width:360px;
}
.search-bar input{
  background:none;border:none;outline:none;font-family:var(--font);
  font-size:14px;color:var(--text);width:100%;
}
.search-bar input::placeholder{color:var(--muted)}
.search-icon{color:var(--muted);font-size:16px}

/* ── Toast ──────────────────────────────────────────────────── */
.toast{
  position:fixed;bottom:28px;right:28px;z-index:500;
  background:var(--card);border:1px solid var(--border2);border-radius:12px;
  padding:12px 18px;font-size:13px;font-weight:600;
  display:flex;align-items:center;gap:8px;
  animation:toastIn 200ms ease;
}
@keyframes toastIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.toast.ok{border-color:var(--green);color:var(--green)}
.toast.err{border-color:var(--red);color:var(--red)}
.toast.info{border-color:var(--blue);color:var(--blue)}

/* ── Skeleton ───────────────────────────────────────────────── */
.skeleton{
  background:linear-gradient(90deg,var(--card) 25%,var(--card2) 50%,var(--card) 75%);
  background-size:200% 100%;animation:shimmer 1.4s infinite;border-radius:10px;
}
@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}

/* ── Config panel ───────────────────────────────────────────── */
.config-page{padding:calc(var(--nav-h) + 30px) 60px 40px}
.config-section{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:22px;margin-bottom:18px}
.config-section h3{font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);margin-bottom:16px}
.config-chips{display:flex;flex-wrap:wrap;gap:8px}
.config-chip{
  background:var(--card2);border:1px solid var(--border);border-radius:8px;
  padding:7px 14px;font-size:12px;display:flex;gap:8px;align-items:center;
}
.chip-label{color:var(--muted);font-weight:600}
.chip-val{font-family:monospace;color:var(--text)}
.chip-val.ok{color:var(--green)}
.chip-val.err{color:var(--red)}
.test-result{font-size:13px;color:var(--muted);margin-bottom:14px;min-height:20px}
.btn{
  display:inline-flex;align-items:center;gap:7px;padding:9px 20px;border-radius:8px;
  font-family:var(--font);font-size:13px;font-weight:700;cursor:pointer;border:none;transition:all 160ms;
}
.btn-primary{background:var(--accent);color:#000}
.btn-primary:hover{background:var(--accent2)}
.btn-ghost{background:var(--card2);color:var(--muted);border:1px solid var(--border2)}
.btn-ghost:hover{color:var(--text);border-color:var(--accent)}
.btn-danger{background:#3a1010;color:var(--red);border:1px solid #6a2020}
.btn-danger:hover{background:#4a1818}
.checklist{font-size:13px;color:var(--muted);line-height:2.2}
.checklist code{
  background:var(--card2);color:var(--accent2);
  padding:1px 7px;border-radius:5px;font-size:12px;
}
</style>
</head>
<body>

<!-- Top nav -->
<nav class="nav">
  <button class="nav-item active" id="navHome" onclick="showPage('home',this)">
    <span class="nav-icon">⌂</span> Home
  </button>
  <button class="nav-item" id="navLibrary" onclick="showPage('library',this)">
    <span class="nav-icon">☰</span> Library
  </button>
  <button class="nav-item" id="navConfig" onclick="showPage('config',this)">
    <span class="nav-icon">⚙</span> Config
  </button>
</nav>

<!-- ── HOME PAGE ───────────────────────────────────────────── -->
<div id="pageHome">

  <!-- Hero -->
  <div class="hero" id="hero">
    <div class="hero-bg" id="heroBg"></div>
    <div class="hero-overlay"></div>
    <div class="hero-content">
      <div class="hero-title" id="heroTitle">Loading…</div>
      <div class="hero-meta" id="heroMeta"></div>
      <div class="hero-dots" id="heroDots"></div>
      <div class="hero-actions">
        <button class="btn-hero btn-add" id="heroAddBtn" onclick="heroAdd()">＋ Add to Plex</button>
        <button class="btn-hero btn-info" onclick="heroInfo()">ⓘ More Info</button>
      </div>
    </div>
  </div>

  <div class="page">
    <!-- Popular Movies -->
    <div class="section" id="sectionMovies">
      <div class="section-header">
        <span class="section-title">Popular — Movie</span>
        <button class="view-all" onclick="">View All ›</button>
      </div>
      <div class="row" id="rowMovies">
        ${[...Array(10)].map(()=>'<div class="card"><div class="skeleton" style="width:140px;height:210px"></div></div>').join('')}
      </div>
    </div>

    <!-- Popular Series -->
    <div class="section" id="sectionSeries">
      <div class="section-header">
        <span class="section-title">Popular — Series</span>
        <button class="view-all" onclick="">View All ›</button>
      </div>
      <div class="row" id="rowSeries">
        ${[...Array(10)].map(()=>'<div class="card"><div class="skeleton" style="width:140px;height:210px"></div></div>').join('')}
      </div>
    </div>

    <!-- Trending -->
    <div class="section" id="sectionTrending">
      <div class="section-header">
        <span class="section-title">Trending This Week</span>
        <button class="view-all" onclick="">View All ›</button>
      </div>
      <div class="row" id="rowTrending">
        ${[...Array(10)].map(()=>'<div class="card"><div class="skeleton" style="width:140px;height:210px"></div></div>').join('')}
      </div>
    </div>
  </div>
</div>

<!-- ── LIBRARY PAGE ─────────────────────────────────────────── -->
<div id="pageLibrary" style="display:none">
  <div class="library-page">
    <div class="library-header">
      <span class="library-title">My Library</span>
      <div class="search-bar">
        <span class="search-icon">⌕</span>
        <input placeholder="Filter stubs…" oninput="filterStubs(this.value)" id="stubFilter"/>
      </div>
    </div>
    <div class="library-grid" id="libraryGrid">
      <div style="color:var(--muted);font-size:14px;grid-column:1/-1">Loading stubs…</div>
    </div>
  </div>
</div>

<!-- ── CONFIG PAGE ──────────────────────────────────────────── -->
<div id="pageConfig" style="display:none">
  <div class="config-page">
    <h2 style="font-size:26px;font-weight:800;margin-bottom:24px;letter-spacing:-.5px">Config</h2>

    <div class="config-section">
      <h3>AIOStreams connection</h3>
      <div class="config-chips" id="cfgChips">Loading…</div>
      <div class="test-result" id="testResult" style="margin-top:14px"></div>
      <button class="btn btn-primary" onclick="runTest()">▶ Test connection</button>
    </div>

    <div class="config-section">
      <h3>Plex setup checklist</h3>
      <div class="checklist">
        <div>1. Add these folders to Plex as library sections:<br>
          <code>/library/Movies</code> &nbsp;
          <code>/library/Movies4K</code> &nbsp;
          <code>/library/Series</code> &nbsp;
          <code>/library/Series4K</code>
        </div>
        <div>2. Plex → Settings → Webhooks → Add webhook URL:<br>
          <code id="webhookUrl">http://&lt;this-host&gt;:8001/webhook/plex</code>
        </div>
        <div>3. AIOStreams must have your debrid credentials configured so results include a direct <code>url</code> field.</div>
      </div>
    </div>
  </div>
</div>

<!-- Detail Modal -->
<div class="modal-bg" id="modal" onclick="closeModal(event)">
  <div class="modal" id="modalBox">
    <div class="modal-hero" id="modalHero">
      <div class="modal-hero-overlay"></div>
    </div>
    <div class="modal-body">
      <div class="modal-title" id="modalTitle"></div>
      <div class="modal-meta" id="modalMeta"></div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px" id="modalPills"></div>
      <div class="modal-overview" id="modalOverview"></div>
      <div class="modal-actions">
        <button class="btn-modal btn-modal-add" id="modalAddBtn" onclick="modalAdd()">＋ Add to Plex</button>
        <button class="btn-modal btn-modal-close" onclick="document.getElementById('modal').classList.remove('open')">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
// ── State ──────────────────────────────────────────────────────
const TMDB_BASE = 'https://image.tmdb.org/t/p/';
const API = '';
let heroItems = [];
let heroIdx = 0;
let heroTimer = null;
let stubs = [];
let modalItem = null;
let libraryImdbSet = new Set();

// ── Page nav ───────────────────────────────────────────────────
function showPage(name, el) {
  ['home','library','config'].forEach(p => {
    document.getElementById('page'+p.charAt(0).toUpperCase()+p.slice(1)).style.display = 'none';
  });
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('page'+name.charAt(0).toUpperCase()+name.slice(1)).style.display = '';
  el.classList.add('active');
  if (name === 'library') { loadLibrary(); }
  if (name === 'config')  { loadConfig(); }
}

// ── TMDB fetch (via gateway proxy to avoid CORS) ───────────────
async function tmdb(path, params={}) {
  const q = new URLSearchParams(params).toString();
  const url = `${API}/api/tmdb/${path}${q ? '?'+q : ''}`;
  const r = await fetch(url);
  return r.json();
}

function img(path, size='w342') {
  if (!path) return 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 140 210"><rect fill="%231c1c26" width="140" height="210"/></svg>';
  return `${TMDB_BASE}${size}${path}`;
}

// ── Hero ───────────────────────────────────────────────────────
async function loadHero() {
  const data = await tmdb('movie/popular', {language:'en-US',page:1});
  const items = (data.results || []).slice(0, 8).filter(m => m.backdrop_path);
  if (!items.length) return;

  // Fetch external_ids to get IMDb id for each hero item
  heroItems = items;
  renderHero(0);

  // Build dots
  const dots = document.getElementById('heroDots');
  dots.innerHTML = items.map((_,i) => `<div class="hero-dot${i===0?' active':''}" onclick="setHero(${i})"></div>`).join('');

  // Autoplay
  heroTimer = setInterval(() => setHero((heroIdx+1) % heroItems.length), 7000);
}

async function setHero(i) {
  heroIdx = i;
  renderHero(i);
  document.querySelectorAll('.hero-dot').forEach((d,j) => d.classList.toggle('active',j===i));
}

async function renderHero(i) {
  const m = heroItems[i];
  if (!m) return;
  const bg = document.getElementById('heroBg');
  bg.style.backgroundImage = `url(${img(m.backdrop_path,'w1280')})`;
  document.getElementById('heroTitle').textContent = m.title || m.name || '';

  const year = (m.release_date || m.first_air_date || '').slice(0,4);
  const type = m.media_type === 'tv' ? 'Series' : 'Movie';
  const genre = ''; // skip genre for speed
  document.getElementById('heroMeta').innerHTML =
    `<span>${type}</span><span class="hero-meta-sep">•</span><span>${year}</span>`;

  // Check if already in library
  const imdbId = m.imdb_id || await getImdbId(m.id, m.media_type || 'movie');
  m._imdb = imdbId;
  const added = libraryImdbSet.has(imdbId);
  const btn = document.getElementById('heroAddBtn');
  btn.textContent = added ? '✓ In Library' : '＋ Add to Plex';
  btn.className = 'btn-hero btn-add' + (added ? ' added' : '');
}

async function getImdbId(tmdbId, type='movie') {
  const mediaType = type === 'tv' ? 'tv' : 'movie';
  try {
    const d = await tmdb(`${mediaType}/${tmdbId}/external_ids`);
    return d.imdb_id || '';
  } catch { return ''; }
}

function heroAdd() {
  const m = heroItems[heroIdx];
  if (!m) return;
  openModal(m, m.media_type || 'movie');
}

function heroInfo() {
  const m = heroItems[heroIdx];
  if (!m) return;
  openModal(m, m.media_type || 'movie');
}

// ── Card rows ──────────────────────────────────────────────────
function renderCard(item, type) {
  const isTV = type === 'tv' || type === 'series';
  const title = item.title || item.name || '';
  const year = (item.release_date || item.first_air_date || '').slice(0,4);
  const rating = item.vote_average ? item.vote_average.toFixed(1) : '';
  const poster = img(item.poster_path, 'w342');
  const inLib = libraryImdbSet.has(item._imdb || '');

  return `
  <div class="card${inLib?' in-library':''}" id="card-${item.id}" onclick='openModal(${JSON.stringify(item).replace(/'/g,"&#39;")}, "${isTV?'tv':'movie'}")'>
    <div class="card-poster">
      <img src="${poster}" loading="lazy" onload="this.classList.remove('loading')" onerror="this.style.display='none'" class="loading"/>
      ${rating ? `<div class="card-badge">★ ${rating}</div>` : ''}
      <div class="card-check">✓</div>
    </div>
    <div class="card-info">
      <div class="card-name">${title}</div>
      <div class="card-year">${year}</div>
    </div>
  </div>`;
}

async function loadRow(rowId, tmdbPath, params, type) {
  const data = await tmdb(tmdbPath, params);
  const items = (data.results || []).slice(0, 20);
  const row = document.getElementById(rowId);
  if (!row) return;
  row.innerHTML = items.map(m => renderCard(m, type)).join('');
  return items;
}

// ── Modal ──────────────────────────────────────────────────────
async function openModal(item, type) {
  modalItem = { ...item, _type: type };
  const isTV = type === 'tv';

  document.getElementById('modalTitle').textContent = item.title || item.name || '';
  const year = (item.release_date || item.first_air_date || '').slice(0,4);
  document.getElementById('modalMeta').innerHTML =
    `<span>${isTV ? 'Series' : 'Movie'}</span>
     ${year ? `<span>•</span><span>${year}</span>` : ''}
     ${item.vote_average ? `<span>•</span><span>★ ${item.vote_average.toFixed(1)}</span>` : ''}`;

  document.getElementById('modalOverview').textContent = item.overview || '';
  document.getElementById('modalHero').style.backgroundImage =
    `url(${img(item.backdrop_path || item.poster_path, 'w780')})`;

  // Genres
  const pills = document.getElementById('modalPills');
  pills.innerHTML = (item.genre_ids || []).slice(0,3).map(gid => {
    const name = GENRE_MAP[gid] || '';
    return name ? `<span class="modal-pill">${name}</span>` : '';
  }).join('');

  // IMDb id
  if (!item._imdb) {
    item._imdb = await getImdbId(item.id, type);
    modalItem._imdb = item._imdb;
  }

  const inLib = libraryImdbSet.has(item._imdb || '');
  const btn = document.getElementById('modalAddBtn');
  btn.textContent = inLib ? '✓ In Library' : '＋ Add to Plex';
  btn.className = 'btn-modal btn-modal-add' + (inLib ? ' added' : '');

  document.getElementById('modal').classList.add('open');
}

function closeModal(e) {
  if (e.target === document.getElementById('modal'))
    document.getElementById('modal').classList.remove('open');
}

async function modalAdd() {
  if (!modalItem) return;
  const btn = document.getElementById('modalAddBtn');
  const imdbId = modalItem._imdb || await getImdbId(modalItem.id, modalItem._type);

  if (!imdbId) {
    toast('No IMDb ID found for this title', 'err');
    return;
  }

  if (libraryImdbSet.has(imdbId)) {
    toast('Already in library', 'info');
    return;
  }

  btn.textContent = '⏳ Fetching streams…';
  btn.disabled = true;

  const title = modalItem.title || modalItem.name || '';
  const year  = parseInt((modalItem.release_date || modalItem.first_air_date || '').slice(0,4)) || null;
  const type  = modalItem._type === 'tv' ? 'series' : 'movie';

  try {
    const r = await fetch(`${API}/api/add`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ imdb_id: imdbId, title, year, media_type: type }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || JSON.stringify(d));

    libraryImdbSet.add(imdbId);
    btn.textContent = '✓ In Library';
    btn.className = 'btn-modal btn-modal-add added';
    btn.disabled = false;

    // Update hero btn if same item
    const hm = heroItems[heroIdx];
    if (hm && hm._imdb === imdbId) {
      const hBtn = document.getElementById('heroAddBtn');
      hBtn.textContent = '✓ In Library';
      hBtn.className = 'btn-hero btn-add added';
    }

    // Update card
    const card = document.getElementById('card-'+modalItem.id);
    if (card) card.classList.add('in-library');

    const q = d.has_4k ? 'HD + 4K' : 'HD';
    toast(`Added "${title}" (${d.streams_found} streams, ${q})`, 'ok');
    await loadStubs();
  } catch(e) {
    btn.textContent = '＋ Add to Plex';
    btn.disabled = false;
    toast(e.message, 'err');
  }
}

// ── Library ────────────────────────────────────────────────────
async function loadStubs() {
  try {
    const r = await fetch(`${API}/api/stubs`);
    const d = await r.json();
    stubs = d.stubs || [];
    libraryImdbSet = new Set(stubs.map(s => s.media_id.split('_')[0]));
  } catch {}
}

let allStubs = [];
async function loadLibrary() {
  await loadStubs();
  allStubs = [...stubs];
  renderLibrary(stubs);
}

function filterStubs(q) {
  const filtered = q
    ? allStubs.filter(s => (s.title||s.media_id).toLowerCase().includes(q.toLowerCase()))
    : allStubs;
  renderLibrary(filtered);
}

function renderLibrary(items) {
  const grid = document.getElementById('libraryGrid');
  if (!items.length) {
    grid.innerHTML = `<div style="color:var(--muted);font-size:14px;grid-column:1/-1">
      No stubs yet. Browse the Home tab and click "Add to Plex".
    </div>`;
    return;
  }
  grid.innerHTML = items.map(s => {
    const stClass = {placeholder:'st-placeholder',active:'st-active',error:'st-error',resolving:'st-resolving'}[s.state]||'st-placeholder';
    const qColor = s.quality==='4k' ? 'var(--accent2)' : 'var(--blue)';
    return `
    <div style="cursor:default">
      <div style="width:140px;height:210px;border-radius:10px;background:var(--card2);display:flex;align-items:center;justify-content:center;font-size:36px;position:relative">
        ${s.quality==='4k'?'🎬':'🎬'}
        <div style="position:absolute;top:7px;right:7px;background:rgba(0,0,0,.75);border-radius:5px;padding:2px 7px;font-size:10px;font-weight:700;color:${qColor}">${s.quality.toUpperCase()}</div>
        <button onclick="deleteStub('${s.stub_id}')" style="position:absolute;top:7px;left:7px;background:rgba(0,0,0,.75);border:none;border-radius:5px;width:24px;height:24px;cursor:pointer;font-size:13px;color:#888;display:flex;align-items:center;justify-content:center" title="Delete">✕</button>
      </div>
      <div style="padding:8px 2px 0">
        <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:140px">${s.title||s.media_id}</div>
        <div><span class="stub-state ${stClass}">${s.state}</span></div>
      </div>
    </div>`;
  }).join('');
}

async function deleteStub(id) {
  if (!confirm('Delete stub and file?')) return;
  await fetch(`${API}/api/stubs/${id}`, {method:'DELETE'});
  toast('Stub deleted', 'ok');
  await loadLibrary();
}

// ── Config ─────────────────────────────────────────────────────
async function loadConfig() {
  try {
    const r = await fetch(`${API}/api/config`);
    const d = await r.json();
    document.getElementById('cfgChips').innerHTML = [
      chip('AIOSTREAMS_URL', d.aiostreams_url, true),
      chip('UUID',           d.uuid_set ? '✓ set' : '✗ not set', d.uuid_set),
      chip('PASSWORD',       d.password_set ? '✓ set' : '✗ not set', d.password_set),
      chip('LIBRARY_ROOT',   d.library_root, true),
    ].join('');
    document.getElementById('webhookUrl').textContent =
      `http://${location.hostname}:8001/webhook/plex`;
  } catch {}
}

function chip(label, val, ok) {
  return `<div class="config-chip">
    <span class="chip-label">${label}</span>
    <span class="chip-val ${ok?'ok':'err'}">${val}</span>
  </div>`;
}

async function runTest() {
  const el = document.getElementById('testResult');
  el.style.color = 'var(--muted)';
  el.textContent = 'Testing…';
  try {
    const r = await fetch(`${API}/api/test`);
    const d = await r.json();
    if (d.ok) {
      el.style.color = 'var(--green)';
      el.textContent = `✓ Connected (HTTP ${d.status_code})`;
    } else {
      el.style.color = 'var(--red)';
      el.textContent = `✗ ${d.error || 'Failed'} — URL: ${d.url}`;
    }
  } catch(e) {
    el.style.color = 'var(--red)';
    el.textContent = `✗ ${e.message}`;
  }
}

// ── Toast ──────────────────────────────────────────────────────
function toast(msg, type='ok') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = (type==='ok'?'✓ ':type==='err'?'✗ ':'ℹ ') + msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// ── Genre map (TMDB ids) ───────────────────────────────────────
const GENRE_MAP = {
  28:'Action',12:'Adventure',16:'Animation',35:'Comedy',80:'Crime',
  99:'Documentary',18:'Drama',10751:'Family',14:'Fantasy',36:'History',
  27:'Horror',10402:'Music',9648:'Mystery',10749:'Romance',878:'Sci-Fi',
  10770:'TV Movie',53:'Thriller',10752:'War',37:'Western',
  10759:'Action & Adventure',10762:'Kids',10763:'News',10764:'Reality',
  10765:'Sci-Fi & Fantasy',10766:'Soap',10767:'Talk',10768:'War & Politics',
};

// ── Init ───────────────────────────────────────────────────────
async function init() {
  await loadStubs();
  await loadHero();
  // Load all rows in parallel
  await Promise.all([
    loadRow('rowMovies',   'movie/popular',       {language:'en-US',page:1}, 'movie'),
    loadRow('rowSeries',   'tv/popular',          {language:'en-US',page:1}, 'tv'),
    loadRow('rowTrending', 'trending/all/week',   {language:'en-US'},        'movie'),
  ]);
}

init();
setInterval(loadStubs, 5000);
</script>
</body>
</html>"""


@app.get("/", response_class=HTMLResponse)
async def ui():
    return HTMLResponse(UI_HTML)


# ---------------------------------------------------------------------------
# TMDB proxy — avoids CORS, no API key exposed to browser
# ---------------------------------------------------------------------------
TMDB_KEY  = os.environ.get("TMDB_API_KEY", "")
TMDB_READ = os.environ.get("TMDB_READ_TOKEN",
    # Public read-access token (no account needed for popular/trending endpoints)
    "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9"
)


@app.get("/api/tmdb/{path:path}")
async def tmdb_proxy(path: str, request: Request):
    """Proxy TMDB API calls from the browser (handles auth + CORS)."""
    assert _http
    params = dict(request.query_params)

    # Use key auth if configured, else try read-access token
    if TMDB_KEY:
        params["api_key"] = TMDB_KEY
        headers = {}
    else:
        headers = {"Authorization": f"Bearer {TMDB_READ}"}

    url = f"https://api.themoviedb.org/3/{path}"
    try:
        async with _http.get(url, params=params, headers=headers,
                             timeout=aiohttp.ClientTimeout(total=10)) as resp:
            data = await resp.json()
            return JSONResponse(data, status_code=resp.status)
    except Exception as exc:
        logger.error("TMDB proxy error: %s", exc)
        raise HTTPException(502, f"TMDB request failed: {exc}")


# ---------------------------------------------------------------------------
# Config + connection test
# ---------------------------------------------------------------------------

@app.get("/api/config")
async def get_config():
    return {
        "aiostreams_url":  os.environ.get("AIOSTREAMS_URL", "http://localhost:3001"),
        "uuid_set":        bool(os.environ.get("AIOSTREAMS_UUID")),
        "password_set":    bool(os.environ.get("AIOSTREAMS_PASSWORD")),
        "library_root":    os.environ.get("LIBRARY_ROOT", "/library"),
    }


@app.get("/api/test")
async def test_connection():
    return await _client.connection_test()


# ---------------------------------------------------------------------------
# Add media
# ---------------------------------------------------------------------------

class AddReq(BaseModel):
    imdb_id:    str
    title:      str
    year:       Optional[int] = None
    media_type: str = "movie"
    season:     Optional[int] = None
    episode:    Optional[int] = None


@app.post("/api/add")
async def add_media(req: AddReq):
    media_id   = req.imdb_id
    if req.season and req.episode:
        media_id += f"_s{req.season}e{req.episode}"
    media_type = MediaType.MOVIE if req.media_type == "movie" else MediaType.SERIES

    item = MediaItem(
        id=media_id, imdb_id=req.imdb_id, title=req.title,
        year=req.year, media_type=media_type,
        season=req.season, episode=req.episode,
    )

    try:
        item.streams = await _client.resolve_all(item)
    except Exception as exc:
        logger.error("AIOStreams query failed: %s", exc)
        raise HTTPException(status_code=502, detail=str(exc))

    if not item.streams:
        raise HTTPException(
            status_code=404,
            detail=(
                "AIOStreams returned no results with a direct URL. "
                "Check debrid config in AIOStreams."
            ),
        )

    stubs = await _stubs.create_stubs(item)
    return {
        "media_id": media_id,
        "title": item.title,
        "streams_found": len(item.streams),
        "has_4k": item.has_4k,
        "stubs_created": [
            {"stub_id": s.stub_id, "quality": s.quality.value, "path": s.abs_path}
            for s in stubs
        ],
    }


# ---------------------------------------------------------------------------
# Stub management
# ---------------------------------------------------------------------------

@app.get("/api/stubs")
async def list_stubs():
    all_s = _stubs.all()
    return {
        "count": len(all_s),
        "stubs": [
            {
                "stub_id":    s.stub_id,
                "media_id":   s.media_id,
                "title":      s.title,
                "quality":    s.quality.value,
                "state":      s.state.value,
                "path":       s.abs_path,
                "stream_url": (s.stream_url[:80] + "…") if s.stream_url else None,
            }
            for s in all_s
        ],
    }


@app.get("/api/stubs/{stub_id}")
async def get_stub(stub_id: str):
    s = _stubs.get(stub_id)
    if not s:
        raise HTTPException(404, "Not found")
    return {
        "stub_id": s.stub_id, "media_id": s.media_id, "title": s.title,
        "quality": s.quality.value, "state": s.state.value,
        "path": s.abs_path, "imdb_id": s.imdb_id,
        "aiostreams_id": s.aiostreams_id, "stream_url": s.stream_url,
        "created_at": s.created_at, "resolved_at": s.resolved_at,
    }


@app.delete("/api/stubs/{stub_id}")
async def delete_stub(stub_id: str):
    s = _stubs.get(stub_id)
    if not s:
        raise HTTPException(404, "Not found")
    p = Path(s.abs_path)
    for f in (p, p.with_suffix(".aiogateway.json")):
        try:
            if f.exists(): f.unlink()
        except Exception: pass
    _stubs._stubs.pop(stub_id, None)
    _stubs._path_index.pop(s.abs_path, None)
    return {"deleted": stub_id}


# ---------------------------------------------------------------------------
# Plex webhook
# ---------------------------------------------------------------------------

@app.post("/webhook/plex")
async def plex_webhook(request: Request):
    ct = request.headers.get("content-type", "")
    if "multipart/form-data" in ct:
        form = await request.form()
        raw = form.get("payload", "{}")
    else:
        raw = (await request.body()).decode()
    result = await _webhook.handle(raw)
    logger.info("Webhook: %s", result)
    return JSONResponse(result)


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

@app.get("/proxy/{stub_id}")
async def proxy_get(stub_id: str, request: Request):
    s = _stubs.get(stub_id)
    if not s:
        raise HTTPException(404, "Stub not found")
    if s.state == StubState.PLACEHOLDER:
        raise HTTPException(503, "Waiting for Plex play event")
    if s.state == StubState.ERROR or not s.stream_url:
        raise HTTPException(502, "Stream resolution failed")
    status, headers, body = await _proxy.proxy(s, request.headers.get("Range"))
    return StreamingResponse(body, status_code=status, headers=headers,
                             media_type=headers.get("Content-Type", "video/x-matroska"))


@app.head("/proxy/{stub_id}")
async def proxy_head(stub_id: str):
    s = _stubs.get(stub_id)
    if not s or not s.stream_url:
        raise HTTPException(404)
    status, headers = await _proxy.head(s)
    return StreamingResponse(b"", status_code=status, headers=headers)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    all_s = _stubs.all()
    return {
        "status": "ok",
        "stubs": len(all_s),
        "active": sum(1 for s in all_s if s.state == StubState.ACTIVE),
        "aiostreams_url": os.environ.get("AIOSTREAMS_URL", "not set"),
    }
