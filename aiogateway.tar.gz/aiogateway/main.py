"""
AIOGateway — single-file FastAPI application.

One container. No nginx. UI served inline.

Endpoints
---------
GET  /                        Web UI
GET  /api/config              Current config (env vars, redacted)
GET  /api/test                Test AIOStreams connectivity
POST /api/add                 Add media: query AIOStreams, create stubs
GET  /api/stubs               List all stubs
GET  /api/stubs/{id}          Single stub
DELETE /api/stubs/{id}        Remove stub + file

POST /webhook/plex            Plex webhook (media.play)

GET  /proxy/{stub_id}         Stream proxy → Plex
HEAD /proxy/{stub_id}         HEAD pre-flight → Plex

GET  /health                  Health check
"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from pydantic import BaseModel

from gateway.aiostreams_client import AIOStreamsClient
from gateway.models import MediaItem, MediaType, Quality, StubState
from gateway.proxy import StreamProxy
from gateway.stub_manager import StubManager
from webhook.handler import PlexWebhookHandler

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s — %(message)s",
)
logger = logging.getLogger("aiogateway")

# ---------------------------------------------------------------------------
# Singletons
# ---------------------------------------------------------------------------
_stubs   = StubManager()
_proxy   = StreamProxy()
_client  = AIOStreamsClient()
_webhook: PlexWebhookHandler | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _webhook
    await _proxy.open()
    await _client.open()
    _webhook = PlexWebhookHandler(_stubs, _client)
    restored = await _stubs.restore()
    logger.info("AIOGateway started — %d stubs restored from disk", restored)
    yield
    await _proxy.close()
    await _client.close()


app = FastAPI(title="AIOGateway", version="0.2.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ---------------------------------------------------------------------------
# Embedded UI (no nginx needed)
# ---------------------------------------------------------------------------

UI_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>AIOGateway</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0f0f13;--sur:#18181f;--card:#1e1e28;--bor:#2a2a38;--acc:#7b5ea7;--acc2:#e8830a;--grn:#3dd68c;--red:#e85555;--txt:#e8e8f0;--mut:#8888a0;--r:10px;--f:'Inter',system-ui,sans-serif}
html,body{height:100%;background:var(--bg);color:var(--txt);font-family:var(--f);font-size:14px;line-height:1.5;-webkit-font-smoothing:antialiased}
.app{display:flex;height:100vh;overflow:hidden}
/* sidebar */
.sb{width:210px;min-width:210px;background:var(--sur);border-right:1px solid var(--bor);display:flex;flex-direction:column;padding:20px 0}
.logo{display:flex;align-items:center;gap:9px;padding:0 16px 20px;border-bottom:1px solid var(--bor);margin-bottom:8px}
.logo-ic{width:30px;height:30px;background:linear-gradient(135deg,var(--acc),var(--acc2));border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0}
.logo-tx{font-size:15px;font-weight:700;letter-spacing:-.3px}
.logo-tx span{color:var(--acc2)}
.nl{font-size:10px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--mut);padding:8px 16px 4px}
.ni{display:flex;align-items:center;gap:8px;padding:8px 16px;color:var(--mut);font-size:13px;font-weight:500;cursor:pointer;position:relative;border:none;background:none;width:100%;text-align:left;transition:all 140ms}
.ni:hover{background:var(--card);color:var(--txt)}
.ni.on{color:var(--txt);background:var(--card)}
.ni.on::before{content:'';position:absolute;left:0;top:50%;transform:translateY(-50%);width:3px;height:60%;background:var(--acc);border-radius:0 2px 2px 0}
.sb-ft{margin-top:auto;padding:12px 16px 0;border-top:1px solid var(--bor);display:flex;flex-direction:column;gap:8px}
.conn-row{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--mut)}
.dot{width:6px;height:6px;border-radius:50%;background:var(--mut);flex-shrink:0;transition:background .3s}
.dot.ok{background:var(--grn);box-shadow:0 0 5px #3dd68c55}
.dot.err{background:var(--red)}
/* main */
.main{flex:1;display:flex;flex-direction:column;overflow:hidden}
.tb{display:flex;align-items:center;gap:12px;padding:13px 22px;border-bottom:1px solid var(--bor);background:var(--sur);flex-shrink:0}
.tb-ti{font-size:15px;font-weight:700;letter-spacing:-.2px}
.tb-ac{display:flex;gap:8px;margin-left:auto}
.btn{display:flex;align-items:center;gap:5px;padding:7px 14px;border-radius:7px;font-family:var(--f);font-size:12px;font-weight:600;cursor:pointer;border:none;transition:all 140ms}
.bp{background:var(--acc);color:#fff}.bp:hover{background:#9370c0}
.bg{background:var(--card);color:var(--mut);border:1px solid var(--bor)}.bg:hover{color:var(--txt);border-color:var(--acc)}
.bd{background:#3a1818;color:var(--red);border:1px solid #5a2222}.bd:hover{background:#4a2020}
.ct{flex:1;overflow-y:auto;padding:22px;display:flex;flex-direction:column;gap:18px}
.ct::-webkit-scrollbar{width:4px}
.ct::-webkit-scrollbar-thumb{background:var(--bor);border-radius:10px}
/* panel */
.pn{background:var(--sur);border:1px solid var(--bor);border-radius:var(--r);padding:18px}
.pn-ti{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:14px}
/* config badge */
.cfg-row{display:flex;flex-wrap:wrap;gap:8px}
.cfg-chip{background:var(--card);border:1px solid var(--bor);border-radius:7px;padding:6px 12px;font-size:12px;display:flex;gap:6px;align-items:center}
.cfg-label{color:var(--mut)}
.cfg-val{color:var(--txt);font-family:'Courier New',monospace}
.cfg-val.ok{color:var(--grn)}
.cfg-val.err{color:var(--red)}
/* form */
.fg{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.fg-full{grid-column:1/-1}
.fl{display:flex;flex-direction:column;gap:4px}
label{font-size:10px;font-weight:600;color:var(--mut);text-transform:uppercase;letter-spacing:.05em}
input,select{background:var(--card);border:1px solid var(--bor);border-radius:7px;padding:7px 11px;color:var(--txt);font-family:var(--f);font-size:13px;outline:none;transition:border-color 140ms;width:100%}
input:focus,select:focus{border-color:var(--acc)}
input::placeholder{color:var(--mut)}
select option{background:var(--card)}
.fm-ac{margin-top:14px;display:flex;gap:8px;align-items:center}
/* stub cards */
.sh{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
.sl{display:flex;flex-direction:column;gap:7px}
.sc{background:var(--card);border:1px solid var(--bor);border-radius:9px;padding:12px 14px;display:flex;align-items:center;gap:12px;transition:border-color 140ms;animation:fi .2s ease}
@keyframes fi{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}
.sc:hover{border-color:var(--acc)}
.sq{width:40px;height:40px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;flex-shrink:0}
.sq.hd{background:#1a2535;color:#5b9bd5}
.sq.fk{background:#2a1a10;color:var(--acc2)}
.si{flex:1;min-width:0}
.st{font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sp{font-size:10px;color:var(--mut);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px;font-family:monospace}
.sm{display:flex;gap:6px;margin-top:4px;flex-wrap:wrap}
.bd2{font-size:10px;font-weight:600;padding:2px 7px;border-radius:20px}
.ph{background:#2a2a1a;color:#a0a060}
.rs{background:#1a2a3a;color:#60a0d0;animation:bp 1.2s infinite}
@keyframes bp{0%,100%{opacity:1}50%{opacity:.4}}
.ac{background:#0d2a1a;color:var(--grn)}
.er{background:#2a0d0d;color:var(--red)}
.sa{display:flex;gap:5px;flex-shrink:0}
.ib{width:28px;height:28px;border-radius:6px;display:flex;align-items:center;justify-content:center;cursor:pointer;border:none;font-size:13px;transition:all 140ms}
.ib:hover{transform:scale(1.1)}
/* log */
.lb{font-family:'Courier New',monospace;font-size:11px;color:#a0a0b8;line-height:1.8;max-height:160px;overflow-y:auto}
.lb::-webkit-scrollbar{width:3px}
.lb::-webkit-scrollbar-thumb{background:var(--bor)}
.ll{display:flex;gap:10px}
.lt{color:var(--acc);min-width:62px}
.lok{color:var(--grn)}.ler{color:var(--red)}.lin{color:#a0a0b8}
/* empty */
.em{text-align:center;padding:40px 20px;color:var(--mut)}
.em-ic{font-size:32px;margin-bottom:8px;opacity:.4}
/* toast */
.toast{position:fixed;bottom:22px;right:22px;background:var(--sur);border:1px solid var(--bor);border-radius:9px;padding:10px 16px;font-size:12px;font-weight:600;z-index:200;animation:fi .2s ease;display:flex;align-items:center;gap:7px}
.toast.ok{border-color:var(--grn);color:var(--grn)}
.toast.err{border-color:var(--red);color:var(--red)}
</style>
</head>
<body>
<div class="app">
<aside class="sb">
  <div class="logo"><div class="logo-ic">⚡</div><span class="logo-tx">AIO<span>Gateway</span></span></div>
  <span class="nl">Views</span>
  <button class="ni on" onclick="nav('library',this)">📚 Library</button>
  <button class="ni" onclick="nav('config',this)">⚙️ Config</button>
  <button class="ni" onclick="nav('log',this)">🖥 Event Log</button>
  <div class="sb-ft">
    <div class="conn-row"><div class="dot" id="aio-dot"></div><span id="aio-txt">AIOStreams…</span></div>
    <div class="conn-row"><div class="dot" id="gw-dot"></div><span id="gw-txt">Gateway…</span></div>
  </div>
</aside>
<div class="main">
  <header class="tb">
    <span class="tb-ti" id="vti">Library</span>
    <div class="tb-ac">
      <button class="btn bg" onclick="refresh()">↻ Refresh</button>
      <button class="btn bp" onclick="toggleForm()">＋ Add Media</button>
    </div>
  </header>

  <!-- Library -->
  <div class="ct" id="vLibrary">
    <div class="pn" id="addForm" style="display:none">
      <div class="pn-ti">Add media → AIOStreams → Plex stubs</div>
      <div class="fg">
        <div class="fl"><label>IMDb ID</label><input id="fId" placeholder="tt1375666"/></div>
        <div class="fl"><label>Type</label><select id="fType" onchange="toggleSeries()"><option value="movie">Movie</option><option value="series">Series</option></select></div>
        <div class="fl fg-full"><label>Title</label><input id="fTitle" placeholder="Inception"/></div>
        <div class="fl"><label>Year</label><input id="fYear" type="number" placeholder="2010"/></div>
        <div id="serFields" style="display:contents">
          <div class="fl"><label>Season</label><input id="fSea" type="number" placeholder="1"/></div>
          <div class="fl"><label>Episode</label><input id="fEp" type="number" placeholder="1"/></div>
        </div>
      </div>
      <div class="fm-ac">
        <button class="btn bp" onclick="addMedia()">⚡ Fetch &amp; create stubs</button>
        <button class="btn bg" onclick="toggleForm()">Cancel</button>
        <span id="fmsg" style="font-size:11px;color:var(--mut);margin-left:4px"></span>
      </div>
    </div>
    <div>
      <div class="sh"><span style="font-size:14px;font-weight:700">Stubs</span><span style="font-size:11px;color:var(--mut)" id="cnt"></span></div>
      <div class="sl" id="sl"><div class="em"><div class="em-ic">📂</div><div>No stubs yet</div><div style="font-size:11px;margin-top:3px;opacity:.7">Add a movie or show above</div></div></div>
    </div>
  </div>

  <!-- Config -->
  <div class="ct" id="vConfig" style="display:none">
    <div class="pn">
      <div class="pn-ti">AIOStreams connection</div>
      <div class="cfg-row" id="cfgRow">Loading…</div>
    </div>
    <div class="pn">
      <div class="pn-ti">Connection test</div>
      <div id="testResult" style="font-size:12px;color:var(--mut)">Click Test to check AIOStreams connectivity.</div>
      <div style="margin-top:12px"><button class="btn bp" onclick="runTest()">▶ Test connection</button></div>
    </div>
    <div class="pn">
      <div class="pn-ti" style="margin-bottom:10px">Plex setup checklist</div>
      <div style="font-size:12px;color:var(--mut);line-height:2">
        <div>1. Add library folders to Plex:</div>
        <div style="font-family:monospace;color:var(--txt);margin-left:12px">/library/Movies &nbsp;&nbsp; /library/Movies4K</div>
        <div style="font-family:monospace;color:var(--txt);margin-left:12px">/library/Series &nbsp;&nbsp; /library/Series4K</div>
        <div style="margin-top:8px">2. Plex → Settings → Webhooks → Add webhook:</div>
        <div style="font-family:monospace;color:var(--acc2);margin-left:12px" id="webhookUrl">http://&lt;this-host&gt;:8001/webhook/plex</div>
        <div style="margin-top:8px">3. AIOStreams must be configured with your debrid credentials.</div>
      </div>
    </div>
  </div>

  <!-- Log -->
  <div class="ct" id="vLog" style="display:none">
    <div class="pn">
      <div class="pn-ti">Event log</div>
      <div class="lb" id="logEl"><div class="ll"><span class="lt">--:--:--</span><span class="lin">Gateway started</span></div></div>
    </div>
  </div>
</div>
</div>

<script>
const API = '';   // same origin
let stubs = [];
let formOpen = false;

// ── Nav ──────────────────────────────────────────────────────
function nav(v, el) {
  ['Library','Config','Log'].forEach(n => {
    document.getElementById('v'+n).style.display = 'none';
  });
  document.querySelectorAll('.ni').forEach(n => n.classList.remove('on'));
  document.getElementById('v'+v.charAt(0).toUpperCase()+v.slice(1)).style.display = 'flex';
  document.getElementById('vti').textContent = {library:'Library',config:'Config',log:'Event Log'}[v];
  el.classList.add('on');
  if (v === 'config') loadConfig();
}

// ── Health ────────────────────────────────────────────────────
async function checkHealth() {
  try {
    const r = await fetch(`${API}/health`);
    const d = await r.json();
    setDot('gw-dot','gw-txt', true, `Gateway OK · ${d.stubs} stubs`);
  } catch {
    setDot('gw-dot','gw-txt', false, 'Gateway offline');
  }
}

async function checkAIO() {
  try {
    const r = await fetch(`${API}/api/test`);
    const d = await r.json();
    setDot('aio-dot','aio-txt', d.ok, d.ok ? 'AIOStreams connected' : (d.error || 'AIOStreams error'));
  } catch {
    setDot('aio-dot','aio-txt', false, 'AIOStreams unreachable');
  }
}

function setDot(dotId, txtId, ok, msg) {
  document.getElementById(dotId).className = 'dot ' + (ok ? 'ok' : 'err');
  document.getElementById(txtId).textContent = msg;
}

// ── Config ────────────────────────────────────────────────────
async function loadConfig() {
  try {
    const r = await fetch(`${API}/api/config`);
    const d = await r.json();
    const el = document.getElementById('cfgRow');
    el.innerHTML = [
      chip('AIOSTREAMS_URL', d.aiostreams_url, true),
      chip('UUID', d.uuid_set ? '✓ set' : '✗ not set', d.uuid_set),
      chip('PASSWORD', d.password_set ? '✓ set' : '✗ not set', d.password_set),
      chip('LIBRARY_ROOT', d.library_root, true),
    ].join('');
    document.getElementById('webhookUrl').textContent =
      `http://${window.location.hostname}:8001/webhook/plex`;
  } catch(e) {
    document.getElementById('cfgRow').textContent = 'Could not load config';
  }
}

function chip(label, val, ok) {
  return `<div class="cfg-chip"><span class="cfg-label">${label}</span><span class="cfg-val ${ok?'ok':'err'}">${val}</span></div>`;
}

async function runTest() {
  const el = document.getElementById('testResult');
  el.textContent = 'Testing…';
  try {
    const r = await fetch(`${API}/api/test`);
    const d = await r.json();
    if (d.ok) {
      el.style.color = 'var(--grn)';
      el.textContent = `✓ Connected to AIOStreams at ${d.url} (HTTP ${d.status_code})`;
    } else {
      el.style.color = 'var(--red)';
      el.textContent = `✗ ${d.error || 'Connection failed'} (url: ${d.url})`;
    }
    checkAIO();
  } catch(e) {
    el.style.color = 'var(--red)';
    el.textContent = `✗ ${e.message}`;
  }
}

// ── Stubs ─────────────────────────────────────────────────────
async function refresh() {
  try {
    const r = await fetch(`${API}/api/stubs`);
    const d = await r.json();
    stubs = d.stubs || [];
    renderStubs();
    document.getElementById('cnt').textContent = `${stubs.length} file${stubs.length!==1?'s':''}`;
  } catch { /* offline */ }
}

function renderStubs() {
  const el = document.getElementById('sl');
  if (!stubs.length) {
    el.innerHTML = '<div class="em"><div class="em-ic">📂</div><div>No stubs yet</div><div style="font-size:11px;margin-top:3px;opacity:.7">Add a movie or show above</div></div>';
    return;
  }
  el.innerHTML = stubs.map(s => {
    const qClass = s.quality === '4k' ? 'fk' : 'hd';
    const qLabel = s.quality === '4k' ? '4K' : 'HD';
    const stClass = {placeholder:'ph',resolving:'rs',active:'ac',error:'er'}[s.state] || 'ph';
    const shortPath = s.path.replace(/^.*\/library\//, '/library/');
    const urlHint = s.stream_url
      ? `<div style="font-size:10px;color:var(--mut);font-family:monospace;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">→ ${s.stream_url}</div>`
      : '';
    return `
    <div class="sc">
      <div class="sq ${qClass}">${qLabel}</div>
      <div class="si">
        <div class="st">${s.title || s.media_id}</div>
        <div class="sp">${shortPath}</div>
        <div class="sm"><span class="bd2 ${stClass}">${s.state}</span></div>
        ${urlHint}
      </div>
      <div class="sa">
        <button class="ib bd" onclick="delStub('${s.stub_id}')" style="background:#3a1818;color:var(--red);border:1px solid #5a2222" title="Delete">🗑</button>
      </div>
    </div>`;
  }).join('');
}

async function delStub(id) {
  if (!confirm('Delete stub and file?')) return;
  await fetch(`${API}/api/stubs/${id}`, {method:'DELETE'});
  log('Deleted stub '+id,'ok');
  toast('Stub deleted','ok');
  refresh();
}

// ── Add form ──────────────────────────────────────────────────
function toggleForm() {
  formOpen = !formOpen;
  document.getElementById('addForm').style.display = formOpen ? 'block' : 'none';
}

function toggleSeries() {
  const s = document.getElementById('fType').value === 'series';
  document.getElementById('serFields').style.display = s ? 'contents' : 'none';
}

async function addMedia() {
  const msg = document.getElementById('fmsg');
  const imdb  = document.getElementById('fId').value.trim();
  const title = document.getElementById('fTitle').value.trim();
  const type  = document.getElementById('fType').value;
  const year  = parseInt(document.getElementById('fYear').value) || null;
  const sea   = parseInt(document.getElementById('fSea').value) || null;
  const ep    = parseInt(document.getElementById('fEp').value) || null;

  if (!imdb || !title) { msg.textContent = 'IMDb ID and title required.'; return; }
  msg.style.color = 'var(--mut)';
  msg.textContent = '⏳ Querying AIOStreams…';

  try {
    const r = await fetch(`${API}/api/add`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({imdb_id:imdb, title, year, media_type:type, season:sea, episode:ep}),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || JSON.stringify(d));
    msg.style.color='var(--grn)';
    msg.textContent=`✓ ${d.streams_found} streams · ${d.stubs_created.length} stubs${d.has_4k?' (HD+4K)':' (HD)'}`;
    log(`Added "${title}" — ${d.streams_found} streams, ${d.stubs_created.length} stubs`,'ok');
    toast(`Stubs created for ${title}`,'ok');
    refresh(); checkHealth();
  } catch(e) {
    msg.style.color='var(--red)';
    msg.textContent='✗ '+e.message;
    log('Error: '+e.message,'err');
    toast(e.message,'err');
  }
}

// ── Log ───────────────────────────────────────────────────────
function log(txt, type='info') {
  const now = new Date().toTimeString().slice(0,8);
  const el = document.getElementById('logEl');
  const cls = {ok:'lok',err:'ler',info:'lin'}[type]||'lin';
  const d = document.createElement('div');
  d.className='ll';
  d.innerHTML=`<span class="lt">${now}</span><span class="${cls}">${txt}</span>`;
  el.appendChild(d);
  el.scrollTop=el.scrollHeight;
}

// ── Toast ─────────────────────────────────────────────────────
function toast(msg, type='ok') {
  const el = document.createElement('div');
  el.className=`toast ${type}`;
  el.textContent=(type==='ok'?'✓ ':'✗ ')+msg;
  document.body.appendChild(el);
  setTimeout(()=>el.remove(), 3000);
}

// ── Poll for state changes ────────────────────────────────────
function pollStates() {
  setInterval(async () => {
    const prev = JSON.stringify(stubs.map(s=>s.state));
    await refresh();
    const next = JSON.stringify(stubs.map(s=>s.state));
    if (prev !== next) {
      stubs.forEach(s => {
        if (s.state==='active') log(`Plex playing stub ${s.stub_id} (${s.quality})`,'ok');
        if (s.state==='error')  log(`Stream error on stub ${s.stub_id}`,'err');
      });
    }
  }, 3000);
}

// ── Init ──────────────────────────────────────────────────────
toggleSeries();
checkHealth();
checkAIO();
refresh();
pollStates();
setInterval(()=>{ checkHealth(); checkAIO(); }, 15000);
</script>
</body>
</html>"""


@app.get("/", response_class=HTMLResponse)
async def ui():
    return HTMLResponse(UI_HTML)


# ---------------------------------------------------------------------------
# Config + connection test
# ---------------------------------------------------------------------------

@app.get("/api/config")
async def get_config():
    return {
        "aiostreams_url":  os.environ.get("AIOSTREAMS_URL", "http://localhost:3001"),
        "uuid_set":        bool(os.environ.get("AIOSTREAMS_UUID")),
        "password_set":    bool(os.environ.get("AIOSTREAMS_PASSWORD")),
        "library_root":    os.environ.get("LIBRARY_ROOT", "/library"),
    }


@app.get("/api/test")
async def test_connection():
    """Test live connectivity to AIOStreams."""
    result = await _client.connection_test()
    return result


# ---------------------------------------------------------------------------
# Add media
# ---------------------------------------------------------------------------

class AddReq(BaseModel):
    imdb_id:    str
    title:      str
    year:       Optional[int] = None
    media_type: str = "movie"
    season:     Optional[int] = None
    episode:    Optional[int] = None


@app.post("/api/add")
async def add_media(req: AddReq):
    media_id   = req.imdb_id
    if req.season and req.episode:
        media_id += f"_s{req.season}e{req.episode}"
    media_type = MediaType.MOVIE if req.media_type == "movie" else MediaType.SERIES

    item = MediaItem(
        id=media_id, imdb_id=req.imdb_id, title=req.title,
        year=req.year, media_type=media_type,
        season=req.season, episode=req.episode,
    )

    try:
        item.streams = await _client.resolve_all(item)
    except Exception as exc:
        logger.error("AIOStreams query failed: %s", exc)
        raise HTTPException(status_code=502, detail=str(exc))

    if not item.streams:
        raise HTTPException(
            status_code=404,
            detail=(
                "AIOStreams returned no results with a direct URL. "
                "Make sure your debrid service is configured in AIOStreams "
                "and the media exists."
            ),
        )

    stubs = await _stubs.create_stubs(item)
    return {
        "media_id": media_id,
        "title": item.title,
        "streams_found": len(item.streams),
        "has_4k": item.has_4k,
        "stubs_created": [
            {"stub_id": s.stub_id, "quality": s.quality.value, "path": s.abs_path}
            for s in stubs
        ],
    }


# ---------------------------------------------------------------------------
# Stub management
# ---------------------------------------------------------------------------

@app.get("/api/stubs")
async def list_stubs():
    all_s = _stubs.all()
    return {
        "count": len(all_s),
        "stubs": [
            {
                "stub_id":   s.stub_id,
                "media_id":  s.media_id,
                "title":     s.title,
                "quality":   s.quality.value,
                "state":     s.state.value,
                "path":      s.abs_path,
                "stream_url": (s.stream_url[:80] + "…") if s.stream_url else None,
            }
            for s in all_s
        ],
    }


@app.get("/api/stubs/{stub_id}")
async def get_stub(stub_id: str):
    s = _stubs.get(stub_id)
    if not s:
        raise HTTPException(404, "Not found")
    return {
        "stub_id": s.stub_id, "media_id": s.media_id, "title": s.title,
        "quality": s.quality.value, "state": s.state.value,
        "path": s.abs_path, "imdb_id": s.imdb_id,
        "aiostreams_id": s.aiostreams_id, "stream_url": s.stream_url,
        "created_at": s.created_at, "resolved_at": s.resolved_at,
    }


@app.delete("/api/stubs/{stub_id}")
async def delete_stub(stub_id: str):
    s = _stubs.get(stub_id)
    if not s:
        raise HTTPException(404, "Not found")
    p = Path(s.abs_path)
    for f in (p, p.with_suffix(".aiogateway.json")):
        try:
            if f.exists(): f.unlink()
        except Exception: pass
    _stubs._stubs.pop(stub_id, None)
    _stubs._path_index.pop(s.abs_path, None)
    return {"deleted": stub_id}


# ---------------------------------------------------------------------------
# Plex webhook
# ---------------------------------------------------------------------------

@app.post("/webhook/plex")
async def plex_webhook(request: Request):
    ct = request.headers.get("content-type", "")
    if "multipart/form-data" in ct:
        form = await request.form()
        raw = form.get("payload", "{}")
    else:
        raw = (await request.body()).decode()
    result = await _webhook.handle(raw)
    logger.info("Webhook result: %s", result)
    return JSONResponse(result)


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

@app.get("/proxy/{stub_id}")
async def proxy_get(stub_id: str, request: Request):
    s = _stubs.get(stub_id)
    if not s:
        raise HTTPException(404, "Stub not found")
    if s.state == StubState.PLACEHOLDER:
        raise HTTPException(503, "Waiting for Plex play event")
    if s.state == StubState.ERROR or not s.stream_url:
        raise HTTPException(502, "Stream resolution failed")
    status, headers, body = await _proxy.proxy(s, request.headers.get("Range"))
    return StreamingResponse(body, status_code=status, headers=headers,
                             media_type=headers.get("Content-Type", "video/x-matroska"))


@app.head("/proxy/{stub_id}")
async def proxy_head(stub_id: str):
    s = _stubs.get(stub_id)
    if not s or not s.stream_url:
        raise HTTPException(404)
    status, headers = await _proxy.head(s)
    return StreamingResponse(b"", status_code=status, headers=headers)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    all_s = _stubs.all()
    return {
        "status": "ok",
        "stubs": len(all_s),
        "active": sum(1 for s in all_s if s.state == StubState.ACTIVE),
        "aiostreams_url": os.environ.get("AIOSTREAMS_URL", "not set"),
    }
