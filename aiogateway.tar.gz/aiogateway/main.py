"""
AIOGateway — FastAPI + NuvioWeb-style UI using Cinemeta for metadata.

Cinemeta (v3-cinemeta.strem.io) is the same free metadata source used by
NuvioWeb/NuvioTV. No API key needed. Returns IMDb IDs, posters/backdrops
from TMDB CDN. Endpoints:
  /catalog/movie/top.json  → popular movies
  /catalog/series/top.json → popular series
  /meta/{type}/{imdb_id}.json → single item detail

Endpoints
---------
GET  /                           NuvioWeb-style browse UI
GET  /api/config                 Env config
GET  /api/test                   AIOStreams connectivity test
GET  /api/cinemeta/{path}        Cinemeta proxy (no CORS issues from browser)
POST /api/add                    Add media → AIOStreams → stub files
GET  /api/stubs                  List stubs
DELETE /api/stubs/{id}           Delete stub + file

POST /webhook/plex               Plex play event
GET  /proxy/{stub_id}            Stream proxy → Plex
HEAD /proxy/{stub_id}            HEAD pre-flight
GET  /health                     Health
"""
from __future__ import annotations

import asyncio
import copy
import json
import logging
import os
import re
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

import aiohttp
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from pydantic import BaseModel

from gateway.aiostreams_client import AIOStreamsClient
from gateway.fuse_fs import mount as fuse_mount, unmount as fuse_unmount, FUSE_AVAILABLE
from gateway.models import MediaItem, MediaType, Quality, StubState
from gateway.proxy import StreamProxy
from gateway.stub_manager import StubManager
from webhook.handler import PlexWebhookHandler

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s — %(message)s")
logger = logging.getLogger("aiogateway")

_stubs   = StubManager()
_proxy   = StreamProxy()
_client  = AIOStreamsClient()
_webhook: PlexWebhookHandler | None = None
_http:    aiohttp.ClientSession | None = None

CINEMETA = "https://v3-cinemeta.strem.io"


def _emergency_unmount():
    if not FUSE_AVAILABLE:
        return
    mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    try:
        logger.info("Emergency unmount: %s", mountpoint)
        fuse_unmount(mountpoint)
    except Exception as exc:
        logger.warning("Emergency unmount error: %s", exc)


import atexit
import signal as _signal

# Register atexit so normal Python exit always unmounts
atexit.register(_emergency_unmount)


def _signal_handler(signum, frame):
    logger.info("Signal %d received — unmounting FUSE and exiting", signum)
    _emergency_unmount()
    # Re-raise default handler so the process exits with the right code
    _signal.signal(signum, _signal.SIG_DFL)
    os.kill(os.getpid(), signum)


# Catch SIGTERM (docker stop) and SIGINT (Ctrl-C)
for _sig in (_signal.SIGTERM, _signal.SIGINT):
    try:
        _signal.signal(_sig, _signal_handler)
    except (OSError, ValueError):
        pass   # may fail in non-main thread contexts


_ttl_sweep_task: Optional[asyncio.Task] = None
_TTL_SWEEP_INTERVAL = 600   # 10 minutes — fine-grained enough for a day-scale TTL

async def _ttl_sweep_loop():
    """
    Periodically reverts ACTIVE stubs whose active_ttl_days setting has
    elapsed back to PLACEHOLDER. The setting is re-read each cycle so
    changes from the UI take effect without a restart.
    """
    from gateway import settings as _settings
    while True:
        try:
            await asyncio.sleep(_TTL_SWEEP_INTERVAL)
            ttl = _settings.get("active_ttl_days", 0)
            if ttl and ttl > 0:
                reverted = await _stubs.sweep_expired(ttl)
                if reverted:
                    logger.info("TTL sweep: reverted %d stub(s) to placeholder (ttl=%g days)",
                               reverted, ttl)
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("TTL sweep error: %s", exc)


_auto_episodes_task: Optional[asyncio.Task] = None

async def _auto_episodes_loop():
    """
    Periodically checks every tracked series for newly-aired episodes and
    auto-stubs them (HD + 4K where available) — see gateway/auto_episodes.py
    for the actual discovery/retry logic. The interval and enable/disable
    setting are re-read each cycle so changes from the UI take effect
    without a restart.

    References _query_episode and _yield_to_play_priority by name rather
    than importing them — both are defined later in this module, but since
    this loop only ever calls them at runtime (after the whole module has
    finished loading), that's safe and avoids reordering a large amount of
    existing code just to satisfy import order.
    """
    from gateway import settings as _settings
    from gateway import auto_episodes as _auto_ep
    while True:
        try:
            interval_min = _settings.get("auto_episodes_interval_minutes", 30)
            await asyncio.sleep(max(60, interval_min * 60))
            if not _settings.get("auto_episodes_enabled", True):
                continue
            result = await _auto_ep.run_sweep(_stubs, _http, _query_episode, _yield_to_play_priority)
            if result.get("new_stubs"):
                logger.info("Auto-episode sweep: %s", result)
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("Auto-episode sweep error: %s", exc)


_pending_movies_task: Optional[asyncio.Task] = None
_spot_check_task: Optional[asyncio.Task] = None
_prewarm_task: Optional[asyncio.Task] = None

async def _pending_movies_loop():
    """
    Periodically retries every tracked-but-unresolved movie — see
    gateway/pending_movies.py. Reuses auto_episodes_interval_minutes for
    cadence rather than introducing a second interval setting; the two
    sweeps are conceptually the same kind of "keep checking until it
    shows up" background job, just for movies vs. episodes.

    References _query_movie by name rather than importing it — it's
    defined later in this module, but since this loop only calls it at
    runtime (after the whole module has finished loading), that's safe.
    """
    from gateway import settings as _settings
    from gateway import pending_movies as _pending_mv
    while True:
        try:
            interval_min = _settings.get("auto_episodes_interval_minutes", 30)
            await asyncio.sleep(max(60, interval_min * 60))
            result = await _pending_mv.run_sweep(_query_movie, yield_fn=_yield_to_play_priority)
            if result.get("resolved"):
                logger.info("Pending-movie sweep: %s", result)
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("Pending-movie sweep error: %s", exc)


async def _spot_check_loop():
    """
    Runs a full spot check (check + auto-fix, same as the manual "Run spot
    check" button) on a configurable interval — 0 hours (the default)
    disables this entirely, any positive number of hours runs it that
    often. References _run_spot_check/_spotcheck_jobs by name rather than
    importing — both are defined later in this module, safe since this
    loop only calls them at runtime after the whole module has loaded.
    """
    from gateway import settings as _settings
    while True:
        try:
            interval_hours = _settings.get("spot_check_interval_hours", 0) or 0
            if not interval_hours:
                await asyncio.sleep(300)   # not enabled — just poll for the setting turning on
                continue
            await asyncio.sleep(max(60, interval_hours * 3600))
            # Re-check in case it was disabled while sleeping
            interval_hours = _settings.get("spot_check_interval_hours", 0) or 0
            if not interval_hours:
                continue
            scope = _settings.get("spot_check_scheduled_scope", "both")
            job_id = uuid.uuid4().hex[:12]
            _spotcheck_jobs[job_id] = {
                "job_id": job_id, "scope": scope, "phase": "checking", "total": 0, "done": 0,
                "current_title": "", "status": "starting", "finished": False,
                "fixed_episodes": [], "still_missing_episodes": [],
                "fixed_movies": [], "still_missing_movies": [],
            }
            await _run_spot_check(job_id, scope)
            job = _spotcheck_jobs.get(job_id, {})
            fixed = len(job.get("fixed_episodes", [])) + len(job.get("fixed_movies", []))
            missing = len(job.get("still_missing_episodes", [])) + len(job.get("still_missing_movies", []))
            logger.info("Scheduled spot check complete: %d found, %d still missing", fixed, missing)
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("Scheduled spot check error: %s", exc)


async def _prewarm_loop():
    """
    Runs "Prewarm new releases" (same job as the manual button) on a
    configurable interval — 0 hours disables this, any positive number
    runs it that often. Defaults on (prewarm_interval_hours: 1) since new
    releases are inherently time-sensitive. References
    _run_prewarm_new_releases/_prewarm_jobs by name rather than
    importing — both are defined later in this module, safe since this
    loop only calls them at runtime after the whole module has loaded.
    """
    from gateway import settings as _settings
    while True:
        try:
            interval_hours = _settings.get("prewarm_interval_hours", 1) or 0
            if not interval_hours:
                await asyncio.sleep(300)   # not enabled — just poll for the setting turning on
                continue
            await asyncio.sleep(max(60, interval_hours * 3600))
            # Re-check in case it was disabled while sleeping
            interval_hours = _settings.get("prewarm_interval_hours", 1) or 0
            if not interval_hours:
                continue
            job_id = uuid.uuid4().hex[:12]
            _prewarm_jobs[job_id] = {
                "job_id": job_id, "phase": "resolving", "total": 0, "done": 0, "current_title": "",
                "status": "starting", "finished": False,
                "resolved": [], "dead_removed": [], "still_placeholder": [],
            }
            await _run_prewarm_new_releases(job_id)
            job = _prewarm_jobs.get(job_id, {})
            logger.info("Scheduled prewarm complete: %d resolved, %d dead removed, %d still placeholder",
                       len(job.get("resolved", [])), len(job.get("dead_removed", [])),
                       len(job.get("still_placeholder", [])))
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("Scheduled prewarm error: %s", exc)


async def _warm_calendar_cache_once():
    """
    Pre-fetches the calendar's default window (same days_back/days_ahead
    the API defaults to, matching the common case of opening the tab on
    the current month) once, shortly after startup, in the background —
    so the FIRST click on the Calendar tab hits an already-warm cache
    instead of paying the full concurrent-Cinemeta-fetch cost right at
    that moment. References get_calendar by name rather than importing;
    safe since this only runs well after the whole module has loaded.
    """
    try:
        await asyncio.sleep(5)   # let the rest of startup settle first
        await get_calendar(days_back=14, days_ahead=30)
        logger.info("Calendar cache pre-warmed at startup")
    except Exception as exc:
        logger.warning("Calendar cache warm-up failed: %s", exc)


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _webhook, _http, _ttl_sweep_task, _auto_episodes_task, _pending_movies_task, _spot_check_task, _prewarm_task
    await _proxy.open()
    await _client.open()
    _http    = aiohttp.ClientSession(headers={"User-Agent": "AIOGateway/0.3"})
    _webhook = PlexWebhookHandler(_stubs, _client, _play_priority_enter, _play_priority_exit)
    restored = await _stubs.restore()
    logger.info("AIOGateway started — %d stubs restored", restored)

    from gateway import settings as _settings
    _settings.load()

    # Mount virtual FUSE filesystem
    mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    if FUSE_AVAILABLE:
        fuse_mount(_stubs, _client, mountpoint)
        logger.info("FUSE mounted at %s", mountpoint)
    else:
        logger.warning("FUSE unavailable — stub files will be served directly (no seeking)")

    _ttl_sweep_task = asyncio.create_task(_ttl_sweep_loop())
    _auto_episodes_task = asyncio.create_task(_auto_episodes_loop())
    _pending_movies_task = asyncio.create_task(_pending_movies_loop())
    _spot_check_task = asyncio.create_task(_spot_check_loop())
    _prewarm_task = asyncio.create_task(_prewarm_loop())
    asyncio.create_task(_warm_calendar_cache_once())

    try:
        yield
    finally:
        # Clean shutdown path — also covered by atexit but explicit is better
        if _ttl_sweep_task:
            _ttl_sweep_task.cancel()
        if _auto_episodes_task:
            _auto_episodes_task.cancel()
        if _pending_movies_task:
            _pending_movies_task.cancel()
        if _spot_check_task:
            _spot_check_task.cancel()
        if _prewarm_task:
            _prewarm_task.cancel()
        if FUSE_AVAILABLE:
            fuse_unmount(mountpoint)
        await _proxy.close()
        await _client.close()
        if _http: await _http.close()


app = FastAPI(title="AIOGateway", version="0.3.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ---------------------------------------------------------------------------
# Cinemeta proxy  —  /api/cinemeta/{path}
# ---------------------------------------------------------------------------

@app.get("/api/cinemeta/{path:path}")
async def cinemeta_proxy(path: str):
    """Proxy Cinemeta requests from the browser to avoid any CORS issues."""
    assert _http
    url = f"{CINEMETA}/{path}"
    try:
        async with _http.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
            data = await resp.json(content_type=None)
            return JSONResponse(data, status_code=resp.status)
    except Exception as exc:
        logger.error("Cinemeta proxy error %s: %s", url, exc)
        raise HTTPException(502, f"Cinemeta unreachable: {exc}")


# ---------------------------------------------------------------------------
# Embedded NuvioWeb-style UI
# ---------------------------------------------------------------------------

UI_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>AIOGateway</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet"/>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#080810;--sur:#10101a;--card:#14141f;--card2:#1a1a28;
  --bor:rgba(255,255,255,.08);--bor2:rgba(255,255,255,.14);
  --txt:#f0f0f8;--mut:#7878a0;--acc:#e8a020;--acc2:#f5b840;
  --blue:#4a9eff;--grn:#3dd68c;--red:#ff5555;
  --navh:64px;--f:'Inter',system-ui,sans-serif;
}
html,body{height:100%;background:var(--bg);color:var(--txt);font-family:var(--f);font-size:15px;line-height:1.5;-webkit-font-smoothing:antialiased;overflow-x:hidden;scroll-behavior:smooth}

/* ── Nav pill ───────────────────────────────────────────────── */
.nav{
  position:fixed;top:18px;left:50%;transform:translateX(-50%);z-index:100;
  display:flex;align-items:center;gap:2px;
  background:rgba(8,8,16,.85);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);
  border:1px solid var(--bor2);border-radius:50px;padding:5px 6px;
}
.ni{
  display:flex;align-items:center;gap:6px;padding:8px 20px;
  border-radius:40px;font-size:14px;font-weight:600;cursor:pointer;
  border:none;background:none;color:var(--mut);font-family:var(--f);
  transition:all 150ms;white-space:nowrap;
}
.ni:hover{color:var(--txt);background:rgba(255,255,255,.07)}
.ni.on{background:rgba(255,255,255,.12);color:var(--txt)}

/* ── Hero ───────────────────────────────────────────────────── */
.hero{position:relative;height:100vh;max-height:600px;min-height:420px;overflow:hidden;display:flex;align-items:flex-end}
.hero-bg{
  position:absolute;inset:0;
  background-size:cover;background-position:center 20%;
  transition:background-image .5s ease;
}
.hero-ov{
  position:absolute;inset:0;
  background:linear-gradient(to bottom,
    rgba(8,8,16,.2) 0%,
    rgba(8,8,16,.0) 20%,
    rgba(8,8,16,.5) 55%,
    rgba(8,8,16,.95) 85%,
    var(--bg) 100%);
}
.hero-body{position:relative;z-index:2;padding:0 56px 48px;max-width:620px}
.hero-logo{max-height:64px;max-width:280px;margin-bottom:14px;object-fit:contain;filter:drop-shadow(0 2px 12px rgba(0,0,0,.8));display:none}
.hero-title{font-size:56px;font-weight:900;letter-spacing:-2px;line-height:1;margin-bottom:10px;text-shadow:0 2px 20px rgba(0,0,0,.9)}
.hero-meta{display:flex;align-items:center;gap:10px;font-size:14px;color:rgba(255,255,255,.7);font-weight:500;margin-bottom:10px}
.hero-sep{opacity:.4}
.hero-rating{background:rgba(255,255,255,.15);border-radius:5px;padding:2px 8px;font-size:12px;font-weight:700;color:var(--acc2)}
.hero-desc{font-size:14px;color:rgba(255,255,255,.65);line-height:1.6;margin-bottom:20px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.hero-dots{display:flex;gap:5px;margin-bottom:22px}
.hero-dot{width:24px;height:3px;border-radius:2px;background:rgba(255,255,255,.25);cursor:pointer;transition:all 200ms}
.hero-dot.on{background:#fff;width:32px}
.hero-acts{display:flex;gap:10px}
.btn-hero{
  display:flex;align-items:center;gap:8px;padding:12px 28px;border-radius:8px;
  font-family:var(--f);font-size:14px;font-weight:700;cursor:pointer;border:none;transition:all 150ms;
}
.btn-add{background:var(--acc);color:#000}
.btn-add:hover{background:var(--acc2);transform:translateY(-1px)}
.btn-add.added{background:var(--grn);color:#000}
.btn-info{background:rgba(255,255,255,.16);color:#fff;backdrop-filter:blur(8px)}
.btn-info:hover{background:rgba(255,255,255,.26)}

/* ── Content rows ───────────────────────────────────────────── */
.rows{padding-bottom:48px}
.sec{margin-bottom:8px}
.sec-hd{display:flex;align-items:center;justify-content:space-between;padding:0 56px;margin-bottom:16px}
.sec-title{font-size:18px;font-weight:700;letter-spacing:-.3px;border-left:3px solid var(--acc);padding-left:12px}
.view-all{font-size:13px;font-weight:600;color:var(--mut);cursor:pointer;background:none;border:none;font-family:var(--f);display:flex;align-items:center;gap:3px}
.view-all:hover{color:var(--txt)}
.row{display:flex;gap:14px;overflow-x:auto;overflow-y:visible;padding:4px 56px 14px;scrollbar-width:none}
.row::-webkit-scrollbar{display:none}

/* ── Card ───────────────────────────────────────────────────── */
.card{flex:0 0 138px;cursor:pointer;position:relative;transition:transform 200ms}
.card:hover{transform:scale(1.07) translateY(-2px)}
.cposter{width:138px;height:207px;border-radius:10px;overflow:hidden;background:var(--card2);position:relative;box-shadow:0 4px 16px rgba(0,0,0,.4)}
.card.inlib .cposter{box-shadow:0 0 0 2px var(--grn),0 4px 16px rgba(0,0,0,.4)}
.cposter img{width:100%;height:100%;object-fit:cover;display:block;opacity:0;transition:opacity .3s}
.cposter img.loaded{opacity:1}
.crating{position:absolute;top:7px;right:7px;background:rgba(0,0,0,.78);backdrop-filter:blur(4px);border-radius:5px;padding:2px 7px;font-size:11px;font-weight:700;color:var(--acc2)}
.ccheck{position:absolute;top:7px;right:7px;width:22px;height:22px;border-radius:50%;background:var(--grn);display:none;align-items:center;justify-content:center;font-size:12px;color:#000;font-weight:800}
.card.inlib .ccheck{display:flex}
.card.inlib .crating{display:none}
.cname{font-size:12px;font-weight:600;margin-top:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cyear{font-size:11px;color:var(--mut);margin-top:2px}

/* ── Search page ─────────────────────────────────────────────── */
/* Same padding rhythm and surface tokens as Library/Config pages */
.srchpage{padding:calc(var(--navh) + 28px) 56px 48px}
.srch-hd{margin-bottom:28px}
.srch-bar-wrap{
  display:flex;align-items:center;gap:10px;
  background:var(--card2);border:1px solid var(--bor2);
  border-radius:10px;padding:12px 16px;
  transition:border-color 180ms;
}
.srch-bar-wrap:focus-within{border-color:var(--acc)}
.srch-icon{font-size:17px;color:var(--mut);flex-shrink:0}
.srch-input{
  background:none;border:none;outline:none;font-family:var(--f);
  font-size:15px;color:var(--txt);width:100%;font-weight:500;
}
.srch-input::placeholder{color:var(--mut)}
.srch-clear{
  background:var(--card);border:1px solid var(--bor2);border-radius:7px;
  color:var(--mut);font-size:12px;padding:5px 11px;cursor:pointer;
  font-family:var(--f);font-weight:600;white-space:nowrap;flex-shrink:0;
  transition:all 150ms;display:none;
}
.srch-clear:hover{color:var(--txt);border-color:var(--acc)}
.srch-tabs{display:flex;gap:6px;margin-top:14px}
.srch-tab{
  padding:7px 18px;border-radius:30px;font-size:13px;font-weight:600;
  cursor:pointer;border:1px solid var(--bor2);background:none;
  color:var(--mut);font-family:var(--f);transition:all 150ms;
}
.srch-tab:hover{color:var(--txt)}
.srch-tab.on{background:var(--acc);color:#000;border-color:var(--acc)}
.srch-status{font-size:13px;color:var(--mut);margin-bottom:18px;min-height:20px}
.srch-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(138px,1fr));
  gap:22px 14px;
}
.srch-empty{
  grid-column:1/-1;text-align:center;padding:60px 20px;
  color:var(--mut);
}
.srch-empty-icon{font-size:36px;margin-bottom:12px;opacity:.3}
.srch-empty-title{font-size:14px;font-weight:600;margin-bottom:4px}
.srch-empty-sub{font-size:12px;opacity:.7}

/* ── View All overlay ───────────────────────────────────────── */
.va-overlay{
  position:fixed;inset:0;background:var(--bg);z-index:150;
  overflow-y:auto;scrollbar-width:none;
  opacity:0;pointer-events:none;transition:opacity 200ms;
}
.va-overlay::-webkit-scrollbar{display:none}
.va-overlay.open{opacity:1;pointer-events:all}
.va-inner{padding:calc(var(--navh) + 28px) 56px 48px}
.va-header{display:flex;align-items:center;gap:18px;margin-bottom:28px}
.va-back{
  display:flex;align-items:center;gap:6px;
  background:var(--card2);border:1px solid var(--bor2);border-radius:8px;
  padding:8px 16px;font-family:var(--f);font-size:13px;font-weight:600;
  color:var(--mut);cursor:pointer;transition:all 150ms;flex-shrink:0;
}
.va-back:hover{color:var(--txt);border-color:var(--acc)}
.va-title{font-size:22px;font-weight:800;letter-spacing:-.4px}
.va-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(138px,1fr));
  gap:22px 14px;
}

/* ── Season picker ──────────────────────────────────────────── */
.season-picker{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px}
.season-btn{
  padding:5px 14px;border-radius:6px;font-size:12px;font-weight:700;
  cursor:pointer;border:1px solid var(--bor2);background:var(--card2);
  color:var(--mut);font-family:var(--f);transition:all 140ms;
}
.season-btn:hover{border-color:var(--acc);color:var(--txt)}
.season-btn.on{background:var(--acc);color:#000;border-color:var(--acc)}
.season-btn.all-btn{background:var(--card2);color:var(--txt);border-color:var(--bor2)}
.season-btn.all-btn.on{background:var(--acc);color:#000}
/* Already-requested season: filled green. Selection (.on) still takes
   visual priority if the user has that season actively picked, so a
   requested season that's also selected shows the accent (orange) state
   rather than competing colors. */
.season-btn.requested{background:var(--grn);color:#000;border-color:var(--grn)}
.season-btn.requested:hover{border-color:var(--grn);color:#000}
.season-btn.requested.on{background:var(--acc);color:#000;border-color:var(--acc)}

/* ── Skeleton ───────────────────────────────────────────────── */
.skel{background:linear-gradient(90deg,var(--card) 25%,var(--card2) 50%,var(--card) 75%);background-size:200% 100%;animation:shim 1.5s infinite;border-radius:10px}
@keyframes shim{0%{background-position:200% 0}100%{background-position:-200% 0}}

/* ── Modal ──────────────────────────────────────────────────── */
.mbg{position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);z-index:200;display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;transition:opacity 180ms}
.mbg.open{opacity:1;pointer-events:all}
.modal{background:var(--card);border:1px solid var(--bor2);border-radius:18px;width:92%;max-width:520px;overflow:hidden;transform:scale(.94) translateY(12px);transition:transform 180ms}
.mbg.open .modal{transform:scale(1) translateY(0)}
.mhero{height:220px;background-size:cover;background-position:center;position:relative}
.mhero-ov{position:absolute;inset:0;background:linear-gradient(to bottom,rgba(20,20,31,.2) 0%,var(--card) 100%)}
.mbody{padding:20px 24px 26px}
.mtitle{font-size:22px;font-weight:800;letter-spacing:-.5px;margin-bottom:6px}
.mmeta{display:flex;gap:9px;font-size:13px;color:var(--mut);margin-bottom:10px;flex-wrap:wrap;align-items:center}
.mrating{background:var(--card2);border:1px solid var(--bor);padding:2px 8px;border-radius:5px;font-size:11px;font-weight:700;color:var(--acc2)}
.mpills{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:14px}
.mpill{background:var(--card2);border:1px solid var(--bor);padding:3px 11px;border-radius:20px;font-size:12px;font-weight:500}
.moverview{font-size:13px;color:var(--mut);line-height:1.7;margin-bottom:22px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.macts{display:flex;gap:10px}
.mbtn{flex:1;display:flex;align-items:center;justify-content:center;gap:7px;padding:12px;border-radius:9px;font-family:var(--f);font-size:13px;font-weight:700;cursor:pointer;border:none;transition:all 150ms}
.mbtn-add{background:var(--acc);color:#000}
.mbtn-add:hover{background:var(--acc2)}
.mbtn-add.added{background:var(--grn);color:#000}
.mbtn-add.pending{background:var(--blue);color:#04111f}
.mbtn-close{background:var(--card2);color:var(--mut);border:1px solid var(--bor2)}
.mbtn-close:hover{color:var(--txt)}
.mclose{position:absolute;top:14px;right:14px;z-index:10;width:30px;height:30px;border-radius:50%;background:rgba(0,0,0,.6);border:none;color:#fff;font-size:15px;cursor:pointer;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px)}
.mclose:hover{background:rgba(0,0,0,.9)}

/* ── Library page ───────────────────────────────────────────── */
.libpage{padding:calc(var(--navh) + 28px) 56px 48px}
.libhd{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px}
.libtitle{font-size:28px;font-weight:800;letter-spacing:-.5px}
.libgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(138px,1fr));gap:22px 14px}
.stub-state{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;margin-top:5px}
.ss-ph{background:#2a2a14;color:#c8a030}
.ss-ac{background:#0d2a18;color:var(--grn)}
.ss-er{background:#2a0d0d;color:var(--red)}
.ss-rs{background:#141e2e;color:var(--blue);animation:sblink 1.1s infinite}
@keyframes sblink{0%,100%{opacity:1}50%{opacity:.35}}
.del-btn{width:26px;height:26px;border-radius:50%;background:rgba(0,0,0,.7);border:none;color:#888;font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all 130ms}
.del-btn:hover{background:var(--red);color:#fff}

/* ── Search ─────────────────────────────────────────────────── */
.searchbar{display:flex;align-items:center;gap:9px;background:var(--card2);border:1px solid var(--bor2);border-radius:10px;padding:9px 15px}
.searchbar input{background:none;border:none;outline:none;font-family:var(--f);font-size:14px;color:var(--txt);width:100%}
.searchbar input::placeholder{color:var(--mut)}

/* ── Calendar ─────────────────────────────────────────────────── */
.cal-day{margin-bottom:28px}
.cal-day-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--mut);margin-bottom:10px;display:flex;align-items:center;gap:10px}
.cal-day-label::after{content:'';flex:1;height:1px;background:var(--bor)}
.cal-day-label.today{color:var(--acc)}
.cal-entries{display:flex;flex-direction:column;gap:8px}
.cal-entry{background:var(--card);border:1px solid var(--bor);border-radius:12px;padding:12px 14px;display:flex;align-items:center;gap:14px;cursor:pointer;transition:border-color 140ms}
.cal-entry:hover{border-color:var(--bor2)}
.cal-entry.inlib{border-left:3px solid var(--grn)}
.cal-entry.future{opacity:.75}
.cal-poster{width:38px;height:57px;border-radius:5px;object-fit:cover;flex-shrink:0;background:var(--card2)}
.cal-poster-placeholder{width:38px;height:57px;border-radius:5px;background:var(--card2);flex-shrink:0;display:flex;align-items:center;justify-content:center;color:var(--mut);font-size:18px}
.cal-info{flex:1;min-width:0}
.cal-title{font-size:14px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cal-sub{font-size:12px;color:var(--mut);margin-top:2px}
.cal-badges{display:flex;gap:6px;margin-top:6px;flex-wrap:wrap}
.cal-badge{font-size:10px;font-weight:700;padding:2px 7px;border-radius:4px;background:var(--card2);color:var(--mut)}
.cal-badge.inlib{background:#0d2a18;color:var(--grn)}
.cal-badge.theatrical{background:#1a1a10;color:#a89050}
.cal-rescan-btn{font-size:11px;font-weight:700;padding:5px 12px;border-radius:6px;border:1px solid var(--bor2);background:none;color:var(--mut);cursor:pointer;flex-shrink:0;transition:all 140ms;white-space:nowrap}
.cal-rescan-btn:hover{border-color:var(--acc);color:var(--acc)}
.cal-rescan-btn.active{border-color:var(--grn);color:var(--grn)}
.cal-rescan-btn.pending{color:var(--blue);border-color:var(--blue)}

/* ── Calendar: month grid ── */
.cal-chips{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px}
.cal-chip{font-size:12px;font-weight:700;padding:6px 13px;border-radius:50px;border:1px solid var(--bor2);background:none;color:var(--mut);cursor:pointer;transition:all 140ms;font-family:var(--f)}
.cal-chip:hover{border-color:var(--acc);color:var(--txt)}
.cal-chip.on{background:var(--acc);color:#000;border-color:var(--acc)}
.cal-monthbar{display:flex;align-items:center;justify-content:center;gap:18px;margin-bottom:16px}
.cal-navbtn{width:32px;height:32px;border-radius:8px;border:1px solid var(--bor2);background:var(--card);color:var(--mut);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:16px;transition:all 140ms}
.cal-navbtn:hover{border-color:var(--acc);color:var(--acc)}
.cal-monthlabel{font-size:16px;font-weight:700;letter-spacing:-.2px;min-width:160px;text-align:center}
.cal-weekrow{display:grid;grid-template-columns:repeat(7,1fr);gap:6px;margin-bottom:6px}
.cal-weekday{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--mut);text-align:center;padding:2px 0}
.cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:6px}
.cal-cell{min-height:84px;border-radius:10px;border:1px solid var(--bor);background:var(--card);padding:6px;cursor:pointer;transition:border-color 140ms;display:flex;flex-direction:column;gap:4px;min-width:0;overflow:hidden}
.cal-cell:hover{border-color:var(--bor2)}
.cal-cell.blank{background:none;border:none;cursor:default}
.cal-cell.selected{border-color:var(--acc)}
.cal-cellnum{font-size:12px;color:var(--mut);width:20px;height:20px;border-radius:50%;display:flex;align-items:center;justify-content:center}
.cal-cellnum.today{background:var(--acc);color:#000;font-weight:700}
.cal-pill{font-size:10px;font-weight:700;padding:2px 6px;border-radius:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;background:rgba(74,158,255,.14);color:var(--blue);border:1px solid rgba(74,158,255,.28)}
.cal-pill.movie{background:rgba(232,160,32,.14);color:var(--acc2);border-color:rgba(232,160,32,.28)}
.cal-pill.inlib{background:var(--grn);color:#04210f;border-color:var(--grn)}
.cal-cellmore{font-size:10px;color:var(--mut);padding:0 2px}
.cal-detail{margin-top:18px;background:var(--card);border:1px solid var(--bor);border-radius:14px;padding:16px}
.cal-detail-date{font-size:14px;font-weight:700;margin-bottom:12px}
.cal-detail-empty{color:var(--mut);font-size:13px;padding:8px 0}


.cfgpage{padding:calc(var(--navh) + 28px) 56px 48px}
.cfgsec{background:var(--card);border:1px solid var(--bor);border-radius:14px;padding:22px;margin-bottom:16px}
.cfgsec h3{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--mut);margin-bottom:16px}
.cfgtabs{display:flex;gap:4px;margin-bottom:24px;border-bottom:1px solid var(--bor);padding-bottom:0}
.cfgtab{
  display:flex;align-items:center;gap:7px;padding:10px 18px;
  font-size:14px;font-weight:600;cursor:pointer;
  border:none;background:none;color:var(--mut);font-family:var(--f);
  border-bottom:2px solid transparent;margin-bottom:-1px;
  transition:all 150ms;white-space:nowrap;
}
.cfgtab:hover{color:var(--txt)}
.cfgtab.on{color:var(--acc);border-bottom-color:var(--acc)}
.cfgpanel{display:none}
.cfgpanel.on{display:block}
.chips{display:flex;flex-wrap:wrap;gap:8px}
.chip{background:var(--card2);border:1px solid var(--bor);border-radius:8px;padding:7px 14px;font-size:12px;display:flex;gap:8px}
.cl{color:var(--mut);font-weight:600}
.cv{font-family:monospace;color:var(--txt)}
.cv.ok{color:var(--grn)}
.cv.er{color:var(--red)}
.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 20px;border-radius:8px;font-family:var(--f);font-size:13px;font-weight:700;cursor:pointer;border:none;transition:all 150ms}
.bp{background:var(--acc);color:#000}.bp:hover{background:var(--acc2)}
.bg2{background:var(--card2);color:var(--mut);border:1px solid var(--bor2)}.bg2:hover{color:var(--txt)}
.tresult{font-size:13px;color:var(--mut);margin-bottom:14px;min-height:20px}
.checklist{font-size:13px;color:var(--mut);line-height:2.2}
.checklist code{background:var(--card2);color:var(--acc2);padding:1px 7px;border-radius:5px;font-size:12px}

/* ── Toast ───────────────────────────────────────────────────── */
.toast{position:fixed;bottom:26px;right:26px;z-index:500;background:var(--card);border:1px solid var(--bor2);border-radius:12px;padding:12px 18px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;animation:tin .2s ease}
@keyframes tin{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.toast.ok{border-color:var(--grn);color:var(--grn)}
.toast.er{border-color:var(--red);color:var(--red)}
.toast.in{border-color:var(--blue);color:var(--blue)}

/* ── Mobile ──────────────────────────────────────────────────── */
/* Every page (.hero-body, .sec-hd, .srchpage, .va-inner, .libpage,
   .cfgpage) shares the same 56px side padding — that's the single
   biggest lever for "too cramped on a phone", so it's the first thing
   trimmed at each breakpoint below. */
@media (max-width: 900px) {
  .hero-body, .sec-hd, .srchpage, .va-inner, .libpage, .cfgpage, .row {
    padding-left: 24px !important;
    padding-right: 24px !important;
  }
}

@media (max-width: 640px) {
  .hero-body, .sec-hd, .srchpage, .va-inner, .libpage, .cfgpage, .row {
    padding-left: 14px !important;
    padding-right: 14px !important;
  }

  /* Nav: five items at desktop padding won't fit a phone width — shrink
     padding/font first, and let it scroll horizontally as a fallback
     rather than wrapping into a second row or overflowing the screen. */
  .nav {
    max-width: calc(100vw - 20px);
    overflow-x: auto;
    -ms-overflow-style: none; scrollbar-width: none;
  }
  .nav::-webkit-scrollbar { display: none; }
  .ni { padding: 7px 12px; font-size: 12px; }

  /* Extra top clearance below the fixed nav — every page uses the same
     --navh-based padding-top, which is a fixed assumed value rather than
     the nav's real rendered height, so this adds a safety margin on
     mobile rather than relying on that assumption being exact. Also
     covers the Calendar page specifically, whose title+Refresh row uses
     justify-content:space-between (title pinned to the far left edge,
     button to the far right) — full-width edge-to-edge like that is
     exactly what ends up peeking out from behind the nav pill (which is
     centered and narrower than the screen) if clearance is even
     slightly short, since the nav's blurred background only covers its
     own centered width, not the full row underneath it. */
  .hero-body, .sec-hd, .srchpage, .va-inner, .libpage, .cfgpage {
    padding-top: calc(var(--navh) + 20px) !important;
  }

  /* Hero: desktop sizing (100vh tall, 56px title) is oversized on a
     phone screen and pushes everything below the fold. */
  .hero { height: 62vh; min-height: 320px; max-height: 460px; }
  .hero-title { font-size: 30px; letter-spacing: -1px; }
  .hero-desc { font-size: 13px; -webkit-line-clamp: 2; }
  .hero-meta { font-size: 12px; }
  .hero-acts { flex-wrap: wrap; }
  .btn-hero { padding: 10px 18px !important; font-size: 13px !important; }

  .libtitle { font-size: 22px; }
  .libhd { flex-wrap: wrap; gap: 12px; }
  .searchbar { max-width: 100% !important; }

  /* Library/search grids: 138px card columns are fine on desktop but
     leave awkward leftover space on a ~375-414px phone — drop the
     minimum so 2 full columns fit cleanly instead of 1.5. */
  .libgrid { grid-template-columns: repeat(auto-fill, minmax(108px, 1fr)) !important; gap: 16px 10px !important; }
  .cposter { width: 100%; height: auto; aspect-ratio: 2/3; }

  /* Calendar: 7 columns is unavoidable for a month grid, so this is
     about making each cell survive at ~45-50px wide rather than
     changing the layout shape. */
  .cal-cell { min-height: 56px; padding: 3px; gap: 2px; }
  .cal-cellnum { font-size: 10px; width: 16px; height: 16px; }
  .cal-pill { font-size: 8px; padding: 1px 3px; }
  .cal-cellmore { font-size: 8px; }
  .cal-weekday { font-size: 9px; }
  .cal-monthlabel { font-size: 14px; min-width: 120px; }
  .cal-navbtn { width: 28px; height: 28px; font-size: 14px; }
  .cal-chips { gap: 6px; }
  .cal-chip { padding: 5px 10px; font-size: 11px; }

  /* Modals: keep them comfortably inside the viewport with room to
     scroll instead of getting clipped or forcing horizontal scroll. */
  .modal { width: 94%; max-height: 88vh; overflow-y: auto; }
  .mbody { padding: 18px 16px 20px; }
  .macts { flex-wrap: wrap; }
  .hero-title, .mtitle { word-break: break-word; }

  /* Config: 6 tabs wrapping onto multiple lines looks broken — scroll
     horizontally instead, same fallback pattern as the main nav. */
  .cfgtabs {
    flex-wrap: nowrap; overflow-x: auto; gap: 2px;
    -ms-overflow-style: none; scrollbar-width: none;
  }
  .cfgtabs::-webkit-scrollbar { display: none; }
  .cfgtab { padding: 9px 12px; font-size: 13px; }
  .cfgsec { padding: 16px; }

  /* Every settings section that pairs two fields side by side
     (Stream preferences, Pending movies, AIOStreams pacing, Spot check
     schedule, etc.) uses this exact inline grid-template-columns value —
     collapsing it to one column is the single change that fixes all of
     them at once, since a CSS class can't otherwise win against an
     inline style without this. */
  div[style*="grid-template-columns:1fr 1fr"] { grid-template-columns: 1fr !important; }
  div[style*="grid-template-columns: 1fr 1fr"] { grid-template-columns: 1fr !important; }

  /* Season/quality action rows (Scan HD / Scan 4K / Scan HD+4K / Remove,
     and similar button clusters) already wrap via inline flex-wrap in
     most places — this is a defensive backstop for the few that don't. */
  .season-btn, .cal-rescan-btn { font-size: 11px; padding: 5px 9px; }
}

@media (max-width: 400px) {
  .hero-title { font-size: 24px; }
  .libgrid { grid-template-columns: repeat(auto-fill, minmax(92px, 1fr)) !important; gap: 12px 8px !important; }
  .cal-cell { min-height: 48px; }
  .cal-pill { display: none; }   /* too tight to show pill text at this width — the day still opens the detail panel */
}
</style>
</head>
<body>

<!-- Nav -->
<nav class="nav">
  <button class="ni on" onclick="nav('home',this)">Home</button>
  <button class="ni"    onclick="nav('search',this)">Search</button>
  <button class="ni"    onclick="nav('calendar',this)">Calendar</button>
  <button class="ni"    onclick="nav('library',this)">Library</button>
  <button class="ni"    onclick="nav('config',this)">Config</button>
</nav>

<!-- SEARCH -->
<div id="pSearch" style="display:none">
  <div class="srchpage">
    <div class="srch-hd">
      <div class="srch-bar-wrap">
        <input class="srch-input" id="srchInput" placeholder="Search movies and series…"
               oninput="onSrchInput(this.value)" onkeydown="if(event.key==='Enter')doSearch()"/>
        <button class="srch-clear" id="srchClear" onclick="clearSearch()">Clear</button>
      </div>
      <div class="srch-tabs">
        <button class="srch-tab on" id="tabAll"    onclick="setTab('all',this)">All</button>
        <button class="srch-tab"    id="tabMovies" onclick="setTab('movie',this)">Movies</button>
        <button class="srch-tab"    id="tabSeries" onclick="setTab('series',this)">Series</button>
      </div>
    </div>
    <div class="srch-status" id="srchStatus"></div>
    <div class="srch-grid" id="srchGrid">
      <div class="srch-empty">
        
        <div class="srch-empty-title">Search for movies and series</div>
        <div class="srch-empty-sub">Powered by Cinemeta — the same source as Stremio</div>
      </div>
    </div>
  </div>
</div>

<!-- HOME -->
<div id="pHome">
  <div class="hero" id="hero">
    <div class="hero-bg" id="heroBg"></div>
    <div class="hero-ov"></div>
    <div class="hero-body">
      <img class="hero-logo" id="heroLogo" alt=""/>
      <div class="hero-title" id="heroTitle">…</div>
      <div class="hero-meta" id="heroMeta"></div>
      <div class="hero-desc" id="heroDesc"></div>
      <div class="hero-dots" id="heroDots"></div>
      <div class="hero-acts">
        <button class="btn-hero btn-add" id="heroBtn" onclick="heroAdd()">Add to Plex</button>
        <button class="btn-hero btn-info" onclick="heroInfo()">More Info</button>
      </div>
    </div>
  </div>

  <div class="rows">
    <div class="sec">
      <div class="sec-hd">
        <span class="sec-title">Popular — Movie</span>
        <button class="view-all" onclick="viewAll('Popular — Movie','catalog/movie/top.json','movie')">View All ›</button>
      </div>
      <div class="row" id="rowM">
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
      </div>
    </div>
    <div class="sec">
      <div class="sec-hd">
        <span class="sec-title">Popular — Series</span>
        <button class="view-all" onclick="viewAll('Popular — Series','catalog/series/top.json','series')">View All ›</button>
      </div>
      <div class="row" id="rowS">
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
      </div>
    </div>
  </div>
</div>

<!-- CALENDAR -->
<div id="pCalendar" style="display:none">
  <div class="cfgpage" style="padding-top:calc(var(--navh) + 28px)">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;flex-wrap:wrap;gap:12px">
      <h2 style="font-size:26px;font-weight:800;letter-spacing:-.5px">Calendar</h2>
      <button class="btn" onclick="loadCalendar(true)" style="padding:6px 14px;font-size:12px">Refresh</button>
    </div>
    <div class="cal-chips" id="calChips"></div>
    <div class="cal-monthbar">
      <button class="cal-navbtn" onclick="calChangeMonth(-1)" aria-label="Previous month">‹</button>
      <span class="cal-monthlabel" id="calMonthLabel"></span>
      <button class="cal-navbtn" onclick="calChangeMonth(1)" aria-label="Next month">›</button>
    </div>
    <div id="calBody">
      <div style="color:var(--mut);font-size:14px;padding:40px 0">Loading calendar…</div>
    </div>
  </div>
</div>

<!-- LIBRARY -->
<div id="pLibrary" style="display:none">
  <div class="libpage">
    <div class="libhd">
      <span class="libtitle">My Library</span>
      <div class="searchbar" style="max-width:300px">
                <input placeholder="Filter…" oninput="libSetQuery(this.value)" id="libFilter"/>
      </div>
    </div>
    <div class="cal-chips" id="libChips" style="margin-bottom:20px"></div>
    <div id="libGrid">
      <div style="color:var(--mut);font-size:14px;padding:40px 0">Loading…</div>
    </div>
  </div>
</div>

<!-- CONFIG -->
<div id="pConfig" style="display:none">
  <div class="cfgpage">
    <h2 style="font-size:26px;font-weight:800;margin-bottom:24px;letter-spacing:-.5px">Config</h2>

    <div class="cfgtabs">
      <button class="cfgtab on" id="cfgtab-connections" onclick="switchCfgTab('connections')">Connections</button>
      <button class="cfgtab" id="cfgtab-fuse" onclick="switchCfgTab('fuse')">FUSE</button>
      <button class="cfgtab" id="cfgtab-streams" onclick="switchCfgTab('streams')">Streams</button>
      <button class="cfgtab" id="cfgtab-migrate" onclick="switchCfgTab('migrate')">Migrate</button>
      <button class="cfgtab" id="cfgtab-backup" onclick="switchCfgTab('backup')">Backup/Restore</button>
    </div>

    <!-- ── Connections ──────────────────────────────────────────── -->
    <div class="cfgpanel on" id="cfgpanel-connections">
      <div class="cfgsec">
        <h3>AIOStreams connection</h3>
        <div class="chips" id="cfgChips">…</div>
        <div class="tresult" id="tresult" style="margin-top:14px"></div>
        <button class="btn bp" onclick="runTest()">Test connection</button>
      </div>
      <div class="cfgsec">
        <h3>Plex setup</h3>
        <div class="checklist">
          <div>1. Add library folders in Plex:<br>
            <code>/library/Movies</code>&nbsp;&nbsp;<code>/library/Movies4K</code>&nbsp;&nbsp;<code>/library/Series</code>&nbsp;&nbsp;<code>/library/Series4K</code>
          </div>
          <div>2. Plex → Settings → Webhooks → Add:<br>
            <code id="wurl">http://&lt;host&gt;:8001/webhook/plex</code>
          </div>
          <div>3. AIOStreams debrid credentials must return direct stream <code>url</code> fields.</div>
        </div>
      </div>
    </div>

    <!-- ── FUSE ─────────────────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-fuse">
      <div class="cfgsec">
        <h3>Active file TTL</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          After a stub resolves to a real stream, it stays active so re-watching
          seeks instantly without re-resolving. Set a TTL to automatically
          revert resolved files back to lightweight stubs after a period of
          inactivity — useful for reclaiming debrid sessions / CDN links you're
          no longer watching. 0 disables this (stays active indefinitely).
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <input type="number" id="ttlInput" min="0" step="0.5" placeholder="0"
                 style="width:100px;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          <span style="color:var(--mut);font-size:13px">days</span>
          <button class="btn bp" onclick="saveTtl()">Save</button>
          <span id="ttlSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
      </div>
      <div class="cfgsec">
        <h3>Prewarm new releases</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          A stub normally stays a lightweight placeholder until Plex
          actually tries to play it, which is when the real resolve
          happens. For something you just added — a new episode
          auto-discovered minutes after it aired, a movie you just
          requested — there's a good chance it's about to be watched
          soon, so the first playback shouldn't also be the moment it
          waits on AIOStreams. This resolves every placeholder stub
          CREATED within the window below to a real stream right now,
          the same way playing it normally would. Based on when the stub
          was added to your library, not the content's actual release
          date — a large migration adding years of back catalog all at
          once will make all of it look "new" here too, since every stub
          it creates gets a fresh created_at regardless of how old the
          content is.
        </div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap">
          <span style="color:var(--mut);font-size:13px">Added within the last</span>
          <input type="number" id="prewarmDaysInput" min="0" step="1" placeholder="3"
                 style="width:80px;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          <span style="color:var(--mut);font-size:13px">days</span>
        </div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap">
          <span style="color:var(--mut);font-size:13px">Run automatically every</span>
          <input type="number" id="prewarmIntervalInput" min="0" step="0.5" placeholder="1"
                 style="width:80px;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          <span style="color:var(--mut);font-size:13px">hours (0 = off, manual button only)</span>
        </div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
          <button class="btn bg2" onclick="savePrewarmSettings()" style="padding:6px 14px;font-size:12px">Save</button>
          <span id="prewarmDaysSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
        <button class="btn bp" onclick="runPrewarmNewReleases()">Prewarm new releases now</button>
      </div>
      <div class="cfgsec">
        <h3>FUSE tuning</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          These control the virtual filesystem's read/cache/prefetch behaviour.
          They're set via environment variables in <code>docker-compose.yml</code>
          and require a container restart to change — shown here read-only for
          reference.
        </div>
        <div class="chips" id="fuseChips">…</div>
      </div>
    </div>

    <!-- ── Streams ──────────────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-streams">
      <div class="cfgsec">
        <h3>Stream preferences</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          Applied on top of whatever AIOStreams itself returns (your AIOStreams
          instance's own filters/sort order, configured at <code>/stremio/configure</code>,
          still run first). These preferences re-rank and filter the results
          aiogateway picks from — they don't replace your AIOStreams config.
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Preferred language</div>
            <input type="text" id="prefLanguage" placeholder="e.g. English"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Preferred audio (comma-separated)</div>
            <input type="text" id="prefAudio" placeholder="e.g. Atmos, TrueHD"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer" onclick="document.getElementById('reqSubs').click()">
          <input type="checkbox" id="reqSubs" style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Prefer streams with subtitles available</span>
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer" onclick="document.getElementById('preferPacks').click()">
          <input type="checkbox" id="preferPacks" checked style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Prefer season/series packs over individual episode files</span>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Min size (GB, 0 = no limit)</div>
            <input type="number" id="minSizeGb" min="0" step="0.5" placeholder="0"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Max size (GB, 0 = no limit)</div>
            <input type="number" id="maxSizeGb" min="0" step="0.5" placeholder="0"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>

        <div style="margin-bottom:20px">
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Exclude words (comma-separated)</div>
          <input type="text" id="excludeWords" placeholder="e.g. CAM, TS, TELESYNC, HDCAM"
                 style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          <div style="color:var(--mut);font-size:12px;margin-top:6px">
            Streams whose filename or quality tag matches any of these are hard-excluded —
            never picked, and never counted as an available stream. Matched as a whole
            word, case-insensitive.
          </div>
        </div>

        <div style="margin-bottom:20px;max-width:260px">
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Minimum 4K sources to create a 4K stub</div>
          <input type="number" id="min4kCandidates" min="1" step="1" placeholder="6"
                 style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          <div style="color:var(--mut);font-size:12px;margin-top:6px">
            A single 4K source tends to be a rare/uncached torrent that's more
            likely to fail than a title with several to fall back on — below
            this many 4K sources found, no 4K stub is created (HD still is).
            Set to 1 to create a 4K stub whenever any 4K source exists at all.
          </div>
        </div>

        <button class="btn bp" onclick="saveStreamPrefs()">Save</button>
        <span id="streamPrefsSaved" style="color:var(--grn);font-size:13px;display:none;margin-left:10px">Saved</span>
      </div>
      <div class="cfgsec">
        <h3>Auto new-episode discovery</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          Periodically checks every series already in your library for
          newly-aired episodes and stubs them automatically (HD always,
          plus 4K if a stream is available) — no manual rescan needed.
          Episodes that have aired but have no stream yet are retried on
          every check until one shows up or the retry window below passes.
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer" onclick="document.getElementById('autoEpEnabled').click()">
          <input type="checkbox" id="autoEpEnabled" checked style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Automatically discover and stub new episodes</span>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Check every (minutes)</div>
            <input type="number" id="autoEpInterval" min="5" step="5" placeholder="10"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Give up retrying after (days)</div>
            <input type="number" id="autoEpRetryDays" min="0" step="0.5" placeholder="3"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:10px">
          <button class="btn bp" onclick="saveAutoEpisodes()">Save</button>
          <button class="btn" onclick="runAutoEpisodeSweepNow()">Check now</button>
          <span id="autoEpSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
        <div id="autoEpSweepResult" style="margin-top:12px;font-size:13px"></div>
      </div>
      <div class="cfgsec">
        <h3>Pending movies</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          When you add a movie that isn't resolvable yet — most commonly
          because it hasn't released, sometimes just because nothing's
          cached at your debrid backend yet — it's tracked here instead of
          the add just failing, and retried automatically on the same
          schedule as the episode check above until a stream shows up.
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer" onclick="document.getElementById('pendingMvEnabled').click()">
          <input type="checkbox" id="pendingMvEnabled" checked style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Automatically retry movies that aren't available yet</span>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;max-width:460px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Give up retrying after (days)</div>
            <input type="number" id="pendingMvRetryDays" min="0" step="1" placeholder="30"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Digital delay after theatrical (days)</div>
            <input type="number" id="digitalDelayDays" min="0" step="1" placeholder="21"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>
        <div style="color:var(--mut);font-size:12px;margin:-10px 0 20px;line-height:1.5">
          Don't search a movie at all until this many days after its theatrical
          release date. Cinemeta only has the theatrical date, not the actual
          digital/VOD date — this is a heuristic to reduce the odds of catching
          a pre-digital cam/TS leak, not an exact check. Set to 0 to search as
          soon as theatrical release has passed (the old behavior).
        </div>

        <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px">
          <button class="btn bp" onclick="savePendingMovies()">Save</button>
          <button class="btn" onclick="runPendingMoviesSweepNow()">Check now</button>
          <span id="pendingMvSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
        <div id="pendingMvSweepResult" style="font-size:13px;margin-bottom:16px"></div>

        <div id="pendingMvList" style="display:flex;flex-direction:column;gap:8px"></div>
      </div>
      <div class="cfgsec">
        <h3>4K unavailable</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          Titles and episodes spot check has confirmed 4K genuinely isn't
          available for — no candidates found, or every candidate that
          did show up turned out to be dead. Every automatic path (normal
          adds, the background scan, auto-episode discovery, future spot
          checks) skips 4K for these from now on, so they don't get
          re-attempted forever. The only way to check again is a manual
          "Scan 4K" (from the Library or series detail modal) — which
          clears the mark automatically if it finds something — or
          removing the mark here to let the next automatic pass try again.
        </div>
        <div id="qualityUnavailList" style="display:flex;flex-direction:column;gap:8px"></div>
      </div>
      <div class="cfgsec">
        <h3>Dead stub cleanup</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          When a stub fails to resolve a stream this many times in a row, it's
          treated as permanently dead — its placeholder file is deleted and
          Plex is told to rescan, so it disappears from your library instead
          of sitting there as a file that looks available but can never
          actually play. Set to 0 to disable cleanup (a dead stub just stays
          flagged with an error and keeps showing up in Plex).
        </div>
        <div style="max-width:260px;margin-bottom:20px">
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Remove after this many failures in a row</div>
          <input type="number" id="deadStubMaxErrors" min="0" step="1" placeholder="3"
                 style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <button class="btn bp" onclick="saveDeadStubCleanup()">Save</button>
          <span id="deadStubSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
      </div>
      <div class="cfgsec">
        <h3>AIOStreams request pacing</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          Every query to AIOStreams — from playback, background episode
          scans, auto-discovery, and migration — goes through a single
          shared throttle, so no combination of background activity can
          burst past these limits, no matter how many things are running
          at once. AIOStreams fans each query out to every addon you have
          configured, so even a modest rate here can still burst higher at
          the addon level — if you're still seeing frequent 429s, lower
          concurrency and/or raise the minimum gap. The gap applies
          immediately; concurrency needs a restart to take effect.
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;max-width:460px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Requests in flight at once</div>
            <input type="number" id="aioMaxConcurrent" min="1" step="1" placeholder="1"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Minimum gap between requests (ms)</div>
            <input type="number" id="aioMinInterval" min="0" step="100" placeholder="1500"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <button class="btn bp" onclick="saveAioPacing()">Save</button>
          <span id="aioPacingSaved" style="color:var(--grn);font-size:13px;display:none">Saved (restart needed for concurrency changes)</span>
        </div>
      </div>
      <div class="cfgsec">
        <h3>Spot check</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          On-demand audit of your whole library — checks every tracked
          series for aired episodes with no stub within seasons you've
          actually requested (a season you never asked for isn't flagged
          just because it exists), and every pending movie whose release
          date has already passed but still hasn't resolved, then
          automatically searches for and adds anything it finds missing.
          Runs through the same AIOStreams pacing as everything else, so
          a check that finds a lot of gaps can take a while — the summary
          at the end shows what was found and what still couldn't be,
          right now, for either reason.
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;cursor:pointer" onclick="document.getElementById('spotVerifyQuality').click()">
          <input type="checkbox" id="spotVerifyQuality" checked style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Also verify existing stubs are the quality they claim to be</span>
        </div>
        <div style="color:var(--mut);font-size:12px;margin:-10px 0 16px;line-height:1.5">
          Checks each resolved stream's URL for a resolution marker that
          directly contradicts its labeled quality (e.g. labeled 4K but
          clearly 1080p) — if found, removes that stub and re-searches for
          a genuinely correct one at the right quality. Unlike everything
          else spot check does, this can remove an existing, working
          stub, so it's conservative: a stream whose URL has no
          identifiable resolution marker is left alone rather than
          guessed at.
        </div>

        <div class="cal-chips" id="spotScopeChips" style="margin-bottom:16px"></div>
        <button class="btn bp" onclick="runSpotCheck()">Run spot check</button>

        <div style="border-top:1px solid var(--bor);margin:22px 0 18px"></div>

        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:12px">Run automatically</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:16px;max-width:460px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Every how many hours (0 = off)</div>
            <input type="number" id="spotIntervalHours" min="0" step="1" placeholder="0"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Scheduled scope</div>
            <select id="spotScheduledScope"
                    style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
              <option value="both">Movies + TV shows</option>
              <option value="movies">Movies only</option>
              <option value="series">TV shows only</option>
            </select>
          </div>
        </div>
        <div style="color:var(--mut);font-size:12px;margin-bottom:16px;line-height:1.5">
          E.g. set to 1 for hourly, 5 for every 5 hours. Scheduled runs use
          the same check-then-fix behavior as the manual button above, just
          on a timer instead of a click.
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <button class="btn bp" onclick="saveSpotCheckSchedule()">Save</button>
          <span id="spotScheduleSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
      </div>
    </div>

    <!-- ── Migrate ──────────────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-migrate">
      <div class="cfgsec">
        <h3>Migrate from Radarr / Sonarr</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:20px;line-height:1.5">
          Point this at an existing Radarr or Sonarr instance. It reads every
          movie (or series + season) that already has a downloaded file
          there, then searches and stubs each one through your own
          AIOStreams connection — nothing is copied or changed on the
          Radarr/Sonarr side.
        </div>

        <div style="max-width:340px;margin-bottom:16px">
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Service</div>
          <select id="migSvc" onchange="migSvcChanged()"
            style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
            <option value="radarr">Radarr (movies)</option>
            <option value="sonarr">Sonarr (series)</option>
          </select>
        </div>

        <div style="display:grid;grid-template-columns:2fr 1fr;gap:16px;max-width:600px;margin-bottom:16px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">URL</div>
            <input type="text" id="migUrl" placeholder="http://192.168.1.x:7878"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px" id="migKeyLabel">API key</div>
            <input type="password" id="migKey" placeholder="API key"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <button class="btn bp" onclick="migSaveAndTest()">Save &amp; test connection</button>
          <button class="btn" onclick="migLoadPreview()">Load library</button>
        </div>
        <div class="tresult" id="migTestResult" style="margin-top:12px"></div>

        <div id="migPreviewWrap" style="display:none;margin-top:22px">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
            <div style="font-size:13px;color:var(--mut)" id="migPreviewSummary"></div>
            <div style="display:flex;gap:16px;font-size:12px">
              <a href="#" onclick="migSelectAll(true);return false" style="color:var(--acc2);text-decoration:none">Select all</a>
              <a href="#" onclick="migSelectAll(false);return false" style="color:var(--acc2);text-decoration:none">Select none</a>
            </div>
          </div>
          <div id="migList" style="display:flex;flex-direction:column;gap:8px;max-height:380px;overflow-y:auto;padding-right:4px"></div>
          <div style="margin-top:18px">
            <button class="btn bp" onclick="migStart()">Start migration</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ── Backup/Restore ───────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-backup">
      <div class="cfgsec">
        <h3>Backup &amp; restore</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          Download a backup of your settings and library (every added movie/
          series, including which seasons and quality tiers — not the actual
          streams, which always re-resolve fresh on next play). Restoring
          merges into your current library by default; check "Replace" to
          wipe the current library first.
        </div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <button class="btn bp" onclick="downloadBackup()">Download backup</button>
          <button class="btn" onclick="document.getElementById('restoreFile').click()">Restore from file…</button>
          <input type="file" id="restoreFile" accept="application/json" style="display:none" onchange="restoreFromFile(event)">
          <label style="display:flex;align-items:center;gap:6px;color:var(--mut);font-size:13px;cursor:pointer">
            <input type="checkbox" id="restoreReplace" style="cursor:pointer">
            Replace (wipe current library first)
          </label>
        </div>
        <div id="restoreResult" style="margin-top:12px;font-size:13px"></div>
      </div>
    </div>

  </div>
</div>

<!-- MODAL -->
<div class="mbg" id="modal" onclick="bgClose(event)">
  <div class="modal">
    <div class="mhero" id="mhero" style="position:relative">
      <div class="mhero-ov"></div>
      <button class="mclose" onclick="closeModal()">✕</button>
    </div>
    <div class="mbody">
      <div class="mtitle" id="mtitle"></div>
      <div class="mmeta" id="mmeta"></div>
      <div class="mpills" id="mpills"></div>
      <div class="moverview" id="moverview"></div>
      <!-- Season picker — shown for series only -->
      <div id="seasonPickerWrap" style="display:none;margin-bottom:14px">
        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:8px">Season</div>
        <div class="season-picker" id="seasonPicker"></div>
      </div>
      <div class="macts">
        <button class="mbtn mbtn-add" id="maddBtn" onclick="modalAdd()">Add to Plex</button>
        <button class="mbtn mbtn-close" onclick="closeModal()">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- MIGRATE PROGRESS MODAL -->
<div class="mbg" id="migModal">
  <div class="modal" style="max-width:420px">
    <div class="mbody" style="padding:26px 26px 22px">
      <div class="mtitle" style="font-size:18px;margin-bottom:4px" id="migModalTitle">Migrating…</div>
      <div style="color:var(--mut);font-size:13px;margin-bottom:20px;min-height:16px" id="migModalCurrent"></div>
      <div style="background:var(--card2);border-radius:8px;height:10px;overflow:hidden;margin-bottom:10px">
        <div id="migBar" style="height:100%;width:0%;background:var(--acc);border-radius:8px;transition:width 300ms"></div>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--mut);margin-bottom:16px">
        <span id="migCount">0 / 0</span>
        <span id="migStatusLabel">Starting…</span>
      </div>
      <div id="migErrors" style="max-height:120px;overflow-y:auto;font-size:12px;color:var(--red);display:flex;flex-direction:column;gap:4px;margin-bottom:6px"></div>
      <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:14px">
        <button class="btn bg2" id="migCancelBtn" onclick="migCancel()">Cancel</button>
        <button class="btn bp" id="migCloseBtn" onclick="migCloseModal()" style="display:none">Done</button>
      </div>
    </div>
  </div>
</div>

<!-- SPOT CHECK MODAL -->
<div class="mbg" id="spotCheckModal">
  <div class="modal" style="max-width:560px">
    <div class="mbody" style="padding:26px 26px 22px">
      <div class="mtitle" style="font-size:18px;margin-bottom:4px" id="spotModalTitle">Spot checking…</div>
      <div style="color:var(--mut);font-size:13px;margin-bottom:20px;min-height:16px" id="spotModalCurrent"></div>
      <div id="spotProgressWrap">
        <div style="background:var(--card2);border-radius:8px;height:10px;overflow:hidden;margin-bottom:10px">
          <div id="spotBar" style="height:100%;width:0%;background:var(--acc);border-radius:8px;transition:width 300ms"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--mut);margin-bottom:16px">
          <span id="spotCount">0 / 0</span>
          <span id="spotStatusLabel">Starting…</span>
        </div>
      </div>
      <div id="spotResults" style="display:none;max-height:360px;overflow-y:auto;margin-bottom:6px"></div>
      <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:14px">
        <button class="btn bg2" id="spotCancelBtn" onclick="spotCancel()">Cancel</button>
        <button class="btn bp" id="spotCloseBtn" onclick="spotCloseModal()" style="display:none">Done</button>
      </div>
    </div>
  </div>
</div>

<!-- PREWARM NEW RELEASES MODAL -->
<div class="mbg" id="prewarmModal">
  <div class="modal" style="max-width:560px">
    <div class="mbody" style="padding:26px 26px 22px">
      <div class="mtitle" style="font-size:18px;margin-bottom:4px" id="prewarmModalTitle">Prewarming new releases…</div>
      <div style="color:var(--mut);font-size:13px;margin-bottom:20px;min-height:16px" id="prewarmModalCurrent"></div>
      <div id="prewarmProgressWrap">
        <div style="background:var(--card2);border-radius:8px;height:10px;overflow:hidden;margin-bottom:10px">
          <div id="prewarmBar" style="height:100%;width:0%;background:var(--acc);border-radius:8px;transition:width 300ms"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--mut);margin-bottom:16px">
          <span id="prewarmCount">0 / 0</span>
          <span id="prewarmStatusLabel">Starting…</span>
        </div>
      </div>
      <div id="prewarmResults" style="display:none;max-height:360px;overflow-y:auto;margin-bottom:6px"></div>
      <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:14px">
        <button class="btn bg2" id="prewarmCancelBtn" onclick="prewarmCancel()">Cancel</button>
        <button class="btn bp" id="prewarmCloseBtn" onclick="prewarmCloseModal()" style="display:none">Done</button>
      </div>
    </div>
  </div>
</div>

<script>
// ── State ──────────────────────────────────────────────────────
let heroItems = [], heroIdx = 0, heroTimer = null;
let stubs = [], allStubs = [], libImdb = new Set();
let libQuery = '';
let libStateFilter = 'all';   // all | active | placeholder
let libMoviePage = 1, libSeriesPage = 1;
let libMovieViewAll = false, libSeriesViewAll = false;
const LIB_PAGE_SIZE = 24;
const LIB_FILTERS = [
  { id: 'all',         label: 'All' },
  { id: 'active',      label: 'Active' },
  { id: 'placeholder', label: 'Placeholder' },
];
let modalItem = null;
const C = '/api/cinemeta';

// ── Nav ────────────────────────────────────────────────────────
function nav(page, el) {
  ['Home','Search','Calendar','Library','Config'].forEach(p => {
    document.getElementById('p'+p).style.display = 'none';
  });
  document.querySelectorAll('.ni').forEach(n => n.classList.remove('on'));
  document.getElementById('p'+page.charAt(0).toUpperCase()+page.slice(1)).style.display = '';
  el.classList.add('on');
  if (page === 'search')   { document.getElementById('srchInput').focus(); }
  if (page === 'library')  loadLib();
  if (page === 'config')   loadCfg();
  if (page === 'calendar') loadCalendar();
}

// ── Cinemeta fetch ─────────────────────────────────────────────
async function cmFetch(path) {
  const r = await fetch(`${C}/${path}`);
  if (!r.ok) throw new Error(`Cinemeta ${r.status}: ${path}`);
  return r.json();
}

// ── Hero ───────────────────────────────────────────────────────
async function loadHero() {
  const data = await cmFetch('catalog/movie/top.json');
  const items = (data.metas || []).filter(m => m.background || m.poster).slice(0, 9);
  if (!items.length) return;
  heroItems = items;
  buildDots();
  setHero(0);
  heroTimer = setInterval(() => setHero((heroIdx+1) % heroItems.length), 7000);
}

function buildDots() {
  document.getElementById('heroDots').innerHTML =
    heroItems.map((_,i) => `<div class="hero-dot${i===0?' on':''}" onclick="setHero(${i})"></div>`).join('');
}

function setHero(i) {
  heroIdx = i;
  const m = heroItems[i];
  if (!m) return;

  // Backdrop
  const bg = m.background || m.poster || '';
  document.getElementById('heroBg').style.backgroundImage = bg ? `url(${bg})` : 'none';

  // Logo
  const logoEl = document.getElementById('heroLogo');
  if (m.logo) {
    logoEl.src = m.logo;
    logoEl.style.display = 'block';
    document.getElementById('heroTitle').style.display = 'none';
  } else {
    logoEl.style.display = 'none';
    document.getElementById('heroTitle').style.display = 'block';
    document.getElementById('heroTitle').textContent = m.name || '';
  }

  // Meta
  const year = m.releaseInfo ? m.releaseInfo.split('–')[0] : '';
  const rating = m.imdbRating ? `${m.imdbRating}` : '';
  const genres = (m.genres || []).slice(0,2).join(' · ');
  const metaParts = [year, genres].filter(Boolean);
  document.getElementById('heroMeta').innerHTML =
    metaParts.map(p=>`<span>${p}</span>`).join('<span class="hero-sep">•</span>') +
    (rating ? `<span class="hero-sep">•</span><span class="hero-rating">${rating}</span>` : '');

  document.getElementById('heroDesc').textContent = m.description || '';

  // Dots
  document.querySelectorAll('.hero-dot').forEach((d,j) => d.classList.toggle('on', j===i));

  // Add button state
  const btn = document.getElementById('heroBtn');
  const inLib = libImdb.has(m.id);
  btn.textContent = inLib ? 'In Library' : 'Add to Plex';
  btn.className = 'btn-hero btn-add' + (inLib ? ' added' : '');
}

function heroAdd()  { if (heroItems[heroIdx]) openModal(heroItems[heroIdx], 'movie'); }
function heroInfo() { if (heroItems[heroIdx]) openModal(heroItems[heroIdx], 'movie'); }

// ── Item store — avoids embedding raw JSON in onclick attrs ───
const _items = {};
function _store(m, type) { _items[m.id] = { m, type }; }
function _click(id) { const e = _items[id]; if (e) openModal(e.m, e.type); }

// ── Card rows ──────────────────────────────────────────────────
function card(m, type) {
  _store(m, type);
  const inLib = libImdb.has(m.id);
  const year = (m.releaseInfo || '').split(/[-–]/)[0].trim();
  const rating = m.imdbRating || '';
  const name = (m.name || '').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const sid = CSS.escape(m.id);
  return `<div class="card${inLib?' inlib':''}" id="c${sid}" onclick="_click('${m.id.replace(/'/g,"\\'")}')">
    <div class="cposter">
      ${m.poster ? `<img src="${m.poster}" loading="lazy" onload="this.classList.add('loaded')" onerror="this.parentNode.style.background='#1a1a28'"/>` : ''}
      ${rating ? `<div class="crating">${rating}</div>` : ''}
      <div class="ccheck">✓</div>
    </div>
    <div class="cname">${name}</div>
    <div class="cyear">${year}</div>
  </div>`;
}

async function loadRow(elId, path, type) {
  try {
    const data = await cmFetch(path);
    const items = (data.metas || []).slice(0, 20);
    _rowCache[path] = data.metas || [];   // cache full list for View All
    document.getElementById(elId).innerHTML = items.map(m => card(m, type)).join('');
    return items;
  } catch(e) {
    document.getElementById(elId).innerHTML = `<div style="color:var(--red);font-size:13px;padding:20px">Failed: ${e.message}</div>`;
    return [];
  }
}

// ── Modal ──────────────────────────────────────────────────────
// Selected season: null = all, number = specific season
let _selectedSeason = null;

async function openModal(item, type) {
  modalItem = { ...item, _type: type };
  _selectedSeason = null;

  // Try to get full meta if we only have preview
  if (!item.description && item.id) {
    try {
      const full = await cmFetch(`meta/${type}/${item.id}.json`);
      if (full.meta) { modalItem = { ...full.meta, _type: type }; item = modalItem; }
    } catch {}
  }

  document.getElementById('mtitle').textContent = item.name || '';
  const year = item.releaseInfo ? item.releaseInfo.split('–')[0] : '';
  const rating = item.imdbRating ? `<span class="mrating">${item.imdbRating}</span>` : '';
  document.getElementById('mmeta').innerHTML =
    `<span>${type==='series'?'Series':'Movie'}</span>` +
    (year ? `<span>•</span><span>${year}</span>` : '') +
    rating;
  document.getElementById('mpills').innerHTML = (item.genres||[]).slice(0,4).map(g=>`<span class="mpill">${g}</span>`).join('');
  document.getElementById('moverview').textContent = item.description || '';
  document.getElementById('mhero').style.backgroundImage =
    `url(${item.background || item.poster || ''})`;

  const inLib = libImdb.has(item.id);
  const btn = document.getElementById('maddBtn');
  btn.textContent = inLib ? 'In Library' : 'Add to Plex';
  btn.className = 'mbtn mbtn-add' + (inLib ? ' added' : '');
  btn.disabled = false;

  // Season picker for series
  const wrap = document.getElementById('seasonPickerWrap');
  const picker = document.getElementById('seasonPicker');
  if (type === 'series') {
    wrap.style.display = 'block';
    picker.innerHTML = '<div style="color:var(--mut);font-size:12px">Loading seasons…</div>';
    buildSeasonPicker(item.id, picker);
  } else {
    wrap.style.display = 'none';
    picker.innerHTML = '';
  }

  document.getElementById('modal').classList.add('open');
}

async function buildSeasonPicker(imdbId, picker) {
  try {
    const r = await fetch(`/api/series/${imdbId}/episodes`);
    const d = await r.json();
    const episodes = d.episodes || [];

    // Get unique aired season numbers
    const seasons = [...new Set(
      episodes.filter(e => e.aired).map(e => e.season)
    )].filter(Boolean).sort((a,b)=>a-b);

    if (!seasons.length) {
      picker.innerHTML = '<div style="color:var(--mut);font-size:12px">No aired seasons found</div>';
      return;
    }

    // A season is "requested" if at least one of its episodes already has
    // a stub (HD or 4K) — same definition used in the library's series
    // detail modal, so the two stay visually consistent.
    const requestedSeasons = new Set(
      episodes.filter(e => e.has_hd || e.has_4k).map(e => e.season)
    );

    // All button + season buttons
    const allBtn = `<button class="season-btn all-btn on" id="sbAll" onclick="selectSeason(null)">All</button>`;
    const seasonBtns = seasons.map(s => {
      const requestedCls = requestedSeasons.has(s) ? ' requested' : '';
      const title = requestedSeasons.has(s) ? ' title="Already requested"' : '';
      return `<button class="season-btn${requestedCls}" id="sb${s}" onclick="selectSeason(${s})"${title}>S${String(s).padStart(2,'0')}</button>`;
    }).join('');
    picker.innerHTML = allBtn + seasonBtns;
  } catch {
    picker.innerHTML = '<div style="color:var(--mut);font-size:12px">Could not load seasons</div>';
  }
}

function selectSeason(season) {
  _selectedSeason = season;
  // Update button styles
  document.querySelectorAll('.season-btn').forEach(b => b.classList.remove('on'));
  const target = season === null
    ? document.getElementById('sbAll')
    : document.getElementById('sb' + season);
  if (target) target.classList.add('on');
}

function closeModal() { document.getElementById('modal').classList.remove('open'); }
function bgClose(e) { if (e.target === document.getElementById('modal')) closeModal(); }

async function modalAdd() {
  if (!modalItem) return;
  const btn = document.getElementById('maddBtn');
  const imdbId = modalItem.id;

  if (!imdbId || !imdbId.startsWith('tt')) {
    toast('No IMDb ID for this title', 'er'); return;
  }
  if (libImdb.has(imdbId)) { toast('Already in library', 'in'); return; }

  btn.textContent = 'Loading streams…';
  btn.disabled = true;

  const title = modalItem.name || '';
  const year  = parseInt((modalItem.releaseInfo||'').slice(0,4)) || null;
  const type  = modalItem._type === 'series' ? 'series' : 'movie';

  try {
    const poster = modalItem.poster || '';
    const body = { imdb_id:imdbId, title, year, media_type:type, poster };
    if (type === 'series' && _selectedSeason !== null) {
      body.season = _selectedSeason;
    }
    const r = await fetch('/api/add', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify(body),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || JSON.stringify(d));

    if (type === 'movie' && d.pending) {
      // Not resolvable yet (commonly not released) — tracked for automatic
      // retry rather than added, so don't mark it "In Library".
      btn.textContent = 'Tracking…'; btn.className = 'mbtn mbtn-add pending'; btn.disabled = true;
      toast(`"${title}" isn't available yet — tracking it and will add automatically once it is`, 'ok');
      return;
    }

    libImdb.add(imdbId);
    btn.textContent = 'In Library'; btn.className = 'mbtn mbtn-add added'; btn.disabled = false;

    // Update hero button
    const hm = heroItems[heroIdx];
    if (hm && hm.id === imdbId) {
      const hb = document.getElementById('heroBtn');
      hb.textContent = 'In Library'; hb.className = 'btn-hero btn-add added';
    }

    // Mark card
    const c = document.getElementById('c'+modalItem.id);
    if (c) c.classList.add('inlib');

    if (type === 'series') {
      const seasonLabel = _selectedSeason !== null ? ` (Season ${_selectedSeason})` : '';
      toast(`Added "${title}"${seasonLabel} — scanning in background…`, 'ok');
      pollScan(imdbId, title);
    } else {
      toast(`Added "${title}" — ${d.streams_found} streams${d.has_4k?' (HD+4K)':''}`, 'ok');
    }
    await syncStubs();
  } catch(e) {
    btn.textContent = 'Add to Plex'; btn.disabled = false;
    // Surface the full AIOStreams diagnostic in the toast
    const msg = e.message || 'Unknown error';
    toast(msg.length > 120 ? msg.slice(0, 117) + '…' : msg, 'er');
    console.error('Add to Plex error:', e.message);
  }
}

// ── Stubs / Library ────────────────────────────────────────────
async function syncStubs() {
  try {
    const r = await fetch('/api/stubs');
    const d = await r.json();
    stubs = d.stubs || [];
    libImdb = new Set(stubs.map(s => s.media_id.split('_')[0]));
  } catch {}
}

// ── Calendar ──────────────────────────────────────────────────
let _calScheduled = {};   // {key: timeoutId} for track-and-rescan timers
let calViewYear  = new Date().getFullYear();
let calViewMonth = new Date().getMonth();   // 0-indexed
let calFilter    = 'all';
let calEntries   = [];
let calSelectedDate = null;

const CAL_FILTERS = [
  { id:'all',      label:'All' },
  { id:'episodes', label:'Episodes' },
  { id:'movies',   label:'Movies' },
  { id:'library',  label:'In library' },
  { id:'upcoming', label:'Upcoming' },
];

function calMatchesFilter(e) {
  if (calFilter === 'all')      return true;
  if (calFilter === 'episodes') return e.type === 'episode';
  if (calFilter === 'movies')   return e.type === 'movie';
  if (calFilter === 'library')  return !!e.in_library;
  if (calFilter === 'upcoming') return !e.in_library;
  return true;
}

function calChangeMonth(delta) {
  calViewMonth += delta;
  if (calViewMonth < 0)  { calViewMonth = 11; calViewYear--; }
  if (calViewMonth > 11) { calViewMonth = 0;  calViewYear++; }
  calSelectedDate = null;
  loadCalendar();
}

function _calDaysBetween(a, b) {
  return Math.round((b - a) / 86400000);
}

async function loadCalendar(force) {
  const body = document.getElementById('calBody');
  body.innerHTML = '<div style="color:var(--mut);font-size:14px;padding:40px 0">Loading…</div>';

  const today = new Date(); today.setHours(0,0,0,0);
  const gridStart = new Date(calViewYear, calViewMonth, 1);
  gridStart.setDate(gridStart.getDate() - gridStart.getDay());
  const gridEnd = new Date(calViewYear, calViewMonth + 1, 0);
  gridEnd.setDate(gridEnd.getDate() + (6 - gridEnd.getDay()));

  const daysBack  = Math.max(0, _calDaysBetween(gridStart, today));
  const daysAhead = Math.max(0, _calDaysBetween(today, gridEnd));

  try {
    const d = await (await fetch(`/api/calendar?days_back=${daysBack}&days_ahead=${daysAhead}`)).json();
    calEntries = d.entries || [];
    renderCalChips();
    renderMonthGrid();
  } catch(e) {
    body.innerHTML = `<div style="color:var(--red);font-size:13px">Failed to load calendar: ${e.message}</div>`;
  }
}

function renderCalChips() {
  const wrap = document.getElementById('calChips');
  wrap.innerHTML = CAL_FILTERS.map(f =>
    `<button class="cal-chip${calFilter===f.id?' on':''}" onclick="calSetFilter('${f.id}')">${f.label}</button>`
  ).join('');
}

function calSetFilter(id) {
  calFilter = id;
  renderCalChips();
  renderMonthGrid();
}

function renderMonthGrid() {
  const monthDate = new Date(calViewYear, calViewMonth, 1);
  document.getElementById('calMonthLabel').textContent =
    monthDate.toLocaleDateString(undefined, { month:'long', year:'numeric' });

  const today = new Date(); today.setHours(0,0,0,0);
  const todayKey = today.toISOString().slice(0,10);

  const grouped = {};
  calEntries.filter(calMatchesFilter).forEach(e => {
    (grouped[e.release_date] = grouped[e.release_date] || []).push(e);
  });

  const firstDow = monthDate.getDay();
  const daysInMonth = new Date(calViewYear, calViewMonth + 1, 0).getDate();

  let weekdays = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']
    .map(d => `<div class="cal-weekday">${d}</div>`).join('');

  let cells = '';
  for (let i = 0; i < firstDow; i++) cells += `<div class="cal-cell blank"></div>`;

  for (let d = 1; d <= daysInMonth; d++) {
    const key = `${calViewYear}-${String(calViewMonth+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const isToday = key === todayKey;
    const dayEvents = grouped[key] || [];
    const maxShow = 2;
    const pills = dayEvents.slice(0, maxShow).map(e => {
      const cls = e.type === 'movie' ? 'movie' : (e.in_library ? 'inlib' : '');
      return `<div class="cal-pill ${cls}" title="${e.title}">${e.title}</div>`;
    }).join('');
    const more = dayEvents.length > maxShow
      ? `<div class="cal-cellmore">+${dayEvents.length - maxShow} more</div>` : '';

    cells += `<div class="cal-cell${key===calSelectedDate?' selected':''}" onclick="calSelectDay('${key}')">
      <span class="cal-cellnum${isToday?' today':''}">${d}</span>
      ${pills}${more}
    </div>`;
  }

  document.getElementById('calBody').innerHTML = `
    <div class="cal-weekrow">${weekdays}</div>
    <div class="cal-grid">${cells}</div>
    <div id="calDetail"></div>
  `;

  if (calSelectedDate) renderCalDetail();
}

function calSelectDay(key) {
  calSelectedDate = key;
  renderMonthGrid();
  document.getElementById('calDetail').scrollIntoView({ behavior:'smooth', block:'nearest' });
}

function renderCalDetail() {
  const wrap = document.getElementById('calDetail');
  if (!wrap) return;
  const today = new Date(); today.setHours(0,0,0,0);
  const isPast = calSelectedDate < today.toISOString().slice(0,10);
  const dayEvents = calEntries.filter(calMatchesFilter).filter(e => e.release_date === calSelectedDate);

  const label = _calDateLabel(calSelectedDate, calSelectedDate === today.toISOString().slice(0,10));

  if (!dayEvents.length) {
    wrap.innerHTML = `<div class="cal-detail">
      <div class="cal-detail-date">${label}</div>
      <div class="cal-detail-empty">No releases this day.</div>
    </div>`;
    return;
  }

  const rows = dayEvents.map(e => _calEntryHtml(e, isPast)).join('');
  wrap.innerHTML = `<div class="cal-detail">
    <div class="cal-detail-date">${label}</div>
    <div class="cal-entries">${rows}</div>
  </div>`;
}

function _calDateLabel(dateStr, isToday) {
  const d = new Date(dateStr + 'T12:00:00');  // noon avoids DST edge cases
  const opts = { weekday:'long', month:'long', day:'numeric' };
  const fmt = d.toLocaleDateString(undefined, opts);
  return isToday ? `Today — ${fmt}` : fmt;
}

function _calEntryHtml(e, isPast) {
  const poster = e.poster
    ? `<img class="cal-poster" src="${e.poster}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
    : '';
  const posterFallback = `<div class="cal-poster-placeholder" style="${e.poster?'display:none':''}">
    ${e.type === 'movie' ? '🎬' : '📺'}
  </div>`;

  // release_ts is a precise Unix timestamp (date + time), not just a date —
  // this is also exactly what governs whether an episode is eligible for
  // auto-stubbing (_is_aired compares against this same timestamp), so
  // showing it here means what you see in the calendar is the same clock
  // the stubbing logic is actually using, not just the release date.
  const relDate = new Date(e.release_ts * 1000);
  const timeStr = relDate.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

  const sub = e.type === 'episode'
    ? `S${String(e.season).padStart(2,'0')}E${String(e.episode).padStart(2,'0')} — ${e.episode_name} · ${timeStr}`
    : `${e.type === 'movie' ? 'Movie' : 'Series'} · ${e.release_date} · ${timeStr}`;

  const badges = [];
  if (e.in_library)    badges.push('<span class="cal-badge inlib">In library</span>');
  if (e.type==='movie' && e.date_type==='theatrical') badges.push('<span class="cal-badge theatrical">Theatrical date · digital may differ</span>');

  const key = e.type === 'episode'
    ? `${e.imdb_id}:${e.season}:${e.episode}`
    : e.imdb_id;

  const rescanBtn = _calRescanBtnHtml(e, key, isPast);

  return `<div class="cal-entry${e.in_library?' inlib':''}${!isPast?' future':''}"
    onclick="_calEntryClick('${e.imdb_id}','${e.type}')">
    ${poster}${posterFallback}
    <div class="cal-info">
      <div class="cal-title">${e.title}</div>
      <div class="cal-sub">${sub}</div>
      ${badges.length ? `<div class="cal-badges">${badges.join('')}</div>` : ''}
    </div>
    ${rescanBtn}
  </div>`;
}

function _calRescanBtnHtml(e, key, isPast) {
  // Only show for content not yet in library OR for past episodes that might
  // now have streams available (scheduled rescan within 30min of release).
  const isScheduled = !!_calScheduled[key];
  const relTs = e.release_ts * 1000;
  const now = Date.now();
  const minsAgo = (now - relTs) / 60000;
  const minsUntil = (relTs - now) / 60000;

  if (minsUntil > 0 && minsUntil <= 60) {
    // Releases within the next hour — show "scan at release" button
    return `<button class="cal-rescan-btn${isScheduled?' pending':''}"
      id="crbtn_${key.replace(/[:]/g,'_')}"
      onclick="event.stopPropagation();calScheduleRescan(${JSON.stringify(e)},${JSON.stringify(key)})"
      title="Schedule a rescan 30 minutes after release">
      ${isScheduled ? '⏳ Scheduled' : '⏰ Schedule scan'}
    </button>`;
  }
  if (minsAgo >= 0 && minsAgo <= 120) {
    // Recently released (within 2 hours) — scan now (or scheduled)
    return `<button class="cal-rescan-btn${isScheduled?' pending':''}"
      id="crbtn_${key.replace(/[:]/g,'_')}"
      onclick="event.stopPropagation();calRescanNow(${JSON.stringify(e)},${JSON.stringify(key)})"
      title="Scan for this release now">
      ${isScheduled ? '⏳ Scanning…' : '🔍 Scan now'}
    </button>`;
  }
  if (!e.in_library && isPast) {
    return `<button class="cal-rescan-btn"
      onclick="event.stopPropagation();calRescanNow(${JSON.stringify(e)},${JSON.stringify(key)})"
      title="Try to find a stream for this">
      Search
    </button>`;
  }
  return '';
}

function _calEntryClick(imdbId, type) {
  // Re-use the existing modal opening logic
  if (type === 'episode') {
    const g = window._libGroups && Object.values(window._libGroups).find(g => g.imdb === imdbId);
    if (g) openSeriesDetail(Object.keys(window._libGroups).find(k => window._libGroups[k] === g));
  } else {
    // Open the discovery modal if we have the item data
    const stub = null;  // could open a Cinemeta modal here in future
  }
}

async function calScheduleRescan(entry, key) {
  const btnId = 'crbtn_' + key.replace(/:/g, '_');
  const btn = document.getElementById(btnId);
  if (btn) { btn.textContent = '⏳ Scheduled'; btn.classList.add('pending'); }

  const relTs = entry.release_ts * 1000;
  const delayMs = Math.max(0, relTs - Date.now()) + 30 * 60 * 1000;  // 30 min after release

  // Cancel any existing timer for this key
  if (_calScheduled[key]) clearTimeout(_calScheduled[key]);

  _calScheduled[key] = setTimeout(async () => {
    delete _calScheduled[key];
    await calRescanNow(entry, key);
  }, delayMs);

  const minsUntil = Math.round(delayMs / 60000);
  toast(`Will scan for "${entry.title}" in ~${minsUntil} min`, 'ok');
}

async function calRescanNow(entry, key) {
  const btnId = 'crbtn_' + key.replace(/:/g, '_');
  const btn = document.getElementById(btnId);
  if (btn) { btn.textContent = '⏳ Scanning…'; btn.classList.add('pending'); }

  try {
    if (entry.type === 'episode') {
      // Use the single-episode add endpoint
      const r = await fetch(`/api/series/${entry.imdb_id}/episode/${entry.season}/${entry.episode}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imdb_id: entry.imdb_id, title: entry.title, media_type: 'series' }),
      });
      const d = await r.json();
      if (r.ok && d.stubbed) {
        toast(`${entry.title} S${String(entry.season).padStart(2,'0')}E${String(entry.episode).padStart(2,'0')} added`, 'ok');
        if (btn) { btn.textContent = '✓ Added'; btn.classList.remove('pending'); btn.classList.add('active'); }
        setTimeout(loadCalendar, 1500);
      } else {
        throw new Error(d.detail || 'No stream found yet');
      }
    } else {
      // Movie: try adding via the main add endpoint
      const r = await fetch('/api/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imdb_id: entry.imdb_id, title: entry.title, media_type: 'movie' }),
      });
      const d = await r.json();
      if (r.ok && d.pending) {
        // Not resolvable yet (commonly not released) — tracked for
        // automatic retry, not actually added, so don't claim "Added".
        toast(`"${entry.title}" isn't available yet — tracking it for automatic retry`, 'ok');
        if (btn) { btn.textContent = 'Tracking'; btn.classList.add('pending'); }
      } else if (r.ok) {
        toast(`"${entry.title}" added to library`, 'ok');
        if (btn) { btn.textContent = '✓ Added'; btn.classList.remove('pending'); btn.classList.add('active'); }
        setTimeout(loadCalendar, 1500);
      } else {
        throw new Error(d.detail || 'No stream found');
      }
    }
  } catch(e) {
    toast(e.message || 'Scan failed', 'er');
    if (btn) { btn.textContent = 'Retry'; btn.classList.remove('pending'); }
  }
}

// ── Library ───────────────────────────────────────────────────
let libMissingCounts = {};

let libPendingMovies = [];

async function loadLib() {
  await syncStubs();
  allStubs = [...stubs];
  try {
    const d = await (await fetch('/api/pending-movies')).json();
    libPendingMovies = d.items || [];
  } catch { libPendingMovies = []; }
  renderLibChips();
  applyLibFilters();
  try {
    const d = await (await fetch('/api/library/missing-counts')).json();
    libMissingCounts = d.counts || {};
    applyLibFilters();   // re-render now that counts are in, without blocking the first paint on them
  } catch {}
}

function libSetQuery(q) {
  libQuery = q;
  libMoviePage = 1; libSeriesPage = 1;
  applyLibFilters();
}

function renderLibChips() {
  document.getElementById('libChips').innerHTML = LIB_FILTERS.map(f =>
    `<button class="cal-chip${libStateFilter === f.id ? ' on' : ''}" onclick="libSetStateFilter('${f.id}')">${f.label}</button>`
  ).join('');
}

function libSetStateFilter(id) {
  libStateFilter = id;
  libMoviePage = 1; libSeriesPage = 1;
  renderLibChips();
  applyLibFilters();
}

function libGoToPage(kind, p) {
  if (kind === 'movie') libMoviePage = p; else libSeriesPage = p;
  applyLibFilters();
  document.getElementById('libGrid').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function libToggleViewAll(kind) {
  if (kind === 'movie') { libMovieViewAll = !libMovieViewAll; libMoviePage = 1; }
  else { libSeriesViewAll = !libSeriesViewAll; libSeriesPage = 1; }
  applyLibFilters();
}

function applyLibFilters() {
  const q = libQuery;
  const textFiltered = q
    ? allStubs.filter(s => (s.title || s.media_id).toLowerCase().includes(q.toLowerCase()))
    : allStubs;
  renderLib(textFiltered);
}

// ── Library: group stubs by base IMDb ID (one card per title) ─
function groupStubs(items) {
  const map = {};
  items.forEach(s => {
    const base = s.media_id.split('_')[0];
    if (!map[base]) map[base] = {
      title: s.title || base,
      imdb: base,
      poster: s.poster || '',
      media_type: s.media_type || 'movie',
      year: s.year || null,
      stubs: []
    };
    if (s.poster && !map[base].poster) map[base].poster = s.poster;
    if (s.year && !map[base].year) map[base].year = s.year;
    map[base].stubs.push(s);
  });
  return Object.values(map);
}

function libGroupCard(g) {
  if (g.pending) {
    const safeId = g.imdb.replace(/[^a-z0-9]/gi,'');
    const posterHtml = g.poster
      ? `<img src="${g.poster}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:10px;opacity:0;transition:opacity .3s" onload="this.style.opacity=1" onerror="this.style.display='none'"/>`
      : '';
    return `<div style="cursor:pointer" onclick="openPendingMovieModal('${safeId}')">
      <div class="cposter" style="position:relative;opacity:.75">
        ${posterHtml}
        <div style="position:absolute;bottom:0;left:0;right:0;background:rgba(74,158,255,.9);color:#04111f;font-size:10px;font-weight:700;text-align:center;padding:4px 2px;border-radius:0 0 10px 10px">TRACKING</div>
      </div>
      <div class="cname" style="margin-top:8px">${g.title}</div>
      <span class="stub-state" style="color:var(--blue);border-color:var(--blue)">pending</span>
    </div>`;
  }

  const has4k = g.stubs.some(s => s.quality === '4k');
  const hasHd = g.stubs.some(s => s.quality === 'hd');
  const state = _groupState(g);
  const sc = {placeholder:'ss-ph',active:'ss-ac',error:'ss-er',resolving:'ss-rs'}[state]||'ss-ph';
  const safeId = g.imdb.replace(/[^a-z0-9]/gi,'');
  const badges = [
    hasHd ? `<span style="background:rgba(0,0,0,.88);color:var(--blue);border-radius:5px;padding:2px 7px;font-size:10px;font-weight:700;display:block">HD</span>` : '',
    has4k ? `<span style="background:rgba(0,0,0,.88);color:var(--acc2);border-radius:5px;padding:2px 7px;font-size:10px;font-weight:700;display:block">4K</span>` : ''
  ].filter(Boolean).join('');
  const posterHtml = g.poster
    ? `<img src="${g.poster}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:10px;opacity:0;transition:opacity .3s" onload="this.style.opacity=1" onerror="this.style.display='none'"/>`
    : '';
  const cardClick = g.media_type === 'series'
    ? `openSeriesDetail('${safeId}')`
    : `openDelModal('${safeId}')`;
  // Missing count comes from /api/library/missing-counts, fetched once
  // when the library loads (see loadLib) — scoped server-side to
  // requested seasons only, same definition spot check uses, so a season
  // you never requested never shows up here just because Cinemeta lists it.
  const missingCount = g.media_type === 'series' ? (libMissingCounts[g.imdb] || 0) : 0;
  const missingBar = missingCount > 0
    ? `<div style="position:absolute;bottom:0;left:0;right:0;background:rgba(163,45,45,.9);color:#fff;font-size:10px;font-weight:700;text-align:center;padding:4px 2px;border-radius:0 0 10px 10px">${missingCount} EP${missingCount === 1 ? '' : 'S'} MISSING</div>`
    : '';
  return `<div style="cursor:pointer" onclick="${cardClick}">
    <div class="cposter" style="position:relative">
      ${posterHtml}
      <div style="position:absolute;top:8px;right:8px;display:flex;flex-direction:column;gap:4px;align-items:flex-end">${badges}</div>
      <button class="del-btn" style="position:absolute;top:8px;left:8px" onclick="event.stopPropagation();openDelModal('${safeId}')" title="Remove">✕</button>
      ${missingBar}
    </div>
    <div class="cname" style="margin-top:8px">${g.title}</div>
    <span class="stub-state ${sc}">${state}</span>
  </div>`;
}

function _groupState(g) {
  const states = g.stubs.map(s => s.state);
  return states.includes('error') ? 'error'
       : states.includes('resolving') ? 'resolving'
       : states.includes('active') ? 'active' : 'placeholder';
}

// Used for the Active/Placeholder filter chips — deliberately different
// from _groupState() above. _groupState collapses a whole title down to
// one "worst state wins" summary for the card badge, which is right for
// a badge but wrong for filtering: a 20-episode show with 19 placeholder
// episodes and 1 already-played one would summarize as "active" and
// disappear entirely from the Placeholder filter. Filtering instead asks
// "does this title have ANY stub in the state I'm looking for" — so a
// mostly-placeholder show still shows up under Placeholder even if one
// episode happens to be active.
function _groupHasState(g, state) {
  return g.stubs.some(s => s.state === state);
}

function renderLib(items) {
  const el = document.getElementById('libGrid');
  el.style.display = 'block';
  if (!items.length && !libPendingMovies.length) {
    el.innerHTML = `<div style="color:var(--mut);font-size:14px;padding:40px 0">
      No stubs yet. Browse Home or Search and click Add to Plex.
    </div>`;
    return;
  }

  let groups = groupStubs(items);

  // Pending movies never have a stub, so groupStubs() never sees them —
  // add a synthetic group per pending movie so they show up in the
  // Movies section as "Tracking" cards instead of only being visible on
  // the Config page. stubs stays empty on these; libGroupCard checks for
  // that (via .pending) to render them distinctly.
  const q = libQuery.toLowerCase();
  for (const p of libPendingMovies) {
    if (q && !(p.title || '').toLowerCase().includes(q)) continue;
    groups.push({
      title: p.title, imdb: p.imdb_id, poster: p.poster || '',
      media_type: 'movie', year: p.year || null,
      stubs: [], pending: true, added_at: p.added_at,
    });
  }

  if (libStateFilter !== 'all') {
    // Pending isn't "active" or "placeholder" — only show it under "All".
    groups = groups.filter(g => !g.pending && _groupHasState(g, libStateFilter));
  }

  if (!groups.length) {
    el.innerHTML = `<div style="color:var(--mut);font-size:14px;padding:40px 0">
      Nothing matches this filter.
    </div>`;
    return;
  }

  groups.sort((a, b) => (a.title || '').localeCompare(b.title || ''));

  window._libGroups = {};
  groups.forEach(g => { window._libGroups[g.imdb.replace(/[^a-z0-9]/gi,'')] = g; });

  const movies = groups.filter(g => g.media_type !== 'series');
  const series = groups.filter(g => g.media_type === 'series');

  const html =
    renderLibSection('movie',  'Movies',   movies) +
    renderLibSection('series', 'TV Shows', series);

  el.innerHTML = html;
}

// Each section (Movies / TV Shows) paginates independently, with its own
// "View all" toggle to drop pagination and show every title in that
// section at once.
function renderLibSection(kind, label, groupsForSection) {
  if (!groupsForSection.length) return '';

  const viewAll = kind === 'movie' ? libMovieViewAll : libSeriesViewAll;
  const totalPages = Math.max(1, Math.ceil(groupsForSection.length / LIB_PAGE_SIZE));

  if (kind === 'movie') { if (libMoviePage > totalPages) libMoviePage = totalPages; }
  else { if (libSeriesPage > totalPages) libSeriesPage = totalPages; }
  const page = kind === 'movie' ? libMoviePage : libSeriesPage;

  const pageItems = viewAll
    ? groupsForSection
    : groupsForSection.slice((page - 1) * LIB_PAGE_SIZE, page * LIB_PAGE_SIZE);

  const showPagination = !viewAll && totalPages > 1;
  const viewAllLabel = viewAll ? 'Show paginated' : 'View all';

  return `<div style="margin-bottom:36px">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;gap:12px;flex-wrap:wrap">
      <div class="sec-title">${label} <span style="color:var(--mut);font-weight:400;font-size:13px">(${groupsForSection.length})</span></div>
      <button class="btn bg2" style="padding:5px 14px;font-size:12px" onclick="libToggleViewAll('${kind}')">${viewAllLabel}</button>
    </div>
    <div class="libgrid">${pageItems.map(libGroupCard).join('')}</div>
    ${showPagination ? renderLibPaginationHtml(kind, page, totalPages, groupsForSection.length) : ''}
  </div>`;
}

function renderLibPaginationHtml(kind, page, totalPages, totalCount) {
  const pageBtn = (label, p, disabled) =>
    `<button class="cal-navbtn" style="width:auto;min-width:32px;padding:0 10px" ${disabled ? 'disabled' : ''} onclick="libGoToPage('${kind}', ${p})">${label}</button>`;
  const numBtn = (p) =>
    `<button class="cal-navbtn" style="width:32px;padding:0;${p === page ? 'background:var(--acc);color:#000;border-color:var(--acc)' : ''}" onclick="libGoToPage('${kind}', ${p})">${p}</button>`;

  // Windowed page numbers: first, last, current ±1, "…" for gaps.
  const pages = [];
  for (let p = 1; p <= totalPages; p++) {
    if (p === 1 || p === totalPages || Math.abs(p - page) <= 1) {
      pages.push(p);
    } else if (pages[pages.length - 1] !== '…') {
      pages.push('…');
    }
  }

  let html = `<div style="display:flex;align-items:center;justify-content:center;gap:8px;margin-top:20px;flex-wrap:wrap">`;
  html += pageBtn('‹ Prev', page - 1, page === 1);
  html += pages.map(p => p === '…'
    ? `<span style="color:var(--mut);font-size:13px;padding:0 4px">…</span>`
    : numBtn(p)
  ).join('');
  html += pageBtn('Next ›', page + 1, page === totalPages);
  html += `<span style="color:var(--mut);font-size:12px;margin-left:10px">${totalCount} title${totalCount === 1 ? '' : 's'}</span>`;
  html += `</div>`;
  return html;
}


// ── Series detail modal ────────────────────────────────────────
const _bg_scans_ui = new Set();

async function openSeriesDetail(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;

  // Show loading immediately
  const dlg = document.createElement('div');
  dlg.id = 'seriesDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.82);backdrop-filter:blur(16px);z-index:300;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `<div style="color:var(--mut);font-size:14px">Loading…</div>`;
  dlg.addEventListener('click', e => { if (e.target===dlg) dlg.remove(); });
  document.body.appendChild(dlg);

  let epData;
  try {
    const r = await fetch(`/api/series/${g.imdb}/episodes`);
    epData = await r.json();
  } catch(e) {
    dlg.querySelector('div').innerHTML = '<span style="color:var(--red)">Failed to load</span>';
    return;
  }

  const episodes   = epData.episodes || [];
  const isScanning = _bg_scans_ui.has(g.imdb) || epData.scanning;

  // Group ALL episodes by season — including seasons with zero stubs
  // ("not yet requested") and unaired ones, not just aired+stubbed ones.
  const seasonMap = {};
  episodes.forEach(ep => {
    seasonMap[ep.season] = seasonMap[ep.season] || [];
    seasonMap[ep.season].push(ep);
  });
  const seasons = Object.keys(seasonMap).map(Number).sort((a,b)=>a-b);

  // A season is "requested" if at least one of its episodes has a stub
  // (HD or 4K) — distinct from "fully downloaded", since a requested
  // season can still have missing episodes.
  const seasonRequested = {};
  seasons.forEach(sn => {
    seasonRequested[sn] = seasonMap[sn].some(e => e.has_hd || e.has_4k);
  });
  const unrequestedSeasons = seasons.filter(sn => !seasonRequested[sn]);

  const totalAired   = episodes.filter(e=>e.aired).length;
  const totalStubbed = episodes.filter(e=>e.aired && e.has_hd).length;
  const totalMissing = totalAired - totalStubbed;

  // Keep the library card's "N eps missing" banner in sync immediately
  // (rather than waiting for the next full loadLib() cycle) — scoped to
  // requested seasons only, matching /api/library/missing-counts exactly.
  const requestedMissing = episodes.filter(e => e.aired && seasonRequested[e.season] && !e.has_hd).length;
  libMissingCounts[g.imdb] = requestedMissing;

  const escTitle = g.title.replace(/\\/g,'\\\\').replace(/'/g,"\\'");
  const escPoster = (g.poster||'').replace(/'/g,"\\'");

  const seasonRows = seasons.map(sn => {
    const eps = seasonMap[sn].sort((a,b)=>a.episode-b.episode);
    const requested = seasonRequested[sn];
    const airedEps = eps.filter(e=>e.aired);
    const missing = airedEps.filter(e=>!e.has_hd).length;

    // Unrequested season: show a single "Request season" row instead of
    // per-episode chips (there's nothing to show per-episode yet).
    if (!requested) {
      const airedCount = airedEps.length;
      const futureCount = eps.length - airedCount;
      const countLabel = airedCount > 0
        ? `${airedCount} ep${airedCount!==1?'s':''}${futureCount>0?` &middot; ${futureCount} upcoming`:''}`
        : `${futureCount} upcoming ep${futureCount!==1?'s':''}`;
      return `<div style="margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;gap:10px;background:var(--card2);border:1px solid var(--bor);border-radius:10px;padding:12px 14px">
        <div>
          <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:3px">
            Season ${sn} <span style="color:var(--txt);font-weight:600">${countLabel}</span>
          </div>
          <div style="font-size:11px;color:var(--mut)">Not requested yet</div>
        </div>
        <button id="reqSeasonBtn_${sn}" class="mbtn mbtn-add" style="padding:8px 16px;font-size:12px;flex-shrink:0;width:auto"
          onclick="requestSeason('${safeId}','${g.imdb}','${escTitle}','${escPoster}',${sn},'${g.year||''}')"
          ${airedCount===0 ? 'disabled title="No aired episodes yet"' : ''}>
          ${airedCount===0 ? 'Not aired' : 'Request season'}
        </button>
      </div>`;
    }

    const chips = airedEps.map(ep => {
      const eStr = String(ep.episode).padStart(2,'0');
      if (ep.has_hd) {
        const col = ep.has_4k ? 'var(--acc2)' : 'var(--blue)';
        const lbl = ep.has_4k ? 'HD+4K' : 'HD';
        // Prefer letting the 4K stub be the one picked when both exist,
        // since that's usually the one worth double-checking; either way
        // this opens the Active Stream picker for whichever stub_id is
        // actually available.
        const targetStubId = ep.uhd_stub_id || ep.hd_stub_id;
        const clickAttr = targetStubId ? `onclick="event.stopPropagation();openActiveStreamModal('${targetStubId}','${escTitle} S${String(sn).padStart(2,'0')}E${eStr}')"` : '';
        return `<span ${clickAttr}
          title="${targetStubId ? 'Click to view/change the active stream' : ''}"
          style="background:var(--card2);border:1px solid var(--bor);border-radius:5px;padding:3px 7px;font-size:10px;font-weight:700;color:${col};white-space:nowrap${targetStubId ? ';cursor:pointer' : ''}">E${eStr} <span style="color:var(--mut);font-weight:400">${lbl}</span></span>`;
      } else {
        const sid   = `ep_${sn}_${ep.episode}`;
        return `<span id="${sid}"
          onclick="searchMissingEp('${safeId}','${g.imdb}','${escTitle}',${sn},${ep.episode},'${escPoster}','${g.year||''}')"
          title="Click to search for S${String(sn).padStart(2,'0')}E${eStr}"
          style="background:transparent;border:1px dashed rgba(255,255,255,.18);border-radius:5px;padding:3px 7px;font-size:10px;font-weight:700;color:rgba(255,255,255,.35);cursor:pointer;white-space:nowrap;transition:all 140ms"
          onmouseover="this.style.borderColor='var(--acc)';this.style.color='var(--txt)'"
          onmouseout="this.style.borderColor='rgba(255,255,255,.18)';this.style.color='rgba(255,255,255,.35)'">E${eStr} <span style="font-weight:400">missing</span></span>`;
      }
    }).join('');

    const mbadge = missing > 0
      ? `<span style="color:var(--red);font-size:10px;font-weight:600;margin-left:6px">${missing} missing</span>` : '';
    const reqBadge = `<span style="color:var(--grn);font-size:10px;font-weight:600;margin-left:6px">requested</span>`;

    return `<div style="margin-bottom:16px">
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:8px;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
        <span>Season ${sn} <span style="color:var(--txt);font-weight:600">${airedEps.length} ep${airedEps.length!==1?'s':''}</span>${reqBadge}${mbadge}</span>
        <span style="display:flex;align-items:center;gap:4px;flex-shrink:0">
          <span id="scanHdSeason_${sn}" onclick="scanSeasonQuality('${g.imdb}',${sn},'hd',this)"
            style="text-transform:none;letter-spacing:0;font-weight:600;color:var(--blue);cursor:pointer;font-size:11px;padding:2px 7px;border-radius:5px;border:1px solid rgba(74,158,255,.3);transition:all 140ms">
            Scan HD
          </span>
          <span id="scanUhdSeason_${sn}" onclick="scanSeasonQuality('${g.imdb}',${sn},'4k',this)"
            style="text-transform:none;letter-spacing:0;font-weight:600;color:var(--acc2);cursor:pointer;font-size:11px;padding:2px 7px;border-radius:5px;border:1px solid rgba(232,160,32,.3);transition:all 140ms">
            Scan 4K
          </span>
          <span id="scanBothSeason_${sn}" onclick="scanSeasonBoth('${g.imdb}',${sn},this)"
            style="text-transform:none;letter-spacing:0;font-weight:600;color:var(--txt);cursor:pointer;font-size:11px;padding:2px 7px;border-radius:5px;border:1px solid var(--bor2);transition:all 140ms">
            Scan HD+4K
          </span>
          <span id="rmSeason_${sn}" onclick="removeSeasonClick('${safeId}','${g.imdb}','${escTitle}',${sn},this)"
            style="text-transform:none;letter-spacing:0;font-weight:600;color:var(--mut);cursor:pointer;font-size:11px;flex-shrink:0;padding:2px 6px;border-radius:5px;transition:all 140ms"
            onmouseover="if(!this.dataset.armed){this.style.color='var(--red)'}" onmouseout="if(!this.dataset.armed){this.style.color='var(--mut)'}">
            Remove
          </span>
        </span>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:5px">${chips}</div>
    </div>`;
  }).join('');

  const posterEl = g.poster
    ? `<img src="${g.poster}" style="width:52px;height:78px;object-fit:cover;border-radius:7px;flex-shrink:0"/>`
    : '';
  const scanBadge = isScanning
    ? `<div style="font-size:11px;color:var(--blue);margin-top:4px;display:flex;align-items:center;gap:5px"><span style="width:6px;height:6px;border-radius:50%;background:var(--blue);display:inline-block;animation:sblink 1s infinite"></span> Scanning…</div>` : '';
  const missingNote = totalMissing > 0 && !isScanning
    ? `<div style="font-size:11px;color:var(--red);margin-top:3px">${totalMissing} ep${totalMissing!==1?'s':''} missing</div>` : '';

  // Only seasons with at least one aired episode can actually be
  // requested right now — an unaired season would just 404.
  const requestableSeasons = unrequestedSeasons.filter(
    sn => seasonMap[sn].some(e => e.aired)
  );
  const requestAllBtn = requestableSeasons.length > 0
    ? `<button id="reqAllBtn" onclick='requestAllSeasons("${safeId}","${g.imdb}","${escTitle}","${escPoster}","${g.year||''}",${JSON.stringify(requestableSeasons)})'
        style="background:none;border:1px solid var(--acc);color:var(--acc);border-radius:6px;padding:3px 10px;font-size:11px;font-weight:700;cursor:pointer;margin-left:8px;white-space:nowrap">
        Request all (${requestableSeasons.length})
      </button>`
    : '';

  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:18px;width:100%;max-width:520px;max-height:82vh;display:flex;flex-direction:column;overflow:hidden">
      <div style="padding:20px 22px 16px;border-bottom:1px solid var(--bor);display:flex;align-items:flex-start;gap:14px;flex-shrink:0">
        ${posterEl}
        <div style="flex:1;min-width:0">
          <div style="font-size:17px;font-weight:800;letter-spacing:-.3px;margin-bottom:3px">${g.title}</div>
          <div style="font-size:12px;color:var(--mut);display:flex;align-items:center;flex-wrap:wrap;row-gap:6px">
            <span>${seasons.length} season${seasons.length!==1?'s':''} &middot; ${totalStubbed}/${totalAired} episodes</span>${requestAllBtn}
          </div>
          ${scanBadge}${missingNote}
        </div>
        <button onclick="document.getElementById('seriesDlg').remove()" style="background:var(--card2);border:1px solid var(--bor);border-radius:8px;color:var(--mut);width:30px;height:30px;cursor:pointer;font-size:14px;flex-shrink:0">✕</button>
      </div>
      <div style="padding:18px 22px;overflow-y:auto;flex:1">
        ${seasons.length ? seasonRows : '<div style="color:var(--mut);font-size:13px">No episodes found yet.</div>'}
      </div>
      <div style="padding:14px 22px;border-top:1px solid var(--bor);display:flex;gap:10px;flex-shrink:0">
        <button id="rescanBtn" class="mbtn mbtn-add"
          onclick="rescanSeries('${safeId}','${g.imdb}','${escTitle}','${escPoster}','${g.year||''}')"
          style="${isScanning?'opacity:.5;pointer-events:none':''}">
          ${isScanning ? 'Scanning…' : 'Rescan all'}
        </button>
        <button class="mbtn mbtn-add" onclick="document.getElementById('seriesDlg').remove();openDelModal('${safeId}')" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)">Remove</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('seriesDlg').remove()">Close</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target===dlg) dlg.remove(); });
}

async function scanSeasonQuality(imdbId, season, quality, el) {
  const original = el.textContent;
  el.textContent = 'Scanning…';
  el.style.pointerEvents = 'none';
  el.style.opacity = '.6';
  try {
    const r = await fetch(`/api/series/${imdbId}/season/${season}/scan/${quality}`, { method: 'POST' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || 'Scan failed');
    toast(`Season ${season} ${quality.toUpperCase()} scan: found ${d.found}/${d.checked} checked (${d.already_had} already had it)`, 'ok');
    await loadLib();
    const safeId = imdbId.replace(/[^a-z0-9]/gi, '');
    document.getElementById('seriesDlg')?.remove();
    openSeriesDetail(safeId);
  } catch (exc) {
    toast(exc.message || 'Scan failed', 'er');
    el.textContent = original;
    el.style.pointerEvents = 'auto';
    el.style.opacity = '1';
  }
}

async function scanSeasonBoth(imdbId, season, el) {
  const original = el.textContent;
  el.style.pointerEvents = 'none';
  el.style.opacity = '.6';
  const results = [];
  for (const quality of ['hd', '4k']) {
    el.textContent = `Scanning ${quality.toUpperCase()}…`;
    try {
      const r = await fetch(`/api/series/${imdbId}/season/${season}/scan/${quality}`, { method: 'POST' });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.detail || 'Scan failed');
      results.push(`${quality.toUpperCase()}: found ${d.found}/${d.checked}`);
    } catch (exc) {
      results.push(`${quality.toUpperCase()}: ${exc.message || 'failed'}`);
    }
  }
  toast(`Season ${season} — ${results.join(' · ')}`, 'ok');
  el.textContent = original;
  el.style.pointerEvents = 'auto';
  el.style.opacity = '1';
  await loadLib();
  const safeId = imdbId.replace(/[^a-z0-9]/gi, '');
  document.getElementById('seriesDlg')?.remove();
  openSeriesDetail(safeId);
}

function removeSeasonClick(safeId, imdbId, title, season, el) {
  if (!el.dataset.armed) {
    // First click: arm it — turns red and waits a few seconds for a
    // second click, rather than popping a whole separate confirm modal
    // for what's a fairly contained, single-season action.
    el.dataset.armed = '1';
    el.textContent = 'Confirm?';
    el.style.color = 'var(--red)';
    el.style.background = 'rgba(255,85,85,.12)';
    el._disarmTimer = setTimeout(() => {
      if (el.dataset.armed) {
        delete el.dataset.armed;
        el.textContent = 'Remove';
        el.style.color = 'var(--mut)';
        el.style.background = 'none';
      }
    }, 4000);
    return;
  }
  clearTimeout(el._disarmTimer);
  removeSeasonNow(safeId, imdbId, title, season, el);
}

async function removeSeasonNow(safeId, imdbId, title, season, el) {
  el.textContent = 'Removing…';
  el.style.pointerEvents = 'none';
  try {
    const r = await fetch(`/api/series/${imdbId}/season/${season}`, { method: 'DELETE' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || 'Could not remove season');
    toast(`Removed Season ${season} of "${title}" (${d.removed} stub${d.removed !== 1 ? 's' : ''})`, 'ok');
    document.getElementById('seriesDlg')?.remove();
    await loadLib();
    openSeriesDetail(safeId);
  } catch (exc) {
    toast(exc.message || 'Could not remove season', 'er');
    el.textContent = 'Remove';
    el.style.pointerEvents = 'auto';
    delete el.dataset.armed;
  }
}

async function requestSeason(safeId, imdbId, title, poster, season, year) {
  const btn = document.getElementById(`reqSeasonBtn_${season}`);
  if (btn) { btn.textContent = 'Requesting…'; btn.disabled = true; }
  _bg_scans_ui.add(imdbId);
  toast(`Requesting Season ${season} of "${title}"`, 'in');
  try {
    const r = await fetch('/api/add', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ imdb_id:imdbId, title, media_type:'series', poster, season, year: year ? parseInt(year) : null }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail||'Error');
    document.getElementById('seriesDlg')?.remove();
    pollScan(imdbId, title);
  } catch(e) {
    _bg_scans_ui.delete(imdbId);
    if (btn) { btn.textContent = 'Request season'; btn.disabled = false; }
    toast(e.message, 'er');
  }
}

async function requestAllSeasons(safeId, imdbId, title, poster, year, unrequestedSeasons) {
  const btn = document.getElementById('reqAllBtn');
  if (btn) { btn.textContent = 'Requesting…'; btn.style.pointerEvents = 'none'; btn.style.opacity = '.6'; }
  _bg_scans_ui.add(imdbId);
  toast(`Requesting ${unrequestedSeasons.length} season${unrequestedSeasons.length!==1?'s':''} of "${title}"`, 'in');
  try {
    // One targeted request per unrequested season (not a blanket whole-
    // series rescan) — avoids re-querying AIOStreams for episodes that
    // are already stubbed, which create_stubs() would just no-op on
    // anyway but wastes API calls/rate-limit budget at series-add scale.
    for (const sn of unrequestedSeasons) {
      const r = await fetch('/api/add', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ imdb_id:imdbId, title, media_type:'series', poster, season: sn, year: year ? parseInt(year) : null }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.detail||'Error');
    }
    document.getElementById('seriesDlg')?.remove();
    pollScan(imdbId, title);
  } catch(e) {
    _bg_scans_ui.delete(imdbId);
    if (btn) { btn.textContent = `Request all`; btn.style.pointerEvents = 'auto'; btn.style.opacity = '1'; }
    toast(e.message, 'er');
  }
}

async function searchMissingEp(safeId, imdbId, title, season, episode, poster, year) {
  const chipId = `ep_${season}_${episode}`;
  const chip   = document.getElementById(chipId);
  const eStr   = String(episode).padStart(2,'0');
  const sStr   = String(season).padStart(2,'0');
  if (chip) {
    chip.textContent = `E${eStr} searching…`;
    chip.style.color = 'var(--blue)';
    chip.style.borderColor = 'var(--blue)';
    chip.style.borderStyle = 'solid';
    chip.style.pointerEvents = 'none';
    chip.onmouseover = chip.onmouseout = null;
  }
  try {
    const r = await fetch(`/api/series/${imdbId}/episode/${season}/${episode}`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({imdb_id:imdbId, title, media_type:'series', poster, year:year?parseInt(year):null}),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail||'No streams found');
    if (chip) {
      const lbl = d.has_4k ? 'HD+4K' : 'HD';
      const col = d.has_4k ? 'var(--acc2)' : 'var(--blue)';
      chip.style.background = 'var(--card2)';
      chip.style.borderColor = 'var(--bor)';
      chip.style.color = col;
      chip.innerHTML = `E${eStr} <span style="color:var(--mut);font-weight:400">${lbl}</span>`;
      chip.style.cursor = 'default';
      chip.onclick = null;
    }
    toast(`Found S${sStr}E${eStr}`, 'ok');
    await syncStubs();
  } catch(e) {
    if (chip) {
      chip.textContent = `E${eStr} not found`;
      chip.style.color = 'var(--red)';
      chip.style.borderColor = 'var(--red)';
      chip.style.pointerEvents = 'auto';
    }
    toast(`S${sStr}E${eStr}: ${e.message}`, 'er');
  }
}


async function rescanSeries(safeId, imdbId, title, poster, year) {
  const btn = document.getElementById('rescanBtn');
  if (btn) { btn.textContent='Scanning…'; btn.style.opacity='.5'; btn.style.pointerEvents='none'; }
  _bg_scans_ui.add(imdbId);
  document.getElementById('seriesDlg')?.remove();
  toast(`Rescanning "${title}"`, 'in');
  try {
    const r = await fetch('/api/add', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ imdb_id:imdbId, title, media_type:'series', poster, year: year ? parseInt(year) : null }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail||'Error');
    pollScan(imdbId, title);
  } catch(e) {
    _bg_scans_ui.delete(imdbId);
    toast(e.message, 'er');
  }
}

// ── Delete options modal ────────────────────────────────────────
function openDelModal(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;
  const hdStub  = g.stubs.find(s => s.quality === 'hd');
  const k4Stub  = g.stubs.find(s => s.quality === '4k');
  const hasHd = !!hdStub;
  const has4k = !!k4Stub;
  const both  = hasHd && has4k;
  const isMovie = g.media_type !== 'series';

  const dlg = document.createElement('div');
  dlg.id = 'delDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:300;display:flex;align-items:center;justify-content:center';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px 28px 24px;max-width:360px;width:90%">
      <div style="font-size:17px;font-weight:800;margin-bottom:6px">${g.title}</div>
      ${isMovie ? `
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin:18px 0 10px">Scan</div>
      <div style="display:flex;gap:8px;margin-bottom:18px">
        <button id="movieScanHd" class="mbtn mbtn-add" style="background:#1a2e40;color:var(--blue);border:1px solid rgba(74,158,255,.3);width:auto;flex:1"
          onclick="scanMovieQuality('${g.imdb}','hd',this)">${hasHd ? 'Rescan HD' : 'Scan HD'}</button>
        <button id="movieScanUhd" class="mbtn mbtn-add" style="background:#2e1e00;color:var(--acc2);border:1px solid rgba(232,160,32,.3);width:auto;flex:1"
          onclick="scanMovieQuality('${g.imdb}','4k',this)">${has4k ? 'Rescan 4K' : 'Scan 4K'}</button>
      </div>
      <div style="margin-bottom:18px">
        <button id="movieScanBoth" class="mbtn mbtn-add" style="background:var(--card2);color:var(--txt);border:1px solid var(--bor2);width:100%"
          onclick="scanMovieBoth('${g.imdb}',this)">Scan HD+4K</button>
      </div>
      ${(hasHd || has4k) ? `
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:10px">Active stream</div>
      <div style="display:flex;gap:8px;margin-bottom:18px">
        ${hasHd ? `<button class="mbtn mbtn-add" style="background:var(--card2);color:var(--blue);border:1px solid rgba(74,158,255,.3);width:auto;flex:1" onclick="openActiveStreamModal('${hdStub.stub_id}','${g.title} (HD)')">View/change HD</button>` : ''}
        ${has4k ? `<button class="mbtn mbtn-add" style="background:var(--card2);color:var(--acc2);border:1px solid rgba(232,160,32,.3);width:auto;flex:1" onclick="openActiveStreamModal('${k4Stub.stub_id}','${g.title} (4K)')">View/change 4K</button>` : ''}
      </div>
      ` : ''}
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:10px">Remove</div>
      ` : `<div style="font-size:13px;color:var(--mut);margin-bottom:22px">Remove from Plex</div>`}
      <div style="display:flex;flex-direction:column;gap:10px">
        ${hasHd ? `<button class="mbtn mbtn-add" style="background:#1a2e40;color:var(--blue);border:1px solid rgba(74,158,255,.3)" onclick="delQuality('${safeId}','hd')">Delete HD stub</button>` : ''}
        ${has4k ? `<button class="mbtn mbtn-add" style="background:#2e1e00;color:var(--acc2);border:1px solid rgba(232,160,32,.3)" onclick="delQuality('${safeId}','4k')">Delete 4K stub</button>` : ''}
        ${both  ? `<button class="mbtn mbtn-add" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)" onclick="delQuality('${safeId}','both')">Delete both (HD + 4K)</button>` : ''}
        <button class="mbtn mbtn-close" onclick="document.getElementById('delDlg').remove()" style="margin-top:4px">Cancel</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

function openPendingMovieModal(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g || !g.pending) return;

  const dlg = document.createElement('div');
  dlg.id = 'pendingMovieDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:300;display:flex;align-items:center;justify-content:center';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px 28px 24px;max-width:360px;width:90%">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${g.title}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:22px">
        ${g.year ? g.year + ' · ' : ''}Not resolvable yet — most commonly because it hasn't
        released, or nothing's cached at your debrid backend yet. Being retried
        automatically until it resolves or the retry window elapses.
      </div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <button id="pendingMovieSearchBtn" class="mbtn mbtn-add" style="background:var(--acc);color:#000"
          onclick="searchPendingMovieNow('${g.imdb}','${safeId}',this)">Search now</button>
        <button class="mbtn mbtn-add" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)"
          onclick="removePendingMovieFromLib('${g.imdb}')">Remove from tracking</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('pendingMovieDlg').remove()" style="margin-top:4px">Close</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

async function searchPendingMovieNow(imdbId, safeId, btn) {
  const g = window._libGroups && window._libGroups[safeId];
  btn.textContent = 'Searching…';
  btn.disabled = true;
  try {
    const r = await fetch('/api/add', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        imdb_id: imdbId, title: g ? g.title : imdbId, media_type: 'movie',
        poster: g ? g.poster : '', year: g && g.year ? parseInt(g.year) : null,
      }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Search failed');
    if (d.pending) {
      toast(`Still not resolvable yet — will keep retrying automatically`, 'in');
    } else {
      toast(`Found and added "${g ? g.title : imdbId}"`, 'ok');
    }
    document.getElementById('pendingMovieDlg')?.remove();
    loadLib();
  } catch (exc) {
    toast(exc.message || 'Search failed', 'er');
    btn.textContent = 'Search now';
    btn.disabled = false;
  }
}

async function removePendingMovieFromLib(imdbId) {
  try {
    await fetch(`/api/pending-movies/${imdbId}`, { method: 'DELETE' });
    toast('Removed from tracking', 'ok');
    document.getElementById('pendingMovieDlg')?.remove();
    loadLib();
  } catch {
    toast('Could not remove', 'er');
  }
}

async function scanMovieQuality(imdbId, quality, el) {
  const original = el.textContent;
  el.textContent = 'Scanning…';
  el.disabled = true;
  el.style.opacity = '.6';
  try {
    const r = await fetch(`/api/movies/${imdbId}/scan/${quality}`, { method: 'POST' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || `No ${quality.toUpperCase()} stream found`);
    toast(`Found and stubbed ${quality.toUpperCase()}`, 'ok');
    document.getElementById('delDlg')?.remove();
    await loadLib();
  } catch (exc) {
    toast(exc.message || 'Scan failed', 'er');
    el.textContent = original;
    el.disabled = false;
    el.style.opacity = '1';
  }
}

async function scanMovieBoth(imdbId, el) {
  const original = el.textContent;
  el.disabled = true;
  el.style.opacity = '.6';
  const results = [];
  for (const quality of ['hd', '4k']) {
    el.textContent = `Scanning ${quality.toUpperCase()}…`;
    try {
      const r = await fetch(`/api/movies/${imdbId}/scan/${quality}`, { method: 'POST' });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.detail || `No ${quality.toUpperCase()} stream found`);
      results.push(`${quality.toUpperCase()}: found`);
    } catch (exc) {
      results.push(`${quality.toUpperCase()}: ${exc.message || 'not found'}`);
    }
  }
  toast(results.join(' · '), 'ok');
  document.getElementById('delDlg')?.remove();
  await loadLib();
}

async function delQuality(safeId, quality) {
  document.getElementById('delDlg')?.remove();
  document.getElementById('seriesDlg')?.remove();
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;

  if (quality === 'both') {
    // Use series delete endpoint — cancels scan + removes everything atomically
    await fetch(`/api/series/${g.imdb}`, { method: 'DELETE' });
    toast('Series removed', 'ok');
  } else {
    const toDelete = quality === 'hd'
      ? g.stubs.filter(s => s.quality === 'hd')
      : g.stubs.filter(s => s.quality === '4k');
    for (const s of toDelete) {
      await fetch(`/api/stubs/${s.stub_id}`, { method: 'DELETE' });
    }
    toast(`Removed ${quality.toUpperCase()} stubs`, 'ok');
  }
  loadLib();
}

// ── Active stream picker ──────────────────────────────────────
async function openActiveStreamModal(stubId, label) {
  document.getElementById('delDlg')?.remove();

  const dlg = document.createElement('div');
  dlg.id = 'activeStreamDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:310;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:24px;max-width:640px;width:100%;max-height:82vh;display:flex;flex-direction:column">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${label}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:16px">Active stream — pick which source Plex actually plays</div>
      <div id="activeStreamList" style="overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:8px">
        <div style="color:var(--mut);font-size:13px;padding:20px 0;text-align:center">Loading candidates…</div>
      </div>
      <button class="mbtn mbtn-close" onclick="document.getElementById('activeStreamDlg').remove()" style="margin-top:16px">Close</button>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);

  try {
    const d = await (await fetch(`/api/stubs/${stubId}/candidates`)).json();
    renderActiveStreamCandidates(stubId, d.candidates || []);
  } catch (exc) {
    document.getElementById('activeStreamList').innerHTML =
      `<div style="color:var(--red);font-size:13px;padding:20px 0;text-align:center">Could not load candidates: ${exc.message || exc}</div>`;
  }
}

function renderActiveStreamCandidates(stubId, candidates) {
  const el = document.getElementById('activeStreamList');
  if (!el) return;
  if (!candidates.length) {
    el.innerHTML = `<div style="color:var(--mut);font-size:13px;padding:20px 0;text-align:center">No candidates available right now.</div>`;
    return;
  }
  window._activeStreamCandidates = candidates;
  el.innerHTML = candidates.map((c, i) => {
    const sizeStr = c.size_gb ? `${c.size_gb} GB` : 'size unknown';
    const tags = [
      c.resolution, c.encode, c.hdr,
      c.cached ? 'cached' : 'uncached',
      c.pack ? `${c.pack} pack` : null,
      c.service,
    ].filter(Boolean).join(' · ');
    return `
    <div style="background:${c.is_current ? 'rgba(232,160,32,.1)' : 'var(--card2)'};border:1px solid ${c.is_current ? 'var(--acc)' : 'var(--bor)'};border-radius:10px;padding:12px 14px;display:flex;align-items:center;gap:12px">
      <div style="flex:1;min-width:0">
        <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${(c.filename||'').replace(/"/g,'&quot;')}">${c.filename || 'Unknown filename'}</div>
        <div style="font-size:11px;color:var(--mut);margin-top:3px">${sizeStr}${tags ? ' · ' + tags : ''}</div>
      </div>
      ${c.is_current
        ? `<span class="cal-badge inlib" style="flex-shrink:0">Current</span>`
        : `<button class="cal-rescan-btn" style="flex-shrink:0" onclick="selectActiveStream('${stubId}',${i},this)">Use this</button>`}
    </div>`;
  }).join('');
}

async function selectActiveStream(stubId, index, btn) {
  const c = (window._activeStreamCandidates || [])[index];
  if (!c) return;
  const original = btn.textContent;
  btn.textContent = 'Setting…';
  btn.disabled = true;
  try {
    const r = await fetch(`/api/stubs/${stubId}/select-stream`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: c.url, headers: c.headers || {}, size: c.size }),
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'Could not set stream');
    }
    toast('Active stream updated', 'ok');
    document.getElementById('activeStreamDlg')?.remove();
    loadLib();
  } catch (exc) {
    toast(exc.message || 'Could not set stream', 'er');
    btn.textContent = original;
    btn.disabled = false;
  }
}

async function delStub(id) {
  await fetch(`/api/stubs/${id}`, { method: 'DELETE' });
  toast('Stub deleted', 'ok');
  loadLib();
}

// ── Config ────────────────────────────────────────────────────
function switchCfgTab(name) {
  document.querySelectorAll('.cfgtab').forEach(el => el.classList.remove('on'));
  document.querySelectorAll('.cfgpanel').forEach(el => el.classList.remove('on'));
  document.getElementById(`cfgtab-${name}`).classList.add('on');
  document.getElementById(`cfgpanel-${name}`).classList.add('on');
}

async function loadCfg() {
  try {
    const d = await (await fetch('/api/config')).json();
    document.getElementById('cfgChips').innerHTML =
      chip('AIOSTREAMS_URL', d.aiostreams_url, true) +
      chip('UUID',           d.uuid_set ? 'Set' : 'Not set', d.uuid_set) +
      chip('PASSWORD',       d.password_set ? 'Set' : 'Not set', d.password_set);
    document.getElementById('wurl').textContent = `http://${location.hostname}:8001/webhook/plex`;

    const f = d.fuse || {};
    document.getElementById('fuseChips').innerHTML =
      chip('FUSE_MOUNTPOINT',        f.mountpoint, true) +
      chip('FUSE_BLOCK_MB',          f.block_mb, true) +
      chip('FUSE_CACHE_BLOCKS',      f.cache_blocks, true) +
      chip('FUSE_PREFETCH_AHEAD',    f.prefetch_ahead, true) +
      chip('FUSE_READ_TIMEOUT',      f.read_timeout, true) +
      chip('FUSE_RESOLVE_TIMEOUT',   f.resolve_timeout, true) +
      chip('FUSE_MAX_INFLIGHT',      f.max_inflight, true) +
      chip('FUSE_POOL_CONNECTIONS',  f.pool_connections, true) +
      chip('FUSE_POOL_MAXSIZE',      f.pool_maxsize, true);
  } catch {}
  try {
    const s = await (await fetch('/api/settings')).json();
    document.getElementById('ttlInput').value = s.active_ttl_days ?? 0;
    document.getElementById('prewarmDaysInput').value = s.prewarm_new_releases_days ?? 3;
    document.getElementById('prewarmIntervalInput').value = s.prewarm_interval_hours ?? 1;
    document.getElementById('prefLanguage').value = s.preferred_language ?? '';
    document.getElementById('prefAudio').value = (s.preferred_audio ?? []).join(', ');
    document.getElementById('reqSubs').checked = !!s.require_subtitles;
    document.getElementById('preferPacks').checked = s.prefer_season_packs !== false;
    document.getElementById('minSizeGb').value = s.min_size_gb ?? 0;
    document.getElementById('maxSizeGb').value = s.max_size_gb ?? 0;
    document.getElementById('excludeWords').value = (s.exclude_words ?? []).join(', ');
    document.getElementById('min4kCandidates').value = s.min_4k_candidates ?? 6;
    document.getElementById('autoEpEnabled').checked = s.auto_episodes_enabled !== false;
    document.getElementById('autoEpInterval').value = s.auto_episodes_interval_minutes ?? 10;
    document.getElementById('autoEpRetryDays').value = s.auto_episodes_retry_days ?? 3;
    document.getElementById('pendingMvEnabled').checked = s.pending_movies_enabled !== false;
    document.getElementById('pendingMvRetryDays').value = s.pending_movies_retry_days ?? 30;
    document.getElementById('digitalDelayDays').value = s.digital_release_delay_days ?? 21;
    document.getElementById('deadStubMaxErrors').value = s.dead_stub_max_errors ?? 3;
    document.getElementById('aioMaxConcurrent').value = s.aiostreams_max_concurrent ?? 1;
    document.getElementById('aioMinInterval').value = s.aiostreams_min_interval_ms ?? 1500;
    document.getElementById('spotIntervalHours').value = s.spot_check_interval_hours ?? 0;
    document.getElementById('spotScheduledScope').value = s.spot_check_scheduled_scope ?? 'both';
    document.getElementById('spotVerifyQuality').checked = s.spot_check_verify_quality !== false;
  } catch {}
  migSvcChanged();
  loadPendingMovies();
  loadQualityUnavailable();
  renderSpotScopeChips();
}

async function loadPendingMovies() {
  const wrap = document.getElementById('pendingMvList');
  if (!wrap) return;
  try {
    const d = await (await fetch('/api/pending-movies')).json();
    const items = d.items || [];
    if (!items.length) {
      wrap.innerHTML = `<div style="color:var(--mut);font-size:13px">Nothing pending right now.</div>`;
      return;
    }
    wrap.innerHTML = items.map(it => `
      <div class="cal-entry">
        ${it.poster
          ? `<img class="cal-poster" src="${it.poster}" loading="lazy">`
          : `<div class="cal-poster-placeholder">\uD83C\uDFAC</div>`}
        <div class="cal-info">
          <div class="cal-title">${it.title}</div>
          <div class="cal-sub">${it.year || ''}${it.year ? ' · ' : ''}Tracking since ${new Date(it.added_at * 1000).toLocaleDateString()}</div>
        </div>
        <button class="cal-rescan-btn" onclick="removePendingMovie('${it.imdb_id}', this)">Remove</button>
      </div>
    `).join('');
  } catch {
    wrap.innerHTML = `<div style="color:var(--red);font-size:13px">Could not load pending movies.</div>`;
  }
}

async function removePendingMovie(imdbId, btn) {
  btn.disabled = true;
  try {
    await fetch(`/api/pending-movies/${imdbId}`, { method: 'DELETE' });
    loadPendingMovies();
  } catch {
    toast('Could not remove', 'er');
    btn.disabled = false;
  }
}

async function loadQualityUnavailable() {
  const wrap = document.getElementById('qualityUnavailList');
  if (!wrap) return;
  try {
    const d = await (await fetch('/api/quality-unavailable')).json();
    const items = d.items || [];
    if (!items.length) {
      wrap.innerHTML = `<div style="color:var(--mut);font-size:13px">Nothing marked right now.</div>`;
      return;
    }
    wrap.innerHTML = items.map(it => {
      const sub = it.season != null && it.episode != null
        ? `S${String(it.season).padStart(2,'0')}E${String(it.episode).padStart(2,'0')} · Marked ${new Date(it.marked_at * 1000).toLocaleDateString()}`
        : `Marked ${new Date(it.marked_at * 1000).toLocaleDateString()}`;
      return `
      <div class="cal-entry">
        ${it.poster
          ? `<img class="cal-poster" src="${it.poster}" loading="lazy">`
          : `<div class="cal-poster-placeholder">${it.season != null ? '\uD83D\uDCFA' : '\uD83C\uDFAC'}</div>`}
        <div class="cal-info">
          <div class="cal-title">${it.title}</div>
          <div class="cal-sub">${sub}</div>
        </div>
        <button class="cal-rescan-btn" onclick="removeQualityUnavailable('${it.key}', this)">Remove mark</button>
      </div>
    `;
    }).join('');
  } catch {
    wrap.innerHTML = `<div style="color:var(--red);font-size:13px">Could not load.</div>`;
  }
}

async function removeQualityUnavailable(key, btn) {
  btn.disabled = true;
  try {
    await fetch(`/api/quality-unavailable/${encodeURIComponent(key)}`, { method: 'DELETE' });
    loadQualityUnavailable();
  } catch {
    toast('Could not remove mark', 'er');
    btn.disabled = false;
  }
}

async function savePendingMovies() {
  const retryDays = parseFloat(document.getElementById('pendingMvRetryDays').value);
  const digitalDelay = parseFloat(document.getElementById('digitalDelayDays').value);
  if (isNaN(retryDays) || retryDays < 0) {
    toast('Retry window must be ≥ 0 days', 'er');
    return;
  }
  if (isNaN(digitalDelay) || digitalDelay < 0) {
    toast('Digital delay must be ≥ 0 days', 'er');
    return;
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        pending_movies_enabled: document.getElementById('pendingMvEnabled').checked,
        pending_movies_retry_days: retryDays,
        digital_release_delay_days: digitalDelay,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('pendingMvSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function runPendingMoviesSweepNow() {
  const resultEl = document.getElementById('pendingMvSweepResult');
  resultEl.innerHTML = `<span style="color:var(--mut)">Checking…</span>`;
  try {
    const d = await (await fetch('/api/pending-movies/sweep-now', { method: 'POST' })).json();
    resultEl.innerHTML = `<span style="color:var(--grn)">Checked ${d.checked ?? 0}, resolved ${d.resolved ?? 0}, ${d.pending ?? 0} still pending</span>`;
    loadPendingMovies();
    loadLib();
  } catch {
    resultEl.innerHTML = `<span style="color:var(--red)">Check failed</span>`;
  }
}

// ── Migrate (Radarr/Sonarr) ──────────────────────────────────────
let migPreviewItems = [];
let migPollTimer = null;

async function migSvcChanged() {
  const svc = document.getElementById('migSvc').value;
  document.getElementById('migPreviewWrap').style.display = 'none';
  document.getElementById('migTestResult').innerHTML = '';
  document.getElementById('migKey').value = '';
  try {
    const s = await (await fetch('/api/migrate/settings')).json();
    if (svc === 'radarr') {
      document.getElementById('migUrl').value = s.radarr_url || '';
      document.getElementById('migKey').placeholder = s.radarr_configured ? 'Saved — leave blank to keep it' : 'API key';
    } else {
      document.getElementById('migUrl').value = s.sonarr_url || '';
      document.getElementById('migKey').placeholder = s.sonarr_configured ? 'Saved — leave blank to keep it' : 'API key';
    }
  } catch {}
}

async function migSaveAndTest() {
  const svc = document.getElementById('migSvc').value;
  const url = document.getElementById('migUrl').value.trim();
  const key = document.getElementById('migKey').value.trim();
  const resultEl = document.getElementById('migTestResult');
  if (!url) {
    resultEl.innerHTML = `<span style="color:var(--red)">Enter a URL first</span>`;
    return;
  }
  resultEl.innerHTML = `<span style="color:var(--mut)">Saving…</span>`;
  try {
    const body = { service: svc, url };
    if (key) body.api_key = key;
    let r = await fetch('/api/migrate/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || 'save failed');

    resultEl.innerHTML = `<span style="color:var(--mut)">Testing connection…</span>`;
    r = await fetch('/api/migrate/test', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ service: svc })
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'connection failed');
    resultEl.innerHTML = `<span style="color:var(--grn)">✓ Connected — ${d.instance_name || svc} v${d.version}</span>`;
    document.getElementById('migKey').value = '';
    migSvcChanged();
  } catch (exc) {
    resultEl.innerHTML = `<span style="color:var(--red)">${exc.message}</span>`;
  }
}

async function migLoadPreview() {
  const svc = document.getElementById('migSvc').value;
  const resultEl = document.getElementById('migTestResult');
  resultEl.innerHTML = `<span style="color:var(--mut)">Loading library from ${svc}…</span>`;
  try {
    const r = await fetch(`/api/migrate/preview?service=${svc}`);
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'load failed');
    migPreviewItems = d.items || [];
    resultEl.innerHTML = '';
    renderMigList(svc);
  } catch (exc) {
    resultEl.innerHTML = `<span style="color:var(--red)">${exc.message}</span>`;
  }
}

function renderMigList(svc) {
  const wrap = document.getElementById('migPreviewWrap');
  const list = document.getElementById('migList');
  const already = migPreviewItems.filter(it => it.in_library).length;
  document.getElementById('migPreviewSummary').textContent =
    `${migPreviewItems.length} ${svc === 'radarr' ? 'movie(s)' : 'series'} found · ${already} already in your library`;

  if (!migPreviewItems.length) {
    list.innerHTML = `<div style="color:var(--mut);font-size:13px;padding:16px">Nothing found — check the connection above.</div>`;
    wrap.style.display = 'block';
    return;
  }

  list.innerHTML = migPreviewItems.map((it, i) => {
    const sub = svc === 'radarr'
      ? (it.year || '')
      : `${it.seasons.length} season${it.seasons.length === 1 ? '' : 's'}${it.year ? ' · ' + it.year : ''}`;
    const badges = [];
    if (it.in_library) badges.push(`<span class="cal-badge inlib">Already in library</span>`);
    if (svc === 'radarr' && !it.has_file) badges.push(`<span class="cal-badge">Not downloaded in Radarr yet</span>`);
    const poster = it.poster
      ? `<img class="cal-poster" src="${it.poster}" loading="lazy">`
      : `<div class="cal-poster-placeholder">${svc === 'radarr' ? '\uD83C\uDFAC' : '\uD83D\uDCFA'}</div>`;
    return `<label class="cal-entry${it.in_library ? ' inlib' : ''}" style="cursor:pointer">
      <input type="checkbox" class="migItemCk" data-i="${i}" ${it.in_library ? '' : 'checked'} style="cursor:pointer;flex-shrink:0" onclick="event.stopPropagation()">
      ${poster}
      <div class="cal-info">
        <div class="cal-title">${it.title}</div>
        <div class="cal-sub">${sub}</div>
        ${badges.length ? `<div class="cal-badges">${badges.join('')}</div>` : ''}
      </div>
    </label>`;
  }).join('');
  wrap.style.display = 'block';
}

function migSelectAll(on) {
  document.querySelectorAll('.migItemCk').forEach(el => { el.checked = on; });
}

async function migStart() {
  const svc = document.getElementById('migSvc').value;
  const checked = Array.from(document.querySelectorAll('.migItemCk'))
    .filter(el => el.checked)
    .map(el => migPreviewItems[parseInt(el.getAttribute('data-i'), 10)].imdb_id);

  if (!checked.length) {
    toast('Select at least one title to migrate', 'er');
    return;
  }

  try {
    const r = await fetch('/api/migrate/run', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ service: svc, imdb_ids: checked, skip_existing: true })
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'could not start migration');
    migOpenModal(svc);
    migPoll(d.job_id);
  } catch (exc) {
    toast(exc.message || 'Could not start migration', 'er');
  }
}

function migOpenModal(svc) {
  document.getElementById('migModalTitle').textContent =
    `Migrating from ${svc === 'radarr' ? 'Radarr' : 'Sonarr'}`;
  document.getElementById('migModalCurrent').textContent = '';
  document.getElementById('migBar').style.width = '0%';
  document.getElementById('migCount').textContent = '0 / 0';
  document.getElementById('migStatusLabel').textContent = 'Starting…';
  document.getElementById('migErrors').innerHTML = '';
  const cancelBtn = document.getElementById('migCancelBtn');
  cancelBtn.style.display = 'inline-flex';
  cancelBtn.disabled = false;
  cancelBtn.textContent = 'Cancel';
  document.getElementById('migCloseBtn').style.display = 'none';
  document.getElementById('migModal').classList.add('open');
}

function migCloseModal() {
  document.getElementById('migModal').classList.remove('open');
  if (migPollTimer) { clearTimeout(migPollTimer); migPollTimer = null; }
}

let migCurrentJobId = null;

async function migCancel() {
  if (!migCurrentJobId) return;
  // Interrupts the current item immediately server-side (see
  // cancel_migration/_run_migration) — disable right away so it's clear
  // the click registered instead of inviting repeated presses while
  // still waiting on the next status poll to reflect it.
  const btn = document.getElementById('migCancelBtn');
  btn.disabled = true;
  btn.textContent = 'Cancelling…';
  document.getElementById('migStatusLabel').textContent = 'Cancelling…';
  try { await fetch(`/api/migrate/cancel/${migCurrentJobId}`, { method: 'POST' }); } catch {}
}

async function migPoll(jobId) {
  migCurrentJobId = jobId;
  try {
    const job = await (await fetch(`/api/migrate/status/${jobId}`)).json();
    const total = job.total || 0;
    const done  = job.done || 0;
    const pct = total ? Math.round((done / total) * 100) : (job.finished ? 100 : 0);
    document.getElementById('migBar').style.width = `${pct}%`;
    document.getElementById('migCount').textContent = `${done} / ${total}`;
    document.getElementById('migModalCurrent').textContent = job.current_title || '';

    const labels = { starting:'Starting…', running:'Migrating…', done:'Done', cancelled:'Cancelled', error:'Failed' };
    document.getElementById('migStatusLabel').textContent = labels[job.status] || job.status;

    if (job.errors && job.errors.length) {
      document.getElementById('migErrors').innerHTML =
        job.errors.map(e => `<div>⚠ ${e}</div>`).join('');
    }

    if (job.finished) {
      document.getElementById('migCancelBtn').style.display = 'none';
      document.getElementById('migCloseBtn').style.display = 'inline-flex';
      migPollTimer = null;
      if (job.status === 'done') { loadLib(); loadCalendar(); }
      return;
    }
    migPollTimer = setTimeout(() => migPoll(jobId), 1000);
  } catch {
    migPollTimer = setTimeout(() => migPoll(jobId), 2000);
  }
}

// ── Spot check ────────────────────────────────────────────────
let spotPollTimer = null;
let spotCurrentJobId = null;
let spotScope = 'both';   // 'both' | 'movies' | 'series'

const SPOT_SCOPES = [
  { id: 'both',   label: 'Movies + TV shows' },
  { id: 'movies', label: 'Movies only' },
  { id: 'series', label: 'TV shows only' },
];

function renderSpotScopeChips() {
  const el = document.getElementById('spotScopeChips');
  if (!el) return;
  el.innerHTML = SPOT_SCOPES.map(s =>
    `<button class="cal-chip${spotScope === s.id ? ' on' : ''}" onclick="spotSetScope('${s.id}')">${s.label}</button>`
  ).join('');
}

function spotSetScope(id) {
  spotScope = id;
  renderSpotScopeChips();
}

async function runSpotCheck() {
  document.getElementById('spotModalTitle').textContent = 'Spot checking…';
  document.getElementById('spotModalCurrent').textContent = '';
  document.getElementById('spotProgressWrap').style.display = 'block';
  document.getElementById('spotResults').style.display = 'none';
  document.getElementById('spotResults').innerHTML = '';
  document.getElementById('spotBar').style.width = '0%';
  document.getElementById('spotCount').textContent = '0 / 0';
  document.getElementById('spotStatusLabel').textContent = 'Starting…';
  const cancelBtn = document.getElementById('spotCancelBtn');
  cancelBtn.style.display = 'inline-flex';
  cancelBtn.disabled = false;
  cancelBtn.textContent = 'Cancel';
  document.getElementById('spotCloseBtn').style.display = 'none';
  document.getElementById('spotCheckModal').classList.add('open');

  try {
    const r = await fetch('/api/spot-check/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        scope: spotScope,
        verify_quality: document.getElementById('spotVerifyQuality').checked,
      }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Could not start spot check');
    spotPoll(d.job_id);
  } catch (exc) {
    toast(exc.message || 'Could not start spot check', 'er');
    document.getElementById('spotCheckModal').classList.remove('open');
  }
}

function spotCloseModal() {
  document.getElementById('spotCheckModal').classList.remove('open');
  if (spotPollTimer) { clearTimeout(spotPollTimer); spotPollTimer = null; }
}

async function spotCancel() {
  if (!spotCurrentJobId) return;
  const btn = document.getElementById('spotCancelBtn');
  btn.disabled = true;
  btn.textContent = 'Cancelling…';
  document.getElementById('spotStatusLabel').textContent = 'Cancelling…';
  try { await fetch(`/api/spot-check/cancel/${spotCurrentJobId}`, { method: 'POST' }); } catch {}
}

// ── Prewarm new releases ─────────────────────────────────────
let prewarmPollTimer = null;
let prewarmCurrentJobId = null;

async function savePrewarmSettings() {
  const days = parseFloat(document.getElementById('prewarmDaysInput').value);
  const interval = parseFloat(document.getElementById('prewarmIntervalInput').value);
  if (isNaN(days) || days < 0) {
    toast('Days must be ≥ 0', 'er');
    return;
  }
  if (isNaN(interval) || interval < 0) {
    toast('Interval must be ≥ 0 hours', 'er');
    return;
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prewarm_new_releases_days: days,
        prewarm_interval_hours: interval,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('prewarmDaysSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function runPrewarmNewReleases() {
  document.getElementById('prewarmModalTitle').textContent = 'Prewarming new releases…';
  document.getElementById('prewarmModalCurrent').textContent = '';
  document.getElementById('prewarmProgressWrap').style.display = 'block';
  document.getElementById('prewarmResults').style.display = 'none';
  document.getElementById('prewarmResults').innerHTML = '';
  document.getElementById('prewarmBar').style.width = '0%';
  document.getElementById('prewarmCount').textContent = '0 / 0';
  document.getElementById('prewarmStatusLabel').textContent = 'Starting…';
  const cancelBtn = document.getElementById('prewarmCancelBtn');
  cancelBtn.style.display = 'inline-flex';
  cancelBtn.disabled = false;
  cancelBtn.textContent = 'Cancel';
  document.getElementById('prewarmCloseBtn').style.display = 'none';
  document.getElementById('prewarmModal').classList.add('open');

  try {
    const r = await fetch('/api/prewarm-new-releases/run', { method: 'POST' });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Could not start');
    prewarmPoll(d.job_id);
  } catch (exc) {
    toast(exc.message || 'Could not start prewarm', 'er');
    document.getElementById('prewarmModal').classList.remove('open');
  }
}

function prewarmCloseModal() {
  document.getElementById('prewarmModal').classList.remove('open');
  if (prewarmPollTimer) { clearTimeout(prewarmPollTimer); prewarmPollTimer = null; }
}

async function prewarmCancel() {
  if (!prewarmCurrentJobId) return;
  const btn = document.getElementById('prewarmCancelBtn');
  btn.disabled = true;
  btn.textContent = 'Cancelling…';
  document.getElementById('prewarmStatusLabel').textContent = 'Cancelling…';
  try { await fetch(`/api/prewarm-new-releases/cancel/${prewarmCurrentJobId}`, { method: 'POST' }); } catch {}
}

async function prewarmPoll(jobId) {
  prewarmCurrentJobId = jobId;
  try {
    const job = await (await fetch(`/api/prewarm-new-releases/status/${jobId}`)).json();
    const total = job.total || 0;
    const done  = job.done || 0;
    const pct = total ? Math.round((done / total) * 100) : (job.finished ? 100 : 0);
    document.getElementById('prewarmBar').style.width = `${pct}%`;
    document.getElementById('prewarmCount').textContent = `${done} / ${total}`;
    document.getElementById('prewarmModalCurrent').textContent = job.current_title || '';

    const phaseLabels = { resolving: 'Resolving…' };
    const labels = { starting:'Starting…', running: phaseLabels[job.phase] || 'Running…', done:'Done', cancelled:'Cancelled' };
    document.getElementById('prewarmStatusLabel').textContent = labels[job.status] || job.status;

    if (job.finished) {
      document.getElementById('prewarmCancelBtn').style.display = 'none';
      document.getElementById('prewarmCloseBtn').style.display = 'inline-flex';
      prewarmPollTimer = null;
      if (job.status === 'done') renderPrewarmResults(job);
      return;
    }
    prewarmPollTimer = setTimeout(() => prewarmPoll(jobId), 1000);
  } catch {
    prewarmPollTimer = setTimeout(() => prewarmPoll(jobId), 2000);
  }
}

function renderPrewarmResults(job) {
  const resolved  = job.resolved || [];
  const deadRemoved = job.dead_removed || [];
  const stillPh   = job.still_placeholder || [];
  document.getElementById('prewarmProgressWrap').style.display = 'none';

  const total = resolved.length + deadRemoved.length + stillPh.length;
  document.getElementById('prewarmModalTitle').textContent =
    total === 0 ? 'Nothing to prewarm' : `Resolved ${resolved.length} of ${total} new release${total !== 1 ? 's' : ''}`;
  document.getElementById('prewarmModalCurrent').textContent =
    total === 0 ? 'No new placeholder stubs within the configured window.'
    : deadRemoved.length ? `${deadRemoved.length} had no working sources and were removed.`
    : '';

  const resEl = document.getElementById('prewarmResults');
  resEl.style.display = 'block';

  const row = (title, poster, badgeLabel, badgeClass, reason) => `
    <div class="cal-entry${badgeClass === 'inlib' ? ' inlib' : ''}" style="margin-bottom:8px">
      ${poster ? `<img class="cal-poster" src="${poster}" loading="lazy">` : `<div class="cal-poster-placeholder">\uD83C\uDFAC</div>`}
      <div class="cal-info">
        <div class="cal-title">${title}</div>
        ${reason ? `<div class="cal-sub">${reason}</div>` : ''}
      </div>
      <span class="cal-badge${badgeClass === 'inlib' ? ' inlib' : ''}">${badgeLabel}</span>
    </div>`;

  let html = '';
  html += resolved.map(r => row(r.title, r.poster, 'Resolved', 'inlib')).join('');
  html += deadRemoved.map(r => row(r.title, '', 'Removed — no sources', '')).join('');
  html += stillPh.map(r => row(r.title, '', 'Still placeholder', '', r.reason)).join('');
  if (!total) {
    html = `<div style="color:var(--mut);font-size:13px;padding:12px 0">Nothing to show.</div>`;
  }
  resEl.innerHTML = html;

  if (resolved.length > 0) { loadLib(); }
}

async function spotPoll(jobId) {
  spotCurrentJobId = jobId;
  try {
    const job = await (await fetch(`/api/spot-check/status/${jobId}`)).json();
    const total = job.total || 0;
    const done  = job.done || 0;
    const pct = total ? Math.round((done / total) * 100) : (job.finished ? 100 : 0);
    document.getElementById('spotBar').style.width = `${pct}%`;
    document.getElementById('spotCount').textContent = `${done} / ${total}`;
    document.getElementById('spotModalCurrent').textContent = job.current_title || '';

    const phaseLabels = { checking: 'Checking…', fixing: 'Searching…', verifying_quality: 'Verifying quality…' };
    const statusLabels = { starting:'Starting…', running: phaseLabels[job.phase] || 'Running…', done:'Done', cancelled:'Cancelled' };
    document.getElementById('spotStatusLabel').textContent = statusLabels[job.status] || job.status;
    document.getElementById('spotModalTitle').textContent =
      job.phase === 'fixing' ? 'Searching for what\u2019s missing…'
      : job.phase === 'verifying_quality' ? 'Verifying stub quality…'
      : 'Checking your library…';

    if (job.finished) {
      document.getElementById('spotCancelBtn').style.display = 'none';
      document.getElementById('spotCloseBtn').style.display = 'inline-flex';
      spotPollTimer = null;
      if (job.status === 'done') renderSpotResults(job);
      return;
    }
    spotPollTimer = setTimeout(() => spotPoll(jobId), 1000);
  } catch {
    spotPollTimer = setTimeout(() => spotPoll(jobId), 2000);
  }
}

function renderSpotResults(job) {
  const fixedEps    = job.fixed_episodes || [];
  const missingEps  = job.still_missing_episodes || [];
  const fixedMovies = job.fixed_movies || [];
  const missingMovies = job.still_missing_movies || [];
  const qualityFixed  = job.quality_fixed || [];
  const qualityIssues = job.quality_unresolved || [];
  document.getElementById('spotProgressWrap').style.display = 'none';

  const fixedTotal   = fixedEps.length + fixedMovies.length + qualityFixed.length;
  const missingTotal = missingEps.length + missingMovies.length + qualityIssues.length;
  const checkedTotal = fixedTotal + missingTotal;

  document.getElementById('spotModalTitle').textContent =
    checkedTotal === 0 ? 'Nothing missing' : `Found ${fixedTotal} of ${checkedTotal} thing${checkedTotal !== 1 ? 's' : ''}`;
  document.getElementById('spotModalCurrent').textContent =
    checkedTotal === 0 ? 'Every tracked series and movie checks out.'
    : missingTotal === 0 ? 'Everything found has been fixed.'
    : `${missingTotal} still couldn't be resolved right now.`;

  const resEl = document.getElementById('spotResults');
  resEl.style.display = 'block';

  const row = (title, sub, poster, icon, fixed, reason, fixedLabel, missingLabel) => `
    <div class="cal-entry${fixed ? ' inlib' : ''}" style="margin-bottom:8px">
      ${poster ? `<img class="cal-poster" src="${poster}" loading="lazy">` : `<div class="cal-poster-placeholder">${icon}</div>`}
      <div class="cal-info">
        <div class="cal-title">${title}</div>
        <div class="cal-sub">${sub}${reason ? ` — ${reason}` : ''}</div>
      </div>
      ${fixed
        ? `<span class="cal-badge inlib">${fixedLabel || 'Found'}</span>`
        : `<span class="cal-badge">${missingLabel || 'Still missing'}</span>`}
    </div>`;

  let html = '';
  if (fixedEps.length || missingEps.length) {
    html += `<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:8px">Episodes (${fixedEps.length} found, ${missingEps.length} still missing)</div>`;
    html += fixedEps.map(e => row(e.title, `S${String(e.season).padStart(2,'0')}E${String(e.episode).padStart(2,'0')} — ${e.episode_name}`, e.poster, '\uD83D\uDCFA', true)).join('');
    html += missingEps.map(e => row(e.title, `S${String(e.season).padStart(2,'0')}E${String(e.episode).padStart(2,'0')} — ${e.episode_name}`, e.poster, '\uD83D\uDCFA', false, e.reason)).join('');
  }
  if (fixedMovies.length || missingMovies.length) {
    html += `<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin:${(fixedEps.length||missingEps.length)?'18px':'0'} 0 8px">Overdue pending movies (${fixedMovies.length} found, ${missingMovies.length} still missing)</div>`;
    html += fixedMovies.map(m => row(m.title, m.year || '', m.poster, '\uD83C\uDFAC', true)).join('');
    html += missingMovies.map(m => row(m.title, m.year || '', m.poster, '\uD83C\uDFAC', false, m.reason)).join('');
  }
  if (qualityFixed.length || qualityIssues.length) {
    const priorSections = fixedEps.length || missingEps.length || fixedMovies.length || missingMovies.length;
    html += `<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin:${priorSections?'18px':'0'} 0 8px">Quality mismatches (${qualityFixed.length} corrected, ${qualityIssues.length} unresolved)</div>`;
    html += qualityFixed.map(q => row(
      q.title, `Was labeled ${q.labeled.toUpperCase()}, stream was actually ${q.detected.toUpperCase()}`,
      q.poster, '\u26A0\uFE0F', true, null, 'Corrected'
    )).join('');
    html += qualityIssues.map(q => row(
      q.title, `Was labeled ${q.labeled.toUpperCase()}, stream was actually ${q.detected.toUpperCase()}`,
      q.poster, '\u26A0\uFE0F', false, q.reason, null, 'Unresolved'
    )).join('');
  }
  if (!checkedTotal) {
    html = `<div style="color:var(--mut);font-size:13px;padding:12px 0">Nothing to show — everything tracked is accounted for.</div>`;
  }
  resEl.innerHTML = html;

  if (fixedTotal > 0) { loadLib(); loadCalendar(); }
  if (typeof loadQualityUnavailable === 'function') loadQualityUnavailable();
}


function chip(l,v,ok){return`<div class="chip"><span class="cl">${l}</span><span class="cv ${ok?'ok':'er'}">${v}</span></div>`}

async function saveTtl() {
  const input = document.getElementById('ttlInput');
  const val = parseFloat(input.value);
  if (isNaN(val) || val < 0) {
    toast('Enter a number ≥ 0', 'er');
    return;
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active_ttl_days: val })
    });
    if (!r.ok) throw new Error('save failed');
    const saved = document.getElementById('ttlSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch {
    toast('Could not save setting', 'er');
  }
}

async function saveStreamPrefs() {
  const minGb = parseFloat(document.getElementById('minSizeGb').value) || 0;
  const maxGb = parseFloat(document.getElementById('maxSizeGb').value) || 0;
  if (minGb < 0 || maxGb < 0) {
    toast('Sizes must be ≥ 0', 'er');
    return;
  }
  if (minGb && maxGb && minGb > maxGb) {
    toast('Min size cannot be greater than max size', 'er');
    return;
  }
  const min4k = parseInt(document.getElementById('min4kCandidates').value, 10);
  if (isNaN(min4k) || min4k < 1) {
    toast('Minimum 4K sources must be at least 1', 'er');
    return;
  }
  const audio = document.getElementById('prefAudio').value
    .split(',').map(s => s.trim()).filter(Boolean);
  const excludeWords = document.getElementById('excludeWords').value
    .split(',').map(s => s.trim()).filter(Boolean);

  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        preferred_language: document.getElementById('prefLanguage').value.trim(),
        preferred_audio: audio,
        require_subtitles: document.getElementById('reqSubs').checked,
        prefer_season_packs: document.getElementById('preferPacks').checked,
        min_size_gb: minGb,
        max_size_gb: maxGb,
        exclude_words: excludeWords,
        min_4k_candidates: min4k,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('streamPrefsSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save preferences', 'er');
  }
}

async function saveAutoEpisodes() {
  const interval = parseInt(document.getElementById('autoEpInterval').value, 10);
  const retryDays = parseFloat(document.getElementById('autoEpRetryDays').value);
  if (isNaN(interval) || interval < 5) {
    toast('Check interval must be at least 5 minutes', 'er');
    return;
  }
  if (isNaN(retryDays) || retryDays < 0) {
    toast('Retry window must be ≥ 0 days', 'er');
    return;
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        auto_episodes_enabled: document.getElementById('autoEpEnabled').checked,
        auto_episodes_interval_minutes: interval,
        auto_episodes_retry_days: retryDays,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('autoEpSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function saveDeadStubCleanup() {
  const maxErrors = parseInt(document.getElementById('deadStubMaxErrors').value, 10);
  if (isNaN(maxErrors) || maxErrors < 0) {
    toast('Enter a whole number ≥ 0', 'er');
    return;
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dead_stub_max_errors: maxErrors })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('deadStubSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function saveAioPacing() {
  const maxConcurrent = parseInt(document.getElementById('aioMaxConcurrent').value, 10);
  const minInterval = parseFloat(document.getElementById('aioMinInterval').value);
  if (isNaN(maxConcurrent) || maxConcurrent < 1) {
    toast('Requests in flight must be at least 1', 'er');
    return;
  }
  if (isNaN(minInterval) || minInterval < 0) {
    toast('Minimum gap must be ≥ 0 ms', 'er');
    return;
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        aiostreams_max_concurrent: maxConcurrent,
        aiostreams_min_interval_ms: minInterval,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('aioPacingSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 3500);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function saveSpotCheckSchedule() {
  const hours = parseFloat(document.getElementById('spotIntervalHours').value);
  if (isNaN(hours) || hours < 0) {
    toast('Interval must be ≥ 0 hours', 'er');
    return;
  }
  const scope = document.getElementById('spotScheduledScope').value;
  const verifyQuality = document.getElementById('spotVerifyQuality').checked;
  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        spot_check_interval_hours: hours,
        spot_check_scheduled_scope: scope,
        spot_check_verify_quality: verifyQuality,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('spotScheduleSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function runAutoEpisodeSweepNow() {
  const resultEl = document.getElementById('autoEpSweepResult');
  resultEl.innerHTML = '<span style="color:var(--mut)">Checking tracked shows for new episodes…</span>';
  try {
    const r = await fetch('/api/auto-episodes/sweep-now', { method: 'POST' });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Sweep failed');
    if (d.skipped) {
      resultEl.innerHTML = `<span style="color:var(--mut)">Skipped (${d.skipped})</span>`;
      return;
    }
    let msg = `Checked ${d.shows_checked} show${d.shows_checked!==1?'s':''}`;
    if (d.new_stubs) msg += ` — ${d.new_stubs} new episode${d.new_stubs!==1?'s':''} stubbed`;
    else msg += ' — no new episodes found';
    if (d.pending) msg += ` (${d.pending} still waiting on a stream)`;
    resultEl.innerHTML = `<span style="color:var(--grn)">✓ ${msg}</span>`;
    if (d.new_stubs) { toast('New episodes added', 'ok'); if (typeof loadLib === 'function') loadLib(); }
  } catch (exc) {
    resultEl.innerHTML = `<span style="color:var(--red)">✕ ${exc.message}</span>`;
  }
}

function downloadBackup() {
  // Plain navigation triggers the browser's normal file-download flow and
  // picks up the Content-Disposition filename from the server response.
  window.location.href = '/api/backup';
}

async function restoreFromFile(event) {
  const file = event.target.files[0];
  event.target.value = '';   // allow re-selecting the same file later
  if (!file) return;

  const resultEl = document.getElementById('restoreResult');
  resultEl.innerHTML = '<span style="color:var(--mut)">Restoring…</span>';

  let bundle;
  try {
    const text = await file.text();
    bundle = JSON.parse(text);
  } catch {
    resultEl.innerHTML = '<span style="color:var(--red)">✕ Not a valid JSON file</span>';
    return;
  }

  const replace = document.getElementById('restoreReplace').checked;
  if (replace && !confirm('This will WIPE your current library before restoring. Continue?')) {
    resultEl.innerHTML = '';
    return;
  }

  try {
    const r = await fetch('/api/restore', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ bundle, replace })
    });
    const d = await r.json();
    if (!r.ok) {
      resultEl.innerHTML = `<span style="color:var(--red)">✕ ${d.detail || 'Restore failed'}</span>`;
      return;
    }
    const lib = d.library;
    let msg = d.settings_restored ? 'Settings restored. ' : '';
    if (lib) {
      msg += `Library: ${lib.imported} imported`;
      if (lib.skipped) msg += `, ${lib.skipped} skipped (already present)`;
      if (lib.errors && lib.errors.length) msg += `, ${lib.errors.length} error(s)`;
    }
    resultEl.innerHTML = `<span style="color:var(--grn)">✓ ${msg}</span>`;
    toast('Restore complete', 'ok');
    loadCfg();
    if (typeof loadLib === 'function') loadLib();
  } catch (exc) {
    resultEl.innerHTML = '<span style="color:var(--red)">✕ Restore request failed</span>';
  }
}

async function runTest() {
  const el = document.getElementById('tresult');
  el.innerHTML = '<span style="color:var(--mut)">Testing…</span>';
  try {
    const d = await (await fetch('/api/test')).json();

    if (d.diagnosis === 'stub') {
      el.innerHTML = `<span style="color:var(--blue)">ℹ Stub mode — AIOSTREAMS_UUID not set. Set it in docker-compose.yml to connect to your AIOStreams instance.</span>`;
      return;
    }

    if (d.ok) {
      el.innerHTML = `<span style="color:var(--grn)">✓ Connected to ${d.url}</span>
        <span style="color:var(--mut);font-size:12px;margin-left:8px">${d.direct_urls} direct streams from ${d.total_results} results</span>`;
    } else {
      const diag = {
        bad_auth:    '🔑 Wrong UUID or password — check AIOSTREAMS_UUID / AIOSTREAMS_PASSWORD',
        no_addons:   '📦 No addons installed — open AIOStreams and install Torrentio or similar',
        no_debrid:   '💳 No debrid service configured — add Real-Debrid/AllDebrid in AIOStreams Services tab',
        unreachable: '🔌 Cannot reach AIOStreams — check AIOSTREAMS_URL and that the container is running',
      }[d.diagnosis] || '';
      el.innerHTML = `<div style="color:var(--red);margin-bottom:6px">✗ ${d.error || 'Connection failed'}</div>`
        + (diag ? `<div style="color:var(--acc2);font-size:12px">${diag}</div>` : '')
        + (d.url ? `<div style="color:var(--mut);font-size:11px;margin-top:4px;font-family:monospace">${d.url}</div>` : '');
    }
  } catch(e) {
    el.innerHTML = `<span style="color:var(--red)">✗ ${e.message}</span>`;
  }
}

// ── Search ────────────────────────────────────────────────────
let srchTab = 'all', srchTimer = null, lastQuery = '';

function onSrchInput(val) {
  document.getElementById('srchClear').style.display = val ? 'block' : 'none';
  clearTimeout(srchTimer);
  if (!val.trim()) {
    showSearchEmpty();
    lastQuery = '';
    return;
  }
  srchTimer = setTimeout(() => doSearch(), 420);
}

function setTab(tab, el) {
  srchTab = tab;
  document.querySelectorAll('.srch-tab').forEach(t => t.classList.remove('on'));
  el.classList.add('on');
  if (lastQuery) doSearch();
}

function clearSearch() {
  document.getElementById('srchInput').value = '';
  document.getElementById('srchClear').style.display = 'none';
  lastQuery = '';
  showSearchEmpty();
}

function showSearchEmpty() {
  document.getElementById('srchStatus').textContent = '';
  document.getElementById('srchGrid').innerHTML = `
    <div class="srch-empty">
      
      <div class="srch-empty-title">Search for movies and series</div>
      <div class="srch-empty-sub">Powered by Cinemeta — the same source as Stremio</div>
    </div>`;
}

async function doSearch() {
  const q = document.getElementById('srchInput').value.trim();
  if (!q) return;
  lastQuery = q;

  const grid = document.getElementById('srchGrid');
  const status = document.getElementById('srchStatus');
  status.textContent = 'Searching…';

  // Skeleton placeholders matching card() dimensions
  grid.innerHTML = Array(8).fill(0).map(() =>
    `<div class="card" style="pointer-events:none">
       <div class="skel cposter"></div>
       <div class="skel cname" style="height:12px;margin-top:8px;width:80%"></div>
       <div class="skel cyear" style="height:11px;margin-top:5px;width:45%"></div>
     </div>`
  ).join('');

  // Cinemeta search: /catalog/{type}/top/search={query}.json
  const encode = encodeURIComponent(q);
  const types = srchTab === 'all'    ? ['movie','series']
              : srchTab === 'movie'  ? ['movie']
              :                        ['series'];

  try {
    const results = await Promise.all(
      types.map(t => cmFetch(`catalog/${t}/top/search=${encode}.json`)
        .then(d => (d.metas || []).map(m => ({ ...m, _type: t })))
        .catch(() => []))
    );

    // Interleave movie + series results so they mix naturally
    const merged = [];
    const arrs = results;
    const maxLen = Math.max(...arrs.map(a => a.length));
    for (let i = 0; i < maxLen; i++) {
      arrs.forEach(a => { if (a[i]) merged.push(a[i]); });
    }

    if (!merged.length) {
      status.textContent = `No results for "${q}"`;
      grid.innerHTML = `
        <div class="srch-empty">
          
          <div class="srch-empty-title">No results for "${q}"</div>
          <div class="srch-empty-sub">Try a different title or check spelling</div>
        </div>`;
      return;
    }

    const typeLabel = srchTab === 'all' ? 'movies & series'
                    : srchTab === 'movie' ? 'movies' : 'series';
    status.textContent = `${merged.length} result${merged.length !== 1 ? 's' : ''} for "${q}"`;
    grid.innerHTML = merged.map(m => card(m, m._type || 'movie')).join('');
  } catch(e) {
    status.textContent = '';
    grid.innerHTML = `<div class="srch-empty">
      <div class="srch-empty-icon">⚠️</div>
      <div class="srch-empty-title">Search failed</div>
      <div class="srch-empty-sub">${e.message}</div>
    </div>`;
    status.textContent = '';
  }
}

// ── Background scan polling ───────────────────────────────────
function pollScan(imdbId, title) {
  _bg_scans_ui.add(imdbId);
  let lastCount = 0;
  const iv = setInterval(async () => {
    try {
      const r = await fetch(`/api/scan/${imdbId}`);
      const d = await r.json();
      if (d.stubs !== lastCount) {
        lastCount = d.stubs;
        await syncStubs();
        await loadLib();
      }
      if (!d.scanning) {
        clearInterval(iv);
        _bg_scans_ui.delete(imdbId);
        toast(`"${title}" — ${d.stubs} stub${d.stubs!==1?'s':''} ready in Plex`, 'ok');
        await syncStubs();
        await loadLib();
      }
    } catch { clearInterval(iv); _bg_scans_ui.delete(imdbId); }
  }, 4000);
}

// ── Toast ─────────────────────────────────────────────────────
function toast(msg, type='ok') {
  const el=document.createElement('div');
  el.className=`toast ${type}`;
  el.textContent=msg;
  document.body.appendChild(el);
  setTimeout(()=>el.remove(), 3500);
}

// ── Init ─────────────────────────────────────────────────────
(async()=>{
  await syncStubs();
  await Promise.all([
    loadHero(),
    loadRow('rowM','catalog/movie/top.json','movie'),
    loadRow('rowS','catalog/series/top.json','series'),
  ]);
})();
setInterval(syncStubs, 5000);

// ── View All ───────────────────────────────────────────────────
// _rowCache stores items already fetched by loadRow keyed by cmPath
const _rowCache = {};

async function viewAll(title, cmPath, type) {
  // Open overlay immediately
  const ov = document.getElementById('vaOverlay');
  document.getElementById('vaTitle').textContent = title;
  document.getElementById('vaGrid').innerHTML = Array(20).fill(0).map(()=>
    `<div class="card" style="pointer-events:none">
       <div class="skel cposter"></div>
       <div class="skel cname" style="height:12px;margin-top:8px;width:80%"></div>
       <div class="skel cyear" style="height:11px;margin-top:5px;width:45%"></div>
     </div>`
  ).join('');
  ov.classList.add('open');
  ov.scrollTop = 0;

  // Fetch (or use cached) items
  let items = _rowCache[cmPath];
  if (!items) {
    try {
      const data = await cmFetch(cmPath);
      items = (data.metas || []);
      _rowCache[cmPath] = items;
    } catch(e) {
      document.getElementById('vaGrid').innerHTML =
        `<div style="color:var(--red);grid-column:1/-1;padding:20px;font-size:13px">Failed to load: ${e.message}</div>`;
      return;
    }
  }
  document.getElementById('vaGrid').innerHTML = items.map(m => card(m, type)).join('');
}

function closeViewAll() {
  document.getElementById('vaOverlay').classList.remove('open');
}

</script>

<!-- View All overlay -->
<div class="va-overlay" id="vaOverlay">
  <div class="va-inner">
    <div class="va-header">
      <button class="va-back" onclick="closeViewAll()">Back</button>
      <span class="va-title" id="vaTitle"></span>
    </div>
    <div class="va-grid" id="vaGrid"></div>
  </div>
</div>

</body>
</html>"""


@app.get("/", response_class=HTMLResponse)
async def ui():
    return HTMLResponse(UI_HTML)


# ---------------------------------------------------------------------------
# Config + test
# ---------------------------------------------------------------------------

@app.get("/api/config")
async def get_config():
    return {
        "aiostreams_url":  os.environ.get("AIOSTREAMS_URL", "http://localhost:3001"),
        "uuid_set":        bool(os.environ.get("AIOSTREAMS_UUID")),
        "password_set":    bool(os.environ.get("AIOSTREAMS_PASSWORD")),
        "library_root":    os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt"),
        "fuse": {
            "mountpoint":         os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt"),
            "block_mb":           os.environ.get("FUSE_BLOCK_MB", "8"),
            "cache_blocks":       os.environ.get("FUSE_CACHE_BLOCKS", "64"),
            "prefetch_ahead":     os.environ.get("FUSE_PREFETCH_AHEAD", "4"),
            "read_timeout":       os.environ.get("FUSE_READ_TIMEOUT", "15"),
            "max_inflight":       os.environ.get("FUSE_MAX_INFLIGHT", "12"),
            "pool_connections":   os.environ.get("FUSE_POOL_CONNECTIONS", "10"),
            "pool_maxsize":       os.environ.get("FUSE_POOL_MAXSIZE", "20"),
            "resolve_timeout":    os.environ.get("FUSE_RESOLVE_TIMEOUT", "15"),
        },
    }


@app.get("/api/settings")
async def get_settings():
    from gateway import settings as _settings
    return _settings.get_all()


class SettingsPatch(BaseModel):
    active_ttl_days:    Optional[float] = None
    preferred_language: Optional[str] = None
    preferred_audio:    Optional[list[str]] = None
    require_subtitles:  Optional[bool] = None
    exclude_words:      Optional[list[str]] = None
    min_4k_candidates:  Optional[int] = None
    prefer_season_packs: Optional[bool] = None
    spot_check_interval_hours:  Optional[float] = None
    spot_check_scheduled_scope: Optional[str] = None
    spot_check_verify_quality: Optional[bool] = None
    prewarm_new_releases_days: Optional[float] = None
    prewarm_interval_hours: Optional[float] = None
    min_size_gb:        Optional[float] = None
    max_size_gb:        Optional[float] = None
    auto_episodes_enabled:          Optional[bool] = None
    auto_episodes_interval_minutes: Optional[int] = None
    auto_episodes_retry_days:       Optional[float] = None
    dead_stub_max_errors:           Optional[int] = None
    aiostreams_max_concurrent:      Optional[int] = None
    aiostreams_min_interval_ms:     Optional[float] = None
    pending_movies_enabled:         Optional[bool] = None
    pending_movies_retry_days:      Optional[float] = None
    digital_release_delay_days:     Optional[float] = None


@app.post("/api/settings")
async def update_settings(patch: SettingsPatch):
    from gateway import settings as _settings
    data = {k: v for k, v in patch.dict().items() if v is not None}
    try:
        updated = _settings.update(data)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    logger.info("Settings updated: %s", data)
    return updated


@app.post("/api/auto-episodes/sweep-now")
async def trigger_auto_episode_sweep():
    """Manually run one auto-episode discovery sweep immediately, instead
    of waiting for the next scheduled interval. Runs even if
    auto_episodes_enabled is off, since an explicit manual trigger is a
    deliberate one-off action, not the recurring background behaviour the
    setting controls."""
    from gateway import auto_episodes as _auto_ep
    result = await _auto_ep.run_sweep(_stubs, _http, _query_episode, _yield_to_play_priority, force=True)
    logger.info("Manual auto-episode sweep: %s", result)
    return result


@app.get("/api/pending-movies")
async def list_pending_movies():
    from gateway import pending_movies as _pending_mv
    return {"items": _pending_mv.list_all()}


@app.delete("/api/pending-movies/{imdb_id}")
async def remove_pending_movie(imdb_id: str):
    from gateway import pending_movies as _pending_mv
    removed = _pending_mv.remove(imdb_id)
    if not removed:
        raise HTTPException(404, "Not in the pending list")
    return {"ok": True}


@app.post("/api/pending-movies/sweep-now")
async def trigger_pending_movies_sweep():
    """Manually retry every pending movie immediately, same deliberate
    one-off pattern as /api/auto-episodes/sweep-now."""
    from gateway import pending_movies as _pending_mv
    result = await _pending_mv.run_sweep(_query_movie, force=True, yield_fn=_yield_to_play_priority)
    logger.info("Manual pending-movie sweep: %s", result)
    return result


@app.get("/api/quality-unavailable")
async def list_quality_unavailable():
    """Everything spot check has confirmed 4K is unavailable for — see
    gateway/quality_unavailable.py. These are skipped by every automatic
    path (normal adds, background scan, auto-episode discovery, the
    pending-movies sweep, future spot checks) until manually cleared,
    either here or by a successful manual "Scan 4K"."""
    from gateway import quality_unavailable as _qu
    return {"items": _qu.list_all()}


@app.delete("/api/quality-unavailable/{key:path}")
async def clear_quality_unavailable(key: str):
    """Clears a 4K-unavailable mark without necessarily re-scanning right
    now — the item just becomes eligible for automatic 4K discovery
    again on whatever picks it up next (background scan, next spot
    check, etc). key is imdb_id for a movie, or imdb_id:season:episode
    for an episode — exactly what /api/quality-unavailable returns."""
    from gateway import quality_unavailable as _qu
    parts = key.split(":")
    imdb_id = parts[0]
    season  = int(parts[1]) if len(parts) > 1 else None
    episode = int(parts[2]) if len(parts) > 2 else None
    removed = _qu.unmark(imdb_id, season, episode)
    if not removed:
        raise HTTPException(404, "Not marked as 4K-unavailable")
    return {"ok": True}


# ---------------------------------------------------------------------------
# Backup / restore — settings + library (stub metadata)
# ---------------------------------------------------------------------------

import datetime as _dt

BACKUP_FORMAT_VERSION = 2

@app.get("/api/backup")
async def create_backup():
    """
    Returns a single JSON bundle containing current settings, library, and
    connection config (AIOStreams URL/UUID/password, Plex URL/token).

    SECURITY NOTE: the connection config block contains real secrets
    (AIOSTREAMS_PASSWORD, PLEX_TOKEN) in plaintext. These can't be restored
    automatically into a running container — env vars are fixed at container
    start, so restore only displays them back for you to paste into
    docker-compose.yml yourself before a restart. Anyone with this file has
    full access to both services; store/share it accordingly.

    Deliberately excludes live resolve state (stream_url/headers/size) —
    a restored library comes back as fresh stubs that re-resolve on next
    play, since old CDN links would likely be expired anyway.
    """
    from gateway import settings as _settings
    bundle = {
        "format_version": BACKUP_FORMAT_VERSION,
        "created_at":     _dt.datetime.now(_dt.timezone.utc).isoformat(),
        "settings":       _settings.get_all(),
        "library":        _stubs.export_all(),
        "connection": {
            "aiostreams_url":      os.environ.get("AIOSTREAMS_URL", ""),
            "aiostreams_uuid":     os.environ.get("AIOSTREAMS_UUID", ""),
            "aiostreams_password": os.environ.get("AIOSTREAMS_PASSWORD", ""),
            "plex_url":            os.environ.get("PLEX_URL", ""),
            "plex_token":          os.environ.get("PLEX_TOKEN", ""),
        },
    }
    filename = f"aiogateway-backup-{_dt.datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    return JSONResponse(
        content=bundle,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


class RestoreReq(BaseModel):
    bundle:  dict
    replace: bool = False   # False = merge (skip existing), True = wipe library first


@app.post("/api/restore")
async def restore_backup(req: RestoreReq):
    """
    Restore settings and/or library from a previously downloaded backup
    bundle. Settings are always applied if present (last-write-wins on
    each key). Library stubs are imported as fresh PLACEHOLDERs — replace
    controls whether the current library is wiped first or merged into.
    """
    from gateway import settings as _settings
    bundle = req.bundle

    if not isinstance(bundle, dict) or "format_version" not in bundle:
        raise HTTPException(400, "Not a valid AIOGateway backup file")

    results = {"settings_restored": False, "library": None}

    settings_data = bundle.get("settings")
    if isinstance(settings_data, dict) and settings_data:
        try:
            _settings.update(settings_data)
            results["settings_restored"] = True
        except ValueError as exc:
            raise HTTPException(400, f"Invalid settings in backup: {exc}")

    library_data = bundle.get("library")
    if isinstance(library_data, list):
        import_result = await _stubs.import_all(library_data, replace=req.replace)
        results["library"] = import_result
        logger.info("Restore: %s", import_result)

    return results


@app.get("/api/test")
async def test_connection():
    return await _client.connection_test()


# ---------------------------------------------------------------------------
# Add media — movies and series (series only stubs aired episodes with streams)
# ---------------------------------------------------------------------------

import asyncio as _asyncio
from datetime import datetime, timezone as _tz

class AddReq(BaseModel):
    imdb_id:    str
    title:      str
    year:       Optional[int] = None
    media_type: str = "movie"
    season:     Optional[int] = None        # None = all seasons
    seasons:    Optional[list[int]] = None  # takes priority over `season` when set — multiple specific seasons in one call
    episode:    Optional[int] = None        # None = all episodes
    poster:     Optional[str] = None


def _is_aired(released: Optional[str]) -> bool:
    """True if episode released date exists and is in the past."""
    if not released:
        return False
    try:
        dt = datetime.fromisoformat(released.replace("Z", "+00:00"))
        return dt <= datetime.now(_tz.utc)
    except Exception:
        return False


def _extract_year(value) -> Optional[int]:
    """
    Extract a clean 4-digit start year from a Cinemeta "year" or
    "releaseInfo" value, which can come back as a plain int (1994), a
    plain year string ("1994"), or — very commonly for SERIES, including
    ongoing ones — a range string like "2024-2026" or "2024-" (open-ended,
    still airing). Using such a value directly as a folder-name suffix
    previously produced folders literally named "(2024-)" instead of
    "(2024)". This always returns just the leading 4 digits, or None if
    nothing parseable is found.
    """
    if value is None:
        return None
    if isinstance(value, int):
        return value
    m = re.match(r"(\d{4})", str(value))
    return int(m.group(1)) if m else None


async def _movie_release_dt(imdb_id: str):
    """Returns the movie's Cinemeta `released` date as an aware datetime, or
    None if unknown/unparseable. Reuses the same cached Cinemeta fetch the
    calendar uses (see _cinemeta_cached), so this doesn't cost an extra
    request beyond what's already being fetched/cached elsewhere."""
    from datetime import datetime, timezone as _tz
    try:
        meta = await _cinemeta_cached("movie", imdb_id)
    except Exception as exc:
        logger.warning("Could not fetch release date for %s: %s", imdb_id, exc)
        return None
    released = meta.get("released")
    if not released:
        return None
    try:
        dt = datetime.fromisoformat(released.replace("Z", "+00:00"))
        if not dt.tzinfo:
            dt = dt.replace(tzinfo=_tz.utc)
        return dt
    except Exception:
        return None


async def _movie_searchable_at(imdb_id: str):
    """
    Returns the datetime a movie should first be searched at all — the
    Cinemeta theatrical release date plus digital_release_delay_days.
    None if the release date itself is unknown (in which case there's
    nothing to delay against, so callers should just search normally).

    This is a heuristic, not an exact digital-release check: there's no
    reliable free API for the actual digital/VOD date, which varies a lot
    by title and studio. The delay is the practical way to cut down on
    catching pre-digital cam/TS leaks before they'd normally show up on
    debrid — see the exclude_words setting for the complementary,
    per-result-filename version of this same problem.
    """
    from datetime import timedelta
    from gateway import settings as _settings
    released_dt = await _movie_release_dt(imdb_id)
    if not released_dt:
        return None
    delay_days = _settings.get("digital_release_delay_days", 0) or 0
    return released_dt + timedelta(days=delay_days) if delay_days else released_dt


async def _add_movie(req: AddReq) -> dict:
    # Don't even search yet if the movie hasn't reached its (theatrical +
    # digital delay) searchable date — anything that shows up this early
    # is essentially always a low-quality cam/TS/screener leak (see the
    # exclude_words setting), not a real encode. Skip the AIOStreams query
    # entirely and just track it as pending — same "keep checking
    # automatically" flow as a movie that's past that date but genuinely
    # has nothing available yet.
    from datetime import datetime, timezone as _tz
    searchable_at = await _movie_searchable_at(req.imdb_id)
    if searchable_at and searchable_at > datetime.now(_tz.utc):
        from gateway import pending_movies as _pending_mv
        await _pending_mv.add(req.imdb_id, req.title, req.year, req.poster or "")
        return {
            "media_id": req.imdb_id, "title": req.title, "media_type": "movie",
            "pending": True, "not_released_yet": True,
            "streams_found": 0, "has_4k": False,
            "episodes_with_streams": 0, "episodes_no_streams": 0,
            "episodes_future": 0, "episodes_skipped": 0,
            "stubs_created": [],
        }

    item = MediaItem(
        id=req.imdb_id, imdb_id=req.imdb_id, title=req.title,
        year=req.year, media_type=MediaType.MOVIE,
    )
    item._poster = req.poster or ""
    item.streams = await _client.resolve_all(item)
    if not item.streams:
        # Not resolvable right now — most commonly nothing's cached at the
        # debrid backend yet (release date already checked above). Track it
        # instead of failing outright: the pending-movies sweep (gateway/
        # pending_movies.py) retries it automatically on the same schedule
        # as the auto-episode sweep until a stream shows up, the same
        # "keep checking" philosophy already used for not-yet-aired
        # episodes.
        from gateway import pending_movies as _pending_mv
        await _pending_mv.add(req.imdb_id, req.title, req.year, req.poster or "")
        return {
            "media_id": item.id, "title": item.title, "media_type": "movie",
            "pending": True, "streams_found": 0, "has_4k": False,
            "episodes_with_streams": 0, "episodes_no_streams": 0,
            "episodes_future": 0, "episodes_skipped": 0,
            "stubs_created": [],
        }
    stubs = await _stubs.create_stubs(item)
    return {
        "media_id": item.id, "title": item.title, "media_type": "movie",
        "pending": False,
        "streams_found": len(item.streams), "has_4k": item.has_4k,
        "episodes_with_streams": 0, "episodes_no_streams": 0,
        "episodes_future": 0, "episodes_skipped": 0,
        "stubs_created": [{"stub_id": s.stub_id, "quality": s.quality.value, "path": s.abs_path} for s in stubs],
    }


async def _query_movie(imdb_id: str, title: str, year, poster: str) -> bool:
    """Used by the pending-movies sweep to retry one tracked movie. Returns
    True if it now has a stub (streams were found), False otherwise."""
    from datetime import datetime, timezone as _tz
    searchable_at = await _movie_searchable_at(imdb_id)
    if searchable_at and searchable_at > datetime.now(_tz.utc):
        return False   # still inside the theatrical/digital delay window — don't waste a query, stays pending

    item = MediaItem(id=imdb_id, imdb_id=imdb_id, title=title, year=year, media_type=MediaType.MOVIE)
    item._poster = poster or ""
    try:
        item.streams = await _client.resolve_all(item)
    except Exception as exc:
        logger.warning("Pending movie resolve failed for %s: %s", imdb_id, exc)
        return False
    if not item.streams:
        return False
    await _stubs.create_stubs(item)
    return True


# Active background scans: imdb_id → asyncio.Task
_bg_scans: dict = {}

# ---------------------------------------------------------------------------
# Play priority: pause every background scan for the exact duration a
# Plex-triggered stub resolve is in flight, then let them resume — not a
# fixed courtesy sleep, a real pause-and-wait.
# ---------------------------------------------------------------------------
# Previously this was a single bool flag, set for the ENTIRE webhook
# handling call (including stop/pause events and the "already resolved"
# fast path that don't need any pause at all), and background loops only
# reacted to it with one fixed 1.5s sleep — which meant a scan could still
# be mid-query when Plex's playback request needed the exact same
# AIOStreams budget, and after the sleep the scan just carried on
# regardless of whether the real resolve had actually finished.
#
# This is a proper readers-writers pattern instead: a play-triggered
# resolve calls _play_priority_enter()/_exit() (via webhook/handler.py,
# scoped to just the _resolve() call, not the whole webhook), and every
# background loop (series scans, auto-episode discovery, pending-movie
# retries, migration, spot check) calls _yield_to_play_priority() before
# each per-item AIOStreams query — which now genuinely blocks until the
# resolve is done, not just once, and resumes immediately after rather
# than on a fixed timer. A counter (not a bool) handles the case where
# more than one play event resolves at once.
_play_priority_count = 0
_play_priority_clear = _asyncio.Event()
_play_priority_clear.set()   # nothing in flight yet — scans may proceed


def _play_priority_enter() -> None:
    global _play_priority_count
    _play_priority_count += 1
    _play_priority_clear.clear()


def _play_priority_exit() -> None:
    global _play_priority_count
    _play_priority_count = max(0, _play_priority_count - 1)
    if _play_priority_count == 0:
        _play_priority_clear.set()


async def _yield_to_play_priority():
    """Called by every background loop before each AIOStreams query. Blocks
    here — for as long as it takes, not a fixed sleep — while a
    play-triggered resolve is in flight, then returns immediately once
    it's done."""
    await _play_priority_clear.wait()


async def _query_episode(
    imdb_id: str, show_title: str, year, poster: str,
    v: dict, sem: "_asyncio.Semaphore"
) -> tuple:
    """
    Query AIOStreams for one episode. Returns (stubbed, has_4k, pack_info).

    pack_info is (pack_kind, pack_season) — detect_pack_type() run on
    whichever stream actually got used for the HD stub — ('episode', None)
    if not stubbed, or if the winning stream isn't pack-derived at all.
    Callers use this to fast-track the rest of a season when a pack shows
    up — see _fast_track_pack_season.
    """
    s_num = v.get("season")
    e_num = v.get("number")
    if s_num is None or e_num is None:
        return False, False, ('episode', None)

    async with sem:
        item = MediaItem(
            id=f"{imdb_id}_s{s_num}e{e_num}", imdb_id=imdb_id,
            title=show_title, show_title=show_title, episode_title="",
            year=year, media_type=MediaType.SERIES,
            season=s_num, episode=e_num,
        )
        streams = []
        for attempt in range(1, 5):
            try:
                streams = await _client.resolve_all(item)
                break
            except Exception as exc:
                exc_str = str(exc)
                is_429  = "429" in exc_str
                if attempt < 4:
                    wait = (attempt * 5) if is_429 else (attempt * 2)
                    logger.warning(
                        "S%02dE%02d attempt %d/4 — %s — retrying in %ds",
                        s_num, e_num, attempt,
                        "rate limited (429)" if is_429 else exc_str[:60], wait
                    )
                    await _asyncio.sleep(wait)
                else:
                    logger.warning("S%02dE%02d all 4 attempts failed", s_num, e_num)
                    return False, False, ('episode', None)

        if not streams:
            return False, False, ('episode', None)

        item.streams = streams
        item._poster = poster
        stubs = await _stubs.create_stubs(item)
        q = " +4K" if item.has_4k else ""
        logger.info("S%02dE%02d: stubbed%s", s_num, e_num, q)

        winning = item.best_stream(Quality.HD)
        pack_info = winning.pack_type if winning else ('episode', None)

        return True, item.has_4k, pack_info


async def _fast_track_pack_season(
    imdb_id: str, show_title: str, year, poster: str,
    season: int, videos: list, already_stubbed: set
) -> set:
    """
    Called when an episode resolves via a season/series pack — since a
    pack, once debrid-cached, usually resolves the rest of its season
    quickly too (same underlying cached torrent, not a fresh scrape), this
    immediately tries every other aired-but-unstubbed episode in that
    season right away, instead of waiting through the slower multi-pass
    background scan built for genuinely hard-to-find content.

    This does NOT skip any AIOStreams queries or guess at a pack's
    contents — every episode here is still resolved through the exact
    same safe per-episode query (imdb_id:season:episode) as always, so
    there's no risk of mislabeling an episode. "Verifying the pack" means
    checking, after each of those normal queries resolves, whether the
    winning stream is ALSO detected as part of the same season/series
    pack — confirming it's genuinely from the pack rather than just
    coincidentally available. Episodes that resolve via some other,
    non-pack source are still stubbed (a real stream is a real stream),
    just not counted as pack-confirmed.

    Every request still goes through the same global AIOStreams rate gate
    as everything else — this doesn't bypass that, it just skips the
    EXTRA local courtesy pacing/multi-pass retry structure _scan_series_bg
    normally adds on top, since a debrid-cached pack is expected to
    resolve quickly and doesn't need that same patience.

    Returns the set of (season, episode) keys stubbed here, so the caller
    can exclude them from any further processing.
    """
    targets = [
        v for v in videos
        if v.get("season") == season and v.get("number") is not None
        and _is_aired(v.get("released"))
        and (season, v.get("number")) not in already_stubbed
    ]
    if not targets:
        return set()

    logger.info(
        "Season %d of %s: pack detected — fast-tracking %d remaining episode(s)",
        season, imdb_id, len(targets)
    )

    sem = _asyncio.Semaphore(1)
    stubbed_keys = set()
    pack_confirmed = 0

    for v in targets:
        await _yield_to_play_priority()
        try:
            stubbed, _, pack_info = await _query_episode(imdb_id, show_title, year, poster, v, sem)
        except Exception as exc:
            logger.warning("Pack fast-track: S%02dE%02d failed: %s",
                          season, v.get("number"), exc)
            continue
        if stubbed:
            ep_num = v.get("number")
            stubbed_keys.add((season, ep_num))
            pack_kind, pack_season = pack_info
            if pack_kind in ("season", "series") and (pack_kind == "series" or pack_season == season):
                pack_confirmed += 1

    logger.info(
        "Season %d of %s: fast-track complete — %d/%d stubbed (%d confirmed from the pack)",
        season, imdb_id, len(stubbed_keys), len(targets), pack_confirmed
    )
    return stubbed_keys


async def _scan_series_bg(
    imdb_id: str, show_title: str, year, poster: str,
    candidates: list, skip_keys: set, known_pack_season: Optional[int] = None
) -> None:
    """
    Background task — sequential scan with 1s delay, repeated up to 3 passes
    until no new episodes are found. Each pass only retries episodes that
    previously returned no streams, ensuring all cached episodes are captured
    even when AIOStreams is inconsistent.

    known_pack_season: if the fast-path E01 query (in _add_series) already
    came back as a season/series pack, its season number is passed in here
    so the fast-track kicks in immediately, before pass 1 even starts,
    rather than waiting to organically rediscover the pack on whichever
    episode happens to run first in the normal loop.
    """
    # Track which episodes already have stubs
    def _already_stubbed(v: dict) -> bool:
        s = v.get("season"); e = v.get("number")
        return (s, e) in skip_keys or any(
            st.imdb_id == imdb_id and
            st.aiostreams_id == f"{imdb_id}:{s}:{e}"
            for st in _stubs.all()
        )

    remaining = [v for v in candidates if not _already_stubbed(v)]
    if not remaining:
        logger.info("BG scan %s: nothing to do", imdb_id)
        _bg_scans.pop(imdb_id, None)
        return

    logger.info("BG scan %s: %d episodes to check", imdb_id, len(remaining))
    sem        = _asyncio.Semaphore(1)
    total_found = 0
    pack_fast_tracked_seasons: set = set()   # avoid re-triggering fast-track for the same season twice

    if known_pack_season is not None:
        pack_fast_tracked_seasons.add(known_pack_season)
        already = set(skip_keys) | {
            (st.season, st.episode) for st in _stubs.all()
            if st.imdb_id == imdb_id and st.season is not None
        }
        fast_keys = await _fast_track_pack_season(
            imdb_id, show_title, year, poster, known_pack_season, candidates, already
        )
        total_found += len(fast_keys)
        remaining = [v for v in remaining if (v.get("season"), v.get("number")) not in fast_keys]
        if not remaining:
            logger.info("BG scan %s complete: %d total episodes stubbed (all via pack fast-track)",
                       imdb_id, total_found)
            _bg_scans.pop(imdb_id, None)
            return

    for pass_num in range(1, 4):   # up to 3 passes
        no_stream_this_pass = []
        found_this_pass     = 0
        skip_in_this_pass: set = set()   # (season, episode) keys handled mid-pass via fast-track

        logger.info("BG scan %s pass %d/%d: checking %d episodes",
                    imdb_id, pass_num, 3, len(remaining))

        for v in remaining:
            key = (v.get("season"), v.get("number"))
            if key in skip_in_this_pass:
                continue

            await _yield_to_play_priority()
            try:
                stubbed, _, pack_info = await _query_episode(
                    imdb_id, show_title, year, poster, v, sem
                )
                if stubbed:
                    found_this_pass += 1
                    total_found     += 1

                    pack_kind, _pack_season = pack_info
                    season = v.get("season")
                    if pack_kind in ("season", "series") and season not in pack_fast_tracked_seasons:
                        pack_fast_tracked_seasons.add(season)
                        already = {key} | {
                            (st.season, st.episode) for st in _stubs.all()
                            if st.imdb_id == imdb_id and st.season is not None
                        }
                        fast_keys = await _fast_track_pack_season(
                            imdb_id, show_title, year, poster, season, candidates, already
                        )
                        for fk in fast_keys:
                            skip_in_this_pass.add(fk)
                        found_this_pass += len(fast_keys)
                        total_found     += len(fast_keys)
                else:
                    no_stream_this_pass.append(v)
            except Exception as exc:
                logger.warning("BG scan episode error: %s", exc)
                no_stream_this_pass.append(v)
            await _asyncio.sleep(1.0)   # 1s between each query

        # Anything the mid-pass fast-track already picked up shouldn't be
        # retried again in the next pass.
        no_stream_this_pass = [
            v for v in no_stream_this_pass
            if (v.get("season"), v.get("number")) not in skip_in_this_pass
        ]

        logger.info("BG scan %s pass %d done: %d new stubs, %d still missing",
                    imdb_id, pass_num, found_this_pass, len(no_stream_this_pass))

        if not no_stream_this_pass:
            break   # everything found — no need for another pass

        remaining = no_stream_this_pass

        if pass_num < 3:
            # Wait a bit longer before the next pass
            wait = pass_num * 5
            logger.info("BG scan %s: waiting %ds before pass %d",
                        imdb_id, wait, pass_num + 1)
            await _asyncio.sleep(wait)

    if remaining:
        logger.info("BG scan %s: %d episode(s) had no streams after 3 passes: %s",
                    imdb_id, len(remaining),
                    [f"S{v.get('season'):02d}E{v.get('number'):02d}" for v in remaining])

    logger.info("BG scan %s complete: %d total episodes stubbed", imdb_id, total_found)
    _bg_scans.pop(imdb_id, None)


async def _add_series(req: AddReq) -> dict:
    """
    Fast path: query E01 immediately, return as soon as stub is created.
    Background task scans all remaining episodes concurrently.
    """
    try:
        async with _http.get(
            f"https://v3-cinemeta.strem.io/meta/series/{req.imdb_id}.json",
            headers={"User-Agent": "AIOGateway/0.3"},
            timeout=aiohttp.ClientTimeout(total=20),
        ) as resp:
            data = await resp.json(content_type=None)
    except Exception as exc:
        raise HTTPException(502, f"Cinemeta fetch failed: {exc}")

    meta   = data.get("meta") or {}
    videos = meta.get("videos") or []
    if not videos:
        raise HTTPException(404, f"No episode data found for {req.imdb_id}")

    poster     = req.poster or meta.get("poster") or ""
    show_title = req.title

    # Always resolve a year server-side rather than trusting the request to
    # supply one consistently. A missing/None year produces a folder name
    # with no "(Year)" suffix — and since the same show gets re-added via
    # several different UI flows (initial add, rescan, per-season request),
    # any one of them omitting the year fragments the show into two
    # differently-named folders for the same series.
    year = req.year
    if not year:
        # Cinemeta's meta endpoint returns "year" directly; releaseInfo is
        # a fallback for older/alternate response shapes. Both can be range
        # strings ("2024-2026" or open-ended "2024-") — _extract_year always
        # pulls just the leading 4 digits.
        year = _extract_year(meta.get("year")) or _extract_year(meta.get("releaseInfo"))
        if year:
            logger.info("Series %s: request had no year, using Cinemeta's %s",
                       req.imdb_id, year)

    if not year:
        # Cinemeta gave nothing usable — fall back to any existing stub for
        # this same show, so a rescan/season-request never accidentally
        # creates a second, differently-named folder just because this one
        # response happened to omit year data.
        existing = next((s for s in _stubs.all() if s.imdb_id == req.imdb_id and s.year), None)
        if existing:
            year = existing.year
            logger.info("Series %s: Cinemeta had no year, reusing %s from existing stub",
                       req.imdb_id, year)

    if not year:
        raise HTTPException(
            502,
            f"Could not determine release year for {req.imdb_id} — refusing to create "
            "stubs that would land in a differently-named folder than the rest of this "
            "show. Try again shortly."
        )

    aired_all  = [v for v in videos if _is_aired(v.get("released"))]
    future_cnt = len(videos) - len(aired_all)

    candidates = aired_all
    if req.seasons is not None:
        wanted_seasons = set(req.seasons)
        candidates = [v for v in candidates if v.get("season") in wanted_seasons]
    elif req.season is not None:
        candidates = [v for v in candidates if v.get("season") == req.season]
    if req.episode is not None:
        candidates = [v for v in candidates if v.get("number") == req.episode]

    if not candidates:
        raise HTTPException(404, f"No aired episodes found. {future_cnt} not yet released.")

    # Sort so E01 of lowest season is first
    candidates.sort(key=lambda v: (v.get("season") or 0, v.get("number") or 0))

    logger.info("Series %s '%s': fast E01 + bg scan %d eps",
                req.imdb_id, show_title, len(candidates))

    # Query first episode immediately
    sem_one = _asyncio.Semaphore(1)
    stubbed, has_4k, pack_info = await _query_episode(
        req.imdb_id, show_title, year, poster, candidates[0], sem_one
    )
    fast_key = (candidates[0].get("season"), candidates[0].get("number"))

    # Only skip E01 in the background scan if it was actually stubbed
    skip_keys = {fast_key} if stubbed else set()

    # If E01 came back as a season/series pack, seed the background scan
    # with that so it fast-tracks the rest of the season immediately
    # instead of waiting to organically rediscover the pack later.
    pack_kind, _pack_season = pack_info
    known_pack_season = fast_key[0] if (stubbed and pack_kind in ("season", "series")) else None

    # Cancel any existing scan and start a new one for all remaining episodes
    if req.imdb_id in _bg_scans:
        _bg_scans[req.imdb_id].cancel()
    task = _asyncio.create_task(
        _scan_series_bg(req.imdb_id, show_title, year, poster, candidates, skip_keys, known_pack_season)
    )
    _bg_scans[req.imdb_id] = task

    return {
        "media_id":    req.imdb_id,
        "title":       req.title,
        "media_type":  "series",
        "streams_found": 1 if stubbed else 0,
        "has_4k":      has_4k,
        "scanning":    True,
        "total_candidates": len(candidates),
        "stubs_created": [],
    }


@app.post("/api/add")
async def add_media(req: AddReq):
    try:
        if req.media_type == "movie":
            return await _add_movie(req)
        else:
            return await _add_series(req)
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Add failed: %s", exc)
        raise HTTPException(502, str(exc))

# ---------------------------------------------------------------------------
# Migrate (Radarr/Sonarr)
# ---------------------------------------------------------------------------

from gateway import migrate_client as _migrate

_migrate_jobs: dict[str, dict] = {}          # job_id → progress state, see start_migration()
_migrate_tasks: dict[str, "asyncio.Task"] = {}   # job_id → the running task, so cancel can actually interrupt it

# One Radarr/Sonarr library snapshot per service, shared between "Load
# library" (preview) and "Start migration" (run) so a migration only ever
# costs Radarr/Sonarr a single /api/v3/movie or /api/v3/series call — not
# one for the preview and another when the run kicks off, which is what
# was happening before this cache existed. Cleared once the migration job
# that used it finishes, so the next "Load library" click always gets a
# fresh read rather than serving stale data indefinitely.
_migrate_cache: dict[str, list[dict]] = {}
_MIGRATE_CACHE_MAX_AGE = 3600   # safety net: don't serve a snapshot older than this even mid-session
_migrate_cache_fetched_at: dict[str, float] = {}


async def _get_migrate_items(service: str, url: str, key: str) -> list[dict]:
    """Returns this service's movie/series list, fetching from Radarr/Sonarr
    only if nothing cached (or the cache is stale). Callers get their own
    deep copy so annotating it (e.g. in_library flags) never corrupts the
    shared cache for the next caller."""
    cached = _migrate_cache.get(service)
    fetched_at = _migrate_cache_fetched_at.get(service, 0)
    if cached is not None and (time.time() - fetched_at) < _MIGRATE_CACHE_MAX_AGE:
        return copy.deepcopy(cached)

    if service == "radarr":
        items = await _migrate.fetch_radarr_movies(url, key)
    else:
        items = await _migrate.fetch_sonarr_series(url, key)

    _migrate_cache[service] = items
    _migrate_cache_fetched_at[service] = time.time()
    return copy.deepcopy(items)


def _clear_migrate_cache(service: str) -> None:
    _migrate_cache.pop(service, None)
    _migrate_cache_fetched_at.pop(service, None)


def _migrate_service_settings(service: str) -> tuple[str, str]:
    from gateway import settings as _settings
    s = _settings.get_all()
    return s.get(f"{service}_url", ""), s.get(f"{service}_api_key", "")


class MigrateSettingsReq(BaseModel):
    service: str                       # "radarr" | "sonarr"
    url:     str
    api_key: Optional[str] = None      # omitted/blank keeps whatever key is already saved


@app.get("/api/migrate/settings")
async def get_migrate_settings():
    from gateway import settings as _settings
    s = _settings.get_all()
    return {
        "radarr_url":        s.get("radarr_url", ""),
        "radarr_configured": bool(s.get("radarr_api_key")),
        "sonarr_url":        s.get("sonarr_url", ""),
        "sonarr_configured": bool(s.get("sonarr_api_key")),
    }


@app.post("/api/migrate/settings")
async def save_migrate_settings(req: MigrateSettingsReq):
    from gateway import settings as _settings
    if req.service not in ("radarr", "sonarr"):
        raise HTTPException(400, "service must be 'radarr' or 'sonarr'")
    patch = {f"{req.service}_url": req.url}
    if req.api_key:
        patch[f"{req.service}_api_key"] = req.api_key
    try:
        _settings.update(patch)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    _clear_migrate_cache(req.service)
    return {"ok": True}


class MigrateTestReq(BaseModel):
    service: str


@app.post("/api/migrate/test")
async def test_migrate_connection(req: MigrateTestReq):
    if req.service not in ("radarr", "sonarr"):
        raise HTTPException(400, "service must be 'radarr' or 'sonarr'")
    url, key = _migrate_service_settings(req.service)
    if not url or not key:
        raise HTTPException(400, f"Set the {req.service.title()} URL and API key first")
    try:
        return await _migrate.test_connection(url, key, req.service)
    except _migrate.MigrateAPIError as exc:
        raise HTTPException(502, str(exc))


@app.get("/api/migrate/preview")
async def preview_migrate(service: str):
    if service not in ("radarr", "sonarr"):
        raise HTTPException(400, "service must be 'radarr' or 'sonarr'")
    url, key = _migrate_service_settings(service)
    if not url or not key:
        raise HTTPException(400, f"Set the {service.title()} URL and API key first")

    try:
        items = await _get_migrate_items(service, url, key)
        if service == "radarr":
            have = {s.imdb_id for s in _stubs.all() if s.media_type == MediaType.MOVIE}
            for it in items:
                it["in_library"] = it["imdb_id"] in have
        else:
            have_seasons: dict[str, set] = {}
            for s in _stubs.all():
                if s.media_type == MediaType.SERIES and s.season is not None:
                    have_seasons.setdefault(s.imdb_id, set()).add(s.season)
            for it in items:
                already = have_seasons.get(it["imdb_id"], set())
                for season in it["seasons"]:
                    season["in_library"] = season["season_number"] in already
                it["in_library"] = all(sn["in_library"] for sn in it["seasons"])
    except _migrate.MigrateAPIError as exc:
        raise HTTPException(502, str(exc))

    return {"service": service, "items": items}


class MigrateRunReq(BaseModel):
    service:       str
    imdb_ids:      Optional[list[str]] = None   # None = migrate everything found
    skip_existing: bool = True


_MIGRATE_CONCURRENCY = 3   # AIOStreams requests allowed in flight at once during migration


async def _add_with_429_retry(kind: str, req: "AddReq", job: dict, label: str):
    """
    Bulk migration fires far more AIOStreams requests than the normal
    one-at-a-time "Add to Plex" click ever does, so it's much more likely
    to outrun AIOStreams' own rate limit — as seen in practice, a large
    library migration can 429 on nearly every item. Retry a 429 a few
    times with real backoff before giving up on that item; anything else
    (404/no results, etc.) is passed straight through to the caller —
    see _add_with_retry, which handles that case separately.
    """
    for attempt, wait in enumerate((0, 5, 15, 30, 60)):
        if wait:
            job["errors_transient"] = job.get("errors_transient", 0) + 1
            logger.warning("[migrate] %s: rate limited, retrying in %ds (attempt %d/5)",
                           label, wait, attempt + 1)
            await asyncio.sleep(wait)
        try:
            if kind == "movie":
                return await _add_movie(req)
            return await _add_series(req)
        except Exception as exc:
            is_429 = "429" in str(exc) or "Too Many Requests" in str(exc)
            if not is_429 or attempt == 4:
                raise



async def _run_migration(job_id: str, service: str, imdb_ids: Optional[list], skip_existing: bool):
    job = _migrate_jobs[job_id]
    try:
        url, key = _migrate_service_settings(service)
        try:
            items = await _get_migrate_items(service, url, key)
        except _migrate.MigrateAPIError as exc:
            job["status"] = "error"
            job["errors"].append(str(exc))
            return

        if imdb_ids is not None:
            wanted = set(imdb_ids)
            items = [it for it in items if it["imdb_id"] in wanted]

        have_movie = {s.imdb_id for s in _stubs.all() if s.media_type == MediaType.MOVIE}
        have_seasons: dict[str, set] = {}
        for s in _stubs.all():
            if s.media_type == MediaType.SERIES and s.season is not None:
                have_seasons.setdefault(s.imdb_id, set()).add(s.season)

        # ONE work item per movie, and — importantly — ONE work item per
        # series covering every season Sonarr has that isn't already
        # stubbed, not one item per season. _add_series only synchronously
        # resolves the first episode of the earliest requested season and
        # hands the rest to a background scan; batching every wanted
        # season into a single call means one fast resolve gets the whole
        # show moving, instead of the previous approach of calling
        # _add_series once per season and having to block for up to 15
        # minutes between each so the next season's call didn't cancel the
        # previous one's still-running background scan (_bg_scans is keyed
        # per imdb_id — two overlapping calls for the SAME show step on
        # each other, but one call already covering every season sidesteps
        # that entirely).
        work = []
        if service == "radarr":
            for it in items:
                if skip_existing and it["imdb_id"] in have_movie:
                    continue
                work.append(("movie", it, None))
        else:
            for it in items:
                already = have_seasons.get(it["imdb_id"], set())
                wanted_seasons = [
                    s2["season_number"] for s2 in it["seasons"]
                    if not (skip_existing and s2["season_number"] in already)
                ]
                if wanted_seasons:
                    work.append(("series", it, wanted_seasons))

        job["total"]  = len(work)
        job["status"] = "running"

        # Bounded concurrency instead of one item at a time with a fixed
        # delay between each — the 429 retry above already backs off
        # reactively when AIOStreams actually asks us to slow down, so a
        # small worker pool gets real throughput on the common case
        # (no rate limiting) while still recovering cleanly on the
        # uncommon case (it does get rate limited).
        sem = asyncio.Semaphore(_MIGRATE_CONCURRENCY)
        in_flight: dict[int, str] = {}

        def _update_current_title():
            job["current_title"] = " · ".join(in_flight.values()) if in_flight else ""

        async def _run_one(idx: int, kind: str, it: dict, seasons_or_none):
            label = (
                it["title"] if kind == "movie"
                else f"{it['title']} ({len(seasons_or_none)} season{'s' if len(seasons_or_none) != 1 else ''})"
            )
            async with sem:
                in_flight[idx] = label
                _update_current_title()
                await _yield_to_play_priority()
                try:
                    req = AddReq(
                        imdb_id=it["imdb_id"], title=it["title"], year=it.get("year"),
                        media_type=kind, poster=it.get("poster"),
                        seasons=seasons_or_none if kind == "series" else None,
                    )
                    result = await _add_with_429_retry(kind, req, job, label)
                    if isinstance(result, dict) and result.get("pending"):
                        # Not resolvable right now (commonly not released
                        # yet) — _add_movie already queued it in the
                        # pending-movies tracker rather than failing, so
                        # this isn't an error, just worth surfacing as
                        # informational.
                        job["pending_count"] = job.get("pending_count", 0) + 1
                except HTTPException as exc:
                    job["errors"].append(f"{label}: {exc.detail}")
                except Exception as exc:
                    job["errors"].append(f"{label}: {exc}")
                finally:
                    in_flight.pop(idx, None)
                    _update_current_title()
                    job["done"] += 1

        await asyncio.gather(*[
            _run_one(idx, kind, it, seasons_or_none)
            for idx, (kind, it, seasons_or_none) in enumerate(work)
        ])

        if job["status"] == "running":
            job["status"] = "done"
    except asyncio.CancelledError:
        # Task.cancel() (see cancel_migration below) raises this inside
        # whatever await was actually in flight at the moment — e.g. mid
        # AIOStreams request — which is what makes Cancel stop immediately
        # instead of only taking effect once the current item finishes.
        # Cancelling the task that's awaiting asyncio.gather() propagates
        # into every in-flight _run_one() call too, so nothing keeps
        # running in the background after cancel.
        job["status"] = "cancelled"
    finally:
        job["finished"]      = True
        job["current_title"] = ""
        _migrate_tasks.pop(job_id, None)
        _clear_migrate_cache(service)


@app.post("/api/migrate/run")
async def start_migration(req: MigrateRunReq):
    if req.service not in ("radarr", "sonarr"):
        raise HTTPException(400, "service must be 'radarr' or 'sonarr'")
    url, key = _migrate_service_settings(req.service)
    if not url or not key:
        raise HTTPException(400, f"Set the {req.service.title()} URL and API key first")

    job_id = uuid.uuid4().hex[:12]
    _migrate_jobs[job_id] = {
        "job_id": job_id, "service": req.service,
        "total": 0, "done": 0, "current_title": "",
        "status": "starting", "finished": False,
        "cancel_requested": False, "errors": [],
    }
    task = asyncio.create_task(_run_migration(job_id, req.service, req.imdb_ids, req.skip_existing))
    _migrate_tasks[job_id] = task
    return {"job_id": job_id}


@app.get("/api/migrate/status/{job_id}")
async def migrate_status(job_id: str):
    job = _migrate_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    return job


@app.post("/api/migrate/cancel/{job_id}")
async def cancel_migration(job_id: str):
    job = _migrate_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    job["cancel_requested"] = True
    task = _migrate_tasks.get(job_id)
    if task and not task.done():
        task.cancel()   # interrupts the in-flight await immediately, see _run_migration
    return {"ok": True}


# ---------------------------------------------------------------------------
# Stubs
# ---------------------------------------------------------------------------

@app.get("/api/scan/{imdb_id}")
async def scan_status(imdb_id: str):
    running = imdb_id in _bg_scans and not _bg_scans[imdb_id].done()
    count   = sum(1 for s in _stubs.all() if s.imdb_id == imdb_id)
    return {"imdb_id": imdb_id, "scanning": running, "stubs": count}


@app.get("/api/series/{imdb_id}/episodes")
async def series_episodes(imdb_id: str):
    """Full aired episode list from Cinemeta with stub status."""
    import re as _re
    try:
        async with _http.get(
            f"https://v3-cinemeta.strem.io/meta/series/{imdb_id}.json",
            headers={"User-Agent": "AIOGateway/0.3"},
            timeout=aiohttp.ClientTimeout(total=15),
        ) as resp:
            data = await resp.json(content_type=None)
    except Exception as exc:
        raise HTTPException(502, f"Cinemeta fetch failed: {exc}")

    videos = (data.get("meta") or {}).get("videos") or []

    # Build stubbed sets from aiostreams_id pattern "imdb:season:episode"
    stubbed_hd, stubbed_4k = {}, {}
    for s in _stubs.all():
        if s.imdb_id != imdb_id:
            continue
        m = _re.search(r':(\d+):(\d+)$', s.aiostreams_id)
        if m:
            key = (int(m.group(1)), int(m.group(2)))
            (stubbed_4k if s.quality == Quality.UHD else stubbed_hd)[key] = s.stub_id

    episodes = []
    for v in videos:
        sn = v.get("season"); ep = v.get("number")
        if sn is None or ep is None or sn == 0:
            continue
        key = (sn, ep)
        episodes.append({
            "season":  sn, "episode": ep,
            "name":    v.get("name") or f"S{sn:02d}E{ep:02d}",
            "aired":   _is_aired(v.get("released")),
            "has_hd":  key in stubbed_hd,
            "has_4k":  key in stubbed_4k,
            "hd_stub_id":  stubbed_hd.get(key),
            "uhd_stub_id": stubbed_4k.get(key),
        })
    return {
        "imdb_id":  imdb_id,
        "episodes": episodes,
        "scanning": imdb_id in _bg_scans and not _bg_scans[imdb_id].done(),
    }


@app.post("/api/series/{imdb_id}/episode/{season}/{episode}")
async def add_single_episode(imdb_id: str, season: int, episode: int, req: AddReq):
    """Search for and stub a single missing episode."""
    year = req.year
    if not year:
        # First fallback: reuse the year from any existing stub of this same
        # show, if one exists — avoids a network round-trip and is exactly
        # consistent with whatever folder name is already in use on disk.
        existing = next((s for s in _stubs.all() if s.imdb_id == imdb_id and s.year), None)
        if existing:
            year = existing.year
            logger.info("Episode S%02dE%02d (%s): reusing year %s from existing stub",
                       season, episode, imdb_id, year)

    if not year:
        # Second fallback: fetch from Cinemeta directly.
        try:
            async with _http.get(
                f"https://v3-cinemeta.strem.io/meta/series/{imdb_id}.json",
                headers={"User-Agent": "AIOGateway/0.3"},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                cm_meta = (await resp.json(content_type=None)).get("meta") or {}
            year = _extract_year(cm_meta.get("year")) or _extract_year(cm_meta.get("releaseInfo"))
            if year:
                logger.info("Episode S%02dE%02d (%s): request had no year, using Cinemeta's %s",
                           season, episode, imdb_id, year)
        except Exception as exc:
            logger.warning("Could not fetch fallback year from Cinemeta for %s: %s", imdb_id, exc)

    if not year:
        # Both fallbacks failed (network error + no existing stub to copy
        # from). Refuse rather than silently creating a year-less stub that
        # would fragment the show into a second, differently-named folder —
        # the caller can retry once Cinemeta is reachable again.
        raise HTTPException(
            502,
            f"Could not determine release year for {imdb_id} (Cinemeta unreachable and "
            "no existing stub to infer it from) — refusing to create a stub that would "
            "land in a differently-named folder. Try again shortly."
        )

    # Verify this specific episode has actually aired before ever touching
    # AIOStreams — every other add/scan path in the app (requestSeason,
    # the background scan, auto-episode discovery, spot check's discovery
    # phase, pack fast-track) already filters to _is_aired() episodes
    # before calling _query_episode; this endpoint was the one gap, since
    # it resolves a single specific (season, episode) directly rather than
    # iterating a pre-filtered list. A not-yet-aired episode should never
    # get a stub, full stop — anything that shows up for one this early
    # would only ever be a mismatched or bogus result, not the real thing.
    try:
        meta = await _cinemeta_cached("series", imdb_id)
        target = next(
            (v for v in (meta.get("videos") or [])
             if v.get("season") == season and v.get("number") == episode),
            None
        )
        if target is not None and not _is_aired(target.get("released")):
            raise HTTPException(
                400,
                f"S{season:02d}E{episode:02d} hasn't aired yet "
                f"({target.get('released', 'no date available')}) — refusing to search for it."
            )
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("Could not verify air date for %s S%02dE%02d, proceeding anyway: %s",
                       imdb_id, season, episode, exc)

    sem = _asyncio.Semaphore(1)
    v = {"season": season, "number": episode}
    stubbed, has_4k, pack_info = await _query_episode(
        imdb_id, req.title, year, req.poster or "", v, sem
    )
    if not stubbed:
        raise HTTPException(404, f"No streams found for S{season:02d}E{episode:02d}")

    # If this single-episode search happened to land on a season/series
    # pack, opportunistically fast-track the rest of that season in the
    # background — same reasoning as the fast-path E01 case, just
    # triggered from a manual/spot-check search instead. Doesn't block
    # this response; runs as a detached task.
    pack_kind, _pack_season = pack_info
    if pack_kind in ("season", "series"):
        try:
            meta = await _cinemeta_cached("series", imdb_id)
            videos = meta.get("videos") or []
            already = {(season, episode)} | {
                (st.season, st.episode) for st in _stubs.all()
                if st.imdb_id == imdb_id and st.season is not None
            }
            _asyncio.create_task(_fast_track_pack_season(
                imdb_id, req.title, year, req.poster or "", season, videos, already
            ))
        except Exception as exc:
            logger.warning("Could not kick off pack fast-track for %s: %s", imdb_id, exc)

    return {"stubbed": True, "has_4k": has_4k, "season": season, "episode": episode}


@app.get("/api/stubs")
async def list_stubs():
    all_s = _stubs.all()
    return {"count": len(all_s), "stubs": [
        {"stub_id": s.stub_id, "media_id": s.media_id, "title": s.title,
         "quality": s.quality.value, "state": s.state.value, "path": s.abs_path,
         "poster": getattr(s, "_poster", ""),
         "media_type": s.aiostreams_type,
         "year": s.year,
         "stream_url": (s.stream_url[:80]+"…") if s.stream_url else None}
        for s in all_s
    ]}


@app.get("/api/stubs/{stub_id}")
async def get_stub(stub_id: str):
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Not found")
    return {"stub_id": s.stub_id, "media_id": s.media_id, "title": s.title,
            "quality": s.quality.value, "state": s.state.value, "path": s.abs_path,
            "imdb_id": s.imdb_id, "aiostreams_id": s.aiostreams_id,
            "stream_url": s.stream_url, "created_at": s.created_at, "resolved_at": s.resolved_at}


# ---------------------------------------------------------------------------
# Calendar — upcoming and recent releases for tracked content
# ---------------------------------------------------------------------------


# Cinemeta cache for the calendar. Two things make this meaningfully
# faster than a plain short-lived in-memory cache:
#
# 1. Persisted to disk, so a restart doesn't throw away everything and
#    force a full cold re-fetch of every tracked title on the next load —
#    which, for a library with hundreds/thousands of tracked titles (e.g.
#    after a large Radarr/Sonarr migration), was the actual source of
#    "still slow" even with the concurrent-fetch fix from before.
#
# 2. Adaptive TTL instead of one fixed short window: a movie released
#    years ago, or a series with no upcoming/recently-aired episodes, is
#    essentially static — Cinemeta's data for it isn't going to change
#    meaningfully, so it's cached for days. Anything upcoming or recently
#    active still refreshes on the old short window, since that's exactly
#    the content whose air/release dates can actually change. Since most
#    of a large tracked library is old, already-released content, this is
#    the change that actually matters at scale — it means most calendar
#    loads do close to zero Cinemeta calls at all, not just fewer.
_calendar_meta_cache: dict[str, tuple] = {}   # "{kind}:{imdb_id}" -> (fetched_at, ttl_seconds, meta)
_CALENDAR_CACHE_SHORT_TTL = 600          # upcoming/recently-active — refresh often
_CALENDAR_CACHE_LONG_TTL  = 7 * 86400    # long-settled — essentially static


def _calendar_cache_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_calendar_cache.json"


_calendar_cache_loaded = False


def _load_calendar_cache() -> None:
    global _calendar_meta_cache, _calendar_cache_loaded
    if _calendar_cache_loaded:
        return
    path = _calendar_cache_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text())
            _calendar_meta_cache = {k: tuple(v) for k, v in raw.items()}
            logger.info("Loaded %d cached calendar title(s) from %s", len(_calendar_meta_cache), path)
    except Exception as exc:
        logger.warning("Could not load calendar cache from %s: %s", path, exc)
        _calendar_meta_cache = {}
    _calendar_cache_loaded = True


def _persist_calendar_cache() -> None:
    path = _calendar_cache_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(_calendar_meta_cache))
    except Exception as exc:
        logger.warning("Could not persist calendar cache to %s: %s", path, exc)


def _calendar_cache_ttl(kind: str, meta: dict) -> int:
    from datetime import datetime, timezone as _tz, timedelta

    def _parse(s):
        if not s: return None
        try:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            if not dt.tzinfo: dt = dt.replace(tzinfo=_tz.utc)
            return dt
        except Exception:
            return None

    now = datetime.now(_tz.utc)
    if kind == "movie":
        dt = _parse(meta.get("released"))
        if dt and dt < now - timedelta(days=60):
            return _CALENDAR_CACHE_LONG_TTL
        return _CALENDAR_CACHE_SHORT_TTL

    # series: long TTL only if every known episode aired more than two
    # weeks ago (nothing upcoming, nothing recent enough for a date to
    # still plausibly be corrected/added) — otherwise short.
    videos = meta.get("videos") or []
    has_upcoming_or_recent = any(
        (dt := _parse(v.get("released"))) and dt > now - timedelta(days=14)
        for v in videos
    )
    return _CALENDAR_CACHE_SHORT_TTL if has_upcoming_or_recent else _CALENDAR_CACHE_LONG_TTL


# How many Cinemeta requests are allowed in flight at once, SHARED across
# every caller (calendar, missing-counts, spot check) — this used to be a
# constant that each caller turned into its OWN separate Semaphore(40),
# which meant they never actually coordinated: if the calendar, the
# missing-counts endpoint, and spot check all happened to run around the
# same time, real concurrent load could hit 3×40=120 requests, not 40 —
# exactly the same class of bug already fixed once for AIOStreams. Cinemeta
# is a more tolerant service than AIOStreams, but not infinitely so; 120
# concurrent connections was enough to cause a wave of timeouts (visible as
# "failed to fetch ... :" with nothing after the colon — asyncio.TimeoutError
# stringifies to an empty string, which is why those log lines look blank).
_CALENDAR_FETCH_CONCURRENCY = 15
_cinemeta_gate = asyncio.Semaphore(_CALENDAR_FETCH_CONCURRENCY)


async def _cinemeta_cached(kind: str, imdb_id: str) -> dict:
    _load_calendar_cache()
    key = f"{kind}:{imdb_id}"
    cached = _calendar_meta_cache.get(key)
    if cached and (time.time() - cached[0]) < cached[1]:
        return cached[2]

    async with _cinemeta_gate:
        async with _http.get(
            f"https://v3-cinemeta.strem.io/meta/{kind}/{imdb_id}.json",
            headers={"User-Agent": "AIOGateway/0.3"},
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            data = await resp.json(content_type=None)
    meta = data.get("meta") or {}
    ttl  = _calendar_cache_ttl(kind, meta)
    _calendar_meta_cache[key] = (time.time(), ttl, meta)
    return meta


@app.get("/api/calendar")
async def get_calendar(days_back: int = 14, days_ahead: int = 30):
    """
    Returns calendar entries for all tracked movies and series episodes
    releasing within [days_back, days_ahead] of today.

    For series: fetches real per-episode air dates from Cinemeta — accurate
    because streaming shows air and go digital on the same date.

    For movies: uses Cinemeta's `released` field, which is the theatrical
    release date for most movies, not the digital/VOD date. Labeled clearly.
    Digital dates vary by title and aren't available in any free no-auth API.

    Each entry includes `release_ts` (Unix timestamp) so the frontend can
    sort and group by date without timezone issues, plus `stub_exists`
    indicating whether the content is already in the library (so the UI
    can show "in library" vs "upcoming").

    Every tracked title's Cinemeta metadata is fetched CONCURRENTLY (bounded
    by a semaphore) rather than one at a time — with a few hundred tracked
    titles, doing this sequentially was the actual bottleneck behind a slow
    calendar load, not anything AIOStreams-related. Results are also cached
    for a few minutes (see _cinemeta_cached above) so repeat loads of the
    same window are close to instant.
    """
    from datetime import datetime, timezone as _tz, timedelta

    now = datetime.now(_tz.utc)
    window_start = now - timedelta(days=days_back)
    window_end   = now + timedelta(days=days_ahead)

    def _parse_date(s: Optional[str]):
        if not s: return None
        try:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            if not dt.tzinfo:
                dt = dt.replace(tzinfo=_tz.utc)
            return dt
        except Exception:
            return None

    def _in_window(dt) -> bool:
        if not dt: return False
        return window_start <= dt <= window_end

    entries = []

    # Single pass over all stubs to build every lookup the loops below need,
    # instead of each title re-scanning the full stub list from scratch.
    all_stubs = _stubs.all()
    series_imdb_ids: set = set()
    movie_imdb_ids: set = set()
    stubbed_episodes: set = set()
    stubbed_movies: set = set()
    poster_by_imdb: dict = {}
    show_title_by_imdb: dict = {}
    movie_stub_by_imdb: dict = {}

    for s in all_stubs:
        if not s.imdb_id:
            continue
        if s.aiostreams_type == "series":
            series_imdb_ids.add(s.imdb_id)
            if s.season and s.episode:
                stubbed_episodes.add((s.imdb_id, s.season, s.episode))
            if s.imdb_id not in poster_by_imdb and getattr(s, "_poster", ""):
                poster_by_imdb[s.imdb_id] = s._poster
            if s.imdb_id not in show_title_by_imdb and (s.show_title or s.title):
                show_title_by_imdb[s.imdb_id] = s.show_title or s.title
        elif s.aiostreams_type == "movie":
            movie_imdb_ids.add(s.imdb_id)
            stubbed_movies.add(s.imdb_id)
            movie_stub_by_imdb.setdefault(s.imdb_id, s)

    async def _fetch_series(imdb_id: str) -> list:
        out = []
        try:
            meta = await _cinemeta_cached("series", imdb_id)
            videos = meta.get("videos") or []
            poster = meta.get("poster") or poster_by_imdb.get(imdb_id, "")
            show_title = show_title_by_imdb.get(imdb_id) or meta.get("name", imdb_id)
            for v in videos:
                sn, ep = v.get("season"), v.get("number")
                if not sn or not ep or sn == 0:
                    continue
                dt = _parse_date(v.get("released"))
                if not _in_window(dt):
                    continue
                key = (imdb_id, sn, ep)
                out.append({
                    "_key":         key,
                    "type":         "episode",
                    "imdb_id":      imdb_id,
                    "title":        show_title,
                    "episode_name": v.get("name") or f"S{sn:02d}E{ep:02d}",
                    "season":       sn,
                    "episode":      ep,
                    "poster":       poster,
                    "release_date": dt.date().isoformat(),
                    "release_ts":   int(dt.timestamp()),
                    "stub_exists":  key in stubbed_episodes,
                    "in_library":   key in stubbed_episodes,
                    "date_type":    "air_date",  # accurate — air date = digital for streaming
                })
        except Exception as exc:
            logger.warning("Calendar: failed to fetch episodes for %s: %s (%s)",
                          imdb_id, exc, type(exc).__name__)
        return out

    async def _fetch_movie(imdb_id: str) -> Optional[dict]:
        try:
            meta = await _cinemeta_cached("movie", imdb_id)
            dt = _parse_date(meta.get("released"))
            if not _in_window(dt):
                return None
            stub = movie_stub_by_imdb.get(imdb_id)
            return {
                "_key":         imdb_id,
                "type":         "movie",
                "imdb_id":      imdb_id,
                "title":        meta.get("name") or (stub.title if stub else imdb_id),
                "poster":       meta.get("poster") or (getattr(stub, "_poster", "") if stub else ""),
                "release_date": dt.date().isoformat(),
                "release_ts":   int(dt.timestamp()),
                "stub_exists":  imdb_id in stubbed_movies,
                "in_library":   imdb_id in stubbed_movies,
                "date_type":    "theatrical",  # Cinemeta gives theatrical, not digital/VOD
            }
        except Exception as exc:
            logger.warning("Calendar: failed to fetch movie meta for %s: %s (%s)",
                          imdb_id, exc, type(exc).__name__)
            return None

    series_results, movie_results = await asyncio.gather(
        asyncio.gather(*[_fetch_series(i) for i in series_imdb_ids]),
        asyncio.gather(*[_fetch_movie(i) for i in movie_imdb_ids]),
    )

    seen_keys = set()
    for ep_list in series_results:
        for e in ep_list:
            if e["_key"] in seen_keys:
                continue
            seen_keys.add(e["_key"])
            del e["_key"]
            entries.append(e)
    for m in movie_results:
        if not m or m["_key"] in seen_keys:
            continue
        seen_keys.add(m["_key"])
        del m["_key"]
        entries.append(m)

    entries.sort(key=lambda e: e["release_ts"])
    asyncio.create_task(asyncio.to_thread(_persist_calendar_cache))
    return {
        "entries":    entries,
        "days_back":  days_back,
        "days_ahead": days_ahead,
        "generated_at": int(now.timestamp()),
    }


@app.get("/api/library/missing-counts")
async def get_missing_counts():
    """
    Returns {imdb_id: missing_episode_count} for every tracked series,
    scoped to seasons that are actually requested — same definition used
    everywhere else in the app (Library's series detail modal, spot
    check): a season counts as requested if it has at least one existing
    stub. A season never requested doesn't count toward "missing" just
    because Cinemeta lists it. Powers the "N missing" banner on library
    cover art. Reuses the same cached Cinemeta fetch the calendar and
    spot check use, so repeat calls are cheap.
    """
    series_info: dict = {}
    for s in _stubs.all():
        if s.media_type == MediaType.SERIES and s.imdb_id:
            info = series_info.setdefault(s.imdb_id, {"seasons": set(), "have": set()})
            if s.season is not None:
                info["seasons"].add(s.season)
                if s.episode is not None:
                    info["have"].add((s.season, s.episode))

    counts: dict = {}

    async def _count_one(imdb_id: str, info: dict):
        try:
            meta = await _cinemeta_cached("series", imdb_id)
            videos = meta.get("videos") or []
            missing = 0
            for v in videos:
                sn, ep = v.get("season"), v.get("number")
                if not sn or not ep or sn == 0:
                    continue
                if sn not in info["seasons"]:
                    continue
                if not _is_aired(v.get("released")):
                    continue
                if (sn, ep) in info["have"]:
                    continue
                missing += 1
            if missing:
                counts[imdb_id] = missing
        except Exception as exc:
            logger.warning("Missing-count check failed for %s: %s (%s)",
                          imdb_id, exc, type(exc).__name__)

    await asyncio.gather(*[_count_one(i, info) for i, info in series_info.items()])
    return {"counts": counts}


# ---------------------------------------------------------------------------
# Spot check — on-demand audit + fix of the whole library for gaps
# ---------------------------------------------------------------------------
# Distinct from the automatic sweeps (auto-episode discovery, pending-movies
# retry), which only run on their own schedule and in the background: this
# is a manual, on-demand action that immediately checks every tracked series
# for aired episodes with no stub — scoped to seasons you've actually
# requested, not the whole show, matching every other "requested" concept in
# the app (Library's series detail modal, requestSeason/removeSeason) — and
# every pending movie whose release date has passed, then actually searches
# for and adds each one found right now, rather than waiting for the next
# scheduled sweep. Useful when you want to force everything up to date
# immediately, or verify the background sweeps have actually kept up.
_spotcheck_jobs: dict[str, dict] = {}
_spotcheck_tasks: dict[str, "asyncio.Task"] = {}


# ---------------------------------------------------------------------------
# Prewarm new releases — proactively resolve recently-created placeholder
# stubs to real streams, ahead of the first actual play
# ---------------------------------------------------------------------------
# Every stub normally sits as a lightweight placeholder until Plex actually
# tries to play it, at which point the webhook triggers a live resolve —
# that's deliberate (resolving everything eagerly would waste AIOStreams
# budget on things that might never get watched). But for something that
# just got added — a new episode auto-discovered minutes after it aired, a
# movie you just requested — there's a good chance it's about to be
# watched soon, and the very first playback shouldn't also be the moment it
# has to wait on AIOStreams resolution + probing. This proactively runs
# that exact same resolve (best_working_for_quality → set_active) for
# whatever's both still a placeholder AND was created within the
# configured window, one at a time through the same rate gate and
# play-priority pausing as every other background loop.
#
# Keyed on the stub's own created_at (when it was added to YOUR library),
# not the content's real release/air date — "new to the Plex library"
# rather than "recently released", a deliberate choice. The tradeoff: a
# large Radarr/Sonarr migration adding years of back catalog all at once
# would make all of it look "new" here too and get prewarmed along with
# it, since every one of those stubs gets a "just now" created_at
# regardless of how old the content actually is.
_prewarm_jobs: dict[str, dict] = {}
_prewarm_tasks: dict[str, "asyncio.Task"] = {}


async def _run_prewarm_new_releases(job_id: str):
    job = _prewarm_jobs[job_id]
    try:
        from gateway import settings as _settings
        from gateway.aiostreams_client import AllCandidatesDeadError

        days = _settings.get("prewarm_new_releases_days", 3) or 0
        cutoff = time.time() - (days * 86400) if days else 0

        # Deliberately keyed on when the stub was added to YOUR library
        # (created_at), not the content's real release/air date — "new to
        # the Plex library" rather than "recently released". A large
        # migration adding years of back catalog all at once would make
        # all of it look "new" here and get prewarmed too; that's a known
        # tradeoff of this definition, not an oversight.
        targets = [
            s for s in _stubs.all()
            if s.state == StubState.PLACEHOLDER and s.created_at >= cutoff
        ]

        job["phase"] = "resolving"
        job["total"]  = len(targets)
        job["done"]   = 0
        job["status"] = "running"

        resolved, dead_removed, still_placeholder = [], [], []

        for s in targets:
            label = (
                s.title if s.media_type == MediaType.MOVIE
                else f"{s.show_title or s.title} S{s.season:02d}E{s.episode:02d}"
                     if s.season is not None and s.episode is not None
                     else (s.show_title or s.title)
            )
            job["current_title"] = label
            await _yield_to_play_priority()

            try:
                item = MediaItem(
                    id=s.media_id, imdb_id=s.imdb_id, title=s.title,
                    show_title=s.show_title, episode_title="",
                    year=s.year, media_type=s.media_type,
                    season=s.season, episode=s.episode,
                )
                item._poster = getattr(s, "_poster", "") or ""

                stream = await _client.best_working_for_quality(item, s.quality)
                if stream and stream.url:
                    await _stubs.set_active(s.stub_id, stream.url, stream.request_headers, size=stream.size)
                    resolved.append({"stub_id": s.stub_id, "title": label, "poster": item._poster})
                else:
                    still_placeholder.append({"stub_id": s.stub_id, "title": label, "reason": "no stream URL"})
            except AllCandidatesDeadError:
                # Same "confirmed dead, clean it up now" behavior as every
                # other live resolve path — see the earlier removal logic
                # in webhook/handler.py and the /proxy fallback.
                logger.warning("Prewarm: all candidates dead for %s — removing stub", label)
                await _stubs.remove_stub(s.stub_id)
                dead_removed.append({"stub_id": s.stub_id, "title": label})
            except Exception as exc:
                still_placeholder.append({"stub_id": s.stub_id, "title": label, "reason": str(exc)})

            job["done"] += 1

        job["resolved"]         = resolved
        job["dead_removed"]     = dead_removed
        job["still_placeholder"] = still_placeholder
        job["status"] = "done"
    except asyncio.CancelledError:
        job["status"] = "cancelled"
    finally:
        job["finished"]      = True
        job["current_title"] = ""
        _prewarm_tasks.pop(job_id, None)


@app.post("/api/prewarm-new-releases/run")
async def start_prewarm_new_releases():
    job_id = uuid.uuid4().hex[:12]
    _prewarm_jobs[job_id] = {
        "job_id": job_id, "phase": "resolving", "total": 0, "done": 0, "current_title": "",
        "status": "starting", "finished": False,
        "resolved": [], "dead_removed": [], "still_placeholder": [],
    }
    task = asyncio.create_task(_run_prewarm_new_releases(job_id))
    _prewarm_tasks[job_id] = task
    return {"job_id": job_id}


@app.get("/api/prewarm-new-releases/status/{job_id}")
async def prewarm_new_releases_status(job_id: str):
    job = _prewarm_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    return job


@app.post("/api/prewarm-new-releases/cancel/{job_id}")
async def cancel_prewarm_new_releases(job_id: str):
    job = _prewarm_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    task = _prewarm_tasks.get(job_id)
    if task and not task.done():
        task.cancel()
    return {"ok": True}


_QUALITY_URL_RE_4K = re.compile(r'(?i)(2160p|\b4k\b|\buhd\b)')
_QUALITY_URL_RE_HD = re.compile(r'(?i)(1080p|720p|\bhd\b)')


def _detect_quality_from_url(url: Optional[str]) -> Optional[str]:
    """
    Best-effort, conservative detection of a resolved stream's actual
    quality from its URL — many debrid CDN links carry the original
    release filename as a path segment, which usually includes a
    resolution tag. Returns 'hd', '4k', or None if inconclusive (no
    identifiable marker at all, or both HD and 4K markers present, which
    can happen with query strings/redirects and isn't a confident signal
    either way — deliberately not guessing in that case).
    """
    if not url:
        return None
    has_4k = bool(_QUALITY_URL_RE_4K.search(url))
    has_hd = bool(_QUALITY_URL_RE_HD.search(url))
    if has_4k and not has_hd:
        return "4k"
    if has_hd and not has_4k:
        return "hd"
    return None


async def _run_spot_check(job_id: str, scope: str = "both", verify_quality_override: Optional[bool] = None):
    job = _spotcheck_jobs[job_id]
    try:
        from gateway import pending_movies as _pending_mv
        from datetime import datetime, timezone as _tz

        check_series = scope in ("both", "series")
        check_movies = scope in ("both", "movies")

        # Every tracked series, with title/poster/year pulled from any of
        # its existing stubs.
        series_info: dict = {}
        if check_series:
            for s in _stubs.all():
                if s.media_type == MediaType.SERIES and s.imdb_id:
                    info = series_info.setdefault(s.imdb_id, {
                        "title": s.show_title or s.title, "poster": "", "year": s.year
                    })
                    if not info["poster"] and getattr(s, "_poster", ""):
                        info["poster"] = s._poster

        pending = _pending_mv.list_all() if check_movies else []

        # ── Phase 1: find what's missing ────────────────────────────────
        job["phase"]  = "checking"
        job["total"]  = len(series_info) + len(pending)
        job["done"]   = 0
        job["status"] = "running"

        missing_episodes = []

        async def _check_series(imdb_id: str, info: dict):
            job["current_title"] = info["title"]
            try:
                meta = await _cinemeta_cached("series", imdb_id)
                videos = meta.get("videos") or []
                have = {
                    (s.season, s.episode) for s in _stubs.all()
                    if s.imdb_id == imdb_id and s.season is not None
                }
                # Only check seasons that are actually requested — same
                # definition used everywhere else (Library's series detail
                # modal, requestSeason/removeSeason): a season counts as
                # requested if it has at least one existing stub. A show
                # you only requested Season 1 of shouldn't have Seasons
                # 2-5 flagged as "missing" just because Cinemeta lists
                # them — those were never asked for in the first place.
                requested_seasons = {sn for sn, _ in have}
                for v in videos:
                    sn, ep = v.get("season"), v.get("number")
                    if not sn or not ep or sn == 0:
                        continue
                    if sn not in requested_seasons:
                        continue
                    if not _is_aired(v.get("released")):
                        continue
                    if (sn, ep) in have:
                        continue
                    missing_episodes.append({
                        "imdb_id": imdb_id, "title": info["title"], "poster": info["poster"],
                        "year": info["year"], "season": sn, "episode": ep,
                        "episode_name": v.get("name") or f"S{sn:02d}E{ep:02d}",
                    })
            except Exception as exc:
                logger.warning("Spot check: failed to check %s: %s (%s)",
                              imdb_id, exc, type(exc).__name__)
            job["done"] += 1

        if check_series:
            await asyncio.gather(*[_check_series(i, info) for i, info in series_info.items()])

        # Pending movies past their searchable date (theatrical release +
        # digital_release_delay_days) — these "should" be findable by now
        # but aren't yet. Using the same delayed date _add_movie/_query_
        # movie use, not the raw theatrical date, so spot check doesn't
        # flag something as "overdue" while it's still inside the window
        # we're deliberately not searching yet.
        now = datetime.now(_tz.utc)
        overdue_movies = []
        for entry in pending:
            job["current_title"] = entry["title"]
            searchable_at = await _movie_searchable_at(entry["imdb_id"])
            if searchable_at and searchable_at <= now:
                overdue_movies.append(entry)
            job["done"] += 1

        # ── Phase 2: actually go search for each missing item ───────────
        # This is what makes it a fix, not just a report — every missing
        # episode and overdue movie found above gets a real search attempt
        # right here, through the exact same code path a manual "Search"
        # click would use. Runs through the normal AIOStreams rate gate
        # like everything else, so a spot check with a lot of gaps can
        # take a while — that's expected, not stuck.
        job["phase"] = "fixing"
        job["total"] = len(missing_episodes) + len(overdue_movies)
        job["done"]  = 0

        from gateway import quality_unavailable as _qu

        fixed_episodes, still_missing_episodes = [], []
        for e in missing_episodes:
            job["current_title"] = f"{e['title']} S{e['season']:02d}E{e['episode']:02d}"
            await _yield_to_play_priority()
            try:
                req = AddReq(
                    imdb_id=e["imdb_id"], title=e["title"], media_type="series",
                    poster=e["poster"], year=e["year"],
                )
                result = await add_single_episode(e["imdb_id"], e["season"], e["episode"], req)
                fixed_episodes.append(e)
                # Found HD but this same resolve found zero 4K candidates —
                # a confident "not available" signal, since resolve_all()
                # checks both qualities in one AIOStreams query. Mark it so
                # future automatic sweeps stop re-attempting 4K here.
                if result and not result.get("has_4k") and not _qu.is_marked(e["imdb_id"], e["season"], e["episode"]):
                    _qu.mark(e["imdb_id"], e["title"], e["season"], e["episode"], e.get("poster", ""))
            except Exception as exc:
                still_missing_episodes.append({**e, "reason": str(exc)})
            job["done"] += 1

        fixed_movies, still_missing_movies = [], []
        for m in overdue_movies:
            job["current_title"] = m["title"]
            await _yield_to_play_priority()
            try:
                req = AddReq(
                    imdb_id=m["imdb_id"], title=m["title"], media_type="movie",
                    poster=m.get("poster", ""), year=m.get("year"),
                )
                result = await _add_movie(req)
                if result.get("pending"):
                    still_missing_movies.append({**m, "reason": "still not resolvable"})
                else:
                    fixed_movies.append(m)
                    if not result.get("has_4k") and not _qu.is_marked(m["imdb_id"]):
                        _qu.mark(m["imdb_id"], m["title"], poster=m.get("poster", ""))
            except Exception as exc:
                still_missing_movies.append({**m, "reason": str(exc)})
            job["done"] += 1

        job["fixed_episodes"]        = fixed_episodes
        job["still_missing_episodes"] = still_missing_episodes
        job["fixed_movies"]          = fixed_movies
        job["still_missing_movies"]  = still_missing_movies

        # ── Phase 3: verify existing stubs are actually the quality they
        # claim to be ─────────────────────────────────────────────────
        # Distinct from phases 1-2 above, which only ever ADD stubs for
        # things that are missing — this is the one part of spot check
        # that can REMOVE an existing, currently-working stub, so it's
        # gated by its own setting (spot_check_verify_quality) and is
        # deliberately conservative: it only acts when the resolved
        # stream's URL contains an unambiguous resolution marker that
        # directly contradicts the stub's labeled quality (e.g. labeled
        # 4K but the URL clearly says 1080p). If the URL has no
        # identifiable marker, or a genuinely ambiguous one, it's left
        # alone rather than guessed at — we don't store the original
        # resolved stream's parsed quality info on the stub itself, so a
        # confident check is only possible when the CDN URL happens to
        # carry that information (common, but not guaranteed).
        from gateway import settings as _settings
        verify_quality = (
            verify_quality_override if verify_quality_override is not None
            else _settings.get("spot_check_verify_quality", True)
        )
        quality_fixed, quality_unresolved = [], []

        if verify_quality:
            job["phase"] = "verifying_quality"
            active_stubs = [
                s for s in _stubs.all()
                if s.state == StubState.ACTIVE and s.stream_url
                and ((s.media_type == MediaType.SERIES and check_series)
                     or (s.media_type == MediaType.MOVIE and check_movies))
            ]
            job["total"] = len(active_stubs)
            job["done"]  = 0

            for s in active_stubs:
                if s.media_type == MediaType.MOVIE:
                    label = s.title
                elif s.season is not None and s.episode is not None:
                    label = f"{s.show_title or s.title} S{s.season:02d}E{s.episode:02d}"
                else:
                    label = s.show_title or s.title
                job["current_title"] = label

                detected = _detect_quality_from_url(s.stream_url)
                if detected and detected != s.quality.value:
                    logger.warning(
                        "Spot check: quality mismatch for %s — labeled %s, "
                        "resolved stream's URL indicates %s",
                        label, s.quality.value.upper(), detected.upper()
                    )
                    item_info = {
                        "stub_id": s.stub_id, "title": label,
                        "poster": getattr(s, "_poster", ""),
                        "labeled": s.quality.value, "detected": detected,
                    }
                    try:
                        removed = await _stubs.remove_stub(s.stub_id)
                        if not removed:
                            quality_unresolved.append({**item_info, "reason": "could not remove mismatched stub"})
                            job["done"] += 1
                            continue

                        target_q = s.quality   # re-search for what it was SUPPOSED to be
                        if s.media_type == MediaType.MOVIE:
                            item = MediaItem(
                                id=s.imdb_id, imdb_id=s.imdb_id, title=s.title,
                                year=s.year, media_type=MediaType.MOVIE,
                            )
                        else:
                            item = MediaItem(
                                id=f"{s.imdb_id}_s{s.season}e{s.episode}", imdb_id=s.imdb_id,
                                title=s.title, show_title=s.show_title, episode_title="",
                                year=s.year, media_type=MediaType.SERIES,
                                season=s.season, episode=s.episode,
                            )
                        item._poster = getattr(s, "_poster", "") or ""

                        await _yield_to_play_priority()
                        new_stream = await _resolve_one_quality(item, target_q)
                        if new_stream:
                            await _stubs.create_stub_for_quality(item, target_q, new_stream)
                            quality_fixed.append(item_info)
                        else:
                            quality_unresolved.append({
                                **item_info,
                                "reason": f"removed, but no clean {target_q.value.upper()} source found",
                            })
                            if target_q == Quality.UHD:
                                _qu.mark(s.imdb_id, label, s.season, s.episode, item_info["poster"])
                    except Exception as exc:
                        quality_unresolved.append({**item_info, "reason": str(exc)})
                job["done"] += 1

        job["quality_fixed"]      = quality_fixed
        job["quality_unresolved"] = quality_unresolved
        job["status"] = "done"
    except asyncio.CancelledError:
        job["status"] = "cancelled"
    finally:
        job["finished"]      = True
        job["current_title"] = ""
        _spotcheck_tasks.pop(job_id, None)


class SpotCheckRunReq(BaseModel):
    scope: str = "both"   # "both" | "movies" | "series"
    verify_quality: Optional[bool] = None   # None = use the persisted spot_check_verify_quality setting


@app.post("/api/spot-check/run")
async def start_spot_check(req: SpotCheckRunReq = SpotCheckRunReq()):
    if req.scope not in ("both", "movies", "series"):
        raise HTTPException(400, "scope must be 'both', 'movies', or 'series'")
    job_id = uuid.uuid4().hex[:12]
    _spotcheck_jobs[job_id] = {
        "job_id": job_id, "scope": req.scope, "phase": "checking", "total": 0, "done": 0,
        "current_title": "", "status": "starting", "finished": False,
        "fixed_episodes": [], "still_missing_episodes": [],
        "fixed_movies": [], "still_missing_movies": [],
        "quality_fixed": [], "quality_unresolved": [],
    }
    task = asyncio.create_task(_run_spot_check(job_id, req.scope, req.verify_quality))
    _spotcheck_tasks[job_id] = task
    return {"job_id": job_id}


@app.get("/api/spot-check/status/{job_id}")
async def spot_check_status(job_id: str):
    job = _spotcheck_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    return job


@app.post("/api/spot-check/cancel/{job_id}")
async def cancel_spot_check(job_id: str):
    job = _spotcheck_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    task = _spotcheck_tasks.get(job_id)
    if task and not task.done():
        task.cancel()
    return {"ok": True}


@app.delete("/api/series/{imdb_id}/season/{season}")
async def remove_season(imdb_id: str, season: int):
    """
    Deletes every stub (HD and 4K) for one season of a tracked series —
    the "un-request a season" counterpart to requestSeason(). Uses
    StubManager.remove_stub() per stub rather than deleting files directly,
    so each removal also triggers the scoped Plex rescan that cleans the
    now-gone episodes out of Plex's library, not just off disk.
    """
    to_remove = [
        s.stub_id for s in _stubs.all()
        if s.imdb_id == imdb_id and s.season == season
    ]
    if not to_remove:
        raise HTTPException(404, "No stubs found for that season")

    removed = 0
    for sid in to_remove:
        if await _stubs.remove_stub(sid):
            removed += 1

    logger.info("Removed season %d of %s: %d stub(s)", season, imdb_id, removed)
    return {"removed": removed, "season": season, "imdb_id": imdb_id}


async def _resolve_one_quality(item: MediaItem, quality: Quality):
    """Resolve just one quality tier for an item, reusing the same probing
    best_working_for_quality already does for live playback (skips dead
    links, applies exclude-words/size filters) — a more thorough check
    than resolve_all's raw "did anything come back at all". Manual scans
    and spot check's quality re-search just want "found something or
    not", so AllCandidatesDeadError collapses to the same None return as
    the plain "nothing found" case here — the special immediate-removal
    handling for that error is specific to the live playback resolve
    path in webhook/handler.py, not these deliberate manual actions."""
    from gateway.aiostreams_client import AllCandidatesDeadError
    try:
        return await _client.best_working_for_quality(item, quality)
    except AllCandidatesDeadError:
        return None


@app.post("/api/movies/{imdb_id}/scan/{quality}")
async def scan_movie_quality(imdb_id: str, quality: str):
    """Manually search for just one quality tier of a movie — for when a
    title has HD but you specifically want to check for 4K (or vice
    versa) right now, rather than waiting on the pending-movies sweep."""
    if quality not in ("hd", "4k"):
        raise HTTPException(400, "quality must be 'hd' or '4k'")
    q = Quality.UHD if quality == "4k" else Quality.HD

    # Prefer metadata from an existing stub for this movie; fall back to
    # Cinemeta if nothing's stubbed yet (e.g. still in the pending list).
    existing = next(
        (s for s in _stubs.all() if s.imdb_id == imdb_id and s.media_type == MediaType.MOVIE),
        None
    )
    if existing:
        title, year, poster = existing.title, existing.year, getattr(existing, "_poster", "")
    else:
        try:
            meta = await _cinemeta_cached("movie", imdb_id)
        except Exception:
            meta = {}
        title  = meta.get("name", imdb_id)
        poster = meta.get("poster", "")
        year   = None
        try:
            if meta.get("year"):
                year = int(str(meta["year"])[:4])
            elif meta.get("released"):
                year = int(meta["released"][:4])
        except Exception:
            pass

    item = MediaItem(id=imdb_id, imdb_id=imdb_id, title=title, year=year, media_type=MediaType.MOVIE)
    item._poster = poster or ""

    stream = await _resolve_one_quality(item, q)
    if not stream:
        raise HTTPException(404, f"No {quality.upper()} stream found")

    stub = await _stubs.create_stub_for_quality(item, q, stream)
    if q == Quality.UHD:
        from gateway import quality_unavailable as _qu
        _qu.unmark(imdb_id)   # found one — clear any earlier "confirmed unavailable" mark
    logger.info("Manual %s scan for movie %s: %s", quality.upper(), imdb_id, stub.stub_id)
    return {"imdb_id": imdb_id, "quality": quality, "stub_id": stub.stub_id}


@app.post("/api/series/{imdb_id}/season/{season}/scan/{quality}")
async def scan_season_quality(imdb_id: str, season: int, quality: str):
    """
    Manually search for just one quality tier across every aired episode
    of one season — the "Scan HD" / "Scan 4K" counterpart to Request
    season, for when a season has (say) HD for most episodes but you want
    to specifically push for 4K right now rather than waiting on the next
    automatic pass.

    Runs synchronously (not handed off to a background task like the
    fast-E01-then-background-scan pattern elsewhere) since this is a
    smaller, deliberate, already-narrow-scoped action — a full season can
    still take a while given the AIOStreams pacing settings, but that's
    expected for an explicit "scan this now" click.
    """
    if quality not in ("hd", "4k"):
        raise HTTPException(400, "quality must be 'hd' or '4k'")
    q = Quality.UHD if quality == "4k" else Quality.HD

    try:
        meta = await _cinemeta_cached("series", imdb_id)
    except Exception as exc:
        raise HTTPException(502, f"Cinemeta fetch failed: {exc}")

    videos = meta.get("videos") or []
    aired_eps = [
        v for v in videos
        if v.get("season") == season and v.get("number") is not None and _is_aired(v.get("released"))
    ]
    if not aired_eps:
        raise HTTPException(404, "No aired episodes found for that season")

    show_title = next(
        (s.show_title or s.title for s in _stubs.all() if s.imdb_id == imdb_id and (s.show_title or s.title)),
        meta.get("name", imdb_id)
    )
    poster = next(
        (getattr(s, "_poster", "") for s in _stubs.all() if s.imdb_id == imdb_id and getattr(s, "_poster", "")),
        meta.get("poster", "")
    )
    year = next((s.year for s in _stubs.all() if s.imdb_id == imdb_id and s.year), None)

    # Skip episodes that already have this exact quality stubbed.
    have = {
        s.episode for s in _stubs.all()
        if s.imdb_id == imdb_id and s.season == season and s.quality == q
    }
    to_scan = [v for v in aired_eps if v.get("number") not in have]

    found = 0
    checked = 0
    for v in to_scan:
        ep_num = v.get("number")
        item = MediaItem(
            id=f"{imdb_id}_s{season}e{ep_num}", imdb_id=imdb_id,
            title=show_title, show_title=show_title, episode_title="",
            year=year, media_type=MediaType.SERIES, season=season, episode=ep_num,
        )
        item._poster = poster or ""
        checked += 1
        try:
            stream = await _resolve_one_quality(item, q)
        except Exception as exc:
            logger.warning("Season %s scan: S%02dE%02d failed: %s", quality, season, ep_num, exc)
            continue
        if stream:
            await _stubs.create_stub_for_quality(item, q, stream)
            found += 1
            if q == Quality.UHD:
                from gateway import quality_unavailable as _qu
                _qu.unmark(imdb_id, season, ep_num)   # found one — clear any earlier mark for this episode

    logger.info("Manual %s scan for %s season %d: %d/%d episodes found",
               quality.upper(), imdb_id, season, found, checked)
    return {
        "imdb_id": imdb_id, "season": season, "quality": quality,
        "checked": checked, "found": found, "already_had": len(aired_eps) - len(to_scan),
    }


@app.get("/api/stubs/{stub_id}/candidates")
async def get_stub_candidates(stub_id: str):
    """
    Lists every available stream AIOStreams currently returns for this
    stub's quality — the same pool best_working_for_quality picks from
    automatically, but shown here so a person can look at filenames/size/
    cache status directly and manually pick a specific one, instead of
    trusting the automatic ranking. Used by Library's "Active stream" tab.
    """
    s = _stubs.get(stub_id)
    if not s:
        raise HTTPException(404, "Not found")

    if s.media_type == MediaType.MOVIE:
        item = MediaItem(
            id=s.imdb_id, imdb_id=s.imdb_id, title=s.title,
            year=s.year, media_type=MediaType.MOVIE,
        )
    else:
        item = MediaItem(
            id=f"{s.imdb_id}_s{s.season}e{s.episode}", imdb_id=s.imdb_id,
            title=s.title, show_title=s.show_title, episode_title="",
            year=s.year, media_type=MediaType.SERIES,
            season=s.season, episode=s.episode,
        )

    try:
        streams = await _client.resolve_all(item)
    except Exception as exc:
        raise HTTPException(502, f"Could not fetch candidates: {exc}")

    matching = [st for st in streams if st.quality == s.quality][:40]

    def _fmt(st):
        size_gb = round(st.size / (1024**3), 2) if st.size else None
        pack_kind, pack_season = st.pack_type
        return {
            "url": st.url,
            "headers": st.request_headers or {},
            "size": st.size,
            "size_gb": size_gb,
            "filename": st.filename,
            "service": st.service,
            "cached": bool(st.cached),
            "resolution": st.parsed_file.resolution if st.parsed_file else None,
            "encode": st.parsed_file.encode if st.parsed_file else None,
            "hdr": st.parsed_file.hdr if st.parsed_file else None,
            "languages": (st.parsed_file.languages or []) if st.parsed_file else [],
            "pack": pack_kind if pack_kind in ("season", "series") else None,
            "is_current": bool(s.stream_url and st.url == s.stream_url),
        }

    return {
        "stub_id": stub_id, "quality": s.quality.value,
        "current_url": s.stream_url,
        "candidates": [_fmt(st) for st in matching],
    }


class SelectStreamReq(BaseModel):
    url: str
    headers: dict = {}
    size: Optional[int] = None


@app.post("/api/stubs/{stub_id}/select-stream")
async def select_stub_stream(stub_id: str, req: SelectStreamReq):
    """
    Manually overrides which specific stream a stub points at — the same
    effect a normal resolve has (set_active), just with a person picking
    the exact candidate instead of best_working_for_quality's automatic
    ranking. Does NOT probe the chosen URL first — this is a deliberate
    manual choice, so it's applied as given; if it turns out dead, the
    normal dead-candidate handling on the next play will catch it same as
    any other stream.
    """
    s = _stubs.get(stub_id)
    if not s:
        raise HTTPException(404, "Not found")
    await _stubs.set_active(stub_id, req.url, req.headers, size=req.size)
    logger.info("Manually selected stream for stub %s: %s…", stub_id, req.url[:80])
    return {"ok": True, "stub_id": stub_id}


@app.delete("/api/stubs/{stub_id}")
async def delete_stub(stub_id: str):
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Not found")
    p = Path(s.abs_path)
    for f in (p, p.with_suffix(".aiogateway.json")):
        try:
            if f.exists(): f.unlink()
        except Exception: pass
    _stubs._stubs.pop(stub_id, None)
    _stubs._path_index.pop(s.abs_path, None)
    return {"deleted": stub_id}


@app.delete("/api/series/{imdb_id}")
async def delete_series(imdb_id: str):
    """Delete ALL stubs for a series and cancel any active background scan."""
    # Cancel background scan first
    if imdb_id in _bg_scans:
        task = _bg_scans.pop(imdb_id)
        task.cancel()
        try:
            await task
        except Exception:
            pass
        logger.info("Cancelled background scan for %s", imdb_id)

    # Delete all stubs for this series
    deleted = 0
    for s in list(_stubs.all()):
        if s.imdb_id != imdb_id:
            continue
        p = Path(s.abs_path)
        for f in (p, p.with_suffix(".aiogateway.json")):
            try:
                if f.exists(): f.unlink()
            except Exception: pass
        _stubs._stubs.pop(s.stub_id, None)
        _stubs._path_index.pop(s.abs_path, None)
        deleted += 1

    logger.info("Deleted %d stubs for series %s", deleted, imdb_id)
    return {"deleted": deleted, "imdb_id": imdb_id}


# ---------------------------------------------------------------------------
# Plex webhook
# ---------------------------------------------------------------------------

@app.post("/webhook/plex")
async def plex_webhook(request: Request):
    ct = request.headers.get("content-type", "")
    if "multipart/form-data" in ct:
        form = await request.form()
        raw = form.get("payload", "{}")
    else:
        raw = (await request.body()).decode()
    result = await _webhook.handle(raw)
    logger.info("Webhook: %s", result)
    return JSONResponse(result)


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

@app.get("/proxy/{stub_id}")
async def proxy_get(stub_id: str, request: Request):
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Stub not found")

    # If not yet resolved, resolve now (webhook may have been missed)
    if s.state == StubState.PLACEHOLDER or (not s.stream_url and s.state != StubState.ERROR):
        logger.info("Proxy resolving stub %s on-demand (webhook not received)", s.stub_id)
        await _stubs.set_resolving(s.stub_id)
        try:
            from gateway.models import MediaItem, MediaType
            media_type = MediaType.MOVIE if s.aiostreams_type == "movie" else MediaType.SERIES
            parts = s.aiostreams_id.split(":")
            item = MediaItem(
                id=s.media_id, imdb_id=s.imdb_id, title=s.title,
                year=None, media_type=media_type,
                season=int(parts[1]) if len(parts) >= 3 else None,
                episode=int(parts[2]) if len(parts) >= 3 else None,
            )
            stream_obj = await _client.best_working_for_quality(item, s.quality)
            if stream_obj and stream_obj.url:
                await _stubs.set_active(s.stub_id, stream_obj.url, stream_obj.request_headers,
                                        size=stream_obj.size)
                logger.info("On-demand resolved stub %s → %s…", s.stub_id, stream_obj.url[:60])
            else:
                await _stubs.set_error(s.stub_id)
                raise HTTPException(502, "No stream URL returned from AIOStreams")
        except HTTPException:
            raise
        except Exception as exc:
            from gateway.aiostreams_client import AllCandidatesDeadError
            if isinstance(exc, AllCandidatesDeadError):
                logger.warning(
                    "Proxy on-demand resolve: all %s candidates dead for %s — removing stub immediately",
                    s.quality.value.upper(), s.stub_id
                )
                await _stubs.remove_stub(s.stub_id)
                raise HTTPException(404, f"This {s.quality.value.upper()} stub had no working sources and has been removed")
            await _stubs.set_error(s.stub_id)
            raise HTTPException(502, f"Stream resolution failed: {exc}")

    if s.state == StubState.ERROR or not s.stream_url:
        raise HTTPException(502, "Stream resolution failed")

    status, headers, body = await _proxy.proxy(s, request.headers.get("Range"))
    return StreamingResponse(body, status_code=status, headers=headers,
                             media_type=headers.get("Content-Type", "video/x-matroska"))


@app.head("/proxy/{stub_id}")
async def proxy_head(stub_id: str):
    s = _stubs.get(stub_id)
    if not s or not s.stream_url: raise HTTPException(404)
    status, headers = await _proxy.head(s)
    return StreamingResponse(b"", status_code=status, headers=headers)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    all_s = _stubs.all()
    return {"status": "ok", "stubs": len(all_s),
            "active": sum(1 for s in all_s if s.state == StubState.ACTIVE),
            "aiostreams_url": os.environ.get("AIOSTREAMS_URL", "not set")}
