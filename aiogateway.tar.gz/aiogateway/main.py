"""
AIOGateway — FastAPI + NuvioWeb-style UI using Cinemeta for metadata.

Cinemeta (v3-cinemeta.strem.io) is the same free metadata source used by
NuvioWeb/NuvioTV. No API key needed. Returns IMDb IDs, posters/backdrops
from TMDB CDN. Endpoints:
  /catalog/movie/top.json  → popular movies
  /catalog/series/top.json → popular series
  /meta/{type}/{imdb_id}.json → single item detail

Endpoints
---------
GET  /                           NuvioWeb-style browse UI
GET  /api/config                 Env config
GET  /api/test                   TorBox connectivity test
GET  /api/torbox/stats           API-saver stats (calls/min, cache hits, breaker)
GET  /api/cinemeta/{path}        Cinemeta proxy (no CORS issues from browser)
POST /api/add                    Add media → TorBox search → stub files
GET  /api/stubs                  List stubs
DELETE /api/stubs/{id}           Delete stub + file

POST /webhook/plex               Plex play event
GET  /proxy/{stub_id}            Stream proxy → Plex
HEAD /proxy/{stub_id}            HEAD pre-flight
GET  /health                     Health
"""
from __future__ import annotations

import asyncio
import copy
import json
import logging
import os
import re
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

import aiohttp
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from pydantic import BaseModel

from gateway.torbox_client import TorBoxClient, AllCandidatesDeadError
from gateway import torbox_guard as _tb_guard
from gateway import alldebrid_api as _ad_api
from gateway.fuse_fs import mount as fuse_mount, unmount as fuse_unmount, FUSE_AVAILABLE
from gateway.models import MediaItem, MediaType, Quality, StubState
from gateway.proxy import StreamProxy
from gateway.stub_manager import StubManager
from webhook.handler import PlexWebhookHandler

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s — %(message)s")
logger = logging.getLogger("aiogateway")

_stubs   = StubManager()
_proxy   = StreamProxy()
_client  = TorBoxClient()
_webhook: PlexWebhookHandler | None = None
_http:    aiohttp.ClientSession | None = None

CINEMETA = "https://v3-cinemeta.strem.io"


def _emergency_unmount():
    if not FUSE_AVAILABLE:
        return
    mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    try:
        logger.info("Emergency unmount: %s", mountpoint)
        fuse_unmount(mountpoint)
    except Exception as exc:
        logger.warning("Emergency unmount error: %s", exc)


import atexit
import signal as _signal

# Register atexit so normal Python exit always unmounts
atexit.register(_emergency_unmount)


def _signal_handler(signum, frame):
    logger.info("Signal %d received — unmounting FUSE and exiting", signum)
    _emergency_unmount()
    # Re-raise default handler so the process exits with the right code
    _signal.signal(signum, _signal.SIG_DFL)
    os.kill(os.getpid(), signum)


# Catch SIGTERM (docker stop) and SIGINT (Ctrl-C)
for _sig in (_signal.SIGTERM, _signal.SIGINT):
    try:
        _signal.signal(_sig, _signal_handler)
    except (OSError, ValueError):
        pass   # may fail in non-main thread contexts


_repair_task: Optional[asyncio.Task] = None

async def _repair_loop():
    """
    Keeps the library honest without placeholders: entries whose TorBox file
    stopped working (ERROR) are re-verified or rebound to another cached
    torrent, and UNBOUND records (restored backups / upgrades from the old
    placeholder design) get bound. Anything TorBox has nothing cached for is
    removed; pending movies / auto-episodes / spot check add it back once
    something shows up. Woken immediately by FUSE when a read fails.
    """
    from gateway import settings as _settings
    await asyncio.sleep(15)
    while True:
        try:
            todo = _stubs.needs_repair()
            if todo:
                counts: dict = {}
                for s in todo:
                    await _yield_to_play_priority()
                    result = await _stubs.repair(s.stub_id)
                    counts[result] = counts.get(result, 0) + 1
                logger.info("Repair pass: %s", counts)
            interval = float(_settings.get("repair_interval_minutes", 10) or 10) * 60
            await _stubs.wait_for_repair_wakeup(max(30.0, interval))
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("Repair loop error: %s", exc)
            await asyncio.sleep(60)


_auto_episodes_task: Optional[asyncio.Task] = None

async def _auto_episodes_loop():
    """
    Periodically checks every tracked series for newly-aired episodes and
    auto-stubs them (HD + 4K where available) — see gateway/auto_episodes.py
    for the actual discovery/retry logic. The interval and enable/disable
    setting are re-read each cycle so changes from the UI take effect
    without a restart.

    References _query_episode and _yield_to_play_priority by name rather
    than importing them — both are defined later in this module, but since
    this loop only ever calls them at runtime (after the whole module has
    finished loading), that's safe and avoids reordering a large amount of
    existing code just to satisfy import order.
    """
    from gateway import settings as _settings
    from gateway import auto_episodes as _auto_ep
    while True:
        try:
            interval_min = _settings.get("auto_episodes_interval_minutes", 30)
            await asyncio.sleep(max(60, interval_min * 60))
            if not _settings.get("auto_episodes_enabled", True):
                continue
            result = await _auto_ep.run_sweep(_stubs, _http, _query_episode, _yield_to_play_priority)
            if result.get("new_stubs"):
                logger.info("Auto-episode sweep: %s", result)
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("Auto-episode sweep error: %s", exc)


_pending_movies_task: Optional[asyncio.Task] = None
_spot_check_task: Optional[asyncio.Task] = None

async def _pending_movies_loop():
    """
    Periodically retries every tracked-but-unresolved movie — see
    gateway/pending_movies.py. Reuses auto_episodes_interval_minutes for
    cadence rather than introducing a second interval setting; the two
    sweeps are conceptually the same kind of "keep checking until it
    shows up" background job, just for movies vs. episodes.

    References _query_movie by name rather than importing it — it's
    defined later in this module, but since this loop only calls it at
    runtime (after the whole module has finished loading), that's safe.
    """
    from gateway import settings as _settings
    from gateway import pending_movies as _pending_mv
    while True:
        try:
            interval_min = _settings.get("auto_episodes_interval_minutes", 30)
            await asyncio.sleep(max(60, interval_min * 60))
            result = await _pending_mv.run_sweep(_query_movie, yield_fn=_yield_to_play_priority)
            if result.get("resolved"):
                logger.info("Pending-movie sweep: %s", result)
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("Pending-movie sweep error: %s", exc)


async def _spot_check_loop():
    """
    Runs a full spot check (check + auto-fix, same as the manual "Run spot
    check" button) on a configurable interval — 0 hours (the default)
    disables this entirely, any positive number of hours runs it that
    often. References _run_spot_check/_spotcheck_jobs by name rather than
    importing — both are defined later in this module, safe since this
    loop only calls them at runtime after the whole module has loaded.
    """
    from gateway import settings as _settings
    while True:
        try:
            interval_hours = _settings.get("spot_check_interval_hours", 0) or 0
            if not interval_hours:
                await asyncio.sleep(300)   # not enabled — just poll for the setting turning on
                continue
            await asyncio.sleep(max(60, interval_hours * 3600))
            # Re-check in case it was disabled while sleeping
            interval_hours = _settings.get("spot_check_interval_hours", 0) or 0
            if not interval_hours:
                continue
            scope = _settings.get("spot_check_scheduled_scope", "both")
            job_id = uuid.uuid4().hex[:12]
            _spotcheck_jobs[job_id] = {
                "job_id": job_id, "scope": scope, "phase": "checking", "total": 0, "done": 0,
                "current_title": "", "status": "starting", "finished": False,
                "fixed_episodes": [], "still_missing_episodes": [],
                "fixed_movies": [], "still_missing_movies": [],
            }
            await _run_spot_check(job_id, scope)
            job = _spotcheck_jobs.get(job_id, {})
            fixed = len(job.get("fixed_episodes", [])) + len(job.get("fixed_movies", []))
            missing = len(job.get("still_missing_episodes", [])) + len(job.get("still_missing_movies", []))
            logger.info("Scheduled spot check complete: %d found, %d still missing", fixed, missing)
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("Scheduled spot check error: %s", exc)


async def _warm_calendar_cache_once():
    """
    Pre-fetches the calendar's default window (same days_back/days_ahead
    the API defaults to, matching the common case of opening the tab on
    the current month) once, shortly after startup, in the background —
    so the FIRST click on the Calendar tab hits an already-warm cache
    instead of paying the full concurrent-Cinemeta-fetch cost right at
    that moment. References get_calendar by name rather than importing;
    safe since this only runs well after the whole module has loaded.
    """
    try:
        await asyncio.sleep(5)   # let the rest of startup settle first
        await get_calendar(days_back=14, days_ahead=30)
        logger.info("Calendar cache pre-warmed at startup")
    except Exception as exc:
        logger.warning("Calendar cache warm-up failed: %s", exc)


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _webhook, _http, _repair_task, _auto_episodes_task, _pending_movies_task, _spot_check_task
    await _proxy.open()
    await _client.open()
    _http    = aiohttp.ClientSession(headers={"User-Agent": "AIOGateway/0.3"})
    _webhook = PlexWebhookHandler(_stubs, _client)
    _stubs.attach(_client, asyncio.get_running_loop())
    if not os.environ.get("PLEX_URL") or "your-plex" in os.environ.get("PLEX_URL", ""):
        logger.warning("PLEX_URL isn't set — nobody can sign in to the web UI until it is")
    restored = await _stubs.restore()
    logger.info("AIOGateway started — %d stubs restored", restored)

    from gateway import settings as _settings
    _settings.load()
    _client.start_background()   # TorBox account mirror + cache maintenance

    # Mount virtual FUSE filesystem
    mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    if FUSE_AVAILABLE:
        fuse_mount(_stubs, _client, mountpoint)
        logger.info("FUSE mounted at %s", mountpoint)
    else:
        logger.warning("FUSE unavailable — library is only reachable through /proxy")

    _repair_task = asyncio.create_task(_repair_loop())
    _auto_episodes_task = asyncio.create_task(_auto_episodes_loop())
    _pending_movies_task = asyncio.create_task(_pending_movies_loop())
    _spot_check_task = asyncio.create_task(_spot_check_loop())
    asyncio.create_task(_warm_calendar_cache_once())

    try:
        yield
    finally:
        # Clean shutdown path — also covered by atexit but explicit is better
        if _repair_task:
            _repair_task.cancel()
        try:
            from gateway import plex_scan as _ps
            await asyncio.to_thread(_ps.flush_now)     # don't lose queued scans on shutdown
        except Exception:
            pass
        if _auto_episodes_task:
            _auto_episodes_task.cancel()
        if _pending_movies_task:
            _pending_movies_task.cancel()
        if _spot_check_task:
            _spot_check_task.cancel()
        if FUSE_AVAILABLE:
            fuse_unmount(mountpoint)
        await _proxy.close()
        await _client.close()
        if _http: await _http.close()


app = FastAPI(title="AIOGateway", version="0.3.0", lifespan=lifespan)

# ---------------------------------------------------------------------------
# Authentication — every request is checked against gateway/auth.py's route
# policy: public, any signed-in user, or admin (the default for anything not
# explicitly listed). No CORS middleware: the UI is same-origin.
# ---------------------------------------------------------------------------

from gateway import auth as _auth

_COOKIE_SECURE = os.environ.get("AIOGATEWAY_COOKIE_SECURE", "").lower() in ("1", "true", "yes")


def _client_ip(request: Request) -> str:
    return request.client.host if request.client else "?"


@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    need = _auth.required_role(request.method, request.url.path)
    user = None
    token = request.cookies.get(_auth.COOKIE_NAME)
    if token:
        user = await asyncio.to_thread(_auth.store().user_for_session, token)
    request.state.user = user
    if need != "public":
        if not user:
            return JSONResponse({"detail": "Sign in required", "code": "login_required"}, status_code=401)
        if need == "admin" and user["role"] != "admin":
            return JSONResponse({"detail": "Admins only", "code": "forbidden"}, status_code=403)
    return await call_next(request)


def _set_session_cookie(resp: JSONResponse, token: str):
    resp.set_cookie(_auth.COOKIE_NAME, token, max_age=_auth.SESSION_TTL, httponly=True,
                    samesite="lax", secure=_COOKIE_SECURE, path="/")


def _auth_error(exc: "_auth.AuthError"):
    return JSONResponse({"detail": str(exc), "code": exc.code}, status_code=exc.status)


@app.get("/api/auth/status")
async def auth_status(request: Request):
    user = request.state.user
    out = {"user": user, "method": "plex"}
    if user and user["role"] == "admin":
        from gateway.torbox_api import key_source
        out["torbox_key_set"] = bool(key_source()[1])
    return out


@app.post("/api/auth/plex/start")
async def auth_plex_start(request: Request):
    """Start "Sign in with Plex": returns the Plex sign-in URL to open. A
    short-lived cookie ties the attempt to this browser."""
    try:
        nonce, info = await asyncio.to_thread(_auth.store().start_signin, _client_ip(request))
    except _auth.AuthError as exc:
        return _auth_error(exc)
    resp = JSONResponse(info)
    resp.set_cookie(_auth.PIN_COOKIE, nonce, max_age=_auth.PIN_TTL, httponly=True,
                    samesite="lax", secure=_COOKIE_SECURE, path="/api/auth/plex")
    return resp


@app.post("/api/auth/plex/finish")
async def auth_plex_finish(request: Request):
    """Poll after opening the Plex sign-in page. {"pending": true} until the
    person approves; then signs them in if their Plex account has access to
    this Plex server."""
    try:
        result = await asyncio.to_thread(_auth.store().finish_signin, request.cookies.get(_auth.PIN_COOKIE))
    except _auth.AuthError as exc:
        resp = _auth_error(exc)
        if exc.code in ("pin_expired", "no_server_access", "disabled"):
            resp.delete_cookie(_auth.PIN_COOKIE, path="/api/auth/plex")
        return resp
    if result is None:
        return {"pending": True}
    user, token = result
    logger.info("Plex sign-in: %s (%s) from %s", user["username"], user["role"], _client_ip(request))
    resp = JSONResponse({"pending": False, "user": user})
    _set_session_cookie(resp, token)
    resp.delete_cookie(_auth.PIN_COOKIE, path="/api/auth/plex")
    return resp


@app.post("/api/auth/logout")
async def auth_logout(request: Request):
    await asyncio.to_thread(_auth.store().end_session, request.cookies.get(_auth.COOKIE_NAME))
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(_auth.COOKIE_NAME, path="/")
    return resp


class UpdateUserReq(BaseModel):
    role: Optional[str] = None
    disabled: Optional[bool] = None


@app.get("/api/users")
async def list_users():
    return {"users": _auth.store().list()}


@app.patch("/api/users/{plex_id}")
async def update_user(plex_id: str, req: UpdateUserReq, request: Request):
    """Change someone's role or block/unblock them. Signs them out. The Plex
    server owner is always an admin."""
    if plex_id == request.state.user["plex_id"] and (req.disabled or req.role == "user"):
        return JSONResponse({"detail": "You can't demote or block yourself"}, status_code=400)
    try:
        return await asyncio.to_thread(lambda: _auth.store().update(plex_id, role=req.role, disabled=req.disabled))
    except _auth.AuthError as exc:
        return _auth_error(exc)


@app.delete("/api/users/{plex_id}")
async def delete_user(plex_id: str, request: Request):
    """Forget someone and sign them out. They can sign in again while the
    Plex server is shared with them — block them to keep them out."""
    if plex_id == request.state.user["plex_id"]:
        return JSONResponse({"detail": "You can't remove yourself"}, status_code=400)
    try:
        await asyncio.to_thread(_auth.store().forget, plex_id)
    except _auth.AuthError as exc:
        return _auth_error(exc)
    return {"ok": True}


# ---------------------------------------------------------------------------
# Cinemeta proxy  —  /api/cinemeta/{path}
# ---------------------------------------------------------------------------

@app.get("/api/cinemeta/{path:path}")
async def cinemeta_proxy(path: str):
    """Proxy Cinemeta requests from the browser to avoid any CORS issues."""
    assert _http
    url = f"{CINEMETA}/{path}"
    try:
        async with _http.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
            data = await resp.json(content_type=None)
            return JSONResponse(data, status_code=resp.status)
    except Exception as exc:
        logger.error("Cinemeta proxy error %s: %s", url, exc)
        raise HTTPException(502, f"Cinemeta unreachable: {exc}")


# ---------------------------------------------------------------------------
# Embedded NuvioWeb-style UI
# ---------------------------------------------------------------------------

UI_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>AIOGateway</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet"/>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#080810;--sur:#10101a;--card:#14141f;--card2:#1a1a28;
  --bor:rgba(255,255,255,.08);--bor2:rgba(255,255,255,.14);
  --txt:#f0f0f8;--mut:#7878a0;--acc:#e8a020;--acc2:#f5b840;
  --blue:#4a9eff;--grn:#3dd68c;--red:#ff5555;
  --navh:64px;--f:'Inter',system-ui,sans-serif;
}
html,body{height:100%;background:var(--bg);color:var(--txt);font-family:var(--f);font-size:15px;line-height:1.5;-webkit-font-smoothing:antialiased;overflow-x:hidden;scroll-behavior:smooth}

/* ── Nav pill ───────────────────────────────────────────────── */
.nav{
  position:fixed;top:18px;left:50%;transform:translateX(-50%);z-index:100;
  display:flex;align-items:center;gap:2px;
  background:rgba(8,8,16,.85);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);
  border:1px solid var(--bor2);border-radius:50px;padding:5px 6px;
}
.ni{
  display:flex;align-items:center;gap:6px;padding:8px 20px;
  border-radius:40px;font-size:14px;font-weight:600;cursor:pointer;
  border:none;background:none;color:var(--mut);font-family:var(--f);
  transition:all 150ms;white-space:nowrap;
}
.ni:hover{color:var(--txt);background:rgba(255,255,255,.07)}
.ni.on{background:rgba(255,255,255,.12);color:var(--txt)}

/* ── Hero ───────────────────────────────────────────────────── */
.hero{position:relative;height:100vh;max-height:600px;min-height:420px;overflow:hidden;display:flex;align-items:flex-end}
.hero-bg{
  position:absolute;inset:0;
  background-size:cover;background-position:center 20%;
  transition:background-image .5s ease;
}
.hero-ov{
  position:absolute;inset:0;
  background:linear-gradient(to bottom,
    rgba(8,8,16,.2) 0%,
    rgba(8,8,16,.0) 20%,
    rgba(8,8,16,.5) 55%,
    rgba(8,8,16,.95) 85%,
    var(--bg) 100%);
}
.hero-body{position:relative;z-index:2;padding:0 56px 48px;max-width:620px}
.hero-logo{max-height:64px;max-width:280px;margin-bottom:14px;object-fit:contain;filter:drop-shadow(0 2px 12px rgba(0,0,0,.8));display:none}
.hero-title{font-size:56px;font-weight:900;letter-spacing:-2px;line-height:1;margin-bottom:10px;text-shadow:0 2px 20px rgba(0,0,0,.9)}
.hero-meta{display:flex;align-items:center;gap:10px;font-size:14px;color:rgba(255,255,255,.7);font-weight:500;margin-bottom:10px}
.hero-sep{opacity:.4}
.hero-rating{background:rgba(255,255,255,.15);border-radius:5px;padding:2px 8px;font-size:12px;font-weight:700;color:var(--acc2)}
.hero-desc{font-size:14px;color:rgba(255,255,255,.65);line-height:1.6;margin-bottom:20px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.hero-dots{display:flex;gap:5px;margin-bottom:22px}
.hero-dot{width:24px;height:3px;border-radius:2px;background:rgba(255,255,255,.25);cursor:pointer;transition:all 200ms}
.hero-dot.on{background:#fff;width:32px}
.hero-acts{display:flex;gap:10px}
.btn-hero{
  display:flex;align-items:center;gap:8px;padding:12px 28px;border-radius:8px;
  font-family:var(--f);font-size:14px;font-weight:700;cursor:pointer;border:none;transition:all 150ms;
}
.btn-add{background:var(--acc);color:#000}
.btn-add:hover{background:var(--acc2);transform:translateY(-1px)}
.btn-add.added{background:var(--grn);color:#000}
.btn-info{background:rgba(255,255,255,.16);color:#fff;backdrop-filter:blur(8px)}
.btn-info:hover{background:rgba(255,255,255,.26)}

/* ── Content rows ───────────────────────────────────────────── */
.rows{padding-bottom:48px}
.sec{margin-bottom:8px}
.sec-hd{display:flex;align-items:center;justify-content:space-between;padding:0 56px;margin-bottom:16px}
.sec-title{font-size:18px;font-weight:700;letter-spacing:-.3px;border-left:3px solid var(--acc);padding-left:12px}
.view-all{font-size:13px;font-weight:600;color:var(--mut);cursor:pointer;background:none;border:none;font-family:var(--f);display:flex;align-items:center;gap:3px}
.view-all:hover{color:var(--txt)}
.row{display:flex;gap:14px;overflow-x:auto;overflow-y:visible;padding:4px 56px 14px;scrollbar-width:none}
.row::-webkit-scrollbar{display:none}

/* ── Card ───────────────────────────────────────────────────── */
.card{flex:0 0 138px;cursor:pointer;position:relative;transition:transform 200ms}
.card:hover{transform:scale(1.07) translateY(-2px)}
.cposter{width:138px;height:207px;border-radius:10px;overflow:hidden;background:var(--card2);position:relative;box-shadow:0 4px 16px rgba(0,0,0,.4)}
.card.inlib .cposter{box-shadow:0 0 0 2px var(--grn),0 4px 16px rgba(0,0,0,.4)}
.cposter img{width:100%;height:100%;object-fit:cover;display:block;opacity:0;transition:opacity .3s}
.cposter img.loaded{opacity:1}
.crating{position:absolute;top:7px;right:7px;background:rgba(0,0,0,.78);backdrop-filter:blur(4px);border-radius:5px;padding:2px 7px;font-size:11px;font-weight:700;color:var(--acc2)}
.ccheck{position:absolute;top:7px;right:7px;width:22px;height:22px;border-radius:50%;background:var(--grn);display:none;align-items:center;justify-content:center;font-size:12px;color:#000;font-weight:800}
.card.inlib .ccheck{display:flex}
.card.inlib .crating{display:none}
.cname{font-size:12px;font-weight:600;margin-top:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cyear{font-size:11px;color:var(--mut);margin-top:2px}

/* ── Search page ─────────────────────────────────────────────── */
/* Same padding rhythm and surface tokens as Library/Config pages */
.srchpage{padding:calc(var(--navh) + 28px) 56px 48px}
.srch-hd{margin-bottom:28px}
.srch-bar-wrap{
  display:flex;align-items:center;gap:10px;
  background:var(--card2);border:1px solid var(--bor2);
  border-radius:10px;padding:12px 16px;
  transition:border-color 180ms;
}
.srch-bar-wrap:focus-within{border-color:var(--acc)}
.srch-icon{font-size:17px;color:var(--mut);flex-shrink:0}
.srch-input{
  background:none;border:none;outline:none;font-family:var(--f);
  font-size:15px;color:var(--txt);width:100%;font-weight:500;
}
.srch-input::placeholder{color:var(--mut)}
.srch-clear{
  background:var(--card);border:1px solid var(--bor2);border-radius:7px;
  color:var(--mut);font-size:12px;padding:5px 11px;cursor:pointer;
  font-family:var(--f);font-weight:600;white-space:nowrap;flex-shrink:0;
  transition:all 150ms;display:none;
}
.srch-clear:hover{color:var(--txt);border-color:var(--acc)}
.srch-tabs{display:flex;gap:6px;margin-top:14px}
.srch-tab{
  padding:7px 18px;border-radius:30px;font-size:13px;font-weight:600;
  cursor:pointer;border:1px solid var(--bor2);background:none;
  color:var(--mut);font-family:var(--f);transition:all 150ms;
}
.srch-tab:hover{color:var(--txt)}
.srch-tab.on{background:var(--acc);color:#000;border-color:var(--acc)}
.srch-status{font-size:13px;color:var(--mut);margin-bottom:18px;min-height:20px}
.srch-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(138px,1fr));
  gap:22px 14px;
}
.srch-empty{
  grid-column:1/-1;text-align:center;padding:60px 20px;
  color:var(--mut);
}
.srch-empty-icon{font-size:36px;margin-bottom:12px;opacity:.3}
.srch-empty-title{font-size:14px;font-weight:600;margin-bottom:4px}
.srch-empty-sub{font-size:12px;opacity:.7}

/* ── View All overlay ───────────────────────────────────────── */
.va-overlay{
  position:fixed;inset:0;background:var(--bg);z-index:150;
  overflow-y:auto;scrollbar-width:none;
  opacity:0;pointer-events:none;transition:opacity 200ms;
}
.va-overlay::-webkit-scrollbar{display:none}
.va-overlay.open{opacity:1;pointer-events:all}
.va-inner{padding:calc(var(--navh) + 28px) 56px 48px}
.va-header{display:flex;align-items:center;gap:18px;margin-bottom:28px}
.va-back{
  display:flex;align-items:center;gap:6px;
  background:var(--card2);border:1px solid var(--bor2);border-radius:8px;
  padding:8px 16px;font-family:var(--f);font-size:13px;font-weight:600;
  color:var(--mut);cursor:pointer;transition:all 150ms;flex-shrink:0;
}
.va-back:hover{color:var(--txt);border-color:var(--acc)}
.va-title{font-size:22px;font-weight:800;letter-spacing:-.4px}
.va-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(138px,1fr));
  gap:22px 14px;
}

/* ── Season picker ──────────────────────────────────────────── */
.season-picker{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px}
.season-btn{
  padding:5px 14px;border-radius:6px;font-size:12px;font-weight:700;
  cursor:pointer;border:1px solid var(--bor2);background:var(--card2);
  color:var(--mut);font-family:var(--f);transition:all 140ms;
}
.season-btn:hover{border-color:var(--acc);color:var(--txt)}
.season-btn.on{background:var(--acc);color:#000;border-color:var(--acc)}
.season-btn.all-btn{background:var(--card2);color:var(--txt);border-color:var(--bor2)}
.season-btn.all-btn.on{background:var(--acc);color:#000}
/* Already-requested season: filled green. Selection (.on) still takes
   visual priority if the user has that season actively picked, so a
   requested season that's also selected shows the accent (orange) state
   rather than competing colors. */
.season-btn.requested{background:var(--grn);color:#000;border-color:var(--grn)}
.season-btn.requested:hover{border-color:var(--grn);color:#000}
.season-btn.requested.on{background:var(--acc);color:#000;border-color:var(--acc)}

/* ── Skeleton ───────────────────────────────────────────────── */
.skel{background:linear-gradient(90deg,var(--card) 25%,var(--card2) 50%,var(--card) 75%);background-size:200% 100%;animation:shim 1.5s infinite;border-radius:10px}
@keyframes shim{0%{background-position:200% 0}100%{background-position:-200% 0}}

/* ── Modal ──────────────────────────────────────────────────── */
.mbg{position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);z-index:200;display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;transition:opacity 180ms}
.mbg.open{opacity:1;pointer-events:all}
.modal{background:var(--card);border:1px solid var(--bor2);border-radius:18px;width:92%;max-width:520px;overflow:hidden;transform:scale(.94) translateY(12px);transition:transform 180ms}
.mbg.open .modal{transform:scale(1) translateY(0)}
.mhero{height:220px;background-size:cover;background-position:center;position:relative}
.mhero-ov{position:absolute;inset:0;background:linear-gradient(to bottom,rgba(20,20,31,.2) 0%,var(--card) 100%)}
.mbody{padding:20px 24px 26px}
.mtitle{font-size:22px;font-weight:800;letter-spacing:-.5px;margin-bottom:6px}
.mmeta{display:flex;gap:9px;font-size:13px;color:var(--mut);margin-bottom:10px;flex-wrap:wrap;align-items:center}
.mrating{background:var(--card2);border:1px solid var(--bor);padding:2px 8px;border-radius:5px;font-size:11px;font-weight:700;color:var(--acc2)}
.mpills{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:14px}
.mpill{background:var(--card2);border:1px solid var(--bor);padding:3px 11px;border-radius:20px;font-size:12px;font-weight:500}
.moverview{font-size:13px;color:var(--mut);line-height:1.7;margin-bottom:22px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.macts{display:flex;gap:10px}
.mbtn{flex:1;display:flex;align-items:center;justify-content:center;gap:7px;padding:12px;border-radius:9px;font-family:var(--f);font-size:13px;font-weight:700;cursor:pointer;border:none;transition:all 150ms}
.mbtn-add{background:var(--acc);color:#000}
.mbtn-add:hover{background:var(--acc2)}
.mbtn-add.added{background:var(--grn);color:#000}
.mbtn-add.pending{background:var(--blue);color:#04111f}
.mbtn-close{background:var(--card2);color:var(--mut);border:1px solid var(--bor2)}
.mbtn-close:hover{color:var(--txt)}
.mclose{position:absolute;top:14px;right:14px;z-index:10;width:30px;height:30px;border-radius:50%;background:rgba(0,0,0,.6);border:none;color:#fff;font-size:15px;cursor:pointer;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px)}
.mclose:hover{background:rgba(0,0,0,.9)}

/* ── Library page ───────────────────────────────────────────── */
.libpage{padding:calc(var(--navh) + 28px) 56px 48px}
.libhd{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px}
.libtitle{font-size:28px;font-weight:800;letter-spacing:-.5px}
.libgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(138px,1fr));gap:22px 14px}
.stub-state{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;margin-top:5px}
.ss-ph{background:#2a2a14;color:#c8a030}
.ss-ac{background:#0d2a18;color:var(--grn)}
.ss-er{background:#2a0d0d;color:var(--red)}
.ss-rs{background:#141e2e;color:var(--blue);animation:sblink 1.1s infinite}
@keyframes sblink{0%,100%{opacity:1}50%{opacity:.35}}
.del-btn{width:26px;height:26px;border-radius:50%;background:rgba(0,0,0,.7);border:none;color:#888;font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all 130ms}
.del-btn:hover{background:var(--red);color:#fff}

/* ── Search ─────────────────────────────────────────────────── */
.searchbar{display:flex;align-items:center;gap:9px;background:var(--card2);border:1px solid var(--bor2);border-radius:10px;padding:9px 15px}
.searchbar input{background:none;border:none;outline:none;font-family:var(--f);font-size:14px;color:var(--txt);width:100%}
.searchbar input::placeholder{color:var(--mut)}

/* ── Calendar ─────────────────────────────────────────────────── */
.cal-day{margin-bottom:28px}
.cal-day-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--mut);margin-bottom:10px;display:flex;align-items:center;gap:10px}
.cal-day-label::after{content:'';flex:1;height:1px;background:var(--bor)}
.cal-day-label.today{color:var(--acc)}
.cal-entries{display:flex;flex-direction:column;gap:8px}
.cal-entry{background:var(--card);border:1px solid var(--bor);border-radius:12px;padding:12px 14px;display:flex;align-items:center;gap:14px;cursor:pointer;transition:border-color 140ms}
.cal-entry:hover{border-color:var(--bor2)}
.cal-entry.inlib{border-left:3px solid var(--grn)}
.cal-entry.future{opacity:.75}
.cal-poster{width:38px;height:57px;border-radius:5px;object-fit:cover;flex-shrink:0;background:var(--card2)}
.cal-poster-placeholder{width:38px;height:57px;border-radius:5px;background:var(--card2);flex-shrink:0;display:flex;align-items:center;justify-content:center;color:var(--mut);font-size:18px}
.cal-info{flex:1;min-width:0}
.cal-title{font-size:14px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cal-sub{font-size:12px;color:var(--mut);margin-top:2px}
.cal-badges{display:flex;gap:6px;margin-top:6px;flex-wrap:wrap}
.cal-badge{font-size:10px;font-weight:700;padding:2px 7px;border-radius:4px;background:var(--card2);color:var(--mut)}
.cal-badge.inlib{background:#0d2a18;color:var(--grn)}
.cal-badge.theatrical{background:#1a1a10;color:#a89050}
.cal-rescan-btn{font-size:11px;font-weight:700;padding:5px 12px;border-radius:6px;border:1px solid var(--bor2);background:none;color:var(--mut);cursor:pointer;flex-shrink:0;transition:all 140ms;white-space:nowrap}
.cal-rescan-btn:hover{border-color:var(--acc);color:var(--acc)}
.cal-rescan-btn.active{border-color:var(--grn);color:var(--grn)}
.cal-rescan-btn.pending{color:var(--blue);border-color:var(--blue)}

/* ── Calendar: month grid ── */
.cal-chips{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px}
.cal-chip{font-size:12px;font-weight:700;padding:6px 13px;border-radius:50px;border:1px solid var(--bor2);background:none;color:var(--mut);cursor:pointer;transition:all 140ms;font-family:var(--f)}
.cal-chip:hover{border-color:var(--acc);color:var(--txt)}
.cal-chip.on{background:var(--acc);color:#000;border-color:var(--acc)}
.cal-monthbar{display:flex;align-items:center;justify-content:center;gap:18px;margin-bottom:16px}
.cal-navbtn{width:32px;height:32px;border-radius:8px;border:1px solid var(--bor2);background:var(--card);color:var(--mut);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:16px;transition:all 140ms}
.cal-navbtn:hover{border-color:var(--acc);color:var(--acc)}
.cal-monthlabel{font-size:16px;font-weight:700;letter-spacing:-.2px;min-width:160px;text-align:center}
.cal-weekrow{display:grid;grid-template-columns:repeat(7,1fr);gap:6px;margin-bottom:6px}
.cal-weekday{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--mut);text-align:center;padding:2px 0}
.cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:6px}
.cal-cell{min-height:84px;border-radius:10px;border:1px solid var(--bor);background:var(--card);padding:6px;cursor:pointer;transition:border-color 140ms;display:flex;flex-direction:column;gap:4px;min-width:0;overflow:hidden}
.cal-cell:hover{border-color:var(--bor2)}
.cal-cell.blank{background:none;border:none;cursor:default}
.cal-cell.selected{border-color:var(--acc)}
.cal-cellnum{font-size:12px;color:var(--mut);width:20px;height:20px;border-radius:50%;display:flex;align-items:center;justify-content:center}
.cal-cellnum.today{background:var(--acc);color:#000;font-weight:700}
.cal-pill{font-size:10px;font-weight:700;padding:2px 6px;border-radius:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;background:rgba(74,158,255,.14);color:var(--blue);border:1px solid rgba(74,158,255,.28)}
.cal-pill.movie{background:rgba(232,160,32,.14);color:var(--acc2);border-color:rgba(232,160,32,.28)}
.cal-pill.inlib{background:var(--grn);color:#04210f;border-color:var(--grn)}
.cal-cellmore{font-size:10px;color:var(--mut);padding:0 2px}
.cal-detail{margin-top:18px;background:var(--card);border:1px solid var(--bor);border-radius:14px;padding:16px}
.cal-detail-date{font-size:14px;font-weight:700;margin-bottom:12px}
.cal-detail-empty{color:var(--mut);font-size:13px;padding:8px 0}


.cfgpage{padding:calc(var(--navh) + 28px) 56px 48px}
.cfgsec{background:var(--card);border:1px solid var(--bor);border-radius:14px;padding:22px;margin-bottom:16px}
.cfgsec h3{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--mut);margin-bottom:16px}
.cfgtabs{display:flex;gap:4px;margin-bottom:24px;border-bottom:1px solid var(--bor);padding-bottom:0}
.cfgtab{
  display:flex;align-items:center;gap:7px;padding:10px 18px;
  font-size:14px;font-weight:600;cursor:pointer;
  border:none;background:none;color:var(--mut);font-family:var(--f);
  border-bottom:2px solid transparent;margin-bottom:-1px;
  transition:all 150ms;white-space:nowrap;
}
.cfgtab:hover{color:var(--txt)}
.cfgtab.on{color:var(--acc);border-bottom-color:var(--acc)}
.cfgpanel{display:none}
.cfgpanel.on{display:block}
.chips{display:flex;flex-wrap:wrap;gap:8px}
.chip{background:var(--card2);border:1px solid var(--bor);border-radius:8px;padding:7px 14px;font-size:12px;display:flex;gap:8px}
.cl{color:var(--mut);font-weight:600}
.cv{font-family:monospace;color:var(--txt)}
.cv.ok{color:var(--grn)}
.cv.er{color:var(--red)}
.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 20px;border-radius:8px;font-family:var(--f);font-size:13px;font-weight:700;cursor:pointer;border:none;transition:all 150ms}
.bp{background:var(--acc);color:#000}.bp:hover{background:var(--acc2)}
.bg2{background:var(--card2);color:var(--mut);border:1px solid var(--bor2)}.bg2:hover{color:var(--txt)}
.tresult{font-size:13px;color:var(--mut);margin-bottom:14px;min-height:20px}
.checklist{font-size:13px;color:var(--mut);line-height:2.2}
.checklist code{background:var(--card2);color:var(--acc2);padding:1px 7px;border-radius:5px;font-size:12px}

/* ── Toast ───────────────────────────────────────────────────── */
.toast{position:fixed;bottom:26px;right:26px;z-index:500;background:var(--card);border:1px solid var(--bor2);border-radius:12px;padding:12px 18px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;animation:tin .2s ease}
@keyframes tin{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.toast.ok{border-color:var(--grn);color:var(--grn)}
.toast.er{border-color:var(--red);color:var(--red)}
.toast.in{border-color:var(--blue);color:var(--blue)}

/* ── Accounts ─────────────────────────────────────────────────── */
.role-user .admin-only{display:none!important}
.authbg{position:fixed;inset:0;z-index:1000;background:var(--bg);display:none;align-items:center;justify-content:center;padding:20px}
.authbg.open{display:flex}
.authcard{width:100%;max-width:380px;background:var(--card);border:1px solid var(--bor2);border-radius:18px;padding:30px 28px}
.authcard h2{font-size:22px;font-weight:800;letter-spacing:-.4px;margin-bottom:6px}
.authsub{color:var(--mut);font-size:13px;line-height:1.5;margin-bottom:20px}
.authlabel{font-size:12px;font-weight:600;color:var(--mut);margin:12px 0 6px}
.authinput{width:100%;padding:10px 12px;border-radius:9px;border:1px solid var(--bor2);background:var(--card2);color:var(--txt);font-family:var(--f);font-size:14px;outline:none}
.authinput:focus{border-color:var(--acc)}
.autherr{color:var(--red);font-size:13px;min-height:18px;margin-top:12px}
.ulist{display:flex;flex-direction:column;gap:8px;margin-bottom:22px}
.urow{display:flex;align-items:center;gap:10px;background:var(--card2);border:1px solid var(--bor);border-radius:10px;padding:10px 12px;flex-wrap:wrap}
.uname{font-weight:700;font-size:14px}
.umeta{color:var(--mut);font-size:12px;flex:1;min-width:120px}
.uthumb{width:34px;height:34px;border-radius:50%;object-fit:cover;background:var(--card);flex-shrink:0}
.navthumb{width:22px;height:22px;border-radius:50%;object-fit:cover;vertical-align:middle;margin-right:6px;background:var(--card2)}
.urole{padding:6px 8px;border-radius:7px;border:1px solid var(--bor2);background:var(--card);color:var(--txt);font-family:var(--f);font-size:12px}

/* ── Mobile ──────────────────────────────────────────────────── */
/* Every page (.hero-body, .sec-hd, .srchpage, .va-inner, .libpage,
   .cfgpage) shares the same 56px side padding — that's the single
   biggest lever for "too cramped on a phone", so it's the first thing
   trimmed at each breakpoint below. */
@media (max-width: 900px) {
  .hero-body, .sec-hd, .srchpage, .va-inner, .libpage, .cfgpage, .row {
    padding-left: 24px !important;
    padding-right: 24px !important;
  }
}

@media (max-width: 640px) {
  .hero-body, .sec-hd, .srchpage, .va-inner, .libpage, .cfgpage, .row {
    padding-left: 14px !important;
    padding-right: 14px !important;
  }

  /* Nav: five items at desktop padding won't fit a phone width — shrink
     padding/font first, and let it scroll horizontally as a fallback
     rather than wrapping into a second row or overflowing the screen. */
  .nav {
    max-width: calc(100vw - 20px);
    overflow-x: auto;
    -ms-overflow-style: none; scrollbar-width: none;
  }
  .nav::-webkit-scrollbar { display: none; }
  .ni { padding: 7px 12px; font-size: 12px; }

  /* Extra top clearance below the fixed nav — every page uses the same
     --navh-based padding-top, which is a fixed assumed value rather than
     the nav's real rendered height, so this adds a safety margin on
     mobile rather than relying on that assumption being exact. Also
     covers the Calendar page specifically, whose title+Refresh row uses
     justify-content:space-between (title pinned to the far left edge,
     button to the far right) — full-width edge-to-edge like that is
     exactly what ends up peeking out from behind the nav pill (which is
     centered and narrower than the screen) if clearance is even
     slightly short, since the nav's blurred background only covers its
     own centered width, not the full row underneath it. */
  .hero-body, .sec-hd, .srchpage, .va-inner, .libpage, .cfgpage {
    padding-top: calc(var(--navh) + 20px) !important;
  }

  /* Hero: desktop sizing (100vh tall, 56px title) is oversized on a
     phone screen and pushes everything below the fold. */
  .hero { height: 62vh; min-height: 320px; max-height: 460px; }
  .hero-title { font-size: 30px; letter-spacing: -1px; }
  .hero-desc { font-size: 13px; -webkit-line-clamp: 2; }
  .hero-meta { font-size: 12px; }
  .hero-acts { flex-wrap: wrap; }
  .btn-hero { padding: 10px 18px !important; font-size: 13px !important; }

  .libtitle { font-size: 22px; }
  .libhd { flex-wrap: wrap; gap: 12px; }
  .searchbar { max-width: 100% !important; }

  /* Library/search grids: 138px card columns are fine on desktop but
     leave awkward leftover space on a ~375-414px phone — drop the
     minimum so 2 full columns fit cleanly instead of 1.5. */
  .libgrid { grid-template-columns: repeat(auto-fill, minmax(108px, 1fr)) !important; gap: 16px 10px !important; }
  .cposter { width: 100%; height: auto; aspect-ratio: 2/3; }

  /* Calendar: 7 columns is unavoidable for a month grid, so this is
     about making each cell survive at ~45-50px wide rather than
     changing the layout shape. */
  .cal-cell { min-height: 56px; padding: 3px; gap: 2px; }
  .cal-cellnum { font-size: 10px; width: 16px; height: 16px; }
  .cal-pill { font-size: 8px; padding: 1px 3px; }
  .cal-cellmore { font-size: 8px; }
  .cal-weekday { font-size: 9px; }
  .cal-monthlabel { font-size: 14px; min-width: 120px; }
  .cal-navbtn { width: 28px; height: 28px; font-size: 14px; }
  .cal-chips { gap: 6px; }
  .cal-chip { padding: 5px 10px; font-size: 11px; }

  /* Modals: keep them comfortably inside the viewport with room to
     scroll instead of getting clipped or forcing horizontal scroll. */
  .modal { width: 94%; max-height: 88vh; overflow-y: auto; }
  .mbody { padding: 18px 16px 20px; }
  .macts { flex-wrap: wrap; }
  .hero-title, .mtitle { word-break: break-word; }

  /* Config: 6 tabs wrapping onto multiple lines looks broken — scroll
     horizontally instead, same fallback pattern as the main nav. */
  .cfgtabs {
    flex-wrap: nowrap; overflow-x: auto; gap: 2px;
    -ms-overflow-style: none; scrollbar-width: none;
  }
  .cfgtabs::-webkit-scrollbar { display: none; }
  .cfgtab { padding: 9px 12px; font-size: 13px; }
  .cfgsec { padding: 16px; }

  /* Every settings section that pairs two fields side by side
     (Stream preferences, Pending movies, TorBox pacing, Spot check
     schedule, etc.) uses this exact inline grid-template-columns value —
     collapsing it to one column is the single change that fixes all of
     them at once, since a CSS class can't otherwise win against an
     inline style without this. */
  div[style*="grid-template-columns:1fr 1fr"] { grid-template-columns: 1fr !important; }
  div[style*="grid-template-columns: 1fr 1fr"] { grid-template-columns: 1fr !important; }

  /* Season/quality action rows (Scan HD / Scan 4K / Scan HD+4K / Remove,
     and similar button clusters) already wrap via inline flex-wrap in
     most places — this is a defensive backstop for the few that don't. */
  .season-btn, .cal-rescan-btn { font-size: 11px; padding: 5px 9px; }
}

@media (max-width: 400px) {
  .hero-title { font-size: 24px; }
  .libgrid { grid-template-columns: repeat(auto-fill, minmax(92px, 1fr)) !important; gap: 12px 8px !important; }
  .cal-cell { min-height: 48px; }
  .cal-pill { display: none; }   /* too tight to show pill text at this width — the day still opens the detail panel */
}
</style>
</head>
<body>

<!-- Nav -->
<nav class="nav">
  <button class="ni on" onclick="nav('home',this)">Home</button>
  <button class="ni"    onclick="nav('search',this)">Search</button>
  <button class="ni"    onclick="nav('calendar',this)">Calendar</button>
  <button class="ni"    onclick="nav('library',this)">Library</button>
  <button class="ni admin-only" id="navConfig" onclick="nav('config',this)">Config</button>
  <button class="ni" id="navUser" onclick="openAccountModal()" title="Account" style="display:none"></button>
</nav>

<!-- SIGN IN WITH PLEX -->
<div class="authbg" id="authBg">
  <div class="authcard" style="text-align:center">
    <h2>AIOGateway</h2>
    <div class="authsub" id="authSub">Sign in with the Plex account you use to watch.</div>
    <button class="btn" id="plexSignInBtn" onclick="startPlexSignIn()"
            style="width:100%;justify-content:center;padding:12px;background:#e5a00d;color:#1f1f1f;font-weight:800;border:none">
      Sign in with Plex
    </button>
    <div id="plexWaiting" style="display:none;margin-top:14px;color:var(--mut);font-size:13px;line-height:1.5">
      Finish signing in in the Plex window…<br>
      <a id="plexOpenLink" href="#" target="_blank" rel="noopener" style="color:var(--acc)">Open it again</a>
      · <a href="#" onclick="cancelPlexSignIn();return false" style="color:var(--mut)">Cancel</a>
    </div>
    <div class="autherr" id="authErr"></div>
  </div>
</div>

<!-- ACCOUNT -->
<div class="mbg" id="accountModal" onclick="if(event.target===this)closeAccountModal()">
  <div class="modal" style="max-width:380px">
    <div class="mbody" style="padding:26px;text-align:center">
      <img id="accountThumb" alt="" style="width:64px;height:64px;border-radius:50%;object-fit:cover;background:var(--card2);margin-bottom:10px">
      <div class="mtitle" id="accountTitle" style="font-size:18px;margin-bottom:2px"></div>
      <div style="color:var(--mut);font-size:13px;margin-bottom:6px" id="accountEmail"></div>
      <div style="color:var(--mut);font-size:12px;margin-bottom:20px" id="accountRole"></div>
      <div style="display:flex;gap:10px;justify-content:center">
        <button class="btn bg2" onclick="logout()">Sign out</button>
        <button class="btn bg2" onclick="closeAccountModal()">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- SEARCH -->
<div id="pSearch" style="display:none">
  <div class="srchpage">
    <div class="srch-hd">
      <div class="srch-bar-wrap">
        <input class="srch-input" id="srchInput" placeholder="Search movies and series…"
               oninput="onSrchInput(this.value)" onkeydown="if(event.key==='Enter')doSearch()"/>
        <button class="srch-clear" id="srchClear" onclick="clearSearch()">Clear</button>
      </div>
      <div class="srch-tabs">
        <button class="srch-tab on" id="tabAll"    onclick="setTab('all',this)">All</button>
        <button class="srch-tab"    id="tabMovies" onclick="setTab('movie',this)">Movies</button>
        <button class="srch-tab"    id="tabSeries" onclick="setTab('series',this)">Series</button>
      </div>
    </div>
    <div class="srch-status" id="srchStatus"></div>
    <div class="srch-grid" id="srchGrid">
      <div class="srch-empty">
        
        <div class="srch-empty-title">Search for movies and series</div>
        <div class="srch-empty-sub">Powered by Cinemeta — the same source as Stremio</div>
      </div>
    </div>
  </div>
</div>

<!-- HOME -->
<div id="pHome">
  <div class="hero" id="hero">
    <div class="hero-bg" id="heroBg"></div>
    <div class="hero-ov"></div>
    <div class="hero-body">
      <img class="hero-logo" id="heroLogo" alt=""/>
      <div class="hero-title" id="heroTitle">…</div>
      <div class="hero-meta" id="heroMeta"></div>
      <div class="hero-desc" id="heroDesc"></div>
      <div class="hero-dots" id="heroDots"></div>
      <div class="hero-acts">
        <button class="btn-hero btn-add" id="heroBtn" onclick="heroAdd()">Add to Plex</button>
        <button class="btn-hero btn-info" onclick="heroInfo()">More Info</button>
      </div>
    </div>
  </div>

  <div class="rows">
    <div class="sec">
      <div class="sec-hd">
        <span class="sec-title">Popular — Movie</span>
        <button class="view-all" onclick="viewAll('Popular — Movie','catalog/movie/top.json','movie')">View All ›</button>
      </div>
      <div class="row" id="rowM">
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
      </div>
    </div>
    <div class="sec">
      <div class="sec-hd">
        <span class="sec-title">Popular — Series</span>
        <button class="view-all" onclick="viewAll('Popular — Series','catalog/series/top.json','series')">View All ›</button>
      </div>
      <div class="row" id="rowS">
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
      </div>
    </div>
  </div>
</div>

<!-- CALENDAR -->
<div id="pCalendar" style="display:none">
  <div class="cfgpage" style="padding-top:calc(var(--navh) + 28px)">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;flex-wrap:wrap;gap:12px">
      <h2 style="font-size:26px;font-weight:800;letter-spacing:-.5px">Calendar</h2>
      <button class="btn" onclick="loadCalendar(true)" style="padding:6px 14px;font-size:12px">Refresh</button>
    </div>
    <div class="cal-chips" id="calChips"></div>
    <div class="cal-monthbar">
      <button class="cal-navbtn" onclick="calChangeMonth(-1)" aria-label="Previous month">‹</button>
      <span class="cal-monthlabel" id="calMonthLabel"></span>
      <button class="cal-navbtn" onclick="calChangeMonth(1)" aria-label="Next month">›</button>
    </div>
    <div id="calBody">
      <div style="color:var(--mut);font-size:14px;padding:40px 0">Loading calendar…</div>
    </div>
  </div>
</div>

<!-- LIBRARY -->
<div id="pLibrary" style="display:none">
  <div class="libpage">
    <div class="libhd">
      <span class="libtitle">My Library</span>
      <div class="searchbar" style="max-width:300px">
                <input placeholder="Filter…" oninput="libSetQuery(this.value)" id="libFilter"/>
      </div>
    </div>
    <div class="cal-chips" id="libChips" style="margin-bottom:20px"></div>
    <div id="libGrid">
      <div style="color:var(--mut);font-size:14px;padding:40px 0">Loading…</div>
    </div>
  </div>
</div>

<!-- CONFIG -->
<div id="pConfig" style="display:none">
  <div class="cfgpage">
    <h2 style="font-size:26px;font-weight:800;margin-bottom:24px;letter-spacing:-.5px">Config</h2>

    <div class="cfgtabs">
      <button class="cfgtab on" id="cfgtab-connections" onclick="switchCfgTab('connections')">Connections</button>
      <button class="cfgtab" id="cfgtab-fuse" onclick="switchCfgTab('fuse')">FUSE</button>
      <button class="cfgtab" id="cfgtab-streams" onclick="switchCfgTab('streams')">Streams</button>
      <button class="cfgtab" id="cfgtab-migrate" onclick="switchCfgTab('migrate')">Migrate</button>
      <button class="cfgtab" id="cfgtab-users" onclick="switchCfgTab('users')">Users</button>
      <button class="cfgtab" id="cfgtab-backup" onclick="switchCfgTab('backup')">Backup/Restore</button>
    </div>

    <!-- ── Connections ──────────────────────────────────────────── -->
    <div class="cfgpanel on" id="cfgpanel-connections">
      <div class="cfgsec">
        <h3>AIOStreams (release search)</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          AIOStreams finds releases using your addons, filters and sorting; TorBox then adds
          and serves them. Only torrent results are used, and a release is only added if
          TorBox has it cached. Find the UUID and password on your AIOStreams configure page.
          Without AIOStreams, TorBox's own search is used.
        </div>
        <div style="display:grid;grid-template-columns:2fr 1fr 1fr;gap:10px;max-width:760px">
          <div><div class="authlabel" style="margin-top:0">URL</div>
            <input class="authinput" style="max-width:none" id="aioUrl" placeholder="http://192.168.1.x:3000" spellcheck="false" autocomplete="off"></div>
          <div><div class="authlabel" style="margin-top:0">UUID</div>
            <input class="authinput" style="max-width:none" id="aioUuid" type="password" autocomplete="off" spellcheck="false"></div>
          <div><div class="authlabel" style="margin-top:0">Password</div>
            <input class="authinput" style="max-width:none" id="aioPass" type="password" autocomplete="new-password"
                   onkeydown="if(event.key==='Enter')saveAiostreams()"></div>
        </div>
        <div id="aioHint" style="color:var(--mut);font-size:12px;margin:8px 0 14px"></div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
          <button class="btn bp" id="aioSaveBtn" onclick="saveAiostreams()">Save &amp; test</button>
          <button class="btn" onclick="testAiostreams()">Test</button>
          <button class="btn bg2" id="aioClearBtn" onclick="clearAiostreams()" style="display:none">Remove</button>
        </div>
        <div class="tresult" id="aioResult" style="margin-top:12px"></div>
      </div>
      <div class="cfgsec">
        <h3>TorBox connection</h3>
        <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">API key</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:6px">
          <input type="password" id="tbKeyInput" autocomplete="off" spellcheck="false" placeholder="Paste your TorBox API key" style="flex:1;min-width:220px;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px"
                 onkeydown="if(event.key==='Enter')saveTorboxKey()">
          <button class="btn bp" id="tbKeySaveBtn" onclick="saveTorboxKey()">Save</button>
          <button class="btn bg2" id="tbKeyClearBtn" onclick="clearTorboxKey()" style="display:none">Remove</button>
        </div>
        <div id="tbKeyHint" style="color:var(--mut);font-size:12px;margin-bottom:16px;line-height:1.5">
          Find it at torbox.app → Settings → API. The key is checked with TorBox before it's saved.
        </div>
        <div class="chips" id="cfgChips">…</div>
        <div class="tresult" id="tresult" style="margin-top:14px"></div>
        <button class="btn bp" onclick="runTest()">Test connection</button>
      </div>
      <div class="cfgsec">
        <h3>AllDebrid connection</h3>
        <div style="color:var(--mut);font-size:12px;margin-bottom:10px;line-height:1.5">
          A second debrid source. While this is off, AllDebrid results are dropped before
          ranking — nothing AllDebrid serves is shown or added. While it's on, only releases
          AllDebrid already has <strong>cached</strong> are used; a magnet is never left
          downloading to make one appear. TorBox and AllDebrid can both be on at once.
        </div>
        <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">API key</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:6px">
          <input type="password" id="adKeyInput" autocomplete="off" spellcheck="false" placeholder="Paste your AllDebrid API key" style="flex:1;min-width:220px;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px"
                 onkeydown="if(event.key==='Enter')saveAlldebridKey()">
          <button class="btn bp" id="adKeySaveBtn" onclick="saveAlldebridKey()">Save</button>
          <button class="btn bg2" id="adKeyClearBtn" onclick="clearAlldebridKey()" style="display:none">Remove</button>
        </div>
        <div id="adKeyHint" style="color:var(--mut);font-size:12px;margin-bottom:14px;line-height:1.5">
          Find it at alldebrid.com → My account → API keys. The key is checked with AllDebrid before it's saved.
        </div>
        <label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer;margin-bottom:12px">
          <input type="checkbox" id="adEnabled" style="cursor:pointer" onchange="saveAlldebridEnabled()">
          Use AllDebrid for cached links
        </label>
        <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;margin-bottom:12px">
          <label style="font-size:12px">When both have a release cached, prefer<br>
            <select id="prefDebrid" class="authinput" style="width:170px;margin-top:4px" onchange="savePreferredDebrid()">
              <option value="torbox">TorBox</option>
              <option value="alldebrid">AllDebrid</option>
            </select></label>
        </div>
        <button class="btn bp" onclick="testAlldebrid()">Test connection</button>
        <div class="tresult" id="adResult" style="margin-top:12px"></div>
      </div>
      <div class="cfgsec">
        <h3>Plex setup</h3>
        <div class="checklist">
          <div>1. Add library folders in Plex (under your FUSE mountpoint):<br>
            <code>Movies</code>&nbsp;&nbsp;<code>Movies4K</code>&nbsp;&nbsp;<code>Series</code>&nbsp;&nbsp;<code>Series4K</code>
          </div>
          <div>2. Plex → Settings → Webhooks → Add:<br>
            <code id="wurl">http://&lt;host&gt;:8001/webhook/plex</code>
          </div>
          <div>3. Enter your TorBox API key above.</div>
          <div style="margin:6px 0 2px;color:var(--txt);font-weight:600">Library scans</div>
          <div>New files are announced to Plex in batches: a scan is sent once nothing new has arrived
            for the quiet period, or at most every max wait during a long add. Seasons of one show share one scan.</div>
          <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;margin:6px 0 10px">
            <label style="font-size:12px">Quiet period (seconds)<br>
              <input type="number" id="plexScanQuiet" min="5" step="1" placeholder="30" class="authinput" style="width:130px;margin-top:4px"></label>
            <label style="font-size:12px">Max wait (seconds)<br>
              <input type="number" id="plexScanMax" min="30" step="1" placeholder="300" class="authinput" style="width:130px;margin-top:4px"></label>
            <button class="btn bp" onclick="savePlexScanSettings()">Save</button>
            <span id="plexScanSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
          </div>
          <div>4. Plex → Settings → Library: turn OFF "Perform extensive media analysis during maintenance" and
            set "Generate video preview thumbnails" / "chapter thumbnails" to Never — those read whole files.</div>
        </div>
      </div>
    </div>

    <!-- ── FUSE ─────────────────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-fuse">
      <div class="cfgsec">
        <h3>FUSE tuning</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          These control the virtual filesystem's read/cache/prefetch behaviour.
          They're set via environment variables in <code>docker-compose.yml</code>
          and require a container restart to change — shown here read-only for
          reference.
        </div>
        <div class="chips" id="fuseChips">…</div>
      </div>
    </div>

    <!-- ── Streams ──────────────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-streams">
      <div class="cfgsec">
        <h3>Release selection</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          Only torrents already cached on TorBox are ever added. Among those,
          the built-in order prefers higher resolution, better sources
          (Remux &gt; BluRay &gt; WEB-DL &gt; WEBRip &gt; HDTV), torrents already in
          your account, and more seeders — these preferences rank above that.
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Preferred language</div>
            <input type="text" id="prefLanguage" placeholder="e.g. English"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Preferred audio (comma-separated)</div>
            <input type="text" id="prefAudio" placeholder="e.g. Atmos, TrueHD"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>


        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer" onclick="document.getElementById('preferPacks').click()">
          <input type="checkbox" id="preferPacks" checked style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Prefer season packs (one torrent add covers the whole season)</span>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Min size (GB, 0 = no limit)</div>
            <input type="number" id="minSizeGb" min="0" step="0.5" placeholder="0"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Max size (GB, 0 = no limit)</div>
            <input type="number" id="maxSizeGb" min="0" step="0.5" placeholder="0"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>

        <div style="margin-bottom:20px">
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Exclude words (comma-separated)</div>
          <input type="text" id="excludeWords" placeholder="e.g. CAM, TS, TELESYNC, HDCAM"
                 style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          <div style="color:var(--mut);font-size:12px;margin-top:6px">
            Releases whose name matches any of these are never added. Matched as a
            whole word, case-insensitive.
          </div>
        </div>

        <div style="margin-bottom:20px;max-width:260px">
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Minimum cached 4K releases before adding 4K</div>
          <input type="number" id="min4kCandidates" min="1" step="1" placeholder="1"
                 style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          <div style="color:var(--mut);font-size:12px;margin-top:6px">
            A 4K version is only added when TorBox has at least this many cached
            4K releases for the title (HD is added either way). 1 = add 4K
            whenever any cached 4K release exists.
          </div>
        </div>

        <button class="btn bp" onclick="saveStreamPrefs()">Save</button>
        <span id="streamPrefsSaved" style="color:var(--grn);font-size:13px;display:none;margin-left:10px">Saved</span>
      </div>
      <div class="cfgsec">
        <h3>Auto new-episode discovery</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          Periodically checks every series in your library for newly-aired
          episodes and adds them as soon as TorBox has a cached torrent (HD,
          plus 4K when available). Aired episodes with nothing cached yet are
          retried on every check until one shows up or the retry window
          below passes.
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer" onclick="document.getElementById('autoEpEnabled').click()">
          <input type="checkbox" id="autoEpEnabled" checked style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Automatically add new episodes</span>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Check every (minutes)</div>
            <input type="number" id="autoEpInterval" min="5" step="5" placeholder="10"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Give up retrying after (days)</div>
            <input type="number" id="autoEpRetryDays" min="0" step="0.5" placeholder="3"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:10px">
          <button class="btn bp" onclick="saveAutoEpisodes()">Save</button>
          <button class="btn" onclick="runAutoEpisodeSweepNow()">Check now</button>
          <span id="autoEpSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
        <div id="autoEpSweepResult" style="margin-top:12px;font-size:13px"></div>
      </div>
      <div class="cfgsec">
        <h3>Pending movies</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          When you add a movie TorBox has nothing cached for yet — usually
          because it hasn't been released — it's tracked instead of the add
          failing, and retried on the same schedule as the episode check
          above until a cached torrent shows up.
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer" onclick="document.getElementById('pendingMvEnabled').click()">
          <input type="checkbox" id="pendingMvEnabled" checked style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Automatically retry movies that aren't cached yet</span>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;max-width:460px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Give up retrying after (days)</div>
            <input type="number" id="pendingMvRetryDays" min="0" step="1" placeholder="30"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Digital delay after theatrical (days)</div>
            <input type="number" id="digitalDelayDays" min="0" step="1" placeholder="21"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>
        <div style="color:var(--mut);font-size:12px;margin:-10px 0 20px;line-height:1.5">
          Don't search a movie at all until this many days after its theatrical
          release date. Cinemeta only has the theatrical date, not the actual
          digital/VOD date — this is a heuristic to reduce the odds of catching
          a pre-digital cam/TS leak, not an exact check. Set to 0 to search as
          soon as theatrical release has passed.
        </div>

        <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px">
          <button class="btn bp" onclick="savePendingMovies()">Save</button>
          <button class="btn" onclick="runPendingMoviesSweepNow()">Check now</button>
          <span id="pendingMvSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
        <div id="pendingMvSweepResult" style="font-size:13px;margin-bottom:16px"></div>
      </div>
      <div class="cfgsec">
        <h3>Library repair</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          Every file in your library is a real file in a torrent cached on
          TorBox — nothing is added until that's true. If a file stops
          working (TorBox dropped the torrent, the link keeps failing), it's
          marked for repair: re-checked, and if it's really gone, swapped for
          another cached torrent of the same quality without changing its
          path in Plex. If TorBox has nothing cached left, it's removed, and
          the normal sweeps add it back once something appears. Restored
          backups are bound the same way.
        </div>
        <div style="max-width:260px;margin-bottom:20px">
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Check for broken files every (minutes)</div>
          <input type="number" id="repairInterval" min="1" step="1" placeholder="10"
                 style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <button class="btn bp" onclick="saveRepairSettings()">Save</button>
          <button class="btn" onclick="runRepairNow()">Repair now</button>
          <span id="repairSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
      </div>
      <div class="cfgsec">
        <h3>TorBox API saver</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:16px;line-height:1.5">
          Modelled on warpbox. Every TorBox call — adds, scans, repair, spot
          check, migration — waits in one shared queue instead of failing, and
          playback reads always go first. CDN links, search results and your
          account's torrent list are cached locally, expired links are
          refreshed in place, a torrent that keeps failing is quarantined by a
          circuit breaker, and the first/last few MB of every file are kept on
          disk so Plex scans and analysis never hit TorBox twice. All values
          apply immediately.
        </div>
        <div class="chips" id="tbStats" style="margin-bottom:18px">…</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px 20px;margin-bottom:16px;max-width:620px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">API requests / minute (max 300)</div>
            <input type="number" id="tbRpm" min="0" step="1" placeholder="250" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Search requests / minute</div>
            <input type="number" id="tbSearchRpm" min="0" step="1" placeholder="120" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Torrent adds / hour</div>
            <input type="number" id="tbCreatePerHour" min="0" step="1" placeholder="60" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">CDN link cache (minutes)</div>
            <input type="number" id="tbCdnTtl" min="0" step="1" placeholder="120" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Search cache (minutes)</div>
            <input type="number" id="tbSearchCache" min="0" step="1" placeholder="360" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Hold reads while rate limited (s)</div>
            <input type="number" id="tbHang" min="0" step="1" placeholder="120" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Probe cache: head per file (MB)</div>
            <input type="number" id="tbProbeHead" min="0" step="1" placeholder="16" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Probe cache: tail per file (MB)</div>
            <input type="number" id="tbProbeTail" min="0" step="1" placeholder="16" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Probe cache: total size (MB)</div>
            <input type="number" id="tbProbeMax" min="0" step="1" placeholder="4096" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Releases tried per add / repair</div>
            <input type="number" id="tbMaxCand" min="0" step="1" placeholder="3" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <button class="btn bp" onclick="saveTorboxSaver()">Save</button>
          <button class="btn" onclick="torboxSyncNow(this)">Sync account now</button>
          <button class="btn bg2" onclick="loadTorboxStats()">Refresh stats</button>
          <span id="tbSaverSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
      </div>
      <div class="cfgsec">
        <h3>Spot check</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          Audit of your whole library — checks every tracked series for aired
          episodes missing from seasons you've actually requested (a season
          you never asked for isn't flagged just because it exists), and
          every pending movie whose release date has passed, then adds
          anything TorBox now has cached.
          Runs through the same TorBox queue as everything else, so
          a check that finds a lot of gaps can take a while — the summary
          at the end shows what was found and what still couldn't be,
          right now, for either reason.
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;cursor:pointer" onclick="document.getElementById('spotVerifyQuality').click()">
          <input type="checkbox" id="spotVerifyQuality" checked style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Also check that files are the quality they're filed under</span>
        </div>
        <div style="color:var(--mut);font-size:12px;margin:-10px 0 16px;line-height:1.5">
          Looks at each file's name for a resolution that contradicts where
          it's filed (e.g. in Movies4K but the file is 1080p) and replaces it
          with a cached release of the right quality. This can remove a
          working file, so it's conservative: a file name with no clear
          resolution tag is left alone.
        </div>

        <div class="cal-chips" id="spotScopeChips" style="margin-bottom:16px"></div>
        <button class="btn bp" onclick="runSpotCheck()">Run spot check</button>

        <div style="border-top:1px solid var(--bor);margin:22px 0 18px"></div>

        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:12px">Run automatically</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:16px;max-width:460px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Every how many hours (0 = off)</div>
            <input type="number" id="spotIntervalHours" min="0" step="1" placeholder="0"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Scheduled scope</div>
            <select id="spotScheduledScope"
                    style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
              <option value="both">Movies + TV shows</option>
              <option value="movies">Movies only</option>
              <option value="series">TV shows only</option>
            </select>
          </div>
        </div>
        <div style="color:var(--mut);font-size:12px;margin-bottom:16px;line-height:1.5">
          E.g. set to 1 for hourly, 5 for every 5 hours. Scheduled runs use
          the same check-then-fix behavior as the manual button above, just
          on a timer instead of a click.
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <button class="btn bp" onclick="saveSpotCheckSchedule()">Save</button>
          <span id="spotScheduleSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
      </div>
    </div>

    <!-- ── Migrate ──────────────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-migrate">
      <div class="cfgsec">
        <h3>Migrate from Radarr / Sonarr</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:20px;line-height:1.5">
          Point this at an existing Radarr or Sonarr instance. It reads every
          movie (or series + season) that already has a downloaded file
          there, then adds each one from cached TorBox torrents — nothing is
          copied or changed on the Radarr/Sonarr side. Adding torrents is
          rate limited by TorBox (see "Torrent adds / hour"), so a large
          library takes a while; titles already in your TorBox account and
          season packs don't count against it.
        </div>

        <div style="max-width:340px;margin-bottom:16px">
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Service</div>
          <select id="migSvc" onchange="migSvcChanged()"
            style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
            <option value="radarr">Radarr (movies)</option>
            <option value="sonarr">Sonarr (series)</option>
          </select>
        </div>

        <div style="display:grid;grid-template-columns:2fr 1fr;gap:16px;max-width:600px;margin-bottom:16px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">URL</div>
            <input type="text" id="migUrl" placeholder="http://192.168.1.x:7878"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px" id="migKeyLabel">API key</div>
            <input type="password" id="migKey" placeholder="API key"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <button class="btn bp" onclick="migSaveAndTest()">Save &amp; test connection</button>
          <button class="btn" onclick="migLoadPreview()">Load library</button>
        </div>
        <div class="tresult" id="migTestResult" style="margin-top:12px"></div>

        <div id="migPreviewWrap" style="display:none;margin-top:22px">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
            <div style="font-size:13px;color:var(--mut)" id="migPreviewSummary"></div>
            <div style="display:flex;gap:16px;font-size:12px">
              <a href="#" onclick="migSelectAll(true);return false" style="color:var(--acc2);text-decoration:none">Select all</a>
              <a href="#" onclick="migSelectAll(false);return false" style="color:var(--acc2);text-decoration:none">Select none</a>
            </div>
          </div>
          <div id="migList" style="display:flex;flex-direction:column;gap:8px;max-height:380px;overflow-y:auto;padding-right:4px"></div>
          <div style="margin-top:18px">
            <button class="btn bp" onclick="migStart()">Start migration</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ── Users ────────────────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-users">
      <div class="cfgsec">
        <h3>Users</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:16px;line-height:1.5">
          People sign in with their Plex account. Anyone your Plex server is shared with
          can sign in and shows up here the first time they do; the server owner is always
          an admin. Access is re-checked with Plex every few hours, so unsharing the server
          in Plex signs them out here too.<br><br>
          <b style="color:var(--txt)">Admins</b> can do everything.
          <b style="color:var(--txt)">Users</b> can browse, search, see the calendar, library
          and available releases, and request movies, series, seasons and episodes — but
          can't delete anything, force scans, pick specific releases, or open Config.
          <b style="color:var(--txt)">Block</b> keeps someone out even while they still have
          Plex access. Changing a role or blocking signs them out.
        </div>
        <div class="ulist" id="userList"><div style="color:var(--mut);font-size:13px">Loading…</div></div>
      </div>
    </div>

    <!-- ── Backup/Restore ───────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-backup">
      <div class="cfgsec">
        <h3>Backup &amp; restore</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          Download a backup of your settings and library (every movie and
          series, with seasons and quality tiers). Restored titles are
          matched to cached torrents in your TorBox account in the
          background and appear in Plex as each one is added. Titles you
          already have keep their current binding and stay playable
          throughout. Check "Replace" to also remove titles the backup
          doesn't contain.
        </div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <button class="btn bp" onclick="downloadBackup()">Download backup</button>
          <button class="btn" onclick="document.getElementById('restoreFile').click()">Restore from file…</button>
          <input type="file" id="restoreFile" accept="application/json" style="display:none" onchange="restoreFromFile(event)">
          <label style="display:flex;align-items:center;gap:6px;color:var(--mut);font-size:13px;cursor:pointer">
            <input type="checkbox" id="restoreReplace" style="cursor:pointer">
            Replace (remove titles not in the backup)
          </label>
        </div>
        <div id="restoreResult" style="margin-top:12px;font-size:13px"></div>
      </div>
    </div>

  </div>
</div>

<!-- MODAL -->
<div class="mbg" id="modal" onclick="bgClose(event)">
  <div class="modal">
    <div class="mhero" id="mhero" style="position:relative">
      <div class="mhero-ov"></div>
      <button class="mclose" onclick="closeModal()">✕</button>
    </div>
    <div class="mbody">
      <div class="mtitle" id="mtitle"></div>
      <div class="mmeta" id="mmeta"></div>
      <div class="mpills" id="mpills"></div>
      <div class="moverview" id="moverview"></div>
      <!-- Season picker — shown for series only -->
      <div id="seasonPickerWrap" style="display:none;margin-bottom:14px">
        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:8px">Season</div>
        <div class="season-picker" id="seasonPicker"></div>
      </div>
      <div class="macts">
        <button class="mbtn mbtn-add" id="maddBtn" onclick="modalAdd()">Add to Plex</button>
        <button class="mbtn mbtn-close" onclick="closeModal()">Close</button>
      </div>
      <div id="mMovieNote" style="display:none;color:var(--mut);font-size:12px;margin-top:12px;line-height:1.5"></div>
      <div class="macts" id="mMovieActs" style="display:none;margin-top:10px">
        <button class="mbtn mbtn-close" id="mSearchAnyway" onclick="modalSearchAnyway()" style="display:none">Search anyway</button>
        <button class="mbtn mbtn-close" onclick="openReleasesModal(modalItem.id, modalItem.name, modalItem.poster, parseInt((modalItem.releaseInfo||'').slice(0,4))||null)">Show releases</button>
      </div>
    </div>
  </div>
</div>

<!-- MIGRATE PROGRESS MODAL -->
<div class="mbg" id="migModal">
  <div class="modal" style="max-width:420px">
    <div class="mbody" style="padding:26px 26px 22px">
      <div class="mtitle" style="font-size:18px;margin-bottom:4px" id="migModalTitle">Migrating…</div>
      <div style="color:var(--mut);font-size:13px;margin-bottom:20px;min-height:16px" id="migModalCurrent"></div>
      <div style="background:var(--card2);border-radius:8px;height:10px;overflow:hidden;margin-bottom:10px">
        <div id="migBar" style="height:100%;width:0%;background:var(--acc);border-radius:8px;transition:width 300ms"></div>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--mut);margin-bottom:16px">
        <span id="migCount">0 / 0</span>
        <span id="migStatusLabel">Starting…</span>
      </div>
      <div id="migErrors" style="max-height:120px;overflow-y:auto;font-size:12px;color:var(--red);display:flex;flex-direction:column;gap:4px;margin-bottom:6px"></div>
      <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:14px">
        <button class="btn bg2" id="migCancelBtn" onclick="migCancel()">Cancel</button>
        <button class="btn bp" id="migCloseBtn" onclick="migCloseModal()" style="display:none">Done</button>
      </div>
    </div>
  </div>
</div>

<!-- SPOT CHECK MODAL -->
<div class="mbg" id="spotCheckModal">
  <div class="modal" style="max-width:560px">
    <div class="mbody" style="padding:26px 26px 22px">
      <div class="mtitle" style="font-size:18px;margin-bottom:4px" id="spotModalTitle">Spot checking…</div>
      <div style="color:var(--mut);font-size:13px;margin-bottom:20px;min-height:16px" id="spotModalCurrent"></div>
      <div id="spotProgressWrap">
        <div style="background:var(--card2);border-radius:8px;height:10px;overflow:hidden;margin-bottom:10px">
          <div id="spotBar" style="height:100%;width:0%;background:var(--acc);border-radius:8px;transition:width 300ms"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--mut);margin-bottom:16px">
          <span id="spotCount">0 / 0</span>
          <span id="spotStatusLabel">Starting…</span>
        </div>
      </div>
      <div id="spotResults" style="display:none;max-height:360px;overflow-y:auto;margin-bottom:6px"></div>
      <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:14px">
        <button class="btn bg2" id="spotCancelBtn" onclick="spotCancel()">Cancel</button>
        <button class="btn bp" id="spotCloseBtn" onclick="spotCloseModal()" style="display:none">Done</button>
      </div>
    </div>
  </div>
</div>


<script>
// ── State ──────────────────────────────────────────────────────
let heroItems = [], heroIdx = 0, heroTimer = null;
let stubs = [], allStubs = [], libImdb = new Set();
let libQuery = '';
let libStateFilter = 'all';   // all | active | repairing
let libMoviePage = 1, libSeriesPage = 1;
let libMovieViewAll = false, libSeriesViewAll = false;
const LIB_PAGE_SIZE = 24;
const LIB_FILTERS = [
  { id: 'all',         label: 'All' },
  { id: 'active',      label: 'Active' },
  { id: 'repairing',   label: 'Repairing' },
  { id: 'missing',     label: 'Missing' },
  { id: 'upcoming',    label: 'Upcoming' },
  { id: 'unavailable', label: 'Unavailable' },
];
let modalItem = null;
const C = '/api/cinemeta';

// ── Nav ────────────────────────────────────────────────────────
function nav(page, el) {
  if (page === 'config' && !isAdmin()) return;
  ['Home','Search','Calendar','Library','Config'].forEach(p => {
    document.getElementById('p'+p).style.display = 'none';
  });
  document.querySelectorAll('.ni').forEach(n => n.classList.remove('on'));
  document.getElementById('p'+page.charAt(0).toUpperCase()+page.slice(1)).style.display = '';
  el.classList.add('on');
  if (page === 'search')   { document.getElementById('srchInput').focus(); }
  if (page === 'library')  loadLib();
  if (page === 'config')   loadCfg();
  if (page === 'calendar') loadCalendar();
}

// ── Cinemeta fetch ─────────────────────────────────────────────
async function cmFetch(path) {
  const r = await fetch(`${C}/${path}`);
  if (!r.ok) throw new Error(`Cinemeta ${r.status}: ${path}`);
  return r.json();
}

// ── Hero ───────────────────────────────────────────────────────
async function loadHero() {
  const data = await cmFetch('catalog/movie/top.json');
  const items = (data.metas || []).filter(m => m.background || m.poster).slice(0, 9);
  if (!items.length) return;
  heroItems = items;
  buildDots();
  setHero(0);
  heroTimer = setInterval(() => setHero((heroIdx+1) % heroItems.length), 7000);
}

function buildDots() {
  document.getElementById('heroDots').innerHTML =
    heroItems.map((_,i) => `<div class="hero-dot${i===0?' on':''}" onclick="setHero(${i})"></div>`).join('');
}

function setHero(i) {
  heroIdx = i;
  const m = heroItems[i];
  if (!m) return;

  // Backdrop
  const bg = m.background || m.poster || '';
  document.getElementById('heroBg').style.backgroundImage = bg ? `url(${bg})` : 'none';

  // Logo
  const logoEl = document.getElementById('heroLogo');
  if (m.logo) {
    logoEl.src = m.logo;
    logoEl.style.display = 'block';
    document.getElementById('heroTitle').style.display = 'none';
  } else {
    logoEl.style.display = 'none';
    document.getElementById('heroTitle').style.display = 'block';
    document.getElementById('heroTitle').textContent = m.name || '';
  }

  // Meta
  const year = m.releaseInfo ? m.releaseInfo.split('–')[0] : '';
  const rating = m.imdbRating ? `${m.imdbRating}` : '';
  const genres = (m.genres || []).slice(0,2).join(' · ');
  const metaParts = [year, genres].filter(Boolean);
  document.getElementById('heroMeta').innerHTML =
    metaParts.map(p=>`<span>${p}</span>`).join('<span class="hero-sep">•</span>') +
    (rating ? `<span class="hero-sep">•</span><span class="hero-rating">${rating}</span>` : '');

  document.getElementById('heroDesc').textContent = m.description || '';

  // Dots
  document.querySelectorAll('.hero-dot').forEach((d,j) => d.classList.toggle('on', j===i));

  // Add button state
  const btn = document.getElementById('heroBtn');
  const inLib = libImdb.has(m.id);
  btn.textContent = inLib ? 'In Library' : 'Add to Plex';
  btn.className = 'btn-hero btn-add' + (inLib ? ' added' : '');
}

function heroAdd()  { if (heroItems[heroIdx]) openModal(heroItems[heroIdx], 'movie'); }
function heroInfo() { if (heroItems[heroIdx]) openModal(heroItems[heroIdx], 'movie'); }

// ── Item store — avoids embedding raw JSON in onclick attrs ───
const _items = {};
function _store(m, type) { _items[m.id] = { m, type }; }
function _click(id) { const e = _items[id]; if (e) openModal(e.m, e.type); }

// ── Card rows ──────────────────────────────────────────────────
function card(m, type) {
  _store(m, type);
  const inLib = libImdb.has(m.id);
  const year = (m.releaseInfo || '').split(/[-–]/)[0].trim();
  const rating = m.imdbRating || '';
  const name = (m.name || '').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const sid = CSS.escape(m.id);
  return `<div class="card${inLib?' inlib':''}" id="c${sid}" onclick="_click('${m.id.replace(/'/g,"\\'")}')">
    <div class="cposter">
      ${m.poster ? `<img src="${m.poster}" loading="lazy" onload="this.classList.add('loaded')" onerror="this.parentNode.style.background='#1a1a28'"/>` : ''}
      ${rating ? `<div class="crating">${rating}</div>` : ''}
      <div class="ccheck">✓</div>
    </div>
    <div class="cname">${name}</div>
    <div class="cyear">${year}</div>
  </div>`;
}

async function loadRow(elId, path, type) {
  try {
    const data = await cmFetch(path);
    const items = (data.metas || []).slice(0, 20);
    _rowCache[path] = data.metas || [];   // cache full list for View All
    document.getElementById(elId).innerHTML = items.map(m => card(m, type)).join('');
    return items;
  } catch(e) {
    document.getElementById(elId).innerHTML = `<div style="color:var(--red);font-size:13px;padding:20px">Failed: ${e.message}</div>`;
    return [];
  }
}

// ── Modal ──────────────────────────────────────────────────────
// Selected season: null = all, number = specific season
let _selectedSeason = null;
let _newSeasonsToAdd = [];

async function openModal(item, type) {
  modalItem = { ...item, _type: type };
  _selectedSeason = null;
  _newSeasonsToAdd = [];

  // Try to get full meta if we only have preview
  if (!item.description && item.id) {
    try {
      const full = await cmFetch(`meta/${type}/${item.id}.json`);
      if (full.meta) { modalItem = { ...full.meta, _type: type }; item = modalItem; }
    } catch {}
  }

  document.getElementById('mtitle').textContent = item.name || '';
  const year = item.releaseInfo ? item.releaseInfo.split('–')[0] : '';
  const rating = item.imdbRating ? `<span class="mrating">${item.imdbRating}</span>` : '';
  document.getElementById('mmeta').innerHTML =
    `<span>${type==='series'?'Series':'Movie'}</span>` +
    (year ? `<span>•</span><span>${year}</span>` : '') +
    rating;
  document.getElementById('mpills').innerHTML = (item.genres||[]).slice(0,4).map(g=>`<span class="mpill">${g}</span>`).join('');
  document.getElementById('moverview').textContent = item.description || '';
  document.getElementById('mhero').style.backgroundImage =
    `url(${item.background || item.poster || ''})`;

  const inLib = libImdb.has(item.id);
  // Movies: offer a search even before release, and a view of what's out there
  const note = document.getElementById('mMovieNote');
  const acts = document.getElementById('mMovieActs');
  const relDate = item.released ? new Date(item.released) : null;
  const unreleased = type === 'movie' && relDate && relDate > new Date();
  acts.style.display = type === 'movie' ? '' : 'none';
  document.getElementById('mSearchAnyway').style.display = unreleased && !inLib ? '' : 'none';
  note.style.display = unreleased ? '' : 'none';
  note.textContent = unreleased
    ? `Not released yet (${relDate.toLocaleDateString()}). Adding tracks it and searches automatically after release; "Search anyway" searches right now.`
    : '';
  const btn = document.getElementById('maddBtn');
  btn.textContent = inLib ? 'In Library' : 'Add to Plex';
  btn.className = 'mbtn mbtn-add' + (inLib ? ' added' : '');
  btn.disabled = false;

  // Season picker for series
  const wrap = document.getElementById('seasonPickerWrap');
  const picker = document.getElementById('seasonPicker');
  if (type === 'series') {
    wrap.style.display = 'block';
    picker.innerHTML = '<div style="color:var(--mut);font-size:12px">Loading seasons…</div>';
    buildSeasonPicker(item.id, picker);
  } else {
    wrap.style.display = 'none';
    picker.innerHTML = '';
  }

  document.getElementById('modal').classList.add('open');
}

async function buildSeasonPicker(imdbId, picker) {
  try {
    const [r, watchR] = await Promise.all([
      fetch(`/api/series/${imdbId}/episodes`),
      fetch(`/api/series/${imdbId}/season-watch`).catch(() => null),
    ]);
    const d = await r.json();
    const episodes = d.episodes || [];
    let watchEnabled = false;
    if (watchR) {
      try { watchEnabled = (await watchR.json()).enabled === true; } catch {}
    }

    // Every season Cinemeta lists at all — including ones that haven't
    // started airing yet (announced, zero episodes aired so far). Used
    // to matter only for aired seasons, but that meant a fully-upcoming
    // season could never even appear as an option, let alone be picked
    // up by "New" below.
    const seasons = [...new Set(
      episodes.map(e => e.season)
    )].filter(Boolean).sort((a,b)=>a-b);

    if (!seasons.length) {
      picker.innerHTML = '<div style="color:var(--mut);font-size:12px">No seasons found</div>';
      return;
    }

    // A season is "requested" if at least one of its episodes already has
    // a stub (HD or 4K) — same definition used in the library's series
    // detail modal, so the two stay visually consistent.
    const requestedSeasons = new Set(
      episodes.filter(e => e.has_hd || e.has_4k).map(e => e.season)
    );

    // Per-season aired/total counts, to tell an old finished season apart
    // from one still actively airing — the "New" button below only wants
    // the latter.
    const seasonCounts = {};
    episodes.forEach(e => {
      if (!e.season) return;
      seasonCounts[e.season] = seasonCounts[e.season] || { total: 0, aired: 0 };
      seasonCounts[e.season].total++;
      if (e.aired) seasonCounts[e.season].aired++;
    });

    // Concrete case: Cinemeta already lists a specific not-yet-requested,
    // purely-upcoming season (zero episodes aired). This stays a one-time
    // grab, same as always — a real, dated season is a different,
    // more certain situation than the speculative case below, so
    // clicking it doesn't also enable persistent watch as a side effect.
    _newSeasonsToAdd = seasons.filter(s =>
      !requestedSeasons.has(s) &&
      seasonCounts[s] && seasonCounts[s].aired === 0
    );
    const hasConcreteNew = _newSeasonsToAdd.length > 0;

    const title  = (modalItem && modalItem.name || '').replace(/'/g, "\\'");
    const poster = modalItem && modalItem.poster || '';
    const year   = parseInt((modalItem && modalItem.releaseInfo || '').slice(0,4)) || '';

    let newBtn;
    if (hasConcreteNew) {
      newBtn = `<button class="season-btn" id="maddNewSeasonsBtn"
        style="background:var(--acc);color:#000;border:none"
        onclick="modalAddNewSeasons()">New (${_newSeasonsToAdd.length})</button>`;
    } else if (watchEnabled) {
      // Nothing concrete to grab right now, but the indefinite watch is
      // already on — the auto-episode sweep is handling this on its
      // own, every cycle, with no action needed. Informational, not a
      // one-time-action button; clicking offers to turn it back off.
      // Green specifically signals "this is active/confirmed", same
      // meaning green already has for an already-requested season chip.
      newBtn = `<button class="season-btn" id="maddNewSeasonsBtn"
        style="background:var(--grn);color:#04140d;border:none"
        title="Automatically tracking whatever the next season turns out to be — click to stop"
        onclick="disableSeasonWatch('${imdbId}')">Watching ✓</button>`;
    } else if (seasons.length > 0) {
      // Nothing concrete, watch not yet on — offer to enable it. This is
      // a SET-ONCE action: unlike the concrete case above, clicking this
      // doesn't grab one specific season, it turns on indefinite
      // tracking so every future gap (this one and any after it) gets
      // handled automatically without needing to come back and click
      // again. Orange (matching "All") since it's an action to take, not
      // yet an active/confirmed state — that's reserved for green.
      newBtn = `<button class="season-btn" id="maddNewSeasonsBtn"
        style="background:var(--acc);color:#000;border:none"
        title="Enables automatic tracking of whatever the next season turns out to be, indefinitely — set once, no need to click again for future seasons"
        onclick="enableSeasonWatch('${imdbId}','${title}','${poster}',${year || 'null'})">New</button>`;
      _newSeasonsToAdd = [];   // nothing to directly add via modalAddNewSeasons in this state
    } else {
      newBtn = `<button class="season-btn" id="maddNewSeasonsBtn" disabled>New</button>`;
      _newSeasonsToAdd = [];
    }

    // All button + New button + season buttons
    const allBtn = `<button class="season-btn all-btn on" id="sbAll" onclick="selectSeason(null)">All</button>`;
    const seasonBtns = seasons.map(s => {
      const requestedCls = requestedSeasons.has(s) ? ' requested' : '';
      const btnTitle = requestedSeasons.has(s) ? ' title="Already requested"' : '';
      return `<button class="season-btn${requestedCls}" id="sb${s}" onclick="selectSeason(${s})"${btnTitle}>S${String(s).padStart(2,'0')}</button>`;
    }).join('');
    picker.innerHTML = allBtn + newBtn + seasonBtns;
  } catch {
    picker.innerHTML = '<div style="color:var(--mut);font-size:12px">Could not load seasons</div>';
  }
}

async function enableSeasonWatch(imdbId, title, poster, year) {
  const btn = document.getElementById('maddNewSeasonsBtn');
  if (btn) { btn.textContent = 'Enabling…'; btn.disabled = true; }
  try {
    const r = await fetch(`/api/series/${imdbId}/season-watch`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, poster, year: year || null }),
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'Could not enable');
    }
    toast(`Now watching "${title}" for its next season — will track automatically`, 'ok');
    if (btn) {
      btn.textContent = 'Watching ✓';
      btn.disabled = false;
      btn.style.background = 'var(--grn)';
      btn.style.color = '#04140d';
      btn.onclick = () => disableSeasonWatch(imdbId);
      btn.title = 'Automatically tracking whatever the next season turns out to be — click to stop';
    }
  } catch (exc) {
    toast(exc.message || 'Could not enable season watch', 'er');
    if (btn) { btn.textContent = 'New'; btn.disabled = false; }
  }
}

async function disableSeasonWatch(imdbId) {
  const btn = document.getElementById('maddNewSeasonsBtn');
  if (btn) { btn.textContent = 'Stopping…'; btn.disabled = true; }
  try {
    await fetch(`/api/series/${imdbId}/season-watch`, { method: 'DELETE' });
    toast('Stopped watching for new seasons', 'ok');
    if (btn) {
      btn.textContent = 'New';
      btn.disabled = false;
      btn.style.background = 'var(--acc)';
      btn.style.color = '#000';
      btn.title = 'Enables automatic tracking of whatever the next season turns out to be, indefinitely — set once, no need to click again for future seasons';
      const title  = (modalItem && modalItem.name || '').replace(/'/g, "\\'");
      const poster = modalItem && modalItem.poster || '';
      const year   = parseInt((modalItem && modalItem.releaseInfo || '').slice(0,4)) || null;
      btn.onclick = () => enableSeasonWatch(imdbId, title, poster, year);
    }
  } catch {
    toast('Could not stop season watch', 'er');
    if (btn) btn.disabled = false;
  }
}

function selectSeason(season) {
  _selectedSeason = season;
  // Update button styles
  document.querySelectorAll('.season-btn').forEach(b => b.classList.remove('on'));
  const target = season === null
    ? document.getElementById('sbAll')
    : document.getElementById('sb' + season);
  if (target) target.classList.add('on');
}

function closeModal() { document.getElementById('modal').classList.remove('open'); }
function bgClose(e) { if (e.target === document.getElementById('modal')) closeModal(); }

async function modalAdd() {
  if (!modalItem) return;
  const btn = document.getElementById('maddBtn');
  const imdbId = modalItem.id;

  if (!imdbId || !imdbId.startsWith('tt')) {
    toast('No IMDb ID for this title', 'er'); return;
  }
  if (libImdb.has(imdbId)) { toast('Already in library', 'in'); return; }

  btn.textContent = 'Loading streams…';
  btn.disabled = true;

  const title = modalItem.name || '';
  const year  = parseInt((modalItem.releaseInfo||'').slice(0,4)) || null;
  const type  = modalItem._type === 'series' ? 'series' : 'movie';

  try {
    const poster = modalItem.poster || '';
    const body = { imdb_id:imdbId, title, year, media_type:type, poster };
    if (type === 'series' && _selectedSeason !== null) {
      body.season = _selectedSeason;
    }
    const r = await fetch('/api/add', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify(body),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || JSON.stringify(d));

    if (type === 'movie' && d.pending) {
      // Nothing cached to add yet — tracked for automatic retry, not "In Library".
      btn.textContent = 'Tracking…'; btn.className = 'mbtn mbtn-add pending'; btn.disabled = true;
      document.getElementById('mSearchAnyway').style.display = '';
      toast(_pendingMessage(title, d), 'ok');
      return;
    }

    if (type === 'series' && d.wanted) {
      // Nothing's aired in this specific season yet — registered so the
      // auto-episode sweep stubs it automatically once its first episode
      // actually airs. Not "In Library" yet, same reasoning as a pending
      // movie above.
      btn.textContent = 'Tracking…'; btn.className = 'mbtn mbtn-add pending'; btn.disabled = true;
      toast(`Season ${d.season} of "${title}" hasn't aired yet — tracking it and will add automatically once it does`, 'ok');
      return;
    }

    libImdb.add(imdbId);
    btn.textContent = 'In Library'; btn.className = 'mbtn mbtn-add added'; btn.disabled = false;

    // Update hero button
    const hm = heroItems[heroIdx];
    if (hm && hm.id === imdbId) {
      const hb = document.getElementById('heroBtn');
      hb.textContent = 'In Library'; hb.className = 'btn-hero btn-add added';
    }

    // Mark card
    const c = document.getElementById('c'+modalItem.id);
    if (c) c.classList.add('inlib');

    if (type === 'series') {
      const seasonLabel = _selectedSeason !== null ? ` (Season ${_selectedSeason})` : '';
      toast(`Added "${title}"${seasonLabel} — scanning in background…`, 'ok');
      pollScan(imdbId, title);
    } else {
      toast(`Added "${title}" — ${d.streams_found} streams${d.has_4k?' (HD+4K)':''}`, 'ok');
    }
    await syncStubs();
  } catch(e) {
    btn.textContent = 'Add to Plex'; btn.disabled = false;
    // Surface the full TorBox diagnostic in the toast
    const msg = e.message || 'Unknown error';
    toast(msg.length > 120 ? msg.slice(0, 117) + '…' : msg, 'er');
    console.error('Add to Plex error:', e.message);
  }
}

function _pendingMessage(title, d) {
  if (!d.searched) return `"${title}" isn't released yet — tracking it. Use "Search anyway" to search now.`;
  if (d.streams_found) return `"${title}": found ${d.streams_found} release(s) but none cached on TorBox yet — tracking it`;
  return `"${title}": nothing found yet — tracking it and will add automatically once it's available`;
}

async function modalSearchAnyway() {
  if (!modalItem) return;
  const b = document.getElementById('mSearchAnyway');
  b.disabled = true; b.textContent = 'Searching…';
  const title = modalItem.name || '';
  try {
    const r = await fetch('/api/add', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ imdb_id: modalItem.id, title, media_type: 'movie', force_search: true,
        year: parseInt((modalItem.releaseInfo||'').slice(0,4)) || null, poster: modalItem.poster || '' }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Search failed');
    const btn = document.getElementById('maddBtn');
    if (d.pending) {
      btn.textContent = 'Tracking…'; btn.className = 'mbtn mbtn-add pending'; btn.disabled = true;
      toast(_pendingMessage(title, d), 'in');
    } else {
      libImdb.add(modalItem.id);
      btn.textContent = 'In Library'; btn.className = 'mbtn mbtn-add added';
      b.style.display = 'none';
      toast(`Added "${title}"${d.has_4k ? ' (HD+4K)' : ''}`, 'ok');
      if (_libraryVisible()) await refreshLibrary(); else await syncStubs();
    }
  } catch (exc) { toast(exc.message, 'er'); }
  b.disabled = false; b.textContent = 'Search anyway';
}

async function openReleasesModal(imdbId, title, poster, year) {
  document.getElementById('releasesDlg')?.remove();
  const dlg = document.createElement('div');
  dlg.id = 'releasesDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.82);backdrop-filter:blur(14px);z-index:320;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `<div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:24px;max-width:720px;width:100%;max-height:84vh;display:flex;flex-direction:column">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${_esc(title)}</div>
      <div id="relSub" style="font-size:13px;color:var(--mut);margin-bottom:14px">Searching…</div>
      <div id="relList" style="overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:8px"></div>
      <button class="mbtn mbtn-close" style="margin-top:14px" onclick="document.getElementById('releasesDlg').remove()">Close</button>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);

  let d;
  try {
    const r = await fetch(`/api/movies/${encodeURIComponent(imdbId)}/releases`);
    d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Search failed');
  } catch (exc) {
    document.getElementById('relSub').innerHTML = `<span style="color:var(--red)">${_esc(exc.message)}</span>`;
    return;
  }
  const src = d.source === 'aiostreams' ? 'AIOStreams' : 'TorBox search';
  const rel = d.released ? new Date(d.released).toLocaleDateString() : null;
  const shown = d.releases.length;
  const total = d.total_cached != null ? d.total_cached : shown;
  // Per-service tally straight from the search, so a service that returned
  // nothing (or nothing cached) is visible rather than just absent.
  const svcNames = { alldebrid: 'AllDebrid', torbox: 'TorBox', realdebrid: 'Real-Debrid',
                     premiumize: 'Premiumize', unchecked: 'unchecked' };
  const svc = Object.entries(d.by_service || {})
    .map(([k, v]) => `${svcNames[k] || k} ${v.cached}/${v.total} cached`).join(' · ');
  document.getElementById('relSub').textContent =
    (total > shown
      ? `top ${shown} of ${total} cached releases from ${src}`
      : `${shown} cached release${shown === 1 ? '' : 's'} from ${src}`) +
    (d.unreleased ? ` · not released yet (${rel})` : rel ? ` · released ${rel}` : '') +
    (d.in_library.length ? ` · in library: ${d.in_library.map(q => q.toUpperCase()).join(', ')}` : '') +
    (svc ? ` · ${svc}` : '');
  window._releases = { imdbId, title, poster, year, list: d.releases };
  const list = document.getElementById('relList');
  if (!d.releases.length) {
    list.innerHTML = `<div style="color:var(--mut);font-size:13px;padding:20px 0;text-align:center">Nothing cached yet.</div>`;
    return;
  }
  const badge = (txt, col) => `<span class="cal-badge" style="${col ? `color:${col}` : ''}">${txt}</span>`;
  list.innerHTML = d.releases.map((x, i) => {
    const size = x.size ? `${(x.size / 1024 ** 3).toFixed(2)} GB` : 'size ?';
    const tags = [x.resolution, x.source, x.encode, (x.hdr || []).join(' '), x.seeders ? `${x.seeders} seeders` : '', x.indexer]
      .filter(Boolean).map(_esc).join(' · ');
    // Which service would serve this release, so a mixed list is readable.
    const who = x.service === 'alldebrid' ? 'AllDebrid' : 'TorBox';
    const cache = x.in_account ? badge(`in your ${who}`, 'var(--grn)')
      : x.cached === true ? badge(`cached on ${who}`, 'var(--grn)')
      : x.cached === false ? badge(`not cached on ${who}`, 'var(--red)')
      : badge(`cache unknown (${who})`);
    const canAdd = x.cached !== false && !x.excluded;
    return `<div style="background:var(--card2);border:1px solid var(--bor);border-radius:10px;padding:10px 12px;display:flex;gap:10px;align-items:center${x.excluded ? ';opacity:.55' : ''}">
      <div style="flex:1;min-width:0">
        <div style="font-size:12px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${_esc(x.name)}">${_esc(x.name) || 'Unnamed release'}</div>
        <div style="font-size:11px;color:var(--mut);margin-top:3px">${size}${tags ? ' · ' + tags : ''}</div>
        <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap">${badge(x.quality.toUpperCase())}${cache}${x.excluded ? badge('excluded by your filters') : ''}</div>
      </div>
      ${canAdd ? `<button class="admin-only cal-rescan-btn" onclick="addRelease(${i}, this)">Add</button>` : ''}
    </div>`;
  }).join('');
}

async function addRelease(i, btn) {
  const R = window._releases; const x = R && R.list[i];
  if (!x) return;
  btn.disabled = true; btn.textContent = 'Adding…';
  try {
    const r = await fetch(`/api/movies/${encodeURIComponent(R.imdbId)}/releases/add`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ hash: x.hash, title: R.title, year: R.year,
                             poster: R.poster || '', service: x.service || null }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Could not add release');
    btn.textContent = '✓ Added';
    toast(`Added ${d.quality.toUpperCase()}: ${d.file}`, 'ok');
    libImdb.add(R.imdbId);
    document.getElementById('pendingMovieDlg')?.remove();
    if (_libraryVisible()) refreshLibrary(); else syncStubs();
  } catch (exc) {
    toast(exc.message, 'er');
    btn.disabled = false; btn.textContent = 'Add';
  }
}

async function modalAddNewSeasons() {
  if (!modalItem || !_newSeasonsToAdd.length) return;
  const btn = document.getElementById('maddNewSeasonsBtn');
  const imdbId = modalItem.id;
  const title  = modalItem.name || '';
  const year   = parseInt((modalItem.releaseInfo||'').slice(0,4)) || null;
  const poster = modalItem.poster || '';

  // /api/add only takes one season at a time, so adding "everything new"
  // for a show with several new seasons is a sequential loop, same as any
  // other multi-item action in this app (season scans, migration) —
  // each request still goes through the normal per-item TorBox pacing.
  const seasons = [..._newSeasonsToAdd];
  let added = 0, wanted = 0, failed = 0;

  for (const season of seasons) {
    btn.textContent = `Adding S${String(season).padStart(2,'0')}… (${added + wanted + failed + 1}/${seasons.length})`;
    btn.disabled = true;
    try {
      const r = await fetch('/api/add', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imdb_id: imdbId, title, year, media_type: 'series', poster, season }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.detail || 'Add failed');
      if (d.wanted) {
        // Nothing's aired in this season yet — registered so the
        // recurring auto-episode sweep stubs it automatically once its
        // first episode actually airs, no second click needed later.
        wanted++;
      } else {
        added++;
        pollScan(imdbId, title);
      }
    } catch (exc) {
      failed++;
      console.error(`Add new season S${season} failed:`, exc.message);
    }
  }

  const mainBtn = document.getElementById('maddBtn');
  if (added > 0) {
    // Something's actually stubbed now — genuinely in Plex.
    libImdb.add(imdbId);
    mainBtn.textContent = 'In Library'; mainBtn.className = 'mbtn mbtn-add added';
    const c = document.getElementById('c'+modalItem.id);
    if (c) c.classList.add('inlib');
  } else if (wanted > 0) {
    // Only registered future season(s) to watch for — nothing's actually
    // in Plex yet, so don't claim it is. Matches the same "Tracking…"
    // treatment a pending movie gets.
    mainBtn.textContent = 'Tracking…'; mainBtn.className = 'mbtn mbtn-add pending';
  }

  // Nothing new left to add now — clear inline styles entirely so it
  // falls back to the exact same look as an unselected season chip,
  // same as buildSeasonPicker's disabled state.
  btn.textContent = 'New';
  btn.disabled = true;
  btn.removeAttribute('style');
  _newSeasonsToAdd = [];


  const parts = [];
  if (added)  parts.push(`${added} added — scanning in background`);
  if (wanted) parts.push(`${wanted} tracked for when ${wanted !== 1 ? 'they air' : 'it airs'}`);
  if (failed) parts.push(`${failed} failed`);
  toast(`"${title}": ${parts.join(', ')}`, failed && !added && !wanted ? 'er' : 'ok');
  await syncStubs();
}

// ── Stubs / Library ────────────────────────────────────────────
let _stubsSignature = null;   // null = not fetched yet (an empty library is '')
async function syncStubs() {
  try {
    const r = await fetch('/api/stubs');
    const d = await r.json();
    stubs = d.stubs || [];
    libImdb = new Set(stubs.map(s => s.media_id.split('_')[0]));
    // Something was added/removed (background sweep, another admin, a
    // picked release): if the Library is on screen, refresh it — including
    // the pending list — so a found movie stops showing as Tracking.
    const sig = stubs.map(s => s.stub_id + s.state).sort().join('|');
    const changed = _stubsSignature !== null && sig !== _stubsSignature;
    _stubsSignature = sig;
    if (changed && _libraryVisible() && !_libRefreshing) refreshLibrary();
  } catch {}
}

let _libRefreshing = false;
function _libraryVisible() {
  const el = document.getElementById('pLibrary');
  return !!el && el.style.display !== 'none';
}
async function refreshLibrary() {
  if (!_libRefreshing) await loadLib();
}

// ── Calendar ──────────────────────────────────────────────────
let _calScheduled = {};   // {key: timeoutId} for track-and-rescan timers
let calViewYear  = new Date().getFullYear();
let calViewMonth = new Date().getMonth();   // 0-indexed
let calFilter    = 'all';
let calEntries   = [];
let calSelectedDate = null;

const CAL_FILTERS = [
  { id:'all',      label:'All' },
  { id:'episodes', label:'Episodes' },
  { id:'movies',   label:'Movies' },
  { id:'library',  label:'In library' },
  { id:'upcoming', label:'Upcoming' },
];

function calMatchesFilter(e) {
  if (calFilter === 'all')      return true;
  if (calFilter === 'episodes') return e.type === 'episode';
  if (calFilter === 'movies')   return e.type === 'movie';
  if (calFilter === 'library')  return !!e.in_library;
  if (calFilter === 'upcoming') return !e.in_library;
  return true;
}

function calChangeMonth(delta) {
  calViewMonth += delta;
  if (calViewMonth < 0)  { calViewMonth = 11; calViewYear--; }
  if (calViewMonth > 11) { calViewMonth = 0;  calViewYear++; }
  calSelectedDate = null;
  loadCalendar();
}

function _calDaysBetween(a, b) {
  return Math.round((b - a) / 86400000);
}

async function loadCalendar(force) {
  const body = document.getElementById('calBody');
  body.innerHTML = '<div style="color:var(--mut);font-size:14px;padding:40px 0">Loading…</div>';

  const today = new Date(); today.setHours(0,0,0,0);
  const gridStart = new Date(calViewYear, calViewMonth, 1);
  gridStart.setDate(gridStart.getDate() - gridStart.getDay());
  const gridEnd = new Date(calViewYear, calViewMonth + 1, 0);
  gridEnd.setDate(gridEnd.getDate() + (6 - gridEnd.getDay()));

  const daysBack  = Math.max(0, _calDaysBetween(gridStart, today));
  const daysAhead = Math.max(0, _calDaysBetween(today, gridEnd));

  try {
    const d = await (await fetch(`/api/calendar?days_back=${daysBack}&days_ahead=${daysAhead}`)).json();
    calEntries = d.entries || [];
    renderCalChips();
    renderMonthGrid();
  } catch(e) {
    body.innerHTML = `<div style="color:var(--red);font-size:13px">Failed to load calendar: ${e.message}</div>`;
  }
}

function renderCalChips() {
  const wrap = document.getElementById('calChips');
  wrap.innerHTML = CAL_FILTERS.map(f =>
    `<button class="cal-chip${calFilter===f.id?' on':''}" onclick="calSetFilter('${f.id}')">${f.label}</button>`
  ).join('');
}

function calSetFilter(id) {
  calFilter = id;
  renderCalChips();
  renderMonthGrid();
}

function renderMonthGrid() {
  const monthDate = new Date(calViewYear, calViewMonth, 1);
  document.getElementById('calMonthLabel').textContent =
    monthDate.toLocaleDateString(undefined, { month:'long', year:'numeric' });

  const today = new Date(); today.setHours(0,0,0,0);
  const todayKey = today.toISOString().slice(0,10);

  const grouped = {};
  calEntries.filter(calMatchesFilter).forEach(e => {
    (grouped[e.release_date] = grouped[e.release_date] || []).push(e);
  });

  const firstDow = monthDate.getDay();
  const daysInMonth = new Date(calViewYear, calViewMonth + 1, 0).getDate();

  let weekdays = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']
    .map(d => `<div class="cal-weekday">${d}</div>`).join('');

  let cells = '';
  for (let i = 0; i < firstDow; i++) cells += `<div class="cal-cell blank"></div>`;

  for (let d = 1; d <= daysInMonth; d++) {
    const key = `${calViewYear}-${String(calViewMonth+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const isToday = key === todayKey;
    const dayEvents = grouped[key] || [];
    const maxShow = 2;
    const pills = dayEvents.slice(0, maxShow).map(e => {
      const cls = e.type === 'movie' ? 'movie' : (e.in_library ? 'inlib' : '');
      return `<div class="cal-pill ${cls}" title="${e.title}">${e.title}</div>`;
    }).join('');
    const more = dayEvents.length > maxShow
      ? `<div class="cal-cellmore">+${dayEvents.length - maxShow} more</div>` : '';

    cells += `<div class="cal-cell${key===calSelectedDate?' selected':''}" onclick="calSelectDay('${key}')">
      <span class="cal-cellnum${isToday?' today':''}">${d}</span>
      ${pills}${more}
    </div>`;
  }

  document.getElementById('calBody').innerHTML = `
    <div class="cal-weekrow">${weekdays}</div>
    <div class="cal-grid">${cells}</div>
    <div id="calDetail"></div>
  `;

  if (calSelectedDate) renderCalDetail();
}

function calSelectDay(key) {
  calSelectedDate = key;
  renderMonthGrid();
  document.getElementById('calDetail').scrollIntoView({ behavior:'smooth', block:'nearest' });
}

function renderCalDetail() {
  const wrap = document.getElementById('calDetail');
  if (!wrap) return;
  const today = new Date(); today.setHours(0,0,0,0);
  const isPast = calSelectedDate < today.toISOString().slice(0,10);
  const dayEvents = calEntries.filter(calMatchesFilter).filter(e => e.release_date === calSelectedDate);

  const label = _calDateLabel(calSelectedDate, calSelectedDate === today.toISOString().slice(0,10));

  if (!dayEvents.length) {
    wrap.innerHTML = `<div class="cal-detail">
      <div class="cal-detail-date">${label}</div>
      <div class="cal-detail-empty">No releases this day.</div>
    </div>`;
    return;
  }

  const rows = dayEvents.map(e => _calEntryHtml(e, isPast)).join('');
  wrap.innerHTML = `<div class="cal-detail">
    <div class="cal-detail-date">${label}</div>
    <div class="cal-entries">${rows}</div>
  </div>`;
}

function _calDateLabel(dateStr, isToday) {
  const d = new Date(dateStr + 'T12:00:00');  // noon avoids DST edge cases
  const opts = { weekday:'long', month:'long', day:'numeric' };
  const fmt = d.toLocaleDateString(undefined, opts);
  return isToday ? `Today — ${fmt}` : fmt;
}

function _calEntryHtml(e, isPast) {
  const poster = e.poster
    ? `<img class="cal-poster" src="${e.poster}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
    : '';
  const posterFallback = `<div class="cal-poster-placeholder" style="${e.poster?'display:none':''}">
    ${e.type === 'movie' ? '🎬' : '📺'}
  </div>`;

  // release_ts is a precise Unix timestamp (date + time), not just a date —
  // this is also exactly what governs whether an episode is eligible for
  // auto-stubbing (_is_aired compares against this same timestamp), so
  // showing it here means what you see in the calendar is the same clock
  // the stubbing logic is actually using, not just the release date.
  const relDate = new Date(e.release_ts * 1000);
  const timeStr = relDate.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

  const sub = e.type === 'episode'
    ? `S${String(e.season).padStart(2,'0')}E${String(e.episode).padStart(2,'0')} — ${e.episode_name} · ${timeStr}`
    : `${e.type === 'movie' ? 'Movie' : 'Series'} · ${e.release_date} · ${timeStr}`;

  const badges = [];
  if (e.in_library)    badges.push('<span class="cal-badge inlib">In library</span>');
  if (e.type==='movie' && e.date_type==='theatrical') badges.push('<span class="cal-badge theatrical">Theatrical date · digital may differ</span>');

  const key = e.type === 'episode'
    ? `${e.imdb_id}:${e.season}:${e.episode}`
    : e.imdb_id;

  const rescanBtn = _calRescanBtnHtml(e, key, isPast);

  return `<div class="cal-entry${e.in_library?' inlib':''}${!isPast?' future':''}"
    onclick="_calEntryClick('${e.imdb_id}','${e.type}')">
    ${poster}${posterFallback}
    <div class="cal-info">
      <div class="cal-title">${e.title}</div>
      <div class="cal-sub">${sub}</div>
      ${badges.length ? `<div class="cal-badges">${badges.join('')}</div>` : ''}
    </div>
    ${rescanBtn}
  </div>`;
}

function _calRescanBtnHtml(e, key, isPast) {
  // Only show for content not yet in library OR for past episodes that might
  // now have streams available (scheduled rescan within 30min of release).
  const isScheduled = !!_calScheduled[key];
  const relTs = e.release_ts * 1000;
  const now = Date.now();
  const minsAgo = (now - relTs) / 60000;
  const minsUntil = (relTs - now) / 60000;

  if (minsUntil > 0 && minsUntil <= 60) {
    // Releases within the next hour — show "scan at release" button
    return `<button class="cal-rescan-btn${isScheduled?' pending':''}"
      id="crbtn_${key.replace(/[:]/g,'_')}"
      onclick="event.stopPropagation();calScheduleRescan(${JSON.stringify(e)},${JSON.stringify(key)})"
      title="Schedule a rescan 30 minutes after release">
      ${isScheduled ? '⏳ Scheduled' : '⏰ Schedule scan'}
    </button>`;
  }
  if (minsAgo >= 0 && minsAgo <= 120) {
    // Recently released (within 2 hours) — scan now (or scheduled)
    return `<button class="cal-rescan-btn${isScheduled?' pending':''}"
      id="crbtn_${key.replace(/[:]/g,'_')}"
      onclick="event.stopPropagation();calRescanNow(${JSON.stringify(e)},${JSON.stringify(key)})"
      title="Scan for this release now">
      ${isScheduled ? '⏳ Scanning…' : '🔍 Scan now'}
    </button>`;
  }
  if (!e.in_library && isPast) {
    return `<button class="cal-rescan-btn"
      onclick="event.stopPropagation();calRescanNow(${JSON.stringify(e)},${JSON.stringify(key)})"
      title="Try to find a stream for this">
      Search
    </button>`;
  }
  return '';
}

function _calEntryClick(imdbId, type) {
  // Re-use the existing modal opening logic
  if (type === 'episode') {
    const g = window._libGroups && Object.values(window._libGroups).find(g => g.imdb === imdbId);
    if (g) openSeriesDetail(Object.keys(window._libGroups).find(k => window._libGroups[k] === g));
  } else {
    // Open the discovery modal if we have the item data
    const stub = null;  // could open a Cinemeta modal here in future
  }
}

async function calScheduleRescan(entry, key) {
  const btnId = 'crbtn_' + key.replace(/:/g, '_');
  const btn = document.getElementById(btnId);
  if (btn) { btn.textContent = '⏳ Scheduled'; btn.classList.add('pending'); }

  const relTs = entry.release_ts * 1000;
  const delayMs = Math.max(0, relTs - Date.now()) + 30 * 60 * 1000;  // 30 min after release

  // Cancel any existing timer for this key
  if (_calScheduled[key]) clearTimeout(_calScheduled[key]);

  _calScheduled[key] = setTimeout(async () => {
    delete _calScheduled[key];
    await calRescanNow(entry, key);
  }, delayMs);

  const minsUntil = Math.round(delayMs / 60000);
  toast(`Will scan for "${entry.title}" in ~${minsUntil} min`, 'ok');
}

async function calRescanNow(entry, key) {
  const btnId = 'crbtn_' + key.replace(/:/g, '_');
  const btn = document.getElementById(btnId);
  if (btn) { btn.textContent = '⏳ Scanning…'; btn.classList.add('pending'); }

  try {
    if (entry.type === 'episode') {
      // Use the single-episode add endpoint
      const r = await fetch(`/api/series/${entry.imdb_id}/episode/${entry.season}/${entry.episode}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imdb_id: entry.imdb_id, title: entry.title, media_type: 'series' }),
      });
      const d = await r.json();
      if (r.ok && d.stubbed) {
        toast(`${entry.title} S${String(entry.season).padStart(2,'0')}E${String(entry.episode).padStart(2,'0')} added`, 'ok');
        if (btn) { btn.textContent = '✓ Added'; btn.classList.remove('pending'); btn.classList.add('active'); }
        setTimeout(loadCalendar, 1500);
      } else {
        throw new Error(d.detail || 'No stream found yet');
      }
    } else {
      // Movie: try adding via the main add endpoint
      const r = await fetch('/api/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imdb_id: entry.imdb_id, title: entry.title, media_type: 'movie' }),
      });
      const d = await r.json();
      if (r.ok && d.pending) {
        // Not resolvable yet (commonly not released) — tracked for
        // automatic retry, not actually added, so don't claim "Added".
        toast(`"${entry.title}" isn't available yet — tracking it for automatic retry`, 'ok');
        if (btn) { btn.textContent = 'Tracking'; btn.classList.add('pending'); }
      } else if (r.ok) {
        toast(`"${entry.title}" added to library`, 'ok');
        if (btn) { btn.textContent = '✓ Added'; btn.classList.remove('pending'); btn.classList.add('active'); }
        setTimeout(loadCalendar, 1500);
      } else {
        throw new Error(d.detail || 'No stream found');
      }
    }
  } catch(e) {
    toast(e.message || 'Scan failed', 'er');
    if (btn) { btn.textContent = 'Retry'; btn.classList.remove('pending'); }
  }
}

// ── Library ───────────────────────────────────────────────────
let libMissingCounts = {};

let libPendingMovies = [];
let libWantedSeasons = [];
let libSeasonWatch = [];
let libQualityUnavailable = [];

async function loadLib() {
  if (_libRefreshing) return;
  _libRefreshing = true;
  try { await _loadLib(); } finally { _libRefreshing = false; }
}

async function _loadLib() {
  await syncStubs();
  allStubs = [...stubs];
  try {
    const [pm, ws, sw, qu] = await Promise.all([
      fetch('/api/pending-movies').then(r => r.json()).catch(() => ({items:[]})),
      fetch('/api/wanted-seasons').then(r => r.json()).catch(() => ({items:[]})),
      fetch('/api/season-watch').then(r => r.json()).catch(() => ({items:[]})),
      fetch('/api/quality-unavailable').then(r => r.json()).catch(() => ({items:[]})),
    ]);
    libPendingMovies      = pm.items || [];
    libWantedSeasons      = ws.items || [];
    libSeasonWatch        = sw.items || [];
    libQualityUnavailable = qu.items || [];
  } catch {
    libPendingMovies = []; libWantedSeasons = []; libSeasonWatch = []; libQualityUnavailable = [];
  }
  renderLibChips();
  applyLibFilters();
  try {
    const d = await (await fetch('/api/library/missing-counts')).json();
    libMissingCounts = d.counts || {};
    applyLibFilters();   // re-render now that counts are in, without blocking the first paint on them
  } catch {}
}

function libSetQuery(q) {
  libQuery = q;
  libMoviePage = 1; libSeriesPage = 1;
  applyLibFilters();
}

function renderLibChips() {
  document.getElementById('libChips').innerHTML = LIB_FILTERS.map(f =>
    `<button class="cal-chip${libStateFilter === f.id ? ' on' : ''}" onclick="libSetStateFilter('${f.id}')">${f.label}</button>`
  ).join('');
}

function libSetStateFilter(id) {
  libStateFilter = id;
  libMoviePage = 1; libSeriesPage = 1;
  renderLibChips();
  applyLibFilters();
}

function libGoToPage(kind, p) {
  if (kind === 'movie') libMoviePage = p; else libSeriesPage = p;
  applyLibFilters();
  document.getElementById('libGrid').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function libToggleViewAll(kind) {
  if (kind === 'movie') { libMovieViewAll = !libMovieViewAll; libMoviePage = 1; }
  else { libSeriesViewAll = !libSeriesViewAll; libSeriesPage = 1; }
  applyLibFilters();
}

function applyLibFilters() {
  const q = libQuery;
  const textFiltered = q
    ? allStubs.filter(s => (s.title || s.media_id).toLowerCase().includes(q.toLowerCase()))
    : allStubs;
  renderLib(textFiltered);
}

// ── Library: group stubs by base IMDb ID (one card per title) ─
function groupStubs(items) {
  const map = {};
  items.forEach(s => {
    const base = s.media_id.split('_')[0];
    if (!map[base]) map[base] = {
      title: s.title || base,
      imdb: base,
      poster: s.poster || '',
      media_type: s.media_type || 'movie',
      year: s.year || null,
      stubs: []
    };
    if (s.poster && !map[base].poster) map[base].poster = s.poster;
    if (s.year && !map[base].year) map[base].year = s.year;
    map[base].stubs.push(s);
  });
  return Object.values(map);
}

function libGroupCard(g) {
  if (g.pending) {
    const safeId = g.imdb.replace(/[^a-z0-9]/gi,'');
    const posterHtml = g.poster
      ? `<img src="${g.poster}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:10px;opacity:0;transition:opacity .3s" onload="this.style.opacity=1" onerror="this.style.display='none'"/>`
      : '';
    return `<div style="cursor:pointer" onclick="openPendingMovieModal('${safeId}')">
      <div class="cposter" style="position:relative;opacity:.75">
        ${posterHtml}
        <div style="position:absolute;bottom:0;left:0;right:0;background:rgba(74,158,255,.9);color:#04111f;font-size:10px;font-weight:700;text-align:center;padding:4px 2px;border-radius:0 0 10px 10px">TRACKING</div>
      </div>
      <div class="cname" style="margin-top:8px">${g.title}</div>
      <span class="stub-state" style="color:var(--blue);border-color:var(--blue)">pending</span>
    </div>`;
  }

  if (g.wantedSeasons) {
    const safeId = g.imdb.replace(/[^a-z0-9]/gi,'');
    const posterHtml = g.poster
      ? `<img src="${g.poster}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:10px;opacity:0;transition:opacity .3s" onload="this.style.opacity=1" onerror="this.style.display='none'"/>`
      : '';
    const seasonList = g.wantedSeasons.slice().sort((a,b)=>a-b).map(s => `S${String(s).padStart(2,'0')}`).join(', ');
    return `<div style="cursor:pointer" onclick="openWantedSeasonCard('${safeId}')">
      <div class="cposter" style="position:relative;opacity:.75">
        ${posterHtml}
        <div style="position:absolute;bottom:0;left:0;right:0;background:rgba(74,158,255,.9);color:#04111f;font-size:10px;font-weight:700;text-align:center;padding:4px 2px;border-radius:0 0 10px 10px">${seasonList} TRACKING</div>
      </div>
      <div class="cname" style="margin-top:8px">${g.title}</div>
      <span class="stub-state" style="color:var(--blue);border-color:var(--blue)">upcoming</span>
    </div>`;
  }

  if (g.watching) {
    const safeId = g.imdb.replace(/[^a-z0-9]/gi,'');
    const posterHtml = g.poster
      ? `<img src="${g.poster}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:10px;opacity:0;transition:opacity .3s" onload="this.style.opacity=1" onerror="this.style.display='none'"/>`
      : '';
    return `<div style="cursor:pointer" onclick="openSeasonWatchCard('${safeId}')">
      <div class="cposter" style="position:relative;opacity:.85">
        ${posterHtml}
        <div style="position:absolute;bottom:0;left:0;right:0;background:rgba(61,214,140,.9);color:#04140d;font-size:10px;font-weight:700;text-align:center;padding:4px 2px;border-radius:0 0 10px 10px">WATCHING</div>
      </div>
      <div class="cname" style="margin-top:8px">${g.title}</div>
      <span class="stub-state" style="color:var(--grn);border-color:var(--grn)">watching</span>
    </div>`;
  }

  if (g.qualityUnavailable) {
    const safeId = g.imdb.replace(/[^a-z0-9]/gi,'');
    const posterHtml = g.poster
      ? `<img src="${g.poster}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:10px;opacity:0;transition:opacity .3s" onload="this.style.opacity=1" onerror="this.style.display='none'"/>`
      : '';
    const sub = g.season != null && g.episode != null
      ? `S${String(g.season).padStart(2,'0')}E${String(g.episode).padStart(2,'0')}`
      : '4K';
    return `<div style="cursor:pointer" onclick="openQualityUnavailableCard('${safeId}')">
      <div class="cposter" style="position:relative;opacity:.75">
        ${posterHtml}
        <div style="position:absolute;bottom:0;left:0;right:0;background:rgba(232,160,32,.9);color:#000;font-size:10px;font-weight:700;text-align:center;padding:4px 2px;border-radius:0 0 10px 10px">${sub} 4K UNAVAILABLE</div>
      </div>
      <div class="cname" style="margin-top:8px">${g.title}</div>
      <span class="stub-state" style="color:var(--acc2);border-color:var(--acc2)">unavailable</span>
    </div>`;
  }

  const has4k = g.stubs.some(s => s.quality === '4k');
  const hasHd = g.stubs.some(s => s.quality === 'hd');
  const state = _groupState(g);
  const sc = {active:'ss-ac',repairing:'ss-rs',unbound:'ss-ph'}[state]||'ss-ph';
  const safeId = g.imdb.replace(/[^a-z0-9]/gi,'');
  const badges = [
    hasHd ? `<span style="background:rgba(0,0,0,.88);color:var(--blue);border-radius:5px;padding:2px 7px;font-size:10px;font-weight:700;display:block">HD</span>` : '',
    has4k ? `<span style="background:rgba(0,0,0,.88);color:var(--acc2);border-radius:5px;padding:2px 7px;font-size:10px;font-weight:700;display:block">4K</span>` : ''
  ].filter(Boolean).join('');
  const posterHtml = g.poster
    ? `<img src="${g.poster}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:10px;opacity:0;transition:opacity .3s" onload="this.style.opacity=1" onerror="this.style.display='none'"/>`
    : '';
  const cardClick = g.media_type === 'series'
    ? `openSeriesDetail('${safeId}')`
    : (isAdmin() ? `openDelModal('${safeId}')` : '');
  // Missing count comes from /api/library/missing-counts, fetched once
  // when the library loads (see loadLib) — scoped server-side to
  // requested seasons only, same definition spot check uses, so a season
  // you never requested never shows up here just because Cinemeta lists it.
  const missingCount = g.media_type === 'series' ? (libMissingCounts[g.imdb] || 0) : 0;
  const missingBar = missingCount > 0
    ? `<div style="position:absolute;bottom:0;left:0;right:0;background:rgba(163,45,45,.9);color:#fff;font-size:10px;font-weight:700;text-align:center;padding:4px 2px;border-radius:0 0 10px 10px">${missingCount} EP${missingCount === 1 ? '' : 'S'} MISSING</div>`
    : '';
  return `<div style="cursor:pointer" onclick="${cardClick}">
    <div class="cposter" style="position:relative">
      ${posterHtml}
      <div style="position:absolute;top:8px;right:8px;display:flex;flex-direction:column;gap:4px;align-items:flex-end">${badges}</div>
      <button class="admin-only del-btn" style="position:absolute;top:8px;left:8px" onclick="event.stopPropagation();openDelModal('${safeId}')" title="Remove">✕</button>
      ${missingBar}
    </div>
    <div class="cname" style="margin-top:8px">${g.title}</div>
    <span class="stub-state ${sc}">${state}</span>
  </div>`;
}

// Entry states: active (real TorBox file), error (was working, being
// repaired — shown as "repairing"), unbound (restored/legacy record not
// bound to a cached torrent yet — hidden from Plex until it is).
function _uiState(state) {
  return state === 'error' ? 'repairing' : state;
}

// A title is only "unbound" when NOTHING in it is playable. One restored
// episode or a freshly-imported 4K tier waiting on the repair loop must not
// make a title whose other entries are active read as unbound.
function _groupState(g) {
  const states = g.stubs.map(s => _uiState(s.state));
  if (!states.length) return 'unbound';
  if (states.every(s => s === 'unbound')) return 'unbound';
  if (states.includes('repairing')) return 'repairing';
  return 'active';
}

// Filter chips ask "does this title have ANY entry in that state".
function _groupHasState(g, state) {
  return g.stubs.some(s => _uiState(s.state) === state);
}

function renderLib(items) {
  const el = document.getElementById('libGrid');
  el.style.display = 'block';
  const anyExtra = libPendingMovies.length || libWantedSeasons.length || libSeasonWatch.length || libQualityUnavailable.length;
  if (!items.length && !anyExtra) {
    el.innerHTML = `<div style="color:var(--mut);font-size:14px;padding:40px 0">
      No stubs yet. Browse Home or Search and click Add to Plex.
    </div>`;
    return;
  }

  let groups = groupStubs(items);
  const q = libQuery.toLowerCase();

  // Pending movies never have a stub, so groupStubs() never sees them —
  // add a synthetic group per pending movie so they show up as
  // "Tracking" cards. stubs stays empty on these; libGroupCard checks
  // for .pending to render them distinctly.
  const inLibrary = new Set(groups.map(g => g.imdb));
  for (const p of libPendingMovies) {
    if (inLibrary.has(p.imdb_id)) continue;   // already in the library — never also show it as Tracking
    if (q && !(p.title || '').toLowerCase().includes(q)) continue;
    groups.push({
      title: p.title, imdb: p.imdb_id, poster: p.poster || '',
      media_type: 'movie', year: p.year || null,
      stubs: [], pending: true, added_at: p.added_at,
    });
  }

  // Wanted seasons — grouped by show, since a show could have more than
  // one wanted season number at once (rare, but possible).
  const wantedByShow = {};
  for (const w of libWantedSeasons) {
    if (q && !(w.title || '').toLowerCase().includes(q)) continue;
    if (!wantedByShow[w.imdb_id]) {
      wantedByShow[w.imdb_id] = {
        title: w.title, imdb: w.imdb_id, poster: w.poster || '',
        media_type: 'series', year: w.year || null,
        stubs: [], wantedSeasons: [], added_at: w.added_at,
      };
    }
    wantedByShow[w.imdb_id].wantedSeasons.push(w.season);
  }
  groups.push(...Object.values(wantedByShow));

  // Season-watch — shows with indefinite tracking enabled.
  for (const w of libSeasonWatch) {
    if (q && !(w.title || '').toLowerCase().includes(q)) continue;
    groups.push({
      title: w.title, imdb: w.imdb_id, poster: w.poster || '',
      media_type: 'series', year: w.year || null,
      stubs: [], watching: true, added_at: w.enabled_at,
    });
  }

  // 4K-unavailable — one entry per movie or specific episode.
  for (const u of libQualityUnavailable) {
    if (q && !(u.title || '').toLowerCase().includes(q)) continue;
    groups.push({
      title: u.title, imdb: u.key, poster: u.poster || '',
      media_type: u.season != null ? 'series' : 'movie', year: null,
      stubs: [], qualityUnavailable: true,
      season: u.season, episode: u.episode, marked_at: u.marked_at,
      _realImdbId: u.imdb_id,
    });
  }

  if (libStateFilter === 'upcoming') {
    // Tracked, but not actually in Plex yet, for any reason: a pending
    // movie, a wanted (not-yet-aired) season, or a show under indefinite
    // season-watch.
    groups = groups.filter(g => g.pending || g.wantedSeasons || g.watching);
  } else if (libStateFilter === 'unavailable') {
    groups = groups.filter(g => g.qualityUnavailable);
  } else if (libStateFilter === 'missing') {
    // Purely about existing series with missing episodes now — pending
    // movies, wanted seasons, and season-watch all have their own home
    // under "Upcoming" instead of overlapping here too.
    groups = groups.filter(g => g.media_type === 'series' && (libMissingCounts[g.imdb] || 0) > 0);
  } else if (libStateFilter !== 'all') {
    // Synthetic categories (pending/tracking/unavailable) are never Active/Repairing.
    groups = groups.filter(g =>
      !g.pending && !g.wantedSeasons && !g.watching && !g.qualityUnavailable &&
      _groupHasState(g, libStateFilter)
    );
  }

  if (!groups.length) {
    el.innerHTML = `<div style="color:var(--mut);font-size:14px;padding:40px 0">
      Nothing matches this filter.
    </div>`;
    return;
  }

  groups.sort((a, b) => (a.title || '').localeCompare(b.title || ''));

  window._libGroups = {};
  groups.forEach(g => { window._libGroups[g.imdb.replace(/[^a-z0-9]/gi,'')] = g; });

  const movies = groups.filter(g => g.media_type !== 'series');
  const series = groups.filter(g => g.media_type === 'series');

  const html =
    renderLibSection('movie',  'Movies',   movies) +
    renderLibSection('series', 'TV Shows', series);

  el.innerHTML = html;
}

// Each section (Movies / TV Shows) paginates independently, with its own
// "View all" toggle to drop pagination and show every title in that
// section at once.
function renderLibSection(kind, label, groupsForSection) {
  if (!groupsForSection.length) return '';

  const viewAll = kind === 'movie' ? libMovieViewAll : libSeriesViewAll;
  const totalPages = Math.max(1, Math.ceil(groupsForSection.length / LIB_PAGE_SIZE));

  if (kind === 'movie') { if (libMoviePage > totalPages) libMoviePage = totalPages; }
  else { if (libSeriesPage > totalPages) libSeriesPage = totalPages; }
  const page = kind === 'movie' ? libMoviePage : libSeriesPage;

  const pageItems = viewAll
    ? groupsForSection
    : groupsForSection.slice((page - 1) * LIB_PAGE_SIZE, page * LIB_PAGE_SIZE);

  const showPagination = !viewAll && totalPages > 1;
  const viewAllLabel = viewAll ? 'Show paginated' : 'View all';

  return `<div style="margin-bottom:36px">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;gap:12px;flex-wrap:wrap">
      <div class="sec-title">${label} <span style="color:var(--mut);font-weight:400;font-size:13px">(${groupsForSection.length})</span></div>
      <button class="btn bg2" style="padding:5px 14px;font-size:12px" onclick="libToggleViewAll('${kind}')">${viewAllLabel}</button>
    </div>
    <div class="libgrid">${pageItems.map(libGroupCard).join('')}</div>
    ${showPagination ? renderLibPaginationHtml(kind, page, totalPages, groupsForSection.length) : ''}
  </div>`;
}

function renderLibPaginationHtml(kind, page, totalPages, totalCount) {
  const pageBtn = (label, p, disabled) =>
    `<button class="cal-navbtn" style="width:auto;min-width:32px;padding:0 10px" ${disabled ? 'disabled' : ''} onclick="libGoToPage('${kind}', ${p})">${label}</button>`;
  const numBtn = (p) =>
    `<button class="cal-navbtn" style="width:32px;padding:0;${p === page ? 'background:var(--acc);color:#000;border-color:var(--acc)' : ''}" onclick="libGoToPage('${kind}', ${p})">${p}</button>`;

  // Windowed page numbers: first, last, current ±1, "…" for gaps.
  const pages = [];
  for (let p = 1; p <= totalPages; p++) {
    if (p === 1 || p === totalPages || Math.abs(p - page) <= 1) {
      pages.push(p);
    } else if (pages[pages.length - 1] !== '…') {
      pages.push('…');
    }
  }

  let html = `<div style="display:flex;align-items:center;justify-content:center;gap:8px;margin-top:20px;flex-wrap:wrap">`;
  html += pageBtn('‹ Prev', page - 1, page === 1);
  html += pages.map(p => p === '…'
    ? `<span style="color:var(--mut);font-size:13px;padding:0 4px">…</span>`
    : numBtn(p)
  ).join('');
  html += pageBtn('Next ›', page + 1, page === totalPages);
  html += `<span style="color:var(--mut);font-size:12px;margin-left:10px">${totalCount} title${totalCount === 1 ? '' : 's'}</span>`;
  html += `</div>`;
  return html;
}


// ── Series detail modal ────────────────────────────────────────
const _bg_scans_ui = new Set();

async function openSeriesDetail(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;

  // Show loading immediately
  const dlg = document.createElement('div');
  dlg.id = 'seriesDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.82);backdrop-filter:blur(16px);z-index:300;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `<div style="color:var(--mut);font-size:14px">Loading…</div>`;
  dlg.addEventListener('click', e => { if (e.target===dlg) dlg.remove(); });
  document.body.appendChild(dlg);

  let epData;
  try {
    const r = await fetch(`/api/series/${g.imdb}/episodes`);
    epData = await r.json();
  } catch(e) {
    dlg.querySelector('div').innerHTML = '<span style="color:var(--red)">Failed to load</span>';
    return;
  }

  const episodes   = epData.episodes || [];
  const isScanning = _bg_scans_ui.has(g.imdb) || epData.scanning;

  // Group ALL episodes by season — including seasons with zero stubs
  // ("not yet requested") and unaired ones, not just aired+stubbed ones.
  const seasonMap = {};
  episodes.forEach(ep => {
    seasonMap[ep.season] = seasonMap[ep.season] || [];
    seasonMap[ep.season].push(ep);
  });
  const seasons = Object.keys(seasonMap).map(Number).sort((a,b)=>a-b);

  // A season is "requested" if at least one of its episodes has a stub
  // (HD or 4K) — distinct from "fully downloaded", since a requested
  // season can still have missing episodes.
  const seasonRequested = {};
  seasons.forEach(sn => {
    seasonRequested[sn] = seasonMap[sn].some(e => e.has_hd || e.has_4k);
  });
  const unrequestedSeasons = seasons.filter(sn => !seasonRequested[sn]);

  const totalAired   = episodes.filter(e=>e.aired).length;
  const totalStubbed = episodes.filter(e=>e.aired && e.has_hd).length;
  const totalMissing = totalAired - totalStubbed;

  // Keep the library card's "N eps missing" banner in sync immediately
  // (rather than waiting for the next full loadLib() cycle) — scoped to
  // requested seasons only, matching /api/library/missing-counts exactly.
  const requestedMissing = episodes.filter(e => e.aired && seasonRequested[e.season] && !e.has_hd).length;
  libMissingCounts[g.imdb] = requestedMissing;

  const escTitle = g.title.replace(/\\/g,'\\\\').replace(/'/g,"\\'");
  const escPoster = (g.poster||'').replace(/'/g,"\\'");

  const seasonRows = seasons.map(sn => {
    const eps = seasonMap[sn].sort((a,b)=>a.episode-b.episode);
    const requested = seasonRequested[sn];
    const airedEps = eps.filter(e=>e.aired);
    const missing = airedEps.filter(e=>!e.has_hd).length;

    // Unrequested season: show a single "Request season" row instead of
    // per-episode chips (there's nothing to show per-episode yet).
    if (!requested) {
      const airedCount = airedEps.length;
      const futureCount = eps.length - airedCount;
      const countLabel = airedCount > 0
        ? `${airedCount} ep${airedCount!==1?'s':''}${futureCount>0?` &middot; ${futureCount} upcoming`:''}`
        : `${futureCount} upcoming ep${futureCount!==1?'s':''}`;
      return `<div style="margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;gap:10px;background:var(--card2);border:1px solid var(--bor);border-radius:10px;padding:12px 14px">
        <div>
          <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:3px">
            Season ${sn} <span style="color:var(--txt);font-weight:600">${countLabel}</span>
          </div>
          <div style="font-size:11px;color:var(--mut)">Not requested yet</div>
        </div>
        <button id="reqSeasonBtn_${sn}" class="mbtn mbtn-add" style="padding:8px 16px;font-size:12px;flex-shrink:0;width:auto"
          onclick="requestSeason('${safeId}','${g.imdb}','${escTitle}','${escPoster}',${sn},'${g.year||''}')"
          ${airedCount===0 ? 'disabled title="No aired episodes yet"' : ''}>
          ${airedCount===0 ? 'Not aired' : 'Request season'}
        </button>
      </div>`;
    }

    const chips = airedEps.map(ep => {
      const eStr = String(ep.episode).padStart(2,'0');
      if (ep.has_hd) {
        const col = ep.has_4k ? 'var(--acc2)' : 'var(--blue)';
        const lbl = ep.has_4k ? 'HD+4K' : 'HD';
        const label = `${escTitle} S${String(sn).padStart(2,'0')}E${eStr}`;
        // Both qualities exist — ask which one before opening the picker,
        // rather than guessing. Only HD exists — nothing to choose
        // between, so go straight to it.
        const clickAttr = !isAdmin() ? '' : ep.has_4k
          ? `onclick="event.stopPropagation();openStreamQualityChoiceModal('${ep.hd_stub_id}','${ep.uhd_stub_id}','${label}')"`
          : (ep.hd_stub_id ? `onclick="event.stopPropagation();openActiveStreamModal('${ep.hd_stub_id}','${label}')"` : '');
        return `<span ${clickAttr}
          title="${clickAttr ? 'Click to view/change the active stream' : ''}"
          style="background:var(--card2);border:1px solid var(--bor);border-radius:5px;padding:3px 7px;font-size:10px;font-weight:700;color:${col};white-space:nowrap${clickAttr ? ';cursor:pointer' : ''}">E${eStr} <span style="color:var(--mut);font-weight:400">${lbl}</span></span>`;
      } else {
        const sid   = `ep_${sn}_${ep.episode}`;
        return `<span id="${sid}"
          onclick="openEpisodeSearchModal('${safeId}','${g.imdb}','${escTitle}',${sn},${ep.episode},'${escPoster}','${g.year||''}')"
          title="Click to search for S${String(sn).padStart(2,'0')}E${eStr}"
          style="background:transparent;border:1px dashed rgba(255,255,255,.18);border-radius:5px;padding:3px 7px;font-size:10px;font-weight:700;color:rgba(255,255,255,.35);cursor:pointer;white-space:nowrap;transition:all 140ms"
          onmouseover="this.style.borderColor='var(--acc)';this.style.color='var(--txt)'"
          onmouseout="this.style.borderColor='rgba(255,255,255,.18)';this.style.color='rgba(255,255,255,.35)'">E${eStr} <span style="font-weight:400">missing</span></span>`;
      }
    }).join('');

    const mbadge = missing > 0
      ? `<span style="color:var(--red);font-size:10px;font-weight:600;margin-left:6px">${missing} missing</span>` : '';
    const reqBadge = `<span style="color:var(--grn);font-size:10px;font-weight:600;margin-left:6px">requested</span>`;

    return `<div style="margin-bottom:16px">
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:8px;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
        <span>Season ${sn} <span style="color:var(--txt);font-weight:600">${airedEps.length} ep${airedEps.length!==1?'s':''}</span>${reqBadge}${mbadge}</span>
        <span style="display:flex;align-items:center;gap:4px;flex-shrink:0">
          <span class="admin-only" id="scanHdSeason_${sn}" onclick="scanSeasonQuality('${g.imdb}',${sn},'hd',this)"
            style="text-transform:none;letter-spacing:0;font-weight:600;color:var(--blue);cursor:pointer;font-size:11px;padding:2px 7px;border-radius:5px;border:1px solid rgba(74,158,255,.3);transition:all 140ms">
            Scan HD
          </span>
          <span class="admin-only" id="scanUhdSeason_${sn}" onclick="scanSeasonQuality('${g.imdb}',${sn},'4k',this)"
            style="text-transform:none;letter-spacing:0;font-weight:600;color:var(--acc2);cursor:pointer;font-size:11px;padding:2px 7px;border-radius:5px;border:1px solid rgba(232,160,32,.3);transition:all 140ms">
            Scan 4K
          </span>
          <span class="admin-only" id="scanBothSeason_${sn}" onclick="scanSeasonBoth('${g.imdb}',${sn},this)"
            style="text-transform:none;letter-spacing:0;font-weight:600;color:var(--txt);cursor:pointer;font-size:11px;padding:2px 7px;border-radius:5px;border:1px solid var(--bor2);transition:all 140ms">
            Scan HD+4K
          </span>
          <span class="admin-only" id="rmSeason_${sn}" onclick="removeSeasonClick('${safeId}','${g.imdb}','${escTitle}',${sn},this)"
            style="text-transform:none;letter-spacing:0;font-weight:600;color:var(--mut);cursor:pointer;font-size:11px;flex-shrink:0;padding:2px 6px;border-radius:5px;transition:all 140ms"
            onmouseover="if(!this.dataset.armed){this.style.color='var(--red)'}" onmouseout="if(!this.dataset.armed){this.style.color='var(--mut)'}">
            Remove
          </span>
        </span>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:5px">${chips}</div>
    </div>`;
  }).join('');

  const posterEl = g.poster
    ? `<img src="${g.poster}" style="width:52px;height:78px;object-fit:cover;border-radius:7px;flex-shrink:0"/>`
    : '';
  const scanBadge = isScanning
    ? `<div style="font-size:11px;color:var(--blue);margin-top:4px;display:flex;align-items:center;gap:5px"><span style="width:6px;height:6px;border-radius:50%;background:var(--blue);display:inline-block;animation:sblink 1s infinite"></span> Scanning…</div>` : '';
  const missingNote = totalMissing > 0 && !isScanning
    ? `<div style="font-size:11px;color:var(--red);margin-top:3px">${totalMissing} ep${totalMissing!==1?'s':''} missing</div>` : '';

  // Only seasons with at least one aired episode can actually be
  // requested right now — an unaired season would just 404.
  const requestableSeasons = unrequestedSeasons.filter(
    sn => seasonMap[sn].some(e => e.aired)
  );
  const requestAllBtn = requestableSeasons.length > 0
    ? `<button id="reqAllBtn" onclick='requestAllSeasons("${safeId}","${g.imdb}","${escTitle}","${escPoster}","${g.year||''}",${JSON.stringify(requestableSeasons)})'
        style="background:none;border:1px solid var(--acc);color:var(--acc);border-radius:6px;padding:3px 10px;font-size:11px;font-weight:700;cursor:pointer;margin-left:8px;white-space:nowrap">
        Request all (${requestableSeasons.length})
      </button>`
    : '';

  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:18px;width:100%;max-width:520px;max-height:82vh;display:flex;flex-direction:column;overflow:hidden">
      <div style="padding:20px 22px 16px;border-bottom:1px solid var(--bor);display:flex;align-items:flex-start;gap:14px;flex-shrink:0">
        ${posterEl}
        <div style="flex:1;min-width:0">
          <div style="font-size:17px;font-weight:800;letter-spacing:-.3px;margin-bottom:3px">${g.title}</div>
          <div style="font-size:12px;color:var(--mut);display:flex;align-items:center;flex-wrap:wrap;row-gap:6px">
            <span>${seasons.length} season${seasons.length!==1?'s':''} &middot; ${totalStubbed}/${totalAired} episodes</span>${requestAllBtn}
          </div>
          ${scanBadge}${missingNote}
        </div>
        <button onclick="document.getElementById('seriesDlg').remove()" style="background:var(--card2);border:1px solid var(--bor);border-radius:8px;color:var(--mut);width:30px;height:30px;cursor:pointer;font-size:14px;flex-shrink:0">✕</button>
      </div>
      <div style="padding:18px 22px;overflow-y:auto;flex:1">
        ${seasons.length ? seasonRows : '<div style="color:var(--mut);font-size:13px">No episodes found yet.</div>'}
      </div>
      <div style="padding:14px 22px;border-top:1px solid var(--bor);display:flex;gap:10px;flex-shrink:0">
        <button id="rescanBtn" class="mbtn mbtn-add"
          onclick="rescanSeries('${safeId}','${g.imdb}','${escTitle}','${escPoster}','${g.year||''}')"
          style="${isScanning?'opacity:.5;pointer-events:none':''}">
          ${isScanning ? 'Scanning…' : 'Rescan all'}
        </button>
        <button class="admin-only mbtn mbtn-add" onclick="document.getElementById('seriesDlg').remove();openDelModal('${safeId}')" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)">Remove</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('seriesDlg').remove()">Close</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target===dlg) dlg.remove(); });
}

async function scanSeasonQuality(imdbId, season, quality, el) {
  const original = el.textContent;
  el.textContent = 'Scanning…';
  el.style.pointerEvents = 'none';
  el.style.opacity = '.6';
  try {
    const r = await fetch(`/api/series/${imdbId}/season/${season}/scan/${quality}`, { method: 'POST' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || 'Scan failed');
    toast(`Season ${season} ${quality.toUpperCase()} scan: found ${d.found}/${d.checked} checked (${d.already_had} already had it)`, 'ok');
    await loadLib();
    const safeId = imdbId.replace(/[^a-z0-9]/gi, '');
    document.getElementById('seriesDlg')?.remove();
    openSeriesDetail(safeId);
  } catch (exc) {
    toast(exc.message || 'Scan failed', 'er');
    el.textContent = original;
    el.style.pointerEvents = 'auto';
    el.style.opacity = '1';
  }
}

async function scanSeasonBoth(imdbId, season, el) {
  const original = el.textContent;
  el.style.pointerEvents = 'none';
  el.style.opacity = '.6';
  const results = [];
  for (const quality of ['hd', '4k']) {
    el.textContent = `Scanning ${quality.toUpperCase()}…`;
    try {
      const r = await fetch(`/api/series/${imdbId}/season/${season}/scan/${quality}`, { method: 'POST' });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.detail || 'Scan failed');
      results.push(`${quality.toUpperCase()}: found ${d.found}/${d.checked}`);
    } catch (exc) {
      results.push(`${quality.toUpperCase()}: ${exc.message || 'failed'}`);
    }
  }
  toast(`Season ${season} — ${results.join(' · ')}`, 'ok');
  el.textContent = original;
  el.style.pointerEvents = 'auto';
  el.style.opacity = '1';
  await loadLib();
  const safeId = imdbId.replace(/[^a-z0-9]/gi, '');
  document.getElementById('seriesDlg')?.remove();
  openSeriesDetail(safeId);
}

function removeSeasonClick(safeId, imdbId, title, season, el) {
  if (!el.dataset.armed) {
    // First click: arm it — turns red and waits a few seconds for a
    // second click, rather than popping a whole separate confirm modal
    // for what's a fairly contained, single-season action.
    el.dataset.armed = '1';
    el.textContent = 'Confirm?';
    el.style.color = 'var(--red)';
    el.style.background = 'rgba(255,85,85,.12)';
    el._disarmTimer = setTimeout(() => {
      if (el.dataset.armed) {
        delete el.dataset.armed;
        el.textContent = 'Remove';
        el.style.color = 'var(--mut)';
        el.style.background = 'none';
      }
    }, 4000);
    return;
  }
  clearTimeout(el._disarmTimer);
  removeSeasonNow(safeId, imdbId, title, season, el);
}

async function removeSeasonNow(safeId, imdbId, title, season, el) {
  el.textContent = 'Removing…';
  el.style.pointerEvents = 'none';
  try {
    const r = await fetch(`/api/series/${imdbId}/season/${season}`, { method: 'DELETE' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || 'Could not remove season');
    toast(`Removed Season ${season} of "${title}" (${d.removed} stub${d.removed !== 1 ? 's' : ''})`, 'ok');
    document.getElementById('seriesDlg')?.remove();
    await loadLib();
    openSeriesDetail(safeId);
  } catch (exc) {
    toast(exc.message || 'Could not remove season', 'er');
    el.textContent = 'Remove';
    el.style.pointerEvents = 'auto';
    delete el.dataset.armed;
  }
}

async function requestSeason(safeId, imdbId, title, poster, season, year) {
  const btn = document.getElementById(`reqSeasonBtn_${season}`);
  if (btn) { btn.textContent = 'Requesting…'; btn.disabled = true; }
  _bg_scans_ui.add(imdbId);
  toast(`Requesting Season ${season} of "${title}"`, 'in');
  try {
    const r = await fetch('/api/add', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ imdb_id:imdbId, title, media_type:'series', poster, season, year: year ? parseInt(year) : null }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail||'Error');
    document.getElementById('seriesDlg')?.remove();
    pollScan(imdbId, title);
  } catch(e) {
    _bg_scans_ui.delete(imdbId);
    if (btn) { btn.textContent = 'Request season'; btn.disabled = false; }
    toast(e.message, 'er');
  }
}

async function requestAllSeasons(safeId, imdbId, title, poster, year, unrequestedSeasons) {
  const btn = document.getElementById('reqAllBtn');
  if (btn) { btn.textContent = 'Requesting…'; btn.style.pointerEvents = 'none'; btn.style.opacity = '.6'; }
  _bg_scans_ui.add(imdbId);
  toast(`Requesting ${unrequestedSeasons.length} season${unrequestedSeasons.length!==1?'s':''} of "${title}"`, 'in');
  try {
    // One targeted request per unrequested season (not a blanket whole-
    // series rescan) — avoids re-querying TorBox for episodes that
    // are already stubbed, which create_stubs() would just no-op on
    // anyway but wastes API calls/rate-limit budget at series-add scale.
    for (const sn of unrequestedSeasons) {
      const r = await fetch('/api/add', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ imdb_id:imdbId, title, media_type:'series', poster, season: sn, year: year ? parseInt(year) : null }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.detail||'Error');
    }
    document.getElementById('seriesDlg')?.remove();
    pollScan(imdbId, title);
  } catch(e) {
    _bg_scans_ui.delete(imdbId);
    if (btn) { btn.textContent = `Request all`; btn.style.pointerEvents = 'auto'; btn.style.opacity = '1'; }
    toast(e.message, 'er');
  }
}

function openEpisodeSearchModal(safeId, imdbId, title, season, episode, poster, year) {
  const eStr = String(episode).padStart(2,'0');
  const sStr = String(season).padStart(2,'0');

  const dlg = document.createElement('div');
  dlg.id = 'episodeSearchDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:310;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px;max-width:360px;width:100%">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${title}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:22px">S${sStr}E${eStr} — search for it</div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <button class="admin-only mbtn mbtn-add" style="background:#1a2e40;color:var(--blue);border:1px solid rgba(74,158,255,.3)"
          onclick="runEpisodeSearch('${safeId}','${imdbId}','${title.replace(/'/g,"\\'")}',${season},${episode},'${poster}','${year}','hd',this)">Search HD</button>
        <button class="admin-only mbtn mbtn-add" style="background:#2e1e00;color:var(--acc2);border:1px solid rgba(232,160,32,.3)"
          onclick="runEpisodeSearch('${safeId}','${imdbId}','${title.replace(/'/g,"\\'")}',${season},${episode},'${poster}','${year}','4k',this)">Search 4K</button>
        <button class="mbtn mbtn-add" style="background:var(--card2);color:var(--txt);border:1px solid var(--bor2)"
          onclick="runEpisodeSearch('${safeId}','${imdbId}','${title.replace(/'/g,"\\'")}',${season},${episode},'${poster}','${year}','both',this)">Search HD+4K</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('episodeSearchDlg').remove()" style="margin-top:4px">Cancel</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

async function runEpisodeSearch(safeId, imdbId, title, season, episode, poster, year, quality, btn) {
  const chipId = `ep_${season}_${episode}`;
  const chip   = document.getElementById(chipId);
  const eStr   = String(episode).padStart(2,'0');
  const sStr   = String(season).padStart(2,'0');

  if (btn) { btn.textContent = 'Searching…'; btn.disabled = true; }
  if (chip) {
    chip.textContent = `E${eStr} searching…`;
    chip.style.color = 'var(--blue)';
    chip.style.borderColor = 'var(--blue)';
    chip.style.borderStyle = 'solid';
    chip.style.pointerEvents = 'none';
    chip.onmouseover = chip.onmouseout = null;
  }

  try {
    let r, d;
    if (quality === 'both') {
      r = await fetch(`/api/series/${imdbId}/episode/${season}/${episode}`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({imdb_id:imdbId, title, media_type:'series', poster, year:year?parseInt(year):null}),
      });
      d = await r.json();
      if (!r.ok) throw new Error(d.detail||'No streams found');
    } else {
      r = await fetch(`/api/series/${imdbId}/episode/${season}/${episode}/scan/${quality}`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({title, poster, year:year?parseInt(year):null}),
      });
      d = await r.json();
      if (!r.ok) throw new Error(d.detail||`No ${quality.toUpperCase()} stream found`);
      d.has_4k = quality === '4k';   // for the chip label below, matching the generic endpoint's shape
    }

    if (chip) {
      const lbl = (quality === 'both' && d.has_4k) ? 'HD+4K' : (quality === '4k' ? '4K' : 'HD');
      const col = (lbl === '4K' || lbl === 'HD+4K') ? 'var(--acc2)' : 'var(--blue)';
      chip.style.background = 'var(--card2)';
      chip.style.borderColor = 'var(--bor)';
      chip.style.color = col;
      chip.innerHTML = `E${eStr} <span style="color:var(--mut);font-weight:400">${lbl}</span>`;
      chip.style.cursor = 'default';
      chip.onclick = null;
    }
    toast(`Found S${sStr}E${eStr} (${quality === 'both' ? (d.has_4k?'HD+4K':'HD') : quality.toUpperCase()})`, 'ok');
    document.getElementById('episodeSearchDlg')?.remove();
    await syncStubs();
  } catch(e) {
    if (btn) { btn.textContent = btn.textContent.replace('Searching…', 'Retry'); btn.disabled = false; }
    if (chip && quality === 'both') {
      // Only reset the chip to "not found" for the combined search — a
      // single HD or 4K miss shouldn't relabel the whole episode as
      // failed if the other quality might still be tried from the modal.
      chip.textContent = `E${eStr} not found`;
      chip.style.color = 'var(--red)';
      chip.style.borderColor = 'var(--red)';
      chip.style.pointerEvents = 'auto';
    } else if (chip) {
      chip.textContent = `E${eStr} missing`;
      chip.style.color = 'rgba(255,255,255,.35)';
      chip.style.borderColor = 'rgba(255,255,255,.18)';
      chip.style.borderStyle = 'dashed';
      chip.style.pointerEvents = 'auto';
      chip.onclick = () => openEpisodeSearchModal(safeId, imdbId, title, season, episode, poster, year);
    }
    toast(`S${sStr}E${eStr}: ${e.message}`, 'er');
  }
}


async function rescanSeries(safeId, imdbId, title, poster, year) {
  const btn = document.getElementById('rescanBtn');
  if (btn) { btn.textContent='Scanning…'; btn.style.opacity='.5'; btn.style.pointerEvents='none'; }
  _bg_scans_ui.add(imdbId);
  document.getElementById('seriesDlg')?.remove();
  toast(`Rescanning "${title}"`, 'in');
  try {
    const r = await fetch('/api/add', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ imdb_id:imdbId, title, media_type:'series', poster, year: year ? parseInt(year) : null }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail||'Error');
    pollScan(imdbId, title);
  } catch(e) {
    _bg_scans_ui.delete(imdbId);
    toast(e.message, 'er');
  }
}

// ── Delete options modal ────────────────────────────────────────
function openDelModal(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;
  const hdStub  = g.stubs.find(s => s.quality === 'hd');
  const k4Stub  = g.stubs.find(s => s.quality === '4k');
  const hasHd = !!hdStub;
  const has4k = !!k4Stub;
  const both  = hasHd && has4k;
  const isMovie = g.media_type !== 'series';

  const dlg = document.createElement('div');
  dlg.id = 'delDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:300;display:flex;align-items:center;justify-content:center';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px 28px 24px;max-width:360px;width:90%">
      <div style="font-size:17px;font-weight:800;margin-bottom:6px">${g.title}</div>
      ${isMovie ? `
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin:18px 0 10px">Scan</div>
      <div style="display:flex;gap:8px;margin-bottom:18px">
        <button id="movieScanHd" class="admin-only mbtn mbtn-add" style="background:#1a2e40;color:var(--blue);border:1px solid rgba(74,158,255,.3);width:auto;flex:1"
          onclick="scanMovieQuality('${g.imdb}','hd',this)">${hasHd ? 'Rescan HD' : 'Scan HD'}</button>
        <button id="movieScanUhd" class="admin-only mbtn mbtn-add" style="background:#2e1e00;color:var(--acc2);border:1px solid rgba(232,160,32,.3);width:auto;flex:1"
          onclick="scanMovieQuality('${g.imdb}','4k',this)">${has4k ? 'Rescan 4K' : 'Scan 4K'}</button>
      </div>
      <div style="margin-bottom:18px">
        <button id="movieScanBoth" class="admin-only mbtn mbtn-add" style="background:var(--card2);color:var(--txt);border:1px solid var(--bor2);width:100%"
          onclick="scanMovieBoth('${g.imdb}',this)">Scan HD+4K</button>
      </div>
      ${(hasHd || has4k) ? `
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:10px">Active stream</div>
      <div style="display:flex;gap:8px;margin-bottom:18px">
        ${hasHd ? `<button class="admin-only mbtn mbtn-add" style="background:var(--card2);color:var(--blue);border:1px solid rgba(74,158,255,.3);width:auto;flex:1" onclick="openActiveStreamModal('${hdStub.stub_id}','${g.title} (HD)')">View/change HD</button>` : ''}
        ${has4k ? `<button class="admin-only mbtn mbtn-add" style="background:var(--card2);color:var(--acc2);border:1px solid rgba(232,160,32,.3);width:auto;flex:1" onclick="openActiveStreamModal('${k4Stub.stub_id}','${g.title} (4K)')">View/change 4K</button>` : ''}
      </div>
      ` : ''}
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:10px">Remove</div>
      ` : `<div style="font-size:13px;color:var(--mut);margin-bottom:22px">Remove from Plex</div>`}
      <div style="display:flex;flex-direction:column;gap:10px">
        ${hasHd ? `<button class="admin-only mbtn mbtn-add" style="background:#1a2e40;color:var(--blue);border:1px solid rgba(74,158,255,.3)" onclick="delQuality('${safeId}','hd')">Delete HD stub</button>` : ''}
        ${has4k ? `<button class="admin-only mbtn mbtn-add" style="background:#2e1e00;color:var(--acc2);border:1px solid rgba(232,160,32,.3)" onclick="delQuality('${safeId}','4k')">Delete 4K stub</button>` : ''}
        ${both  ? `<button class="admin-only mbtn mbtn-add" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)" onclick="delQuality('${safeId}','both')">Delete both (HD + 4K)</button>` : ''}
        <button class="mbtn mbtn-close" onclick="document.getElementById('delDlg').remove()" style="margin-top:4px">Cancel</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

function openPendingMovieModal(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g || !g.pending) return;

  const dlg = document.createElement('div');
  dlg.id = 'pendingMovieDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:300;display:flex;align-items:center;justify-content:center';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px 28px 24px;max-width:360px;width:90%">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${g.title}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:22px">
        ${g.year ? g.year + ' · ' : ''}Nothing cached on TorBox yet — usually because it isn't
        released. It's checked automatically; "Search now" searches immediately, even
        before release.
      </div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <button id="pendingMovieSearchBtn" class="mbtn mbtn-add" style="background:var(--acc);color:#000"
          onclick="searchPendingMovieNow('${g.imdb}','${safeId}',this)">Search now</button>
        <button class="mbtn mbtn-close"
          onclick="openReleasesModal('${g.imdb}', ${JSON.stringify(g.title || '').replace(/"/g, '&quot;')}, '${g.poster || ''}', ${parseInt(g.year) || 'null'})">Show releases</button>
        <button class="admin-only mbtn mbtn-add" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)"
          onclick="removePendingMovieFromLib('${g.imdb}')">Remove from tracking</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('pendingMovieDlg').remove()" style="margin-top:4px">Close</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

function openWantedSeasonCard(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g || !g.wantedSeasons) return;
  const seasonList = g.wantedSeasons.slice().sort((a,b)=>a-b).map(s => `S${String(s).padStart(2,'0')}`).join(', ');

  const dlg = document.createElement('div');
  dlg.id = 'wantedSeasonDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:300;display:flex;align-items:center;justify-content:center';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px 28px 24px;max-width:360px;width:90%">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${g.title}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:22px">
        ${seasonList} ${g.wantedSeasons.length > 1 ? "haven't" : "hasn't"} aired yet — tracked so the
        auto-episode sweep adds it automatically the moment it does. No action needed unless
        you'd rather stop tracking it.
      </div>
      <div style="display:flex;flex-direction:column;gap:10px">
        ${g.wantedSeasons.slice().sort((a,b)=>a-b).map(s => `
        <button class="admin-only mbtn mbtn-add" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)"
          onclick="removeWantedSeason('${g.imdb}',${s},this)">Stop tracking S${String(s).padStart(2,'0')}</button>
        `).join('')}
        <button class="mbtn mbtn-close" onclick="document.getElementById('wantedSeasonDlg').remove()" style="margin-top:4px">Close</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

function openSeasonWatchCard(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g || !g.watching) return;

  const dlg = document.createElement('div');
  dlg.id = 'seasonWatchDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:300;display:flex;align-items:center;justify-content:center';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px 28px 24px;max-width:360px;width:90%">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${g.title}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:22px">
        Indefinite season-watch is on — whatever the next season turns out to be gets
        tracked and added automatically once it airs, including any season after that
        too, for as long as this stays enabled.
      </div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <button class="admin-only mbtn mbtn-add" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)"
          onclick="removeSeasonWatch('${g.imdb}',this)">Stop watching</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('seasonWatchDlg').remove()" style="margin-top:4px">Close</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

function openQualityUnavailableCard(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g || !g.qualityUnavailable) return;
  const sub = g.season != null && g.episode != null
    ? `S${String(g.season).padStart(2,'0')}E${String(g.episode).padStart(2,'0')}`
    : 'This movie';

  const dlg = document.createElement('div');
  dlg.id = 'qualityUnavailDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:300;display:flex;align-items:center;justify-content:center';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px 28px 24px;max-width:360px;width:90%">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${g.title}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:22px">
        ${sub} — spot check confirmed 4K genuinely isn't available. Every automatic
        path skips 4K here from now on. Removing the mark lets the next automatic
        pass try again, or use "Scan 4K" directly from this item's card for an
        immediate manual check.
      </div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <button class="admin-only mbtn mbtn-add" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)"
          onclick="removeQualityUnavailable('${g.imdb}',this)">Remove mark</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('qualityUnavailDlg').remove()" style="margin-top:4px">Close</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}


async function searchPendingMovieNow(imdbId, safeId, btn) {
  const g = window._libGroups && window._libGroups[safeId];
  btn.disabled = true; btn.textContent = 'Searching…';
  try {
    const r = await fetch('/api/add', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        imdb_id: imdbId, title: g ? g.title : imdbId, media_type: 'movie',
        poster: g ? g.poster : '', year: g && g.year ? parseInt(g.year) : null, force_search: true,
      }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Search failed');
    if (d.pending) {
      toast(_pendingMessage(g ? g.title : imdbId, d), 'in');
    } else {
      toast(`Found and added "${g ? g.title : imdbId}"`, 'ok');
    }
    document.getElementById('pendingMovieDlg')?.remove();
    loadLib();
  } catch (exc) {
    toast(exc.message || 'Search failed', 'er');
    btn.textContent = 'Search now';
    btn.disabled = false;
  }
}

async function removePendingMovieFromLib(imdbId) {
  try {
    await fetch(`/api/pending-movies/${imdbId}`, { method: 'DELETE' });
    toast('Removed from tracking', 'ok');
    document.getElementById('pendingMovieDlg')?.remove();
    loadLib();
  } catch {
    toast('Could not remove', 'er');
  }
}

async function scanMovieQuality(imdbId, quality, el) {
  const original = el.textContent;
  el.textContent = 'Scanning…';
  el.disabled = true;
  el.style.opacity = '.6';
  try {
    const r = await fetch(`/api/movies/${imdbId}/scan/${quality}`, { method: 'POST' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || `No ${quality.toUpperCase()} stream found`);
    toast(`Found and stubbed ${quality.toUpperCase()}`, 'ok');
    document.getElementById('delDlg')?.remove();
    await loadLib();
  } catch (exc) {
    toast(exc.message || 'Scan failed', 'er');
    el.textContent = original;
    el.disabled = false;
    el.style.opacity = '1';
  }
}

async function scanMovieBoth(imdbId, el) {
  const original = el.textContent;
  el.disabled = true;
  el.style.opacity = '.6';
  const results = [];
  for (const quality of ['hd', '4k']) {
    el.textContent = `Scanning ${quality.toUpperCase()}…`;
    try {
      const r = await fetch(`/api/movies/${imdbId}/scan/${quality}`, { method: 'POST' });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.detail || `No ${quality.toUpperCase()} stream found`);
      results.push(`${quality.toUpperCase()}: found`);
    } catch (exc) {
      results.push(`${quality.toUpperCase()}: ${exc.message || 'not found'}`);
    }
  }
  toast(results.join(' · '), 'ok');
  document.getElementById('delDlg')?.remove();
  await loadLib();
}

async function delQuality(safeId, quality) {
  document.getElementById('delDlg')?.remove();
  document.getElementById('seriesDlg')?.remove();
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;

  if (quality === 'both') {
    // Use series delete endpoint — cancels scan + removes everything atomically
    await fetch(`/api/series/${g.imdb}`, { method: 'DELETE' });
    toast('Series removed', 'ok');
  } else {
    const toDelete = quality === 'hd'
      ? g.stubs.filter(s => s.quality === 'hd')
      : g.stubs.filter(s => s.quality === '4k');
    for (const s of toDelete) {
      await fetch(`/api/stubs/${s.stub_id}`, { method: 'DELETE' });
    }
    toast(`Removed ${quality.toUpperCase()} stubs`, 'ok');
  }
  loadLib();
}

// ── Active stream picker ──────────────────────────────────────
function openStreamQualityChoiceModal(hdStubId, uhdStubId, label) {
  document.getElementById('delDlg')?.remove();

  const dlg = document.createElement('div');
  dlg.id = 'streamQualityChoiceDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:310;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px;max-width:340px;width:100%">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${label}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:22px">Which quality's active stream do you want to view/change?</div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <button class="admin-only mbtn mbtn-add" style="background:#1a2e40;color:var(--blue);border:1px solid rgba(74,158,255,.3)"
          onclick="document.getElementById('streamQualityChoiceDlg').remove();openActiveStreamModal('${hdStubId}','${label} (HD)')">HD</button>
        <button class="admin-only mbtn mbtn-add" style="background:#2e1e00;color:var(--acc2);border:1px solid rgba(232,160,32,.3)"
          onclick="document.getElementById('streamQualityChoiceDlg').remove();openActiveStreamModal('${uhdStubId}','${label} (4K)')">4K</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('streamQualityChoiceDlg').remove()" style="margin-top:4px">Cancel</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

async function openActiveStreamModal(stubId, label) {
  document.getElementById('delDlg')?.remove();

  const dlg = document.createElement('div');
  dlg.id = 'activeStreamDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:310;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:24px;max-width:640px;width:100%;max-height:82vh;display:flex;flex-direction:column">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${label}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:16px">Active stream — pick which source Plex actually plays</div>
      <div id="activeStreamList" style="overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:8px">
        <div style="color:var(--mut);font-size:13px;padding:20px 0;text-align:center">Loading candidates…</div>
      </div>
      <button class="mbtn mbtn-close" onclick="document.getElementById('activeStreamDlg').remove()" style="margin-top:16px">Close</button>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);

  try {
    const d = await (await fetch(`/api/stubs/${stubId}/candidates`)).json();
    renderActiveStreamCandidates(stubId, d.candidates || []);
  } catch (exc) {
    document.getElementById('activeStreamList').innerHTML =
      `<div style="color:var(--red);font-size:13px;padding:20px 0;text-align:center">Could not load candidates: ${exc.message || exc}</div>`;
  }
}

function renderActiveStreamCandidates(stubId, candidates) {
  const el = document.getElementById('activeStreamList');
  if (!el) return;
  if (!candidates.length) {
    el.innerHTML = `<div style="color:var(--mut);font-size:13px;padding:20px 0;text-align:center">No candidates available right now.</div>`;
    return;
  }
  window._activeStreamCandidates = candidates;
  el.innerHTML = candidates.map((c, i) => {
    const sizeStr = c.size_gb ? `${c.size_gb} GB` : 'size unknown';
    const tags = [
      c.resolution, c.encode, c.hdr,
      c.cached ? 'cached' : 'uncached',
      c.pack ? `${c.pack} pack` : null,
      c.service,
    ].filter(Boolean).join(' · ');
    return `
    <div style="background:${c.is_current ? 'rgba(232,160,32,.1)' : 'var(--card2)'};border:1px solid ${c.is_current ? 'var(--acc)' : 'var(--bor)'};border-radius:10px;padding:12px 14px;display:flex;align-items:center;gap:12px">
      <div style="flex:1;min-width:0">
        <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${(c.filename||'').replace(/"/g,'&quot;')}">${c.filename || 'Unknown filename'}</div>
        <div style="font-size:11px;color:var(--mut);margin-top:3px">${sizeStr}${tags ? ' · ' + tags : ''}</div>
      </div>
      ${c.is_current
        ? `<span class="cal-badge inlib" style="flex-shrink:0">Current</span>`
        : `<button class="admin-only cal-rescan-btn" style="flex-shrink:0" onclick="selectActiveStream('${stubId}',${i},this)">Use this</button>`}
    </div>`;
  }).join('');
}

async function selectActiveStream(stubId, index, btn) {
  const c = (window._activeStreamCandidates || [])[index];
  if (!c) return;
  const original = btn.textContent;
  btn.textContent = 'Setting…';
  btn.disabled = true;
  try {
    const r = await fetch(`/api/stubs/${stubId}/select-stream`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: c.url, headers: c.headers || {}, size: c.size }),
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'Could not set stream');
    }
    toast('Active stream updated', 'ok');
    document.getElementById('activeStreamDlg')?.remove();
    loadLib();
  } catch (exc) {
    toast(exc.message || 'Could not set stream', 'er');
    btn.textContent = original;
    btn.disabled = false;
  }
}

async function delStub(id) {
  await fetch(`/api/stubs/${id}`, { method: 'DELETE' });
  toast('Stub deleted', 'ok');
  loadLib();
}

// ── Config ────────────────────────────────────────────────────
function switchCfgTab(name) {
  document.querySelectorAll('.cfgtab').forEach(el => el.classList.remove('on'));
  document.querySelectorAll('.cfgpanel').forEach(el => el.classList.remove('on'));
  document.getElementById(`cfgtab-${name}`).classList.add('on');
  document.getElementById(`cfgpanel-${name}`).classList.add('on');
  if (name === 'users') loadUsers();
}

async function loadCfg() {
  try {
    const d = await (await fetch('/api/config')).json();
    document.getElementById('cfgChips').innerHTML =
      chip('Release search', d.search_source === 'aiostreams' ? 'AIOStreams' : 'TorBox search', true) +
      chip('TorBox key', {config: 'Saved in Config', env: 'From environment'}[d.torbox_key_source] || 'Not set', d.torbox_key_set) +
      chip('AllDebrid', d.alldebrid && d.alldebrid.in_use ? 'On (cached only)'
                       : (d.alldebrid && d.alldebrid.key_set ? 'Key saved, off' : 'Not set'),
           !!(d.alldebrid && d.alldebrid.in_use)) +
      chip('PLEX_URL',       d.plex_url || 'Not set', !!d.plex_url) +
      chip('Plex sign-in', d.plex_signin && d.plex_signin.ok ? 'Server found' : (d.plex_signin ? d.plex_signin.error : 'Unknown'), !!(d.plex_signin && d.plex_signin.ok));
    document.getElementById('wurl').textContent = `http://${location.hostname}:8001/webhook/plex`;
    renderTorboxKeyState(d.torbox_key_source);
    const ad = d.alldebrid || {};
    renderAlldebridState(ad.enabled, ad.key_set, ad.key_source, d.preferred_debrid);
    renderAiostreamsState(d.aiostreams, d.search_source);

    const f = d.fuse || {};
    document.getElementById('fuseChips').innerHTML =
      chip('FUSE_MOUNTPOINT',        f.mountpoint, true) +
      chip('FUSE_BLOCK_MB',          f.block_mb, true) +
      chip('FUSE_CACHE_BLOCKS',      f.cache_blocks, true) +
      chip('FUSE_PREFETCH_AHEAD',    f.prefetch_ahead, true) +
      chip('FUSE_READ_TIMEOUT',      f.read_timeout, true) +
      chip('FUSE_MAX_INFLIGHT',      f.max_inflight, true) +
      chip('FUSE_POOL_CONNECTIONS',  f.pool_connections, true) +
      chip('FUSE_POOL_MAXSIZE',      f.pool_maxsize, true);
  } catch {}
  try {
    const s = await (await fetch('/api/settings')).json();
    document.getElementById('prefLanguage').value = s.preferred_language ?? '';
    document.getElementById('prefAudio').value = (s.preferred_audio ?? []).join(', ');
    document.getElementById('preferPacks').checked = s.prefer_season_packs !== false;
    document.getElementById('minSizeGb').value = s.min_size_gb ?? 0;
    document.getElementById('maxSizeGb').value = s.max_size_gb ?? 0;
    document.getElementById('excludeWords').value = (s.exclude_words ?? []).join(', ');
    document.getElementById('min4kCandidates').value = s.min_4k_candidates ?? 1;
    document.getElementById('autoEpEnabled').checked = s.auto_episodes_enabled !== false;
    document.getElementById('autoEpInterval').value = s.auto_episodes_interval_minutes ?? 10;
    document.getElementById('autoEpRetryDays').value = s.auto_episodes_retry_days ?? 3;
    document.getElementById('pendingMvEnabled').checked = s.pending_movies_enabled !== false;
    document.getElementById('pendingMvRetryDays').value = s.pending_movies_retry_days ?? 30;
    document.getElementById('digitalDelayDays').value = s.digital_release_delay_days ?? 21;
    document.getElementById('repairInterval').value = s.repair_interval_minutes ?? 10;
    document.getElementById('plexScanQuiet').value = s.plex_scan_quiet_seconds ?? 30;
    document.getElementById('plexScanMax').value = s.plex_scan_max_wait_seconds ?? 300;
    document.getElementById('tbRpm').value = s.torbox_requests_per_minute ?? 250;
    document.getElementById('tbSearchRpm').value = s.torbox_search_per_minute ?? 120;
    document.getElementById('tbCreatePerHour').value = s.torbox_create_per_hour ?? 60;
    document.getElementById('tbCdnTtl').value = s.torbox_cdn_url_ttl_minutes ?? 120;
    document.getElementById('tbSearchCache').value = s.torbox_search_cache_minutes ?? 360;
    document.getElementById('tbHang').value = s.torbox_hang_max_seconds ?? 120;
    document.getElementById('tbProbeHead').value = s.probe_cache_head_mb ?? 16;
    document.getElementById('tbProbeTail').value = s.probe_cache_tail_mb ?? 16;
    document.getElementById('tbProbeMax').value = s.probe_cache_max_mb ?? 4096;
    document.getElementById('tbMaxCand').value = s.torbox_max_candidates ?? 3;
    document.getElementById('spotIntervalHours').value = s.spot_check_interval_hours ?? 0;
    document.getElementById('spotScheduledScope').value = s.spot_check_scheduled_scope ?? 'both';
    document.getElementById('spotVerifyQuality').checked = s.spot_check_verify_quality !== false;
  } catch {}
  migSvcChanged();
  renderSpotScopeChips();
  loadTorboxStats();
}

async function removePendingMovie(imdbId, btn) {
  if (btn) btn.disabled = true;
  try {
    await fetch(`/api/pending-movies/${imdbId}`, { method: 'DELETE' });
    loadLib();
  } catch {
    toast('Could not remove', 'er');
    if (btn) btn.disabled = false;
  }
}

async function removeQualityUnavailable(key, btn) {
  if (btn) btn.disabled = true;
  try {
    await fetch(`/api/quality-unavailable/${encodeURIComponent(key)}`, { method: 'DELETE' });
    loadLib();
  } catch {
    toast('Could not remove mark', 'er');
    if (btn) btn.disabled = false;
  }
}

async function removeWantedSeason(imdbId, season, btn) {
  if (btn) btn.disabled = true;
  try {
    await fetch(`/api/wanted-seasons/${imdbId}/${season}`, { method: 'DELETE' });
    loadLib();
  } catch {
    toast('Could not remove', 'er');
    if (btn) btn.disabled = false;
  }
}

async function removeSeasonWatch(imdbId, btn) {
  if (btn) btn.disabled = true;
  try {
    await fetch(`/api/series/${imdbId}/season-watch`, { method: 'DELETE' });
    loadLib();
  } catch {
    toast('Could not remove', 'er');
    if (btn) btn.disabled = false;
  }
}

async function savePendingMovies() {
  const retryDays = parseFloat(document.getElementById('pendingMvRetryDays').value);
  const digitalDelay = parseFloat(document.getElementById('digitalDelayDays').value);
  if (isNaN(retryDays) || retryDays < 0) {
    toast('Retry window must be ≥ 0 days', 'er');
    return;
  }
  if (isNaN(digitalDelay) || digitalDelay < 0) {
    toast('Digital delay must be ≥ 0 days', 'er');
    return;
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        pending_movies_enabled: document.getElementById('pendingMvEnabled').checked,
        pending_movies_retry_days: retryDays,
        digital_release_delay_days: digitalDelay,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('pendingMvSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function runPendingMoviesSweepNow() {
  const resultEl = document.getElementById('pendingMvSweepResult');
  resultEl.innerHTML = `<span style="color:var(--mut)">Checking…</span>`;
  try {
    const d = await (await fetch('/api/pending-movies/sweep-now', { method: 'POST' })).json();
    resultEl.innerHTML = `<span style="color:var(--grn)">Checked ${d.checked ?? 0}, resolved ${d.resolved ?? 0}, ${d.pending ?? 0} still pending</span>`;
    loadPendingMovies();
    loadLib();
  } catch {
    resultEl.innerHTML = `<span style="color:var(--red)">Check failed</span>`;
  }
}

// ── Migrate (Radarr/Sonarr) ──────────────────────────────────────
let migPreviewItems = [];
let migPollTimer = null;

async function migSvcChanged() {
  const svc = document.getElementById('migSvc').value;
  document.getElementById('migPreviewWrap').style.display = 'none';
  document.getElementById('migTestResult').innerHTML = '';
  document.getElementById('migKey').value = '';
  try {
    const s = await (await fetch('/api/migrate/settings')).json();
    if (svc === 'radarr') {
      document.getElementById('migUrl').value = s.radarr_url || '';
      document.getElementById('migKey').placeholder = s.radarr_configured ? 'Saved — leave blank to keep it' : 'API key';
    } else {
      document.getElementById('migUrl').value = s.sonarr_url || '';
      document.getElementById('migKey').placeholder = s.sonarr_configured ? 'Saved — leave blank to keep it' : 'API key';
    }
  } catch {}
}

async function migSaveAndTest() {
  const svc = document.getElementById('migSvc').value;
  const url = document.getElementById('migUrl').value.trim();
  const key = document.getElementById('migKey').value.trim();
  const resultEl = document.getElementById('migTestResult');
  if (!url) {
    resultEl.innerHTML = `<span style="color:var(--red)">Enter a URL first</span>`;
    return;
  }
  resultEl.innerHTML = `<span style="color:var(--mut)">Saving…</span>`;
  try {
    const body = { service: svc, url };
    if (key) body.api_key = key;
    let r = await fetch('/api/migrate/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || 'save failed');

    resultEl.innerHTML = `<span style="color:var(--mut)">Testing connection…</span>`;
    r = await fetch('/api/migrate/test', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ service: svc })
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'connection failed');
    resultEl.innerHTML = `<span style="color:var(--grn)">✓ Connected — ${d.instance_name || svc} v${d.version}</span>`;
    document.getElementById('migKey').value = '';
    migSvcChanged();
  } catch (exc) {
    resultEl.innerHTML = `<span style="color:var(--red)">${exc.message}</span>`;
  }
}

async function migLoadPreview() {
  const svc = document.getElementById('migSvc').value;
  const resultEl = document.getElementById('migTestResult');
  resultEl.innerHTML = `<span style="color:var(--mut)">Loading library from ${svc}…</span>`;
  try {
    const r = await fetch(`/api/migrate/preview?service=${svc}`);
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'load failed');
    migPreviewItems = d.items || [];
    resultEl.innerHTML = '';
    renderMigList(svc);
  } catch (exc) {
    resultEl.innerHTML = `<span style="color:var(--red)">${exc.message}</span>`;
  }
}

function renderMigList(svc) {
  const wrap = document.getElementById('migPreviewWrap');
  const list = document.getElementById('migList');
  const already = migPreviewItems.filter(it => it.in_library).length;
  document.getElementById('migPreviewSummary').textContent =
    `${migPreviewItems.length} ${svc === 'radarr' ? 'movie(s)' : 'series'} found · ${already} already in your library`;

  if (!migPreviewItems.length) {
    list.innerHTML = `<div style="color:var(--mut);font-size:13px;padding:16px">Nothing found — check the connection above.</div>`;
    wrap.style.display = 'block';
    return;
  }

  list.innerHTML = migPreviewItems.map((it, i) => {
    const sub = svc === 'radarr'
      ? (it.year || '')
      : `${it.seasons.length} season${it.seasons.length === 1 ? '' : 's'}${it.year ? ' · ' + it.year : ''}`;
    const badges = [];
    if (it.in_library) badges.push(`<span class="cal-badge inlib">Already in library</span>`);
    if (svc === 'radarr' && !it.has_file) badges.push(`<span class="cal-badge">Not downloaded in Radarr yet</span>`);
    const poster = it.poster
      ? `<img class="cal-poster" src="${it.poster}" loading="lazy">`
      : `<div class="cal-poster-placeholder">${svc === 'radarr' ? '\uD83C\uDFAC' : '\uD83D\uDCFA'}</div>`;
    return `<label class="cal-entry${it.in_library ? ' inlib' : ''}" style="cursor:pointer">
      <input type="checkbox" class="migItemCk" data-i="${i}" ${it.in_library ? '' : 'checked'} style="cursor:pointer;flex-shrink:0" onclick="event.stopPropagation()">
      ${poster}
      <div class="cal-info">
        <div class="cal-title">${it.title}</div>
        <div class="cal-sub">${sub}</div>
        ${badges.length ? `<div class="cal-badges">${badges.join('')}</div>` : ''}
      </div>
    </label>`;
  }).join('');
  wrap.style.display = 'block';
}

function migSelectAll(on) {
  document.querySelectorAll('.migItemCk').forEach(el => { el.checked = on; });
}

async function migStart() {
  const svc = document.getElementById('migSvc').value;
  const checked = Array.from(document.querySelectorAll('.migItemCk'))
    .filter(el => el.checked)
    .map(el => migPreviewItems[parseInt(el.getAttribute('data-i'), 10)].imdb_id);

  if (!checked.length) {
    toast('Select at least one title to migrate', 'er');
    return;
  }

  try {
    const r = await fetch('/api/migrate/run', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ service: svc, imdb_ids: checked, skip_existing: true })
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'could not start migration');
    migOpenModal(svc);
    migPoll(d.job_id);
  } catch (exc) {
    toast(exc.message || 'Could not start migration', 'er');
  }
}

function migOpenModal(svc) {
  document.getElementById('migModalTitle').textContent =
    `Migrating from ${svc === 'radarr' ? 'Radarr' : 'Sonarr'}`;
  document.getElementById('migModalCurrent').textContent = '';
  document.getElementById('migBar').style.width = '0%';
  document.getElementById('migCount').textContent = '0 / 0';
  document.getElementById('migStatusLabel').textContent = 'Starting…';
  document.getElementById('migErrors').innerHTML = '';
  const cancelBtn = document.getElementById('migCancelBtn');
  cancelBtn.style.display = 'inline-flex';
  cancelBtn.disabled = false;
  cancelBtn.textContent = 'Cancel';
  document.getElementById('migCloseBtn').style.display = 'none';
  document.getElementById('migModal').classList.add('open');
}

function migCloseModal() {
  document.getElementById('migModal').classList.remove('open');
  if (migPollTimer) { clearTimeout(migPollTimer); migPollTimer = null; }
}

let migCurrentJobId = null;

async function migCancel() {
  if (!migCurrentJobId) return;
  // Interrupts the current item immediately server-side (see
  // cancel_migration/_run_migration) — disable right away so it's clear
  // the click registered instead of inviting repeated presses while
  // still waiting on the next status poll to reflect it.
  const btn = document.getElementById('migCancelBtn');
  btn.disabled = true;
  btn.textContent = 'Cancelling…';
  document.getElementById('migStatusLabel').textContent = 'Cancelling…';
  try { await fetch(`/api/migrate/cancel/${migCurrentJobId}`, { method: 'POST' }); } catch {}
}

async function migPoll(jobId) {
  migCurrentJobId = jobId;
  try {
    const job = await (await fetch(`/api/migrate/status/${jobId}`)).json();
    const total = job.total || 0;
    const done  = job.done || 0;
    const pct = total ? Math.round((done / total) * 100) : (job.finished ? 100 : 0);
    document.getElementById('migBar').style.width = `${pct}%`;
    document.getElementById('migCount').textContent = `${done} / ${total}`;
    document.getElementById('migModalCurrent').textContent = job.current_title || '';

    const labels = { starting:'Starting…', running:'Migrating…', done:'Done', cancelled:'Cancelled', error:'Failed' };
    document.getElementById('migStatusLabel').textContent = labels[job.status] || job.status;

    if (job.errors && job.errors.length) {
      document.getElementById('migErrors').innerHTML =
        job.errors.map(e => `<div>⚠ ${e}</div>`).join('');
    }

    if (job.finished) {
      document.getElementById('migCancelBtn').style.display = 'none';
      document.getElementById('migCloseBtn').style.display = 'inline-flex';
      migPollTimer = null;
      if (job.status === 'done') { loadLib(); loadCalendar(); }
      return;
    }
    migPollTimer = setTimeout(() => migPoll(jobId), 1000);
  } catch {
    migPollTimer = setTimeout(() => migPoll(jobId), 2000);
  }
}

// ── Spot check ────────────────────────────────────────────────
let spotPollTimer = null;
let spotCurrentJobId = null;
let spotScope = 'both';   // 'both' | 'movies' | 'series'

const SPOT_SCOPES = [
  { id: 'both',   label: 'Movies + TV shows' },
  { id: 'movies', label: 'Movies only' },
  { id: 'series', label: 'TV shows only' },
];

function renderSpotScopeChips() {
  const el = document.getElementById('spotScopeChips');
  if (!el) return;
  el.innerHTML = SPOT_SCOPES.map(s =>
    `<button class="cal-chip${spotScope === s.id ? ' on' : ''}" onclick="spotSetScope('${s.id}')">${s.label}</button>`
  ).join('');
}

function spotSetScope(id) {
  spotScope = id;
  renderSpotScopeChips();
}

async function runSpotCheck() {
  document.getElementById('spotModalTitle').textContent = 'Spot checking…';
  document.getElementById('spotModalCurrent').textContent = '';
  document.getElementById('spotProgressWrap').style.display = 'block';
  document.getElementById('spotResults').style.display = 'none';
  document.getElementById('spotResults').innerHTML = '';
  document.getElementById('spotBar').style.width = '0%';
  document.getElementById('spotCount').textContent = '0 / 0';
  document.getElementById('spotStatusLabel').textContent = 'Starting…';
  const cancelBtn = document.getElementById('spotCancelBtn');
  cancelBtn.style.display = 'inline-flex';
  cancelBtn.disabled = false;
  cancelBtn.textContent = 'Cancel';
  document.getElementById('spotCloseBtn').style.display = 'none';
  document.getElementById('spotCheckModal').classList.add('open');

  try {
    const r = await fetch('/api/spot-check/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        scope: spotScope,
        verify_quality: document.getElementById('spotVerifyQuality').checked,
      }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Could not start spot check');
    spotPoll(d.job_id);
  } catch (exc) {
    toast(exc.message || 'Could not start spot check', 'er');
    document.getElementById('spotCheckModal').classList.remove('open');
  }
}

function spotCloseModal() {
  document.getElementById('spotCheckModal').classList.remove('open');
  if (spotPollTimer) { clearTimeout(spotPollTimer); spotPollTimer = null; }
}

async function spotCancel() {
  if (!spotCurrentJobId) return;
  const btn = document.getElementById('spotCancelBtn');
  btn.disabled = true;
  btn.textContent = 'Cancelling…';
  document.getElementById('spotStatusLabel').textContent = 'Cancelling…';
  try { await fetch(`/api/spot-check/cancel/${spotCurrentJobId}`, { method: 'POST' }); } catch {}
}

async function spotPoll(jobId) {
  spotCurrentJobId = jobId;
  try {
    const job = await (await fetch(`/api/spot-check/status/${jobId}`)).json();
    const total = job.total || 0;
    const done  = job.done || 0;
    const pct = total ? Math.round((done / total) * 100) : (job.finished ? 100 : 0);
    document.getElementById('spotBar').style.width = `${pct}%`;
    document.getElementById('spotCount').textContent = `${done} / ${total}`;
    document.getElementById('spotModalCurrent').textContent = job.current_title || '';

    const phaseLabels = { checking: 'Checking…', fixing: 'Searching…', verifying_quality: 'Verifying quality…' };
    const statusLabels = { starting:'Starting…', running: phaseLabels[job.phase] || 'Running…', done:'Done', cancelled:'Cancelled' };
    document.getElementById('spotStatusLabel').textContent = statusLabels[job.status] || job.status;
    document.getElementById('spotModalTitle').textContent =
      job.phase === 'fixing' ? 'Searching for what\u2019s missing…'
      : job.phase === 'verifying_quality' ? 'Verifying stub quality…'
      : 'Checking your library…';

    if (job.finished) {
      document.getElementById('spotCancelBtn').style.display = 'none';
      document.getElementById('spotCloseBtn').style.display = 'inline-flex';
      spotPollTimer = null;
      if (job.status === 'done') renderSpotResults(job);
      return;
    }
    spotPollTimer = setTimeout(() => spotPoll(jobId), 1000);
  } catch {
    spotPollTimer = setTimeout(() => spotPoll(jobId), 2000);
  }
}

function renderSpotResults(job) {
  const fixedEps    = job.fixed_episodes || [];
  const missingEps  = job.still_missing_episodes || [];
  const fixedMovies = job.fixed_movies || [];
  const missingMovies = job.still_missing_movies || [];
  const qualityFixed  = job.quality_fixed || [];
  const qualityIssues = job.quality_unresolved || [];
  document.getElementById('spotProgressWrap').style.display = 'none';

  const fixedTotal   = fixedEps.length + fixedMovies.length + qualityFixed.length;
  const missingTotal = missingEps.length + missingMovies.length + qualityIssues.length;
  const checkedTotal = fixedTotal + missingTotal;

  document.getElementById('spotModalTitle').textContent =
    checkedTotal === 0 ? 'Nothing missing' : `Found ${fixedTotal} of ${checkedTotal} thing${checkedTotal !== 1 ? 's' : ''}`;
  document.getElementById('spotModalCurrent').textContent =
    checkedTotal === 0 ? 'Every tracked series and movie checks out.'
    : missingTotal === 0 ? 'Everything found has been fixed.'
    : `${missingTotal} still couldn't be resolved right now.`;

  const resEl = document.getElementById('spotResults');
  resEl.style.display = 'block';

  const row = (title, sub, poster, icon, fixed, reason, fixedLabel, missingLabel) => `
    <div class="cal-entry${fixed ? ' inlib' : ''}" style="margin-bottom:8px">
      ${poster ? `<img class="cal-poster" src="${poster}" loading="lazy">` : `<div class="cal-poster-placeholder">${icon}</div>`}
      <div class="cal-info">
        <div class="cal-title">${title}</div>
        <div class="cal-sub">${sub}${reason ? ` — ${reason}` : ''}</div>
      </div>
      ${fixed
        ? `<span class="cal-badge inlib">${fixedLabel || 'Found'}</span>`
        : `<span class="cal-badge">${missingLabel || 'Still missing'}</span>`}
    </div>`;

  let html = '';
  if (fixedEps.length || missingEps.length) {
    html += `<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:8px">Episodes (${fixedEps.length} found, ${missingEps.length} still missing)</div>`;
    html += fixedEps.map(e => row(e.title, `S${String(e.season).padStart(2,'0')}E${String(e.episode).padStart(2,'0')} — ${e.episode_name}`, e.poster, '\uD83D\uDCFA', true)).join('');
    html += missingEps.map(e => row(e.title, `S${String(e.season).padStart(2,'0')}E${String(e.episode).padStart(2,'0')} — ${e.episode_name}`, e.poster, '\uD83D\uDCFA', false, e.reason)).join('');
  }
  if (fixedMovies.length || missingMovies.length) {
    html += `<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin:${(fixedEps.length||missingEps.length)?'18px':'0'} 0 8px">Overdue pending movies (${fixedMovies.length} found, ${missingMovies.length} still missing)</div>`;
    html += fixedMovies.map(m => row(m.title, m.year || '', m.poster, '\uD83C\uDFAC', true)).join('');
    html += missingMovies.map(m => row(m.title, m.year || '', m.poster, '\uD83C\uDFAC', false, m.reason)).join('');
  }
  if (qualityFixed.length || qualityIssues.length) {
    const priorSections = fixedEps.length || missingEps.length || fixedMovies.length || missingMovies.length;
    html += `<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin:${priorSections?'18px':'0'} 0 8px">Quality mismatches (${qualityFixed.length} corrected, ${qualityIssues.length} unresolved)</div>`;
    html += qualityFixed.map(q => row(
      q.title, `Was labeled ${q.labeled.toUpperCase()}, stream was actually ${q.detected.toUpperCase()}`,
      q.poster, '\u26A0\uFE0F', true, null, 'Corrected'
    )).join('');
    html += qualityIssues.map(q => row(
      q.title, `Was labeled ${q.labeled.toUpperCase()}, stream was actually ${q.detected.toUpperCase()}`,
      q.poster, '\u26A0\uFE0F', false, q.reason, null, 'Unresolved'
    )).join('');
  }
  if (!checkedTotal) {
    html = `<div style="color:var(--mut);font-size:13px;padding:12px 0">Nothing to show — everything tracked is accounted for.</div>`;
  }
  resEl.innerHTML = html;

  if (fixedTotal > 0) { loadLib(); loadCalendar(); }
  loadLib();   // spot check can affect quality-unavailable/missing state, both shown in the Library tab now
}


function chip(l,v,ok){return`<div class="chip"><span class="cl">${l}</span><span class="cv ${ok?'ok':'er'}">${v}</span></div>`}

async function saveStreamPrefs() {
  const minGb = parseFloat(document.getElementById('minSizeGb').value) || 0;
  const maxGb = parseFloat(document.getElementById('maxSizeGb').value) || 0;
  if (minGb < 0 || maxGb < 0) {
    toast('Sizes must be ≥ 0', 'er');
    return;
  }
  if (minGb && maxGb && minGb > maxGb) {
    toast('Min size cannot be greater than max size', 'er');
    return;
  }
  const min4k = parseInt(document.getElementById('min4kCandidates').value, 10);
  if (isNaN(min4k) || min4k < 1) {
    toast('Minimum cached 4K releases must be at least 1', 'er');
    return;
  }
  const audio = document.getElementById('prefAudio').value
    .split(',').map(s => s.trim()).filter(Boolean);
  const excludeWords = document.getElementById('excludeWords').value
    .split(',').map(s => s.trim()).filter(Boolean);

  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        preferred_language: document.getElementById('prefLanguage').value.trim(),
        preferred_audio: audio,
        prefer_season_packs: document.getElementById('preferPacks').checked,
        min_size_gb: minGb,
        max_size_gb: maxGb,
        exclude_words: excludeWords,
        min_4k_candidates: min4k,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('streamPrefsSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save release selection', 'er');
  }
}

async function saveAutoEpisodes() {
  const interval = parseInt(document.getElementById('autoEpInterval').value, 10);
  const retryDays = parseFloat(document.getElementById('autoEpRetryDays').value);
  if (isNaN(interval) || interval < 5) {
    toast('Check interval must be at least 5 minutes', 'er');
    return;
  }
  if (isNaN(retryDays) || retryDays < 0) {
    toast('Retry window must be ≥ 0 days', 'er');
    return;
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        auto_episodes_enabled: document.getElementById('autoEpEnabled').checked,
        auto_episodes_interval_minutes: interval,
        auto_episodes_retry_days: retryDays,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('autoEpSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function savePlexScanSettings() {
  const quiet = parseFloat(document.getElementById('plexScanQuiet').value);
  const max = parseFloat(document.getElementById('plexScanMax').value);
  if (isNaN(quiet) || quiet < 5) { toast('Quiet period must be at least 5 seconds', 'er'); return; }
  if (isNaN(max) || max < 30) { toast('Max wait must be at least 30 seconds', 'er'); return; }
  if (max < quiet) { toast('Max wait should be at least the quiet period', 'er'); return; }
  const r = await fetch('/api/settings', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ plex_scan_quiet_seconds: quiet, plex_scan_max_wait_seconds: max }),
  });
  if (!r.ok) { const d = await r.json().catch(() => ({})); toast(d.detail || 'Could not save', 'er'); return; }
  const el = document.getElementById('plexScanSaved');
  el.style.display = 'inline'; setTimeout(() => { el.style.display = 'none'; }, 2000);
}

async function saveRepairSettings() {
  const minutes = parseFloat(document.getElementById('repairInterval').value);
  if (isNaN(minutes) || minutes < 1) { toast('Interval must be at least 1 minute', 'er'); return; }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ repair_interval_minutes: minutes })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('repairSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function runRepairNow() {
  try {
    const d = await (await fetch('/api/repair/run', { method: 'POST' })).json();
    toast(d.queued ? `Repairing ${d.queued} entr${d.queued === 1 ? 'y' : 'ies'} in the background` : 'Nothing needs repair', 'ok');
  } catch { toast('Could not start repair', 'er'); }
}

async function loadTorboxStats() {
  const el = document.getElementById('tbStats');
  if (!el) return;
  try {
    const d = await (await fetch('/api/torbox/stats')).json();
    const pc = d.probe_cache || {};
    el.innerHTML =
      chip('Calls last min', `${d.calls_last_minute ?? 0} / ${d.limit_per_minute ?? '?'}`, (d.calls_last_minute ?? 0) < (d.limit_per_minute ?? 250)) +
      chip('CDN link hits', d.cdn_url_cache_hits ?? 0, true) +
      chip('Search hits', d.search_cache_hits ?? 0, true) +
      chip('Probe cache hits', d.probe_cache_hits ?? 0, true) +
      chip('Link repairs', d.cdn_url_repairs ?? 0, true) +
      chip('429s', d.http_429 ?? 0, !(d.http_429)) +
      chip('Quarantined', d.breaker_open ?? 0, !(d.breaker_open)) +
      chip('Torrents mirrored', d.known_torrents ?? 0, true) +
      chip('Probe cache', `${pc.mb ?? 0} / ${pc.max_mb ?? 0} MB`, true) +
      chip('Plex scans sent', `${(d.plex_scans || {}).scans_sent ?? 0} for ${(d.plex_scans || {}).requests_queued ?? 0} changes`, true);
  } catch { el.innerHTML = '<span style="color:var(--mut);font-size:13px">Stats unavailable</span>'; }
}

async function saveTorboxSaver() {
  const num = id => parseFloat(document.getElementById(id).value);
  const body = {
    torbox_requests_per_minute: num('tbRpm'),
    torbox_search_per_minute: num('tbSearchRpm'),
    torbox_create_per_hour: num('tbCreatePerHour'),
    torbox_cdn_url_ttl_minutes: num('tbCdnTtl'),
    torbox_search_cache_minutes: num('tbSearchCache'),
    torbox_hang_max_seconds: num('tbHang'),
    probe_cache_head_mb: num('tbProbeHead'),
    probe_cache_tail_mb: num('tbProbeTail'),
    probe_cache_max_mb: num('tbProbeMax'),
    torbox_max_candidates: num('tbMaxCand'),
  };
  for (const [k, v] of Object.entries(body)) {
    if (typeof v === 'number' && isNaN(v)) { toast(`${k} must be a number`, 'er'); return; }
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('tbSaverSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2500);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function torboxSyncNow(btn) {
  btn.disabled = true; const t = btn.textContent; btn.textContent = 'Syncing…';
  try {
    const r = await fetch('/api/torbox/sync-now', { method: 'POST' });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'sync failed');
    toast(`Mirrored ${d.torrents} torrent(s) from your TorBox account`, 'ok');
    loadTorboxStats();
  } catch (exc) { toast(exc.message, 'er'); }
  btn.disabled = false; btn.textContent = t;
}

async function saveSpotCheckSchedule() {
  const hours = parseFloat(document.getElementById('spotIntervalHours').value);
  if (isNaN(hours) || hours < 0) {
    toast('Interval must be ≥ 0 hours', 'er');
    return;
  }
  const scope = document.getElementById('spotScheduledScope').value;
  const verifyQuality = document.getElementById('spotVerifyQuality').checked;
  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        spot_check_interval_hours: hours,
        spot_check_scheduled_scope: scope,
        spot_check_verify_quality: verifyQuality,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('spotScheduleSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function runAutoEpisodeSweepNow() {
  const resultEl = document.getElementById('autoEpSweepResult');
  resultEl.innerHTML = '<span style="color:var(--mut)">Checking tracked shows for new episodes…</span>';
  try {
    const r = await fetch('/api/auto-episodes/sweep-now', { method: 'POST' });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Sweep failed');
    if (d.skipped) {
      resultEl.innerHTML = `<span style="color:var(--mut)">Skipped (${d.skipped})</span>`;
      return;
    }
    let msg = `Checked ${d.shows_checked} show${d.shows_checked!==1?'s':''}`;
    if (d.new_stubs) msg += ` — ${d.new_stubs} new episode${d.new_stubs!==1?'s':''} stubbed`;
    else msg += ' — no new episodes found';
    if (d.pending) msg += ` (${d.pending} still waiting on a stream)`;
    resultEl.innerHTML = `<span style="color:var(--grn)">✓ ${msg}</span>`;
    if (d.new_stubs) { toast('New episodes added', 'ok'); if (typeof loadLib === 'function') loadLib(); }
  } catch (exc) {
    resultEl.innerHTML = `<span style="color:var(--red)">✕ ${exc.message}</span>`;
  }
}

function downloadBackup() {
  // Plain navigation triggers the browser's normal file-download flow and
  // picks up the Content-Disposition filename from the server response.
  window.location.href = '/api/backup';
}

async function restoreFromFile(event) {
  const file = event.target.files[0];
  event.target.value = '';   // allow re-selecting the same file later
  if (!file) return;

  const resultEl = document.getElementById('restoreResult');
  resultEl.innerHTML = '<span style="color:var(--mut)">Restoring…</span>';

  let bundle;
  try {
    const text = await file.text();
    bundle = JSON.parse(text);
  } catch {
    resultEl.innerHTML = '<span style="color:var(--red)">✕ Not a valid JSON file</span>';
    return;
  }

  const replace = document.getElementById('restoreReplace').checked;
  if (replace && !confirm('This will REMOVE any title not present in the backup. Titles in both are kept as-is. Continue?')) {
    resultEl.innerHTML = '';
    return;
  }

  try {
    const r = await fetch('/api/restore', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ bundle, replace })
    });
    const d = await r.json();
    if (!r.ok) {
      resultEl.innerHTML = `<span style="color:var(--red)">✕ ${d.detail || 'Restore failed'}</span>`;
      return;
    }
    const lib = d.library;
    let msg = d.settings_restored ? 'Settings restored. ' : '';
    if (lib) {
      msg += `Library: ${lib.imported} imported`;
      if (lib.skipped) msg += `, ${lib.skipped} already present (left untouched)`;
      if (lib.pruned) msg += `, ${lib.pruned} removed`;
      if (lib.errors && lib.errors.length) msg += `, ${lib.errors.length} error(s)`;
    }
    resultEl.innerHTML = `<span style="color:var(--grn)">✓ ${msg}</span>`;
    toast('Restore complete', 'ok');
    loadCfg();
    if (typeof loadLib === 'function') loadLib();
  } catch (exc) {
    resultEl.innerHTML = '<span style="color:var(--red)">✕ Restore request failed</span>';
  }
}

function renderAiostreamsState(a, searchSource) {
  a = a || {};
  document.getElementById('aioUrl').value = a.url || '';
  document.getElementById('aioUuid').value = '';
  document.getElementById('aioPass').value = '';
  document.getElementById('aioUuid').placeholder = a.uuid_set ? 'Saved — leave blank to keep' : 'UUID';
  document.getElementById('aioPass').placeholder = a.password_set ? 'Saved — leave blank to keep' : 'Password';
  document.getElementById('aioClearBtn').style.display = a.source === 'config' ? '' : 'none';
  document.getElementById('aioHint').textContent = a.configured
    ? (a.source === 'env' ? 'Using AIOSTREAMS_* from the environment. Saving here overrides it.' : 'Release search is using AIOStreams.')
    : 'Not set up — release search is using TorBox search.';
}

async function saveAiostreams() {
  const url = document.getElementById('aioUrl').value.trim();
  const uuidInput = document.getElementById('aioUuid').value.trim();
  const password = document.getElementById('aioPass').value;
  const res = document.getElementById('aioResult');
  const btn = document.getElementById('aioSaveBtn');
  if (!url) { toast('Enter the AIOStreams URL', 'er'); return; }
  let uuid = uuidInput;
  if (!uuid) {
    if (!document.getElementById('aioUuid').placeholder.startsWith('Saved')) { toast('Enter your AIOStreams UUID', 'er'); return; }
    uuid = null;
  }
  btn.disabled = true; btn.textContent = 'Testing…';
  res.innerHTML = '<span style="color:var(--mut)">Running a test search…</span>';
  try {
    const r = await fetch('/api/aiostreams/config', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, uuid: uuid ?? '__keep__', password: password || null }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Could not save');
    res.innerHTML = _aioSummary(d);
    toast('AIOStreams saved', 'ok');
    await loadCfg();
    document.getElementById('aioResult').innerHTML = _aioSummary(d);
  } catch (exc) {
    res.innerHTML = `<span style="color:var(--red)">✗ ${_esc(exc.message)}</span>`;
  } finally {
    btn.disabled = false; btn.textContent = 'Save & test';
  }
}

function _aioSummary(d) {
  const warn = d.torrent_results === 0 && d.total_results > 0
    ? `<div style="color:var(--acc2);font-size:12px;margin-top:4px">None of the results were torrents with a hash (usenet/HTTP only), so nothing could be added through TorBox. Enable torrent addons in AIOStreams.</div>` : '';
  return `<span style="color:var(--grn)">✓ Connected</span>
    <span style="color:var(--mut);font-size:12px;margin-left:8px">test search: ${d.total_results} results · ${d.torrent_results} torrents · ${d.cached_torrents} cached</span>${warn}`;
}

async function testAiostreams() {
  const res = document.getElementById('aioResult');
  res.innerHTML = '<span style="color:var(--mut)">Testing…</span>';
  const d = await (await fetch('/api/aiostreams/test', { method: 'POST' })).json();
  res.innerHTML = d.ok ? _aioSummary(d) : `<span style="color:var(--red)">✗ ${_esc(d.error)}</span>`;
}

async function clearAiostreams() {
  if (!confirm('Remove the saved AIOStreams details? Release search falls back to the environment settings or TorBox search.')) return;
  const d = await (await fetch('/api/aiostreams/config', { method: 'DELETE' })).json();
  toast(d.search_source === 'aiostreams' ? 'Removed — using AIOSTREAMS_* from the environment' : 'Removed — using TorBox search', 'ok');
  document.getElementById('aioResult').innerHTML = '';
  loadCfg();
}

function renderTorboxKeyState(source) {
  const input = document.getElementById('tbKeyInput');
  const hint = document.getElementById('tbKeyHint');
  input.value = '';
  document.getElementById('tbKeyClearBtn').style.display = source === 'config' ? '' : 'none';
  if (source === 'config') {
    input.placeholder = 'Saved — paste a new key to replace it';
    hint.textContent = 'A key is saved. It isn\'t shown again; paste a new one to replace it, or Remove it.';
  } else if (source === 'env') {
    input.placeholder = 'Using TORBOX_API_KEY from the environment — paste a key to override';
    hint.textContent = 'Currently using TORBOX_API_KEY from docker-compose.yml. A key saved here takes priority over it.';
  } else {
    input.placeholder = 'Paste your TorBox API key';
    hint.textContent = 'Find it at torbox.app → Settings → API. The key is checked with TorBox before it\'s saved.';
  }
}

async function saveTorboxKey() {
  const input = document.getElementById('tbKeyInput');
  const btn = document.getElementById('tbKeySaveBtn');
  const key = input.value.trim();
  if (!key) { toast('Paste a TorBox API key first', 'er'); input.focus(); return; }
  btn.disabled = true; btn.textContent = 'Checking…';
  try {
    const r = await fetch('/api/torbox/key', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ api_key: key }),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || 'Could not save the key');
    const plans = {0: 'Free', 1: 'Essential', 2: 'Pro', 3: 'Standard'};
    toast(`TorBox key saved${d.email ? ' — ' + d.email : ''}${d.plan != null ? ' (' + (plans[d.plan] || 'plan ' + d.plan) + ')' : ''}`, 'ok');
    await loadCfg();
  } catch (exc) {
    toast(exc.message, 'er');
  } finally {
    btn.disabled = false; btn.textContent = 'Save';
  }
}

async function clearTorboxKey() {
  if (!confirm('Remove the saved TorBox API key? Library files stop streaming until a key is set again (unless TORBOX_API_KEY is set in the environment).')) return;
  try {
    const d = await (await fetch('/api/torbox/key', { method: 'DELETE' })).json();
    toast(d.source === 'env' ? 'Saved key removed — using TORBOX_API_KEY from the environment' : 'Saved key removed', 'ok');
    await loadCfg();
  } catch { toast('Could not remove the key', 'er'); }
}

function renderAlldebridState(enabled, keySet, keySource, preferred) {
  const input = document.getElementById('adKeyInput');
  const hint  = document.getElementById('adKeyHint');
  const box   = document.getElementById('adEnabled');
  const pref  = document.getElementById('prefDebrid');
  if (!input) return;
  input.value = '';
  document.getElementById('adKeyClearBtn').style.display = keySource === 'config' ? '' : 'none';
  if (keySource === 'config') {
    input.placeholder = 'Saved — paste a new key to replace it';
    hint.textContent = "A key is saved. It isn't shown again; paste a new one to replace it, or Remove it.";
  } else if (keySource === 'env') {
    input.placeholder = 'Using ALLDEBRID_API_KEY from the environment — paste a key to override';
    hint.textContent = 'Currently using ALLDEBRID_API_KEY from docker-compose.yml. A key saved here takes priority over it.';
  } else {
    input.placeholder = 'Paste your AllDebrid API key';
    hint.textContent = "Find it at alldebrid.com → My account → API keys. The key is checked with AllDebrid before it's saved.";
  }
  box.checked  = !!enabled;
  box.disabled = !keySet;
  if (!keySet) {
    hint.textContent += ' Add a key before switching AllDebrid on.';
  }
  if (pref) pref.value = preferred || 'torbox';
}

async function saveAlldebridKey() {
  const input = document.getElementById('adKeyInput');
  const btn = document.getElementById('adKeySaveBtn');
  const key = input.value.trim();
  if (!key) { toast('Paste an AllDebrid API key first', 'er'); input.focus(); return; }
  btn.disabled = true; btn.textContent = 'Checking…';
  try {
    const r = await fetch('/api/alldebrid/key', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ api_key: key }),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || 'Could not save the key');
    toast(`AllDebrid key saved${d.username ? ' — ' + d.username : ''}. Switch it on to start using cached links.`, 'ok');
    await loadCfg();
  } catch (exc) {
    toast(exc.message, 'er');
  } finally {
    btn.disabled = false; btn.textContent = 'Save';
  }
}

async function clearAlldebridKey() {
  if (!confirm('Remove the saved AllDebrid API key? AllDebrid is switched off too, and entries bound to AllDebrid stop streaming until a key is set again.')) return;
  try {
    const d = await (await fetch('/api/alldebrid/key', { method: 'DELETE' })).json();
    toast(d.source === 'env' ? 'Saved key removed — using ALLDEBRID_API_KEY from the environment' : 'Saved key removed', 'ok');
    await loadCfg();
  } catch { toast('Could not remove the key', 'er'); }
}

async function saveAlldebridEnabled() {
  const box = document.getElementById('adEnabled');
  const on = box.checked;
  try {
    const r = await fetch('/api/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ alldebrid_enabled: on }),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || 'Could not save');
    toast(on ? 'AllDebrid on — cached AllDebrid releases can now be added' : 'AllDebrid off — its results are no longer shown', 'ok');
  } catch (exc) {
    box.checked = !on;
    toast(exc.message, 'er');
  }
}

async function savePreferredDebrid() {
  const v = document.getElementById('prefDebrid').value;
  try {
    const r = await fetch('/api/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ preferred_debrid: v }),
    });
    if (!r.ok) throw new Error('Could not save');
    toast('Preference saved', 'ok');
  } catch (exc) { toast(exc.message, 'er'); }
}

async function testAlldebrid() {
  const el = document.getElementById('adResult');
  el.innerHTML = '<span style="color:var(--mut)">Testing…</span>';
  try {
    const d = await (await fetch('/api/alldebrid/test')).json();
    if (d.ok) {
      el.innerHTML = `<span style="color:var(--grn)">✓ AllDebrid account OK${d.username ? ' — ' + d.username : ''}</span>
        <span style="color:var(--mut);font-size:12px;margin-left:8px">${d.enabled ? 'in use for cached links' : 'saved but switched off'}</span>`;
    } else {
      const diag = {
        no_key:      '🔑 Enter your AllDebrid API key above',
        bad_auth:    '🔑 AllDebrid rejected the API key — copy it again from alldebrid.com → My account',
        not_premium: '⚠ This account isn\'t premium — AllDebrid won\'t unlock cached links for it',
        unreachable: '🔌 Cannot reach api.alldebrid.com — check the container\'s network/DNS',
      }[d.diagnosis] || '';
      el.innerHTML = `<span style="color:var(--red)">✕ ${d.error || 'Test failed'}</span>` +
        (diag ? `<div style="color:var(--mut);font-size:12px;margin-top:6px">${diag}</div>` : '');
    }
  } catch { el.innerHTML = '<span style="color:var(--red)">✕ Test request failed</span>'; }
}

async function runTest() {
  const el = document.getElementById('tresult');
  el.innerHTML = '<span style="color:var(--mut)">Testing…</span>';
  try {
    const d = await (await fetch('/api/test')).json();

    const plans = {0: 'Free', 1: 'Essential', 2: 'Pro', 3: 'Standard'};
    if (d.ok) {
      el.innerHTML = `<span style="color:var(--grn)">✓ TorBox account OK${d.plan != null ? ' — ' + (plans[d.plan] || 'plan ' + d.plan) : ''}</span>
        <span style="color:var(--mut);font-size:12px;margin-left:8px">search test: ${d.cached_results} cached of ${d.total_results} results</span>`;
    } else {
      const diag = {
        no_key:        '🔑 Enter your TorBox API key above',
        bad_auth:      '🔑 TorBox rejected the API key — copy it again from torbox.app → Settings',
        unreachable:   '🔌 Cannot reach api.torbox.app — check the container\'s network/DNS',
        search_failed: '🔎 Account works but search-api.torbox.app failed — try again shortly',
      }[d.diagnosis] || '';
      el.innerHTML = `<div style="color:var(--red);margin-bottom:6px">✗ ${d.error || 'Connection failed'}</div>`
        + (diag ? `<div style="color:var(--acc2);font-size:12px">${diag}</div>` : '');
    }
  } catch(e) {
    el.innerHTML = `<span style="color:var(--red)">✗ ${e.message}</span>`;
  }
}

// ── Search ────────────────────────────────────────────────────
let srchTab = 'all', srchTimer = null, lastQuery = '';

function onSrchInput(val) {
  document.getElementById('srchClear').style.display = val ? 'block' : 'none';
  clearTimeout(srchTimer);
  if (!val.trim()) {
    showSearchEmpty();
    lastQuery = '';
    return;
  }
  srchTimer = setTimeout(() => doSearch(), 420);
}

function setTab(tab, el) {
  srchTab = tab;
  document.querySelectorAll('.srch-tab').forEach(t => t.classList.remove('on'));
  el.classList.add('on');
  if (lastQuery) doSearch();
}

function clearSearch() {
  document.getElementById('srchInput').value = '';
  document.getElementById('srchClear').style.display = 'none';
  lastQuery = '';
  showSearchEmpty();
}

function showSearchEmpty() {
  document.getElementById('srchStatus').textContent = '';
  document.getElementById('srchGrid').innerHTML = `
    <div class="srch-empty">
      
      <div class="srch-empty-title">Search for movies and series</div>
      <div class="srch-empty-sub">Powered by Cinemeta — the same source as Stremio</div>
    </div>`;
}

async function doSearch() {
  const q = document.getElementById('srchInput').value.trim();
  if (!q) return;
  lastQuery = q;

  const grid = document.getElementById('srchGrid');
  const status = document.getElementById('srchStatus');
  status.textContent = 'Searching…';

  // Skeleton placeholders matching card() dimensions
  grid.innerHTML = Array(8).fill(0).map(() =>
    `<div class="card" style="pointer-events:none">
       <div class="skel cposter"></div>
       <div class="skel cname" style="height:12px;margin-top:8px;width:80%"></div>
       <div class="skel cyear" style="height:11px;margin-top:5px;width:45%"></div>
     </div>`
  ).join('');

  // Cinemeta search: /catalog/{type}/top/search={query}.json
  const encode = encodeURIComponent(q);
  const types = srchTab === 'all'    ? ['movie','series']
              : srchTab === 'movie'  ? ['movie']
              :                        ['series'];

  try {
    const results = await Promise.all(
      types.map(t => cmFetch(`catalog/${t}/top/search=${encode}.json`)
        .then(d => (d.metas || []).map(m => ({ ...m, _type: t })))
        .catch(() => []))
    );

    // Interleave movie + series results so they mix naturally
    const merged = [];
    const arrs = results;
    const maxLen = Math.max(...arrs.map(a => a.length));
    for (let i = 0; i < maxLen; i++) {
      arrs.forEach(a => { if (a[i]) merged.push(a[i]); });
    }

    if (!merged.length) {
      status.textContent = `No results for "${q}"`;
      grid.innerHTML = `
        <div class="srch-empty">
          
          <div class="srch-empty-title">No results for "${q}"</div>
          <div class="srch-empty-sub">Try a different title or check spelling</div>
        </div>`;
      return;
    }

    const typeLabel = srchTab === 'all' ? 'movies & series'
                    : srchTab === 'movie' ? 'movies' : 'series';
    status.textContent = `${merged.length} result${merged.length !== 1 ? 's' : ''} for "${q}"`;
    grid.innerHTML = merged.map(m => card(m, m._type || 'movie')).join('');
  } catch(e) {
    status.textContent = '';
    grid.innerHTML = `<div class="srch-empty">
      <div class="srch-empty-icon">⚠️</div>
      <div class="srch-empty-title">Search failed</div>
      <div class="srch-empty-sub">${e.message}</div>
    </div>`;
    status.textContent = '';
  }
}


function pollScan(imdbId, title) {
  _bg_scans_ui.add(imdbId);
  let lastCount = 0;
  const iv = setInterval(async () => {
    try {
      const r = await fetch(`/api/scan/${imdbId}`);
      const d = await r.json();
      if (d.stubs !== lastCount) {
        lastCount = d.stubs;
        await syncStubs();
        await loadLib();
      }
      if (!d.scanning) {
        clearInterval(iv);
        _bg_scans_ui.delete(imdbId);
        toast(`"${title}" — ${d.stubs} stub${d.stubs!==1?'s':''} ready in Plex`, 'ok');
        await syncStubs();
        await loadLib();
      }
    } catch { clearInterval(iv); _bg_scans_ui.delete(imdbId); }
  }, 4000);
}

// ── Toast ─────────────────────────────────────────────────────
function toast(msg, type='ok') {
  const el=document.createElement('div');
  el.className=`toast ${type}`;
  el.textContent=msg;
  document.body.appendChild(el);
  setTimeout(()=>el.remove(), 3500);
}

// ── Accounts ──────────────────────────────────────────────────
let CURRENT_USER = null;
let _authResolve = null;
let _appStarted = false;
let _lastForbiddenToast = 0;
const isAdmin = () => !!(CURRENT_USER && CURRENT_USER.role === 'admin');

const _rawFetch = window.fetch.bind(window);
window.fetch = async (input, init) => {
  const r = await _rawFetch(input, init);
  const url = typeof input === 'string' ? input : (input && input.url) || '';
  if (url.startsWith('/api/') && !url.startsWith('/api/auth/')) {
    if (r.status === 401 && CURRENT_USER) {
      CURRENT_USER = null;
      toast('Your session ended — please sign in again', 'in');
      checkAuth();
    } else if (r.status === 403 && Date.now() - _lastForbiddenToast > 3000) {
      _lastForbiddenToast = Date.now();
      toast('Only admins can do that', 'er');
    }
  }
  return r;
};

async function checkAuth() {
  let st;
  try { st = await (await _rawFetch('/api/auth/status')).json(); }
  catch { st = { user: null }; }
  if (st.user) {
    CURRENT_USER = st.user;
    document.getElementById('authBg').classList.remove('open');
    applyRole();
    return st;
  }
  showAuth();
  return new Promise(resolve => { _authResolve = resolve; });
}

function showAuth(message) {
  cancelPlexSignIn(true);
  document.getElementById('authErr').textContent = message || '';
  document.getElementById('authBg').classList.add('open');
}

let _plexPoll = null;
let _plexPopup = null;

async function startPlexSignIn() {
  const err = document.getElementById('authErr');
  const btn = document.getElementById('plexSignInBtn');
  err.textContent = '';
  // Open the window synchronously (inside the click) so popup blockers allow it
  _plexPopup = window.open('', 'plexauth', 'width=600,height=720');
  btn.disabled = true; btn.textContent = 'Opening Plex…';
  let d;
  try {
    const r = await _rawFetch('/api/auth/plex/start', { method: 'POST' });
    d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Could not start Plex sign-in');
  } catch (exc) {
    if (_plexPopup) _plexPopup.close();
    err.textContent = exc.message;
    btn.disabled = false; btn.textContent = 'Sign in with Plex';
    return;
  }
  if (_plexPopup && !_plexPopup.closed) _plexPopup.location = d.auth_url;
  else _plexPopup = window.open(d.auth_url, 'plexauth', 'width=600,height=720');
  document.getElementById('plexOpenLink').href = d.auth_url;
  document.getElementById('plexWaiting').style.display = '';
  btn.textContent = 'Waiting for Plex…';

  const deadline = Date.now() + (d.expires_in || 600) * 1000;
  clearInterval(_plexPoll);
  _plexPoll = setInterval(async () => {
    if (Date.now() > deadline) { showAuth('Sign-in timed out — try again'); return; }
    let res, body;
    try {
      res = await _rawFetch('/api/auth/plex/finish', { method: 'POST' });
      body = await res.json().catch(() => ({}));
    } catch { return; }   // network blip — keep polling
    if (res.ok && body.pending) return;
    clearInterval(_plexPoll); _plexPoll = null;
    if (_plexPopup && !_plexPopup.closed) _plexPopup.close();
    if (!res.ok) { showAuth(body.detail || 'Sign-in failed'); return; }
    CURRENT_USER = body.user;
    cancelPlexSignIn(true);
    document.getElementById('authBg').classList.remove('open');
    applyRole();
    toast(`Signed in as ${CURRENT_USER.username}`, 'ok');
    if (_authResolve) { const r2 = _authResolve; _authResolve = null; r2({ user: body.user }); }
    else if (!_appStarted) startApp();
  }, 1500);
}

function cancelPlexSignIn(silent) {
  clearInterval(_plexPoll); _plexPoll = null;
  const btn = document.getElementById('plexSignInBtn');
  if (btn) { btn.disabled = false; btn.textContent = 'Sign in with Plex'; }
  const w = document.getElementById('plexWaiting');
  if (w) w.style.display = 'none';
  if (!silent && _plexPopup && !_plexPopup.closed) _plexPopup.close();
}

function applyRole() {
  document.body.classList.toggle('role-user', !isAdmin());
  const u = document.getElementById('navUser');
  u.style.display = CURRENT_USER ? '' : 'none';
  u.innerHTML = CURRENT_USER
    ? `${CURRENT_USER.thumb ? `<img class="navthumb" src="${_esc(CURRENT_USER.thumb)}" alt="">` : ''}${_esc(CURRENT_USER.username)}`
    : '';
  if (!isAdmin() && document.getElementById('pConfig').style.display !== 'none') {
    nav('home', document.querySelector('.nav .ni'));
  }
}

function openAccountModal() {
  if (!CURRENT_USER) return;
  const img = document.getElementById('accountThumb');
  img.src = CURRENT_USER.thumb || ''; img.style.display = CURRENT_USER.thumb ? '' : 'none';
  document.getElementById('accountTitle').textContent = CURRENT_USER.username;
  document.getElementById('accountEmail').textContent = CURRENT_USER.email || '';
  document.getElementById('accountRole').textContent =
    CURRENT_USER.owner ? 'Admin · Plex server owner' : (isAdmin() ? 'Admin' : 'User');
  document.getElementById('accountModal').classList.add('open');
}
function closeAccountModal() { document.getElementById('accountModal').classList.remove('open'); }

async function logout() {
  await _rawFetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
  location.reload();
}

// ── Config → Users (admin) ─────────────────────────────────────
function _esc(v) { return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function _when(ts) { return ts ? new Date(ts * 1000).toLocaleDateString() : 'never'; }

async function loadUsers() {
  const el = document.getElementById('userList');
  try {
    const d = await (await fetch('/api/users')).json();
    if (!d.users.length) { el.innerHTML = '<div style="color:var(--mut);font-size:13px">Nobody has signed in yet.</div>'; return; }
    el.innerHTML = d.users.map(u => {
      const me = CURRENT_USER && u.plex_id === CURRENT_USER.plex_id;
      const id = _esc(u.plex_id);
      const locked = u.owner || me;
      const roleCtl = u.owner
        ? '<span class="cal-badge" style="color:var(--acc)">Server owner · Admin</span>'
        : `<select class="urole" onchange="setUserRole('${id}', this.value)" ${me ? 'disabled title="You can\'t change your own role"' : ''}>
             <option value="user" ${u.role === 'user' ? 'selected' : ''}>User</option>
             <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option>
           </select>`;
      return `<div class="urow"${u.disabled ? ' style="opacity:.6"' : ''}>
        ${u.thumb ? `<img class="uthumb" src="${_esc(u.thumb)}" alt="">` : '<span class="uthumb"></span>'}
        <span class="uname">${_esc(u.username)}${me ? ' <span style="color:var(--mut);font-weight:500">(you)</span>' : ''}</span>
        <span class="umeta">${_esc(u.email)}${u.email ? ' · ' : ''}last sign-in ${_when(u.last_login_at)}${u.disabled ? ' · <b style="color:var(--red)">blocked</b>' : ''}</span>
        ${roleCtl}
        ${locked ? '' : `<button class="btn bg2" style="padding:6px 12px;font-size:12px" onclick="setUserBlocked('${id}', ${!u.disabled})">${u.disabled ? 'Unblock' : 'Block'}</button>
        <button class="btn bg2" style="padding:6px 12px;font-size:12px;color:var(--red)" onclick="forgetUser('${id}', '${_esc(u.username).replace(/'/g, "\\'")}')">Remove</button>`}
      </div>`;
    }).join('');
  } catch { el.innerHTML = '<div style="color:var(--red);font-size:13px">Could not load users</div>'; }
}

async function _patchUser(id, body, okMsg) {
  const r = await fetch(`/api/users/${encodeURIComponent(id)}`, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  });
  const d = await r.json().catch(() => ({}));
  toast(r.ok ? okMsg(d) : (d.detail || 'Could not update user'), r.ok ? 'ok' : 'er');
  loadUsers();
}
const setUserRole = (id, role) => _patchUser(id, { role }, d => `${d.username} is now ${role === 'admin' ? 'an admin' : 'a user'}`);
const setUserBlocked = (id, disabled) => _patchUser(id, { disabled }, d => disabled ? `${d.username} is blocked and signed out` : `${d.username} can sign in again`);

async function forgetUser(id, name) {
  if (!confirm(`Remove ${name}? They're signed out now, but can sign in again as a regular user while your Plex server is shared with them. Use Block to keep them out.`)) return;
  const r = await fetch(`/api/users/${encodeURIComponent(id)}`, { method: 'DELETE' });
  const d = await r.json().catch(() => ({}));
  toast(r.ok ? `Removed ${name}` : (d.detail || 'Could not remove user'), r.ok ? 'ok' : 'er');
  loadUsers();
}

// ── Init ─────────────────────────────────────────────────────
async function startApp() {
  if (_appStarted) return;
  _appStarted = true;
  await syncStubs();
  await Promise.all([
    loadHero(),
    loadRow('rowM','catalog/movie/top.json','movie'),
    loadRow('rowS','catalog/series/top.json','series'),
  ]);
  setInterval(() => { if (CURRENT_USER) syncStubs(); }, 5000);
}

(async()=>{
  const st = await checkAuth();
  if (isAdmin()) {
    _rawFetch('/api/auth/status').then(r => r.json()).then(d => {
      if (d.torbox_key_set === false) toast('Add your TorBox API key in Config → Connections to get started', 'in');
    }).catch(() => {});
  }
  startApp();
})();

// ── View All ───────────────────────────────────────────────────
// _rowCache stores items already fetched by loadRow keyed by cmPath
const _rowCache = {};

async function viewAll(title, cmPath, type) {
  // Open overlay immediately
  const ov = document.getElementById('vaOverlay');
  document.getElementById('vaTitle').textContent = title;
  document.getElementById('vaGrid').innerHTML = Array(20).fill(0).map(()=>
    `<div class="card" style="pointer-events:none">
       <div class="skel cposter"></div>
       <div class="skel cname" style="height:12px;margin-top:8px;width:80%"></div>
       <div class="skel cyear" style="height:11px;margin-top:5px;width:45%"></div>
     </div>`
  ).join('');
  ov.classList.add('open');
  ov.scrollTop = 0;

  // Fetch (or use cached) items
  let items = _rowCache[cmPath];
  if (!items) {
    try {
      const data = await cmFetch(cmPath);
      items = (data.metas || []);
      _rowCache[cmPath] = items;
    } catch(e) {
      document.getElementById('vaGrid').innerHTML =
        `<div style="color:var(--red);grid-column:1/-1;padding:20px;font-size:13px">Failed to load: ${e.message}</div>`;
      return;
    }
  }
  document.getElementById('vaGrid').innerHTML = items.map(m => card(m, type)).join('');
}

function closeViewAll() {
  document.getElementById('vaOverlay').classList.remove('open');
}

</script>

<!-- View All overlay -->
<div class="va-overlay" id="vaOverlay">
  <div class="va-inner">
    <div class="va-header">
      <button class="va-back" onclick="closeViewAll()">Back</button>
      <span class="va-title" id="vaTitle"></span>
    </div>
    <div class="va-grid" id="vaGrid"></div>
  </div>
</div>

</body>
</html>"""


@app.get("/", response_class=HTMLResponse)
async def ui():
    return HTMLResponse(UI_HTML)


# ---------------------------------------------------------------------------
# Config + test
# ---------------------------------------------------------------------------

def _settings_mod():
    from gateway import settings as _s
    return _s


@app.get("/api/config")
async def get_config():
    return {
        "plex_signin":       await asyncio.to_thread(_plex_signin_status),
        "aiostreams":        _aiostreams_status(),
        "search_source":     _client.search_source(),
        "torbox_key_set":    bool(_torbox_key_source()[1]),
        "torbox_key_source": _torbox_key_source()[1],     # "config" | "env" | ""
        "alldebrid": {
            "enabled":    bool(_settings_mod().get("alldebrid_enabled", False)),
            "key_set":    bool(_ad_api.key_source()[1]),
            "key_source": _ad_api.key_source()[1],        # "config" | "env" | ""
            "in_use":     _ad_api.enabled(),
        },
        "preferred_debrid": _settings_mod().get("preferred_debrid", "torbox"),
        "plex_url":        os.environ.get("PLEX_URL", ""),
        "fuse": {
            "mountpoint":         os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt"),
            "block_mb":           os.environ.get("FUSE_BLOCK_MB", "8"),
            "cache_blocks":       os.environ.get("FUSE_CACHE_BLOCKS", "64"),
            "prefetch_ahead":     os.environ.get("FUSE_PREFETCH_AHEAD", "4"),
            "read_timeout":       os.environ.get("FUSE_READ_TIMEOUT", "15"),
            "max_inflight":       os.environ.get("FUSE_MAX_INFLIGHT", "12"),
            "pool_connections":   os.environ.get("FUSE_POOL_CONNECTIONS", "10"),
            "pool_maxsize":       os.environ.get("FUSE_POOL_MAXSIZE", "20"),
        },
    }


_SECRET_SETTINGS = ("torbox_api_key", "alldebrid_api_key", "aiostreams_uuid",
                    "aiostreams_password", "radarr_api_key", "sonarr_api_key")


@app.get("/api/settings")
async def get_settings():
    """Settings for the UI. API keys are never sent back to the browser —
    only whether each one is set."""
    from gateway import settings as _settings
    out = _settings.get_all()
    for k in _SECRET_SETTINGS:
        out[k + "_set"] = bool(out.pop(k, ""))
    return out


class SettingsPatch(BaseModel):
    preferred_language: Optional[str] = None
    preferred_audio:    Optional[list[str]] = None
    exclude_words:      Optional[list[str]] = None
    min_4k_candidates:  Optional[int] = None
    prefer_season_packs: Optional[bool] = None
    spot_check_interval_hours:  Optional[float] = None
    spot_check_scheduled_scope: Optional[str] = None
    spot_check_verify_quality: Optional[bool] = None
    min_size_gb:        Optional[float] = None
    max_size_gb:        Optional[float] = None
    auto_episodes_enabled:          Optional[bool] = None
    auto_episodes_interval_minutes: Optional[int] = None
    auto_episodes_retry_days:       Optional[float] = None
    repair_interval_minutes:        Optional[float] = None
    plex_scan_quiet_seconds:        Optional[float] = None
    plex_scan_max_wait_seconds:     Optional[float] = None
    aiostreams_per_minute:          Optional[float] = None
    aiostreams_timeout_seconds:     Optional[float] = None
    torbox_requests_per_minute:     Optional[float] = None
    torbox_search_per_minute:       Optional[float] = None
    torbox_create_per_hour:         Optional[float] = None
    torbox_cdn_url_ttl_minutes:     Optional[float] = None
    torbox_search_cache_minutes:    Optional[float] = None
    torbox_hang_max_seconds:        Optional[float] = None
    torbox_max_candidates:          Optional[int] = None
    probe_cache_head_mb:            Optional[float] = None
    probe_cache_tail_mb:            Optional[float] = None
    probe_cache_max_mb:             Optional[float] = None
    pending_movies_enabled:         Optional[bool] = None
    pending_movies_retry_days:      Optional[float] = None
    digital_release_delay_days:     Optional[float] = None
    # AllDebrid. The API key itself is not settable here — it goes through
    # /api/alldebrid/key so it's validated against AllDebrid before saving.
    alldebrid_enabled:              Optional[bool] = None
    preferred_debrid:               Optional[str] = None
    alldebrid_requests_per_minute:  Optional[float] = None
    alldebrid_link_ttl_minutes:     Optional[float] = None
    alldebrid_uncached_negative_hours: Optional[float] = None
    alldebrid_sync_minutes:         Optional[float] = None


@app.post("/api/settings")
async def update_settings(patch: SettingsPatch):
    from gateway import settings as _settings
    data = {k: v for k, v in patch.dict().items() if v is not None}
    try:
        updated = _settings.update(data)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    logger.info("Settings updated: %s", data)
    return updated


@app.post("/api/auto-episodes/sweep-now")
async def trigger_auto_episode_sweep():
    """Manually run one auto-episode discovery sweep immediately, instead
    of waiting for the next scheduled interval. Runs even if
    auto_episodes_enabled is off, since an explicit manual trigger is a
    deliberate one-off action, not the recurring background behaviour the
    setting controls."""
    from gateway import auto_episodes as _auto_ep
    result = await _auto_ep.run_sweep(_stubs, _http, _query_episode, _yield_to_play_priority, force=True)
    logger.info("Manual auto-episode sweep: %s", result)
    return result


@app.get("/api/pending-movies")
async def list_pending_movies():
    """Movies being tracked. Anything that's already in the library is
    dropped here too, so a stale entry can never show up next to the real
    movie."""
    from gateway import pending_movies as _pending_mv
    in_library = {s.imdb_id for s in _stubs.listed() if s.media_type == MediaType.MOVIE}
    for item in _pending_mv.list_all():
        if item["imdb_id"] in in_library:
            _pending_mv.remove(item["imdb_id"])
    return {"items": _pending_mv.list_all()}


@app.delete("/api/pending-movies/{imdb_id}")
async def remove_pending_movie(imdb_id: str):
    from gateway import pending_movies as _pending_mv
    removed = _pending_mv.remove(imdb_id)
    if not removed:
        raise HTTPException(404, "Not in the pending list")
    return {"ok": True}


@app.post("/api/pending-movies/sweep-now")
async def trigger_pending_movies_sweep():
    """Manually retry every pending movie immediately, same deliberate
    one-off pattern as /api/auto-episodes/sweep-now."""
    from gateway import pending_movies as _pending_mv
    result = await _pending_mv.run_sweep(_query_movie, force=True, yield_fn=_yield_to_play_priority)
    logger.info("Manual pending-movie sweep: %s", result)
    return result


@app.get("/api/quality-unavailable")
async def list_quality_unavailable():
    """Everything spot check has confirmed 4K is unavailable for — see
    gateway/quality_unavailable.py. These are skipped by every automatic
    path (normal adds, background scan, auto-episode discovery, the
    pending-movies sweep, future spot checks) until manually cleared,
    either here or by a successful manual "Scan 4K"."""
    from gateway import quality_unavailable as _qu
    return {"items": _qu.list_all()}


@app.delete("/api/quality-unavailable/{key:path}")
async def clear_quality_unavailable(key: str):
    """Clears a 4K-unavailable mark without necessarily re-scanning right
    now — the item just becomes eligible for automatic 4K discovery
    again on whatever picks it up next (background scan, next spot
    check, etc). key is imdb_id for a movie, or imdb_id:season:episode
    for an episode — exactly what /api/quality-unavailable returns."""
    from gateway import quality_unavailable as _qu
    parts = key.split(":")
    imdb_id = parts[0]
    season  = int(parts[1]) if len(parts) > 1 else None
    episode = int(parts[2]) if len(parts) > 2 else None
    removed = _qu.unmark(imdb_id, season, episode)
    if not removed:
        raise HTTPException(404, "Not marked as 4K-unavailable")
    return {"ok": True}


@app.get("/api/wanted-seasons")
async def list_wanted_seasons():
    """Seasons registered via the Library modal's "New" button (or a
    direct season-scoped add) while they had zero aired episodes — see
    gateway/wanted_seasons.py. Picked up automatically by the
    auto-episode sweep once each one's first episode actually airs."""
    from gateway import wanted_seasons as _ws
    return {"items": _ws.list_all()}


@app.delete("/api/wanted-seasons/{imdb_id}/{season}")
async def clear_wanted_season(imdb_id: str, season: int):
    """Clears a wanted-season mark without waiting for it to air —
    just stops the auto-episode sweep from treating it as eligible."""
    from gateway import wanted_seasons as _ws
    removed = _ws.remove(imdb_id, season)
    if not removed:
        raise HTTPException(404, "Not marked as a wanted season")
    return {"ok": True}


class SeasonWatchReq(BaseModel):
    title: str
    poster: str = ""
    year: Optional[int] = None


@app.post("/api/series/{imdb_id}/season-watch")
async def enable_season_watch(imdb_id: str, req: SeasonWatchReq):
    """Enables indefinite season-watch for a show — see
    gateway/season_watch.py. Once set, the auto-episode sweep
    automatically registers whatever the next season turns out to be,
    every cycle, for as long as this stays enabled — no repeat clicks
    needed for future gaps."""
    from gateway import season_watch as _sw
    _sw.enable(imdb_id, req.title, req.poster, req.year)
    return {"ok": True, "imdb_id": imdb_id}


@app.delete("/api/series/{imdb_id}/season-watch")
async def disable_season_watch(imdb_id: str):
    """Turns off indefinite season-watch for a show."""
    from gateway import season_watch as _sw
    removed = _sw.disable(imdb_id)
    if not removed:
        raise HTTPException(404, "Season-watch not enabled for this show")
    return {"ok": True}


@app.get("/api/series/{imdb_id}/season-watch")
async def get_season_watch(imdb_id: str):
    """Whether indefinite season-watch is currently enabled for a show."""
    from gateway import season_watch as _sw
    return {"enabled": _sw.is_enabled(imdb_id)}


@app.get("/api/season-watch")
async def list_season_watch():
    """Every show with indefinite season-watch enabled."""
    from gateway import season_watch as _sw
    return {"items": _sw.list_all()}


# ---------------------------------------------------------------------------
# Backup / restore — settings + library (stub metadata)
# ---------------------------------------------------------------------------

import datetime as _dt

BACKUP_FORMAT_VERSION = 2

@app.get("/api/backup")
async def create_backup():
    """
    Returns a single JSON bundle containing current settings, library, and
    connection config (TorBox API key, Plex URL/token).

    SECURITY NOTE: the connection config block contains real secrets
    (TorBox API key, PLEX_TOKEN) in plaintext. The TorBox key is also part
    of the settings block, so restoring a backup restores it. Plex values can't be restored
    automatically into a running container — env vars are fixed at container
    start, so restore only displays them back for you to paste into
    docker-compose.yml yourself before a restart. Anyone with this file has
    full access to both services; store/share it accordingly.

    Deliberately excludes live resolve state (stream_url/headers/size) —
    a restored library comes back as fresh stubs that re-resolve on next
    play, since old CDN links would likely be expired anyway.
    """
    from gateway import settings as _settings
    bundle = {
        "format_version": BACKUP_FORMAT_VERSION,
        "created_at":     _dt.datetime.now(_dt.timezone.utc).isoformat(),
        "settings":       _settings.get_all(),
        "library":        _stubs.export_all(),
        "connection": {
            "torbox_api_key":      _torbox_key_source()[0],
            "plex_url":            os.environ.get("PLEX_URL", ""),
            "plex_token":          os.environ.get("PLEX_TOKEN", ""),
        },
    }
    filename = f"aiogateway-backup-{_dt.datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    return JSONResponse(
        content=bundle,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


class RestoreReq(BaseModel):
    bundle:  dict
    replace: bool = False   # False = merge, True = also prune what the backup lacks


@app.post("/api/restore")
async def restore_backup(req: RestoreReq):
    """
    Restore settings and/or library from a previously downloaded backup
    bundle. Settings are always applied if present (last-write-wins on
    each key). Library entries the backup has and this instance doesn't are
    imported unbound and bound to cached torrents in the background by the
    repair loop; entries already here keep their current binding and state,
    so a restore never turns working media unbound. replace additionally
    prunes entries the backup doesn't contain.
    """
    from gateway import settings as _settings
    bundle = req.bundle

    if not isinstance(bundle, dict) or "format_version" not in bundle:
        raise HTTPException(400, "Not a valid AIOGateway backup file")

    results = {"settings_restored": False, "library": None}

    settings_data = bundle.get("settings")
    if isinstance(settings_data, dict) and settings_data:
        try:
            _settings.update(settings_data)
            results["settings_restored"] = True
        except ValueError as exc:
            raise HTTPException(400, f"Invalid settings in backup: {exc}")

    library_data = bundle.get("library")
    if isinstance(library_data, list):
        import_result = await _stubs.import_all(library_data, replace=req.replace)
        results["library"] = import_result
        logger.info("Restore: %s", import_result)

    return results


@app.get("/api/test")
async def test_connection():
    return await _client.connection_test()


# ---------------------------------------------------------------------------
# Add media — movies and series (series only stubs aired episodes with streams)
# ---------------------------------------------------------------------------

import asyncio as _asyncio
from datetime import datetime, timezone as _tz

class AddReq(BaseModel):
    imdb_id:    str
    title:      str
    year:       Optional[int] = None
    media_type: str = "movie"
    season:     Optional[int] = None        # None = all seasons
    seasons:    Optional[list[int]] = None  # takes priority over `season` when set — multiple specific seasons in one call
    force_search: bool = False              # movies: search even before release (+ digital delay)
    episode:    Optional[int] = None        # None = all episodes
    poster:     Optional[str] = None


def _is_aired(released: Optional[str]) -> bool:
    """True if episode released date exists and is in the past."""
    if not released:
        return False
    try:
        dt = datetime.fromisoformat(released.replace("Z", "+00:00"))
        return dt <= datetime.now(_tz.utc)
    except Exception:
        return False


def _extract_year(value) -> Optional[int]:
    """
    Extract a clean 4-digit start year from a Cinemeta "year" or
    "releaseInfo" value, which can come back as a plain int (1994), a
    plain year string ("1994"), or — very commonly for SERIES, including
    ongoing ones — a range string like "2024-2026" or "2024-" (open-ended,
    still airing). Using such a value directly as a folder-name suffix
    previously produced folders literally named "(2024-)" instead of
    "(2024)". This always returns just the leading 4 digits, or None if
    nothing parseable is found.
    """
    if value is None:
        return None
    if isinstance(value, int):
        return value
    m = re.match(r"(\d{4})", str(value))
    return int(m.group(1)) if m else None


async def _movie_release_dt(imdb_id: str):
    """Returns the movie's Cinemeta `released` date as an aware datetime, or
    None if unknown/unparseable. Reuses the same cached Cinemeta fetch the
    calendar uses (see _cinemeta_cached), so this doesn't cost an extra
    request beyond what's already being fetched/cached elsewhere."""
    from datetime import datetime, timezone as _tz
    try:
        meta = await _cinemeta_cached("movie", imdb_id)
    except Exception as exc:
        logger.warning("Could not fetch release date for %s: %s", imdb_id, exc)
        return None
    released = meta.get("released")
    if not released:
        return None
    try:
        dt = datetime.fromisoformat(released.replace("Z", "+00:00"))
        if not dt.tzinfo:
            dt = dt.replace(tzinfo=_tz.utc)
        return dt
    except Exception:
        return None


async def _movie_searchable_at(imdb_id: str):
    """
    Returns the datetime a movie should first be searched at all — the
    Cinemeta theatrical release date plus digital_release_delay_days.
    None if the release date itself is unknown (in which case there's
    nothing to delay against, so callers should just search normally).

    This is a heuristic, not an exact digital-release check: there's no
    reliable free API for the actual digital/VOD date, which varies a lot
    by title and studio. The delay is the practical way to cut down on
    catching pre-digital cam/TS leaks before they'd normally show up on
    debrid — see the exclude_words setting for the complementary,
    per-result-filename version of this same problem.
    """
    from datetime import timedelta
    from gateway import settings as _settings
    released_dt = await _movie_release_dt(imdb_id)
    if not released_dt:
        return None
    delay_days = _settings.get("digital_release_delay_days", 0) or 0
    return released_dt + timedelta(days=delay_days) if delay_days else released_dt


async def _add_movie(req: AddReq) -> dict:
    # Don't even search yet if the movie hasn't reached its (theatrical +
    # digital delay) searchable date — anything that shows up this early
    # is essentially always a low-quality cam/TS/screener leak (see the
    # exclude_words setting), not a real encode. Skip the TorBox query
    # entirely and just track it as pending — same "keep checking
    # automatically" flow as a movie that's past that date but genuinely
    # has nothing available yet.
    from datetime import datetime, timezone as _tz
    searchable_at = await _movie_searchable_at(req.imdb_id)
    if searchable_at and searchable_at > datetime.now(_tz.utc) and not req.force_search:
        from gateway import pending_movies as _pending_mv
        await _pending_mv.add(req.imdb_id, req.title, req.year, req.poster or "")
        return {
            "media_id": req.imdb_id, "title": req.title, "media_type": "movie",
            "pending": True, "not_released_yet": True, "searched": False,
            "streams_found": 0, "has_4k": False,
            "episodes_with_streams": 0, "episodes_no_streams": 0,
            "episodes_future": 0, "episodes_skipped": 0,
            "stubs_created": [],
        }

    item = MediaItem(
        id=req.imdb_id, imdb_id=req.imdb_id, title=req.title,
        year=req.year, media_type=MediaType.MOVIE,
    )
    item._poster = req.poster or ""
    unreleased = bool(searchable_at and searchable_at > datetime.now(_tz.utc))
    # A forced search skips the cached "nothing found" result so a manual
    # "Search anyway" always asks AIOStreams/TorBox again.
    item.streams = await _client.resolve_all(item, fresh=req.force_search)
    if not item.streams:
        # Not resolvable right now — most commonly nothing's cached at the
        # debrid backend yet (release date already checked above). Track it
        # instead of failing outright: the pending-movies sweep (gateway/
        # pending_movies.py) retries it automatically on the same schedule
        # as the auto-episode sweep until a stream shows up, the same
        # "keep checking" philosophy already used for not-yet-aired
        # episodes.
        from gateway import pending_movies as _pending_mv
        await _pending_mv.add(req.imdb_id, req.title, req.year, req.poster or "")
        return {
            "media_id": item.id, "title": item.title, "media_type": "movie",
            "pending": True, "searched": True, "not_released_yet": unreleased,
            "streams_found": 0, "has_4k": False,
            "episodes_with_streams": 0, "episodes_no_streams": 0,
            "episodes_future": 0, "episodes_skipped": 0,
            "stubs_created": [],
        }
    stubs = await _stubs.create_stubs(item)
    if not stubs:
        # Search found releases but none could be bound to a cached torrent
        # right now — track it exactly like "nothing found yet".
        from gateway import pending_movies as _pending_mv
        await _pending_mv.add(req.imdb_id, req.title, req.year, req.poster or "")
        return {
            "media_id": item.id, "title": item.title, "media_type": "movie",
            "pending": True, "searched": True, "not_released_yet": unreleased,
            "streams_found": len(item.streams), "has_4k": False,
            "episodes_with_streams": 0, "episodes_no_streams": 0,
            "episodes_future": 0, "episodes_skipped": 0,
            "stubs_created": [],
        }
    from gateway import pending_movies as _pending_mv
    _pending_mv.remove(req.imdb_id)     # it's in the library now — stop tracking it
    return {
        "media_id": item.id, "title": item.title, "media_type": "movie",
        "pending": False,
        "streams_found": len(item.streams), "has_4k": any(s.quality == Quality.UHD for s in stubs),
        "episodes_with_streams": 0, "episodes_no_streams": 0,
        "episodes_future": 0, "episodes_skipped": 0,
        "stubs_created": [{"stub_id": s.stub_id, "quality": s.quality.value, "path": s.abs_path} for s in stubs],
    }


async def _query_movie(imdb_id: str, title: str, year, poster: str) -> bool:
    """Used by the pending-movies sweep to retry one tracked movie. Returns
    True if it now has a stub (streams were found), False otherwise."""
    from datetime import datetime, timezone as _tz
    searchable_at = await _movie_searchable_at(imdb_id)
    if searchable_at and searchable_at > datetime.now(_tz.utc):
        return False   # still inside the theatrical/digital delay window — don't waste a query, stays pending

    item = MediaItem(id=imdb_id, imdb_id=imdb_id, title=title, year=year, media_type=MediaType.MOVIE)
    item._poster = poster or ""
    try:
        item.streams = await _client.resolve_all(item)
    except Exception as exc:
        logger.warning("Pending movie resolve failed for %s: %s", imdb_id, exc)
        return False
    if not item.streams:
        return False
    return bool(await _stubs.create_stubs(item))


# Active background scans: imdb_id → asyncio.Task
_bg_scans: dict = {}

# ---------------------------------------------------------------------------
# Play priority: pause every background scan for the exact duration a
# Plex-triggered stub resolve is in flight, then let them resume — not a
# fixed courtesy sleep, a real pause-and-wait.
# ---------------------------------------------------------------------------
# Previously this was a single bool flag, set for the ENTIRE webhook
# handling call (including stop/pause events and the "already resolved"
# fast path that don't need any pause at all), and background loops only
# reacted to it with one fixed 1.5s sleep — which meant a scan could still
# be mid-query when Plex's playback request needed the exact same
# TorBox budget, and after the sleep the scan just carried on
# regardless of whether the real resolve had actually finished.
#
# This is a proper readers-writers pattern instead: a play-triggered
# resolve calls _play_priority_enter()/_exit() (via webhook/handler.py,
# scoped to just the _resolve() call, not the whole webhook), and every
# background loop (series scans, auto-episode discovery, pending-movie
# retries, migration, spot check) calls _yield_to_play_priority() before
# each per-item TorBox query — which now genuinely blocks until the
# resolve is done, not just once, and resumes immediately after rather
# than on a fixed timer. A counter (not a bool) handles the case where
# more than one play event resolves at once.
_play_priority_count = 0
_play_priority_clear = _asyncio.Event()
_play_priority_clear.set()   # nothing in flight yet — scans may proceed


def _play_priority_enter() -> None:
    global _play_priority_count
    _play_priority_count += 1
    _play_priority_clear.clear()


def _play_priority_exit() -> None:
    global _play_priority_count
    _play_priority_count = max(0, _play_priority_count - 1)
    if _play_priority_count == 0:
        _play_priority_clear.set()


async def _yield_to_play_priority():
    """Called by every background loop before each TorBox query. Blocks
    here — for as long as it takes, not a fixed sleep — while a
    play-triggered resolve is in flight, then returns immediately once
    it's done."""
    await _play_priority_clear.wait()


async def _query_episode(
    imdb_id: str, show_title: str, year, poster: str,
    v: dict, sem: "_asyncio.Semaphore"
) -> tuple:
    """
    Query TorBox for one episode. Returns (stubbed, has_4k, pack_info).

    pack_info is (pack_kind, pack_season) — detect_pack_type() run on
    whichever stream actually got used for the HD stub — ('episode', None)
    if not stubbed, or if the winning stream isn't pack-derived at all.
    Callers use this to fast-track the rest of a season when a pack shows
    up — see _fast_track_pack_season.
    """
    s_num = v.get("season")
    e_num = v.get("number")
    if s_num is None or e_num is None:
        return False, False, ('episode', None)

    async with sem:
        item = MediaItem(
            id=f"{imdb_id}_s{s_num}e{e_num}", imdb_id=imdb_id,
            title=show_title, show_title=show_title, episode_title="",
            year=year, media_type=MediaType.SERIES,
            season=s_num, episode=e_num,
        )
        streams = []
        for attempt in range(1, 5):
            try:
                streams = await _client.resolve_all(item)
                break
            except Exception as exc:
                exc_str = str(exc)
                is_429  = "429" in exc_str
                if attempt < 4:
                    wait = (attempt * 5) if is_429 else (attempt * 2)
                    logger.warning(
                        "S%02dE%02d attempt %d/4 — %s — retrying in %ds",
                        s_num, e_num, attempt,
                        "rate limited (429)" if is_429 else exc_str[:60], wait
                    )
                    await _asyncio.sleep(wait)
                else:
                    logger.warning("S%02dE%02d all 4 attempts failed", s_num, e_num)
                    return False, False, ('episode', None)

        if not streams:
            return False, False, ('episode', None)

        item.streams = streams
        item._poster = poster
        stubs = await _stubs.create_stubs(item)
        if not stubs:
            return False, False, ('episode', None)
        has_4k = any(st.quality == Quality.UHD for st in stubs)
        logger.info("S%02dE%02d: added%s", s_num, e_num, " +4K" if has_4k else "")

        # Pack detection now looks at the TORRENT the file was bound from
        # (its name), not the episode file — that's what tells us the rest
        # of the season is sitting in the same cached torrent.
        from gateway.models import detect_pack_type
        from gateway.torbox_client import ref_hash
        from gateway import torbox_guard as _tbg
        bound = next((st for st in stubs if st.quality == Quality.HD), stubs[0])
        rec = _tbg.store().get_torrent(ref_hash(bound.stream_url) or "")
        pack_info = detect_pack_type(rec["name"]) if rec and rec.get("name") else ('episode', None)

        return True, has_4k, pack_info


async def _fast_track_pack_season(
    imdb_id: str, show_title: str, year, poster: str,
    season: int, videos: list, already_stubbed: set
) -> set:
    """
    Called when an episode resolves via a season/series pack — since a
    pack, once debrid-cached, usually resolves the rest of its season
    quickly too (same underlying cached torrent, not a fresh scrape), this
    immediately tries every other aired-but-unstubbed episode in that
    season right away, instead of waiting through the slower multi-pass
    background scan built for genuinely hard-to-find content.

    This does NOT skip any TorBox queries or guess at a pack's
    contents — every episode here is still resolved through the exact
    same safe per-episode query (imdb_id:season:episode) as always, so
    there's no risk of mislabeling an episode. "Verifying the pack" means
    checking, after each of those normal queries resolves, whether the
    winning stream is ALSO detected as part of the same season/series
    pack — confirming it's genuinely from the pack rather than just
    coincidentally available. Episodes that resolve via some other,
    non-pack source are still stubbed (a real stream is a real stream),
    just not counted as pack-confirmed.

    Every request still goes through the same global TorBox rate gate
    as everything else — this doesn't bypass that, it just skips the
    EXTRA local courtesy pacing/multi-pass retry structure _scan_series_bg
    normally adds on top, since a debrid-cached pack is expected to
    resolve quickly and doesn't need that same patience.

    Returns the set of (season, episode) keys stubbed here, so the caller
    can exclude them from any further processing.
    """
    targets = [
        v for v in videos
        if v.get("season") == season and v.get("number") is not None
        and _is_aired(v.get("released"))
        and (season, v.get("number")) not in already_stubbed
    ]
    if not targets:
        return set()

    logger.info(
        "Season %d of %s: pack detected — fast-tracking %d remaining episode(s)",
        season, imdb_id, len(targets)
    )

    sem = _asyncio.Semaphore(1)
    stubbed_keys = set()
    pack_confirmed = 0

    for v in targets:
        await _yield_to_play_priority()
        try:
            stubbed, _, pack_info = await _query_episode(imdb_id, show_title, year, poster, v, sem)
        except Exception as exc:
            logger.warning("Pack fast-track: S%02dE%02d failed: %s",
                          season, v.get("number"), exc)
            continue
        if stubbed:
            ep_num = v.get("number")
            stubbed_keys.add((season, ep_num))
            pack_kind, pack_season = pack_info
            if pack_kind in ("season", "series") and (pack_kind == "series" or pack_season == season):
                pack_confirmed += 1

    logger.info(
        "Season %d of %s: fast-track complete — %d/%d stubbed (%d confirmed from the pack)",
        season, imdb_id, len(stubbed_keys), len(targets), pack_confirmed
    )
    return stubbed_keys


async def _scan_series_bg(
    imdb_id: str, show_title: str, year, poster: str,
    candidates: list, skip_keys: set, known_pack_season: Optional[int] = None
) -> None:
    """
    Background task — sequential scan with 1s delay, repeated up to 3 passes
    until no new episodes are found. Each pass only retries episodes that
    previously returned no streams, ensuring all cached episodes are captured
    even when TorBox is inconsistent.

    known_pack_season: if the fast-path E01 query (in _add_series) already
    came back as a season/series pack, its season number is passed in here
    so the fast-track kicks in immediately, before pass 1 even starts,
    rather than waiting to organically rediscover the pack on whichever
    episode happens to run first in the normal loop.
    """
    # Track which episodes already have stubs
    def _already_stubbed(v: dict) -> bool:
        s = v.get("season"); e = v.get("number")
        return (s, e) in skip_keys or any(
            st.imdb_id == imdb_id and
            st.aiostreams_id == f"{imdb_id}:{s}:{e}"
            for st in _stubs.all()
        )

    remaining = [v for v in candidates if not _already_stubbed(v)]
    if not remaining:
        logger.info("BG scan %s: nothing to do", imdb_id)
        _bg_scans.pop(imdb_id, None)
        return

    logger.info("BG scan %s: %d episodes to check", imdb_id, len(remaining))
    sem        = _asyncio.Semaphore(1)
    total_found = 0
    pack_fast_tracked_seasons: set = set()   # avoid re-triggering fast-track for the same season twice

    if known_pack_season is not None:
        pack_fast_tracked_seasons.add(known_pack_season)
        already = set(skip_keys) | {
            (st.season, st.episode) for st in _stubs.all()
            if st.imdb_id == imdb_id and st.season is not None
        }
        fast_keys = await _fast_track_pack_season(
            imdb_id, show_title, year, poster, known_pack_season, candidates, already
        )
        total_found += len(fast_keys)
        remaining = [v for v in remaining if (v.get("season"), v.get("number")) not in fast_keys]
        if not remaining:
            logger.info("BG scan %s complete: %d total episodes stubbed (all via pack fast-track)",
                       imdb_id, total_found)
            _bg_scans.pop(imdb_id, None)
            return

    for pass_num in range(1, 4):   # up to 3 passes
        no_stream_this_pass = []
        found_this_pass     = 0
        skip_in_this_pass: set = set()   # (season, episode) keys handled mid-pass via fast-track

        logger.info("BG scan %s pass %d/%d: checking %d episodes",
                    imdb_id, pass_num, 3, len(remaining))

        for v in remaining:
            key = (v.get("season"), v.get("number"))
            if key in skip_in_this_pass:
                continue

            await _yield_to_play_priority()
            try:
                stubbed, _, pack_info = await _query_episode(
                    imdb_id, show_title, year, poster, v, sem
                )
                if stubbed:
                    found_this_pass += 1
                    total_found     += 1

                    pack_kind, _pack_season = pack_info
                    season = v.get("season")
                    if pack_kind in ("season", "series") and season not in pack_fast_tracked_seasons:
                        pack_fast_tracked_seasons.add(season)
                        already = {key} | {
                            (st.season, st.episode) for st in _stubs.all()
                            if st.imdb_id == imdb_id and st.season is not None
                        }
                        fast_keys = await _fast_track_pack_season(
                            imdb_id, show_title, year, poster, season, candidates, already
                        )
                        for fk in fast_keys:
                            skip_in_this_pass.add(fk)
                        found_this_pass += len(fast_keys)
                        total_found     += len(fast_keys)
                else:
                    no_stream_this_pass.append(v)
            except Exception as exc:
                logger.warning("BG scan episode error: %s", exc)
                no_stream_this_pass.append(v)
            await _asyncio.sleep(1.0)   # 1s between each query

        # Anything the mid-pass fast-track already picked up shouldn't be
        # retried again in the next pass.
        no_stream_this_pass = [
            v for v in no_stream_this_pass
            if (v.get("season"), v.get("number")) not in skip_in_this_pass
        ]

        logger.info("BG scan %s pass %d done: %d new stubs, %d still missing",
                    imdb_id, pass_num, found_this_pass, len(no_stream_this_pass))

        if not no_stream_this_pass:
            break   # everything found — no need for another pass

        remaining = no_stream_this_pass

        if pass_num < 3:
            # Wait a bit longer before the next pass
            wait = pass_num * 5
            logger.info("BG scan %s: waiting %ds before pass %d",
                        imdb_id, wait, pass_num + 1)
            await _asyncio.sleep(wait)

    if remaining:
        logger.info("BG scan %s: %d episode(s) had no streams after 3 passes: %s",
                    imdb_id, len(remaining),
                    [f"S{v.get('season'):02d}E{v.get('number'):02d}" for v in remaining])

    logger.info("BG scan %s complete: %d total episodes stubbed", imdb_id, total_found)
    _bg_scans.pop(imdb_id, None)


async def _add_series(req: AddReq) -> dict:
    """
    Fast path: query E01 immediately, return as soon as stub is created.
    Background task scans all remaining episodes concurrently.
    """
    try:
        async with _http.get(
            f"https://v3-cinemeta.strem.io/meta/series/{req.imdb_id}.json",
            headers={"User-Agent": "AIOGateway/0.3"},
            timeout=aiohttp.ClientTimeout(total=20),
        ) as resp:
            data = await resp.json(content_type=None)
    except Exception as exc:
        raise HTTPException(502, f"Cinemeta fetch failed: {exc}")

    meta   = data.get("meta") or {}
    videos = meta.get("videos") or []
    if not videos:
        raise HTTPException(404, f"No episode data found for {req.imdb_id}")

    poster     = req.poster or meta.get("poster") or ""
    show_title = req.title

    # Always resolve a year server-side rather than trusting the request to
    # supply one consistently. A missing/None year produces a folder name
    # with no "(Year)" suffix — and since the same show gets re-added via
    # several different UI flows (initial add, rescan, per-season request),
    # any one of them omitting the year fragments the show into two
    # differently-named folders for the same series.
    year = req.year
    if not year:
        # Cinemeta's meta endpoint returns "year" directly; releaseInfo is
        # a fallback for older/alternate response shapes. Both can be range
        # strings ("2024-2026" or open-ended "2024-") — _extract_year always
        # pulls just the leading 4 digits.
        year = _extract_year(meta.get("year")) or _extract_year(meta.get("releaseInfo"))
        if year:
            logger.info("Series %s: request had no year, using Cinemeta's %s",
                       req.imdb_id, year)

    if not year:
        # Cinemeta gave nothing usable — fall back to any existing stub for
        # this same show, so a rescan/season-request never accidentally
        # creates a second, differently-named folder just because this one
        # response happened to omit year data.
        existing = next((s for s in _stubs.all() if s.imdb_id == req.imdb_id and s.year), None)
        if existing:
            year = existing.year
            logger.info("Series %s: Cinemeta had no year, reusing %s from existing stub",
                       req.imdb_id, year)

    if not year:
        raise HTTPException(
            502,
            f"Could not determine release year for {req.imdb_id} — refusing to create "
            "stubs that would land in a differently-named folder than the rest of this "
            "show. Try again shortly."
        )

    aired_all  = [v for v in videos if _is_aired(v.get("released"))]
    future_cnt = len(videos) - len(aired_all)

    candidates = aired_all
    if req.seasons is not None:
        wanted_seasons = set(req.seasons)
        candidates = [v for v in candidates if v.get("season") in wanted_seasons]
    elif req.season is not None:
        candidates = [v for v in candidates if v.get("season") == req.season]
    if req.episode is not None:
        candidates = [v for v in candidates if v.get("number") == req.episode]

    if not candidates:
        # If this was a request for one specific season (not the whole
        # show, not a specific episode), register it as "wanted" so the
        # recurring auto-episode sweep picks it up automatically once its
        # first episode actually airs — instead of just failing here and
        # forgetting the request entirely, which is what happened before
        # this existed. Works whether Cinemeta already lists the season
        # with zero aired episodes (announced, dated), OR has literally
        # nothing for it at all yet (renewed but not yet scheduled — the
        # sweep re-fetches Cinemeta fresh every cycle, so it'll notice
        # the moment real episode data shows up either way). A specific-
        # episode request, or a whole-show request with genuinely nothing
        # aired anywhere, still just fails — there's no single season to
        # register in those cases.
        if req.season is not None and req.episode is None and req.seasons is None:
            season_videos = [v for v in videos if v.get("season") == req.season]
            from gateway import wanted_seasons as _ws
            _ws.add(req.imdb_id, req.season, show_title, poster, year)
            return {
                "media_id": req.imdb_id, "title": show_title, "media_type": "series",
                "wanted": True, "season": req.season,
                "streams_found": 0, "has_4k": False,
                "episodes_with_streams": 0, "episodes_no_streams": 0,
                "episodes_future": len(season_videos), "episodes_skipped": 0,
                "stubs_created": [],
            }
        raise HTTPException(404, f"No aired episodes found. {future_cnt} not yet released.")

    # Sort so E01 of lowest season is first
    candidates.sort(key=lambda v: (v.get("season") or 0, v.get("number") or 0))

    logger.info("Series %s '%s': fast E01 + bg scan %d eps",
                req.imdb_id, show_title, len(candidates))

    # Query first episode immediately
    sem_one = _asyncio.Semaphore(1)
    stubbed, has_4k, pack_info = await _query_episode(
        req.imdb_id, show_title, year, poster, candidates[0], sem_one
    )
    fast_key = (candidates[0].get("season"), candidates[0].get("number"))

    # Only skip E01 in the background scan if it was actually stubbed
    skip_keys = {fast_key} if stubbed else set()

    # If E01 came back as a season/series pack, seed the background scan
    # with that so it fast-tracks the rest of the season immediately
    # instead of waiting to organically rediscover the pack later.
    pack_kind, _pack_season = pack_info
    known_pack_season = fast_key[0] if (stubbed and pack_kind in ("season", "series")) else None

    # Cancel any existing scan and start a new one for all remaining episodes
    if req.imdb_id in _bg_scans:
        _bg_scans[req.imdb_id].cancel()
    task = _asyncio.create_task(
        _scan_series_bg(req.imdb_id, show_title, year, poster, candidates, skip_keys, known_pack_season)
    )
    _bg_scans[req.imdb_id] = task

    return {
        "media_id":    req.imdb_id,
        "title":       req.title,
        "media_type":  "series",
        "streams_found": 1 if stubbed else 0,
        "has_4k":      has_4k,
        "scanning":    True,
        "total_candidates": len(candidates),
        "stubs_created": [],
    }


@app.post("/api/add")
async def add_media(req: AddReq):
    try:
        if req.media_type == "movie":
            return await _add_movie(req)
        else:
            return await _add_series(req)
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Add failed: %s", exc)
        raise HTTPException(502, str(exc))

# ---------------------------------------------------------------------------
# Migrate (Radarr/Sonarr)
# ---------------------------------------------------------------------------

from gateway import migrate_client as _migrate

_migrate_jobs: dict[str, dict] = {}          # job_id → progress state, see start_migration()
_migrate_tasks: dict[str, "asyncio.Task"] = {}   # job_id → the running task, so cancel can actually interrupt it

# One Radarr/Sonarr library snapshot per service, shared between "Load
# library" (preview) and "Start migration" (run) so a migration only ever
# costs Radarr/Sonarr a single /api/v3/movie or /api/v3/series call — not
# one for the preview and another when the run kicks off, which is what
# was happening before this cache existed. Cleared once the migration job
# that used it finishes, so the next "Load library" click always gets a
# fresh read rather than serving stale data indefinitely.
_migrate_cache: dict[str, list[dict]] = {}
_MIGRATE_CACHE_MAX_AGE = 3600   # safety net: don't serve a snapshot older than this even mid-session
_migrate_cache_fetched_at: dict[str, float] = {}


async def _get_migrate_items(service: str, url: str, key: str) -> list[dict]:
    """Returns this service's movie/series list, fetching from Radarr/Sonarr
    only if nothing cached (or the cache is stale). Callers get their own
    deep copy so annotating it (e.g. in_library flags) never corrupts the
    shared cache for the next caller."""
    cached = _migrate_cache.get(service)
    fetched_at = _migrate_cache_fetched_at.get(service, 0)
    if cached is not None and (time.time() - fetched_at) < _MIGRATE_CACHE_MAX_AGE:
        return copy.deepcopy(cached)

    if service == "radarr":
        items = await _migrate.fetch_radarr_movies(url, key)
    else:
        items = await _migrate.fetch_sonarr_series(url, key)

    _migrate_cache[service] = items
    _migrate_cache_fetched_at[service] = time.time()
    return copy.deepcopy(items)


def _clear_migrate_cache(service: str) -> None:
    _migrate_cache.pop(service, None)
    _migrate_cache_fetched_at.pop(service, None)


def _migrate_service_settings(service: str) -> tuple[str, str]:
    from gateway import settings as _settings
    s = _settings.get_all()
    return s.get(f"{service}_url", ""), s.get(f"{service}_api_key", "")


class MigrateSettingsReq(BaseModel):
    service: str                       # "radarr" | "sonarr"
    url:     str
    api_key: Optional[str] = None      # omitted/blank keeps whatever key is already saved


@app.get("/api/migrate/settings")
async def get_migrate_settings():
    from gateway import settings as _settings
    s = _settings.get_all()
    return {
        "radarr_url":        s.get("radarr_url", ""),
        "radarr_configured": bool(s.get("radarr_api_key")),
        "sonarr_url":        s.get("sonarr_url", ""),
        "sonarr_configured": bool(s.get("sonarr_api_key")),
    }


@app.post("/api/migrate/settings")
async def save_migrate_settings(req: MigrateSettingsReq):
    from gateway import settings as _settings
    if req.service not in ("radarr", "sonarr"):
        raise HTTPException(400, "service must be 'radarr' or 'sonarr'")
    patch = {f"{req.service}_url": req.url}
    if req.api_key:
        patch[f"{req.service}_api_key"] = req.api_key
    try:
        _settings.update(patch)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    _clear_migrate_cache(req.service)
    return {"ok": True}


class MigrateTestReq(BaseModel):
    service: str


@app.post("/api/migrate/test")
async def test_migrate_connection(req: MigrateTestReq):
    if req.service not in ("radarr", "sonarr"):
        raise HTTPException(400, "service must be 'radarr' or 'sonarr'")
    url, key = _migrate_service_settings(req.service)
    if not url or not key:
        raise HTTPException(400, f"Set the {req.service.title()} URL and API key first")
    try:
        return await _migrate.test_connection(url, key, req.service)
    except _migrate.MigrateAPIError as exc:
        raise HTTPException(502, str(exc))


@app.get("/api/migrate/preview")
async def preview_migrate(service: str):
    if service not in ("radarr", "sonarr"):
        raise HTTPException(400, "service must be 'radarr' or 'sonarr'")
    url, key = _migrate_service_settings(service)
    if not url or not key:
        raise HTTPException(400, f"Set the {service.title()} URL and API key first")

    try:
        items = await _get_migrate_items(service, url, key)
        if service == "radarr":
            have = {s.imdb_id for s in _stubs.all() if s.media_type == MediaType.MOVIE}
            for it in items:
                it["in_library"] = it["imdb_id"] in have
        else:
            have_seasons: dict[str, set] = {}
            for s in _stubs.all():
                if s.media_type == MediaType.SERIES and s.season is not None:
                    have_seasons.setdefault(s.imdb_id, set()).add(s.season)
            for it in items:
                already = have_seasons.get(it["imdb_id"], set())
                for season in it["seasons"]:
                    season["in_library"] = season["season_number"] in already
                it["in_library"] = all(sn["in_library"] for sn in it["seasons"])
    except _migrate.MigrateAPIError as exc:
        raise HTTPException(502, str(exc))

    return {"service": service, "items": items}


class MigrateRunReq(BaseModel):
    service:       str
    imdb_ids:      Optional[list[str]] = None   # None = migrate everything found
    skip_existing: bool = True


_MIGRATE_CONCURRENCY = 3   # TorBox requests allowed in flight at once during migration


async def _add_with_429_retry(kind: str, req: "AddReq", job: dict, label: str):
    """
    Bulk migration fires far more TorBox requests than the normal
    one-at-a-time "Add to Plex" click ever does, so it's much more likely
    to outrun TorBox's rate limit — as seen in practice, a large
    library migration can 429 on nearly every item. Retry a 429 a few
    times with real backoff before giving up on that item; anything else
    (404/no results, etc.) is passed straight through to the caller —
    see _add_with_retry, which handles that case separately.
    """
    for attempt, wait in enumerate((0, 5, 15, 30, 60)):
        if wait:
            job["errors_transient"] = job.get("errors_transient", 0) + 1
            logger.warning("[migrate] %s: rate limited, retrying in %ds (attempt %d/5)",
                           label, wait, attempt + 1)
            await asyncio.sleep(wait)
        try:
            if kind == "movie":
                return await _add_movie(req)
            return await _add_series(req)
        except Exception as exc:
            is_429 = "429" in str(exc) or "Too Many Requests" in str(exc)
            if not is_429 or attempt == 4:
                raise



async def _run_migration(job_id: str, service: str, imdb_ids: Optional[list], skip_existing: bool):
    job = _migrate_jobs[job_id]
    try:
        url, key = _migrate_service_settings(service)
        try:
            items = await _get_migrate_items(service, url, key)
        except _migrate.MigrateAPIError as exc:
            job["status"] = "error"
            job["errors"].append(str(exc))
            return

        if imdb_ids is not None:
            wanted = set(imdb_ids)
            items = [it for it in items if it["imdb_id"] in wanted]

        have_movie = {s.imdb_id for s in _stubs.all() if s.media_type == MediaType.MOVIE}
        have_seasons: dict[str, set] = {}
        for s in _stubs.all():
            if s.media_type == MediaType.SERIES and s.season is not None:
                have_seasons.setdefault(s.imdb_id, set()).add(s.season)

        # ONE work item per movie, and — importantly — ONE work item per
        # series covering every season Sonarr has that isn't already
        # stubbed, not one item per season. _add_series only synchronously
        # resolves the first episode of the earliest requested season and
        # hands the rest to a background scan; batching every wanted
        # season into a single call means one fast resolve gets the whole
        # show moving, instead of the previous approach of calling
        # _add_series once per season and having to block for up to 15
        # minutes between each so the next season's call didn't cancel the
        # previous one's still-running background scan (_bg_scans is keyed
        # per imdb_id — two overlapping calls for the SAME show step on
        # each other, but one call already covering every season sidesteps
        # that entirely).
        work = []
        if service == "radarr":
            for it in items:
                if skip_existing and it["imdb_id"] in have_movie:
                    continue
                work.append(("movie", it, None))
        else:
            for it in items:
                already = have_seasons.get(it["imdb_id"], set())
                wanted_seasons = [
                    s2["season_number"] for s2 in it["seasons"]
                    if not (skip_existing and s2["season_number"] in already)
                ]
                if wanted_seasons:
                    work.append(("series", it, wanted_seasons))

        job["total"]  = len(work)
        job["status"] = "running"

        # Bounded concurrency instead of one item at a time with a fixed
        # delay between each — the 429 retry above already backs off
        # reactively when TorBox actually asks us to slow down, so a
        # small worker pool gets real throughput on the common case
        # (no rate limiting) while still recovering cleanly on the
        # uncommon case (it does get rate limited).
        sem = asyncio.Semaphore(_MIGRATE_CONCURRENCY)
        in_flight: dict[int, str] = {}

        def _update_current_title():
            job["current_title"] = " · ".join(in_flight.values()) if in_flight else ""

        async def _run_one(idx: int, kind: str, it: dict, seasons_or_none):
            label = (
                it["title"] if kind == "movie"
                else f"{it['title']} ({len(seasons_or_none)} season{'s' if len(seasons_or_none) != 1 else ''})"
            )
            async with sem:
                in_flight[idx] = label
                _update_current_title()
                await _yield_to_play_priority()
                try:
                    req = AddReq(
                        imdb_id=it["imdb_id"], title=it["title"], year=it.get("year"),
                        media_type=kind, poster=it.get("poster"),
                        seasons=seasons_or_none if kind == "series" else None,
                    )
                    result = await _add_with_429_retry(kind, req, job, label)
                    if isinstance(result, dict) and result.get("pending"):
                        # Not resolvable right now (commonly not released
                        # yet) — _add_movie already queued it in the
                        # pending-movies tracker rather than failing, so
                        # this isn't an error, just worth surfacing as
                        # informational.
                        job["pending_count"] = job.get("pending_count", 0) + 1
                except HTTPException as exc:
                    job["errors"].append(f"{label}: {exc.detail}")
                except Exception as exc:
                    job["errors"].append(f"{label}: {exc}")
                finally:
                    in_flight.pop(idx, None)
                    _update_current_title()
                    job["done"] += 1

        await asyncio.gather(*[
            _run_one(idx, kind, it, seasons_or_none)
            for idx, (kind, it, seasons_or_none) in enumerate(work)
        ])

        if job["status"] == "running":
            job["status"] = "done"
    except asyncio.CancelledError:
        # Task.cancel() (see cancel_migration below) raises this inside
        # whatever await was actually in flight at the moment — e.g. mid
        # TorBox request — which is what makes Cancel stop immediately
        # instead of only taking effect once the current item finishes.
        # Cancelling the task that's awaiting asyncio.gather() propagates
        # into every in-flight _run_one() call too, so nothing keeps
        # running in the background after cancel.
        job["status"] = "cancelled"
    finally:
        job["finished"]      = True
        job["current_title"] = ""
        _migrate_tasks.pop(job_id, None)
        _clear_migrate_cache(service)


@app.post("/api/migrate/run")
async def start_migration(req: MigrateRunReq):
    if req.service not in ("radarr", "sonarr"):
        raise HTTPException(400, "service must be 'radarr' or 'sonarr'")
    url, key = _migrate_service_settings(req.service)
    if not url or not key:
        raise HTTPException(400, f"Set the {req.service.title()} URL and API key first")

    job_id = uuid.uuid4().hex[:12]
    _migrate_jobs[job_id] = {
        "job_id": job_id, "service": req.service,
        "total": 0, "done": 0, "current_title": "",
        "status": "starting", "finished": False,
        "cancel_requested": False, "errors": [],
    }
    task = asyncio.create_task(_run_migration(job_id, req.service, req.imdb_ids, req.skip_existing))
    _migrate_tasks[job_id] = task
    return {"job_id": job_id}


@app.get("/api/migrate/status/{job_id}")
async def migrate_status(job_id: str):
    job = _migrate_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    return job


@app.post("/api/migrate/cancel/{job_id}")
async def cancel_migration(job_id: str):
    job = _migrate_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    job["cancel_requested"] = True
    task = _migrate_tasks.get(job_id)
    if task and not task.done():
        task.cancel()   # interrupts the in-flight await immediately, see _run_migration
    return {"ok": True}


# ---------------------------------------------------------------------------
# Stubs
# ---------------------------------------------------------------------------

@app.get("/api/scan/{imdb_id}")
async def scan_status(imdb_id: str):
    running = imdb_id in _bg_scans and not _bg_scans[imdb_id].done()
    count   = sum(1 for s in _stubs.all() if s.imdb_id == imdb_id)
    return {"imdb_id": imdb_id, "scanning": running, "stubs": count}


@app.get("/api/series/{imdb_id}/episodes")
async def series_episodes(imdb_id: str):
    """Full aired episode list from Cinemeta with stub status."""
    import re as _re
    try:
        async with _http.get(
            f"https://v3-cinemeta.strem.io/meta/series/{imdb_id}.json",
            headers={"User-Agent": "AIOGateway/0.3"},
            timeout=aiohttp.ClientTimeout(total=15),
        ) as resp:
            data = await resp.json(content_type=None)
    except Exception as exc:
        raise HTTPException(502, f"Cinemeta fetch failed: {exc}")

    videos = (data.get("meta") or {}).get("videos") or []

    # Build stubbed sets from aiostreams_id pattern "imdb:season:episode"
    stubbed_hd, stubbed_4k = {}, {}
    for s in _stubs.all():
        if s.imdb_id != imdb_id:
            continue
        m = _re.search(r':(\d+):(\d+)$', s.aiostreams_id)
        if m:
            key = (int(m.group(1)), int(m.group(2)))
            (stubbed_4k if s.quality == Quality.UHD else stubbed_hd)[key] = s.stub_id

    episodes = []
    for v in videos:
        sn = v.get("season"); ep = v.get("number")
        if sn is None or ep is None or sn == 0:
            continue
        key = (sn, ep)
        episodes.append({
            "season":  sn, "episode": ep,
            "name":    v.get("name") or f"S{sn:02d}E{ep:02d}",
            "aired":   _is_aired(v.get("released")),
            "has_hd":  key in stubbed_hd,
            "has_4k":  key in stubbed_4k,
            "hd_stub_id":  stubbed_hd.get(key),
            "uhd_stub_id": stubbed_4k.get(key),
        })
    return {
        "imdb_id":  imdb_id,
        "episodes": episodes,
        "scanning": imdb_id in _bg_scans and not _bg_scans[imdb_id].done(),
        # Cinemeta's series status — "Ended"/"Canceled" vs "Continuing"/
        # "In Production". Used to disable the Library modal's "New"
        # button for a show that will never air another season, rather
        # than leaving it enabled (or worse, letting it register a
        # wanted-season that can never resolve) for something already
        # confirmed over.
        "status": (data.get("meta") or {}).get("status"),
    }


@app.post("/api/series/{imdb_id}/episode/{season}/{episode}")
async def add_single_episode(imdb_id: str, season: int, episode: int, req: AddReq):
    """Search for and stub a single missing episode."""
    year = req.year
    if not year:
        # First fallback: reuse the year from any existing stub of this same
        # show, if one exists — avoids a network round-trip and is exactly
        # consistent with whatever folder name is already in use on disk.
        existing = next((s for s in _stubs.all() if s.imdb_id == imdb_id and s.year), None)
        if existing:
            year = existing.year
            logger.info("Episode S%02dE%02d (%s): reusing year %s from existing stub",
                       season, episode, imdb_id, year)

    if not year:
        # Second fallback: fetch from Cinemeta directly.
        try:
            async with _http.get(
                f"https://v3-cinemeta.strem.io/meta/series/{imdb_id}.json",
                headers={"User-Agent": "AIOGateway/0.3"},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                cm_meta = (await resp.json(content_type=None)).get("meta") or {}
            year = _extract_year(cm_meta.get("year")) or _extract_year(cm_meta.get("releaseInfo"))
            if year:
                logger.info("Episode S%02dE%02d (%s): request had no year, using Cinemeta's %s",
                           season, episode, imdb_id, year)
        except Exception as exc:
            logger.warning("Could not fetch fallback year from Cinemeta for %s: %s", imdb_id, exc)

    if not year:
        # Both fallbacks failed (network error + no existing stub to copy
        # from). Refuse rather than silently creating a year-less stub that
        # would fragment the show into a second, differently-named folder —
        # the caller can retry once Cinemeta is reachable again.
        raise HTTPException(
            502,
            f"Could not determine release year for {imdb_id} (Cinemeta unreachable and "
            "no existing stub to infer it from) — refusing to create a stub that would "
            "land in a differently-named folder. Try again shortly."
        )

    # Verify this specific episode has actually aired before ever touching
    # TorBox — every other add/scan path in the app (requestSeason,
    # the background scan, auto-episode discovery, spot check's discovery
    # phase, pack fast-track) already filters to _is_aired() episodes
    # before calling _query_episode; this endpoint was the one gap, since
    # it resolves a single specific (season, episode) directly rather than
    # iterating a pre-filtered list. A not-yet-aired episode should never
    # get a stub, full stop — anything that shows up for one this early
    # would only ever be a mismatched or bogus result, not the real thing.
    try:
        meta = await _cinemeta_cached("series", imdb_id)
        target = next(
            (v for v in (meta.get("videos") or [])
             if v.get("season") == season and v.get("number") == episode),
            None
        )
        if target is not None and not _is_aired(target.get("released")):
            raise HTTPException(
                400,
                f"S{season:02d}E{episode:02d} hasn't aired yet "
                f"({target.get('released', 'no date available')}) — refusing to search for it."
            )
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("Could not verify air date for %s S%02dE%02d, proceeding anyway: %s",
                       imdb_id, season, episode, exc)

    sem = _asyncio.Semaphore(1)
    v = {"season": season, "number": episode}
    stubbed, has_4k, pack_info = await _query_episode(
        imdb_id, req.title, year, req.poster or "", v, sem
    )
    if not stubbed:
        raise HTTPException(404, f"No streams found for S{season:02d}E{episode:02d}")

    # If this single-episode search happened to land on a season/series
    # pack, opportunistically fast-track the rest of that season in the
    # background — same reasoning as the fast-path E01 case, just
    # triggered from a manual/spot-check search instead. Doesn't block
    # this response; runs as a detached task.
    pack_kind, _pack_season = pack_info
    if pack_kind in ("season", "series"):
        try:
            meta = await _cinemeta_cached("series", imdb_id)
            videos = meta.get("videos") or []
            already = {(season, episode)} | {
                (st.season, st.episode) for st in _stubs.all()
                if st.imdb_id == imdb_id and st.season is not None
            }
            _asyncio.create_task(_fast_track_pack_season(
                imdb_id, req.title, year, req.poster or "", season, videos, already
            ))
        except Exception as exc:
            logger.warning("Could not kick off pack fast-track for %s: %s", imdb_id, exc)

    return {"stubbed": True, "has_4k": has_4k, "season": season, "episode": episode}


@app.get("/api/stubs")
async def list_stubs():
    all_s = _stubs.all()
    return {"count": len(all_s), "stubs": [
        {"stub_id": s.stub_id, "media_id": s.media_id, "title": s.title,
         "quality": s.quality.value, "state": s.state.value, "path": s.abs_path,
         "poster": getattr(s, "_poster", ""),
         "media_type": s.aiostreams_type,
         "year": s.year,
         "stream_url": (s.stream_url[:80]+"…") if s.stream_url else None}
        for s in all_s
    ]}


@app.get("/api/stubs/{stub_id}")
async def get_stub(stub_id: str):
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Not found")
    return {"stub_id": s.stub_id, "media_id": s.media_id, "title": s.title,
            "quality": s.quality.value, "state": s.state.value, "path": s.abs_path,
            "imdb_id": s.imdb_id, "aiostreams_id": s.aiostreams_id,
            "stream_url": s.stream_url, "created_at": s.created_at, "resolved_at": s.resolved_at}


# ---------------------------------------------------------------------------
# Calendar — upcoming and recent releases for tracked content
# ---------------------------------------------------------------------------


# Cinemeta cache for the calendar. Two things make this meaningfully
# faster than a plain short-lived in-memory cache:
#
# 1. Persisted to disk, so a restart doesn't throw away everything and
#    force a full cold re-fetch of every tracked title on the next load —
#    which, for a library with hundreds/thousands of tracked titles (e.g.
#    after a large Radarr/Sonarr migration), was the actual source of
#    "still slow" even with the concurrent-fetch fix from before.
#
# 2. Adaptive TTL instead of one fixed short window: a movie released
#    years ago, or a series with no upcoming/recently-aired episodes, is
#    essentially static — Cinemeta's data for it isn't going to change
#    meaningfully, so it's cached for days. Anything upcoming or recently
#    active still refreshes on the old short window, since that's exactly
#    the content whose air/release dates can actually change. Since most
#    of a large tracked library is old, already-released content, this is
#    the change that actually matters at scale — it means most calendar
#    loads do close to zero Cinemeta calls at all, not just fewer.
_calendar_meta_cache: dict[str, tuple] = {}   # "{kind}:{imdb_id}" -> (fetched_at, ttl_seconds, meta)
_CALENDAR_CACHE_SHORT_TTL = 600          # upcoming/recently-active — refresh often
_CALENDAR_CACHE_LONG_TTL  = 7 * 86400    # long-settled — essentially static


def _calendar_cache_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_calendar_cache.json"


_calendar_cache_loaded = False


def _load_calendar_cache() -> None:
    global _calendar_meta_cache, _calendar_cache_loaded
    if _calendar_cache_loaded:
        return
    path = _calendar_cache_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text())
            _calendar_meta_cache = {k: tuple(v) for k, v in raw.items()}
            logger.info("Loaded %d cached calendar title(s) from %s", len(_calendar_meta_cache), path)
    except Exception as exc:
        logger.warning("Could not load calendar cache from %s: %s", path, exc)
        _calendar_meta_cache = {}
    _calendar_cache_loaded = True


def _persist_calendar_cache() -> None:
    path = _calendar_cache_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(_calendar_meta_cache))
    except Exception as exc:
        logger.warning("Could not persist calendar cache to %s: %s", path, exc)


def _calendar_cache_ttl(kind: str, meta: dict) -> int:
    from datetime import datetime, timezone as _tz, timedelta

    def _parse(s):
        if not s: return None
        try:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            if not dt.tzinfo: dt = dt.replace(tzinfo=_tz.utc)
            return dt
        except Exception:
            return None

    now = datetime.now(_tz.utc)
    if kind == "movie":
        dt = _parse(meta.get("released"))
        if dt and dt < now - timedelta(days=60):
            return _CALENDAR_CACHE_LONG_TTL
        return _CALENDAR_CACHE_SHORT_TTL

    # series: long TTL only if every known episode aired more than two
    # weeks ago (nothing upcoming, nothing recent enough for a date to
    # still plausibly be corrected/added) — otherwise short.
    videos = meta.get("videos") or []
    has_upcoming_or_recent = any(
        (dt := _parse(v.get("released"))) and dt > now - timedelta(days=14)
        for v in videos
    )
    return _CALENDAR_CACHE_SHORT_TTL if has_upcoming_or_recent else _CALENDAR_CACHE_LONG_TTL


# How many Cinemeta requests are allowed in flight at once, SHARED across
# every caller (calendar, missing-counts, spot check) — this used to be a
# constant that each caller turned into its OWN separate Semaphore(40),
# which meant they never actually coordinated: if the calendar, the
# missing-counts endpoint, and spot check all happened to run around the
# same time, real concurrent load could hit 3×40=120 requests, not 40 —
# exactly the same class of bug already fixed once for TorBox. Cinemeta
# is a more tolerant service than TorBox, but not infinitely so; 120
# concurrent connections was enough to cause a wave of timeouts (visible as
# "failed to fetch ... :" with nothing after the colon — asyncio.TimeoutError
# stringifies to an empty string, which is why those log lines look blank).
_CALENDAR_FETCH_CONCURRENCY = 15
_cinemeta_gate = asyncio.Semaphore(_CALENDAR_FETCH_CONCURRENCY)


async def _cinemeta_cached(kind: str, imdb_id: str) -> dict:
    _load_calendar_cache()
    key = f"{kind}:{imdb_id}"
    cached = _calendar_meta_cache.get(key)
    if cached and (time.time() - cached[0]) < cached[1]:
        return cached[2]

    async with _cinemeta_gate:
        async with _http.get(
            f"https://v3-cinemeta.strem.io/meta/{kind}/{imdb_id}.json",
            headers={"User-Agent": "AIOGateway/0.3"},
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            data = await resp.json(content_type=None)
    meta = data.get("meta") or {}
    ttl  = _calendar_cache_ttl(kind, meta)
    _calendar_meta_cache[key] = (time.time(), ttl, meta)
    return meta


@app.get("/api/calendar")
async def get_calendar(days_back: int = 14, days_ahead: int = 30):
    """
    Returns calendar entries for all tracked movies and series episodes
    releasing within [days_back, days_ahead] of today.

    For series: fetches real per-episode air dates from Cinemeta — accurate
    because streaming shows air and go digital on the same date.

    For movies: uses Cinemeta's `released` field, which is the theatrical
    release date for most movies, not the digital/VOD date. Labeled clearly.
    Digital dates vary by title and aren't available in any free no-auth API.

    Each entry includes `release_ts` (Unix timestamp) so the frontend can
    sort and group by date without timezone issues, plus `stub_exists`
    indicating whether the content is already in the library (so the UI
    can show "in library" vs "upcoming").

    Every tracked title's Cinemeta metadata is fetched CONCURRENTLY (bounded
    by a semaphore) rather than one at a time — with a few hundred tracked
    titles, doing this sequentially was the actual bottleneck behind a slow
    calendar load, not anything TorBox-related. Results are also cached
    for a few minutes (see _cinemeta_cached above) so repeat loads of the
    same window are close to instant.
    """
    from datetime import datetime, timezone as _tz, timedelta

    now = datetime.now(_tz.utc)
    window_start = now - timedelta(days=days_back)
    window_end   = now + timedelta(days=days_ahead)

    def _parse_date(s: Optional[str]):
        if not s: return None
        try:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            if not dt.tzinfo:
                dt = dt.replace(tzinfo=_tz.utc)
            return dt
        except Exception:
            return None

    def _in_window(dt) -> bool:
        if not dt: return False
        return window_start <= dt <= window_end

    entries = []

    # Single pass over all stubs to build every lookup the loops below need,
    # instead of each title re-scanning the full stub list from scratch.
    all_stubs = _stubs.all()
    series_imdb_ids: set = set()
    movie_imdb_ids: set = set()
    stubbed_episodes: set = set()
    stubbed_movies: set = set()
    poster_by_imdb: dict = {}
    show_title_by_imdb: dict = {}
    movie_stub_by_imdb: dict = {}

    for s in all_stubs:
        if not s.imdb_id:
            continue
        if s.aiostreams_type == "series":
            series_imdb_ids.add(s.imdb_id)
            if s.season and s.episode:
                stubbed_episodes.add((s.imdb_id, s.season, s.episode))
            if s.imdb_id not in poster_by_imdb and getattr(s, "_poster", ""):
                poster_by_imdb[s.imdb_id] = s._poster
            if s.imdb_id not in show_title_by_imdb and (s.show_title or s.title):
                show_title_by_imdb[s.imdb_id] = s.show_title or s.title
        elif s.aiostreams_type == "movie":
            movie_imdb_ids.add(s.imdb_id)
            stubbed_movies.add(s.imdb_id)
            movie_stub_by_imdb.setdefault(s.imdb_id, s)

    async def _fetch_series(imdb_id: str) -> list:
        out = []
        try:
            meta = await _cinemeta_cached("series", imdb_id)
            videos = meta.get("videos") or []
            poster = meta.get("poster") or poster_by_imdb.get(imdb_id, "")
            show_title = show_title_by_imdb.get(imdb_id) or meta.get("name", imdb_id)
            for v in videos:
                sn, ep = v.get("season"), v.get("number")
                if not sn or not ep or sn == 0:
                    continue
                dt = _parse_date(v.get("released"))
                if not _in_window(dt):
                    continue
                key = (imdb_id, sn, ep)
                out.append({
                    "_key":         key,
                    "type":         "episode",
                    "imdb_id":      imdb_id,
                    "title":        show_title,
                    "episode_name": v.get("name") or f"S{sn:02d}E{ep:02d}",
                    "season":       sn,
                    "episode":      ep,
                    "poster":       poster,
                    "release_date": dt.date().isoformat(),
                    "release_ts":   int(dt.timestamp()),
                    "stub_exists":  key in stubbed_episodes,
                    "in_library":   key in stubbed_episodes,
                    "date_type":    "air_date",  # accurate — air date = digital for streaming
                })
        except Exception as exc:
            logger.warning("Calendar: failed to fetch episodes for %s: %s (%s)",
                          imdb_id, exc, type(exc).__name__)
        return out

    async def _fetch_movie(imdb_id: str) -> Optional[dict]:
        try:
            meta = await _cinemeta_cached("movie", imdb_id)
            dt = _parse_date(meta.get("released"))
            if not _in_window(dt):
                return None
            stub = movie_stub_by_imdb.get(imdb_id)
            return {
                "_key":         imdb_id,
                "type":         "movie",
                "imdb_id":      imdb_id,
                "title":        meta.get("name") or (stub.title if stub else imdb_id),
                "poster":       meta.get("poster") or (getattr(stub, "_poster", "") if stub else ""),
                "release_date": dt.date().isoformat(),
                "release_ts":   int(dt.timestamp()),
                "stub_exists":  imdb_id in stubbed_movies,
                "in_library":   imdb_id in stubbed_movies,
                "date_type":    "theatrical",  # Cinemeta gives theatrical, not digital/VOD
            }
        except Exception as exc:
            logger.warning("Calendar: failed to fetch movie meta for %s: %s (%s)",
                          imdb_id, exc, type(exc).__name__)
            return None

    series_results, movie_results = await asyncio.gather(
        asyncio.gather(*[_fetch_series(i) for i in series_imdb_ids]),
        asyncio.gather(*[_fetch_movie(i) for i in movie_imdb_ids]),
    )

    seen_keys = set()
    for ep_list in series_results:
        for e in ep_list:
            if e["_key"] in seen_keys:
                continue
            seen_keys.add(e["_key"])
            del e["_key"]
            entries.append(e)
    for m in movie_results:
        if not m or m["_key"] in seen_keys:
            continue
        seen_keys.add(m["_key"])
        del m["_key"]
        entries.append(m)

    entries.sort(key=lambda e: e["release_ts"])
    asyncio.create_task(asyncio.to_thread(_persist_calendar_cache))
    return {
        "entries":    entries,
        "days_back":  days_back,
        "days_ahead": days_ahead,
        "generated_at": int(now.timestamp()),
    }


@app.get("/api/library/missing-counts")
async def get_missing_counts():
    """
    Returns {imdb_id: missing_episode_count} for every tracked series,
    scoped to seasons that are actually requested — same definition used
    everywhere else in the app (Library's series detail modal, spot
    check): a season counts as requested if it has at least one existing
    stub. A season never requested doesn't count toward "missing" just
    because Cinemeta lists it. Powers the "N missing" banner on library
    cover art. Reuses the same cached Cinemeta fetch the calendar and
    spot check use, so repeat calls are cheap.
    """
    series_info: dict = {}
    for s in _stubs.all():
        if s.media_type == MediaType.SERIES and s.imdb_id:
            info = series_info.setdefault(s.imdb_id, {"seasons": set(), "have": set()})
            if s.season is not None:
                info["seasons"].add(s.season)
                if s.episode is not None:
                    info["have"].add((s.season, s.episode))

    counts: dict = {}

    async def _count_one(imdb_id: str, info: dict):
        try:
            meta = await _cinemeta_cached("series", imdb_id)
            videos = meta.get("videos") or []
            missing = 0
            for v in videos:
                sn, ep = v.get("season"), v.get("number")
                if not sn or not ep or sn == 0:
                    continue
                if sn not in info["seasons"]:
                    continue
                if not _is_aired(v.get("released")):
                    continue
                if (sn, ep) in info["have"]:
                    continue
                missing += 1
            if missing:
                counts[imdb_id] = missing
        except Exception as exc:
            logger.warning("Missing-count check failed for %s: %s (%s)",
                          imdb_id, exc, type(exc).__name__)

    await asyncio.gather(*[_count_one(i, info) for i, info in series_info.items()])
    return {"counts": counts}


# ---------------------------------------------------------------------------
# Spot check — on-demand audit + fix of the whole library for gaps
# ---------------------------------------------------------------------------
# Distinct from the automatic sweeps (auto-episode discovery, pending-movies
# retry), which only run on their own schedule and in the background: this
# is a manual, on-demand action that immediately checks every tracked series
# for aired episodes with no stub — scoped to seasons you've actually
# requested, not the whole show, matching every other "requested" concept in
# the app (Library's series detail modal, requestSeason/removeSeason) — and
# every pending movie whose release date has passed, then actually searches
# for and adds each one found right now, rather than waiting for the next
# scheduled sweep. Useful when you want to force everything up to date
# immediately, or verify the background sweeps have actually kept up.
_spotcheck_jobs: dict[str, dict] = {}
_spotcheck_tasks: dict[str, "asyncio.Task"] = {}


_QUALITY_URL_RE_4K = re.compile(r'(?i)(2160p|\b4k\b|\buhd\b)')
_QUALITY_URL_RE_HD = re.compile(r'(?i)(1080p|720p|\bhd\b)')


def _detect_quality_from_url(url: Optional[str]) -> Optional[str]:
    """
    Best-effort, conservative detection of a resolved stream's actual
    quality from its URL — many debrid CDN links carry the original
    release filename as a path segment, which usually includes a
    resolution tag. Returns 'hd', '4k', or None if inconclusive (no
    identifiable marker at all, or both HD and 4K markers present, which
    can happen with query strings/redirects and isn't a confident signal
    either way — deliberately not guessing in that case).
    """
    if not url:
        return None
    has_4k = bool(_QUALITY_URL_RE_4K.search(url))
    has_hd = bool(_QUALITY_URL_RE_HD.search(url))
    if has_4k and not has_hd:
        return "4k"
    if has_hd and not has_4k:
        return "hd"
    return None


async def _run_spot_check(job_id: str, scope: str = "both", verify_quality_override: Optional[bool] = None):
    job = _spotcheck_jobs[job_id]
    try:
        from gateway import pending_movies as _pending_mv
        from datetime import datetime, timezone as _tz

        check_series = scope in ("both", "series")
        check_movies = scope in ("both", "movies")

        # Every tracked series, with title/poster/year pulled from any of
        # its existing stubs.
        series_info: dict = {}
        if check_series:
            for s in _stubs.all():
                if s.media_type == MediaType.SERIES and s.imdb_id:
                    info = series_info.setdefault(s.imdb_id, {
                        "title": s.show_title or s.title, "poster": "", "year": s.year
                    })
                    if not info["poster"] and getattr(s, "_poster", ""):
                        info["poster"] = s._poster

        pending = _pending_mv.list_all() if check_movies else []

        # ── Phase 1: find what's missing ────────────────────────────────
        job["phase"]  = "checking"
        job["total"]  = len(series_info) + len(pending)
        job["done"]   = 0
        job["status"] = "running"

        missing_episodes = []

        async def _check_series(imdb_id: str, info: dict):
            job["current_title"] = info["title"]
            try:
                meta = await _cinemeta_cached("series", imdb_id)
                videos = meta.get("videos") or []
                have = {
                    (s.season, s.episode) for s in _stubs.all()
                    if s.imdb_id == imdb_id and s.season is not None
                }
                # Only check seasons that are actually requested — same
                # definition used everywhere else (Library's series detail
                # modal, requestSeason/removeSeason): a season counts as
                # requested if it has at least one existing stub. A show
                # you only requested Season 1 of shouldn't have Seasons
                # 2-5 flagged as "missing" just because Cinemeta lists
                # them — those were never asked for in the first place.
                requested_seasons = {sn for sn, _ in have}
                for v in videos:
                    sn, ep = v.get("season"), v.get("number")
                    if not sn or not ep or sn == 0:
                        continue
                    if sn not in requested_seasons:
                        continue
                    if not _is_aired(v.get("released")):
                        continue
                    if (sn, ep) in have:
                        continue
                    missing_episodes.append({
                        "imdb_id": imdb_id, "title": info["title"], "poster": info["poster"],
                        "year": info["year"], "season": sn, "episode": ep,
                        "episode_name": v.get("name") or f"S{sn:02d}E{ep:02d}",
                    })
            except Exception as exc:
                logger.warning("Spot check: failed to check %s: %s (%s)",
                              imdb_id, exc, type(exc).__name__)
            job["done"] += 1

        if check_series:
            await asyncio.gather(*[_check_series(i, info) for i, info in series_info.items()])

        # Pending movies past their searchable date (theatrical release +
        # digital_release_delay_days) — these "should" be findable by now
        # but aren't yet. Using the same delayed date _add_movie/_query_
        # movie use, not the raw theatrical date, so spot check doesn't
        # flag something as "overdue" while it's still inside the window
        # we're deliberately not searching yet.
        now = datetime.now(_tz.utc)
        overdue_movies = []
        for entry in pending:
            job["current_title"] = entry["title"]
            searchable_at = await _movie_searchable_at(entry["imdb_id"])
            if searchable_at and searchable_at <= now:
                overdue_movies.append(entry)
            job["done"] += 1

        # ── Phase 2: actually go search for each missing item ───────────
        # This is what makes it a fix, not just a report — every missing
        # episode and overdue movie found above gets a real search attempt
        # right here, through the exact same code path a manual "Search"
        # click would use. Runs through the normal TorBox rate gate
        # like everything else, so a spot check with a lot of gaps can
        # take a while — that's expected, not stuck.
        job["phase"] = "fixing"
        job["total"] = len(missing_episodes) + len(overdue_movies)
        job["done"]  = 0

        from gateway import quality_unavailable as _qu

        fixed_episodes, still_missing_episodes = [], []
        for e in missing_episodes:
            job["current_title"] = f"{e['title']} S{e['season']:02d}E{e['episode']:02d}"
            await _yield_to_play_priority()
            try:
                req = AddReq(
                    imdb_id=e["imdb_id"], title=e["title"], media_type="series",
                    poster=e["poster"], year=e["year"],
                )
                result = await add_single_episode(e["imdb_id"], e["season"], e["episode"], req)
                fixed_episodes.append(e)
                # Found HD but this same resolve found zero 4K candidates —
                # a confident "not available" signal, since resolve_all()
                # checks both qualities in one TorBox query. Mark it so
                # future automatic sweeps stop re-attempting 4K here.
                if result and not result.get("has_4k") and not _qu.is_marked(e["imdb_id"], e["season"], e["episode"]):
                    _qu.mark(e["imdb_id"], e["title"], e["season"], e["episode"], e.get("poster", ""))
            except Exception as exc:
                still_missing_episodes.append({**e, "reason": str(exc)})
            job["done"] += 1

        fixed_movies, still_missing_movies = [], []
        for m in overdue_movies:
            job["current_title"] = m["title"]
            await _yield_to_play_priority()
            try:
                req = AddReq(
                    imdb_id=m["imdb_id"], title=m["title"], media_type="movie",
                    poster=m.get("poster", ""), year=m.get("year"),
                )
                result = await _add_movie(req)
                if result.get("pending"):
                    still_missing_movies.append({**m, "reason": "still not resolvable"})
                else:
                    fixed_movies.append(m)
                    if not result.get("has_4k") and not _qu.is_marked(m["imdb_id"]):
                        _qu.mark(m["imdb_id"], m["title"], poster=m.get("poster", ""))
            except Exception as exc:
                still_missing_movies.append({**m, "reason": str(exc)})
            job["done"] += 1

        job["fixed_episodes"]        = fixed_episodes
        job["still_missing_episodes"] = still_missing_episodes
        job["fixed_movies"]          = fixed_movies
        job["still_missing_movies"]  = still_missing_movies

        # ── Phase 3: verify existing stubs are actually the quality they
        # claim to be ─────────────────────────────────────────────────
        # Distinct from phases 1-2 above, which only ever ADD stubs for
        # things that are missing — this is the one part of spot check
        # that can REMOVE an existing, currently-working stub, so it's
        # gated by its own setting (spot_check_verify_quality) and is
        # deliberately conservative: it only acts when the resolved
        # stream's URL contains an unambiguous resolution marker that
        # directly contradicts the stub's labeled quality (e.g. labeled
        # 4K but the URL clearly says 1080p). If the URL has no
        # identifiable marker, or a genuinely ambiguous one, it's left
        # alone rather than guessed at — we don't store the original
        # resolved stream's parsed quality info on the stub itself, so a
        # confident check is only possible when the CDN URL happens to
        # carry that information (common, but not guaranteed).
        from gateway import settings as _settings
        verify_quality = (
            verify_quality_override if verify_quality_override is not None
            else _settings.get("spot_check_verify_quality", True)
        )
        quality_fixed, quality_unresolved = [], []

        if verify_quality:
            job["phase"] = "verifying_quality"
            active_stubs = [
                s for s in _stubs.all()
                if s.state == StubState.ACTIVE and s.stream_url
                and ((s.media_type == MediaType.SERIES and check_series)
                     or (s.media_type == MediaType.MOVIE and check_movies))
            ]
            job["total"] = len(active_stubs)
            job["done"]  = 0

            for s in active_stubs:
                if s.media_type == MediaType.MOVIE:
                    label = s.title
                elif s.season is not None and s.episode is not None:
                    label = f"{s.show_title or s.title} S{s.season:02d}E{s.episode:02d}"
                else:
                    label = s.show_title or s.title
                job["current_title"] = label

                detected = _detect_quality_from_url(s.stream_url)
                if detected and detected != s.quality.value:
                    logger.warning(
                        "Spot check: quality mismatch for %s — labeled %s, "
                        "resolved stream's URL indicates %s",
                        label, s.quality.value.upper(), detected.upper()
                    )
                    item_info = {
                        "stub_id": s.stub_id, "title": label,
                        "poster": getattr(s, "_poster", ""),
                        "labeled": s.quality.value, "detected": detected,
                    }
                    try:
                        removed = await _stubs.remove_stub(s.stub_id)
                        if not removed:
                            quality_unresolved.append({**item_info, "reason": "could not remove mismatched stub"})
                            job["done"] += 1
                            continue

                        target_q = s.quality   # re-search for what it was SUPPOSED to be
                        if s.media_type == MediaType.MOVIE:
                            item = MediaItem(
                                id=s.imdb_id, imdb_id=s.imdb_id, title=s.title,
                                year=s.year, media_type=MediaType.MOVIE,
                            )
                        else:
                            item = MediaItem(
                                id=f"{s.imdb_id}_s{s.season}e{s.episode}", imdb_id=s.imdb_id,
                                title=s.title, show_title=s.show_title, episode_title="",
                                year=s.year, media_type=MediaType.SERIES,
                                season=s.season, episode=s.episode,
                            )
                        item._poster = getattr(s, "_poster", "") or ""

                        await _yield_to_play_priority()
                        new_stream = await _resolve_one_quality(item, target_q)
                        if new_stream:
                            await _stubs.create_stub_for_quality(item, target_q, new_stream)
                            quality_fixed.append(item_info)
                        else:
                            quality_unresolved.append({
                                **item_info,
                                "reason": f"removed, but no clean {target_q.value.upper()} source found",
                            })
                            if target_q == Quality.UHD:
                                _qu.mark(s.imdb_id, label, s.season, s.episode, item_info["poster"])
                    except Exception as exc:
                        quality_unresolved.append({**item_info, "reason": str(exc)})
                job["done"] += 1

        job["quality_fixed"]      = quality_fixed
        job["quality_unresolved"] = quality_unresolved
        job["status"] = "done"
    except asyncio.CancelledError:
        job["status"] = "cancelled"
    finally:
        job["finished"]      = True
        job["current_title"] = ""
        _spotcheck_tasks.pop(job_id, None)


class SpotCheckRunReq(BaseModel):
    scope: str = "both"   # "both" | "movies" | "series"
    verify_quality: Optional[bool] = None   # None = use the persisted spot_check_verify_quality setting


@app.post("/api/spot-check/run")
async def start_spot_check(req: SpotCheckRunReq = SpotCheckRunReq()):
    if req.scope not in ("both", "movies", "series"):
        raise HTTPException(400, "scope must be 'both', 'movies', or 'series'")
    job_id = uuid.uuid4().hex[:12]
    _spotcheck_jobs[job_id] = {
        "job_id": job_id, "scope": req.scope, "phase": "checking", "total": 0, "done": 0,
        "current_title": "", "status": "starting", "finished": False,
        "fixed_episodes": [], "still_missing_episodes": [],
        "fixed_movies": [], "still_missing_movies": [],
        "quality_fixed": [], "quality_unresolved": [],
    }
    task = asyncio.create_task(_run_spot_check(job_id, req.scope, req.verify_quality))
    _spotcheck_tasks[job_id] = task
    return {"job_id": job_id}


@app.get("/api/spot-check/status/{job_id}")
async def spot_check_status(job_id: str):
    job = _spotcheck_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    return job


@app.post("/api/spot-check/cancel/{job_id}")
async def cancel_spot_check(job_id: str):
    job = _spotcheck_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    task = _spotcheck_tasks.get(job_id)
    if task and not task.done():
        task.cancel()
    return {"ok": True}


@app.delete("/api/series/{imdb_id}/season/{season}")
async def remove_season(imdb_id: str, season: int):
    """
    Deletes every stub (HD and 4K) for one season of a tracked series —
    the "un-request a season" counterpart to requestSeason(). Uses
    StubManager.remove_stub() per stub rather than deleting files directly,
    so each removal also triggers the scoped Plex rescan that cleans the
    now-gone episodes out of Plex's library, not just off disk.
    """
    to_remove = [
        s.stub_id for s in _stubs.all()
        if s.imdb_id == imdb_id and s.season == season
    ]
    if not to_remove:
        raise HTTPException(404, "No stubs found for that season")

    removed = 0
    for sid in to_remove:
        if await _stubs.remove_stub(sid):
            removed += 1

    logger.info("Removed season %d of %s: %d stub(s)", season, imdb_id, removed)
    return {"removed": removed, "season": season, "imdb_id": imdb_id}


async def _resolve_one_quality(item: MediaItem, quality: Quality):
    """Bind one quality tier to a cached torrent for manual scans and spot
    check. "Nothing cached could be bound" and "TorBox busy" both come back
    as None here — these are deliberate one-off actions the user can retry."""
    from gateway.torbox_client import TorBoxUnavailableError
    try:
        return await _client.bind_for_quality(item, quality, priority=_tb_guard.HIGH)
    except (AllCandidatesDeadError, TorBoxUnavailableError):
        return None


async def _movie_meta_for_scan(imdb_id: str, existing=None) -> tuple:
    """(title, year, poster) for a movie being scanned: an existing library
    entry first, then its pending-list entry (which has exactly this info),
    then Cinemeta. Keeps a pending movie from being filed under its IMDb id
    if Cinemeta happens to be unreachable."""
    if existing:
        return existing.title, existing.year, getattr(existing, "_poster", "")
    from gateway import pending_movies as _pending_mv
    p = next((x for x in _pending_mv.list_all() if x["imdb_id"] == imdb_id), None)
    try:
        meta = await _cinemeta_cached("movie", imdb_id)
    except Exception:
        meta = {}
    year = None
    try:
        if meta.get("year"):
            year = int(str(meta["year"])[:4])
        elif meta.get("released"):
            year = int(meta["released"][:4])
    except Exception:
        pass
    if p:
        return (meta.get("name") or p.get("title") or imdb_id, year or p.get("year"),
                meta.get("poster") or p.get("poster") or "")
    return meta.get("name", imdb_id), year, meta.get("poster", "")


@app.post("/api/movies/{imdb_id}/scan/{quality}")
async def scan_movie_quality(imdb_id: str, quality: str):
    """Manually search for just one quality tier of a movie — for when a
    title has HD but you specifically want to check for 4K (or vice
    versa) right now, rather than waiting on the pending-movies sweep."""
    if quality not in ("hd", "4k"):
        raise HTTPException(400, "quality must be 'hd' or '4k'")
    q = Quality.UHD if quality == "4k" else Quality.HD

    # Prefer metadata from an existing stub for this movie; fall back to
    # Cinemeta if nothing's stubbed yet (e.g. still in the pending list).
    existing = next(
        (s for s in _stubs.all() if s.imdb_id == imdb_id and s.media_type == MediaType.MOVIE),
        None
    )
    title, year, poster = await _movie_meta_for_scan(imdb_id, existing)

    item = MediaItem(id=imdb_id, imdb_id=imdb_id, title=title, year=year, media_type=MediaType.MOVIE)
    item._poster = poster or ""

    stream = await _resolve_one_quality(item, q)
    if not stream:
        raise HTTPException(404, f"No {quality.upper()} stream found")

    stub = await _stubs.create_stub_for_quality(item, q, stream)
    if not stub:
        raise HTTPException(404, f"No cached {quality.upper()} torrent could be added")
    if q == Quality.UHD:
        from gateway import quality_unavailable as _qu
        _qu.unmark(imdb_id)   # found one — clear any earlier "confirmed unavailable" mark
    logger.info("Manual %s scan for movie %s: %s", quality.upper(), imdb_id, stub.stub_id)
    return {"imdb_id": imdb_id, "quality": quality, "stub_id": stub.stub_id}


@app.post("/api/series/{imdb_id}/season/{season}/scan/{quality}")
async def scan_season_quality(imdb_id: str, season: int, quality: str):
    """
    Manually search for just one quality tier across every aired episode
    of one season — the "Scan HD" / "Scan 4K" counterpart to Request
    season, for when a season has (say) HD for most episodes but you want
    to specifically push for 4K right now rather than waiting on the next
    automatic pass.

    Runs synchronously (not handed off to a background task like the
    fast-E01-then-background-scan pattern elsewhere) since this is a
    smaller, deliberate, already-narrow-scoped action — a full season can
    still take a while given the TorBox pacing settings, but that's
    expected for an explicit "scan this now" click.
    """
    if quality not in ("hd", "4k"):
        raise HTTPException(400, "quality must be 'hd' or '4k'")
    q = Quality.UHD if quality == "4k" else Quality.HD

    try:
        meta = await _cinemeta_cached("series", imdb_id)
    except Exception as exc:
        raise HTTPException(502, f"Cinemeta fetch failed: {exc}")

    videos = meta.get("videos") or []
    aired_eps = [
        v for v in videos
        if v.get("season") == season and v.get("number") is not None and _is_aired(v.get("released"))
    ]
    if not aired_eps:
        raise HTTPException(404, "No aired episodes found for that season")

    show_title = next(
        (s.show_title or s.title for s in _stubs.all() if s.imdb_id == imdb_id and (s.show_title or s.title)),
        meta.get("name", imdb_id)
    )
    poster = next(
        (getattr(s, "_poster", "") for s in _stubs.all() if s.imdb_id == imdb_id and getattr(s, "_poster", "")),
        meta.get("poster", "")
    )
    year = next((s.year for s in _stubs.all() if s.imdb_id == imdb_id and s.year), None)

    # Skip episodes that already have this exact quality stubbed.
    have = {
        s.episode for s in _stubs.all()
        if s.imdb_id == imdb_id and s.season == season and s.quality == q
    }
    to_scan = [v for v in aired_eps if v.get("number") not in have]

    found = 0
    checked = 0
    for v in to_scan:
        ep_num = v.get("number")
        item = MediaItem(
            id=f"{imdb_id}_s{season}e{ep_num}", imdb_id=imdb_id,
            title=show_title, show_title=show_title, episode_title="",
            year=year, media_type=MediaType.SERIES, season=season, episode=ep_num,
        )
        item._poster = poster or ""
        checked += 1
        try:
            stream = await _resolve_one_quality(item, q)
        except Exception as exc:
            logger.warning("Season %s scan: S%02dE%02d failed: %s", quality, season, ep_num, exc)
            continue
        if stream:
            await _stubs.create_stub_for_quality(item, q, stream)
            found += 1
            if q == Quality.UHD:
                from gateway import quality_unavailable as _qu
                _qu.unmark(imdb_id, season, ep_num)   # found one — clear any earlier mark for this episode

    logger.info("Manual %s scan for %s season %d: %d/%d episodes found",
               quality.upper(), imdb_id, season, found, checked)
    return {
        "imdb_id": imdb_id, "season": season, "quality": quality,
        "checked": checked, "found": found, "already_had": len(aired_eps) - len(to_scan),
    }


class EpisodeQualityScanReq(BaseModel):
    title: str
    poster: str = ""
    year: Optional[int] = None


@app.post("/api/series/{imdb_id}/episode/{season}/{episode}/scan/{quality}")
async def scan_episode_quality(imdb_id: str, season: int, episode: int, quality: str, req: EpisodeQualityScanReq):
    """
    Search for just one specific quality tier of one specific episode —
    the single-episode counterpart to scan_season_quality/
    scan_movie_quality, and what powers the HD/4K choice on a missing
    episode chip in the series detail modal (add_single_episode, by
    contrast, always does HD plus 4K-if-available and has no way to
    target just one tier).

    Same air-date guard as add_single_episode — refuses outright if this
    specific episode hasn't aired yet, for the same reason: anything
    that showed up for an unaired episode would only ever be a bogus or
    mismatched result.
    """
    if quality not in ("hd", "4k"):
        raise HTTPException(400, "quality must be 'hd' or '4k'")
    q = Quality.UHD if quality == "4k" else Quality.HD

    try:
        meta = await _cinemeta_cached("series", imdb_id)
        target = next(
            (v for v in (meta.get("videos") or [])
             if v.get("season") == season and v.get("number") == episode),
            None
        )
        if target is not None and not _is_aired(target.get("released")):
            raise HTTPException(
                400,
                f"S{season:02d}E{episode:02d} hasn't aired yet "
                f"({target.get('released', 'no date available')}) — refusing to search for it."
            )
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("Could not verify air date for %s S%02dE%02d, proceeding anyway: %s",
                       imdb_id, season, episode, exc)

    item = MediaItem(
        id=f"{imdb_id}_s{season}e{episode}", imdb_id=imdb_id,
        title=req.title, show_title=req.title, episode_title="",
        year=req.year, media_type=MediaType.SERIES, season=season, episode=episode,
    )
    item._poster = req.poster or ""

    stream = await _resolve_one_quality(item, q)
    if not stream:
        raise HTTPException(404, f"No {quality.upper()} stream found for S{season:02d}E{episode:02d}")

    stub = await _stubs.create_stub_for_quality(item, q, stream)
    if not stub:
        raise HTTPException(404, f"No cached {quality.upper()} torrent could be added for S{season:02d}E{episode:02d}")
    if q == Quality.UHD:
        from gateway import quality_unavailable as _qu
        _qu.unmark(imdb_id, season, episode)   # found one — clear any earlier mark for this episode
    logger.info("Manual %s scan for %s S%02dE%02d: %s", quality.upper(), imdb_id, season, episode, stub.stub_id)
    return {"imdb_id": imdb_id, "season": season, "episode": episode, "quality": quality, "stub_id": stub.stub_id}


@app.get("/api/stubs/{stub_id}/candidates")
async def get_stub_candidates(stub_id: str):
    """
    Lists every available stream TorBox currently returns for this
    stub's quality — the same pool best_working_for_quality picks from
    automatically, but shown here so a person can look at filenames/size/
    cache status directly and manually pick a specific one, instead of
    trusting the automatic ranking. Used by Library's "Active stream" tab.
    """
    s = _stubs.get(stub_id)
    if not s:
        raise HTTPException(404, "Not found")

    if s.media_type == MediaType.MOVIE:
        item = MediaItem(
            id=s.imdb_id, imdb_id=s.imdb_id, title=s.title,
            year=s.year, media_type=MediaType.MOVIE,
        )
    else:
        item = MediaItem(
            id=f"{s.imdb_id}_s{s.season}e{s.episode}", imdb_id=s.imdb_id,
            title=s.title, show_title=s.show_title, episode_title="",
            year=s.year, media_type=MediaType.SERIES,
            season=s.season, episode=s.episode,
        )

    try:
        streams = await _client.resolve_all(item)
    except Exception as exc:
        logger.exception("get_stub_candidates: resolve_all failed for stub %s (%s)", stub_id, item.title)
        raise HTTPException(502, f"Could not fetch candidates: {exc}")

    matching = [st for st in streams if st.quality == s.quality][:40]

    def _fmt(st):
        size_gb = round(st.size / (1024**3), 2) if st.size else None
        pack_kind, pack_season = st.pack_type
        return {
            "url": st.url,
            "headers": st.request_headers or {},
            "size": st.size,
            "size_gb": size_gb,
            "filename": st.filename,
            "service": st.service,
            "cached": bool(st.cached),
            "resolution": st.parsed_file.resolution if st.parsed_file else None,
            "encode": st.parsed_file.encode if st.parsed_file else None,
            "hdr": st.parsed_file.hdr if st.parsed_file else None,
            "languages": (st.parsed_file.languages or []) if st.parsed_file else [],
            "pack": pack_kind if pack_kind in ("season", "series") else None,
            "is_current": _same_source(st.url, s.stream_url),
        }

    return {
        "stub_id": stub_id, "quality": s.quality.value,
        "current_url": s.stream_url,
        "candidates": [_fmt(st) for st in matching],
    }


def _same_source(candidate_url: Optional[str], current_url: Optional[str]) -> bool:
    """A search candidate is the query form of a ref (torbox://hash?s=..)
    while the stub holds the materialized form (torbox://hash/file/name) —
    same torrent means same source."""
    from gateway.torbox_client import ref_hash
    if not candidate_url or not current_url:
        return False
    ch, uh = ref_hash(candidate_url), ref_hash(current_url)
    return bool(ch and ch == uh) or candidate_url == current_url


class SelectStreamReq(BaseModel):
    url: str
    headers: dict = {}
    size: Optional[int] = None


@app.post("/api/stubs/{stub_id}/select-stream")
async def select_stub_stream(stub_id: str, req: SelectStreamReq):
    """
    Manually overrides which specific stream a stub points at — the same
    effect a normal resolve has (set_active), just with a person picking
    the exact candidate instead of best_working_for_quality's automatic
    ranking. Does NOT probe the chosen URL first — this is a deliberate
    manual choice, so it's applied as given; if it turns out dead, the
    normal dead-candidate handling on the next play will catch it same as
    any other stream.
    """
    s = _stubs.get(stub_id)
    if not s:
        raise HTTPException(404, "Not found")
    from gateway.torbox_client import is_ref, make_query_ref, ref_hash, parse_ref
    url, size = req.url, req.size
    if is_ref(url):
        # Candidates from the picker are unresolved (hash + episode). Add the
        # torrent if needed and pin the exact file for THIS stub's episode.
        info = parse_ref(url)
        q = make_query_ref(info["hash"], s.season, s.episode)
        try:
            stream = await _client.materialize_ref(q)
        except Exception as exc:
            raise HTTPException(502, f"TorBox could not provide that source: {exc}")
        url, size = stream.url, stream.size
    await _stubs.set_active(stub_id, url, {}, size=size)
    try:
        from gateway.fuse_fs import invalidate_stub
        invalidate_stub(stub_id)
    except Exception:
        pass
    logger.info("Manually selected stream for stub %s: %s…", stub_id, req.url[:80])
    return {"ok": True, "stub_id": stub_id}


@app.delete("/api/stubs/{stub_id}")
async def delete_stub(stub_id: str):
    if not await _stubs.remove_stub(stub_id):
        raise HTTPException(404, "Not found")
    return {"deleted": stub_id}


@app.delete("/api/series/{imdb_id}")
async def delete_series(imdb_id: str):
    """Delete ALL stubs for a series and cancel any active background scan."""
    # Cancel background scan first
    if imdb_id in _bg_scans:
        task = _bg_scans.pop(imdb_id)
        task.cancel()
        try:
            await task
        except Exception:
            pass
        logger.info("Cancelled background scan for %s", imdb_id)

    deleted = 0
    for s in list(_stubs.all()):
        if s.imdb_id == imdb_id and await _stubs.remove_stub(s.stub_id):
            deleted += 1

    logger.info("Deleted %d stubs for series %s", deleted, imdb_id)
    return {"deleted": deleted, "imdb_id": imdb_id}


# ---------------------------------------------------------------------------
# Plex webhook
# ---------------------------------------------------------------------------

@app.post("/webhook/plex")
async def plex_webhook(request: Request):
    ct = request.headers.get("content-type", "")
    if "multipart/form-data" in ct:
        form = await request.form()
        raw = form.get("payload", "{}")
    else:
        raw = (await request.body()).decode()
    result = await _webhook.handle(raw)
    logger.info("Webhook: %s", result)
    return JSONResponse(result)


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

@app.get("/proxy/{stub_id}")
async def proxy_get(stub_id: str, request: Request):
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Stub not found")

    from gateway.stub_manager import is_listed
    if not is_listed(s):
        raise HTTPException(404, "Not bound to a TorBox file (yet)")

    range_header = request.headers.get("Range")
    if not range_header:
        # Full-file GET: redirect straight to the CDN (warpbox's smart
        # redirect) — saves a connection slot and all the bandwidth.
        from gateway.proxy import real_url
        from fastapi.responses import RedirectResponse
        try:
            return RedirectResponse(await real_url(s), status_code=302)
        except Exception as exc:
            raise HTTPException(502, f"TorBox link unavailable: {exc}")
    status, headers, body = await _proxy.proxy(s, range_header)
    return StreamingResponse(body, status_code=status, headers=headers,
                             media_type=headers.get("Content-Type", "video/x-matroska"))


@app.head("/proxy/{stub_id}")
async def proxy_head(stub_id: str):
    s = _stubs.get(stub_id)
    if not s or not s.stream_url: raise HTTPException(404)
    status, headers = await _proxy.head(s)
    return StreamingResponse(b"", status_code=status, headers=headers)


# ---------------------------------------------------------------------------
# TorBox API saver
# ---------------------------------------------------------------------------

@app.get("/api/torbox/stats")
async def torbox_stats():
    from gateway import settings as _settings
    out = await asyncio.to_thread(_client.stats)
    out["limit_per_minute"] = _settings.get("torbox_requests_per_minute", 250)
    from gateway import plex_scan as _ps
    out["plex_scans"] = _ps.stats()
    return out


@app.post("/api/torbox/sync-now")
async def torbox_sync_now():
    try:
        n = await asyncio.to_thread(_client.sync_torrents_sync)
    except Exception as exc:
        raise HTTPException(502, f"TorBox sync failed: {exc}")
    return {"torrents": n}


def _torbox_key_source() -> tuple[str, str]:
    from gateway.torbox_api import key_source
    return key_source()


class TorBoxKeyReq(BaseModel):
    api_key: str


@app.post("/api/torbox/key")
async def set_torbox_key(req: TorBoxKeyReq):
    """
    Save the TorBox API key from Config → Connections. The key is checked
    against TorBox first and only saved if TorBox accepts it. Switching to
    a different account clears everything tied to the old one (mirrored
    torrent list, cached links, failure caches); library entries re-add
    their torrents to the new account on their next read or repair pass.
    """
    from gateway import settings as _settings
    from gateway import torbox_api as _tb
    key = req.api_key.strip()
    if not key:
        raise HTTPException(400, "Paste a TorBox API key")
    try:
        me = await asyncio.to_thread(_tb.user_me, _tb_guard.HIGH, key)
    except _tb.TorBoxError as exc:
        if exc.status in (401, 403):
            raise HTTPException(400, "TorBox rejected this API key")
        raise HTTPException(502, f"Couldn't reach TorBox to check the key: {exc}")

    previous = _tb.api_key()
    _settings.update({"torbox_api_key": key})
    if previous != key:
        await _torbox_account_changed()
    logger.info("TorBox API key saved from Config (account %s)", me.get("email") or "?")
    return {"ok": True, "source": "config", "email": me.get("email"), "plan": me.get("plan")}


@app.delete("/api/torbox/key")
async def clear_torbox_key():
    """Remove the key saved in Config. TORBOX_API_KEY from the environment,
    if set, is used again."""
    from gateway import settings as _settings
    from gateway import torbox_api as _tb
    previous = _tb.api_key()
    _settings.update({"torbox_api_key": ""})
    if _tb.api_key() != previous:
        await _torbox_account_changed()
    return {"ok": True, "source": _tb.key_source()[1]}


class AllDebridKeyReq(BaseModel):
    api_key: str


@app.post("/api/alldebrid/key")
async def set_alldebrid_key(req: AllDebridKeyReq):
    """Save the AllDebrid API key, checked against AllDebrid first. Saving a
    key doesn't switch AllDebrid on — that's the separate toggle, so nothing
    starts serving AllDebrid links until you ask for it."""
    from gateway import settings as _settings
    from gateway import alldebrid_client as _ad
    key = req.api_key.strip()
    if not key:
        raise HTTPException(400, "Paste an AllDebrid API key")
    result = await asyncio.to_thread(_ad.connection_test, key)
    if result.get("diagnosis") == "bad_auth":
        raise HTTPException(400, "AllDebrid rejected this API key")
    if result.get("diagnosis") == "not_premium":
        raise HTTPException(400, result.get("error") or "This AllDebrid account isn't premium")
    if not result.get("ok"):
        raise HTTPException(502, f"Couldn't reach AllDebrid to check the key: {result.get('error')}")

    previous = _ad_api.api_key()
    _settings.update({"alldebrid_api_key": key})
    if previous != key:
        await asyncio.to_thread(_ad.store().reset)
    logger.info("AllDebrid API key saved from Config (account %s)", result.get("username") or "?")
    return {"ok": True, "source": "config", "username": result.get("username"),
            "premium": result.get("premium")}


@app.delete("/api/alldebrid/key")
async def clear_alldebrid_key():
    """Remove the saved key and switch AllDebrid off — leaving it enabled
    with no key would just drop every AllDebrid result anyway."""
    from gateway import settings as _settings
    from gateway import alldebrid_client as _ad
    _settings.update({"alldebrid_api_key": "", "alldebrid_enabled": False})
    await asyncio.to_thread(_ad.store().reset)
    return {"ok": True, "source": _ad_api.key_source()[1]}


@app.get("/api/alldebrid/test")
async def test_alldebrid():
    """Connection check for Config → Connections."""
    from gateway import alldebrid_client as _ad
    return await asyncio.to_thread(_ad.connection_test)


async def _torbox_account_changed():
    await asyncio.to_thread(_tb_guard.store().reset_account_data)
    _tb_guard.breaker.reset()
    from gateway import torbox_api as _tb
    if _tb.api_key():
        async def _sync():
            try:
                await asyncio.to_thread(_client.sync_torrents_sync)
            except Exception as exc:
                logger.warning("Account sync after key change failed: %s", exc)
        asyncio.create_task(_sync())


def _plex_signin_status() -> dict:
    from gateway import plex_auth
    try:
        return {"ok": True, "server_id": plex_auth.server_id()}
    except plex_auth.PlexAuthError as exc:
        return {"ok": False, "error": str(exc)}


def _aiostreams_status() -> dict:
    from gateway import aiostreams_api as _aio
    cfg = _aio.config()
    return {"url": cfg["url"], "uuid_set": bool(cfg["uuid"]), "password_set": bool(cfg["password"]),
            "configured": _aio.is_configured(cfg), "source": cfg["source"]}


class AIOStreamsConfigReq(BaseModel):
    url: str
    uuid: str
    password: Optional[str] = None      # omit/blank to keep the saved password
    # uuid "" or "__keep__" keeps the saved UUID


@app.post("/api/aiostreams/config")
async def set_aiostreams_config(req: AIOStreamsConfigReq):
    """Save AIOStreams connection details from Config → Connections. They're
    tested with a real search first and only saved if AIOStreams accepts them."""
    from gateway import settings as _settings
    from gateway import aiostreams_api as _aio
    saved = _aio.config()
    password = req.password if req.password else saved["password"]
    uuid = saved["uuid"] if req.uuid in ("", "__keep__") else req.uuid.strip()
    try:
        info = await asyncio.to_thread(_aio.test, req.url, uuid or "", password or "")
    except _aio.AIOStreamsError as exc:
        raise HTTPException(400, str(exc))
    _settings.update({"aiostreams_url": req.url.strip().rstrip("/"), "aiostreams_uuid": uuid,
                      "aiostreams_password": password})
    await asyncio.to_thread(_tb_guard.store().drop_search, "search:")   # results now come from a different source
    logger.info("AIOStreams configured: %s (%s)", req.url, info)
    return {"ok": True, **info, "status": _aiostreams_status()}


@app.delete("/api/aiostreams/config")
async def clear_aiostreams_config():
    """Forget the AIOStreams details saved in Config (environment variables,
    if set, are used again; otherwise TorBox's own search is used)."""
    from gateway import settings as _settings
    _settings.update({"aiostreams_url": "", "aiostreams_uuid": "", "aiostreams_password": ""})
    await asyncio.to_thread(_tb_guard.store().drop_search, "search:")
    return {"ok": True, "status": _aiostreams_status(), "search_source": _client.search_source()}


@app.post("/api/aiostreams/test")
async def test_aiostreams():
    from gateway import aiostreams_api as _aio
    cfg = _aio.config()
    if not _aio.is_configured(cfg):
        return {"ok": False, "diagnosis": "not_configured", "error": "AIOStreams isn't set up"}
    try:
        info = await asyncio.to_thread(_aio.test, cfg["url"], cfg["uuid"], cfg["password"])
    except _aio.AIOStreamsError as exc:
        return {"ok": False, "diagnosis": exc.diagnosis, "error": str(exc)}
    return {"ok": True, **info}


@app.get("/api/movies/{imdb_id}/releases")
async def movie_releases(imdb_id: str):
    """The cached releases AIOStreams (or TorBox search) finds for a movie
    right now, released or not, best first — capped at releases_max_results
    (15 by default). Always a fresh search."""
    item = MediaItem(id=imdb_id, imdb_id=imdb_id, title=imdb_id, media_type=MediaType.MOVIE)
    try:
        releases, total_cached, by_service = await _client.releases(item, fresh=True)
    except Exception as exc:
        raise HTTPException(502, f"Search failed: {exc}")
    from datetime import datetime, timezone as _tz
    released_at = await _movie_release_dt(imdb_id)
    return {
        "imdb_id": imdb_id, "source": _client.search_source(), "releases": releases,
        "total_cached": total_cached, "by_service": by_service,
        "released": released_at.isoformat() if released_at else None,
        "unreleased": bool(released_at and released_at > datetime.now(_tz.utc)),
        "in_library": [s.quality.value for s in _stubs.listed() if s.imdb_id == imdb_id and s.media_type == MediaType.MOVIE],
    }


class AddReleaseReq(BaseModel):
    hash: str
    title: str
    year: Optional[int] = None
    poster: Optional[str] = None
    # Which debrid service to bind through. Comes straight from the release
    # row the admin clicked, so a release listed as cached on AllDebrid is
    # added through AllDebrid rather than being re-checked on TorBox.
    service: Optional[str] = None


@app.post("/api/movies/{imdb_id}/releases/add")
async def add_movie_release(imdb_id: str, req: AddReleaseReq):
    """Admin: add one specific release. Its quality tier (HD/4K) comes from
    the file; it replaces whatever is already filed in that tier."""
    from gateway import torbox_api as _tb
    from gateway.torbox_client import FileNotInTorrent
    if not re.match(r"^[a-fA-F0-9]{40}$", req.hash or ""):
        raise HTTPException(400, "Invalid torrent hash")
    item = MediaItem(id=imdb_id, imdb_id=imdb_id, title=req.title, year=req.year, media_type=MediaType.MOVIE)
    item._poster = req.poster or ""
    try:
        stream = await _client.bind_hash(item, req.hash, req.service)
    except FileNotInTorrent as exc:
        raise HTTPException(400, f"That release has no playable video file: {exc}")
    except _tb.TorBoxError as exc:
        who = "AllDebrid" if (req.service or "").lower() == "alldebrid" else "TorBox"
        if not exc.retryable:
            raise HTTPException(409, f"{who} doesn't have that release cached")
        raise HTTPException(503, f"{who} is busy — try again shortly ({exc})")
    quality = stream.quality
    sid_existing = next((s for s in _stubs.all() if s.media_id == imdb_id and s.quality == quality), None)
    if sid_existing:
        await _stubs.set_active(sid_existing.stub_id, stream.url, {}, stream.size)
        stub = sid_existing
    else:
        stub = await _stubs.create_stub_for_quality(item, quality, stream)
    from gateway import pending_movies as _pending_mv
    _pending_mv.remove(imdb_id)
    return {"ok": True, "stub_id": stub.stub_id, "quality": quality.value, "file": stream.filename}


@app.post("/api/repair/run")
async def run_repair_now(stub_id: Optional[str] = None):
    """Repair one entry right now, or wake the repair loop for everything."""
    if stub_id:
        if not _stubs.get(stub_id):
            raise HTTPException(404, "Not found")
        return {"stub_id": stub_id, "result": await _stubs.repair(stub_id)}
    for s in _stubs.all():
        if s.state != StubState.ACTIVE:
            s.last_error_at = None
    _stubs.wake_repair()
    return {"queued": sum(1 for s in _stubs.all() if s.state != StubState.ACTIVE)}


@app.post("/api/torbox/clear-search-cache")
async def torbox_clear_search_cache(imdb_id: Optional[str] = None):
    """Forget cached search results (all, or one title) so the next scan
    re-queries TorBox — e.g. right after a release you know just landed."""
    from gateway import torbox_guard as _g
    await asyncio.to_thread(_g.store().drop_search, f"search:{imdb_id}:" if imdb_id else "search:")
    return {"ok": True}


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    all_s = _stubs.all()
    return {"status": "ok", "stubs": len(all_s),
            "active": sum(1 for s in all_s if s.state == StubState.ACTIVE),
            "repairing": sum(1 for s in all_s if s.state == StubState.ERROR),
            "unbound": sum(1 for s in all_s if s.state == StubState.UNBOUND),
            "torbox_key_source": _torbox_key_source()[1] or "not set",
            "torbox": {k: v for k, v in _client.stats().items() if k in ("calls_last_minute", "http_429", "breaker_open")}}
