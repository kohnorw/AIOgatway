"""
AIOGateway — FastAPI + NuvioWeb-style UI using Cinemeta for metadata.

Cinemeta (v3-cinemeta.strem.io) is the same free metadata source used by
NuvioWeb/NuvioTV. No API key needed. Returns IMDb IDs, posters/backdrops
from TMDB CDN. Endpoints:
  /catalog/movie/top.json  → popular movies
  /catalog/series/top.json → popular series
  /meta/{type}/{imdb_id}.json → single item detail

Endpoints
---------
GET  /                           NuvioWeb-style browse UI
GET  /api/config                 Env config
GET  /api/test                   AIOStreams connectivity test
GET  /api/cinemeta/{path}        Cinemeta proxy (no CORS issues from browser)
POST /api/add                    Add media → AIOStreams → stub files
GET  /api/stubs                  List stubs
DELETE /api/stubs/{id}           Delete stub + file

POST /webhook/plex               Plex play event
GET  /proxy/{stub_id}            Stream proxy → Plex
HEAD /proxy/{stub_id}            HEAD pre-flight
GET  /health                     Health
"""
from __future__ import annotations

import asyncio
import copy
import json
import logging
import os
import re
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

import aiohttp
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from pydantic import BaseModel

from gateway.aiostreams_client import AIOStreamsClient, _probe_stream
from gateway.fuse_fs import mount as fuse_mount, unmount as fuse_unmount, FUSE_AVAILABLE
from gateway.models import MediaItem, MediaType, Quality, StubState
from gateway.proxy import StreamProxy
from gateway.stub_manager import StubManager
from webhook.handler import PlexWebhookHandler

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s — %(message)s")
logger = logging.getLogger("aiogateway")

_stubs   = StubManager()
_proxy   = StreamProxy()
_client  = AIOStreamsClient()
_webhook: PlexWebhookHandler | None = None
_http:    aiohttp.ClientSession | None = None

CINEMETA = "https://v3-cinemeta.strem.io"


def _emergency_unmount():
    if not FUSE_AVAILABLE:
        return
    mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    try:
        logger.info("Emergency unmount: %s", mountpoint)
        fuse_unmount(mountpoint)
    except Exception as exc:
        logger.warning("Emergency unmount error: %s", exc)


import atexit
import signal as _signal

# Register atexit so normal Python exit always unmounts
atexit.register(_emergency_unmount)


def _signal_handler(signum, frame):
    logger.info("Signal %d received — unmounting FUSE and exiting", signum)
    _emergency_unmount()
    # Re-raise default handler so the process exits with the right code
    _signal.signal(signum, _signal.SIG_DFL)
    os.kill(os.getpid(), signum)


# Catch SIGTERM (docker stop) and SIGINT (Ctrl-C)
for _sig in (_signal.SIGTERM, _signal.SIGINT):
    try:
        _signal.signal(_sig, _signal_handler)
    except (OSError, ValueError):
        pass   # may fail in non-main thread contexts


_ttl_sweep_task: Optional[asyncio.Task] = None
_TTL_SWEEP_INTERVAL = 600   # 10 minutes — fine-grained enough for a day-scale TTL

async def _ttl_sweep_loop():
    """
    Periodically reverts ACTIVE stubs older than the fixed active-file
    TTL (settings.ACTIVE_TTL_DAYS) back to PLACEHOLDER, as long as
    active_ttl_enabled is on. The toggle is re-read each cycle so
    flipping it from the UI takes effect without a restart.

    One TTL governs everything: the sweep filters on state and age only,
    so HD and 4K, movies and series all expire on identical terms. The
    per-folder breakdown is logged purely so that's visible in the logs.
    """
    from gateway import settings as _settings
    while True:
        try:
            await asyncio.sleep(_TTL_SWEEP_INTERVAL)
            ttl = _settings.get_effective_ttl_days()
            if ttl and ttl > 0:
                result = await _stubs.sweep_expired_breakdown(ttl)
                if result["total"]:
                    detail = ", ".join(
                        f"{folder} {n}" for folder, n in sorted(result["by_folder"].items())
                    )
                    logger.info(
                        "TTL sweep: reverted %d stub(s) to placeholder (ttl=%g days) — %s",
                        result["total"], ttl, detail,
                    )
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("TTL sweep error: %s", exc)


_auto_episodes_task: Optional[asyncio.Task] = None

async def _auto_episodes_loop():
    """
    Periodically checks every tracked series for newly-aired episodes and
    auto-stubs them (HD + 4K where available) — see gateway/auto_episodes.py
    for the actual discovery/retry logic. The interval and enable/disable
    setting are re-read each cycle so changes from the UI take effect
    without a restart.

    References _query_episode, _yield_to_play_priority, and
    _fast_track_pack_season by name rather than importing them — all
    three are defined later in this module, but since this loop only
    ever calls them at runtime (after the whole module has finished
    loading), that's safe and avoids reordering a large amount of
    existing code just to satisfy import order.
    """
    from gateway import settings as _settings
    from gateway import auto_episodes as _auto_ep
    while True:
        try:
            interval_min = _settings.get("auto_episodes_interval_minutes", 30)
            await asyncio.sleep(max(60, interval_min * 60))
            if not _settings.get("auto_episodes_enabled", True):
                continue
            result = await _auto_ep.run_sweep(_stubs, _http, _query_episode, _yield_to_play_priority,
                                              fast_track_pack_fn=_fast_track_pack_season)
            if result.get("new_stubs"):
                logger.info("Auto-episode sweep: %s", result)
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("Auto-episode sweep error: %s", exc)


_pending_movies_task: Optional[asyncio.Task] = None
# Two prewarm tasks now, not one: the event-driven worker that reacts to
# stub creation (the path that actually makes newly-added content get
# prewarmed) and the periodic/startup backstop sweep. See the prewarm
# section further down for the full picture.
_prewarm_task: Optional[asyncio.Task] = None          # backstop sweep
_prewarm_new_stub_task: Optional[asyncio.Task] = None  # event-driven

async def _pending_movies_loop():
    """
    Periodically retries every tracked-but-unresolved movie — see
    gateway/pending_movies.py. Reuses auto_episodes_interval_minutes for
    cadence rather than introducing a second interval setting; the two
    sweeps are conceptually the same kind of "keep checking until it
    shows up" background job, just for movies vs. episodes.

    References _query_movie by name rather than importing it — it's
    defined later in this module, but since this loop only calls it at
    runtime (after the whole module has finished loading), that's safe.
    """
    from gateway import settings as _settings
    from gateway import pending_movies as _pending_mv
    while True:
        try:
            interval_min = _settings.get("auto_episodes_interval_minutes", 30)
            await asyncio.sleep(max(60, interval_min * 60))
            result = await _pending_mv.run_sweep(_query_movie, yield_fn=_yield_to_play_priority)
            if result.get("resolved"):
                logger.info("Pending-movie sweep: %s", result)
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("Pending-movie sweep error: %s", exc)


async def _warm_calendar_cache_once():
    """
    Pre-fetches the calendar's default window (same days_back/days_ahead
    the API defaults to, matching the common case of opening the tab on
    the current month) once, shortly after startup, in the background —
    so the FIRST click on the Calendar tab hits an already-warm cache
    instead of paying the full concurrent-Cinemeta-fetch cost right at
    that moment. References get_calendar by name rather than importing;
    safe since this only runs well after the whole module has loaded.
    """
    try:
        await asyncio.sleep(5)   # let the rest of startup settle first
        await get_calendar(days_back=14, days_ahead=30)
        logger.info("Calendar cache pre-warmed at startup")
    except Exception as exc:
        logger.warning("Calendar cache warm-up failed: %s", exc)


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _webhook, _http, _ttl_sweep_task, _auto_episodes_task, _pending_movies_task
    global _prewarm_task, _prewarm_new_stub_task
    await _proxy.open()
    await _client.open()
    _http    = aiohttp.ClientSession(headers={"User-Agent": "AIOGateway/0.3"})
    _webhook = PlexWebhookHandler(_stubs, _client, _play_priority_enter, _play_priority_exit)
    restored = await _stubs.restore()
    logger.info("AIOGateway started — %d stubs restored", restored)

    from gateway import settings as _settings
    _settings.load()

    # Stub history holds the facts that must outlive a stub object —
    # first_seen_at and dead-source tracking. Backfill it from what's on
    # disk so an existing library doesn't start with an empty ledger and
    # treat every restored stub as first-seen-now.
    try:
        from gateway import stub_history as _hist
        live_ids = set()
        backfilled = 0
        for s in _stubs.all():
            live_ids.add(s.stub_id)
            seen = getattr(s, "first_seen_at", None) or s.created_at
            recorded = _hist.note_created(s.stub_id, seen)
            if s.first_seen_at is None:
                s.first_seen_at = recorded
                backfilled += 1
        pruned = _hist.prune(live_ids)
        if backfilled or pruned:
            logger.info("Stub history: backfilled %d, pruned %d stale record(s)",
                        backfilled, pruned)
    except Exception as exc:
        logger.warning("Could not initialise stub history: %s", exc)

    # Mount virtual FUSE filesystem
    mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    if FUSE_AVAILABLE:
        fuse_mount(_stubs, _client, mountpoint)
        logger.info("FUSE mounted at %s", mountpoint)
    else:
        logger.warning("FUSE unavailable — stub files will be served directly (no seeking)")

    _ttl_sweep_task = asyncio.create_task(_ttl_sweep_loop())
    _auto_episodes_task = asyncio.create_task(_auto_episodes_loop())
    _pending_movies_task = asyncio.create_task(_pending_movies_loop())
    # Prewarming reacts to stub creation rather than only to a timer —
    # register the callback BEFORE anything can create stubs, so nothing
    # added during this boot slips past it.
    _stubs.on_stub_created(_note_new_stub_for_prewarm)
    _prewarm_new_stub_task = asyncio.create_task(_prewarm_new_stub_worker())
    _prewarm_task = asyncio.create_task(_prewarm_sweep_loop())
    asyncio.create_task(_warm_calendar_cache_once())

    try:
        yield
    finally:
        # Clean shutdown path — also covered by atexit but explicit is better
        if _ttl_sweep_task:
            _ttl_sweep_task.cancel()
        if _auto_episodes_task:
            _auto_episodes_task.cancel()
        if _pending_movies_task:
            _pending_movies_task.cancel()
        if _prewarm_task:
            _prewarm_task.cancel()
        if _prewarm_new_stub_task:
            _prewarm_new_stub_task.cancel()
        if FUSE_AVAILABLE:
            fuse_unmount(mountpoint)
        await _proxy.close()
        await _client.close()
        if _http: await _http.close()


app = FastAPI(title="AIOGateway", version="0.3.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
# Note: allow_credentials is NOT set (defaults to False) — combined with
# allow_origins=["*"], browsers will never send the session cookie on a
# cross-origin request regardless, since credentialed cross-origin
# requests specifically require a named origin, not a wildcard. The
# wildcard here is safe to leave as-is alongside cookie-based auth.

# ---------------------------------------------------------------------------
# Auth middleware — every request except an explicit public allowlist
# requires a valid session; "user" role is further restricted to the
# specific endpoints Home/Search/Calendar actually use. See gateway/auth.py
# for the session security model itself.
# ---------------------------------------------------------------------------
import re as _authre
from starlette.middleware.base import BaseHTTPMiddleware

_AUTH_PUBLIC_PATHS = {"/", "/api/auth/plex/start", "/api/auth/me", "/webhook/plex"}
_AUTH_PUBLIC_PREFIXES = ("/proxy/",)
_AUTH_PUBLIC_REGEXES = [
    _authre.compile(r"^/api/auth/plex/poll/[^/]+$"),
]

# Endpoints a plain "user" role account may reach — everything else
# requires role=admin. Deliberately an allowlist (fail-closed) rather
# than a denylist, given how much surface this app has: anything not
# explicitly listed here is admin-only by default, not by omission.
_AUTH_USER_ALLOWED_REGEXES = [
    _authre.compile(r"^/api/cinemeta/"),
    _authre.compile(r"^/api/calendar$"),
    _authre.compile(r"^/api/stubs$"),
    _authre.compile(r"^/api/add$"),
    _authre.compile(r"^/api/series/[^/]+/episodes$"),
    _authre.compile(r"^/api/series/[^/]+/episode/\d+/\d+$"),
    _authre.compile(r"^/api/series/[^/]+/season-watch$"),
    _authre.compile(r"^/api/auth/logout$"),
]


class _AuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        path = request.url.path

        if (
            path in _AUTH_PUBLIC_PATHS
            or any(path.startswith(p) for p in _AUTH_PUBLIC_PREFIXES)
            or any(rx.match(path) for rx in _AUTH_PUBLIC_REGEXES)
        ):
            return await call_next(request)

        from gateway import auth as _auth

        # Static API key — the scripting path (Config → API, or
        # AIOGW_API_KEY). A plain header: no cookie, no session, no
        # expiry, and no in-memory cache that can go stale.
        api_tok = request.headers.get(_auth.API_KEY_HEADER)
        if api_tok and _auth.validate_api_key(api_tok):
            request.state.user = {"plex_user_id": "_api", "username": "api-key",
                                  "role": "admin"}
            return await call_next(request)

        token = request.cookies.get(_auth.SESSION_COOKIE_NAME)
        user = _auth.validate_session(token, request.headers.get("user-agent", ""))
        if not user:
            return JSONResponse({"detail": "Not authenticated"}, status_code=401)

        request.state.user = user

        if user.get("role") != "admin" and not any(
            rx.match(path) for rx in _AUTH_USER_ALLOWED_REGEXES
        ):
            return JSONResponse({"detail": "Admin access required"}, status_code=403)

        return await call_next(request)


app.add_middleware(_AuthMiddleware)

# ---------------------------------------------------------------------------
# Auth — Plex OAuth PIN login, session, and admin user management
# ---------------------------------------------------------------------------

@app.post("/api/auth/plex/start")
async def auth_plex_start(request: Request):
    from gateway import auth as _auth
    try:
        result = await _auth.start_plex_login(request.client.host if request.client else "unknown")
    except RuntimeError as exc:
        raise HTTPException(429, str(exc))
    except Exception as exc:
        logger.warning("Could not start Plex login: %s", exc)
        raise HTTPException(502, "Could not reach Plex — try again in a moment.")
    return result


@app.get("/api/auth/plex/poll/{pin_id}")
async def auth_plex_poll(pin_id: str, request: Request, response: Response):
    from gateway import auth as _auth
    try:
        result = await _auth.poll_plex_login(
            pin_id,
            request.headers.get("user-agent", ""),
            request.client.host if request.client else "unknown",
        )
    except RuntimeError as exc:
        raise HTTPException(400, str(exc))
    except Exception as exc:
        logger.warning("Plex login poll failed: %s", exc)
        raise HTTPException(502, "Could not verify the Plex login — try again.")

    if result is None:
        return {"status": "waiting"}

    response.set_cookie(
        _auth.SESSION_COOKIE_NAME,
        result["session_token"],
        httponly=True,
        secure=_auth.cookie_secure_for_request(request),
        samesite="strict",
        max_age=int(_auth.SESSION_MAX_AGE_DAYS * 86400),
        path="/",
    )
    return {"status": "ok", "user": result["user"]}


@app.get("/api/auth/me")
async def auth_me(request: Request):
    """Whether the current request has a valid session, and who it
    belongs to — the frontend uses this on load to decide whether to
    show the login screen or the main app, and which nav tabs to show."""
    from gateway import auth as _auth
    token = request.cookies.get(_auth.SESSION_COOKIE_NAME)
    user = _auth.validate_session(token, request.headers.get("user-agent", ""))
    if not user:
        return JSONResponse({"authenticated": False}, status_code=401)
    return {
        "authenticated": True,
        "user": {k: v for k, v in user.items() if k != "plex_token"},
    }


@app.post("/api/auth/logout")
async def auth_logout(request: Request, response: Response):
    from gateway import auth as _auth
    token = request.cookies.get(_auth.SESSION_COOKIE_NAME)
    if token:
        _auth.destroy_session(token)
    response.delete_cookie(_auth.SESSION_COOKIE_NAME, path="/")
    return {"ok": True}


def _require_admin(request: Request) -> dict:
    user = getattr(request.state, "user", None)
    if not user or user.get("role") != "admin":
        raise HTTPException(403, "Admin access required")
    return user


@app.get("/api/users")
async def list_users(request: Request):
    _require_admin(request)
    from gateway import auth as _auth
    return {"users": _auth.list_users()}


class SetRoleReq(BaseModel):
    role: str   # "admin" | "user"


@app.post("/api/users/{plex_user_id}/role")
async def set_user_role(plex_user_id: str, req: SetRoleReq, request: Request):
    admin = _require_admin(request)
    from gateway import auth as _auth
    if req.role not in ("admin", "user"):
        raise HTTPException(400, "role must be 'admin' or 'user'")
    # Don't allow demoting the last remaining admin — that would lock
    # everyone out of Config/Library with no way back in short of
    # editing the users file directly on disk.
    if (
        req.role == "user"
        and plex_user_id == admin["plex_user_id"]
        and _auth.admin_count() <= 1
    ):
        raise HTTPException(400, "Can't demote the last remaining admin.")
    ok = _auth.set_role(plex_user_id, req.role)
    if not ok:
        raise HTTPException(404, "User not found")
    return {"ok": True}


@app.delete("/api/users/{plex_user_id}")
async def remove_user(plex_user_id: str, request: Request):
    _require_admin(request)          # gate only; the caller isn't needed here
    from gateway import auth as _auth
    user = _auth.get_user(plex_user_id)
    if user and user.get("role") == "admin" and _auth.admin_count() <= 1:
        raise HTTPException(400, "Can't remove the last remaining admin.")
    ok = _auth.delete_user(plex_user_id)
    if not ok:
        raise HTTPException(404, "User not found")
    return {"ok": True}


# ---------------------------------------------------------------------------
# Cinemeta proxy  —  /api/cinemeta/{path}
# ---------------------------------------------------------------------------

@app.get("/api/cinemeta/{path:path}")
async def cinemeta_proxy(path: str):
    """Proxy Cinemeta requests from the browser to avoid any CORS issues."""
    assert _http
    url = f"{CINEMETA}/{path}"
    try:
        async with _http.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
            data = await resp.json(content_type=None)
            return JSONResponse(data, status_code=resp.status)
    except Exception as exc:
        logger.error("Cinemeta proxy error %s: %s", url, exc)
        raise HTTPException(502, f"Cinemeta unreachable: {exc}")


# ---------------------------------------------------------------------------
# Embedded NuvioWeb-style UI
# ---------------------------------------------------------------------------

UI_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>AIOGateway</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet"/>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#080810;--sur:#10101a;--card:#14141f;--card2:#1a1a28;
  --bor:rgba(255,255,255,.08);--bor2:rgba(255,255,255,.14);
  --txt:#f0f0f8;--mut:#7878a0;--acc:#e8a020;--acc2:#f5b840;
  --blue:#4a9eff;--grn:#3dd68c;--red:#ff5555;
  --navh:64px;--f:'Inter',system-ui,sans-serif;
}
html,body{height:100%;background:var(--bg);color:var(--txt);font-family:var(--f);font-size:15px;line-height:1.5;-webkit-font-smoothing:antialiased;overflow-x:hidden;scroll-behavior:smooth}

/* ── Nav pill ───────────────────────────────────────────────── */
.nav{
  position:fixed;top:18px;left:50%;transform:translateX(-50%);z-index:100;
  display:flex;align-items:center;gap:2px;
  background:rgba(8,8,16,.85);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);
  border:1px solid var(--bor2);border-radius:50px;padding:5px 6px;
}
.ni{
  display:flex;align-items:center;gap:6px;padding:8px 20px;
  border-radius:40px;font-size:14px;font-weight:600;cursor:pointer;
  border:none;background:none;color:var(--mut);font-family:var(--f);
  transition:all 150ms;white-space:nowrap;
}
.ni:hover{color:var(--txt);background:rgba(255,255,255,.07)}
.ni.on{background:rgba(255,255,255,.12);color:var(--txt)}

/* ── Hero ───────────────────────────────────────────────────── */
.hero{position:relative;height:100vh;max-height:600px;min-height:420px;overflow:hidden;display:flex;align-items:flex-end}
.hero-bg{
  position:absolute;inset:0;
  background-size:cover;background-position:center 20%;
  transition:background-image .5s ease;
}
.hero-ov{
  position:absolute;inset:0;
  background:linear-gradient(to bottom,
    rgba(8,8,16,.2) 0%,
    rgba(8,8,16,.0) 20%,
    rgba(8,8,16,.5) 55%,
    rgba(8,8,16,.95) 85%,
    var(--bg) 100%);
}
.hero-body{position:relative;z-index:2;padding:0 56px 48px;max-width:620px}
.hero-logo{max-height:64px;max-width:280px;margin-bottom:14px;object-fit:contain;filter:drop-shadow(0 2px 12px rgba(0,0,0,.8));display:none}
.hero-title{font-size:56px;font-weight:900;letter-spacing:-2px;line-height:1;margin-bottom:10px;text-shadow:0 2px 20px rgba(0,0,0,.9)}
.hero-meta{display:flex;align-items:center;gap:10px;font-size:14px;color:rgba(255,255,255,.7);font-weight:500;margin-bottom:10px}
.hero-sep{opacity:.4}
.hero-rating{background:rgba(255,255,255,.15);border-radius:5px;padding:2px 8px;font-size:12px;font-weight:700;color:var(--acc2)}
.hero-desc{font-size:14px;color:rgba(255,255,255,.65);line-height:1.6;margin-bottom:20px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.hero-dots{display:flex;gap:5px;margin-bottom:22px}
.hero-dot{width:24px;height:3px;border-radius:2px;background:rgba(255,255,255,.25);cursor:pointer;transition:all 200ms}
.hero-dot.on{background:#fff;width:32px}
.hero-acts{display:flex;gap:10px}
.btn-hero{
  display:flex;align-items:center;gap:8px;padding:12px 28px;border-radius:8px;
  font-family:var(--f);font-size:14px;font-weight:700;cursor:pointer;border:none;transition:all 150ms;
}
.btn-add{background:var(--acc);color:#000}
.btn-add:hover{background:var(--acc2);transform:translateY(-1px)}
.btn-add.added{background:var(--grn);color:#000}
.btn-info{background:rgba(255,255,255,.16);color:#fff;backdrop-filter:blur(8px)}
.btn-info:hover{background:rgba(255,255,255,.26)}

/* ── Content rows ───────────────────────────────────────────── */
.rows{padding-bottom:48px}
.sec{margin-bottom:8px}
.sec-hd{display:flex;align-items:center;justify-content:space-between;padding:0 56px;margin-bottom:16px}
.sec-title{font-size:18px;font-weight:700;letter-spacing:-.3px;border-left:3px solid var(--acc);padding-left:12px}
.view-all{font-size:13px;font-weight:600;color:var(--mut);cursor:pointer;background:none;border:none;font-family:var(--f);display:flex;align-items:center;gap:3px}
.view-all:hover{color:var(--txt)}
.row{display:flex;gap:14px;overflow-x:auto;overflow-y:visible;padding:4px 56px 14px;scrollbar-width:none}
.row::-webkit-scrollbar{display:none}

/* ── Card ───────────────────────────────────────────────────── */
.card{flex:0 0 138px;cursor:pointer;position:relative;transition:transform 200ms}
.card:hover{transform:scale(1.07) translateY(-2px)}
.cposter{width:138px;height:207px;border-radius:10px;overflow:hidden;background:var(--card2);position:relative;box-shadow:0 4px 16px rgba(0,0,0,.4)}
.card.inlib .cposter{box-shadow:0 0 0 2px var(--grn),0 4px 16px rgba(0,0,0,.4)}
.cposter img{width:100%;height:100%;object-fit:cover;display:block;opacity:0;transition:opacity .3s}
.cposter img.loaded{opacity:1}
.crating{position:absolute;top:7px;right:7px;background:rgba(0,0,0,.78);backdrop-filter:blur(4px);border-radius:5px;padding:2px 7px;font-size:11px;font-weight:700;color:var(--acc2)}
.ccheck{position:absolute;top:7px;right:7px;width:22px;height:22px;border-radius:50%;background:var(--grn);display:none;align-items:center;justify-content:center;font-size:12px;color:#000;font-weight:800}
.card.inlib .ccheck{display:flex}
.card.inlib .crating{display:none}
.cname{font-size:12px;font-weight:600;margin-top:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cyear{font-size:11px;color:var(--mut);margin-top:2px}

/* ── Search page ─────────────────────────────────────────────── */
/* Same padding rhythm and surface tokens as Library/Config pages */
.srchpage{padding:calc(var(--navh) + 28px) 56px 48px}
.srch-hd{margin-bottom:28px}
.srch-bar-wrap{
  display:flex;align-items:center;gap:10px;
  background:var(--card2);border:1px solid var(--bor2);
  border-radius:10px;padding:12px 16px;
  transition:border-color 180ms;
}
.srch-bar-wrap:focus-within{border-color:var(--acc)}
.srch-icon{font-size:17px;color:var(--mut);flex-shrink:0}
.srch-input{
  background:none;border:none;outline:none;font-family:var(--f);
  font-size:15px;color:var(--txt);width:100%;font-weight:500;
}
.srch-input::placeholder{color:var(--mut)}
.srch-clear{
  background:var(--card);border:1px solid var(--bor2);border-radius:7px;
  color:var(--mut);font-size:12px;padding:5px 11px;cursor:pointer;
  font-family:var(--f);font-weight:600;white-space:nowrap;flex-shrink:0;
  transition:all 150ms;display:none;
}
.srch-clear:hover{color:var(--txt);border-color:var(--acc)}
.srch-tabs{display:flex;gap:6px;margin-top:14px}
.srch-tab{
  padding:7px 18px;border-radius:30px;font-size:13px;font-weight:600;
  cursor:pointer;border:1px solid var(--bor2);background:none;
  color:var(--mut);font-family:var(--f);transition:all 150ms;
}
.srch-tab:hover{color:var(--txt)}
.srch-tab.on{background:var(--acc);color:#000;border-color:var(--acc)}
.srch-status{font-size:13px;color:var(--mut);margin-bottom:18px;min-height:20px}
.srch-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(138px,1fr));
  gap:22px 14px;
}
.srch-empty{
  grid-column:1/-1;text-align:center;padding:60px 20px;
  color:var(--mut);
}
.srch-empty-icon{font-size:36px;margin-bottom:12px;opacity:.3}
.srch-empty-title{font-size:14px;font-weight:600;margin-bottom:4px}
.srch-empty-sub{font-size:12px;opacity:.7}

/* ── View All overlay ───────────────────────────────────────── */
.va-overlay{
  position:fixed;inset:0;background:var(--bg);z-index:150;
  overflow-y:auto;scrollbar-width:none;
  opacity:0;pointer-events:none;transition:opacity 200ms;
}
.va-overlay::-webkit-scrollbar{display:none}
.va-overlay.open{opacity:1;pointer-events:all}
.va-inner{padding:calc(var(--navh) + 28px) 56px 48px}
.va-header{display:flex;align-items:center;gap:18px;margin-bottom:28px}
.va-back{
  display:flex;align-items:center;gap:6px;
  background:var(--card2);border:1px solid var(--bor2);border-radius:8px;
  padding:8px 16px;font-family:var(--f);font-size:13px;font-weight:600;
  color:var(--mut);cursor:pointer;transition:all 150ms;flex-shrink:0;
}
.va-back:hover{color:var(--txt);border-color:var(--acc)}
.va-title{font-size:22px;font-weight:800;letter-spacing:-.4px}
.va-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(138px,1fr));
  gap:22px 14px;
}

/* ── Season picker ──────────────────────────────────────────── */
.season-picker{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px}
.season-btn{
  padding:5px 14px;border-radius:6px;font-size:12px;font-weight:700;
  cursor:pointer;border:1px solid var(--bor2);background:var(--card2);
  color:var(--mut);font-family:var(--f);transition:all 140ms;
}
.season-btn:hover{border-color:var(--acc);color:var(--txt)}
.season-btn.on{background:var(--acc);color:#000;border-color:var(--acc)}
.season-btn.all-btn{background:var(--card2);color:var(--txt);border-color:var(--bor2)}
.season-btn.all-btn.on{background:var(--acc);color:#000}
/* Already-requested season: filled green. Selection (.on) still takes
   visual priority if the user has that season actively picked, so a
   requested season that's also selected shows the accent (orange) state
   rather than competing colors. */
.season-btn.requested{background:var(--grn);color:#000;border-color:var(--grn)}
.season-btn.requested:hover{border-color:var(--grn);color:#000}
.season-btn.requested.on{background:var(--acc);color:#000;border-color:var(--acc)}

/* ── Skeleton ───────────────────────────────────────────────── */
.skel{background:linear-gradient(90deg,var(--card) 25%,var(--card2) 50%,var(--card) 75%);background-size:200% 100%;animation:shim 1.5s infinite;border-radius:10px}
@keyframes shim{0%{background-position:200% 0}100%{background-position:-200% 0}}

/* ── Modal ──────────────────────────────────────────────────── */
.mbg{position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);z-index:200;display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;transition:opacity 180ms}
.mbg.open{opacity:1;pointer-events:all}
.modal{background:var(--card);border:1px solid var(--bor2);border-radius:18px;width:92%;max-width:520px;overflow:hidden;transform:scale(.94) translateY(12px);transition:transform 180ms}
.mbg.open .modal{transform:scale(1) translateY(0)}
.mhero{height:220px;background-size:cover;background-position:center;position:relative}
.mhero-ov{position:absolute;inset:0;background:linear-gradient(to bottom,rgba(20,20,31,.2) 0%,var(--card) 100%)}
.mbody{padding:20px 24px 26px}
.mtitle{font-size:22px;font-weight:800;letter-spacing:-.5px;margin-bottom:6px}
.mmeta{display:flex;gap:9px;font-size:13px;color:var(--mut);margin-bottom:10px;flex-wrap:wrap;align-items:center}
.mrating{background:var(--card2);border:1px solid var(--bor);padding:2px 8px;border-radius:5px;font-size:11px;font-weight:700;color:var(--acc2)}
.mpills{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:14px}
.mpill{background:var(--card2);border:1px solid var(--bor);padding:3px 11px;border-radius:20px;font-size:12px;font-weight:500}
.moverview{font-size:13px;color:var(--mut);line-height:1.7;margin-bottom:22px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.macts{display:flex;gap:10px}
.mbtn{flex:1;display:flex;align-items:center;justify-content:center;gap:7px;padding:12px;border-radius:9px;font-family:var(--f);font-size:13px;font-weight:700;cursor:pointer;border:none;transition:all 150ms}
.mbtn-add{background:var(--acc);color:#000}
.mbtn-add:hover{background:var(--acc2)}
.mbtn-add.added{background:var(--grn);color:#000}
.mbtn-add.pending{background:var(--blue);color:#04111f}
.mbtn-close{background:var(--card2);color:var(--mut);border:1px solid var(--bor2)}
.mbtn-close:hover{color:var(--txt)}
.mclose{position:absolute;top:14px;right:14px;z-index:10;width:30px;height:30px;border-radius:50%;background:rgba(0,0,0,.6);border:none;color:#fff;font-size:15px;cursor:pointer;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px)}
.mclose:hover{background:rgba(0,0,0,.9)}

/* ── Library page ───────────────────────────────────────────── */
.libpage{padding:calc(var(--navh) + 28px) 56px 48px}
.libhd{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px}
.libtitle{font-size:28px;font-weight:800;letter-spacing:-.5px}
.libgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(138px,1fr));gap:22px 14px}
.stub-state{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;margin-top:5px}
.ss-ph{background:#2a2a14;color:#c8a030}
.ss-ac{background:#0d2a18;color:var(--grn)}
.ss-er{background:#2a0d0d;color:var(--red)}
.ss-rs{background:#141e2e;color:var(--blue);animation:sblink 1.1s infinite}
@keyframes sblink{0%,100%{opacity:1}50%{opacity:.35}}
.del-btn{width:26px;height:26px;border-radius:50%;background:rgba(0,0,0,.7);border:none;color:#888;font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all 130ms}
.del-btn:hover{background:var(--red);color:#fff}

/* ── Search ─────────────────────────────────────────────────── */
.searchbar{display:flex;align-items:center;gap:9px;background:var(--card2);border:1px solid var(--bor2);border-radius:10px;padding:9px 15px}
.searchbar input{background:none;border:none;outline:none;font-family:var(--f);font-size:14px;color:var(--txt);width:100%}
.searchbar input::placeholder{color:var(--mut)}

/* ── Calendar ─────────────────────────────────────────────────── */
.cal-day{margin-bottom:28px}
.cal-day-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--mut);margin-bottom:10px;display:flex;align-items:center;gap:10px}
.cal-day-label::after{content:'';flex:1;height:1px;background:var(--bor)}
.cal-day-label.today{color:var(--acc)}
.cal-entries{display:flex;flex-direction:column;gap:8px}
.cal-entry{background:var(--card);border:1px solid var(--bor);border-radius:12px;padding:12px 14px;display:flex;align-items:center;gap:14px;cursor:pointer;transition:border-color 140ms}
.cal-entry:hover{border-color:var(--bor2)}
.cal-entry.inlib{border-left:3px solid var(--grn)}
.cal-entry.future{opacity:.75}
.cal-poster{width:38px;height:57px;border-radius:5px;object-fit:cover;flex-shrink:0;background:var(--card2)}
.cal-poster-placeholder{width:38px;height:57px;border-radius:5px;background:var(--card2);flex-shrink:0;display:flex;align-items:center;justify-content:center;color:var(--mut);font-size:18px}
.cal-info{flex:1;min-width:0}
.cal-title{font-size:14px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cal-sub{font-size:12px;color:var(--mut);margin-top:2px}
.cal-badges{display:flex;gap:6px;margin-top:6px;flex-wrap:wrap}
.cal-badge{font-size:10px;font-weight:700;padding:2px 7px;border-radius:4px;background:var(--card2);color:var(--mut)}
.cal-badge.inlib{background:#0d2a18;color:var(--grn)}
.cal-badge.theatrical{background:#1a1a10;color:#a89050}
.cal-badge.stale{background:#241a10;color:var(--acc2)}
.cal-rescan-btn{font-size:11px;font-weight:700;padding:5px 12px;border-radius:6px;border:1px solid var(--bor2);background:none;color:var(--mut);cursor:pointer;flex-shrink:0;transition:all 140ms;white-space:nowrap}
.cal-rescan-btn:hover{border-color:var(--acc);color:var(--acc)}
.cal-rescan-btn.active{border-color:var(--grn);color:var(--grn)}
.cal-rescan-btn.pending{color:var(--blue);border-color:var(--blue)}

/* ── Calendar: month grid ── */
.cal-chips{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px}
.cal-chip{font-size:12px;font-weight:700;padding:6px 13px;border-radius:50px;border:1px solid var(--bor2);background:none;color:var(--mut);cursor:pointer;transition:all 140ms;font-family:var(--f)}
.cal-chip:hover{border-color:var(--acc);color:var(--txt)}
.cal-chip.on{background:var(--acc);color:#000;border-color:var(--acc)}
.cal-monthbar{display:flex;align-items:center;justify-content:center;gap:18px;margin-bottom:16px}
.cal-navbtn{width:32px;height:32px;border-radius:8px;border:1px solid var(--bor2);background:var(--card);color:var(--mut);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:16px;transition:all 140ms}
.cal-navbtn:hover{border-color:var(--acc);color:var(--acc)}
.cal-monthlabel{font-size:16px;font-weight:700;letter-spacing:-.2px;min-width:160px;text-align:center}
.cal-weekrow{display:grid;grid-template-columns:repeat(7,1fr);gap:6px;margin-bottom:6px}
.cal-weekday{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--mut);text-align:center;padding:2px 0}
.cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:6px}
.cal-cell{min-height:84px;border-radius:10px;border:1px solid var(--bor);background:var(--card);padding:6px;cursor:pointer;transition:border-color 140ms;display:flex;flex-direction:column;gap:4px;min-width:0;overflow:hidden}
.cal-cell:hover{border-color:var(--bor2)}
.cal-cell.blank{background:none;border:none;cursor:default}
.cal-cell.selected{border-color:var(--acc)}
.cal-cellnum{font-size:12px;color:var(--mut);width:20px;height:20px;border-radius:50%;display:flex;align-items:center;justify-content:center}
.cal-cellnum.today{background:var(--acc);color:#000;font-weight:700}
.cal-pill{font-size:10px;font-weight:700;padding:2px 6px;border-radius:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;background:rgba(74,158,255,.14);color:var(--blue);border:1px solid rgba(74,158,255,.28)}
.cal-pill.movie{background:rgba(232,160,32,.14);color:var(--acc2);border-color:rgba(232,160,32,.28)}
.cal-pill.inlib{background:var(--grn);color:#04210f;border-color:var(--grn)}
.cal-cellmore{font-size:10px;color:var(--mut);padding:0 2px}
.cal-detail{margin-top:18px;background:var(--card);border:1px solid var(--bor);border-radius:14px;padding:16px}
.cal-detail-date{font-size:14px;font-weight:700;margin-bottom:12px}
.cal-detail-empty{color:var(--mut);font-size:13px;padding:8px 0}


.cfgpage{padding:calc(var(--navh) + 28px) 56px 48px}
.cfgsec{background:var(--card);border:1px solid var(--bor);border-radius:14px;padding:22px;margin-bottom:16px}
.cfgsec h3{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--mut);margin-bottom:16px}
.cfgtabs{display:flex;gap:4px;margin-bottom:24px;border-bottom:1px solid var(--bor);padding-bottom:0}
.cfgtab{
  display:flex;align-items:center;gap:7px;padding:10px 18px;
  font-size:14px;font-weight:600;cursor:pointer;
  border:none;background:none;color:var(--mut);font-family:var(--f);
  border-bottom:2px solid transparent;margin-bottom:-1px;
  transition:all 150ms;white-space:nowrap;
}
.cfgtab:hover{color:var(--txt)}
.cfgtab.on{color:var(--acc);border-bottom-color:var(--acc)}
.cfgpanel{display:none}
.cfgpanel.on{display:block}
.chips{display:flex;flex-wrap:wrap;gap:8px}
.chip{background:var(--card2);border:1px solid var(--bor);border-radius:8px;padding:7px 14px;font-size:12px;display:flex;gap:8px}
.cl{color:var(--mut);font-weight:600}
.cv{font-family:monospace;color:var(--txt)}
.cv.ok{color:var(--grn)}
.cv.er{color:var(--red)}
.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 20px;border-radius:8px;font-family:var(--f);font-size:13px;font-weight:700;cursor:pointer;border:none;transition:all 150ms}
.bp{background:var(--acc);color:#000}.bp:hover{background:var(--acc2)}
.bg2{background:var(--card2);color:var(--mut);border:1px solid var(--bor2)}.bg2:hover{color:var(--txt)}
.tresult{font-size:13px;color:var(--mut);margin-bottom:14px;min-height:20px}
.checklist{font-size:13px;color:var(--mut);line-height:2.2}
.checklist code{background:var(--card2);color:var(--acc2);padding:1px 7px;border-radius:5px;font-size:12px}

/* ── Toast ───────────────────────────────────────────────────── */
.toast{position:fixed;bottom:26px;right:26px;z-index:500;background:var(--card);border:1px solid var(--bor2);border-radius:12px;padding:12px 18px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;animation:tin .2s ease}
@keyframes tin{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.toast.ok{border-color:var(--grn);color:var(--grn)}
.toast.er{border-color:var(--red);color:var(--red)}
.toast.in{border-color:var(--blue);color:var(--blue)}

/* ── Mobile ──────────────────────────────────────────────────── */
/* Every page (.hero-body, .sec-hd, .srchpage, .va-inner, .libpage,
   .cfgpage) shares the same 56px side padding — that's the single
   biggest lever for "too cramped on a phone", so it's the first thing
   trimmed at each breakpoint below. */
@media (max-width: 900px) {
  .hero-body, .sec-hd, .srchpage, .va-inner, .libpage, .cfgpage, .row {
    padding-left: 24px !important;
    padding-right: 24px !important;
  }
}

/* Nav shrink — five tabs plus the user badge at desktop padding won't
   fit a phone width, so padding/font shrink first, and the whole pill
   scrolls horizontally as a fallback rather than wrapping into a
   second row or overflowing the screen. The badge lives inside this
   same pill (see the nav markup) so it shrinks and scrolls along with
   everything else automatically — no separate positioning logic
   needed for it. */
@media (max-width: 780px) {
  .nav {
    max-width: calc(100vw - 24px);
    overflow-x: auto;
    -ms-overflow-style: none; scrollbar-width: none;
  }
  .nav::-webkit-scrollbar { display: none; }
  .ni { padding: 7px 12px; font-size: 12px; }
}

@media (max-width: 640px) {
  .hero-body, .sec-hd, .srchpage, .va-inner, .libpage, .cfgpage, .row {
    padding-left: 14px !important;
    padding-right: 14px !important;
  }

  /* Extra top clearance below the fixed nav — every page uses the same
     --navh-based padding-top, which is a fixed assumed value rather than
     the nav's real rendered height, so this adds a safety margin on
     mobile rather than relying on that assumption being exact. Also
     covers the Calendar page specifically, whose title+Refresh row uses
     justify-content:space-between (title pinned to the far left edge,
     button to the far right) — full-width edge-to-edge like that is
     exactly what ends up peeking out from behind the nav pill (which is
     centered and narrower than the screen) if clearance is even
     slightly short, since the nav's blurred background only covers its
     own centered width, not the full row underneath it. */
  .hero-body, .sec-hd, .srchpage, .va-inner, .libpage, .cfgpage {
    padding-top: calc(var(--navh) + 20px) !important;
  }

  /* Hero: desktop sizing (100vh tall, 56px title) is oversized on a
     phone screen and pushes everything below the fold. height:auto
     (floored by min-height, no max-height cap) instead of a fixed
     range — matters once .hero-desc below stops clamping to 2 lines,
     since a fixed/capped height would just silently clip the now-
     longer text again regardless of removing the clamp. Safe to let
     this grow: .hero-bg is inset:0 with background-size:cover, so it
     naturally expands to cover whatever height the container ends up
     being — a short description still gets the same min-height-tall
     hero it always did, a long one just makes the hero a bit taller
     rather than cutting text off. */
  .hero { height: auto; min-height: 320px; max-height: none; }
  .hero-title { font-size: 30px; letter-spacing: -1px; }
  /* Full text on mobile instead of clamping to 2 lines — there's no
     "hover to see more" or easy way to expand truncated text on a touch
     screen the way there effectively is with a mouse, so clamping here
     just permanently hides the rest of the description with no way to
     read it. */
  .hero-desc { font-size: 13px; -webkit-line-clamp: unset; overflow: visible; }
  .hero-meta { font-size: 12px; }
  .hero-acts { flex-wrap: wrap; }
  .btn-hero { padding: 10px 18px !important; font-size: 13px !important; }

  /* Same reasoning as .hero-desc above — the "More Info" modal's
     overview was clamped to 3 lines, which on a touch screen has no
     equivalent to a mouse hover for seeing the rest. */
  .moverview { -webkit-line-clamp: unset; overflow: visible; }

  .libtitle { font-size: 22px; }
  .libhd { flex-wrap: wrap; gap: 12px; }
  .searchbar { max-width: 100% !important; }

  /* Library/search grids: 138px card columns are fine on desktop but
     leave awkward leftover space on a ~375-414px phone — drop the
     minimum so 2 full columns fit cleanly instead of 1.5. */
  .libgrid { grid-template-columns: repeat(auto-fill, minmax(108px, 1fr)) !important; gap: 16px 10px !important; }
  .cposter { width: 100%; height: auto; aspect-ratio: 2/3; }

  /* Calendar: 7 columns is unavoidable for a month grid, so this is
     about making each cell survive at ~45-50px wide rather than
     changing the layout shape. */
  .cal-cell { min-height: 56px; padding: 3px; gap: 2px; }
  .cal-cellnum { font-size: 10px; width: 16px; height: 16px; }
  .cal-pill { font-size: 8px; padding: 1px 3px; }
  .cal-cellmore { font-size: 8px; }
  .cal-weekday { font-size: 9px; }
  .cal-monthlabel { font-size: 14px; min-width: 120px; }
  .cal-navbtn { width: 28px; height: 28px; font-size: 14px; }
  .cal-chips { gap: 6px; }
  .cal-chip { padding: 5px 10px; font-size: 11px; }

  /* Modals: keep them comfortably inside the viewport with room to
     scroll instead of getting clipped or forcing horizontal scroll. */
  .modal { width: 94%; max-height: 88vh; overflow-y: auto; }
  .mbody { padding: 18px 16px 20px; }
  .macts { flex-wrap: wrap; }
  .hero-title, .mtitle { word-break: break-word; }

  /* Config: 6 tabs wrapping onto multiple lines looks broken — scroll
     horizontally instead, same fallback pattern as the main nav. */
  .cfgtabs {
    flex-wrap: nowrap; overflow-x: auto; gap: 2px;
    -ms-overflow-style: none; scrollbar-width: none;
  }
  .cfgtabs::-webkit-scrollbar { display: none; }
  .cfgtab { padding: 9px 12px; font-size: 13px; }
  .cfgsec { padding: 16px; }

  /* Every settings section that pairs two fields side by side
     (Stream preferences, Pending movies, AIOStreams pacing
     schedule, etc.) uses this exact inline grid-template-columns value —
     collapsing it to one column is the single change that fixes all of
     them at once, since a CSS class can't otherwise win against an
     inline style without this. */
  div[style*="grid-template-columns:1fr 1fr"] { grid-template-columns: 1fr !important; }
  div[style*="grid-template-columns: 1fr 1fr"] { grid-template-columns: 1fr !important; }

  /* Season/quality action rows (Scan HD / Scan 4K / Scan HD+4K / Remove,
     and similar button clusters) already wrap via inline flex-wrap in
     most places — this is a defensive backstop for the few that don't. */
  .season-btn, .cal-rescan-btn { font-size: 11px; padding: 5px 9px; }
}

@media (max-width: 400px) {
  .hero-title { font-size: 24px; }
  .libgrid { grid-template-columns: repeat(auto-fill, minmax(92px, 1fr)) !important; gap: 12px 8px !important; }
  .cal-cell { min-height: 48px; }
  .cal-pill { display: none; }   /* too tight to show pill text at this width — the day still opens the detail panel */
}
/* ── Item action sheet (openDelModal) ──────────────────────────────
   Deliberately flat: one neutral row style, no per-quality colour
   fills. Quality is chosen once via the segmented control at the top
   and the rows below act on that choice, so the sheet doesn't need to
   repeat "HD / 4K / both" across three separate pairs of buttons.
   Colour is reserved for the two destructive rows, which is the only
   place it carries information. */
.aseg { display:flex; gap:4px; background:var(--card2); border:1px solid var(--bor2);
        border-radius:10px; padding:4px; margin-bottom:18px }
.aseg button { flex:1; background:transparent; border:0; border-radius:7px; padding:8px 4px;
        font-family:var(--f); font-size:13px; font-weight:700; color:var(--mut);
        cursor:pointer; transition:background .12s, color .12s }
.aseg button:hover { color:var(--txt) }
.aseg button.on { background:var(--card); color:var(--txt); box-shadow:0 1px 3px rgba(0,0,0,.35) }
.arow { display:flex; align-items:center; justify-content:center; width:100%;
        background:var(--card2); border:1px solid var(--bor2); border-radius:10px;
        padding:13px 12px; margin-bottom:9px;
        font-family:var(--f); font-size:14.5px; font-weight:700; color:var(--txt);
        text-align:center; cursor:pointer; transition:background .12s, border-color .12s }
.arow:hover { background:var(--bor); border-color:var(--mut) }
.arow.off { color:var(--mut); opacity:.4; cursor:default }
.arow.off:hover { background:var(--card2); border-color:var(--bor2) }
.arow.danger { color:var(--red); border-color:rgba(255,85,85,.3) }
.arow.danger:hover { background:rgba(255,85,85,.1); border-color:rgba(255,85,85,.55) }
.arow.quiet { color:var(--mut); background:transparent }
.arow.quiet:hover { background:var(--card2); border-color:var(--bor2) }
.asep { height:1px; background:var(--bor); margin:14px 2px }
.apill { display:inline-block; font-size:11px; font-weight:700; letter-spacing:.04em;
         padding:3px 8px; border-radius:999px; border:1px solid var(--bor2);
         color:var(--mut); margin-right:6px }
.apill.has { border-color:rgba(74,158,255,.35); color:var(--blue) }
</style>
</head>
<body>

<!-- LOGIN SCREEN -->
<div id="loginScreen" style="position:fixed;inset:0;z-index:1000;background:var(--bg);display:none;align-items:center;justify-content:center;flex-direction:column;padding:20px">
  <div style="max-width:380px;width:100%;text-align:center">
    <div style="font-size:34px;font-weight:900;letter-spacing:-1px;margin-bottom:10px;color:var(--txt)">AIOGateway</div>
    <div style="color:var(--mut);font-size:14px;margin-bottom:40px;line-height:1.5">
      Sign in with your Plex account to continue
    </div>
    <button id="plexLoginBtn" class="btn bp" style="width:100%;padding:14px;font-size:15px;justify-content:center" onclick="startPlexLogin()">
      Log in with Plex
    </button>
    <div id="loginStatus" style="margin-top:22px;color:var(--mut);font-size:13px;display:none;line-height:1.5"></div>
    <div id="loginLinkArea"></div>
    <div id="loginError" style="margin-top:22px;color:var(--red);font-size:13px;display:none;line-height:1.5"></div>
  </div>
</div>

<!-- Nav -->
<nav class="nav">
  <button class="ni on" onclick="nav('home',this)">Home</button>
  <button class="ni"    onclick="nav('search',this)">Search</button>
  <button class="ni"    onclick="nav('calendar',this)">Calendar</button>
  <button class="ni" id="navLibrary" onclick="nav('library',this)">Library</button>
  <button class="ni" id="navConfig"  onclick="nav('config',this)">Config</button>

  <!-- USER BADGE (only shown once logged in) — lives inside the nav
       pill itself, right after Config, so it's just another item in
       the same flex row instead of a separately fixed-positioned
       element that has to be kept in sync with the nav's own size and
       position. For a non-admin "user" role, Library and Config are
       hidden entirely (see applyRoleGating()), so this naturally ends
       up right after Calendar for them — DOM order plus flex simply
       skips the hidden buttons in front of it, no extra logic needed.
       Just the picture, no name/divider — the dropdown (opened via
       toggleUserMenu) shows the name for anyone who needs to confirm
       which account they're on. -->
  <div id="userBadge" style="display:none;align-items:center;padding:4px;cursor:pointer" onclick="toggleUserMenu()">
    <img id="userBadgeThumb" src="" style="width:28px;height:28px;border-radius:50%;object-fit:cover;display:none">
    <div id="userBadgeInitial" style="width:28px;height:28px;border-radius:50%;background:var(--acc);color:#000;font-weight:800;font-size:13px;display:none;align-items:center;justify-content:center"></div>
  </div>
</nav>

<!-- USER MENU dropdown — deliberately NOT nested inside .nav. Below
     780px, .nav gets overflow-x:auto so the tabs can scroll instead of
     wrapping — but per spec, once one axis has a non-visible overflow,
     the browser forces the other axis to 'auto' too, which clips any
     descendant that extends outside the nav's own box. A dropdown
     living inside that container was invisible/unhittable in portrait
     as a result (worked in landscape/desktop only because .nav's
     overflow-x:auto rule doesn't apply above 780px). Rendering it as a
     sibling of .nav instead, positioned via JS from the badge's live
     bounding rect (see openUserMenu below), sidesteps the clipping
     entirely regardless of screen width. -->
<div id="userMenu" style="display:none;position:fixed;z-index:150;background:var(--card);border:1px solid var(--bor2);border-radius:12px;padding:8px;min-width:170px;box-shadow:0 8px 24px rgba(0,0,0,.5)">
  <div id="userMenuName" style="font-size:13px;font-weight:700;padding:6px 10px 1px;white-space:nowrap"></div>
  <div id="userMenuRole" style="font-size:11px;color:var(--mut);padding:0 10px 8px;text-transform:uppercase;letter-spacing:.06em;font-weight:700"></div>
  <button onclick="event.stopPropagation();logout()" style="width:100%;text-align:left;background:none;border:none;color:var(--red);font-family:var(--f);font-size:13px;font-weight:600;padding:8px 10px;border-radius:8px;cursor:pointer" onmouseover="this.style.background='var(--card2)'" onmouseout="this.style.background='none'">Log out</button>
</div>


<!-- SEARCH -->
<div id="pSearch" style="display:none">
  <div class="srchpage">
    <div class="srch-hd">
      <div class="srch-bar-wrap">
        <input class="srch-input" id="srchInput" placeholder="Search movies and series…"
               oninput="onSrchInput(this.value)" onkeydown="if(event.key==='Enter')doSearch()"/>
        <button class="srch-clear" id="srchClear" onclick="clearSearch()">Clear</button>
      </div>
      <div class="srch-tabs">
        <button class="srch-tab on" id="tabAll"    onclick="setTab('all',this)">All</button>
        <button class="srch-tab"    id="tabMovies" onclick="setTab('movie',this)">Movies</button>
        <button class="srch-tab"    id="tabSeries" onclick="setTab('series',this)">Series</button>
      </div>
    </div>
    <div class="srch-status" id="srchStatus"></div>
    <div class="srch-grid" id="srchGrid">
      <div class="srch-empty">
        
        <div class="srch-empty-title">Search for movies and series</div>
        <div class="srch-empty-sub">Powered by Cinemeta — the same source as Stremio</div>
      </div>
    </div>
  </div>
</div>

<!-- HOME -->
<div id="pHome">
  <div class="hero" id="hero">
    <div class="hero-bg" id="heroBg"></div>
    <div class="hero-ov"></div>
    <div class="hero-body">
      <img class="hero-logo" id="heroLogo" alt=""/>
      <div class="hero-title" id="heroTitle">…</div>
      <div class="hero-meta" id="heroMeta"></div>
      <div class="hero-desc" id="heroDesc"></div>
      <div class="hero-dots" id="heroDots"></div>
      <div class="hero-acts">
        <button class="btn-hero btn-add" id="heroBtn" onclick="heroAdd()">Add to Plex</button>
        <button class="btn-hero btn-info" onclick="heroInfo()">More Info</button>
      </div>
    </div>
  </div>

  <div class="rows">
    <div class="sec">
      <div class="sec-hd">
        <span class="sec-title">Popular — Movie</span>
        <button class="view-all" onclick="viewAll('Popular — Movie','catalog/movie/top.json','movie')">View All ›</button>
      </div>
      <div class="row" id="rowM">
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
      </div>
    </div>
    <div class="sec">
      <div class="sec-hd">
        <span class="sec-title">Popular — Series</span>
        <button class="view-all" onclick="viewAll('Popular — Series','catalog/series/top.json','series')">View All ›</button>
      </div>
      <div class="row" id="rowS">
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
      </div>
    </div>
  </div>
</div>

<!-- CALENDAR -->
<div id="pCalendar" style="display:none">
  <div class="cfgpage" style="padding-top:calc(var(--navh) + 28px)">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;flex-wrap:wrap;gap:12px">
      <h2 style="font-size:26px;font-weight:800;letter-spacing:-.5px">Calendar</h2>
      <button class="btn" onclick="loadCalendar(true)" style="padding:6px 14px;font-size:12px">Refresh</button>
    </div>
    <div class="cal-chips" id="calChips"></div>
    <div class="cal-monthbar">
      <button class="cal-navbtn" onclick="calChangeMonth(-1)" aria-label="Previous month">‹</button>
      <span class="cal-monthlabel" id="calMonthLabel"></span>
      <button class="cal-navbtn" onclick="calChangeMonth(1)" aria-label="Next month">›</button>
    </div>
    <div id="calBody">
      <div style="color:var(--mut);font-size:14px;padding:40px 0">Loading calendar…</div>
    </div>
  </div>
</div>

<!-- LIBRARY -->
<div id="pLibrary" style="display:none">
  <div class="libpage">
    <div class="libhd">
      <span class="libtitle">My Library</span>
      <div class="searchbar" style="max-width:300px">
                <input placeholder="Filter…" oninput="libSetQuery(this.value)" id="libFilter"/>
      </div>
    </div>
    <div class="cal-chips" id="libChips" style="margin-bottom:20px"></div>
    <div id="libGrid">
      <div style="color:var(--mut);font-size:14px;padding:40px 0">Loading…</div>
    </div>
  </div>
</div>

<!-- CONFIG -->
<div id="pConfig" style="display:none">
  <div class="cfgpage">
    <h2 style="font-size:26px;font-weight:800;margin-bottom:24px;letter-spacing:-.5px">Config</h2>

    <div class="cfgtabs">
      <button class="cfgtab on" id="cfgtab-connections" onclick="switchCfgTab('connections')">Connections</button>
      <button class="cfgtab" id="cfgtab-users" onclick="switchCfgTab('users');loadUsers()">Users</button>
      <button class="cfgtab" id="cfgtab-fuse" onclick="switchCfgTab('fuse')">FUSE</button>
      <button class="cfgtab" id="cfgtab-streams" onclick="switchCfgTab('streams')">Streams</button>
      <button class="cfgtab" id="cfgtab-api" onclick="switchCfgTab('api');loadApiKey()">API</button>
      <button class="cfgtab" id="cfgtab-migrate" onclick="switchCfgTab('migrate')">Migrate</button>
      <button class="cfgtab" id="cfgtab-backup" onclick="switchCfgTab('backup')">Backup/Restore</button>
    </div>

    <!-- ── Connections ──────────────────────────────────────────── -->
    <div class="cfgpanel on" id="cfgpanel-connections">
      <div class="cfgsec">
        <h3>AIOStreams connection</h3>
        <div class="chips" id="cfgChips">…</div>
        <div class="tresult" id="tresult" style="margin-top:14px"></div>
        <button class="btn bp" onclick="runTest()">Test connection</button>
      </div>
      <div class="cfgsec">
        <h3>Plex setup</h3>
        <div class="checklist">
          <div>1. Add library folders in Plex:<br>
            <code>/library/Movies</code>&nbsp;&nbsp;<code>/library/Movies4K</code>&nbsp;&nbsp;<code>/library/Series</code>&nbsp;&nbsp;<code>/library/Series4K</code>
          </div>
          <div>2. Plex → Settings → Webhooks → Add:<br>
            <code id="wurl">http://&lt;host&gt;:8001/webhook/plex</code>
          </div>
          <div>3. AIOStreams debrid credentials must return direct stream <code>url</code> fields.</div>
        </div>
      </div>
    </div>

    <!-- ── FUSE ─────────────────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-fuse">
      <div class="cfgsec">
        <h3>Active file TTL</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          The one expiry rule for the whole library. When a file resolves to a
          real stream it goes active, so playback and seeking are instant. Once
          it's been active for <strong>30 days</strong> it reverts to a
          lightweight placeholder, releasing the debrid session / CDN link —
          it re-resolves by itself the next time something plays it.
          <br><br>
          Applies to <strong>all four libraries equally</strong> — HD and 4K,
          movies and TV — with no separate per-quality setting. Counted from
          when the file was resolved, and every route to active counts the
          same: a play, a manual pick, or automatic prewarming.
          <br><br>
          Fixed at 30 days — turn it off entirely with the switch below
          instead of adjusting the number.
        </div>
        <div style="display:flex;align-items:center;gap:8px;cursor:pointer" onclick="document.getElementById('ttlEnabled').click()">
          <input type="checkbox" id="ttlEnabled" style="cursor:pointer" onclick="event.stopPropagation();saveTtlEnabled()">
          <span style="font-size:14px">Expire active files (30 days)</span>
          <span id="ttlEnabledSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
        <div style="color:var(--mut);font-size:12.5px;margin-top:6px;line-height:1.5">
          Off: nothing ever reverts to a placeholder again — a resolved file
          stays active and playable forever, and no new placeholders get
          created for it. Turning it back on resumes expiring on the same
          30-day TTL.
        </div>
        <div id="ttlCoverage" style="color:var(--mut);font-size:12.5px;margin-top:14px;line-height:1.6"></div>
      </div>
      <div class="cfgsec">
        <h3>Keep new content active</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          Starts the TTL clock on new content ahead of the first play, so
          anything you're likely to watch next is already resolved instead of
          waiting on AIOStreams the moment you hit play.
          <br><br>
          Something qualifies if it was <em>added</em> in the last few days or
          if it <em>released/aired</em> in the last few days — either counts.
          That's both halves of "new": a catalogue film requested today is
          caught by the first, and a film added weeks before its release, or an
          episode stubbed before a copy actually landed, is caught by the
          second once it turns up. Bulk imports from Radarr/Sonarr are detected
          and skipped, so a migration doesn't activate your whole back
          catalogue at once.
          <br><br>
          Anything activated this way is governed by the Active file TTL above,
          exactly like a file resolved by a normal play.
          <br><br>
          <strong>Requires a non-zero, enabled Active file TTL.</strong> With
          expiry set to 0, or its "Expire active files" switch off, nothing
          ever releases an active file, so activating something nobody has
          played would hold its link indefinitely. While that's the case this
          does nothing, and files resolve on first play as normal.
        </div>
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;cursor:pointer" onclick="document.getElementById('prewarmEnabled').click()">
          <input type="checkbox" id="prewarmEnabled" style="cursor:pointer" onclick="event.stopPropagation();savePrewarmEnabled()">
          <span style="font-size:14px">Automatically activate newly added and newly released content</span>
          <span id="prewarmDaysSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
        <div id="prewarmTtlWarn" style="display:none;color:var(--wrn,#e0a030);font-size:13px;margin-bottom:14px;line-height:1.5">
          Inactive — the Active file TTL above is 0 or its "Expire active files"
          switch is off. Files will resolve on first play only. Set a
          non-zero TTL and turn expiry on to enable this.
        </div>
        <button class="btn bp" onclick="runPrewarmNewContent()">Run now</button>
      </div>
      <div class="cfgsec">
        <h3>FUSE tuning</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          These control the virtual filesystem's read/cache/prefetch behaviour.
          They're set via environment variables in <code>docker-compose.yml</code>
          and require a container restart to change — shown here read-only for
          reference.
        </div>
        <div class="chips" id="fuseChips">…</div>
      </div>
    </div>

    <!-- ── Streams ──────────────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-streams">
      <div class="cfgsec">
        <h3>Stream preferences</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          Applied on top of whatever AIOStreams itself returns (your AIOStreams
          instance's own filters/sort order, configured at <code>/stremio/configure</code>,
          still run first). These preferences re-rank and filter the results
          aiogateway picks from — they don't replace your AIOStreams config.
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Preferred language</div>
            <input type="text" id="prefLanguage" placeholder="e.g. English"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Preferred audio (comma-separated)</div>
            <input type="text" id="prefAudio" placeholder="e.g. Atmos, TrueHD"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer" onclick="document.getElementById('reqSubs').click()">
          <input type="checkbox" id="reqSubs" style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Prefer streams with subtitles available</span>
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer" onclick="document.getElementById('preferPacks').click()">
          <input type="checkbox" id="preferPacks" checked style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Prefer season/series packs over individual episode files</span>
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer" onclick="document.getElementById('allowUsenet').click()">
          <input type="checkbox" id="allowUsenet" checked style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Allow usenet-sourced results to be picked (if enabled in AIOStreams)</span>
        </div>
        <div style="color:var(--mut);font-size:12px;margin-top:-14px;margin-bottom:20px">
          Only matters if you have a usenet service/indexer set up in AIOStreams itself — otherwise
          AIOStreams never returns usenet results in the first place. Turn this off to only ever
          pick debrid/torrent-backed streams even if usenet ones show up.
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Min size (GB, 0 = no limit)</div>
            <input type="number" id="minSizeGb" min="0" step="0.5" placeholder="0"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Max size (GB, 0 = no limit)</div>
            <input type="number" id="maxSizeGb" min="0" step="0.5" placeholder="0"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>

        <div style="margin-bottom:20px">
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Exclude words (comma-separated)</div>
          <input type="text" id="excludeWords" placeholder="e.g. CAM, TS, TELESYNC, HDCAM"
                 style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          <div style="color:var(--mut);font-size:12px;margin-top:6px">
            Streams whose filename or quality tag matches any of these are hard-excluded —
            never picked, and never counted as an available stream. Matched as a whole
            word, case-insensitive.
          </div>
        </div>

        <div style="margin-bottom:20px;max-width:260px">
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Minimum 4K sources to create a 4K stub</div>
          <input type="number" id="min4kCandidates" min="1" step="1" placeholder="6"
                 style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          <div style="color:var(--mut);font-size:12px;margin-top:6px">
            A single 4K source tends to be a rare/uncached torrent that's more
            likely to fail than a title with several to fall back on — below
            this many 4K sources found, no 4K stub is created (HD still is).
            Set to 1 to create a 4K stub whenever any 4K source exists at all.
          </div>
        </div>

        <button class="btn bp" onclick="saveStreamPrefs()">Save</button>
        <span id="streamPrefsSaved" style="color:var(--grn);font-size:13px;display:none;margin-left:10px">Saved</span>
      </div>
      <div class="cfgsec">
        <h3>Auto new-episode discovery</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          Periodically checks every series already in your library for
          newly-aired episodes and stubs them automatically (HD always,
          plus 4K if a stream is available) — no manual rescan needed.
          Episodes that have aired but have no stream yet are retried on
          every check until one shows up or the retry window below passes.
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer" onclick="document.getElementById('autoEpEnabled').click()">
          <input type="checkbox" id="autoEpEnabled" checked style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Automatically discover and stub new episodes</span>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Check every (minutes)</div>
            <input type="number" id="autoEpInterval" min="5" step="5" placeholder="10"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Give up retrying after (days)</div>
            <input type="number" id="autoEpRetryDays" min="0" step="0.5" placeholder="3"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:10px">
          <button class="btn bp" onclick="saveAutoEpisodes()">Save</button>
          <button class="btn" onclick="runAutoEpisodeSweepNow()">Check now</button>
          <span id="autoEpSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
        <div id="autoEpSweepResult" style="margin-top:12px;font-size:13px"></div>
      </div>
      <div class="cfgsec">
        <h3>Pending movies</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          When you add a movie that isn't resolvable yet — most commonly
          because it hasn't released, sometimes just because nothing's
          cached at your debrid backend yet — it's tracked here instead of
          the add just failing, and retried automatically on the same
          schedule as the episode check above until a stream shows up.
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;cursor:pointer" onclick="document.getElementById('pendingMvEnabled').click()">
          <input type="checkbox" id="pendingMvEnabled" checked style="cursor:pointer" onclick="event.stopPropagation()">
          <span style="font-size:14px">Automatically retry movies that aren't available yet</span>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;max-width:460px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Give up retrying after (days)</div>
            <input type="number" id="pendingMvRetryDays" min="0" step="1" placeholder="30"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Digital delay after theatrical (days)</div>
            <input type="number" id="digitalDelayDays" min="0" step="1" placeholder="21"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>
        <div style="color:var(--mut);font-size:12px;margin:-10px 0 20px;line-height:1.5">
          Don't search a movie at all until this many days after its theatrical
          release date. Cinemeta only has the theatrical date, not the actual
          digital/VOD date — this is a heuristic to reduce the odds of catching
          a pre-digital cam/TS leak, not an exact check. Set to 0 to search as
          soon as theatrical release has passed (the old behavior).
        </div>

        <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px">
          <button class="btn bp" onclick="savePendingMovies()">Save</button>
          <button class="btn" onclick="runPendingMoviesSweepNow()">Check now</button>
          <span id="pendingMvSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
        <div id="pendingMvSweepResult" style="font-size:13px;margin-bottom:16px"></div>
      </div>
      <div class="cfgsec">
        <h3>Dead stub cleanup</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          When a stub fails to resolve a stream this many times in a row, it's
          treated as permanently dead — its placeholder file is deleted and
          Plex is told to rescan, so it disappears from your library instead
          of sitting there as a file that looks available but can never
          actually play. Set to 0 to disable cleanup (a dead stub just stays
          flagged with an error and keeps showing up in Plex).
        </div>
        <div style="max-width:260px;margin-bottom:20px">
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Remove after this many failures in a row</div>
          <input type="number" id="deadStubMaxErrors" min="0" step="1" placeholder="3"
                 style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <button class="btn bp" onclick="saveDeadStubCleanup()">Save</button>
          <span id="deadStubSaved" style="color:var(--grn);font-size:13px;display:none">Saved</span>
        </div>
      </div>
      <div class="cfgsec">
        <h3>AIOStreams request pacing</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          Every query to AIOStreams — from playback, background episode
          scans, auto-discovery, and migration — goes through a single
          shared throttle, so no combination of background activity can
          burst past these limits, no matter how many things are running
          at once. AIOStreams fans each query out to every addon you have
          configured, so even a modest rate here can still burst higher at
          the addon level — if you're still seeing frequent 429s, lower
          concurrency and/or raise the minimum gap. The gap applies
          immediately; concurrency needs a restart to take effect.
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;max-width:460px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Requests in flight at once</div>
            <input type="number" id="aioMaxConcurrent" min="1" step="1" placeholder="1"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Minimum gap between requests (ms)</div>
            <input type="number" id="aioMinInterval" min="0" step="100" placeholder="1500"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <button class="btn bp" onclick="saveAioPacing()">Save</button>
          <span id="aioPacingSaved" style="color:var(--grn);font-size:13px;display:none">Saved (restart needed for concurrency changes)</span>
        </div>
      </div>
      </div>
    </div>

    <!-- ── Migrate ──────────────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-api">
      <div style="font-size:13px;color:var(--mut);margin-bottom:14px">
        An API key lets scripts, cron jobs and <code>curl</code> reach the API without a
        browser session. Send it as an <code>X-API-Key</code> header. Treat it like a
        password — it has full admin access.
      </div>

      <div id="apiKeySrcNote" style="display:none;font-size:12px;color:var(--acc2);
           background:rgba(232,160,32,.08);border:1px solid rgba(232,160,32,.25);
           border-radius:8px;padding:10px 12px;margin-bottom:14px"></div>

      <div style="display:flex;gap:8px;align-items:center;margin-bottom:6px">
        <input id="apiKeyField" readonly placeholder="No API key yet"
               style="flex:1;background:var(--card2);border:1px solid var(--bor2);
                      border-radius:8px;padding:10px 12px;color:var(--txt);
                      font-family:ui-monospace,monospace;font-size:12.5px">
        <button class="mbtn mbtn-add" style="width:auto;padding:10px 14px"
                onclick="copyApiKey()">Copy</button>
      </div>

      <div style="display:flex;gap:8px;margin:12px 0 18px">
        <button class="mbtn mbtn-add" style="width:auto;padding:10px 16px"
                id="apiKeyGenBtn" onclick="generateApiKey()">Generate new key</button>
        <button class="mbtn mbtn-rm" style="width:auto;padding:10px 16px"
                id="apiKeyRevokeBtn" onclick="revokeApiKey()">Revoke</button>
      </div>

      <div style="font-size:13px;color:var(--mut);line-height:1.7">
        <div style="color:var(--txt);font-weight:700;margin-bottom:6px">Examples</div>
        <div style="background:var(--card2);border:1px solid var(--bor2);border-radius:8px;
                    padding:12px;font-family:ui-monospace,monospace;font-size:12px;
                    white-space:pre-wrap;word-break:break-all;color:var(--txt)"
             id="apiKeyExamples"></div>
        <div style="margin-top:10px">
          Generating a new key immediately invalidates the old one. Anything still using
          it will start getting 401s.
        </div>
      </div>
    </div>

    <div class="cfgpanel" id="cfgpanel-migrate">
      <div class="cfgsec">
        <h3>Migrate from Radarr / Sonarr</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:20px;line-height:1.5">
          Point this at an existing Radarr or Sonarr instance. It reads every
          movie (or series + season) that already has a downloaded file
          there, then searches and stubs each one through your own
          AIOStreams connection — nothing is copied or changed on the
          Radarr/Sonarr side.
        </div>

        <div style="max-width:340px;margin-bottom:16px">
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Service</div>
          <select id="migSvc" onchange="migSvcChanged()"
            style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
            <option value="radarr">Radarr (movies)</option>
            <option value="sonarr">Sonarr (series)</option>
          </select>
        </div>

        <div style="display:grid;grid-template-columns:2fr 1fr;gap:16px;max-width:600px;margin-bottom:16px">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">URL</div>
            <input type="text" id="migUrl" placeholder="http://192.168.1.x:7878"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px" id="migKeyLabel">API key</div>
            <input type="password" id="migKey" placeholder="API key"
                   style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card);color:var(--txt);font-family:var(--f);font-size:14px">
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <button class="btn bp" onclick="migSaveAndTest()">Save &amp; test connection</button>
          <button class="btn" onclick="migLoadPreview()">Load library</button>
        </div>
        <div class="tresult" id="migTestResult" style="margin-top:12px"></div>

        <div id="migPreviewWrap" style="display:none;margin-top:22px">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
            <div style="font-size:13px;color:var(--mut)" id="migPreviewSummary"></div>
            <div style="display:flex;gap:16px;font-size:12px">
              <a href="#" onclick="migSelectAll(true);return false" style="color:var(--acc2);text-decoration:none">Select all</a>
              <a href="#" onclick="migSelectAll(false);return false" style="color:var(--acc2);text-decoration:none">Select none</a>
            </div>
          </div>
          <div id="migList" style="display:flex;flex-direction:column;gap:8px;max-height:380px;overflow-y:auto;padding-right:4px"></div>
          <div style="margin-top:18px">
            <button class="btn bp" onclick="migStart()">Start migration</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ── Backup/Restore ───────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-backup">
      <div class="cfgsec">
        <h3>Backup &amp; restore</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:14px;line-height:1.5">
          Download a backup of your settings and library (every added movie/
          series, including which seasons and quality tiers — not the actual
          streams, which always re-resolve fresh on next play). Restoring
          merges into your current library by default; check "Replace" to
          wipe the current library first.
        </div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <button class="btn bp" onclick="downloadBackup()">Download backup</button>
          <button class="btn" onclick="document.getElementById('restoreFile').click()">Restore from file…</button>
          <input type="file" id="restoreFile" accept="application/json" style="display:none" onchange="restoreFromFile(event)">
          <label style="display:flex;align-items:center;gap:6px;color:var(--mut);font-size:13px;cursor:pointer">
            <input type="checkbox" id="restoreReplace" style="cursor:pointer">
            Replace (wipe current library first)
          </label>
        </div>
        <div id="restoreResult" style="margin-top:12px;font-size:13px"></div>
      </div>
    </div>

    <!-- ── Users ────────────────────────────────────────────────── -->
    <div class="cfgpanel" id="cfgpanel-users">
      <div class="cfgsec">
        <h3>Users</h3>
        <div style="color:var(--mut);font-size:13px;margin-bottom:18px;line-height:1.5">
          Anyone who logs in with a Plex account that has access to this
          server gets an account automatically — there's no separate
          signup. New accounts start as a plain "user" (Home, Search,
          and Calendar only); promote someone to "admin" here to give
          them full access, including this Config page and the Library
          tab. The very first person to ever log in becomes admin
          automatically, since there'd otherwise be no way to get
          started. Changing a role immediately signs that person out of
          every device they're logged in on, so the change takes effect
          right away rather than after their session happens to expire.
        </div>
        <div id="usersList" style="display:flex;flex-direction:column;gap:8px">
          <div style="color:var(--mut);font-size:13px">Loading…</div>
        </div>
      </div>
    </div>

  </div>
</div>

<!-- MODAL -->
<div class="mbg" id="modal" onclick="bgClose(event)">
  <div class="modal">
    <div class="mhero" id="mhero" style="position:relative">
      <div class="mhero-ov"></div>
      <button class="mclose" onclick="closeModal()">✕</button>
    </div>
    <div class="mbody">
      <div class="mtitle" id="mtitle"></div>
      <div class="mmeta" id="mmeta"></div>
      <div class="mpills" id="mpills"></div>
      <div class="moverview" id="moverview"></div>
      <!-- Season picker — shown for series only -->
      <div id="seasonPickerWrap" style="display:none;margin-bottom:14px">
        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:8px">Season</div>
        <div class="season-picker" id="seasonPicker"></div>
      </div>
      <div class="macts">
        <button class="mbtn mbtn-add" id="maddBtn" onclick="modalAdd()">Add to Plex</button>
        <button class="mbtn mbtn-close" onclick="closeModal()">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- MIGRATE PROGRESS MODAL -->
<div class="mbg" id="migModal">
  <div class="modal" style="max-width:420px">
    <div class="mbody" style="padding:26px 26px 22px">
      <div class="mtitle" style="font-size:18px;margin-bottom:4px" id="migModalTitle">Migrating…</div>
      <div style="color:var(--mut);font-size:13px;margin-bottom:20px;min-height:16px" id="migModalCurrent"></div>
      <div style="background:var(--card2);border-radius:8px;height:10px;overflow:hidden;margin-bottom:10px">
        <div id="migBar" style="height:100%;width:0%;background:var(--acc);border-radius:8px;transition:width 300ms"></div>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--mut);margin-bottom:16px">
        <span id="migCount">0 / 0</span>
        <span id="migStatusLabel">Starting…</span>
      </div>
      <div id="migErrors" style="max-height:120px;overflow-y:auto;font-size:12px;color:var(--red);display:flex;flex-direction:column;gap:4px;margin-bottom:6px"></div>
      <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:14px">
        <button class="btn bg2" id="migCancelBtn" onclick="migCancel()">Cancel</button>
        <button class="btn bp" id="migCloseBtn" onclick="migCloseModal()" style="display:none">Done</button>
      </div>
    </div>
  </div>
</div>

<!-- PREWARM NEW CONTENT MODAL -->
<div class="mbg" id="prewarmModal">
  <div class="modal" style="max-width:560px">
    <div class="mbody" style="padding:26px 26px 22px">
      <div class="mtitle" style="font-size:18px;margin-bottom:4px" id="prewarmModalTitle">Prewarming new content…</div>
      <div style="color:var(--mut);font-size:13px;margin-bottom:20px;min-height:16px" id="prewarmModalCurrent"></div>
      <div id="prewarmProgressWrap">
        <div style="background:var(--card2);border-radius:8px;height:10px;overflow:hidden;margin-bottom:10px">
          <div id="prewarmBar" style="height:100%;width:0%;background:var(--acc);border-radius:8px;transition:width 300ms"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--mut);margin-bottom:16px">
          <span id="prewarmCount">0 / 0</span>
          <span id="prewarmStatusLabel">Starting…</span>
        </div>
      </div>
      <div id="prewarmResults" style="display:none;max-height:360px;overflow-y:auto;margin-bottom:6px"></div>
      <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:14px">
        <button class="btn bg2" id="prewarmCancelBtn" onclick="prewarmCancel()">Cancel</button>
        <button class="btn bp" id="prewarmCloseBtn" onclick="prewarmCloseModal()" style="display:none">Done</button>
      </div>
    </div>
  </div>
</div>

<script>
// ── State ──────────────────────────────────────────────────────
let heroItems = [], heroIdx = 0, heroTimer = null;
let stubs = [], allStubs = [], libImdb = new Set();
let libQuery = '';
let libStateFilter = 'all';   // all | active | placeholder
let libMoviePage = 1, libSeriesPage = 1;
let libMovieViewAll = false, libSeriesViewAll = false;
const LIB_PAGE_SIZE = 24;
const LIB_FILTERS = [
  { id: 'all',         label: 'All' },
  { id: 'recent',      label: 'Recently added' },
  { id: 'active',      label: 'Active' },
  { id: 'placeholder', label: 'Placeholder' },
  { id: 'missing',     label: 'Missing' },
  { id: 'upcoming',    label: 'Upcoming' },
  { id: 'unavailable', label: 'Unavailable' },
];
// How far back "Recently added" reaches. Anything added inside this
// window shows, newest first; if nothing is that new the tab falls back
// to the most recent titles regardless of age, so it's never an empty
// screen on a library that simply hasn't changed lately.
const LIB_RECENT_DAYS = 30;
const LIB_RECENT_FALLBACK = 24;
let modalItem = null;
const C = '/api/cinemeta';

// ── Nav ────────────────────────────────────────────────────────
function nav(page, el) {
  ['Home','Search','Calendar','Library','Config'].forEach(p => {
    document.getElementById('p'+p).style.display = 'none';
  });
  document.querySelectorAll('.ni').forEach(n => n.classList.remove('on'));
  document.getElementById('p'+page.charAt(0).toUpperCase()+page.slice(1)).style.display = '';
  el.classList.add('on');
  if (page === 'search')   { document.getElementById('srchInput').focus(); }
  if (page === 'library')  loadLib();
  if (page === 'config')   loadCfg();
  if (page === 'calendar') loadCalendar();
}

// ── Cinemeta fetch ─────────────────────────────────────────────
async function cmFetch(path) {
  const r = await fetch(`${C}/${path}`);
  if (!r.ok) throw new Error(`Cinemeta ${r.status}: ${path}`);
  return r.json();
}

// ── Hero ───────────────────────────────────────────────────────
async function loadHero() {
  const data = await cmFetch('catalog/movie/top.json');
  const items = (data.metas || []).filter(m => m.background || m.poster).slice(0, 9);
  if (!items.length) return;
  heroItems = items;
  buildDots();
  setHero(0);
  heroTimer = setInterval(() => setHero((heroIdx+1) % heroItems.length), 7000);
}

function buildDots() {
  document.getElementById('heroDots').innerHTML =
    heroItems.map((_,i) => `<div class="hero-dot${i===0?' on':''}" onclick="setHero(${i})"></div>`).join('');
}

function setHero(i) {
  heroIdx = i;
  const m = heroItems[i];
  if (!m) return;

  // Backdrop
  const bg = m.background || m.poster || '';
  document.getElementById('heroBg').style.backgroundImage = bg ? `url(${bg})` : 'none';

  // Logo
  const logoEl = document.getElementById('heroLogo');
  if (m.logo) {
    logoEl.src = m.logo;
    logoEl.style.display = 'block';
    document.getElementById('heroTitle').style.display = 'none';
  } else {
    logoEl.style.display = 'none';
    document.getElementById('heroTitle').style.display = 'block';
    document.getElementById('heroTitle').textContent = m.name || '';
  }

  // Meta
  const year = m.releaseInfo ? m.releaseInfo.split('–')[0] : '';
  const rating = m.imdbRating ? `${m.imdbRating}` : '';
  const genres = (m.genres || []).slice(0,2).join(' · ');
  const metaParts = [year, genres].filter(Boolean);
  document.getElementById('heroMeta').innerHTML =
    metaParts.map(p=>`<span>${p}</span>`).join('<span class="hero-sep">•</span>') +
    (rating ? `<span class="hero-sep">•</span><span class="hero-rating">${rating}</span>` : '');

  document.getElementById('heroDesc').textContent = m.description || '';

  // Dots
  document.querySelectorAll('.hero-dot').forEach((d,j) => d.classList.toggle('on', j===i));

  // Add button state
  const btn = document.getElementById('heroBtn');
  const inLib = libImdb.has(m.id);
  btn.textContent = inLib ? 'In Library' : 'Add to Plex';
  btn.className = 'btn-hero btn-add' + (inLib ? ' added' : '');
}

function heroAdd()  { if (heroItems[heroIdx]) openModal(heroItems[heroIdx], 'movie'); }
function heroInfo() { if (heroItems[heroIdx]) openModal(heroItems[heroIdx], 'movie'); }

// ── Item store — avoids embedding raw JSON in onclick attrs ───
const _items = {};
function _store(m, type) { _items[m.id] = { m, type }; }
function _click(id) { const e = _items[id]; if (e) openModal(e.m, e.type); }

// ── Card rows ──────────────────────────────────────────────────
function card(m, type) {
  _store(m, type);
  const inLib = libImdb.has(m.id);
  const year = (m.releaseInfo || '').split(/[-–]/)[0].trim();
  const rating = m.imdbRating || '';
  const name = (m.name || '').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const sid = CSS.escape(m.id);
  return `<div class="card${inLib?' inlib':''}" id="c${sid}" onclick="_click('${m.id.replace(/'/g,"\\'")}')">
    <div class="cposter">
      ${m.poster ? `<img src="${m.poster}" loading="lazy" onload="this.classList.add('loaded')" onerror="this.parentNode.style.background='#1a1a28'"/>` : ''}
      ${rating ? `<div class="crating">${rating}</div>` : ''}
      <div class="ccheck">✓</div>
    </div>
    <div class="cname">${name}</div>
    <div class="cyear">${year}</div>
  </div>`;
}

async function loadRow(elId, path, type) {
  try {
    const data = await cmFetch(path);
    const items = (data.metas || []).slice(0, 20);
    _rowCache[path] = data.metas || [];   // cache full list for View All
    document.getElementById(elId).innerHTML = items.map(m => card(m, type)).join('');
    return items;
  } catch(e) {
    document.getElementById(elId).innerHTML = `<div style="color:var(--red);font-size:13px;padding:20px">Failed: ${e.message}</div>`;
    return [];
  }
}

// ── Modal ──────────────────────────────────────────────────────
// Selected season: null = all, number = specific season
let _selectedSeason = null;
let _newSeasonsToAdd = [];
// Populated by buildSeasonPicker each time the modal opens for a series —
// everything handleAllSeasonsClick() needs to decide "are all seasons
// already requested" without re-fetching, and to know what to request
// if not.
let _allSeasonsInfo = null;

async function openModal(item, type) {
  modalItem = { ...item, _type: type };
  _selectedSeason = null;
  _newSeasonsToAdd = [];
  _allSeasonsInfo = null;

  // Try to get full meta if we only have preview
  if (!item.description && item.id) {
    try {
      const full = await cmFetch(`meta/${type}/${item.id}.json`);
      if (full.meta) { modalItem = { ...full.meta, _type: type }; item = modalItem; }
    } catch {}
  }

  document.getElementById('mtitle').textContent = item.name || '';
  const year = item.releaseInfo ? item.releaseInfo.split('–')[0] : '';
  const rating = item.imdbRating ? `<span class="mrating">${item.imdbRating}</span>` : '';
  document.getElementById('mmeta').innerHTML =
    `<span>${type==='series'?'Series':'Movie'}</span>` +
    (year ? `<span>•</span><span>${year}</span>` : '') +
    rating;
  document.getElementById('mpills').innerHTML = (item.genres||[]).slice(0,4).map(g=>`<span class="mpill">${g}</span>`).join('');
  document.getElementById('moverview').textContent = item.description || '';
  document.getElementById('mhero').style.backgroundImage =
    `url(${item.background || item.poster || ''})`;

  const inLib = libImdb.has(item.id);
  const btn = document.getElementById('maddBtn');
  btn.textContent = inLib ? 'In Library' : 'Add to Plex';
  btn.className = 'mbtn mbtn-add' + (inLib ? ' added' : '');
  btn.disabled = false;

  // Season picker for series
  const wrap = document.getElementById('seasonPickerWrap');
  const picker = document.getElementById('seasonPicker');
  if (type === 'series') {
    wrap.style.display = 'block';
    picker.innerHTML = '<div style="color:var(--mut);font-size:12px">Loading seasons…</div>';
    buildSeasonPicker(item.id, picker);
  } else {
    wrap.style.display = 'none';
    picker.innerHTML = '';
  }

  document.getElementById('modal').classList.add('open');
}

async function buildSeasonPicker(imdbId, picker) {
  try {
    const [r, watchR] = await Promise.all([
      fetch(`/api/series/${imdbId}/episodes`),
      fetch(`/api/series/${imdbId}/season-watch`).catch(() => null),
    ]);
    const d = await r.json();
    const episodes = d.episodes || [];
    let watchEnabled = false;
    if (watchR) {
      try { watchEnabled = (await watchR.json()).enabled === true; } catch {}
    }

    // Every season Cinemeta lists at all — including ones that haven't
    // started airing yet (announced, zero episodes aired so far). Used
    // to matter only for aired seasons, but that meant a fully-upcoming
    // season could never even appear as an option, let alone be picked
    // up by "New" below.
    const seasons = [...new Set(
      episodes.map(e => e.season)
    )].filter(Boolean).sort((a,b)=>a-b);

    if (!seasons.length) {
      picker.innerHTML = '<div style="color:var(--mut);font-size:12px">No seasons found</div>';
      return;
    }

    // A season is "requested" if at least one of its episodes already has
    // a stub (HD or 4K) — same definition used in the library's series
    // detail modal, so the two stay visually consistent.
    const requestedSeasons = new Set(
      episodes.filter(e => e.has_hd || e.has_4k).map(e => e.season)
    );

    // Per-season aired/total counts, to tell an old finished season apart
    // from one still actively airing — the "New" button below only wants
    // the latter.
    const seasonCounts = {};
    episodes.forEach(e => {
      if (!e.season) return;
      seasonCounts[e.season] = seasonCounts[e.season] || { total: 0, aired: 0 };
      seasonCounts[e.season].total++;
      if (e.aired) seasonCounts[e.season].aired++;
    });

    // Stashed for handleAllSeasonsClick() — it needs to know, at click
    // time, exactly which seasons exist, which already have a stub, and
    // which have aired episodes at all (an unaired season can't be
    // requested yet, so it shouldn't block "All" from going green).
    _allSeasonsInfo = { imdbId, seasons, requestedSeasons, seasonCounts };

    // Concrete case: Cinemeta already lists a specific not-yet-requested,
    // purely-upcoming season (zero episodes aired). This stays a one-time
    // grab, same as always — a real, dated season is a different,
    // more certain situation than the speculative case below, so
    // clicking it doesn't also enable persistent watch as a side effect.
    _newSeasonsToAdd = seasons.filter(s =>
      !requestedSeasons.has(s) &&
      seasonCounts[s] && seasonCounts[s].aired === 0
    );
    const hasConcreteNew = _newSeasonsToAdd.length > 0;

    const title  = (modalItem && modalItem.name || '').replace(/'/g, "\\'");
    const poster = modalItem && modalItem.poster || '';
    const year   = parseInt((modalItem && modalItem.releaseInfo || '').slice(0,4)) || '';

    let newBtn;
    if (hasConcreteNew) {
      newBtn = `<button class="season-btn" id="maddNewSeasonsBtn"
        style="background:var(--acc);color:#000;border:none"
        onclick="modalAddNewSeasons()">New (${_newSeasonsToAdd.length})</button>`;
    } else if (watchEnabled) {
      // Nothing concrete to grab right now, but the indefinite watch is
      // already on — the auto-episode sweep is handling this on its
      // own, every cycle, with no action needed. Informational, not a
      // one-time-action button; clicking offers to turn it back off.
      // Green specifically signals "this is active/confirmed", same
      // meaning green already has for an already-requested season chip.
      newBtn = `<button class="season-btn" id="maddNewSeasonsBtn"
        style="background:var(--grn);color:#04140d;border:none"
        title="Automatically tracking whatever the next season turns out to be — click to stop"
        onclick="disableSeasonWatch('${imdbId}')">Tracking ✓</button>`;
    } else if (seasons.length > 0) {
      // Nothing concrete, watch not yet on — offer to enable it. This is
      // a SET-ONCE action: unlike the concrete case above, clicking this
      // doesn't grab one specific season, it turns on indefinite
      // tracking so every future gap (this one and any after it) gets
      // handled automatically without needing to come back and click
      // again. Orange (matching "All") since it's an action to take, not
      // yet an active/confirmed state — that's reserved for green.
      newBtn = `<button class="season-btn" id="maddNewSeasonsBtn"
        style="background:var(--acc);color:#000;border:none"
        title="Enables automatic tracking of whatever the next season turns out to be, indefinitely — set once, no need to click again for future seasons"
        onclick="enableSeasonWatch('${imdbId}','${title}','${poster}',${year || 'null'})">New</button>`;
      _newSeasonsToAdd = [];   // nothing to directly add via modalAddNewSeasons in this state
    } else {
      newBtn = `<button class="season-btn" id="maddNewSeasonsBtn" disabled>New</button>`;
      _newSeasonsToAdd = [];
    }

    // All button + New button + season buttons. "All" starts green only
    // when every requestable season (i.e. one with at least one aired
    // episode) already has a stub — otherwise it's the same orange as
    // "New" (an action still to take), and clicking it goes and requests
    // whatever's missing instead of just toggling the filter. Uses an
    // inline style rather than the shared .requested CSS class: that
    // class is deliberately overridden by .season-btn.requested.on (so a
    // *selected* per-season chip still reads as "selected", not
    // "requested"), but "All" is always selected by default, so the same
    // rule would silently keep it orange even when complete.
    const requestableSeasons = seasons.filter(s => seasonCounts[s] && seasonCounts[s].aired > 0);
    const allRequested = requestableSeasons.length > 0 &&
      requestableSeasons.every(s => requestedSeasons.has(s));
    const allBtn = `<button class="season-btn all-btn on" id="sbAll"
      ${allRequested ? 'style="background:var(--grn);color:#04140d;border-color:var(--grn)"' : ''}
      title="${allRequested ? 'All seasons already requested' : 'Check for and request any missing seasons'}"
      onclick="handleAllSeasonsClick('${imdbId}')">All</button>`;
    const seasonBtns = seasons.map(s => {
      const requestedCls = requestedSeasons.has(s) ? ' requested' : '';
      const btnTitle = requestedSeasons.has(s) ? ' title="Already requested"' : '';
      return `<button class="season-btn${requestedCls}" id="sb${s}" onclick="selectSeason(${s})"${btnTitle}>S${String(s).padStart(2,'0')}</button>`;
    }).join('');
    picker.innerHTML = allBtn + newBtn + seasonBtns;
  } catch {
    picker.innerHTML = '<div style="color:var(--mut);font-size:12px">Could not load seasons</div>';
  }
}

async function enableSeasonWatch(imdbId, title, poster, year) {
  const btn = document.getElementById('maddNewSeasonsBtn');
  if (btn) { btn.textContent = 'Enabling…'; btn.disabled = true; }
  try {
    const r = await fetch(`/api/series/${imdbId}/season-watch`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, poster, year: year || null }),
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'Could not enable');
    }
    toast(`Now tracking "${title}" — future seasons will be added automatically`, 'ok');
    if (btn) {
      btn.textContent = 'Tracking ✓';
      btn.disabled = false;
      btn.style.background = 'var(--grn)';
      btn.style.color = '#04140d';
      btn.onclick = () => disableSeasonWatch(imdbId);
      btn.title = 'Automatically tracking whatever the next season turns out to be — click to stop';
    }
  } catch (exc) {
    toast(exc.message || 'Could not enable season watch', 'er');
    if (btn) { btn.textContent = 'New'; btn.disabled = false; }
  }
}

async function disableSeasonWatch(imdbId) {
  const btn = document.getElementById('maddNewSeasonsBtn');
  if (btn) { btn.textContent = 'Stopping…'; btn.disabled = true; }
  try {
    await fetch(`/api/series/${imdbId}/season-watch`, { method: 'DELETE' });
    toast('Stopped tracking new seasons', 'ok');
    if (btn) {
      btn.textContent = 'New';
      btn.disabled = false;
      btn.style.background = 'var(--acc)';
      btn.style.color = '#000';
      btn.title = 'Enables automatic tracking of whatever the next season turns out to be, indefinitely — set once, no need to click again for future seasons';
      const title  = (modalItem && modalItem.name || '').replace(/'/g, "\\'");
      const poster = modalItem && modalItem.poster || '';
      const year   = parseInt((modalItem && modalItem.releaseInfo || '').slice(0,4)) || null;
      btn.onclick = () => enableSeasonWatch(imdbId, title, poster, year);
    }
  } catch {
    toast('Could not stop season watch', 'er');
    if (btn) btn.disabled = false;
  }
}

function selectSeason(season) {
  _selectedSeason = season;
  // Update button styles
  document.querySelectorAll('.season-btn').forEach(b => b.classList.remove('on'));
  const target = season === null
    ? document.getElementById('sbAll')
    : document.getElementById('sb' + season);
  if (target) target.classList.add('on');
}

// "All" button: first behaves like the old plain filter (selects "no
// specific season" for modalAdd), then actually checks whether every
// requestable season is already stubbed. If something's missing, request
// it — same one-request-per-season loop requestAllSeasons() uses in the
// library's series detail modal, just wired to the browse/add modal's
// state instead. If nothing's missing, there's nothing to request —
// just flip the button green so that's visible at a glance.
async function handleAllSeasonsClick(imdbId) {
  selectSeason(null);
  const btn = document.getElementById('sbAll');
  const info = _allSeasonsInfo;
  if (!btn || !info || info.imdbId !== imdbId) return;

  const { seasons, requestedSeasons, seasonCounts } = info;
  const requestableSeasons = seasons.filter(s => seasonCounts[s] && seasonCounts[s].aired > 0);
  const missing = requestableSeasons.filter(s => !requestedSeasons.has(s));

  if (!missing.length) {
    btn.style.background = 'var(--grn)';
    btn.style.color = '#04140d';
    btn.style.borderColor = 'var(--grn)';
    btn.title = 'All seasons already requested';
    return;
  }

  const title  = (modalItem && modalItem.name || '');
  const poster = (modalItem && modalItem.poster) || '';
  const year   = parseInt((modalItem && modalItem.releaseInfo || '').slice(0,4)) || null;

  const original = btn.textContent;
  btn.textContent = 'Requesting…';
  btn.style.pointerEvents = 'none';
  btn.style.opacity = '.6';
  toast(`Requesting ${missing.length} missing season${missing.length!==1?'s':''} of "${title}"`, 'in');

  let added = 0, wanted = 0, failed = 0;
  for (const sn of missing) {
    try {
      const r = await fetch('/api/add', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imdb_id: imdbId, title, year, media_type: 'series', poster, season: sn }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.detail || 'Add failed');
      if (d.wanted) wanted++; else { added++; requestedSeasons.add(sn); }
    } catch (exc) {
      failed++;
      console.error(`Add season S${sn} failed:`, exc.message);
    }
  }

  btn.style.pointerEvents = 'auto';
  btn.style.opacity = '1';

  if (added > 0) {
    pollScan(imdbId, title);
    triggerPrewarmNow();
    libImdb.add(imdbId);
    const mainBtn = document.getElementById('maddBtn');
    if (mainBtn) { mainBtn.textContent = 'In Library'; mainBtn.className = 'mbtn mbtn-add added'; }
  }

  // Green only once every requestable season is actually accounted for —
  // a season that came back "wanted" (not aired yet) still isn't stubbed,
  // so the job isn't fully done even though nothing failed.
  const stillMissing = requestableSeasons.filter(s => !requestedSeasons.has(s));
  if (!stillMissing.length && !failed) {
    btn.style.background = 'var(--grn)';
    btn.style.color = '#04140d';
    btn.style.borderColor = 'var(--grn)';
    btn.title = 'All seasons already requested';
  } else {
    btn.textContent = original;
  }

  const parts = [];
  if (added)  parts.push(`${added} added — scanning in background`);
  if (wanted) parts.push(`${wanted} tracked for when ${wanted !== 1 ? 'they air' : 'it airs'}`);
  if (failed) parts.push(`${failed} failed`);
  if (parts.length) toast(`"${title}": ${parts.join(', ')}`, failed && !added && !wanted ? 'er' : 'ok');
  await syncStubs();
}

function closeModal() { document.getElementById('modal').classList.remove('open'); }
function bgClose(e) { if (e.target === document.getElementById('modal')) closeModal(); }

async function modalAdd() {
  if (!modalItem) return;
  const btn = document.getElementById('maddBtn');
  const imdbId = modalItem.id;

  if (!imdbId || !imdbId.startsWith('tt')) {
    toast('No IMDb ID for this title', 'er'); return;
  }
  if (libImdb.has(imdbId)) { toast('Already in library', 'in'); return; }

  btn.textContent = 'Loading streams…';
  btn.disabled = true;

  const title = modalItem.name || '';
  const year  = parseInt((modalItem.releaseInfo||'').slice(0,4)) || null;
  const type  = modalItem._type === 'series' ? 'series' : 'movie';

  try {
    const poster = modalItem.poster || '';
    const body = { imdb_id:imdbId, title, year, media_type:type, poster };
    if (type === 'series' && _selectedSeason !== null) {
      body.season = _selectedSeason;
    }
    const r = await fetch('/api/add', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify(body),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || JSON.stringify(d));

    if (type === 'movie' && d.pending) {
      // Not resolvable yet (commonly not released) — tracked for automatic
      // retry rather than added, so don't mark it "In Library".
      btn.textContent = 'Tracking…'; btn.className = 'mbtn mbtn-add pending'; btn.disabled = true;
      toast(`"${title}" isn't available yet — tracking it and will add automatically once it is`, 'ok');
      return;
    }

    if (type === 'series' && d.wanted) {
      // Nothing's aired in this specific season yet — registered so the
      // auto-episode sweep stubs it automatically once its first episode
      // actually airs. Not "In Library" yet, same reasoning as a pending
      // movie above.
      btn.textContent = 'Tracking…'; btn.className = 'mbtn mbtn-add pending'; btn.disabled = true;
      toast(`Season ${d.season} of "${title}" hasn't aired yet — tracking it and will add automatically once it does`, 'ok');
      return;
    }

    libImdb.add(imdbId);
    btn.textContent = 'In Library'; btn.className = 'mbtn mbtn-add added'; btn.disabled = false;

    // Update hero button
    const hm = heroItems[heroIdx];
    if (hm && hm.id === imdbId) {
      const hb = document.getElementById('heroBtn');
      hb.textContent = 'In Library'; hb.className = 'btn-hero btn-add added';
    }

    // Mark card
    const c = document.getElementById('c'+modalItem.id);
    if (c) c.classList.add('inlib');

    if (type === 'series') {
      const seasonLabel = _selectedSeason !== null ? ` (Season ${_selectedSeason})` : '';
      toast(`Added "${title}"${seasonLabel} — scanning in background…`, 'ok');
      pollScan(imdbId, title);
      triggerPrewarmNow();   // resolve the fast-added first episode right away; pollScan triggers again once the rest of the season is scanned
    } else {
      toast(`Added "${title}" — ${d.streams_found} streams${d.has_4k?' (HD+4K)':''}`, 'ok');
      triggerPrewarmNow();
    }
    await syncStubs();
  } catch(e) {
    btn.textContent = 'Add to Plex'; btn.disabled = false;
    // Surface the full AIOStreams diagnostic in the toast
    const msg = e.message || 'Unknown error';
    toast(msg.length > 120 ? msg.slice(0, 117) + '…' : msg, 'er');
    console.error('Add to Plex error:', e.message);
  }
}

async function modalAddNewSeasons() {
  if (!modalItem || !_newSeasonsToAdd.length) return;
  const btn = document.getElementById('maddNewSeasonsBtn');
  const imdbId = modalItem.id;
  const title  = modalItem.name || '';
  const year   = parseInt((modalItem.releaseInfo||'').slice(0,4)) || null;
  const poster = modalItem.poster || '';

  // /api/add only takes one season at a time, so adding "everything new"
  // for a show with several new seasons is a sequential loop, same as any
  // other multi-item action in this app (season scans, migration) —
  // each request still goes through the normal per-item AIOStreams pacing.
  const seasons = [..._newSeasonsToAdd];
  let added = 0, wanted = 0, failed = 0;

  for (const season of seasons) {
    btn.textContent = `Adding S${String(season).padStart(2,'0')}… (${added + wanted + failed + 1}/${seasons.length})`;
    btn.disabled = true;
    try {
      const r = await fetch('/api/add', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imdb_id: imdbId, title, year, media_type: 'series', poster, season }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.detail || 'Add failed');
      if (d.wanted) {
        // Nothing's aired in this season yet — registered so the
        // recurring auto-episode sweep stubs it automatically once its
        // first episode actually airs, no second click needed later.
        wanted++;
      } else {
        added++;
        pollScan(imdbId, title);
      }
    } catch (exc) {
      failed++;
      console.error(`Add new season S${season} failed:`, exc.message);
    }
  }

  const mainBtn = document.getElementById('maddBtn');
  if (added > 0) {
    // Something's actually stubbed now — genuinely in Plex.
    libImdb.add(imdbId);
    mainBtn.textContent = 'In Library'; mainBtn.className = 'mbtn mbtn-add added';
    const c = document.getElementById('c'+modalItem.id);
    if (c) c.classList.add('inlib');
  } else if (wanted > 0) {
    // Only registered future season(s) to watch for — nothing's actually
    // in Plex yet, so don't claim it is. Matches the same "Tracking…"
    // treatment a pending movie gets.
    mainBtn.textContent = 'Tracking…'; mainBtn.className = 'mbtn mbtn-add pending';
  }

  // Nothing new left to add now — clear inline styles entirely so it
  // falls back to the exact same look as an unselected season chip,
  // same as buildSeasonPicker's disabled state.
  btn.textContent = 'New';
  btn.disabled = true;
  btn.removeAttribute('style');
  _newSeasonsToAdd = [];

  if (added > 0) triggerPrewarmNow();   // resolve the fast-added first episodes now; pollScan (fired per season above) triggers again once each season finishes scanning

  const parts = [];
  if (added)  parts.push(`${added} added — scanning in background`);
  if (wanted) parts.push(`${wanted} tracked for when ${wanted !== 1 ? 'they air' : 'it airs'}`);
  if (failed) parts.push(`${failed} failed`);
  toast(`"${title}": ${parts.join(', ')}`, failed && !added && !wanted ? 'er' : 'ok');
  await syncStubs();
}

// ── Stubs / Library ────────────────────────────────────────────
async function syncStubs() {
  try {
    const r = await fetch('/api/stubs');
    const d = await r.json();
    stubs = d.stubs || [];
    libImdb = new Set(stubs.map(s => s.media_id.split('_')[0]));
  } catch {}
}

// ── Calendar ──────────────────────────────────────────────────
let _calScheduled = {};   // {key: timeoutId} for track-and-rescan timers
let calViewYear  = new Date().getFullYear();
let calViewMonth = new Date().getMonth();   // 0-indexed
let calFilter    = 'all';
let calEntries   = [];
let calSelectedDate = null;
let calMeta      = { oldestAge:null, unavailable:[], loadedAt:0, refreshed:false };

const CAL_FILTERS = [
  { id:'all',      label:'All' },
  { id:'episodes', label:'Episodes' },
  { id:'movies',   label:'Movies' },
  { id:'library',  label:'In library' },
  { id:'upcoming', label:'Upcoming' },
];

function calMatchesFilter(e) {
  if (calFilter === 'all')      return true;
  if (calFilter === 'episodes') return e.type === 'episode';
  if (calFilter === 'movies')   return e.type === 'movie';
  if (calFilter === 'library')  return !!e.in_library;
  if (calFilter === 'upcoming') return !e.in_library;
  return true;
}

function calChangeMonth(delta) {
  calViewMonth += delta;
  if (calViewMonth < 0)  { calViewMonth = 11; calViewYear--; }
  if (calViewMonth > 11) { calViewMonth = 0;  calViewYear++; }
  calSelectedDate = null;
  loadCalendar();
}

function _calDaysBetween(a, b) {
  return Math.round((b - a) / 86400000);
}

// Local YYYY-MM-DD for a Date. NOT toISOString().slice(0,10) — that
// converts to UTC first, so for anyone east of Greenwich local midnight
// lands on the previous UTC day and "today" highlights the wrong cell.
function _calDateKey(d) {
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

// The day an entry belongs on, in the viewer's own timezone.
//
// This is the fix for the main "shows land on the wrong day" bug. The
// backend's `release_date` is the UTC calendar date of `release_ts`,
// while the month grid's cells are keyed by LOCAL dates — so any release
// whose UTC timestamp falls in the small hours of UTC showed up a day
// late. A 9pm Eastern air time is 01:00 UTC the following day, which is
// most US prime-time television; those episodes were consistently
// rendered one square too far right, and the time printed on the entry
// ("9:00 PM", rendered in local time) openly contradicted the date it
// was filed under. Deriving the day from the timestamp locally makes the
// date and the time agree, and puts the episode on the night it airs.
function _calEntryDate(e) {
  return _calDateKey(new Date(e.release_ts * 1000));
}

async function loadCalendar(force) {
  const body = document.getElementById('calBody');
  // `force` was previously accepted and then never used, which made the
  // Refresh button a no-op as far as correctness went: it re-requested
  // /api/calendar, the server served the same cached Cinemeta metadata,
  // and a wrong air date stayed wrong. It now asks the server to actually
  // re-check upstream.
  body.innerHTML = force
    ? '<div style="color:var(--mut);font-size:14px;padding:40px 0">Re-checking release dates…</div>'
    : '<div style="color:var(--mut);font-size:14px;padding:40px 0">Loading…</div>';

  const today = new Date(); today.setHours(0,0,0,0);
  const gridStart = new Date(calViewYear, calViewMonth, 1);
  gridStart.setDate(gridStart.getDate() - gridStart.getDay());
  const gridEnd = new Date(calViewYear, calViewMonth + 1, 0);
  gridEnd.setDate(gridEnd.getDate() + (6 - gridEnd.getDay()));

  const daysBack  = Math.max(0, _calDaysBetween(gridStart, today));
  const daysAhead = Math.max(0, _calDaysBetween(today, gridEnd));

  try {
    const qs = `days_back=${daysBack}&days_ahead=${daysAhead}${force ? '&refresh=1' : ''}`;
    const d = await (await fetch(`/api/calendar?${qs}`)).json();
    calEntries = d.entries || [];
    calMeta = {
      oldestAge:   d.oldest_meta_age,
      unavailable: d.unavailable || [],
      loadedAt:    Date.now(),
      refreshed:   !!d.refreshed,
    };
    renderCalChips();
    renderMonthGrid();
    if (force) {
      toast(calMeta.unavailable.length
        ? `Re-checked — ${calMeta.unavailable.length} title(s) could not be reached`
        : 'Release dates re-checked', calMeta.unavailable.length ? 'er' : 'ok');
    }
  } catch(e) {
    body.innerHTML = `<div style="color:var(--red);font-size:13px">Failed to load calendar: ${e.message}</div>`;
  }
}

function renderCalChips() {
  const wrap = document.getElementById('calChips');
  wrap.innerHTML = CAL_FILTERS.map(f =>
    `<button class="cal-chip${calFilter===f.id?' on':''}" onclick="calSetFilter('${f.id}')">${f.label}</button>`
  ).join('');
}

function calSetFilter(id) {
  calFilter = id;
  renderCalChips();
  renderMonthGrid();
}

function renderMonthGrid() {
  const monthDate = new Date(calViewYear, calViewMonth, 1);
  document.getElementById('calMonthLabel').textContent =
    monthDate.toLocaleDateString(undefined, { month:'long', year:'numeric' });

  const today = new Date(); today.setHours(0,0,0,0);
  const todayKey = _calDateKey(today);

  const grouped = {};
  calEntries.filter(calMatchesFilter).forEach(e => {
    const k = _calEntryDate(e);
    (grouped[k] = grouped[k] || []).push(e);
  });

  const firstDow = monthDate.getDay();
  const daysInMonth = new Date(calViewYear, calViewMonth + 1, 0).getDate();

  let weekdays = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']
    .map(d => `<div class="cal-weekday">${d}</div>`).join('');

  let cells = '';
  for (let i = 0; i < firstDow; i++) cells += `<div class="cal-cell blank"></div>`;

  for (let d = 1; d <= daysInMonth; d++) {
    const key = `${calViewYear}-${String(calViewMonth+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const isToday = key === todayKey;
    const dayEvents = grouped[key] || [];
    const maxShow = 2;
    const pills = dayEvents.slice(0, maxShow).map(e => {
      const cls = e.type === 'movie' ? 'movie' : (e.in_library ? 'inlib' : '');
      return `<div class="cal-pill ${cls}" title="${e.title}">${e.title}</div>`;
    }).join('');
    const more = dayEvents.length > maxShow
      ? `<div class="cal-cellmore">+${dayEvents.length - maxShow} more</div>` : '';

    cells += `<div class="cal-cell${key===calSelectedDate?' selected':''}" onclick="calSelectDay('${key}')">
      <span class="cal-cellnum${isToday?' today':''}">${d}</span>
      ${pills}${more}
    </div>`;
  }

  document.getElementById('calBody').innerHTML = `
    ${_calFreshnessHtml()}
    <div class="cal-weekrow">${weekdays}</div>
    <div class="cal-grid">${cells}</div>
    <div id="calDetail"></div>
  `;

  if (calSelectedDate) renderCalDetail();
}

function _calAgeStr(secs) {
  if (secs == null) return 'unknown';
  if (secs < 90)    return 'just now';
  if (secs < 5400)  return `${Math.round(secs/60)} min ago`;
  if (secs < 172800)return `${Math.round(secs/3600)} h ago`;
  return `${Math.round(secs/86400)} d ago`;
}

// Two things a calendar can't tell you by looking at it: how old the data
// behind it is, and whether anything is missing outright. Both are exactly
// the states where the calendar is "wrong", so both get said out loud.
function _calFreshnessHtml() {
  const bits = [];
  const age = calMeta.oldestAge;
  if (age != null) {
    const stale = age > 21600;   // >6h — beyond every non-settled TTL
    bits.push(`<span style="color:${stale ? 'var(--acc2)' : 'var(--mut)'}">
      Release data checked ${_calAgeStr(age)}${stale ? ' — hit Refresh to re-check' : ''}</span>`);
  }
  const un = calMeta.unavailable || [];
  if (un.length) {
    const names = un.slice(0, 3).map(u => u.title).join(', ');
    bits.push(`<span style="color:var(--red)">
      ${un.length} title${un.length===1?'':'s'} could not be checked (${names}${un.length>3?', …':''}) —
      ${un.length===1?'it may be':'they may be'} missing from this view</span>`);
  }
  if (!bits.length) return '';
  return `<div style="font-size:11px;line-height:1.6;margin-bottom:10px;display:flex;flex-direction:column;gap:2px">${bits.join('')}</div>`;
}

function calSelectDay(key) {
  calSelectedDate = key;
  renderMonthGrid();
  document.getElementById('calDetail').scrollIntoView({ behavior:'smooth', block:'nearest' });
}

function renderCalDetail() {
  const wrap = document.getElementById('calDetail');
  if (!wrap) return;
  const today = new Date(); today.setHours(0,0,0,0);
  const todayKey = _calDateKey(today);
  const isPast = calSelectedDate < todayKey;
  const dayEvents = calEntries.filter(calMatchesFilter).filter(e => _calEntryDate(e) === calSelectedDate);

  const label = _calDateLabel(calSelectedDate, calSelectedDate === todayKey);

  if (!dayEvents.length) {
    wrap.innerHTML = `<div class="cal-detail">
      <div class="cal-detail-date">${label}</div>
      <div class="cal-detail-empty">No releases this day.</div>
    </div>`;
    return;
  }

  const rows = dayEvents.map(e => _calEntryHtml(e, isPast)).join('');
  wrap.innerHTML = `<div class="cal-detail">
    <div class="cal-detail-date">${label}</div>
    <div class="cal-entries">${rows}</div>
  </div>`;
}

function _calDateLabel(dateStr, isToday) {
  const d = new Date(dateStr + 'T12:00:00');  // noon avoids DST edge cases
  const opts = { weekday:'long', month:'long', day:'numeric' };
  const fmt = d.toLocaleDateString(undefined, opts);
  return isToday ? `Today — ${fmt}` : fmt;
}

function _calEntryHtml(e, isPast) {
  const poster = e.poster
    ? `<img class="cal-poster" src="${e.poster}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
    : '';
  const posterFallback = `<div class="cal-poster-placeholder" style="${e.poster?'display:none':''}">
    ${e.type === 'movie' ? '🎬' : '📺'}
  </div>`;

  // release_ts is a precise Unix timestamp (date + time), not just a date —
  // this is also exactly what governs whether an episode is eligible for
  // auto-stubbing (_is_aired compares against this same timestamp), so
  // showing it here means what you see in the calendar is the same clock
  // the stubbing logic is actually using, not just the release date.
  const relDate = new Date(e.release_ts * 1000);
  const timeStr = relDate.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

  const sub = e.type === 'episode'
    ? `S${String(e.season).padStart(2,'0')}E${String(e.episode).padStart(2,'0')} — ${e.episode_name} · ${timeStr}`
    : `${e.type === 'movie' ? 'Movie' : 'Series'} · ${_calEntryDate(e)} · ${timeStr}`;

  const badges = [];
  if (e.in_library)    badges.push('<span class="cal-badge inlib">In library</span>');
  if (e.type==='movie' && e.date_type==='theatrical') badges.push('<span class="cal-badge theatrical">Theatrical date · digital may differ</span>');
  // Per-entry provenance: a date sourced from days-old metadata is worth
  // flagging on the row itself, since that's where you'd act on it.
  if (e.meta_age != null && e.meta_age > 21600)
    badges.push(`<span class="cal-badge stale" title="Cinemeta metadata for this title was last fetched ${_calAgeStr(e.meta_age)}">Date from ${_calAgeStr(e.meta_age)}</span>`);

  const key = e.type === 'episode'
    ? `${e.imdb_id}:${e.season}:${e.episode}`
    : e.imdb_id;

  const rescanBtn = _calRescanBtnHtml(e, key, isPast);

  return `<div class="cal-entry${e.in_library?' inlib':''}${!isPast?' future':''}"
    onclick='_calEntryClick(${JSON.stringify(e).replace(/'/g, "&#39;")})'>
    ${poster}${posterFallback}
    <div class="cal-info">
      <div class="cal-title">${e.title}</div>
      <div class="cal-sub">${sub}</div>
      ${badges.length ? `<div class="cal-badges">${badges.join('')}</div>` : ''}
    </div>
    ${rescanBtn}
  </div>`;
}

function _calRescanBtnHtml(e, key, isPast) {
  // Only show for content not yet in library OR for past episodes that might
  // now have streams available (scheduled rescan within 30min of release).
  const isScheduled = !!_calScheduled[key];
  const relTs = e.release_ts * 1000;
  const now = Date.now();
  const minsAgo = (now - relTs) / 60000;
  const minsUntil = (relTs - now) / 60000;

  if (minsUntil > 0 && minsUntil <= 60) {
    // Releases within the next hour — show "scan at release" button
    return `<button class="cal-rescan-btn${isScheduled?' pending':''}"
      id="crbtn_${key.replace(/[:]/g,'_')}"
      onclick="event.stopPropagation();calScheduleRescan(${JSON.stringify(e)},${JSON.stringify(key)})"
      title="Schedule a rescan 30 minutes after release">
      ${isScheduled ? '⏳ Scheduled' : '⏰ Schedule scan'}
    </button>`;
  }
  if (minsAgo >= 0 && minsAgo <= 120) {
    // Recently released (within 2 hours) — scan now (or scheduled)
    return `<button class="cal-rescan-btn${isScheduled?' pending':''}"
      id="crbtn_${key.replace(/[:]/g,'_')}"
      onclick="event.stopPropagation();calRescanNow(${JSON.stringify(e)},${JSON.stringify(key)})"
      title="Scan for this release now">
      ${isScheduled ? '⏳ Scanning…' : '🔍 Scan now'}
    </button>`;
  }
  if (!e.in_library && isPast) {
    return `<button class="cal-rescan-btn"
      onclick="event.stopPropagation();calRescanNow(${JSON.stringify(e)},${JSON.stringify(key)})"
      title="Try to find a stream for this">
      Search
    </button>`;
  }
  // Not released yet (more than an hour out) and not in the library.
  // Previously this rendered nothing at all, so an upcoming title was
  // simply unsearchable from the calendar — you could only wait for the
  // automatic sweeps. Release dates are wrong often enough (early digital
  // windows, streaming-first drops, regional/simulcast timing, plain stale
  // Cinemeta metadata) that being able to say "look now anyway" matters.
  // The search still has to actually find something, so a genuinely
  // unreleased title just comes back empty rather than doing any harm.
  if (!e.in_library) {
    const relDate = new Date(e.release_ts * 1000);
    const daysOut = Math.ceil((relDate - Date.now()) / 86400000);
    return `<button class="cal-rescan-btn"
      onclick="event.stopPropagation();calRescanNow(${JSON.stringify(e)},${JSON.stringify(key)})"
      title="Not due for ~${daysOut} day${daysOut === 1 ? '' : 's'} — search for it anyway">
      Search anyway
    </button>`;
  }
  return '';
}

function _calEntryClick(e) {
  // Clicking a row used to do almost nothing: for an episode it tried to
  // open the Library series modal, which only worked if the show was
  // already tracked there, and for a movie it did literally nothing.
  // Anything upcoming — i.e. the whole reason to look at a calendar — was
  // a dead click.
  //
  // For something already in the library, keep the old behaviour: jump to
  // its Library detail, which is what you actually want (manage seasons,
  // inspect the active stream). For anything NOT in the library, open the
  // manual search picker directly on this exact release, so you can go
  // looking for a source by hand the moment you see it listed — including
  // for titles that aren't out yet, where automatic searches deliberately
  // hold off but an early digital/streaming drop may already be up.
  if (e.in_library && e.type === 'episode' && window._libGroups) {
    const key = Object.keys(window._libGroups).find(k => window._libGroups[k].imdb === e.imdb_id);
    if (key) { openSeriesDetail(key); return; }
  }

  openManualSearchModal(e.type === 'episode' ? 'episode' : 'movie', {
    imdb_id: e.imdb_id,
    title:   e.title,
    poster:  e.poster || '',
    year:    e.year || null,
    season:  e.season,
    episode: e.episode,
    onDone:  () => loadCalendar(),
    context: _calSearchContext(e),
  });
}

// Short note shown at the top of the picker explaining what you're looking
// at, since searching from a calendar means you're often searching for
// something that hasn't technically come out yet.
function _calSearchContext(e) {
  const mins = (e.release_ts * 1000 - Date.now()) / 60000;
  if (mins > 1440)
    return `Not due for about ${Math.ceil(mins/1440)} more day(s) — sources may not exist yet, but early digital and streaming-first drops often land before the listed date.`;
  if (mins > 0)
    return `Due in about ${Math.max(1, Math.round(mins))} min — sources usually appear shortly after release.`;
  if (e.type === 'movie')
    return 'Listed date is the theatrical date; the digital release is usually later.';
  return 'Released — if nothing shows up, try again in a little while.';
}

async function calScheduleRescan(entry, key) {
  const btnId = 'crbtn_' + key.replace(/:/g, '_');
  const btn = document.getElementById(btnId);
  if (btn) { btn.textContent = '⏳ Scheduled'; btn.classList.add('pending'); }

  const relTs = entry.release_ts * 1000;
  const delayMs = Math.max(0, relTs - Date.now()) + 30 * 60 * 1000;  // 30 min after release

  // Cancel any existing timer for this key
  if (_calScheduled[key]) clearTimeout(_calScheduled[key]);

  _calScheduled[key] = setTimeout(async () => {
    delete _calScheduled[key];
    await calRescanNow(entry, key);
  }, delayMs);

  const minsUntil = Math.round(delayMs / 60000);
  toast(`Will scan for "${entry.title}" in ~${minsUntil} min`, 'ok');
}

async function calRescanNow(entry, key) {
  const btnId = 'crbtn_' + key.replace(/:/g, '_');
  const btn = document.getElementById(btnId);
  if (btn) { btn.textContent = '⏳ Scanning…'; btn.classList.add('pending'); }

  try {
    // force: true on every one of these — they're all explicit clicks, and
    // the whole point of a manual search is to look regardless of what the
    // release/air date says. The background sweeps never set it, so the
    // automatic behaviour (don't waste queries on unreleased content, don't
    // catch pre-digital cam/TS leaks) is unchanged.
    if (entry.type === 'episode') {
      // Use the single-episode add endpoint
      const r = await fetch(`/api/series/${entry.imdb_id}/episode/${entry.season}/${entry.episode}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imdb_id: entry.imdb_id, title: entry.title, media_type: 'series', force: true }),
      });
      const d = await r.json();
      if (r.ok && d.stubbed) {
        toast(`${entry.title} S${String(entry.season).padStart(2,'0')}E${String(entry.episode).padStart(2,'0')} added`, 'ok');
        if (btn) { btn.textContent = '✓ Added'; btn.classList.remove('pending'); btn.classList.add('active'); }
        setTimeout(loadCalendar, 1500);
      } else {
        throw new Error(d.detail || 'No stream found yet');
      }
    } else {
      // Movie: try adding via the main add endpoint
      const r = await fetch('/api/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imdb_id: entry.imdb_id, title: entry.title, media_type: 'movie', force: true }),
      });
      const d = await r.json();
      if (r.ok && d.pending) {
        // With force set, this now means the search genuinely ran and came
        // back with nothing — not that we declined to look. Tracked for
        // automatic retry either way, so don't claim "Added".
        toast(`Nothing available for "${entry.title}" yet — tracking it for automatic retry`, 'ok');
        if (btn) { btn.textContent = 'Tracking'; btn.classList.add('pending'); }
      } else if (r.ok) {
        toast(`"${entry.title}" added to library`, 'ok');
        if (btn) { btn.textContent = '✓ Added'; btn.classList.remove('pending'); btn.classList.add('active'); }
        setTimeout(loadCalendar, 1500);
      } else {
        throw new Error(d.detail || 'No stream found');
      }
    }
  } catch(e) {
    toast(e.message || 'Scan failed', 'er');
    if (btn) { btn.textContent = 'Retry'; btn.classList.remove('pending'); }
  }
}

// ── Library ───────────────────────────────────────────────────
let libMissingCounts = {};

let libPendingMovies = [];
let libWantedSeasons = [];
let libSeasonWatch = [];
let libQualityUnavailable = [];
let libLibraryItems = [];

async function loadLib() {
  await syncStubs();
  allStubs = [...stubs];
  try {
    const [pm, ws, sw, qu, li] = await Promise.all([
      fetch('/api/pending-movies').then(r => r.json()).catch(() => ({items:[]})),
      fetch('/api/wanted-seasons').then(r => r.json()).catch(() => ({items:[]})),
      fetch('/api/season-watch').then(r => r.json()).catch(() => ({items:[]})),
      fetch('/api/quality-unavailable').then(r => r.json()).catch(() => ({items:[]})),
      fetch('/api/library/items').then(r => r.json()).catch(() => ({items:[]})),
    ]);
    libPendingMovies      = pm.items || [];
    libWantedSeasons      = ws.items || [];
    libSeasonWatch        = sw.items || [];
    libQualityUnavailable = qu.items || [];
    libLibraryItems       = li.items || [];
  } catch {
    libPendingMovies = []; libWantedSeasons = []; libSeasonWatch = []; libQualityUnavailable = []; libLibraryItems = [];
  }
  renderLibChips();
  applyLibFilters();
  try {
    const d = await (await fetch('/api/library/missing-counts')).json();
    libMissingCounts = d.counts || {};
    applyLibFilters();   // re-render now that counts are in, without blocking the first paint on them
  } catch {}
}

function libSetQuery(q) {
  libQuery = q;
  libMoviePage = 1; libSeriesPage = 1;
  applyLibFilters();
}

function renderLibChips() {
  document.getElementById('libChips').innerHTML = LIB_FILTERS.map(f =>
    `<button class="cal-chip${libStateFilter === f.id ? ' on' : ''}" onclick="libSetStateFilter('${f.id}')">${f.label}</button>`
  ).join('');
}

function libSetStateFilter(id) {
  libStateFilter = id;
  libMoviePage = 1; libSeriesPage = 1;
  renderLibChips();
  applyLibFilters();
}

function libGoToPage(kind, p) {
  if (kind === 'movie') libMoviePage = p; else libSeriesPage = p;
  applyLibFilters();
  document.getElementById('libGrid').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function libToggleViewAll(kind) {
  if (kind === 'movie') { libMovieViewAll = !libMovieViewAll; libMoviePage = 1; }
  else { libSeriesViewAll = !libSeriesViewAll; libSeriesPage = 1; }
  applyLibFilters();
}

function applyLibFilters() {
  const q = libQuery;
  const textFiltered = q
    ? allStubs.filter(s => (s.title || s.media_id).toLowerCase().includes(q.toLowerCase()))
    : allStubs;
  renderLib(textFiltered);
}

// ── Library: group stubs by base IMDb ID (one card per title) ─
function groupStubs(items) {
  const map = {};
  items.forEach(s => {
    const base = s.media_id.split('_')[0];
    if (!map[base]) map[base] = {
      title: s.title || base,
      imdb: base,
      poster: s.poster || '',
      media_type: s.media_type || 'movie',
      year: s.year || null,
      stubs: []
    };
    if (s.poster && !map[base].poster) map[base].poster = s.poster;
    if (s.year && !map[base].year) map[base].year = s.year;
    map[base].stubs.push(s);
  });
  return Object.values(map);
}

// True once a title has at least one real stub — from that point on it
// gets its normal active/placeholder card, never the synthetic
// pending/wanted/watching/unavailable-only layouts below, even if one
// of those flags is also set on it (e.g. an active show that also has
// a wanted future season). Those flags still show up as a small
// caption on the real card via _trackingCaption().
function _hasRealStub(g) {
  return !!(g.stubs && g.stubs.length);
}

function libGroupCard(g) {
  if (g.pending && !_hasRealStub(g)) {
    const safeId = g.imdb.replace(/[^a-z0-9]/gi,'');
    const posterHtml = g.poster
      ? `<img src="${g.poster}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:10px;opacity:0;transition:opacity .3s" onload="this.style.opacity=1" onerror="this.style.display='none'"/>`
      : '';
    return `<div style="cursor:pointer" onclick="openPendingMovieModal('${safeId}')">
      <div class="cposter" style="position:relative;opacity:.75">
        ${posterHtml}
        <div style="position:absolute;bottom:0;left:0;right:0;background:rgba(74,158,255,.9);color:#04111f;font-size:10px;font-weight:700;text-align:center;padding:4px 2px;border-radius:0 0 10px 10px">TRACKING</div>
      </div>
      <div class="cname" style="margin-top:8px">${g.title}</div>
      <span class="stub-state" style="color:var(--blue);border-color:var(--blue)">pending</span>
    </div>`;
  }

  // Wanted seasons and season-watch are the same idea to the person —
  // "get future seasons automatically" — so they share one unified
  // TRACKING card (a show with both never renders twice). The banner is
  // always just "TRACKING"; the specific tracked seasons are shown in
  // the modal when the card is clicked, not on the cover art.
  if ((g.wantedSeasons || g.watching) && !_hasRealStub(g)) {
    const safeId = g.imdb.replace(/[^a-z0-9]/gi,'');
    const posterHtml = g.poster
      ? `<img src="${g.poster}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:10px;opacity:0;transition:opacity .3s" onload="this.style.opacity=1" onerror="this.style.display='none'"/>`
      : '';
    return `<div style="cursor:pointer" onclick="openUpcomingShowCard('${safeId}')">
      <div class="cposter" style="position:relative;opacity:.75">
        ${posterHtml}
        <div style="position:absolute;bottom:0;left:0;right:0;background:rgba(74,158,255,.9);color:#04111f;font-size:10px;font-weight:700;text-align:center;padding:4px 2px;border-radius:0 0 10px 10px">TRACKING</div>
      </div>
      <div class="cname" style="margin-top:8px">${g.title}</div>
      <span class="stub-state" style="color:var(--blue);border-color:var(--blue)">upcoming</span>
    </div>`;
  }

  if (g.qualityUnavailable && !_hasRealStub(g)) {
    const safeId = g.imdb.replace(/[^a-z0-9]/gi,'');
    const posterHtml = g.poster
      ? `<img src="${g.poster}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:10px;opacity:0;transition:opacity .3s" onload="this.style.opacity=1" onerror="this.style.display='none'"/>`
      : '';
    const sub = g.season != null && g.episode != null
      ? `S${String(g.season).padStart(2,'0')}E${String(g.episode).padStart(2,'0')}`
      : '4K';
    return `<div style="cursor:pointer" onclick="openQualityUnavailableCard('${safeId}')">
      <div class="cposter" style="position:relative;opacity:.75">
        ${posterHtml}
        <div style="position:absolute;bottom:0;left:0;right:0;background:rgba(232,160,32,.9);color:#000;font-size:10px;font-weight:700;text-align:center;padding:4px 2px;border-radius:0 0 10px 10px">${sub} 4K UNAVAILABLE</div>
      </div>
      <div class="cname" style="margin-top:8px">${g.title}</div>
      <span class="stub-state" style="color:var(--acc2);border-color:var(--acc2)">unavailable</span>
    </div>`;
  }

  const has4k = g.stubs.some(s => s.quality === '4k');
  const hasHd = g.stubs.some(s => s.quality === 'hd');
  const state = _groupState(g);
  const sc = {placeholder:'ss-ph',active:'ss-ac',error:'ss-er',resolving:'ss-rs'}[state]||'ss-ph';
  const safeId = g.imdb.replace(/[^a-z0-9]/gi,'');
  const badges = [
    hasHd ? `<span style="background:rgba(0,0,0,.88);color:var(--blue);border-radius:5px;padding:2px 7px;font-size:10px;font-weight:700;display:block">HD</span>` : '',
    has4k ? `<span style="background:rgba(0,0,0,.88);color:var(--acc2);border-radius:5px;padding:2px 7px;font-size:10px;font-weight:700;display:block">4K</span>` : ''
  ].filter(Boolean).join('');
  const posterHtml = g.poster
    ? `<img src="${g.poster}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:10px;opacity:0;transition:opacity .3s" onload="this.style.opacity=1" onerror="this.style.display='none'"/>`
    : '';
  const cardClick = g.media_type === 'series'
    ? `openSeriesDetail('${safeId}')`
    : `openDelModal('${safeId}')`;
  // Missing count comes from /api/library/missing-counts, fetched once
  // when the library loads (see loadLib) — scoped server-side to
  // requested seasons only, the same definition used everywhere else, so a season
  // you never requested never shows up here just because Cinemeta lists it.
  const missingCount = g.media_type === 'series' ? (libMissingCounts[g.imdb] || 0) : 0;
  const missingBar = missingCount > 0
    ? `<div style="position:absolute;bottom:0;left:0;right:0;background:rgba(163,45,45,.9);color:#fff;font-size:10px;font-weight:700;text-align:center;padding:4px 2px;border-radius:0 0 10px 10px">${missingCount} EP${missingCount === 1 ? '' : 'S'} MISSING</div>`
    : '';
  return `<div style="cursor:pointer" onclick="${cardClick}">
    <div class="cposter" style="position:relative">
      ${posterHtml}
      <div style="position:absolute;top:8px;right:8px;display:flex;flex-direction:column;gap:4px;align-items:flex-end">${badges}</div>
      <button class="del-btn" style="position:absolute;top:8px;left:8px" onclick="event.stopPropagation();openDelModal('${safeId}')" title="Remove">✕</button>
      ${missingBar}
    </div>
    <div class="cname" style="margin-top:8px">${g.title}</div>
    <span class="stub-state ${sc}">${state}</span>
    ${_trackingCaption(g)}
    ${_requesterCaption(g)}
  </div>`;
}

// Small line under an already-active card noting that it's ALSO tracked
// for something not in Plex yet — a future season, indefinite
// season-watch, or a 4K stub that couldn't be resolved. Only ever shown
// on a real (has-stubs) card; the tracking-only synthetic cards above
// already say this via their own banner instead.
function _trackingCaption(g) {
  if (!_hasRealStub(g)) return '';
  const bits = [];
  if (g.wantedSeasons && g.wantedSeasons.length) bits.push('Tracking future season');
  else if (g.watching) bits.push('Tracking future seasons');
  if (g.qualityUnavailable) bits.push('4K unavailable');
  if (!bits.length) return '';
  return `<div style="font-size:11px;color:var(--blue);margin-top:3px;line-height:1.3">${bits.join(' · ')}</div>`;
}

// Small "Requested by X" line under a library card. Only titles added
// after requester tracking existed have anyone to credit, so this is
// empty for the back catalogue rather than guessing. In the Recently
// added tab it also carries the age, since that's the tab where when
// something arrived is the point.
function _requesterCaption(g) {
  const bits = [];
  if (g.requested_by) bits.push(`Requested by ${g.requested_by}`);
  if (libStateFilter === 'recent' && g.added_at) bits.push(_relTime(g.added_at));
  if (!bits.length) return '';
  return `<div style="font-size:11px;color:var(--mut);margin-top:3px;line-height:1.3;
    overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${bits.join(' · ')}</div>`;
}

// Coarse relative time — hours, then days, then weeks. Nothing here
// needs minute precision and "3w ago" reads better than a date.
function _relTime(ts) {
  const secs = Math.max(0, (Date.now() / 1000) - ts);
  if (secs < 3600)   return 'just now';
  if (secs < 86400)  return `${Math.floor(secs / 3600)}h ago`;
  if (secs < 604800) return `${Math.floor(secs / 86400)}d ago`;
  return `${Math.floor(secs / 604800)}w ago`;
}

function _groupState(g) {
  const states = g.stubs.map(s => s.state);
  return states.includes('error') ? 'error'
       : states.includes('resolving') ? 'resolving'
       : states.includes('active') ? 'active' : 'placeholder';
}

// Used for the Active/Placeholder filter chips — deliberately different
// from _groupState() above. _groupState collapses a whole title down to
// one "worst state wins" summary for the card badge, which is right for
// a badge but wrong for filtering: a 20-episode show with 19 placeholder
// episodes and 1 already-played one would summarize as "active" and
// disappear entirely from the Placeholder filter. Filtering instead asks
// "does this title have ANY stub in the state I'm looking for" — so a
// mostly-placeholder show still shows up under Placeholder even if one
// episode happens to be active.
function _groupHasState(g, state) {
  return g.stubs.some(s => s.state === state);
}

function renderLib(items) {
  const el = document.getElementById('libGrid');
  el.style.display = 'block';
  const anyExtra = libPendingMovies.length || libWantedSeasons.length || libSeasonWatch.length || libQualityUnavailable.length;
  if (!items.length && !anyExtra) {
    el.innerHTML = `<div style="color:var(--mut);font-size:14px;padding:40px 0">
      No stubs yet. Browse Home or Search and click Add to Plex.
    </div>`;
    return;
  }

  let groups = groupStubs(items);
  const q = libQuery.toLowerCase();

  // Every synthetic "tracking" entry below (pending / wanted-seasons /
  // season-watch / quality-unavailable) describes a *status*, not a
  // separate title — if the show already has a real card from stubs
  // (groupStubs, above), the status belongs ON that card, not as a
  // second card with the same IMDb id. This map is how we find "does
  // this title already have a card" before deciding to push a new one.
  const groupByImdb = {};
  groups.forEach(g => { groupByImdb[g.imdb] = g; });

  // Pending movies never have a stub, so groupStubs() never sees them —
  // add a synthetic group per pending movie so they show up as
  // "Tracking" cards. stubs stays empty on these; libGroupCard checks
  // for .pending to render them distinctly. If the title already has a
  // real card (e.g. a stub already exists again), just flag it instead.
  for (const p of libPendingMovies) {
    if (q && !(p.title || '').toLowerCase().includes(q)) continue;
    if (groupByImdb[p.imdb_id]) {
      groupByImdb[p.imdb_id].pending = true;
      continue;
    }
    const g = {
      title: p.title, imdb: p.imdb_id, poster: p.poster || '',
      media_type: 'movie', year: p.year || null,
      stubs: [], pending: true, added_at: p.added_at,
    };
    groups.push(g);
    groupByImdb[p.imdb_id] = g;
  }

  // Wanted seasons — grouped by show, since a show could have more than
  // one wanted season number at once (rare, but possible). If the show
  // already has a real card, the wanted seasons attach to it instead of
  // spawning a second "upcoming" card for the same title.
  const wantedByShow = {};
  for (const w of libWantedSeasons) {
    if (q && !(w.title || '').toLowerCase().includes(q)) continue;
    const existing = groupByImdb[w.imdb_id];
    if (existing) {
      if (!existing.wantedSeasons) existing.wantedSeasons = [];
      existing.wantedSeasons.push(w.season);
      wantedByShow[w.imdb_id] = existing;
      continue;
    }
    if (!wantedByShow[w.imdb_id]) {
      wantedByShow[w.imdb_id] = {
        title: w.title, imdb: w.imdb_id, poster: w.poster || '',
        media_type: 'series', year: w.year || null,
        stubs: [], wantedSeasons: [], added_at: w.added_at,
      };
      groups.push(wantedByShow[w.imdb_id]);
      groupByImdb[w.imdb_id] = wantedByShow[w.imdb_id];
    }
    wantedByShow[w.imdb_id].wantedSeasons.push(w.season);
  }

  // Season-watch — shows with indefinite tracking enabled. Watching and
  // per-season tracking are the same idea from the person's point of
  // view ("get me future seasons automatically"), so a show that has
  // BOTH gets ONE card, not two: if a wanted-seasons group (or a real
  // stub-based card) for this show already exists, just flag it as
  // watching instead of pushing a duplicate group.
  for (const w of libSeasonWatch) {
    if (q && !(w.title || '').toLowerCase().includes(q)) continue;
    const existing = groupByImdb[w.imdb_id] || wantedByShow[w.imdb_id];
    if (existing) {
      existing.watching = true;
      continue;
    }
    const g = {
      title: w.title, imdb: w.imdb_id, poster: w.poster || '',
      media_type: 'series', year: w.year || null,
      stubs: [], watching: true, added_at: w.enabled_at,
    };
    groups.push(g);
    groupByImdb[w.imdb_id] = g;
  }

  // 4K-unavailable — one entry per movie or specific episode. Attaches
  // to an existing real card for the same title rather than spawning a
  // second card, same rule as above.
  for (const u of libQualityUnavailable) {
    if (q && !(u.title || '').toLowerCase().includes(q)) continue;
    const existing = groupByImdb[u.key];
    if (existing) {
      existing.qualityUnavailable = true;
      existing.season = u.season; existing.episode = u.episode;
      existing.marked_at = u.marked_at; existing._realImdbId = u.imdb_id;
      continue;
    }
    const g = {
      title: u.title, imdb: u.key, poster: u.poster || '',
      media_type: u.season != null ? 'series' : 'movie', year: null,
      stubs: [], qualityUnavailable: true,
      season: u.season, episode: u.episode, marked_at: u.marked_at,
      _realImdbId: u.imdb_id,
    };
    groups.push(g);
    groupByImdb[u.key] = g;
  }

  // Library items with zero remaining stubs — e.g. every quality stub
  // for a title was deleted (Delete HD/4K stub, or Delete both) but the
  // title itself was never explicitly removed via Delete series/movie.
  // Without this, groupStubs() (which only ever sees stubs) would make
  // the title vanish from the Library the moment its last stub is gone —
  // exactly what "Delete HD stub" etc. are meant NOT to do. Skipped if
  // the title already has a card from stubs, or from one of the tracked
  // states above (pending/wanted/watching/unavailable), so this only
  // ever adds a card, never duplicates one.
  const alreadyShown = new Set(groups.map(g => g.imdb));
  for (const li of libLibraryItems) {
    if (alreadyShown.has(li.imdb_id)) continue;
    if (q && !(li.title || '').toLowerCase().includes(q)) continue;
    groups.push({
      title: li.title, imdb: li.imdb_id, poster: li.poster || '',
      media_type: li.media_type || 'movie', year: li.year || null,
      stubs: [], added_at: li.added_at,
    });
    alreadyShown.add(li.imdb_id);
  }

  // Fold the library_items record (added_at, requester) onto every
  // group, however that group was built. Groups assembled from stubs
  // don't carry either field — stubs only know about streams — so
  // without this pass "Recently added" and the requester line would
  // only ever work for the zero-stub titles below.
  const libMeta = {};
  for (const li of libLibraryItems) libMeta[li.imdb_id] = li;
  for (const g of groups) {
    const li = libMeta[g.imdb];
    if (!li) continue;
    if (!g.added_at) g.added_at = li.added_at;
    g.requested_by       = li.requested_by || '';
    g.requested_by_thumb = li.requested_by_thumb || '';
    g.requested_at       = li.requested_at || null;
  }

  if (libStateFilter === 'recent') {
    // Newest first, and only titles we actually know an add time for —
    // anything predating library_items has no added_at and would
    // otherwise sort to the bottom as "added in 1970".
    const dated = groups.filter(g => g.added_at);
    const cutoff = (Date.now() / 1000) - (LIB_RECENT_DAYS * 86400);
    const inWindow = dated.filter(g => g.added_at >= cutoff);
    groups = (inWindow.length ? inWindow : dated)
      .sort((a, b) => b.added_at - a.added_at)
      .slice(0, inWindow.length ? undefined : LIB_RECENT_FALLBACK);
  } else if (libStateFilter === 'upcoming') {
    // Tracked, but not actually in Plex yet, for any reason: a pending
    // movie, a wanted (not-yet-aired) season, or a show under indefinite
    // season-watch.
    groups = groups.filter(g => g.pending || g.wantedSeasons || g.watching);
  } else if (libStateFilter === 'unavailable') {
    groups = groups.filter(g => g.qualityUnavailable);
  } else if (libStateFilter === 'missing') {
    // Purely about existing series with missing episodes now — pending
    // movies, wanted seasons, and season-watch all have their own home
    // under "Upcoming" instead of overlapping here too.
    groups = groups.filter(g => g.media_type === 'series' && (libMissingCounts[g.imdb] || 0) > 0);
  } else if (libStateFilter !== 'all') {
    // A tracking-only card (no real stub) never matches Active/Placeholder —
    // it isn't in Plex yet, whatever its stub-like flags say. A card that
    // DOES have a real stub is judged purely on _groupHasState, even if it
    // also carries a tracking flag (e.g. an active show also tracking a
    // future season still belongs in "Active").
    groups = groups.filter(g =>
      (_hasRealStub(g) || (!g.pending && !g.wantedSeasons && !g.watching && !g.qualityUnavailable)) &&
      _groupHasState(g, libStateFilter)
    );
  }

  if (!groups.length) {
    el.innerHTML = `<div style="color:var(--mut);font-size:14px;padding:40px 0">
      Nothing matches this filter.
    </div>`;
    return;
  }

  // Alphabetical everywhere except "Recently added", which was just
  // sorted newest-first and would lose that ordering here.
  if (libStateFilter !== 'recent') {
    groups.sort((a, b) => (a.title || '').localeCompare(b.title || ''));
  }

  window._libGroups = {};
  groups.forEach(g => { window._libGroups[g.imdb.replace(/[^a-z0-9]/gi,'')] = g; });

  const movies = groups.filter(g => g.media_type !== 'series');
  const series = groups.filter(g => g.media_type === 'series');

  const html =
    renderLibSection('movie',  'Movies',   movies) +
    renderLibSection('series', 'TV Shows', series);

  el.innerHTML = html;
}

// Each section (Movies / TV Shows) paginates independently, with its own
// "View all" toggle to drop pagination and show every title in that
// section at once.
function renderLibSection(kind, label, groupsForSection) {
  if (!groupsForSection.length) return '';

  const viewAll = kind === 'movie' ? libMovieViewAll : libSeriesViewAll;
  const totalPages = Math.max(1, Math.ceil(groupsForSection.length / LIB_PAGE_SIZE));

  if (kind === 'movie') { if (libMoviePage > totalPages) libMoviePage = totalPages; }
  else { if (libSeriesPage > totalPages) libSeriesPage = totalPages; }
  const page = kind === 'movie' ? libMoviePage : libSeriesPage;

  const pageItems = viewAll
    ? groupsForSection
    : groupsForSection.slice((page - 1) * LIB_PAGE_SIZE, page * LIB_PAGE_SIZE);

  const showPagination = !viewAll && totalPages > 1;
  const viewAllLabel = viewAll ? 'Show paginated' : 'View all';

  return `<div style="margin-bottom:36px">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;gap:12px;flex-wrap:wrap">
      <div class="sec-title">${label} <span style="color:var(--mut);font-weight:400;font-size:13px">(${groupsForSection.length})</span></div>
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
        ${libStateFilter === 'active' ? `<button class="btn bg2" style="padding:5px 14px;font-size:12px;color:var(--red);border-color:rgba(255,85,85,.35)" onclick="clearActiveStubsSection('${kind}', this)">Clear all active</button>` : ''}
        <button class="btn bg2" style="padding:5px 14px;font-size:12px" onclick="libToggleViewAll('${kind}')">${viewAllLabel}</button>
      </div>
    </div>
    <div class="libgrid">${pageItems.map(libGroupCard).join('')}</div>
    ${showPagination ? renderLibPaginationHtml(kind, page, totalPages, groupsForSection.length) : ''}
  </div>`;
}

// "Clear all active" for one Library section (Movies or TV Shows) —
// bulk revert of every active stub of that media type back to a
// placeholder, via /api/stubs/clear-active. Uses the same two-click
// arm/confirm pattern as the destructive delete buttons: first click
// arms, second click within the same render actually fires.
async function clearActiveStubsSection(kind, btn) {
  const mediaType = kind === 'movie' ? 'movie' : 'series';
  if (btn && !btn.dataset.armed) {
    btn.dataset.armed = '1';
    btn.textContent = 'Confirm clear?';
    setTimeout(() => {
      if (btn.isConnected && btn.dataset.armed) {
        delete btn.dataset.armed;
        btn.textContent = 'Clear all active';
      }
    }, 4000);
    return;
  }
  if (btn) { btn.disabled = true; btn.textContent = 'Clearing…'; }
  try {
    const r = await fetch('/api/stubs/clear-active', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ media_type: mediaType }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Clear failed');
    toast(`Cleared ${d.cleared} active stub${d.cleared === 1 ? '' : 's'} — reverted to placeholder`, 'ok');
    loadLib();
  } catch (exc) {
    toast(exc.message || 'Clear failed', 'er');
    if (btn) { btn.disabled = false; delete btn.dataset.armed; btn.textContent = 'Clear all active'; }
  }
}

function renderLibPaginationHtml(kind, page, totalPages, totalCount) {
  const pageBtn = (label, p, disabled) =>
    `<button class="cal-navbtn" style="width:auto;min-width:32px;padding:0 10px" ${disabled ? 'disabled' : ''} onclick="libGoToPage('${kind}', ${p})">${label}</button>`;
  const numBtn = (p) =>
    `<button class="cal-navbtn" style="width:32px;padding:0;${p === page ? 'background:var(--acc);color:#000;border-color:var(--acc)' : ''}" onclick="libGoToPage('${kind}', ${p})">${p}</button>`;

  // Windowed page numbers: first, last, current ±1, "…" for gaps.
  const pages = [];
  for (let p = 1; p <= totalPages; p++) {
    if (p === 1 || p === totalPages || Math.abs(p - page) <= 1) {
      pages.push(p);
    } else if (pages[pages.length - 1] !== '…') {
      pages.push('…');
    }
  }

  let html = `<div style="display:flex;align-items:center;justify-content:center;gap:8px;margin-top:20px;flex-wrap:wrap">`;
  html += pageBtn('‹ Prev', page - 1, page === 1);
  html += pages.map(p => p === '…'
    ? `<span style="color:var(--mut);font-size:13px;padding:0 4px">…</span>`
    : numBtn(p)
  ).join('');
  html += pageBtn('Next ›', page + 1, page === totalPages);
  html += `<span style="color:var(--mut);font-size:12px;margin-left:10px">${totalCount} title${totalCount === 1 ? '' : 's'}</span>`;
  html += `</div>`;
  return html;
}


// ── Series detail modal ────────────────────────────────────────
const _bg_scans_ui = new Set();

async function openSeriesDetail(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;

  // Show loading immediately
  const dlg = document.createElement('div');
  dlg.id = 'seriesDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.82);backdrop-filter:blur(16px);z-index:300;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `<div style="color:var(--mut);font-size:14px">Loading…</div>`;
  dlg.addEventListener('click', e => { if (e.target===dlg) dlg.remove(); });
  document.body.appendChild(dlg);

  let epData;
  try {
    const r = await fetch(`/api/series/${g.imdb}/episodes`);
    epData = await r.json();
  } catch(e) {
    dlg.querySelector('div').innerHTML = '<span style="color:var(--red)">Failed to load</span>';
    return;
  }

  const episodes   = epData.episodes || [];
  const isScanning = _bg_scans_ui.has(g.imdb) || epData.scanning;

  // Group ALL episodes by season — including seasons with zero stubs
  // ("not yet requested") and unaired ones, not just aired+stubbed ones.
  const seasonMap = {};
  episodes.forEach(ep => {
    seasonMap[ep.season] = seasonMap[ep.season] || [];
    seasonMap[ep.season].push(ep);
  });
  const seasons = Object.keys(seasonMap).map(Number).sort((a,b)=>a-b);

  // A season is "requested" if at least one of its episodes has a stub
  // (HD or 4K) — distinct from "fully downloaded", since a requested
  // season can still have missing episodes.
  const seasonRequested = {};
  seasons.forEach(sn => {
    seasonRequested[sn] = seasonMap[sn].some(e => e.has_hd || e.has_4k);
  });
  const unrequestedSeasons = seasons.filter(sn => !seasonRequested[sn]);

  const totalAired   = episodes.filter(e=>e.aired).length;
  const totalStubbed = episodes.filter(e=>e.aired && (e.has_hd || e.has_4k)).length;
  const totalMissing = totalAired - totalStubbed;

  // Keep the library card's "N eps missing" banner in sync immediately
  // (rather than waiting for the next full loadLib() cycle) — scoped to
  // requested seasons only, matching /api/library/missing-counts exactly.
  const requestedMissing = episodes.filter(e => e.aired && seasonRequested[e.season] && !e.has_hd && !e.has_4k).length;
  libMissingCounts[g.imdb] = requestedMissing;

  const escTitle = g.title.replace(/\\/g,'\\\\').replace(/'/g,"\\'");
  const escPoster = (g.poster||'').replace(/'/g,"\\'");

  const seasonRows = seasons.map(sn => {
    const eps = seasonMap[sn].sort((a,b)=>a.episode-b.episode);
    const requested = seasonRequested[sn];
    const airedEps = eps.filter(e=>e.aired);
    const missing = airedEps.filter(e=>!e.has_hd && !e.has_4k).length;

    // Unrequested season: show a single "Request season" row instead of
    // per-episode chips (there's nothing to show per-episode yet).
    if (!requested) {
      const airedCount = airedEps.length;
      const futureCount = eps.length - airedCount;
      const countLabel = airedCount > 0
        ? `${airedCount} ep${airedCount!==1?'s':''}${futureCount>0?` &middot; ${futureCount} upcoming`:''}`
        : `${futureCount} upcoming ep${futureCount!==1?'s':''}`;
      return `<div style="margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;gap:10px;background:var(--card2);border:1px solid var(--bor);border-radius:10px;padding:12px 14px">
        <div>
          <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:3px">
            Season ${sn} <span style="color:var(--txt);font-weight:600">${countLabel}</span>
          </div>
          <div style="font-size:11px;color:var(--mut)">Not requested yet</div>
        </div>
        <button id="reqSeasonBtn_${sn}" class="mbtn mbtn-add" style="padding:8px 16px;font-size:12px;flex-shrink:0;width:auto"
          onclick="requestSeason('${safeId}','${g.imdb}','${escTitle}','${escPoster}',${sn},'${g.year||''}')"
          ${airedCount===0 ? 'disabled title="No aired episodes yet"' : ''}>
          ${airedCount===0 ? 'Not aired' : 'Request season'}
        </button>
      </div>`;
    }

    const chips = airedEps.map(ep => {
      const eStr = String(ep.episode).padStart(2,'0');
      if (ep.has_hd || ep.has_4k) {
        const col = ep.has_4k ? 'var(--acc2)' : 'var(--blue)';
        const lbl = ep.has_hd && ep.has_4k ? 'HD+4K' : (ep.has_4k ? '4K' : 'HD');
        const label = `${escTitle} S${String(sn).padStart(2,'0')}E${eStr}`;
        // One entry point per episode: the manage modal offers, per
        // existing quality, "select a new stream", "clear active
        // stream", and "delete stub" — no separate quality-choice hop.
        const clickAttr = `onclick="event.stopPropagation();openEpisodeManageModal('${safeId}','${label}','${ep.hd_stub_id||''}','${ep.uhd_stub_id||''}')"`;
        // Small ✕ as a shortcut straight to the delete options — same
        // modal, kept for muscle memory from the old delete-only flow.
        const delAttr = `onclick="event.stopPropagation();openEpisodeDeleteModal('${safeId}','${label}','${ep.hd_stub_id||''}','${ep.uhd_stub_id||''}')"`;
        return `<span
          title="Click to manage streams (view/change/clear/delete per quality)"
          style="background:var(--card2);border:1px solid var(--bor);border-radius:5px;padding:3px 4px 3px 7px;font-size:10px;font-weight:700;color:${col};white-space:nowrap;display:inline-flex;align-items:center;gap:5px">
          <span ${clickAttr} style="cursor:pointer">E${eStr} <span style="color:var(--mut);font-weight:400">${lbl}</span></span>
          <span ${delAttr} title="Remove this episode's stream(s)" style="cursor:pointer;color:var(--mut);font-weight:400;padding:0 3px;border-radius:3px" onmouseover="this.style.color='var(--red)'" onmouseout="this.style.color='var(--mut)'">✕</span>
        </span>`;
      } else {
        const sid   = `ep_${sn}_${ep.episode}`;
        return `<span id="${sid}"
          onclick="openEpisodeSearchModal('${safeId}','${g.imdb}','${escTitle}',${sn},${ep.episode},'${escPoster}','${g.year||''}')"
          title="Click to search for S${String(sn).padStart(2,'0')}E${eStr}"
          style="background:transparent;border:1px dashed rgba(255,255,255,.18);border-radius:5px;padding:3px 7px;font-size:10px;font-weight:700;color:rgba(255,255,255,.35);cursor:pointer;white-space:nowrap;transition:all 140ms"
          onmouseover="this.style.borderColor='var(--acc)';this.style.color='var(--txt)'"
          onmouseout="this.style.borderColor='rgba(255,255,255,.18)';this.style.color='rgba(255,255,255,.35)'">E${eStr} <span style="font-weight:400">missing</span></span>`;
      }
    }).join('');

    const mbadge = missing > 0
      ? `<span style="color:var(--red);font-size:10px;font-weight:600;margin-left:6px">${missing} missing</span>` : '';
    const reqBadge = `<span style="color:var(--grn);font-size:10px;font-weight:600;margin-left:6px">requested</span>`;

    return `<div style="margin-bottom:16px">
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);margin-bottom:8px;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
        <span>Season ${sn} <span style="color:var(--txt);font-weight:600">${airedEps.length} ep${airedEps.length!==1?'s':''}</span>${reqBadge}${mbadge}</span>
        <span style="display:flex;align-items:center;gap:4px;flex-shrink:0">
          <span id="scanHdSeason_${sn}" onclick="scanSeasonQuality('${g.imdb}',${sn},'hd',this)"
            style="text-transform:none;letter-spacing:0;font-weight:600;color:var(--blue);cursor:pointer;font-size:11px;padding:2px 7px;border-radius:5px;border:1px solid rgba(74,158,255,.3);transition:all 140ms">
            Scan HD
          </span>
          <span id="scanUhdSeason_${sn}" onclick="scanSeasonQuality('${g.imdb}',${sn},'4k',this)"
            style="text-transform:none;letter-spacing:0;font-weight:600;color:var(--acc2);cursor:pointer;font-size:11px;padding:2px 7px;border-radius:5px;border:1px solid rgba(232,160,32,.3);transition:all 140ms">
            Scan 4K
          </span>
          <span id="scanBothSeason_${sn}" onclick="scanSeasonBoth('${g.imdb}',${sn},this)"
            style="text-transform:none;letter-spacing:0;font-weight:600;color:var(--txt);cursor:pointer;font-size:11px;padding:2px 7px;border-radius:5px;border:1px solid var(--bor2);transition:all 140ms">
            Scan HD+4K
          </span>
          <span id="rmSeason_${sn}" onclick="removeSeasonClick('${safeId}','${g.imdb}','${escTitle}',${sn},this)"
            style="text-transform:none;letter-spacing:0;font-weight:600;color:var(--mut);cursor:pointer;font-size:11px;flex-shrink:0;padding:2px 6px;border-radius:5px;transition:all 140ms"
            onmouseover="if(!this.dataset.armed){this.style.color='var(--red)'}" onmouseout="if(!this.dataset.armed){this.style.color='var(--mut)'}">
            Remove
          </span>
        </span>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:5px">${chips}</div>
    </div>`;
  }).join('');

  const posterEl = g.poster
    ? `<img src="${g.poster}" style="width:52px;height:78px;object-fit:cover;border-radius:7px;flex-shrink:0"/>`
    : '';
  const scanBadge = isScanning
    ? `<div style="font-size:11px;color:var(--blue);margin-top:4px;display:flex;align-items:center;gap:5px"><span style="width:6px;height:6px;border-radius:50%;background:var(--blue);display:inline-block;animation:sblink 1s infinite"></span> Scanning…</div>` : '';
  const missingNote = totalMissing > 0 && !isScanning
    ? `<div style="font-size:11px;color:var(--red);margin-top:3px">${totalMissing} ep${totalMissing!==1?'s':''} missing</div>` : '';

  // Only seasons with at least one aired episode can actually be
  // requested right now — an unaired season would just 404.
  const requestableSeasons = unrequestedSeasons.filter(
    sn => seasonMap[sn].some(e => e.aired)
  );
  const requestAllBtn = requestableSeasons.length > 0
    ? `<button id="reqAllBtn" onclick="requestAllSeasons('${safeId}','${g.imdb}','${escTitle}','${escPoster}','${g.year||''}',${JSON.stringify(requestableSeasons)})"
        style="background:none;border:1px solid var(--acc);color:var(--acc);border-radius:6px;padding:3px 10px;font-size:11px;font-weight:700;cursor:pointer;margin-left:8px;white-space:nowrap">
        Request all (${requestableSeasons.length})
      </button>`
    : '';

  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:18px;width:100%;max-width:520px;max-height:82vh;display:flex;flex-direction:column;overflow:hidden">
      <div style="padding:20px 22px 16px;border-bottom:1px solid var(--bor);display:flex;align-items:flex-start;gap:14px;flex-shrink:0">
        ${posterEl}
        <div style="flex:1;min-width:0">
          <div style="font-size:17px;font-weight:800;letter-spacing:-.3px;margin-bottom:3px">${g.title}</div>
          ${g.requested_by ? `<div style="font-size:12px;color:var(--mut);margin-bottom:3px">Requested by ${g.requested_by}</div>` : ''}
          <div style="font-size:12px;color:var(--mut);display:flex;align-items:center;flex-wrap:wrap;row-gap:6px">
            <span>${seasons.length} season${seasons.length!==1?'s':''} &middot; ${totalStubbed}/${totalAired} episodes</span>${requestAllBtn}
          </div>
          ${scanBadge}${missingNote}
        </div>
        <button onclick="document.getElementById('seriesDlg').remove()" style="background:var(--card2);border:1px solid var(--bor);border-radius:8px;color:var(--mut);width:30px;height:30px;cursor:pointer;font-size:14px;flex-shrink:0">✕</button>
      </div>
      <div style="padding:18px 22px;overflow-y:auto;flex:1">
        ${seasons.length ? seasonRows : '<div style="color:var(--mut);font-size:13px">No episodes found yet.</div>'}
      </div>
      <div style="padding:14px 22px;border-top:1px solid var(--bor);display:flex;gap:10px;flex-shrink:0">
        <button id="rescanBtn" class="mbtn mbtn-add"
          onclick="rescanSeries('${safeId}','${g.imdb}','${escTitle}','${escPoster}','${g.year||''}')"
          style="${isScanning?'opacity:.5;pointer-events:none':''}">
          ${isScanning ? 'Scanning…' : 'Rescan all'}
        </button>
        <button class="mbtn mbtn-add" onclick="document.getElementById('seriesDlg').remove();openDelModal('${safeId}')" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)">Remove</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('seriesDlg').remove()">Close</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target===dlg) dlg.remove(); });
}

async function scanSeasonQuality(imdbId, season, quality, el) {
  const original = el.textContent;
  el.textContent = 'Scanning…';
  el.style.pointerEvents = 'none';
  el.style.opacity = '.6';
  try {
    const r = await fetch(`/api/series/${imdbId}/season/${season}/scan/${quality}`, { method: 'POST' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || 'Scan failed');
    toast(`Season ${season} ${quality.toUpperCase()} scan: found ${d.found}/${d.checked} checked (${d.already_had} already had it)`, 'ok');
    await loadLib();
    const safeId = imdbId.replace(/[^a-z0-9]/gi, '');
    document.getElementById('seriesDlg')?.remove();
    openSeriesDetail(safeId);
  } catch (exc) {
    toast(exc.message || 'Scan failed', 'er');
    el.textContent = original;
    el.style.pointerEvents = 'auto';
    el.style.opacity = '1';
  }
}

async function scanSeasonBoth(imdbId, season, el) {
  const original = el.textContent;
  el.style.pointerEvents = 'none';
  el.style.opacity = '.6';
  const results = [];
  for (const quality of ['hd', '4k']) {
    el.textContent = `Scanning ${quality.toUpperCase()}…`;
    try {
      const r = await fetch(`/api/series/${imdbId}/season/${season}/scan/${quality}`, { method: 'POST' });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.detail || 'Scan failed');
      results.push(`${quality.toUpperCase()}: found ${d.found}/${d.checked}`);
    } catch (exc) {
      results.push(`${quality.toUpperCase()}: ${exc.message || 'failed'}`);
    }
  }
  toast(`Season ${season} — ${results.join(' · ')}`, 'ok');
  el.textContent = original;
  el.style.pointerEvents = 'auto';
  el.style.opacity = '1';
  await loadLib();
  const safeId = imdbId.replace(/[^a-z0-9]/gi, '');
  document.getElementById('seriesDlg')?.remove();
  openSeriesDetail(safeId);
}

function removeSeasonClick(safeId, imdbId, title, season, el) {
  if (!el.dataset.armed) {
    // First click: arm it — turns red and waits a few seconds for a
    // second click, rather than popping a whole separate confirm modal
    // for what's a fairly contained, single-season action.
    el.dataset.armed = '1';
    el.textContent = 'Confirm?';
    el.style.color = 'var(--red)';
    el.style.background = 'rgba(255,85,85,.12)';
    el._disarmTimer = setTimeout(() => {
      if (el.dataset.armed) {
        delete el.dataset.armed;
        el.textContent = 'Remove';
        el.style.color = 'var(--mut)';
        el.style.background = 'none';
      }
    }, 4000);
    return;
  }
  clearTimeout(el._disarmTimer);
  removeSeasonNow(safeId, imdbId, title, season, el);
}

async function removeSeasonNow(safeId, imdbId, title, season, el) {
  el.textContent = 'Removing…';
  el.style.pointerEvents = 'none';
  try {
    const r = await fetch(`/api/series/${imdbId}/season/${season}`, { method: 'DELETE' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || 'Could not remove season');
    toast(`Removed Season ${season} of "${title}" (${d.removed} stub${d.removed !== 1 ? 's' : ''})`, 'ok');
    document.getElementById('seriesDlg')?.remove();
    await loadLib();
    openSeriesDetail(safeId);
  } catch (exc) {
    toast(exc.message || 'Could not remove season', 'er');
    el.textContent = 'Remove';
    el.style.pointerEvents = 'auto';
    delete el.dataset.armed;
  }
}

async function requestSeason(safeId, imdbId, title, poster, season, year) {
  const btn = document.getElementById(`reqSeasonBtn_${season}`);
  if (btn) { btn.textContent = 'Requesting…'; btn.disabled = true; }
  _bg_scans_ui.add(imdbId);
  toast(`Requesting Season ${season} of "${title}"`, 'in');
  try {
    const r = await fetch('/api/add', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ imdb_id:imdbId, title, media_type:'series', poster, season, year: year ? parseInt(year) : null }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail||'Error');
    document.getElementById('seriesDlg')?.remove();
    pollScan(imdbId, title);
  } catch(e) {
    _bg_scans_ui.delete(imdbId);
    if (btn) { btn.textContent = 'Request season'; btn.disabled = false; }
    toast(e.message, 'er');
  }
}

async function requestAllSeasons(safeId, imdbId, title, poster, year, unrequestedSeasons) {
  const btn = document.getElementById('reqAllBtn');
  if (btn) { btn.textContent = 'Requesting…'; btn.style.pointerEvents = 'none'; btn.style.opacity = '.6'; }
  _bg_scans_ui.add(imdbId);
  toast(`Requesting ${unrequestedSeasons.length} season${unrequestedSeasons.length!==1?'s':''} of "${title}"`, 'in');
  try {
    // One targeted request per unrequested season (not a blanket whole-
    // series rescan) — avoids re-querying AIOStreams for episodes that
    // are already stubbed, which create_stubs() would just no-op on
    // anyway but wastes API calls/rate-limit budget at series-add scale.
    for (const sn of unrequestedSeasons) {
      const r = await fetch('/api/add', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ imdb_id:imdbId, title, media_type:'series', poster, season: sn, year: year ? parseInt(year) : null }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.detail||'Error');
    }
    document.getElementById('seriesDlg')?.remove();
    pollScan(imdbId, title);
  } catch(e) {
    _bg_scans_ui.delete(imdbId);
    if (btn) { btn.textContent = `Request all`; btn.style.pointerEvents = 'auto'; btn.style.opacity = '1'; }
    toast(e.message, 'er');
  }
}

function openEpisodeSearchModal(safeId, imdbId, title, season, episode, poster, year) {
  const eStr = String(episode).padStart(2,'0');
  const sStr = String(season).padStart(2,'0');

  const dlg = document.createElement('div');
  dlg.id = 'episodeSearchDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:310;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px;max-width:360px;width:100%">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${title}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:22px">S${sStr}E${eStr} — search for a specific quality, or both</div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <button class="mbtn mbtn-add" style="background:#1a2e40;color:var(--blue);border:1px solid rgba(74,158,255,.3)"
          onclick="runEpisodeSearch('${safeId}','${imdbId}','${title.replace(/'/g,"\\'")}',${season},${episode},'${poster}','${year}','hd',this)">Search HD</button>
        <button class="mbtn mbtn-add" style="background:#2e1e00;color:var(--acc2);border:1px solid rgba(232,160,32,.3)"
          onclick="runEpisodeSearch('${safeId}','${imdbId}','${title.replace(/'/g,"\\'")}',${season},${episode},'${poster}','${year}','4k',this)">Search 4K</button>
        <button class="mbtn mbtn-add" style="background:var(--card2);color:var(--txt);border:1px solid var(--bor2)"
          onclick="runEpisodeSearch('${safeId}','${imdbId}','${title.replace(/'/g,"\\'")}',${season},${episode},'${poster}','${year}','both',this)">Search HD+4K</button>
        <button class="mbtn mbtn-add" style="background:transparent;color:var(--mut);border:1px dashed var(--bor2)"
          onclick="document.getElementById('episodeSearchDlg').remove();openManualSearchModal('episode',{imdb_id:'${imdbId}',title:'${title.replace(/'/g,"\\'")}',poster:'${poster}',year:('${year}'?parseInt('${year}'):null),season:${season},episode:${episode},safeId:'${safeId}'})">Search manually</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('episodeSearchDlg').remove()" style="margin-top:4px">Cancel</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

async function runEpisodeSearch(safeId, imdbId, title, season, episode, poster, year, quality, btn) {
  const chipId = `ep_${season}_${episode}`;
  const chip   = document.getElementById(chipId);
  const eStr   = String(episode).padStart(2,'0');
  const sStr   = String(season).padStart(2,'0');

  if (btn) { btn.textContent = 'Searching…'; btn.disabled = true; }
  if (chip) {
    chip.textContent = `E${eStr} searching…`;
    chip.style.color = 'var(--blue)';
    chip.style.borderColor = 'var(--blue)';
    chip.style.borderStyle = 'solid';
    chip.style.pointerEvents = 'none';
    chip.onmouseover = chip.onmouseout = null;
  }

  try {
    let r, d;
    if (quality === 'both') {
      r = await fetch(`/api/series/${imdbId}/episode/${season}/${episode}`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({imdb_id:imdbId, title, media_type:'series', poster, year:year?parseInt(year):null}),
      });
      d = await r.json();
      if (!r.ok) throw new Error(d.detail||'No streams found');
    } else {
      r = await fetch(`/api/series/${imdbId}/episode/${season}/${episode}/scan/${quality}`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({title, poster, year:year?parseInt(year):null}),
      });
      d = await r.json();
      if (!r.ok) throw new Error(d.detail||`No ${quality.toUpperCase()} stream found`);
      d.has_4k = quality === '4k';   // for the chip label below, matching the generic endpoint's shape
    }

    if (chip) {
      const lbl = (quality === 'both' && d.has_4k) ? 'HD+4K' : (quality === '4k' ? '4K' : 'HD');
      const col = (lbl === '4K' || lbl === 'HD+4K') ? 'var(--acc2)' : 'var(--blue)';
      chip.style.background = 'var(--card2)';
      chip.style.borderColor = 'var(--bor)';
      chip.style.color = col;
      chip.innerHTML = `E${eStr} <span style="color:var(--mut);font-weight:400">${lbl}</span>`;
      chip.style.cursor = 'default';
      chip.onclick = null;
    }
    toast(`Found S${sStr}E${eStr} (${quality === 'both' ? (d.has_4k?'HD+4K':'HD') : quality.toUpperCase()})`, 'ok');
    document.getElementById('episodeSearchDlg')?.remove();
    await syncStubs();
  } catch(e) {
    if (btn) { btn.textContent = btn.textContent.replace('Searching…', 'Retry'); btn.disabled = false; }
    if (chip && quality === 'both') {
      // Only reset the chip to "not found" for the combined search — a
      // single HD or 4K miss shouldn't relabel the whole episode as
      // failed if the other quality might still be tried from the modal.
      chip.textContent = `E${eStr} not found`;
      chip.style.color = 'var(--red)';
      chip.style.borderColor = 'var(--red)';
      chip.style.pointerEvents = 'auto';
    } else if (chip) {
      chip.textContent = `E${eStr} missing`;
      chip.style.color = 'rgba(255,255,255,.35)';
      chip.style.borderColor = 'rgba(255,255,255,.18)';
      chip.style.borderStyle = 'dashed';
      chip.style.pointerEvents = 'auto';
      chip.onclick = () => openEpisodeSearchModal(safeId, imdbId, title, season, episode, poster, year);
    }
    toast(`S${sStr}E${eStr}: ${e.message}`, 'er');
  }
}


async function rescanSeries(safeId, imdbId, title, poster, year) {
  const btn = document.getElementById('rescanBtn');
  if (btn) { btn.textContent='Scanning…'; btn.style.opacity='.5'; btn.style.pointerEvents='none'; }
  _bg_scans_ui.add(imdbId);
  document.getElementById('seriesDlg')?.remove();
  toast(`Rescanning "${title}"`, 'in');
  try {
    const r = await fetch('/api/add', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ imdb_id:imdbId, title, media_type:'series', poster, year: year ? parseInt(year) : null }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail||'Error');
    pollScan(imdbId, title);
  } catch(e) {
    _bg_scans_ui.delete(imdbId);
    toast(e.message, 'er');
  }
}

// ── Episode-level stream removal ───────────────────────────────
// Deletes just one episode's stub(s) — deliberately does NOT touch the
// season, series, or gateway/library_items, same "remove the stream,
// keep the title" principle as the movie/series Delete-stub buttons.
// The episode just goes back to showing as "missing" until rescanned.
function openEpisodeDeleteModal(safeId, label, hdStubId, uhdStubId) {
  document.getElementById('epDelDlg')?.remove();
  const hasHd = !!hdStubId;
  const has4k = !!uhdStubId;
  const dlg = document.createElement('div');
  dlg.id = 'epDelDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:320;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:24px;max-width:320px;width:100%">
      <div style="font-size:15px;font-weight:800;margin-bottom:4px">${label}</div>
      <div style="font-size:12px;color:var(--mut);margin-bottom:18px">Removes this episode's stream(s) only — the episode goes back to "missing" until rescanned. The season and show stay untouched.</div>
      <div style="display:flex;flex-direction:column;gap:8px">
        ${hasHd ? `<button class="mbtn mbtn-add" style="background:#1a2e40;color:var(--blue);border:1px solid rgba(74,158,255,.3)" onclick="delEpisodeStub('${safeId}','${hdStubId}',this)">Delete HD stream</button>` : ''}
        ${has4k ? `<button class="mbtn mbtn-add" style="background:#2e1e00;color:var(--acc2);border:1px solid rgba(232,160,32,.3)" onclick="delEpisodeStub('${safeId}','${uhdStubId}',this)">Delete 4K stream</button>` : ''}
        ${(hasHd && has4k) ? `<button class="mbtn mbtn-add" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)" onclick="delEpisodeStubBoth('${safeId}','${hdStubId}','${uhdStubId}',this)">Delete both</button>` : ''}
        <button class="mbtn mbtn-close" onclick="document.getElementById('epDelDlg').remove()">Cancel</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

async function _reopenSeriesAfterEpisodeDelete(safeId) {
  document.getElementById('epDelDlg')?.remove();
  document.getElementById('epManageDlg')?.remove();
  await loadLib();
  document.getElementById('seriesDlg')?.remove();
  openSeriesDetail(safeId);
}

async function delEpisodeStub(safeId, stubId, btn) {
  if (btn) { btn.textContent = 'Removing…'; btn.style.pointerEvents = 'none'; btn.style.opacity = '.6'; }
  try {
    // fetch() only rejects on network failure, so an unchecked call here
    // reported success on a 404/500 and then reopened the series with the
    // stub still present — indistinguishable from the button doing nothing.
    const r = await fetch(`/api/stubs/${stubId}`, { method: 'DELETE' });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || `Delete failed (${r.status})`);
    }
    toast('Episode stream removed', 'ok');
    await _reopenSeriesAfterEpisodeDelete(safeId);
  } catch (exc) {
    toast(exc.message || 'Could not remove stream', 'er');
    if (btn) { btn.style.pointerEvents = 'auto'; btn.style.opacity = '1'; }
  }
}

async function delEpisodeStubBoth(safeId, hdStubId, uhdStubId, btn) {
  if (btn) { btn.textContent = 'Removing…'; btn.style.pointerEvents = 'none'; btn.style.opacity = '.6'; }
  try {
    for (const [q, id] of [['HD', hdStubId], ['4K', uhdStubId]]) {
      const r = await fetch(`/api/stubs/${id}`, { method: 'DELETE' });
      if (!r.ok) {
        const d = await r.json().catch(() => ({}));
        throw new Error(d.detail || `${q} delete failed (${r.status})`);
      }
    }
    toast('Episode streams removed', 'ok');
    await _reopenSeriesAfterEpisodeDelete(safeId);
  } catch (exc) {
    toast(exc.message || 'Could not remove streams', 'er');
    if (btn) { btn.style.pointerEvents = 'auto'; btn.style.opacity = '1'; }
  }
}

// ── Item action sheet ───────────────────────────────────────────
// Every action here used to be its own button, which meant the same
// three verbs (scan / change stream / delete) each appeared twice —
// once for HD, once for 4K — plus combined variants, for ten buttons in
// five colours. Quality is now picked once at the top and the rows act
// on that choice, so the same feature set fits in four rows that don't
// change position as you switch between HD, 4K and both.
function openDelModal(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;
  window._delModalSafeId = safeId;
  // Open on whichever quality actually exists, so the common case (one
  // stub, wanting to act on it) needs no selection at all.
  window._delModalQuality = g.stubs.some(s => s.quality === 'hd') ? 'hd'
                          : g.stubs.some(s => s.quality === '4k') ? '4k' : 'hd';

  const dlg = document.createElement('div');
  dlg.id = 'delDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:300;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `<div id="delDlgBody" style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:24px 20px 18px;max-width:380px;width:100%;max-height:88vh;overflow-y:auto"></div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
  renderDelModal();
}

function setDelModalQuality(q) {
  window._delModalQuality = q;
  renderDelModal();
}

function renderDelModal() {
  const safeId = window._delModalSafeId;
  const body = document.getElementById('delDlgBody');
  const g = window._libGroups && window._libGroups[safeId];
  if (!body || !g) return;

  const hdStub = g.stubs.find(s => s.quality === 'hd');
  const k4Stub = g.stubs.find(s => s.quality === '4k');
  const hasHd = !!hdStub, has4k = !!k4Stub;
  const isMovie = g.media_type !== 'series';
  const q = window._delModalQuality || 'hd';
  const esc = s => String(s || '').replace(/'/g, "\\'");

  // What the current selection resolves to. Keeping this as one small
  // table means each row below is a single lookup rather than its own
  // nest of hd/4k/both conditionals.
  const sel = {
    hd:   { label: 'HD',      stub: hdStub, exists: hasHd },
    '4k': { label: '4K',      stub: k4Stub, exists: has4k },
    both: { label: 'HD + 4K', stub: null,   exists: hasHd && has4k },
  }[q];

  const row = (label, onclick, opts = {}) => {
    const cls = 'arow' + (opts.off ? ' off' : '') + (opts.danger ? ' danger' : '')
                       + (opts.quiet ? ' quiet' : '');
    const attrs = opts.off ? '' : ` onclick="${onclick}"`;
    const id = opts.id ? ` id="${opts.id}"` : '';
    return `<button class="${cls}"${id}${attrs}>${label}</button>`;
  };

  let rows = '';

  if (isMovie) {
    // Scan — always available: this is how a missing quality gets added,
    // so it must work whether or not a stub exists yet.
    const scanCall = q === 'both'
      ? `scanMovieBoth('${g.imdb}',this)`
      : `scanMovieQuality('${g.imdb}','${q}',this)`;
    rows += row(`${sel.exists ? 'Rescan' : 'Scan'} ${sel.label}`, scanCall);

    rows += row('Search manually',
      `openManualSearchModal('movie',{imdb_id:'${g.imdb}',title:'${esc(g.title)}',poster:'${esc(g.poster||'')}',year:${g.year||'null'}})`);

    // Change active stream — needs one specific stub, so "both" has
    // nothing to point at.
    if (q === 'both') {
      rows += row('Change active stream', '', { off: true });
    } else {
      rows += row('Change active stream',
        `openActiveStreamModal('${sel.stub ? sel.stub.stub_id : ''}','${esc(g.title)} (${sel.label})')`,
        { off: !sel.exists });
    }
    rows += `<div class="asep"></div>`;
  }

  // Delete stream(s) — same row for all three selections.
  rows += row(`Delete ${sel.label} stream${q === 'both' ? 's' : ''}`,
              `delQuality('${safeId}','${q}')`,
              { off: !sel.exists, danger: sel.exists });

  const titleWord = isMovie ? 'movie' : 'series';
  rows += row(`Delete ${titleWord} entirely`,
              `armDeleteTitle(this,'${safeId}',${isMovie})`,
              { danger: true, id: 'delTitleBtn' });

  const requester = g.requested_by
    ? `<div style="font-size:12.5px;color:var(--mut);margin-bottom:10px">Requested by ${g.requested_by}</div>`
    : '';

  body.innerHTML = `
    <div style="font-size:17px;font-weight:800;margin-bottom:${requester ? '4' : '10'}px">${g.title}</div>
    ${requester}
    <div style="margin-bottom:16px">
      <span class="apill ${hasHd ? 'has' : ''}">HD ${hasHd ? '✓' : '—'}</span>
      <span class="apill ${has4k ? 'has' : ''}">4K ${has4k ? '✓' : '—'}</span>
    </div>
    <div class="aseg">
      <button class="${q === 'hd'   ? 'on' : ''}" onclick="setDelModalQuality('hd')">HD</button>
      <button class="${q === '4k'   ? 'on' : ''}" onclick="setDelModalQuality('4k')">4K</button>
      <button class="${q === 'both' ? 'on' : ''}" onclick="setDelModalQuality('both')">Both</button>
    </div>
    ${rows}
    <div class="asep"></div>
    ${row('Cancel', `document.getElementById('delDlg').remove()`, { quiet: true })}`;
}

// Two-click arm/confirm on the destructive "Delete series"/"Delete movie"
// button — same pattern as removeSeasonClick's per-season Remove, just
// generalized here since this is the one true "gone for good" action.
//
function armDeleteTitle(el, safeId, isMovie) {
  const word = isMovie ? 'movie' : 'series';
  if (!el.dataset.armed) {
    el.dataset.armed = '1';
    el.textContent = 'Click again to confirm';
    el._disarmTimer = setTimeout(() => {
      if (el.dataset.armed) {
        delete el.dataset.armed;
        el.textContent = `Delete ${word} entirely`;
      }
    }, 4000);
    return;
  }
  clearTimeout(el._disarmTimer);
  deleteTitleEntirely(safeId, isMovie, el);
}

async function deleteTitleEntirely(safeId, isMovie, el) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;
  if (el) { el.textContent = 'Deleting…'; el.style.pointerEvents = 'none'; el.style.opacity = '.6'; }
  try {
    const r = await fetch(`/api/${isMovie ? 'movie' : 'series'}/${g.imdb}`, { method: 'DELETE' });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'Delete failed');
    }
    toast(`${isMovie ? 'Movie' : 'Series'} deleted`, 'ok');
    document.getElementById('delDlg')?.remove();
    document.getElementById('seriesDlg')?.remove();
    loadLib();
  } catch (exc) {
    toast(exc.message || 'Delete failed', 'er');
    if (el) {
      delete el.dataset.armed;
      el.textContent = `Delete ${isMovie ? 'movie' : 'series'} entirely`;
      el.style.pointerEvents = 'auto';
      el.style.opacity = '1';
    }
  }
}

function openPendingMovieModal(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g || !g.pending) return;

  const dlg = document.createElement('div');
  dlg.id = 'pendingMovieDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:300;display:flex;align-items:center;justify-content:center';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px 28px 24px;max-width:360px;width:90%">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${g.title}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:22px">
        ${g.year ? g.year + ' · ' : ''}Not resolvable yet — most commonly because it hasn't
        released, or nothing's cached at your debrid backend yet. Being retried
        automatically until it resolves or the retry window elapses.
      </div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <button class="mbtn mbtn-add" style="background:var(--acc);color:#000"
          onclick="openPendingMovieManualSearch('${safeId}')">Search manually</button>
        <div style="font-size:12px;color:var(--mut);margin:-4px 0 4px;line-height:1.45">
          Browse every source AIOStreams has right now and pick one yourself,
          instead of letting the automatic search decide. Works even before the
          listed release date — early digital drops often beat it.
        </div>
        <button id="pendingMovieSearchBtn" class="mbtn mbtn-add" style="background:var(--card2);color:var(--txt);border:1px solid var(--bor2)"
          onclick="searchPendingMovieNow('${g.imdb}','${safeId}',this)">Search automatically</button>
        <button class="mbtn mbtn-add" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)"
          onclick="removePendingMovieFromLib('${g.imdb}')">Remove from tracking</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('pendingMovieDlg').remove()" style="margin-top:4px">Close</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

// Unified modal for an upcoming/tracked show — covers wanted (specific
// not-yet-aired) seasons AND indefinite season-watch, since a show can
// have either or both and they're one card in the Library. Always offers
// a single "Stop tracking this show" that clears everything at once;
// when only a few specific seasons are tracked, per-season stop buttons
// are offered too (skipped when there are many, where one bulk button
// beats a wall of 30 buttons).
function openUpcomingShowCard(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g || (!g.wantedSeasons && !g.watching)) return;

  const seasons = (g.wantedSeasons || []).slice().sort((a,b)=>a-b);
  const fmt = s => `S${String(s).padStart(2,'0')}`;
  const seasonList = seasons.length > 8
    ? `${fmt(seasons[0])}–${fmt(seasons[seasons.length-1])} (${seasons.length} seasons)`
    : seasons.map(fmt).join(', ');

  const descParts = [];
  if (seasons.length) {
    descParts.push(`${seasonList} ${seasons.length > 1 ? "haven't" : "hasn't"} aired yet —
      tracked so the auto-episode sweep adds ${seasons.length > 1 ? 'each one' : 'it'}
      automatically the moment it airs.`);
  }
  if (g.watching) {
    descParts.push(`Indefinite tracking is also on — whatever the next season turns
      out to be gets added automatically once it airs, for as long as this stays enabled.`);
  }
  descParts.push(`No action needed unless you'd rather stop tracking.`);

  const perSeasonButtons = (seasons.length && seasons.length <= 6)
    ? seasons.map(s => `
        <button class="mbtn mbtn-add" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)"
          onclick="removeWantedSeason('${g.imdb}',${s},this);document.getElementById('upcomingShowDlg')?.remove()">Stop tracking ${fmt(s)} only</button>
      `).join('')
    : '';

  const dlg = document.createElement('div');
  dlg.id = 'upcomingShowDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:300;display:flex;align-items:center;justify-content:center';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px 28px 24px;max-width:360px;width:90%;max-height:85vh;overflow-y:auto">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${g.title}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:22px">${descParts.join(' ')}</div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <button class="mbtn mbtn-add" style="background:var(--acc);color:#000;font-weight:700"
          onclick="openUpcomingManualSearch('${safeId}',${JSON.stringify(seasons)})">Search manually</button>
        <div style="font-size:12px;color:var(--mut);margin:-4px 0 4px;line-height:1.45">
          Pick the episode, then choose a source yourself from everything
          AIOStreams has right now — rather than letting the automatic search
          decide, or come back empty.
        </div>
        <button id="upcomingSearchBtn" class="mbtn mbtn-add" style="background:var(--card2);color:var(--txt);border:1px solid var(--bor2);font-weight:700"
          onclick="searchUpcomingShowNow('${g.imdb}','${safeId}',${JSON.stringify(seasons)},this)">Search automatically</button>
        <div style="font-size:12px;color:var(--mut);margin:-4px 0 4px;line-height:1.45">
          Searches regardless of the listed air date — useful when a premiere
          is already out but Cinemeta hasn't caught up. Tracking stays on
          either way.
        </div>
        <button class="mbtn mbtn-add" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3);font-weight:700"
          onclick="stopTrackingShow('${g.imdb}',${JSON.stringify(seasons)},${!!g.watching},this)">Stop tracking this show</button>
        ${perSeasonButtons}
        <button class="mbtn mbtn-close" onclick="document.getElementById('upcomingShowDlg').remove()" style="margin-top:4px">Close</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

// Manual "go look now" for a tracked-but-unaired show. Hits the
// force-search endpoint, which ignores Cinemeta air dates — see
// /api/series/{imdb}/search-upcoming. Deliberately does NOT stop
// tracking on failure: not finding anything today says nothing about
// tomorrow, and the automatic sweep should keep running either way.
async function searchUpcomingShowNow(imdbId, safeId, seasons, btn) {
  const g = window._libGroups && window._libGroups[safeId];
  if (btn) { btn.disabled = true; btn.textContent = 'Searching…'; btn.style.opacity = '.6'; }
  try {
    const r = await fetch(`/api/series/${imdbId}/search-upcoming`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title:   g ? g.title : '',
        poster:  g ? g.poster : '',
        year:    g && g.year ? parseInt(g.year) : null,
        seasons: seasons && seasons.length ? seasons : null,
      }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Search failed');

    if (d.stubbed > 0) {
      toast(`Found ${d.stubbed} episode${d.stubbed !== 1 ? 's' : ''}: ${d.episodes.join(', ')}`, 'ok');
      document.getElementById('upcomingShowDlg')?.remove();
      loadLib();
      loadCalendar();
    } else {
      toast(d.detail || `Searched ${d.searched} episode${d.searched !== 1 ? 's' : ''} — nothing available yet. Still tracking.`, 'in');
      if (btn) { btn.disabled = false; btn.textContent = 'Search again'; btn.style.opacity = '1'; }
    }
  } catch (exc) {
    toast(exc.message || 'Search failed', 'er');
    if (btn) { btn.disabled = false; btn.textContent = 'Search now'; btn.style.opacity = '1'; }
  }
}

// Manual search for an upcoming show needs one extra step that the movie
// case doesn't: a stream is per-episode, but an "upcoming show" is tracked
// at season level (or, with indefinite season-watch, at no level at all).
// So ask which episode first, defaulting to the premiere of the earliest
// tracked season — overwhelmingly the one you're waiting on — then hand
// off to the same picker everything else uses.
function openUpcomingManualSearch(safeId, seasons) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;
  document.getElementById('upcomingShowDlg')?.remove();

  const list = (seasons || []).slice().sort((a,b) => a-b);
  const seasonField = list.length
    ? `<select id="umsSeason" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card2);color:var(--txt);font-family:var(--f);font-size:14px">
         ${list.map(s => `<option value="${s}">Season ${s}</option>`).join('')}
       </select>`
    // Indefinite season-watch with no specific season marked — we genuinely
    // don't know which season is next, so let it be typed in.
    : `<input type="number" id="umsSeason" min="1" step="1" value="1"
         style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card2);color:var(--txt);font-family:var(--f);font-size:14px">`;

  const dlg = document.createElement('div');
  dlg.id = 'umsPickDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:310;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:26px;max-width:380px;width:100%">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${g.title}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:20px">Which episode do you want to pick a stream for?</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:18px">
        <div>
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Season</div>
          ${seasonField}
        </div>
        <div>
          <div style="font-size:12px;font-weight:600;color:var(--mut);margin-bottom:8px">Episode</div>
          <input type="number" id="umsEpisode" min="1" step="1" value="1"
            style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--bor);background:var(--card2);color:var(--txt);font-family:var(--f);font-size:14px">
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <button class="mbtn mbtn-add" style="background:var(--acc);color:#000;font-weight:700"
          onclick="_umsGo('${safeId}')">Find streams</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('umsPickDlg').remove()">Cancel</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

function _umsGo(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;
  const season  = parseInt(document.getElementById('umsSeason').value, 10);
  const episode = parseInt(document.getElementById('umsEpisode').value, 10);
  if (!season || season < 1 || !episode || episode < 1) {
    toast('Season and episode must both be 1 or higher', 'er');
    return;
  }
  document.getElementById('umsPickDlg')?.remove();
  openManualSearchModal('episode', {
    imdb_id: g.imdb,
    title:   g.title,
    poster:  g.poster || '',
    year:    g.year ? parseInt(g.year) : null,
    season, episode,
    context: "Not aired yet as far as Cinemeta knows — if the premiere is already out, sources will show up here anyway. Tracking stays on either way.",
    onDone:  async () => { await loadLib(); loadCalendar(); },
  });
}

// Clears EVERYTHING that keeps a show "upcoming": every wanted-season
// mark plus the indefinite season-watch flag, in one click.
async function stopTrackingShow(imdbId, seasons, watching, btn) {
  if (btn) { btn.disabled = true; btn.textContent = 'Stopping…'; }
  try {
    for (const s of (seasons || [])) {
      await fetch(`/api/wanted-seasons/${imdbId}/${s}`, { method: 'DELETE' }).catch(() => {});
    }
    if (watching) {
      await fetch(`/api/series/${imdbId}/season-watch`, { method: 'DELETE' }).catch(() => {});
    }
    document.getElementById('upcomingShowDlg')?.remove();
    toast('Stopped tracking — no future seasons will be added automatically', 'ok');
    loadLib();
  } catch {
    toast('Could not stop tracking', 'er');
    if (btn) { btn.disabled = false; btn.textContent = 'Stop tracking this show'; }
  }
}

function openQualityUnavailableCard(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g || !g.qualityUnavailable) return;
  const sub = g.season != null && g.episode != null
    ? `S${String(g.season).padStart(2,'0')}E${String(g.episode).padStart(2,'0')}`
    : 'This movie';

  const dlg = document.createElement('div');
  dlg.id = 'qualityUnavailDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:300;display:flex;align-items:center;justify-content:center';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:28px 28px 24px;max-width:360px;width:90%">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${g.title}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:22px">
        ${sub} — 4K was confirmed genuinely unavailable. Every automatic
        path skips 4K here from now on. Removing the mark lets the next automatic
        pass try again, or use "Scan 4K" directly from this item's card for an
        immediate manual check.
      </div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <button class="mbtn mbtn-add" style="background:#2a0d0d;color:var(--red);border:1px solid rgba(255,85,85,.3)"
          onclick="removeQualityUnavailable('${g.imdb}',this)">Remove mark</button>
        <button class="mbtn mbtn-close" onclick="document.getElementById('qualityUnavailDlg').remove()" style="margin-top:4px">Close</button>
      </div>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}


// Hand a still-pending movie straight to the manual stream picker, so a
// title that the automatic search keeps coming back empty on can be
// resolved by hand instead of only ever being retried on a timer.
function openPendingMovieManualSearch(safeId) {
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;
  document.getElementById('pendingMovieDlg')?.remove();
  openManualSearchModal('movie', {
    imdb_id: g.imdb,
    title:   g.title,
    poster:  g.poster || '',
    year:    g.year ? parseInt(g.year) : null,
    context: 'Still tracked as pending — picking a source here resolves it immediately and stops the automatic retries.',
    onDone:  async () => { await loadLib(); loadCalendar(); },
  });
}


async function searchPendingMovieNow(imdbId, safeId, btn) {
  const g = window._libGroups && window._libGroups[safeId];
  btn.disabled = true;
  try {
    const r = await fetch('/api/add', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        imdb_id: imdbId, title: g ? g.title : imdbId, media_type: 'movie',
        poster: g ? g.poster : '', year: g && g.year ? parseInt(g.year) : null,
        // Without force, this button did nothing useful for the most common
        // reason a movie is pending in the first place: still inside the
        // theatrical + digital-delay window, which made _add_movie return
        // "pending" without ever querying AIOStreams. A manual "Search now"
        // has to actually search.
        force: true,
      }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Search failed');
    if (d.pending) {
      toast(`Searched — nothing available yet. Will keep retrying automatically`, 'in');
    } else {
      toast(`Found and added "${g ? g.title : imdbId}"`, 'ok');
    }
    document.getElementById('pendingMovieDlg')?.remove();
    loadLib();
  } catch (exc) {
    toast(exc.message || 'Search failed', 'er');
    btn.textContent = 'Search now';
    btn.disabled = false;
  }
}

async function removePendingMovieFromLib(imdbId) {
  try {
    await fetch(`/api/pending-movies/${imdbId}`, { method: 'DELETE' });
    toast('Removed from tracking', 'ok');
    document.getElementById('pendingMovieDlg')?.remove();
    loadLib();
  } catch {
    toast('Could not remove', 'er');
  }
}

async function scanMovieQuality(imdbId, quality, el) {
  const original = el.textContent;
  el.textContent = 'Scanning…';
  el.disabled = true;
  el.style.opacity = '.6';
  try {
    const r = await fetch(`/api/movies/${imdbId}/scan/${quality}`, { method: 'POST' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || `No ${quality.toUpperCase()} stream found`);
    toast(`Found and stubbed ${quality.toUpperCase()}`, 'ok');
    document.getElementById('delDlg')?.remove();
    await loadLib();
  } catch (exc) {
    toast(exc.message || 'Scan failed', 'er');
    el.textContent = original;
    el.disabled = false;
    el.style.opacity = '1';
  }
}

async function scanMovieBoth(imdbId, el) {
  el.disabled = true;
  el.style.opacity = '.6';
  const results = [];
  for (const quality of ['hd', '4k']) {
    el.textContent = `Scanning ${quality.toUpperCase()}…`;
    try {
      const r = await fetch(`/api/movies/${imdbId}/scan/${quality}`, { method: 'POST' });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.detail || `No ${quality.toUpperCase()} stream found`);
      results.push(`${quality.toUpperCase()}: found`);
    } catch (exc) {
      results.push(`${quality.toUpperCase()}: ${exc.message || 'not found'}`);
    }
  }
  toast(results.join(' · '), 'ok');
  document.getElementById('delDlg')?.remove();
  await loadLib();
}

async function delQuality(safeId, quality) {
  document.getElementById('delDlg')?.remove();
  document.getElementById('seriesDlg')?.remove();
  const g = window._libGroups && window._libGroups[safeId];
  if (!g) return;

  // Only ever deletes stub(s) — the title itself (gateway/library_items)
  // is untouched here even when this removes the last remaining stub, so
  // the series/movie stays in the Library as a shell you can rescan.
  // Deleting the title entirely is a separate, explicit action (see
  // deleteTitleEntirely / the Delete series-Delete movie button).
  if (quality === 'both' && g.media_type === 'series') {
    // Cancel any running background scan first — otherwise it just
    // recreates the episode stubs we're about to delete right back.
    await fetch(`/api/series/${g.imdb}/cancel-scan`, { method: 'POST' }).catch(() => {});
  }
  const toDelete = quality === 'both'
    ? g.stubs.filter(s => s.quality === 'hd' || s.quality === '4k')
    : g.stubs.filter(s => s.quality === quality);
  for (const s of toDelete) {
    await fetch(`/api/stubs/${s.stub_id}`, { method: 'DELETE' });
  }
  toast(quality === 'both' ? 'Removed HD + 4K stubs' : `Removed ${quality.toUpperCase()} stub${toDelete.length===1?'':'s'}`, 'ok');
  loadLib();
}

// ── Active stream picker ──────────────────────────────────────
// Per-episode stream management — one modal listing each existing
// quality (HD / 4K) with the three actions that make sense per stub:
//   • Select stream — opens the full candidate picker (view current
//     link, pick a different source, remove link).
//   • Clear active stream — reverts just that quality's stub back to a
//     placeholder (stub and episode stay; resolves fresh on next play).
//   • Delete stub — removes that quality's stub entirely (episode goes
//     back to "missing" for that quality until rescanned).
function openEpisodeManageModal(safeId, label, hdStubId, uhdStubId) {
  document.getElementById('epManageDlg')?.remove();
  // Same flat, centered button list as the title action sheet — one
  // neutral style, colour only on the destructive rows, and the quality
  // said once in the button label rather than in a coloured section
  // header wrapping each group.
  const dlg = document.createElement('div');
  dlg.id = 'epManageDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:315;display:flex;align-items:center;justify-content:center;padding:20px';

  const card = document.createElement('div');
  card.style.cssText = 'background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:24px 20px 18px;max-width:360px;width:100%;max-height:82vh;overflow-y:auto';

  // Title goes in via textContent, so an apostrophe/quote/angle bracket in
  // a show name is inert text rather than markup.
  const head = document.createElement('div');
  head.style.cssText = 'font-size:15px;font-weight:800;margin-bottom:16px';
  head.textContent = label;
  card.appendChild(head);

  // Buttons are wired with addEventListener and closures instead of inline
  // onclick strings. The old version rebuilt a JS string literal around
  // `label`; a title like "Widow's Bay" closed the literal early and the
  // handler died with a syntax error, so the row did nothing when tapped.
  // Nothing here is stringified, so no title can break a handler.
  const addRow = (text, cls, fn) => {
    const b = document.createElement('button');
    b.className = cls;
    b.textContent = text;
    b.addEventListener('click', () => fn(b));
    card.appendChild(b);
    return b;
  };
  const addSep = () => {
    const s = document.createElement('div');
    s.className = 'asep';
    card.appendChild(s);
  };

  const qualityRows = (q, sid) => {
    const name = q === 'hd' ? 'HD' : '4K';
    addRow(`Select ${name} stream`, 'arow', () => {
      document.getElementById('epManageDlg')?.remove();
      openActiveStreamModal(sid, `${label} (${name})`);
    });
    addRow(`Clear ${name} stream`, 'arow', b => clearEpisodeStubStream(sid, b));
    addRow(`Delete ${name} stub`, 'arow danger', b => delEpisodeStub(safeId, sid, b));
  };

  if (hdStubId) qualityRows('hd', hdStubId);
  if (hdStubId && uhdStubId) addSep();
  if (uhdStubId) qualityRows('4k', uhdStubId);
  if (hdStubId && uhdStubId) {
    addSep();
    addRow('Delete both stubs', 'arow danger',
      b => delEpisodeStubBoth(safeId, hdStubId, uhdStubId, b));
  }
  addSep();
  addRow('Close', 'arow quiet', () => dlg.remove());

  dlg.appendChild(card);
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

// "Clear active stream" for a single episode stub — same clear-stream
// endpoint the Active Stream modal's "Remove link" uses, just reachable
// in one click from the episode manage modal without opening the picker.
async function clearEpisodeStubStream(stubId, btn) {
  const original = btn.textContent;
  btn.disabled = true; btn.textContent = 'Clearing…';
  try {
    const r = await fetch(`/api/stubs/${stubId}/clear-stream`, { method: 'POST' });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'Could not clear');
    }
    toast('Active stream cleared — will resolve fresh on next play', 'ok');
    // Confirm, then hand the button back. It used to be left disabled
    // reading "Cleared ✓" for as long as the modal stayed open, which
    // looked like a dead button once you'd picked a new stream and wanted
    // to clear it again — the only way out was closing and reopening.
    btn.textContent = 'Cleared ✓';
    setTimeout(() => {
      if (!btn.isConnected) return;
      btn.textContent = original;
      btn.disabled = false;
    }, 1500);
    loadLib();
  } catch (exc) {
    toast(exc.message || 'Could not clear stream', 'er');
    btn.disabled = false; btn.textContent = original;
  }
}

async function openActiveStreamModal(stubId, label) {
  document.getElementById('delDlg')?.remove();

  const dlg = document.createElement('div');
  dlg.id = 'activeStreamDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:310;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:24px;max-width:640px;width:100%;max-height:82vh;display:flex;flex-direction:column">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${label}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:16px">Active stream — pick which source Plex actually plays</div>
      <div id="currentLinkBox" style="margin-bottom:14px"></div>
      <div id="activeStreamList" style="overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:8px">
        <div style="color:var(--mut);font-size:13px;padding:20px 0;text-align:center">Loading candidates…</div>
      </div>
      <button class="mbtn mbtn-close" onclick="document.getElementById('activeStreamDlg').remove()" style="margin-top:14px">Close</button>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);

  try {
    const d = await (await fetch(`/api/stubs/${stubId}/candidates`)).json();
    renderCurrentLink(stubId, d.current_url || null);
    renderActiveStreamCandidates(stubId, d.candidates || []);
  } catch (exc) {
    document.getElementById('activeStreamList').innerHTML =
      `<div style="color:var(--red);font-size:13px;padding:20px 0;text-align:center">Could not load candidates: ${exc.message || exc}</div>`;
  }
}

function renderCurrentLink(stubId, currentUrl) {
  const el = document.getElementById('currentLinkBox');
  if (!el) return;
  if (!currentUrl) {
    el.innerHTML = `<div style="font-size:12px;color:var(--mut)">No link currently set — will resolve fresh next time it's played.</div>`;
    return;
  }
  el.innerHTML = `
    <div style="background:var(--card2);border:1px solid var(--bor);border-radius:10px;padding:10px 12px;display:flex;align-items:center;gap:10px">
      <div style="flex:1;min-width:0">
        <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--mut);margin-bottom:2px">Current link</div>
        <div style="font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${currentUrl.replace(/"/g,'&quot;')}">${currentUrl}</div>
      </div>
      <button id="removeLinkBtn" class="mbtn mbtn-add" style="width:auto;flex-shrink:0;background:#3a0a0a;color:#ff6b6b;border:1px solid rgba(255,85,85,.4);padding:0 14px"
        onclick="removeCurrentLink('${stubId}',this)">Remove link</button>
    </div>`;
}

async function removeCurrentLink(stubId, btn) {
  const original = btn.textContent;
  btn.textContent = 'Removing…';
  btn.disabled = true;
  try {
    const r = await fetch(`/api/stubs/${stubId}/clear-stream`, { method: 'POST' });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'Could not remove link');
    }
    toast('Link removed', 'ok');
    renderCurrentLink(stubId, null);
    // Candidates' "Current" badge is now stale — refresh the list too.
    try {
      const d = await (await fetch(`/api/stubs/${stubId}/candidates`)).json();
      renderActiveStreamCandidates(stubId, d.candidates || []);
    } catch {}
    loadLib();
  } catch (exc) {
    toast(exc.message || 'Could not remove link', 'er');
    btn.textContent = original;
    btn.disabled = false;
  }
}


function renderActiveStreamCandidates(stubId, candidates) {
  const el = document.getElementById('activeStreamList');
  if (!el) return;
  if (!candidates.length) {
    el.innerHTML = `<div style="color:var(--mut);font-size:13px;padding:20px 0;text-align:center">No candidates available right now.</div>`;
    return;
  }
  window._activeStreamCandidates = candidates;
  el.innerHTML = candidates.map((c, i) => {
    const sizeStr = c.size_gb ? `${c.size_gb} GB` : 'size unknown';
    const tags = [
      c.resolution, c.encode, c.hdr,
      c.cached ? 'cached' : 'uncached',
      c.stream_type === 'usenet' ? 'usenet' : null,
      c.pack ? `${c.pack} pack` : null,
      c.service,
    ].filter(Boolean).join(' · ');
    return `
    <div style="background:${c.is_current ? 'rgba(61,214,140,.08)' : 'var(--card2)'};border:${c.is_current ? '2px solid var(--grn)' : '1px solid var(--bor)'};border-radius:10px;padding:12px 14px;display:flex;align-items:center;gap:12px">
      <div style="flex:1;min-width:0">
        <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${(c.filename||'').replace(/"/g,'&quot;')}">${c.filename || 'Unknown filename'}</div>
        <div style="font-size:11px;color:var(--mut);margin-top:3px">${sizeStr}${tags ? ' · ' + tags : ''}</div>
      </div>
      ${c.is_current
        ? `<span class="cal-badge inlib" style="flex-shrink:0;background:rgba(61,214,140,.15);color:var(--grn);border:1px solid rgba(61,214,140,.4)">Active</span>`
        : `<button class="cal-rescan-btn" style="flex-shrink:0" onclick="selectActiveStream('${stubId}',${i},this)">Use this</button>`}
    </div>`;
  }).join('');
}

async function selectActiveStream(stubId, index, btn) {
  const c = (window._activeStreamCandidates || [])[index];
  if (!c) return;
  const original = btn.textContent;
  btn.textContent = 'Setting…';
  btn.disabled = true;
  try {
    const r = await fetch(`/api/stubs/${stubId}/select-stream`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: c.url, headers: c.headers || {}, size: c.size }),
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'Could not set stream');
    }
    toast('Active stream updated', 'ok');
    renderCurrentLink(stubId, c.url);
    try {
      const d2 = await (await fetch(`/api/stubs/${stubId}/candidates`)).json();
      renderActiveStreamCandidates(stubId, d2.candidates || []);
    } catch {}
    loadLib();
  } catch (exc) {
    toast(exc.message || 'Could not set stream', 'er');
    btn.textContent = original;
    btn.disabled = false;
  }
}

// ── Manual search picker (no stub exists yet) ───────────────────
// Fallback for when the automatic scan/search comes back with nothing
// (or picked something dead) — browse AIOStreams' raw candidate list by
// hand and stub whichever one looks right. Same picker UI as the
// Active Stream modal above, just backed by search-candidates/manual-stub
// instead of candidates/select-stream, since there's no stub_id yet to
// hang those off of.
function openManualSearchModal(kind, info) {
  document.getElementById('episodeSearchDlg')?.remove();
  document.getElementById('delDlg')?.remove();

  window._manualSearchInfo = { kind, ...info };
  window._manualSearchQuality = null;

  const label = kind === 'episode'
    ? `${info.title} — S${String(info.season).padStart(2,'0')}E${String(info.episode).padStart(2,'0')}`
    : info.title;

  const dlg = document.createElement('div');
  dlg.id = 'manualSearchDlg';
  dlg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);z-index:320;display:flex;align-items:center;justify-content:center;padding:20px';
  dlg.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--bor2);border-radius:16px;padding:24px;max-width:640px;width:100%;max-height:82vh;display:flex;flex-direction:column">
      <div style="font-size:17px;font-weight:800;margin-bottom:4px">${label}</div>
      <div style="font-size:13px;color:var(--mut);margin-bottom:${info.context ? '8' : '14'}px">Search manually — pick a source directly instead of the automatic search</div>
      ${info.context ? `<div style="font-size:12px;color:var(--acc2);margin-bottom:14px">${info.context}</div>` : ''}
      <div style="display:flex;gap:8px;margin-bottom:14px">
        <button id="manualQualityHd" class="mbtn mbtn-add" style="background:var(--card2);color:var(--blue);border:1px solid rgba(74,158,255,.3);width:auto;flex:1" onclick="_runManualSearch('hd')">HD</button>
        <button id="manualQualityUhd" class="mbtn mbtn-add" style="background:var(--card2);color:var(--acc2);border:1px solid rgba(232,160,32,.3);width:auto;flex:1" onclick="_runManualSearch('4k')">4K</button>
        <button id="manualQualityAll" class="mbtn mbtn-add" style="background:var(--card2);color:var(--txt);border:1px solid var(--bor2);width:auto;flex:1" onclick="_runManualSearch(null)">Both</button>
      </div>
      <div id="manualSearchList" style="overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:8px">
        <div style="color:var(--mut);font-size:13px;padding:20px 0;text-align:center">Pick a quality above to search.</div>
      </div>
      <button class="mbtn mbtn-close" onclick="document.getElementById('manualSearchDlg').remove()" style="margin-top:14px">Close</button>
    </div>`;
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.remove(); });
  document.body.appendChild(dlg);
}

async function _runManualSearch(quality) {
  window._manualSearchQuality = quality;
  const el = document.getElementById('manualSearchList');
  if (!el) return;
  el.innerHTML = `<div style="color:var(--mut);font-size:13px;padding:20px 0;text-align:center">Searching…</div>`;

  const info = window._manualSearchInfo;
  const body = JSON.stringify({
    title: info.title, poster: info.poster || '',
    year: info.year ? parseInt(info.year) : null,
    quality,
  });
  const url = info.kind === 'episode'
    ? `/api/series/${info.imdb_id}/episode/${info.season}/${info.episode}/search-candidates`
    : `/api/movies/${info.imdb_id}/search-candidates`;

  try {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Search failed');
    renderManualSearchCandidates(d.candidates || []);
  } catch (exc) {
    el.innerHTML = `<div style="color:var(--red);font-size:13px;padding:20px 0;text-align:center">${exc.message || exc}</div>`;
  }
}

function renderManualSearchCandidates(candidates) {
  const el = document.getElementById('manualSearchList');
  if (!el) return;
  if (!candidates.length) {
    el.innerHTML = `<div style="color:var(--mut);font-size:13px;padding:20px 0;text-align:center">No candidates found.</div>`;
    return;
  }
  window._manualSearchCandidates = candidates;
  el.innerHTML = candidates.map((c, i) => {
    const sizeStr = c.size_gb ? `${c.size_gb} GB` : 'size unknown';
    const tags = [
      c.resolution, c.encode, c.hdr,
      c.cached ? 'cached' : 'uncached',
      c.stream_type === 'usenet' ? 'usenet' : null,
      c.pack ? `${c.pack} pack` : null,
      c.service,
    ].filter(Boolean).join(' · ');
    return `
    <div style="background:var(--card2);border:1px solid var(--bor);border-radius:10px;padding:12px 14px;display:flex;align-items:center;gap:12px">
      <div style="flex:1;min-width:0">
        <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${(c.filename||'').replace(/"/g,'&quot;')}">${c.filename || 'Unknown filename'}</div>
        <div style="font-size:11px;color:var(--mut);margin-top:3px">${c.quality === '4k' ? '4K' : 'HD'} · ${sizeStr}${tags ? ' · ' + tags : ''}</div>
      </div>
      <button class="cal-rescan-btn" style="flex-shrink:0" onclick="selectManualStream(${i},this)">Use this</button>
    </div>`;
  }).join('');
}

async function selectManualStream(index, btn) {
  const c = (window._manualSearchCandidates || [])[index];
  const info = window._manualSearchInfo;
  if (!c || !info) return;
  const original = btn.textContent;
  btn.textContent = 'Stubbing…';
  btn.disabled = true;
  try {
    const body = JSON.stringify({
      title: info.title, poster: info.poster || '',
      year: info.year ? parseInt(info.year) : null,
      quality: c.quality, url: c.url, headers: c.headers || {},
      size: c.size, filename: c.filename || '',
    });
    const url = info.kind === 'episode'
      ? `/api/series/${info.imdb_id}/episode/${info.season}/${info.episode}/manual-stub`
      : `/api/movies/${info.imdb_id}/manual-stub`;
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Could not stub this stream');
    toast(`Stubbed ${c.quality === '4k' ? '4K' : 'HD'} from picked source`, 'ok');
    document.getElementById('manualSearchDlg')?.remove();
    // Callers opening this from somewhere other than the Library (e.g. the
    // Calendar) pass their own refresh, so we reload the view the person is
    // actually looking at rather than always bouncing through loadLib.
    if (typeof info.onDone === 'function') {
      await info.onDone();
    } else if (info.kind === 'episode' && info.safeId) {
      await _reopenSeriesAfterEpisodeDelete(info.safeId);
    } else {
      await loadLib();
    }
  } catch (exc) {
    toast(exc.message || 'Could not stub this stream', 'er');
    btn.textContent = original;
    btn.disabled = false;
  }
}

async function delStub(id) {
  await fetch(`/api/stubs/${id}`, { method: 'DELETE' });
  toast('Stub deleted', 'ok');
  loadLib();
}

// ── Config ────────────────────────────────────────────────────
async function loadApiKey() {
  const field = document.getElementById('apiKeyField');
  const note  = document.getElementById('apiKeySrcNote');
  const gen   = document.getElementById('apiKeyGenBtn');
  const rev   = document.getElementById('apiKeyRevokeBtn');
  if (!field) return;
  try {
    const d = await (await fetch('/api/apikey')).json();
    field.value = d.key || '';
    field.placeholder = d.key ? '' : 'No API key yet — generate one below';
    const fromEnv = d.source === 'env';
    note.style.display = fromEnv ? 'block' : 'none';
    if (fromEnv) {
      note.textContent = 'This key comes from the AIOGW_API_KEY environment variable, '
        + 'which takes precedence over anything set here. Remove it from '
        + 'docker-compose.yml to manage the key from this page.';
    }
    gen.disabled = fromEnv;
    rev.disabled = fromEnv || !d.key;
    gen.style.opacity = fromEnv ? .45 : 1;
    rev.style.opacity = (fromEnv || !d.key) ? .45 : 1;
    gen.textContent = d.key && !fromEnv ? 'Regenerate key' : 'Generate new key';
    renderApiExamples(d.key);
  } catch {
    field.placeholder = 'Could not load API key';
  }
}

function renderApiExamples(key) {
  const el = document.getElementById('apiKeyExamples');
  if (!el) return;
  const k = key || 'YOUR_KEY';
  const base = window.location.origin;
  el.textContent =
    `# See TTL and prewarm state\n` +
    `curl -H "X-API-Key: ${k}" \\\n  ${base}/api/ttl/status\n\n` +
    `# Expire every active stub (reset all TTLs)\n` +
    `curl -X POST -H "X-API-Key: ${k}" \\\n  -H "Content-Type: application/json" -d '{}' \\\n  ${base}/api/stubs/expire-all\n\n` +
    `# Series only\n` +
    `curl -X POST -H "X-API-Key: ${k}" \\\n  -H "Content-Type: application/json" -d '{"media_type":"series"}' \\\n  ${base}/api/stubs/expire-all`;
}

async function copyApiKey() {
  const field = document.getElementById('apiKeyField');
  if (!field || !field.value) { toast('No key to copy', 'er'); return; }
  try {
    await navigator.clipboard.writeText(field.value);
    toast('API key copied', 'ok');
  } catch {
    // Clipboard API needs a secure context; plenty of people reach this
    // over plain http on a LAN IP, where it silently fails.
    field.removeAttribute('readonly');
    field.select();
    document.execCommand('copy');
    field.setAttribute('readonly', '');
    toast('API key copied', 'ok');
  }
}

async function generateApiKey() {
  const existing = document.getElementById('apiKeyField').value;
  if (existing && !confirm('Generate a new key? The current one stops working immediately.')) return;
  try {
    const r = await fetch('/api/apikey/generate', { method: 'POST' });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Could not generate a key');
    toast('New API key generated', 'ok');
    await loadApiKey();
  } catch (exc) { toast(exc.message || 'Could not generate a key', 'er'); }
}

async function revokeApiKey() {
  if (!confirm('Revoke the API key? Anything using it will stop working.')) return;
  try {
    const r = await fetch('/api/apikey', { method: 'DELETE' });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Could not revoke the key');
    toast('API key revoked', 'ok');
    await loadApiKey();
  } catch (exc) { toast(exc.message || 'Could not revoke the key', 'er'); }
}

function switchCfgTab(name) {
  document.querySelectorAll('.cfgtab').forEach(el => el.classList.remove('on'));
  document.querySelectorAll('.cfgpanel').forEach(el => el.classList.remove('on'));
  document.getElementById(`cfgtab-${name}`).classList.add('on');
  document.getElementById(`cfgpanel-${name}`).classList.add('on');
}

async function loadUsers() {
  const wrap = document.getElementById('usersList');
  if (!wrap) return;
  try {
    const d = await (await fetch('/api/users')).json();
    const users = d.users || [];
    if (!users.length) {
      wrap.innerHTML = `<div style="color:var(--mut);font-size:13px">No users yet.</div>`;
      return;
    }
    const adminCount = users.filter(u => u.role === 'admin').length;
    users.sort((a,b) => (a.username||'').localeCompare(b.username||''));
    wrap.innerHTML = users.map(u => {
      const isSelf = currentUser && currentUser.plex_user_id === u.plex_user_id;
      const isLastAdmin = u.role === 'admin' && adminCount <= 1;
      const avatar = u.thumb
        ? `<img src="${u.thumb}" style="width:40px;height:40px;border-radius:50%;object-fit:cover">`
        : `<div style="width:40px;height:40px;border-radius:50%;background:var(--acc);color:#000;font-weight:800;font-size:15px;display:flex;align-items:center;justify-content:center">${(u.username||'?').charAt(0).toUpperCase()}</div>`;
      const roleBadge = u.role === 'admin'
        ? `<span class="cal-badge inlib">Admin</span>`
        : `<span class="cal-badge">User</span>`;
      const lastLogin = u.last_login ? new Date(u.last_login * 1000).toLocaleDateString() : '—';
      return `
      <div class="cal-entry">
        ${avatar}
        <div class="cal-info">
          <div class="cal-title">${u.username}${isSelf ? ' (you)' : ''}</div>
          <div class="cal-sub">${u.email || ''}${u.email ? ' · ' : ''}Last login ${lastLogin}</div>
        </div>
        ${roleBadge}
        <div style="display:flex;gap:6px;margin-left:10px">
          ${u.role === 'admin'
            ? `<button class="cal-rescan-btn" ${isLastAdmin ? 'disabled title="Can\'t demote the last remaining admin"' : ''} onclick="changeUserRole('${u.plex_user_id}','user',this)">Make user</button>`
            : `<button class="cal-rescan-btn" onclick="changeUserRole('${u.plex_user_id}','admin',this)">Make admin</button>`}
          <button class="cal-rescan-btn" ${isLastAdmin ? 'disabled title="Can\'t remove the last remaining admin"' : ''} style="color:var(--red)" onclick="removeUserAccount('${u.plex_user_id}','${(u.username||'').replace(/'/g,"\\'")}',this)">Remove</button>
        </div>
      </div>`;
    }).join('');
  } catch {
    wrap.innerHTML = `<div style="color:var(--red);font-size:13px">Could not load users.</div>`;
  }
}

async function changeUserRole(plexUserId, role, btn) {
  btn.disabled = true;
  try {
    const r = await fetch(`/api/users/${plexUserId}/role`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role }),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || 'Could not change role');
    toast(`Role updated — that account is now signed out everywhere and will need to log in again`, 'ok');
    loadUsers();
  } catch (exc) {
    toast(exc.message || 'Could not change role', 'er');
    btn.disabled = false;
  }
}

async function removeUserAccount(plexUserId, username, btn) {
  if (!confirm(`Remove ${username}'s account? They'll need to log in again to get a new one.`)) return;
  btn.disabled = true;
  try {
    const r = await fetch(`/api/users/${plexUserId}`, { method: 'DELETE' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.detail || 'Could not remove user');
    toast(`Removed ${username}`, 'ok');
    loadUsers();
  } catch (exc) {
    toast(exc.message || 'Could not remove user', 'er');
    btn.disabled = false;
  }
}

async function loadCfg() {
  try {
    const d = await (await fetch('/api/config')).json();
    document.getElementById('cfgChips').innerHTML =
      chip('AIOSTREAMS_URL', d.aiostreams_url, true) +
      chip('UUID',           d.uuid_set ? 'Set' : 'Not set', d.uuid_set) +
      chip('PASSWORD',       d.password_set ? 'Set' : 'Not set', d.password_set);
    document.getElementById('wurl').textContent = `http://${location.hostname}:8001/webhook/plex`;

    const f = d.fuse || {};
    document.getElementById('fuseChips').innerHTML =
      chip('FUSE_MOUNTPOINT',        f.mountpoint, true) +
      chip('FUSE_BLOCK_MB',          f.block_mb, true) +
      chip('FUSE_CACHE_BLOCKS',      f.cache_blocks, true) +
      chip('FUSE_PREFETCH_AHEAD',    f.prefetch_ahead, true) +
      chip('FUSE_READ_TIMEOUT',      f.read_timeout, true) +
      chip('FUSE_RESOLVE_TIMEOUT',   f.resolve_timeout, true) +
      chip('FUSE_MAX_INFLIGHT',      f.max_inflight, true) +
      chip('FUSE_POOL_CONNECTIONS',  f.pool_connections, true) +
      chip('FUSE_POOL_MAXSIZE',      f.pool_maxsize, true);
  } catch {}
  try {
    const s = await (await fetch('/api/settings')).json();
    document.getElementById('ttlEnabled').checked = s.active_ttl_enabled !== false;
    document.getElementById('prewarmEnabled').checked = s.prewarm_enabled ?? true;
    refreshPrewarmTtlWarn(s.active_ttl_days ?? 30, s.active_ttl_enabled !== false);
    loadTtlCoverage();
    document.getElementById('prefLanguage').value = s.preferred_language ?? '';
    document.getElementById('prefAudio').value = (s.preferred_audio ?? []).join(', ');
    document.getElementById('reqSubs').checked = !!s.require_subtitles;
    document.getElementById('preferPacks').checked = s.prefer_season_packs !== false;
    document.getElementById('allowUsenet').checked = s.allow_usenet !== false;
    document.getElementById('minSizeGb').value = s.min_size_gb ?? 0;
    document.getElementById('maxSizeGb').value = s.max_size_gb ?? 0;
    document.getElementById('excludeWords').value = (s.exclude_words ?? []).join(', ');
    document.getElementById('min4kCandidates').value = s.min_4k_candidates ?? 6;
    document.getElementById('autoEpEnabled').checked = s.auto_episodes_enabled !== false;
    document.getElementById('autoEpInterval').value = s.auto_episodes_interval_minutes ?? 10;
    document.getElementById('autoEpRetryDays').value = s.auto_episodes_retry_days ?? 3;
    document.getElementById('pendingMvEnabled').checked = s.pending_movies_enabled !== false;
    document.getElementById('pendingMvRetryDays').value = s.pending_movies_retry_days ?? 30;
    document.getElementById('digitalDelayDays').value = s.digital_release_delay_days ?? 21;
    document.getElementById('deadStubMaxErrors').value = s.dead_stub_max_errors ?? 3;
    document.getElementById('aioMaxConcurrent').value = s.aiostreams_max_concurrent ?? 1;
    document.getElementById('aioMinInterval').value = s.aiostreams_min_interval_ms ?? 1500;
  } catch {}
  migSvcChanged();
}

async function removePendingMovie(imdbId, btn) {
  if (btn) btn.disabled = true;
  try {
    await fetch(`/api/pending-movies/${imdbId}`, { method: 'DELETE' });
    loadLib();
  } catch {
    toast('Could not remove', 'er');
    if (btn) btn.disabled = false;
  }
}

async function removeQualityUnavailable(key, btn) {
  if (btn) btn.disabled = true;
  try {
    await fetch(`/api/quality-unavailable/${encodeURIComponent(key)}`, { method: 'DELETE' });
    loadLib();
  } catch {
    toast('Could not remove mark', 'er');
    if (btn) btn.disabled = false;
  }
}

async function removeWantedSeason(imdbId, season, btn) {
  if (btn) btn.disabled = true;
  try {
    await fetch(`/api/wanted-seasons/${imdbId}/${season}`, { method: 'DELETE' });
    loadLib();
  } catch {
    toast('Could not remove', 'er');
    if (btn) btn.disabled = false;
  }
}

async function savePendingMovies() {
  const retryDays = parseFloat(document.getElementById('pendingMvRetryDays').value);
  const digitalDelay = parseFloat(document.getElementById('digitalDelayDays').value);
  if (isNaN(retryDays) || retryDays < 0) {
    toast('Retry window must be ≥ 0 days', 'er');
    return;
  }
  if (isNaN(digitalDelay) || digitalDelay < 0) {
    toast('Digital delay must be ≥ 0 days', 'er');
    return;
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        pending_movies_enabled: document.getElementById('pendingMvEnabled').checked,
        pending_movies_retry_days: retryDays,
        digital_release_delay_days: digitalDelay,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('pendingMvSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function runPendingMoviesSweepNow() {
  const resultEl = document.getElementById('pendingMvSweepResult');
  resultEl.innerHTML = `<span style="color:var(--mut)">Checking…</span>`;
  try {
    const d = await (await fetch('/api/pending-movies/sweep-now', { method: 'POST' })).json();
    resultEl.innerHTML = `<span style="color:var(--grn)">Checked ${d.checked ?? 0}, resolved ${d.resolved ?? 0}, ${d.pending ?? 0} still pending</span>`;
    loadPendingMovies();
    loadLib();
  } catch {
    resultEl.innerHTML = `<span style="color:var(--red)">Check failed</span>`;
  }
}

// ── Migrate (Radarr/Sonarr) ──────────────────────────────────────
let migPreviewItems = [];
let migPollTimer = null;

async function migSvcChanged() {
  const svc = document.getElementById('migSvc').value;
  document.getElementById('migPreviewWrap').style.display = 'none';
  document.getElementById('migTestResult').innerHTML = '';
  document.getElementById('migKey').value = '';
  try {
    const s = await (await fetch('/api/migrate/settings')).json();
    if (svc === 'radarr') {
      document.getElementById('migUrl').value = s.radarr_url || '';
      document.getElementById('migKey').placeholder = s.radarr_configured ? 'Saved — leave blank to keep it' : 'API key';
    } else {
      document.getElementById('migUrl').value = s.sonarr_url || '';
      document.getElementById('migKey').placeholder = s.sonarr_configured ? 'Saved — leave blank to keep it' : 'API key';
    }
  } catch {}
}

async function migSaveAndTest() {
  const svc = document.getElementById('migSvc').value;
  const url = document.getElementById('migUrl').value.trim();
  const key = document.getElementById('migKey').value.trim();
  const resultEl = document.getElementById('migTestResult');
  if (!url) {
    resultEl.innerHTML = `<span style="color:var(--red)">Enter a URL first</span>`;
    return;
  }
  resultEl.innerHTML = `<span style="color:var(--mut)">Saving…</span>`;
  try {
    const body = { service: svc, url };
    if (key) body.api_key = key;
    let r = await fetch('/api/migrate/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || 'save failed');

    resultEl.innerHTML = `<span style="color:var(--mut)">Testing connection…</span>`;
    r = await fetch('/api/migrate/test', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ service: svc })
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'connection failed');
    resultEl.innerHTML = `<span style="color:var(--grn)">✓ Connected — ${d.instance_name || svc} v${d.version}</span>`;
    document.getElementById('migKey').value = '';
    migSvcChanged();
  } catch (exc) {
    resultEl.innerHTML = `<span style="color:var(--red)">${exc.message}</span>`;
  }
}

async function migLoadPreview() {
  const svc = document.getElementById('migSvc').value;
  const resultEl = document.getElementById('migTestResult');
  resultEl.innerHTML = `<span style="color:var(--mut)">Loading library from ${svc}…</span>`;
  try {
    const r = await fetch(`/api/migrate/preview?service=${svc}`);
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'load failed');
    migPreviewItems = d.items || [];
    resultEl.innerHTML = '';
    renderMigList(svc);
  } catch (exc) {
    resultEl.innerHTML = `<span style="color:var(--red)">${exc.message}</span>`;
  }
}

function renderMigList(svc) {
  const wrap = document.getElementById('migPreviewWrap');
  const list = document.getElementById('migList');
  const already = migPreviewItems.filter(it => it.in_library).length;
  document.getElementById('migPreviewSummary').textContent =
    `${migPreviewItems.length} ${svc === 'radarr' ? 'movie(s)' : 'series'} found · ${already} already in your library`;

  if (!migPreviewItems.length) {
    list.innerHTML = `<div style="color:var(--mut);font-size:13px;padding:16px">Nothing found — check the connection above.</div>`;
    wrap.style.display = 'block';
    return;
  }

  list.innerHTML = migPreviewItems.map((it, i) => {
    const sub = svc === 'radarr'
      ? (it.year || '')
      : `${it.seasons.length} season${it.seasons.length === 1 ? '' : 's'}${it.year ? ' · ' + it.year : ''}`;
    const badges = [];
    if (it.in_library) badges.push(`<span class="cal-badge inlib">Already in library</span>`);
    if (svc === 'radarr' && !it.has_file) badges.push(`<span class="cal-badge">Not downloaded in Radarr yet</span>`);
    const poster = it.poster
      ? `<img class="cal-poster" src="${it.poster}" loading="lazy">`
      : `<div class="cal-poster-placeholder">${svc === 'radarr' ? '\uD83C\uDFAC' : '\uD83D\uDCFA'}</div>`;
    return `<label class="cal-entry${it.in_library ? ' inlib' : ''}" style="cursor:pointer">
      <input type="checkbox" class="migItemCk" data-i="${i}" ${it.in_library ? '' : 'checked'} style="cursor:pointer;flex-shrink:0" onclick="event.stopPropagation()">
      ${poster}
      <div class="cal-info">
        <div class="cal-title">${it.title}</div>
        <div class="cal-sub">${sub}</div>
        ${badges.length ? `<div class="cal-badges">${badges.join('')}</div>` : ''}
      </div>
    </label>`;
  }).join('');
  wrap.style.display = 'block';
}

function migSelectAll(on) {
  document.querySelectorAll('.migItemCk').forEach(el => { el.checked = on; });
}

async function migStart() {
  const svc = document.getElementById('migSvc').value;
  const checked = Array.from(document.querySelectorAll('.migItemCk'))
    .filter(el => el.checked)
    .map(el => migPreviewItems[parseInt(el.getAttribute('data-i'), 10)].imdb_id);

  if (!checked.length) {
    toast('Select at least one title to migrate', 'er');
    return;
  }

  try {
    const r = await fetch('/api/migrate/run', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ service: svc, imdb_ids: checked, skip_existing: true })
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'could not start migration');
    migOpenModal(svc);
    migPoll(d.job_id);
  } catch (exc) {
    toast(exc.message || 'Could not start migration', 'er');
  }
}

function migOpenModal(svc) {
  document.getElementById('migModalTitle').textContent =
    `Migrating from ${svc === 'radarr' ? 'Radarr' : 'Sonarr'}`;
  document.getElementById('migModalCurrent').textContent = '';
  document.getElementById('migBar').style.width = '0%';
  document.getElementById('migCount').textContent = '0 / 0';
  document.getElementById('migStatusLabel').textContent = 'Starting…';
  document.getElementById('migErrors').innerHTML = '';
  const cancelBtn = document.getElementById('migCancelBtn');
  cancelBtn.style.display = 'inline-flex';
  cancelBtn.disabled = false;
  cancelBtn.textContent = 'Cancel';
  document.getElementById('migCloseBtn').style.display = 'none';
  document.getElementById('migModal').classList.add('open');
}

function migCloseModal() {
  document.getElementById('migModal').classList.remove('open');
  if (migPollTimer) { clearTimeout(migPollTimer); migPollTimer = null; }
}

let migCurrentJobId = null;

async function migCancel() {
  if (!migCurrentJobId) return;
  // Interrupts the current item immediately server-side (see
  // cancel_migration/_run_migration) — disable right away so it's clear
  // the click registered instead of inviting repeated presses while
  // still waiting on the next status poll to reflect it.
  const btn = document.getElementById('migCancelBtn');
  btn.disabled = true;
  btn.textContent = 'Cancelling…';
  document.getElementById('migStatusLabel').textContent = 'Cancelling…';
  try { await fetch(`/api/migrate/cancel/${migCurrentJobId}`, { method: 'POST' }); } catch {}
}

async function migPoll(jobId) {
  migCurrentJobId = jobId;
  try {
    const job = await (await fetch(`/api/migrate/status/${jobId}`)).json();
    const total = job.total || 0;
    const done  = job.done || 0;
    const pct = total ? Math.round((done / total) * 100) : (job.finished ? 100 : 0);
    document.getElementById('migBar').style.width = `${pct}%`;
    document.getElementById('migCount').textContent = `${done} / ${total}`;
    document.getElementById('migModalCurrent').textContent = job.current_title || '';

    const labels = { starting:'Starting…', running:'Migrating…', done:'Done', cancelled:'Cancelled', error:'Failed' };
    document.getElementById('migStatusLabel').textContent = labels[job.status] || job.status;

    if (job.errors && job.errors.length) {
      document.getElementById('migErrors').innerHTML =
        job.errors.map(e => `<div>⚠ ${e}</div>`).join('');
    }

    if (job.finished) {
      document.getElementById('migCancelBtn').style.display = 'none';
      document.getElementById('migCloseBtn').style.display = 'inline-flex';
      migPollTimer = null;
      if (job.status === 'done') { loadLib(); loadCalendar(); }
      return;
    }
    migPollTimer = setTimeout(() => migPoll(jobId), 1000);
  } catch {
    migPollTimer = setTimeout(() => migPoll(jobId), 2000);
  }
}

// ── Prewarm new content ───────────────────────────────────────
let prewarmPollTimer = null;
let prewarmCurrentJobId = null;

// The window/interval/retry/bulk-threshold knobs this section used to
// expose are gone — the TTL is the only dial on this tab now. Their
// values still exist in settings (and are still tunable via
// POST /api/settings for anyone who wants to), they just default to
// sensible numbers instead of asking the user to pick four.
async function savePrewarmEnabled() {
  const enabled = document.getElementById('prewarmEnabled').checked;
  try {
    const r = await fetch('/api/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prewarm_enabled: enabled })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('prewarmDaysSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    // Put the checkbox back — it shouldn't show a state that wasn't saved.
    document.getElementById('prewarmEnabled').checked = !enabled;
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function runPrewarmNewContent() {
  document.getElementById('prewarmModalTitle').textContent = 'Prewarming new content…';
  document.getElementById('prewarmModalCurrent').textContent = '';
  document.getElementById('prewarmProgressWrap').style.display = 'block';
  document.getElementById('prewarmResults').style.display = 'none';
  document.getElementById('prewarmResults').innerHTML = '';
  document.getElementById('prewarmBar').style.width = '0%';
  document.getElementById('prewarmCount').textContent = '0 / 0';
  document.getElementById('prewarmStatusLabel').textContent = 'Starting…';
  const cancelBtn = document.getElementById('prewarmCancelBtn');
  cancelBtn.style.display = 'inline-flex';
  cancelBtn.disabled = false;
  cancelBtn.textContent = 'Cancel';
  document.getElementById('prewarmCloseBtn').style.display = 'none';
  document.getElementById('prewarmModal').classList.add('open');

  try {
    const r = await fetch('/api/prewarm-new-content/run', { method: 'POST' });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Could not start');
    prewarmPoll(d.job_id);
  } catch (exc) {
    toast(exc.message || 'Could not start prewarm', 'er');
    document.getElementById('prewarmModal').classList.remove('open');
  }
}

function prewarmCloseModal() {
  document.getElementById('prewarmModal').classList.remove('open');
  if (prewarmPollTimer) { clearTimeout(prewarmPollTimer); prewarmPollTimer = null; }
}

async function prewarmCancel() {
  if (!prewarmCurrentJobId) return;
  const btn = document.getElementById('prewarmCancelBtn');
  btn.disabled = true;
  btn.textContent = 'Cancelling…';
  document.getElementById('prewarmStatusLabel').textContent = 'Cancelling…';
  try { await fetch(`/api/prewarm-new-content/cancel/${prewarmCurrentJobId}`, { method: 'POST' }); } catch {}
}

async function prewarmPoll(jobId) {
  prewarmCurrentJobId = jobId;
  try {
    const job = await (await fetch(`/api/prewarm-new-content/status/${jobId}`)).json();
    const total = job.total || 0;
    const done  = job.done || 0;
    const pct = total ? Math.round((done / total) * 100) : (job.finished ? 100 : 0);
    document.getElementById('prewarmBar').style.width = `${pct}%`;
    document.getElementById('prewarmCount').textContent = `${done} / ${total}`;
    document.getElementById('prewarmModalCurrent').textContent = job.current_title || '';

    const phaseLabels = {
      queued:    'Waiting for another prewarm pass…',
      selecting: 'Checking what qualifies…',
      resolving: 'Resolving…',
    };
    const labels = {
      starting: 'Starting…',
      queued:   'Queued behind another pass…',
      running:  phaseLabels[job.phase] || 'Running…',
      done:     'Done',
      cancelled:'Cancelled',
      error:    'Failed',
    };
    document.getElementById('prewarmStatusLabel').textContent = labels[job.status] || job.status;

    if (job.finished) {
      document.getElementById('prewarmCancelBtn').style.display = 'none';
      document.getElementById('prewarmCloseBtn').style.display = 'inline-flex';
      prewarmPollTimer = null;
      if (job.status === 'done') {
        renderPrewarmResults(job);
      } else if (job.status === 'error') {
        // A pass that blew up mid-way still has partial results worth
        // showing, but lead with what went wrong rather than silently
        // presenting it as a normal finish.
        document.getElementById('prewarmModalTitle').textContent = 'Prewarm failed';
        document.getElementById('prewarmModalCurrent').textContent = job.error || 'Unknown error';
        document.getElementById('prewarmProgressWrap').style.display = 'none';
      }
      return;
    }
    prewarmPollTimer = setTimeout(() => prewarmPoll(jobId), 1000);
  } catch {
    prewarmPollTimer = setTimeout(() => prewarmPoll(jobId), 2000);
  }
}

function renderPrewarmResults(job) {
  const resolved  = job.resolved || [];
  const deadRemoved = job.dead_removed || [];
  const stillPh   = job.still_placeholder || [];
  document.getElementById('prewarmProgressWrap').style.display = 'none';

  const total = resolved.length + deadRemoved.length + stillPh.length;
  document.getElementById('prewarmModalTitle').textContent =
    total === 0 ? 'Nothing to prewarm' : `Resolved ${resolved.length} of ${total} item${total !== 1 ? 's' : ''}`;
  document.getElementById('prewarmModalCurrent').textContent =
    total === 0 ? 'Nothing added or released within the configured window is still a placeholder.'
    : deadRemoved.length ? `${deadRemoved.length} had no working sources and were removed.`
    : '';

  const resEl = document.getElementById('prewarmResults');
  resEl.style.display = 'block';

  const row = (title, poster, badgeLabel, badgeClass, reason) => `
    <div class="cal-entry${badgeClass === 'inlib' ? ' inlib' : ''}" style="margin-bottom:8px">
      ${poster ? `<img class="cal-poster" src="${poster}" loading="lazy">` : `<div class="cal-poster-placeholder">\uD83C\uDFAC</div>`}
      <div class="cal-info">
        <div class="cal-title">${title}</div>
        ${reason ? `<div class="cal-sub">${reason}</div>` : ''}
      </div>
      <span class="cal-badge${badgeClass === 'inlib' ? ' inlib' : ''}">${badgeLabel}</span>
    </div>`;

  let html = '';
  html += resolved.map(r => row(r.title, r.poster, 'Resolved', 'inlib')).join('');
  html += deadRemoved.map(r => row(r.title, '', 'Removed — no sources', '')).join('');
  html += stillPh.map(r => row(r.title, '', 'Still placeholder', '', r.reason)).join('');
  if (!total) {
    html = `<div style="color:var(--mut);font-size:13px;padding:12px 0">Nothing to show.</div>`;
  }
  resEl.innerHTML = html;

  if (resolved.length > 0) { loadLib(); }
}

function chip(l,v,ok){return`<div class="chip"><span class="cl">${l}</span><span class="cv ${ok?'ok':'er'}">${v}</span></div>`}

// Shows what the single TTL is currently holding, per library. The point
// is to make "it covers all four" checkable rather than a claim in the
// blurb — if 4K series were somehow escaping expiry, it'd show here.
async function loadTtlCoverage() {
  const el = document.getElementById('ttlCoverage');
  if (!el) return;
  try {
    const d = await (await fetch('/api/ttl-status')).json();
    const a = d.active || {};
    const cell = (label, n) =>
      `<span style="display:inline-block;min-width:120px">${label}: <strong style="color:var(--txt)">${n ?? 0}</strong></span>`;
    const note = d.ttl_days > 0
      ? `Each reverts to a placeholder ${d.ttl_days} day${d.ttl_days === 1 ? '' : 's'} after it resolved.`
      : `Expiry is off — these stay active indefinitely.`;
    el.innerHTML =
      `Currently active under this TTL:<br>` +
      cell('Movies', a.Movies) + cell('Movies4K', a.Movies4K) + '<br>' +
      cell('Series', a.Series) + cell('Series4K', a.Series4K) + '<br>' +
      `${note} ${d.placeholders ?? 0} placeholder${(d.placeholders ?? 0) === 1 ? '' : 's'} waiting.`;
  } catch {
    el.innerHTML = '';
  }
}

async function saveTtlEnabled() {
  const enabled = document.getElementById('ttlEnabled').checked;
  try {
    const r = await fetch('/api/settings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active_ttl_enabled: enabled })
    });
    if (!r.ok) throw new Error('save failed');
    const saved = document.getElementById('ttlEnabledSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
    loadTtlCoverage();
    // The TTL is fixed at 30 days now — only the switch itself changes.
    refreshPrewarmTtlWarn(30, enabled);
  } catch {
    // Put the checkbox back — it shouldn't show a state that wasn't saved.
    document.getElementById('ttlEnabled').checked = !enabled;
    toast('Could not save setting', 'er');
  }
}

function refreshPrewarmTtlWarn(ttlDays, ttlEnabled) {
  const warn = document.getElementById('prewarmTtlWarn');
  const box  = document.getElementById('prewarmEnabled');
  if (!warn || !box) return;
  const dead = ttlEnabled === false || !(parseFloat(ttlDays) > 0);
  warn.style.display     = dead ? 'block' : 'none';
  box.disabled           = dead;
  box.parentElement.style.opacity = dead ? '0.55' : '1';
}

async function saveStreamPrefs() {
  const minGb = parseFloat(document.getElementById('minSizeGb').value) || 0;
  const maxGb = parseFloat(document.getElementById('maxSizeGb').value) || 0;
  if (minGb < 0 || maxGb < 0) {
    toast('Sizes must be ≥ 0', 'er');
    return;
  }
  if (minGb && maxGb && minGb > maxGb) {
    toast('Min size cannot be greater than max size', 'er');
    return;
  }
  const min4k = parseInt(document.getElementById('min4kCandidates').value, 10);
  if (isNaN(min4k) || min4k < 1) {
    toast('Minimum 4K sources must be at least 1', 'er');
    return;
  }
  const audio = document.getElementById('prefAudio').value
    .split(',').map(s => s.trim()).filter(Boolean);
  const excludeWords = document.getElementById('excludeWords').value
    .split(',').map(s => s.trim()).filter(Boolean);

  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        preferred_language: document.getElementById('prefLanguage').value.trim(),
        preferred_audio: audio,
        require_subtitles: document.getElementById('reqSubs').checked,
        prefer_season_packs: document.getElementById('preferPacks').checked,
        allow_usenet: document.getElementById('allowUsenet').checked,
        min_size_gb: minGb,
        max_size_gb: maxGb,
        exclude_words: excludeWords,
        min_4k_candidates: min4k,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('streamPrefsSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save preferences', 'er');
  }
}

async function saveAutoEpisodes() {
  const interval = parseInt(document.getElementById('autoEpInterval').value, 10);
  const retryDays = parseFloat(document.getElementById('autoEpRetryDays').value);
  if (isNaN(interval) || interval < 5) {
    toast('Check interval must be at least 5 minutes', 'er');
    return;
  }
  if (isNaN(retryDays) || retryDays < 0) {
    toast('Retry window must be ≥ 0 days', 'er');
    return;
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        auto_episodes_enabled: document.getElementById('autoEpEnabled').checked,
        auto_episodes_interval_minutes: interval,
        auto_episodes_retry_days: retryDays,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('autoEpSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function saveDeadStubCleanup() {
  const maxErrors = parseInt(document.getElementById('deadStubMaxErrors').value, 10);
  if (isNaN(maxErrors) || maxErrors < 0) {
    toast('Enter a whole number ≥ 0', 'er');
    return;
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dead_stub_max_errors: maxErrors })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('deadStubSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 2000);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function saveAioPacing() {
  const maxConcurrent = parseInt(document.getElementById('aioMaxConcurrent').value, 10);
  const minInterval = parseFloat(document.getElementById('aioMinInterval').value);
  if (isNaN(maxConcurrent) || maxConcurrent < 1) {
    toast('Requests in flight must be at least 1', 'er');
    return;
  }
  if (isNaN(minInterval) || minInterval < 0) {
    toast('Minimum gap must be ≥ 0 ms', 'er');
    return;
  }
  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        aiostreams_max_concurrent: maxConcurrent,
        aiostreams_min_interval_ms: minInterval,
      })
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.detail || 'save failed');
    }
    const saved = document.getElementById('aioPacingSaved');
    saved.style.display = 'inline';
    setTimeout(() => { saved.style.display = 'none'; }, 3500);
  } catch (exc) {
    toast(exc.message || 'Could not save setting', 'er');
  }
}

async function runAutoEpisodeSweepNow() {
  const resultEl = document.getElementById('autoEpSweepResult');
  resultEl.innerHTML = '<span style="color:var(--mut)">Checking tracked shows for new episodes…</span>';
  try {
    const r = await fetch('/api/auto-episodes/sweep-now', { method: 'POST' });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Sweep failed');
    if (d.skipped) {
      resultEl.innerHTML = `<span style="color:var(--mut)">Skipped (${d.skipped})</span>`;
      return;
    }
    let msg = `Checked ${d.shows_checked} show${d.shows_checked!==1?'s':''}`;
    if (d.new_stubs) msg += ` — ${d.new_stubs} new episode${d.new_stubs!==1?'s':''} stubbed`;
    else msg += ' — no new episodes found';
    if (d.pending) msg += ` (${d.pending} still waiting on a stream)`;
    resultEl.innerHTML = `<span style="color:var(--grn)">✓ ${msg}</span>`;
    if (d.new_stubs) { toast('New episodes added', 'ok'); if (typeof loadLib === 'function') loadLib(); }
  } catch (exc) {
    resultEl.innerHTML = `<span style="color:var(--red)">✕ ${exc.message}</span>`;
  }
}

function downloadBackup() {
  // Plain navigation triggers the browser's normal file-download flow and
  // picks up the Content-Disposition filename from the server response.
  window.location.href = '/api/backup';
}

async function restoreFromFile(event) {
  const file = event.target.files[0];
  event.target.value = '';   // allow re-selecting the same file later
  if (!file) return;

  const resultEl = document.getElementById('restoreResult');
  resultEl.innerHTML = '<span style="color:var(--mut)">Restoring…</span>';

  let bundle;
  try {
    const text = await file.text();
    bundle = JSON.parse(text);
  } catch {
    resultEl.innerHTML = '<span style="color:var(--red)">✕ Not a valid JSON file</span>';
    return;
  }

  const replace = document.getElementById('restoreReplace').checked;
  if (replace && !confirm('This will WIPE your current library before restoring. Continue?')) {
    resultEl.innerHTML = '';
    return;
  }

  try {
    const r = await fetch('/api/restore', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ bundle, replace })
    });
    const d = await r.json();
    if (!r.ok) {
      resultEl.innerHTML = `<span style="color:var(--red)">✕ ${d.detail || 'Restore failed'}</span>`;
      return;
    }
    const lib = d.library;
    let msg = d.settings_restored ? 'Settings restored. ' : '';
    if (lib) {
      msg += `Library: ${lib.imported} imported`;
      if (lib.skipped) msg += `, ${lib.skipped} skipped (already present)`;
      if (lib.errors && lib.errors.length) msg += `, ${lib.errors.length} error(s)`;
    }
    resultEl.innerHTML = `<span style="color:var(--grn)">✓ ${msg}</span>`;
    toast('Restore complete', 'ok');
    loadCfg();
    if (typeof loadLib === 'function') loadLib();
  } catch (exc) {
    resultEl.innerHTML = '<span style="color:var(--red)">✕ Restore request failed</span>';
  }
}

async function runTest() {
  const el = document.getElementById('tresult');
  el.innerHTML = '<span style="color:var(--mut)">Testing…</span>';
  try {
    const d = await (await fetch('/api/test')).json();

    if (d.diagnosis === 'stub') {
      el.innerHTML = `<span style="color:var(--blue)">ℹ Stub mode — AIOSTREAMS_UUID not set. Set it in docker-compose.yml to connect to your AIOStreams instance.</span>`;
      return;
    }

    if (d.ok) {
      el.innerHTML = `<span style="color:var(--grn)">✓ Connected to ${d.url}</span>
        <span style="color:var(--mut);font-size:12px;margin-left:8px">${d.direct_urls} direct streams from ${d.total_results} results</span>`;
    } else {
      const diag = {
        bad_auth:    '🔑 Wrong UUID or password — check AIOSTREAMS_UUID / AIOSTREAMS_PASSWORD',
        no_addons:   '📦 No addons installed — open AIOStreams and install Torrentio or similar',
        no_debrid:   '💳 No debrid service configured — add Real-Debrid/AllDebrid in AIOStreams Services tab',
        unreachable: '🔌 Cannot reach AIOStreams — check AIOSTREAMS_URL and that the container is running',
      }[d.diagnosis] || '';
      el.innerHTML = `<div style="color:var(--red);margin-bottom:6px">✗ ${d.error || 'Connection failed'}</div>`
        + (diag ? `<div style="color:var(--acc2);font-size:12px">${diag}</div>` : '')
        + (d.url ? `<div style="color:var(--mut);font-size:11px;margin-top:4px;font-family:monospace">${d.url}</div>` : '');
    }
  } catch(e) {
    el.innerHTML = `<span style="color:var(--red)">✗ ${e.message}</span>`;
  }
}

// ── Search ────────────────────────────────────────────────────
let srchTab = 'all', srchTimer = null, lastQuery = '';

function onSrchInput(val) {
  document.getElementById('srchClear').style.display = val ? 'block' : 'none';
  clearTimeout(srchTimer);
  if (!val.trim()) {
    showSearchEmpty();
    lastQuery = '';
    return;
  }
  srchTimer = setTimeout(() => doSearch(), 420);
}

function setTab(tab, el) {
  srchTab = tab;
  document.querySelectorAll('.srch-tab').forEach(t => t.classList.remove('on'));
  el.classList.add('on');
  if (lastQuery) doSearch();
}

function clearSearch() {
  document.getElementById('srchInput').value = '';
  document.getElementById('srchClear').style.display = 'none';
  lastQuery = '';
  showSearchEmpty();
}

function showSearchEmpty() {
  document.getElementById('srchStatus').textContent = '';
  document.getElementById('srchGrid').innerHTML = `
    <div class="srch-empty">
      
      <div class="srch-empty-title">Search for movies and series</div>
      <div class="srch-empty-sub">Powered by Cinemeta — the same source as Stremio</div>
    </div>`;
}

async function doSearch() {
  const q = document.getElementById('srchInput').value.trim();
  if (!q) return;
  lastQuery = q;

  const grid = document.getElementById('srchGrid');
  const status = document.getElementById('srchStatus');
  status.textContent = 'Searching…';

  // Skeleton placeholders matching card() dimensions
  grid.innerHTML = Array(8).fill(0).map(() =>
    `<div class="card" style="pointer-events:none">
       <div class="skel cposter"></div>
       <div class="skel cname" style="height:12px;margin-top:8px;width:80%"></div>
       <div class="skel cyear" style="height:11px;margin-top:5px;width:45%"></div>
     </div>`
  ).join('');

  // Cinemeta search: /catalog/{type}/top/search={query}.json
  const encode = encodeURIComponent(q);
  const types = srchTab === 'all'    ? ['movie','series']
              : srchTab === 'movie'  ? ['movie']
              :                        ['series'];

  try {
    const results = await Promise.all(
      types.map(t => cmFetch(`catalog/${t}/top/search=${encode}.json`)
        .then(d => (d.metas || []).map(m => ({ ...m, _type: t })))
        .catch(() => []))
    );

    // Interleave movie + series results so they mix naturally
    const merged = [];
    const arrs = results;
    const maxLen = Math.max(...arrs.map(a => a.length));
    for (let i = 0; i < maxLen; i++) {
      arrs.forEach(a => { if (a[i]) merged.push(a[i]); });
    }

    if (!merged.length) {
      status.textContent = `No results for "${q}"`;
      grid.innerHTML = `
        <div class="srch-empty">
          
          <div class="srch-empty-title">No results for "${q}"</div>
          <div class="srch-empty-sub">Try a different title or check spelling</div>
        </div>`;
      return;
    }

    const typeLabel = srchTab === 'all' ? 'movies & series'
                    : srchTab === 'movie' ? 'movies' : 'series';
    status.textContent = `${merged.length} result${merged.length !== 1 ? 's' : ''} for "${q}"`;
    grid.innerHTML = merged.map(m => card(m, m._type || 'movie')).join('');
  } catch(e) {
    status.textContent = '';
    grid.innerHTML = `<div class="srch-empty">
      <div class="srch-empty-icon">⚠️</div>
      <div class="srch-empty-title">Search failed</div>
      <div class="srch-empty-sub">${e.message}</div>
    </div>`;
    status.textContent = '';
  }
}

// ── Background scan polling ───────────────────────────────────
// Fire-and-forget nudge after adds/scans. The server now prewarms new
// stubs on its own as they're created (see _prewarm_new_stub_worker), so
// this is no longer what makes prewarming happen — it just skips the
// few-second debounce when someone is sitting on the UI watching for it.
// Safe to call repeatedly: passes run one at a time behind a lock and
// each stub is re-checked before resolving, so overlapping calls converge
// rather than duplicating work.
function triggerPrewarmNow() {
  fetch('/api/prewarm-new-content/run', { method: 'POST' }).catch(() => {});
}

function pollScan(imdbId, title) {
  _bg_scans_ui.add(imdbId);
  let lastCount = 0;
  const iv = setInterval(async () => {
    try {
      const r = await fetch(`/api/scan/${imdbId}`);
      const d = await r.json();
      if (d.stubs !== lastCount) {
        lastCount = d.stubs;
        await syncStubs();
        await loadLib();
      }
      if (!d.scanning) {
        clearInterval(iv);
        _bg_scans_ui.delete(imdbId);
        toast(`"${title}" — ${d.stubs} stub${d.stubs!==1?'s':''} ready in Plex`, 'ok');
        await syncStubs();
        await loadLib();
        triggerPrewarmNow();   // resolve the episodes the scan just created, don't wait for the schedule
      }
    } catch { clearInterval(iv); _bg_scans_ui.delete(imdbId); }
  }, 4000);
}

// ── Toast ─────────────────────────────────────────────────────
function toast(msg, type='ok') {
  const el=document.createElement('div');
  el.className=`toast ${type}`;
  el.textContent=msg;
  document.body.appendChild(el);
  setTimeout(()=>el.remove(), 3500);
}

// ── Auth ─────────────────────────────────────────────────────
function copyLoginLink(url) {
  navigator.clipboard.writeText(url).then(() => {
    toast('Link copied', 'ok');
  }).catch(() => {
    toast('Could not copy — long-press the "Open Plex login" link above instead', 'er');
  });
}

function showLoginScreen() {
  document.getElementById('loginScreen').style.display = 'flex';
  document.querySelector('.nav').style.display = 'none';
  const badge = document.getElementById('userBadge');
  if (badge) badge.style.display = 'none';
  ['Home','Search','Calendar','Library','Config'].forEach(p => {
    const el = document.getElementById('p'+p);
    if (el) el.style.display = 'none';
  });
}

function hideLoginScreen() {
  document.getElementById('loginScreen').style.display = 'none';
  document.querySelector('.nav').style.display = 'flex';
}

function applyRoleGating() {
  const isAdmin = currentUser && currentUser.role === 'admin';
  const navLib = document.getElementById('navLibrary');
  const navCfg = document.getElementById('navConfig');
  if (navLib) navLib.style.display = isAdmin ? '' : 'none';
  if (navCfg) navCfg.style.display = isAdmin ? '' : 'none';
  // The backend enforces this independently (fail-closed allowlist in
  // _AuthMiddleware) — hiding the tabs here is purely so a non-admin
  // account never sees a confusing 403 by stumbling onto them, not the
  // actual security boundary.
  if (!isAdmin) {
    const activeTab = document.querySelector('.ni.on');
    const onRestricted = activeTab && (activeTab.textContent === 'Library' || activeTab.textContent === 'Config');
    if (onRestricted) {
      const homeBtn = document.querySelector('.nav .ni');
      if (homeBtn) nav('home', homeBtn);
    }
  }
}

function renderUserBadge() {
  if (!currentUser) return;
  const badge = document.getElementById('userBadge');
  const thumb = document.getElementById('userBadgeThumb');
  const initial = document.getElementById('userBadgeInitial');
  const menuName = document.getElementById('userMenuName');
  const role = document.getElementById('userMenuRole');
  badge.style.display = 'flex';
  menuName.textContent = currentUser.username || 'Account';
  role.textContent = currentUser.role === 'admin' ? 'Admin' : 'User';
  if (currentUser.thumb) {
    thumb.src = currentUser.thumb;
    thumb.style.display = 'block';
    initial.style.display = 'none';
  } else {
    thumb.style.display = 'none';
    initial.style.display = 'flex';
    initial.textContent = (currentUser.username || '?').charAt(0).toUpperCase();
  }
}

// The menu is a fixed-position sibling of .nav (see the markup above),
// so it needs its own position computed from the badge's live bounding
// rect every time it opens — it's not just "below the badge" via CSS
// the way a nested dropdown would be.
function positionUserMenu() {
  const badge = document.getElementById('userBadge');
  const menu = document.getElementById('userMenu');
  if (!badge || !menu) return;
  const rect = badge.getBoundingClientRect();
  menu.style.top = (rect.bottom + 10) + 'px';
  menu.style.right = (window.innerWidth - rect.right) + 'px';
}

function toggleUserMenu() {
  const menu = document.getElementById('userMenu');
  const opening = menu.style.display !== 'block';
  if (opening) {
    positionUserMenu();
    menu.style.display = 'block';
  } else {
    menu.style.display = 'none';
  }
}
// Reposition an already-open menu on resize/rotate, same reasoning as
// positionUserMenu() itself — the badge can move between breakpoints.
window.addEventListener('resize', () => {
  const menu = document.getElementById('userMenu');
  if (menu && menu.style.display === 'block') positionUserMenu();
});
document.addEventListener('click', e => {
  const badge = document.getElementById('userBadge');
  const menu = document.getElementById('userMenu');
  // Now that the menu is a sibling of the badge rather than a child of
  // it, an outside click has to be checked against both — otherwise a
  // tap inside the (now-detached) menu itself would incorrectly count
  // as "outside" and close it immediately.
  if (menu && badge && menu.style.display === 'block' &&
      !badge.contains(e.target) && !menu.contains(e.target)) {
    menu.style.display = 'none';
  }
});

let _loginPollTimer = null;
let _loginPollDeadline = 0;

async function startPlexLogin() {
  const btn = document.getElementById('plexLoginBtn');
  const statusEl = document.getElementById('loginStatus');
  const errEl = document.getElementById('loginError');
  const linkArea = document.getElementById('loginLinkArea');
  errEl.style.display = 'none';
  linkArea.innerHTML = '';
  btn.disabled = true;
  btn.textContent = 'Opening Plex…';

  // Opened here, synchronously, BEFORE the await below — this is what
  // actually matters for mobile Safari and other strict popup blockers:
  // a window.open() is only trusted as a direct response to the tap if
  // there's no async gap before it runs. Calling it AFTER an awaited
  // fetch (like the previous version of this function did) means the
  // browser no longer considers it part of the same user gesture, and
  // blocks it outright regardless of popup settings — which is exactly
  // what was happening. Its real destination gets set a moment later,
  // once the pin request resolves.
  const popup = window.open('about:blank', 'plexLogin', 'width=480,height=700');

  try {
    const r = await fetch('/api/auth/plex/start', { method: 'POST' });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Could not start login');

    let opened = false;
    if (popup && !popup.closed) {
      try { popup.location.href = d.auth_url; opened = true; } catch {}
    }

    statusEl.style.display = 'block';
    if (opened) {
      statusEl.textContent = 'Complete the login in the new window — this page will continue automatically once you do.';
    } else {
      // Even the synchronous-open trick doesn't get past every mobile
      // browser's popup blocker. Give a REAL tappable link (a genuine
      // user tap on an <a target="_blank"> is essentially never
      // blocked, unlike a script-driven window.open()) plus a copy
      // button, instead of a wall of raw unreadable/uncopyable URL text.
      statusEl.textContent = "Couldn't open a new window automatically — tap below to continue:";
      linkArea.innerHTML = `
        <a href="${d.auth_url}" target="_blank" rel="noopener"
           style="display:block;text-align:center;background:var(--acc);color:#000;font-weight:700;padding:14px;border-radius:12px;text-decoration:none;margin-top:14px;font-size:14px">
          Open Plex login
        </a>
        <button onclick="copyLoginLink('${d.auth_url}')"
           style="display:block;width:100%;text-align:center;background:var(--card2);color:var(--txt);font-weight:600;padding:11px;border-radius:12px;border:1px solid var(--bor2);margin-top:8px;cursor:pointer;font-family:var(--f);font-size:13px">
          Copy link instead
        </button>`;
    }
    btn.textContent = 'Waiting for Plex…';

    _loginPollDeadline = Date.now() + 5 * 60 * 1000;   // 5 minutes to complete login
    pollPlexLogin(d.pin_id);
  } catch (exc) {
    if (popup && !popup.closed) popup.close();
    errEl.style.display = 'block';
    errEl.textContent = exc.message || 'Could not start Plex login';
    btn.disabled = false;
    btn.textContent = 'Log in with Plex';
  }
}

async function pollPlexLogin(pinId) {
  if (Date.now() > _loginPollDeadline) {
    const btn = document.getElementById('plexLoginBtn');
    const statusEl = document.getElementById('loginStatus');
    const errEl = document.getElementById('loginError');
    statusEl.style.display = 'none';
    errEl.style.display = 'block';
    errEl.textContent = 'Login timed out — try again.';
    btn.disabled = false;
    btn.textContent = 'Log in with Plex';
    return;
  }

  try {
    const r = await fetch(`/api/auth/plex/poll/${pinId}`);
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || 'Login failed');

    if (d.status === 'ok') {
      currentUser = d.user;
      hideLoginScreen();
      applyRoleGating();
      renderUserBadge();
      const btn = document.getElementById('plexLoginBtn');
      btn.disabled = false;
      btn.textContent = 'Log in with Plex';
      document.getElementById('loginStatus').style.display = 'none';
      await syncStubs();
      await Promise.all([
        loadHero(),
        loadRow('rowM','catalog/movie/top.json','movie'),
        loadRow('rowS','catalog/series/top.json','series'),
      ]);
      setInterval(syncStubs, 5000);
      return;
    }
    // still waiting — keep polling
    _loginPollTimer = setTimeout(() => pollPlexLogin(pinId), 2000);
  } catch (exc) {
    const btn = document.getElementById('plexLoginBtn');
    const statusEl = document.getElementById('loginStatus');
    const errEl = document.getElementById('loginError');
    statusEl.style.display = 'none';
    errEl.style.display = 'block';
    errEl.textContent = exc.message || 'Could not verify login';
    btn.disabled = false;
    btn.textContent = 'Log in with Plex';
  }
}

async function logout() {
  if (_loginPollTimer) { clearTimeout(_loginPollTimer); _loginPollTimer = null; }
  try { await fetch('/api/auth/logout', { method: 'POST' }); } catch {}
  currentUser = null;
  document.getElementById('userMenu').style.display = 'none';
  showLoginScreen();
  document.getElementById('loginStatus').style.display = 'none';
  document.getElementById('loginError').style.display = 'none';
  document.getElementById('loginLinkArea').innerHTML = '';
  const btn = document.getElementById('plexLoginBtn');
  btn.disabled = false;
  btn.textContent = 'Log in with Plex';
}

// ── Init ─────────────────────────────────────────────────────
let currentUser = null;

async function checkAuthAndInit() {
  try {
    const r = await fetch('/api/auth/me');
    if (r.status !== 200) {
      showLoginScreen();
      return;
    }
    const d = await r.json();
    currentUser = d.user;
  } catch {
    showLoginScreen();
    return;
  }

  hideLoginScreen();
  applyRoleGating();
  renderUserBadge();

  await syncStubs();
  await Promise.all([
    loadHero(),
    loadRow('rowM','catalog/movie/top.json','movie'),
    loadRow('rowS','catalog/series/top.json','series'),
  ]);
  setInterval(syncStubs, 5000);
}
checkAuthAndInit();

// ── View All ───────────────────────────────────────────────────
// _rowCache stores items already fetched by loadRow keyed by cmPath
const _rowCache = {};

async function viewAll(title, cmPath, type) {
  // Open overlay immediately
  const ov = document.getElementById('vaOverlay');
  document.getElementById('vaTitle').textContent = title;
  document.getElementById('vaGrid').innerHTML = Array(20).fill(0).map(()=>
    `<div class="card" style="pointer-events:none">
       <div class="skel cposter"></div>
       <div class="skel cname" style="height:12px;margin-top:8px;width:80%"></div>
       <div class="skel cyear" style="height:11px;margin-top:5px;width:45%"></div>
     </div>`
  ).join('');
  ov.classList.add('open');
  ov.scrollTop = 0;

  // Fetch (or use cached) items
  let items = _rowCache[cmPath];
  if (!items) {
    try {
      const data = await cmFetch(cmPath);
      items = (data.metas || []);
      _rowCache[cmPath] = items;
    } catch(e) {
      document.getElementById('vaGrid').innerHTML =
        `<div style="color:var(--red);grid-column:1/-1;padding:20px;font-size:13px">Failed to load: ${e.message}</div>`;
      return;
    }
  }
  document.getElementById('vaGrid').innerHTML = items.map(m => card(m, type)).join('');
}

function closeViewAll() {
  document.getElementById('vaOverlay').classList.remove('open');
}

</script>

<!-- View All overlay -->
<div class="va-overlay" id="vaOverlay">
  <div class="va-inner">
    <div class="va-header">
      <button class="va-back" onclick="closeViewAll()">Back</button>
      <span class="va-title" id="vaTitle"></span>
    </div>
    <div class="va-grid" id="vaGrid"></div>
  </div>
</div>

</body>
</html>"""


@app.get("/", response_class=HTMLResponse)
async def ui():
    return HTMLResponse(UI_HTML)


# ---------------------------------------------------------------------------
# Config + test
# ---------------------------------------------------------------------------

@app.get("/api/config")
async def get_config():
    return {
        "aiostreams_url":  os.environ.get("AIOSTREAMS_URL", "http://localhost:3001"),
        "uuid_set":        bool(os.environ.get("AIOSTREAMS_UUID")),
        "password_set":    bool(os.environ.get("AIOSTREAMS_PASSWORD")),
        "library_root":    os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt"),
        "fuse": {
            "mountpoint":         os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt"),
            "block_mb":           os.environ.get("FUSE_BLOCK_MB", "8"),
            "cache_blocks":       os.environ.get("FUSE_CACHE_BLOCKS", "64"),
            "prefetch_ahead":     os.environ.get("FUSE_PREFETCH_AHEAD", "4"),
            "read_timeout":       os.environ.get("FUSE_READ_TIMEOUT", "15"),
            "max_inflight":       os.environ.get("FUSE_MAX_INFLIGHT", "12"),
            "pool_connections":   os.environ.get("FUSE_POOL_CONNECTIONS", "10"),
            "pool_maxsize":       os.environ.get("FUSE_POOL_MAXSIZE", "20"),
            "resolve_timeout":    os.environ.get("FUSE_RESOLVE_TIMEOUT", "15"),
        },
    }


@app.get("/api/settings")
async def get_settings():
    from gateway import settings as _settings
    return _settings.get_all()


@app.get("/api/ttl-status")
async def ttl_status():
    """
    What the Active file TTL is currently holding, broken down by
    library. Backs the coverage line under the TTL setting — the single
    TTL applies to every library, and this is what makes that visible
    rather than something you have to take on faith.
    """
    from gateway import settings as _settings
    active = _stubs.active_breakdown()
    return {
        "ttl_days":          _settings.get_effective_ttl_days(),
        "active_ttl_days":   _settings.ACTIVE_TTL_DAYS,
        "active_ttl_enabled": bool(_settings.get("active_ttl_enabled", True)),
        "active":       active,
        "active_total": sum(active.values()),
        "placeholders": sum(1 for s in _stubs.all() if s.state == StubState.PLACEHOLDER),
    }


class SettingsPatch(BaseModel):
    # active_ttl_days is intentionally absent — the active-file TTL is now
    # a fixed constant (gateway.settings.ACTIVE_TTL_DAYS), not something
    # the API can change. active_ttl_enabled is the only remaining knob.
    active_ttl_enabled: Optional[bool] = None
    preferred_language: Optional[str] = None
    preferred_audio:    Optional[list[str]] = None
    require_subtitles:  Optional[bool] = None
    exclude_words:      Optional[list[str]] = None
    min_4k_candidates:  Optional[int] = None
    prefer_season_packs: Optional[bool] = None
    pack_first_fill:            Optional[bool] = None
    pack_fill_require_cached:   Optional[bool] = None
    pack_fill_min_candidates:   Optional[int]  = None
    stable_stub_filenames:      Optional[bool] = None
    prewarm_skip_ttl_expired:   Optional[bool] = None
    allow_usenet:       Optional[bool] = None
    prewarm_enabled:        Optional[bool] = None
    prewarm_new_content_days: Optional[float] = None
    prewarm_interval_hours: Optional[float] = None
    prewarm_bulk_import_threshold: Optional[int] = None
    prewarm_retry_cooldown_hours:  Optional[float] = None
    min_size_gb:        Optional[float] = None
    max_size_gb:        Optional[float] = None
    auto_episodes_enabled:          Optional[bool] = None
    auto_episodes_interval_minutes: Optional[int] = None
    auto_episodes_retry_days:       Optional[float] = None
    dead_stub_max_errors:           Optional[int] = None
    aiostreams_max_concurrent:      Optional[int] = None
    aiostreams_min_interval_ms:     Optional[float] = None
    pending_movies_enabled:         Optional[bool] = None
    pending_movies_retry_days:      Optional[float] = None
    digital_release_delay_days:     Optional[float] = None


@app.post("/api/settings")
async def update_settings(patch: SettingsPatch):
    from gateway import settings as _settings
    data = {k: v for k, v in patch.dict().items() if v is not None}
    try:
        updated = _settings.update(data)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    logger.info("Settings updated: %s", data)
    return updated


@app.post("/api/auto-episodes/sweep-now")
async def trigger_auto_episode_sweep():
    """Manually run one auto-episode discovery sweep immediately, instead
    of waiting for the next scheduled interval. Runs even if
    auto_episodes_enabled is off, since an explicit manual trigger is a
    deliberate one-off action, not the recurring background behaviour the
    setting controls."""
    from gateway import auto_episodes as _auto_ep
    result = await _auto_ep.run_sweep(_stubs, _http, _query_episode, _yield_to_play_priority, force=True,
                                      fast_track_pack_fn=_fast_track_pack_season)
    logger.info("Manual auto-episode sweep: %s", result)
    return result


@app.get("/api/pending-movies")
async def list_pending_movies():
    from gateway import pending_movies as _pending_mv
    return {"items": _pending_mv.list_all()}


@app.delete("/api/pending-movies/{imdb_id}")
async def remove_pending_movie(imdb_id: str):
    from gateway import pending_movies as _pending_mv
    removed = _pending_mv.remove(imdb_id)
    if not removed:
        raise HTTPException(404, "Not in the pending list")
    return {"ok": True}


@app.post("/api/pending-movies/sweep-now")
async def trigger_pending_movies_sweep():
    """Manually retry every pending movie immediately, same deliberate
    one-off pattern as /api/auto-episodes/sweep-now."""
    from gateway import pending_movies as _pending_mv
    result = await _pending_mv.run_sweep(_query_movie, force=True, yield_fn=_yield_to_play_priority)
    logger.info("Manual pending-movie sweep: %s", result)
    return result


@app.get("/api/quality-unavailable")
async def list_quality_unavailable():
    """Everything confirmed to have no 4K available — see
    gateway/quality_unavailable.py. These are skipped by every automatic
    path (normal adds, background scan, auto-episode discovery, the
    pending-movies sweep) until manually cleared,
    either here or by a successful manual "Scan 4K"."""
    from gateway import quality_unavailable as _qu
    return {"items": _qu.list_all()}


@app.delete("/api/quality-unavailable/{key:path}")
async def clear_quality_unavailable(key: str):
    """Clears a 4K-unavailable mark without necessarily re-scanning right
    now — the item just becomes eligible for automatic 4K discovery
    again on whatever picks it up next (background scan, next
    check, etc). key is imdb_id for a movie, or imdb_id:season:episode
    for an episode — exactly what /api/quality-unavailable returns."""
    from gateway import quality_unavailable as _qu
    parts = key.split(":")
    imdb_id = parts[0]
    season  = int(parts[1]) if len(parts) > 1 else None
    episode = int(parts[2]) if len(parts) > 2 else None
    removed = _qu.unmark(imdb_id, season, episode)
    if not removed:
        raise HTTPException(404, "Not marked as 4K-unavailable")
    return {"ok": True}


@app.get("/api/wanted-seasons")
async def list_wanted_seasons():
    """Seasons registered via the Library modal's "New" button (or a
    direct season-scoped add) while they had zero aired episodes — see
    gateway/wanted_seasons.py. Picked up automatically by the
    auto-episode sweep once each one's first episode actually airs."""
    from gateway import wanted_seasons as _ws
    return {"items": _ws.list_all()}


@app.delete("/api/wanted-seasons/{imdb_id}/{season}")
async def clear_wanted_season(imdb_id: str, season: int):
    """Clears a wanted-season mark without waiting for it to air —
    just stops the auto-episode sweep from treating it as eligible."""
    from gateway import wanted_seasons as _ws
    removed = _ws.remove(imdb_id, season)
    if not removed:
        raise HTTPException(404, "Not marked as a wanted season")
    return {"ok": True}


class SearchUpcomingReq(BaseModel):
    title:   str = ""
    poster:  str = ""
    year:    Optional[int] = None
    seasons: Optional[list[int]] = None   # None/empty = every season Cinemeta knows about


@app.post("/api/series/{imdb_id}/search-upcoming")
async def search_upcoming_series(imdb_id: str, req: SearchUpcomingReq):
    """
    Manually search a tracked-but-not-yet-aired show right now, ignoring
    air dates.

    The automatic paths (auto-episode sweep, background scan)
    all filter to _is_aired() episodes first, which is correct for them —
    querying AIOStreams for something that doesn't exist yet is wasted
    budget. But it also meant an upcoming show was completely
    unsearchable by hand: the Library card for a tracked season offered
    only "stop tracking", and there was no way to say "the premiere is
    clearly out already, go look". Cinemeta air dates run stale or
    timezone-shifted often enough for simulcast and streaming-first shows
    that this needs to be possible.

    Only ever reached by an explicit click. Episodes that already have a
    stub are skipped, and anything that doesn't resolve is simply
    reported back — nothing is marked failed or given up on, and the
    normal automatic tracking continues untouched either way.
    """
    from gateway import wanted_seasons as _ws

    try:
        meta = await _cinemeta_cached("series", imdb_id)
    except Exception as exc:
        raise HTTPException(502, f"Could not fetch series metadata: {exc}")

    title = req.title or meta.get("name") or imdb_id
    year  = req.year or _extract_year(meta.get("year")) or _extract_year(meta.get("releaseInfo"))
    if not year:
        raise HTTPException(
            502,
            f"Could not determine release year for {imdb_id} — refusing to create stubs "
            "that would land in a differently-named folder."
        )

    # Explicit seasons win; otherwise fall back to whatever's currently
    # marked wanted for this show. Empty after both means "no scope given" —
    # search every season Cinemeta lists that isn't already stubbed.
    wanted = set(req.seasons or []) or set(_ws.seasons_for(imdb_id) or [])

    existing = {
        (s.season, s.episode) for s in _stubs.all()
        if s.imdb_id == imdb_id and s.season is not None and s.episode is not None
    }

    targets = [
        v for v in (meta.get("videos") or [])
        if v.get("number") is not None and v.get("season")
        and (not wanted or v.get("season") in wanted)
        and (v.get("season"), v.get("number")) not in existing
    ]
    # Earliest first: for a show that just premiered, E01 is both the most
    # likely to actually resolve and the one that can fast-track the rest
    # of the season if it lands on a pack.
    targets.sort(key=lambda v: (v.get("season"), v.get("number")))

    if not targets:
        return {"searched": 0, "stubbed": 0, "episodes": [], "detail": "Nothing left to search for this show."}

    sem = _asyncio.Semaphore(1)
    stubbed_eps, missing_eps = [], []
    for v in targets:
        await _yield_to_play_priority()
        label = f"S{v['season']:02d}E{v['number']:02d}"
        try:
            ok, _has4k, _pack = await _query_episode(imdb_id, title, year, req.poster or "", v, sem)
        except Exception as exc:
            logger.warning("Manual upcoming search failed for %s %s: %s", imdb_id, label, exc)
            ok = False
        (stubbed_eps if ok else missing_eps).append(label)

    logger.info("Manual upcoming search for %s (%s): %d/%d stubbed",
                title, imdb_id, len(stubbed_eps), len(targets))
    return {
        "searched": len(targets),
        "stubbed":  len(stubbed_eps),
        "episodes": stubbed_eps,
        "missing":  missing_eps,
    }


class SeasonWatchReq(BaseModel):
    title: str
    poster: str = ""
    year: Optional[int] = None


@app.post("/api/series/{imdb_id}/season-watch")
async def enable_season_watch(imdb_id: str, req: SeasonWatchReq):
    """Enables indefinite season-watch for a show — see
    gateway/season_watch.py. Once set, the auto-episode sweep
    automatically registers whatever the next season turns out to be,
    every cycle, for as long as this stays enabled — no repeat clicks
    needed for future gaps."""
    from gateway import season_watch as _sw
    _sw.enable(imdb_id, req.title, req.poster, req.year)
    return {"ok": True, "imdb_id": imdb_id}


@app.delete("/api/series/{imdb_id}/season-watch")
async def disable_season_watch(imdb_id: str):
    """Turns off indefinite season-watch for a show."""
    from gateway import season_watch as _sw
    removed = _sw.disable(imdb_id)
    if not removed:
        raise HTTPException(404, "Season-watch not enabled for this show")
    return {"ok": True}


@app.get("/api/series/{imdb_id}/season-watch")
async def get_season_watch(imdb_id: str):
    """Whether indefinite season-watch is currently enabled for a show."""
    from gateway import season_watch as _sw
    return {"enabled": _sw.is_enabled(imdb_id)}


@app.get("/api/season-watch")
async def list_season_watch():
    """Every show with indefinite season-watch enabled."""
    from gateway import season_watch as _sw
    return {"items": _sw.list_all()}


# ---------------------------------------------------------------------------
# Backup / restore — settings + library (stub metadata)
# ---------------------------------------------------------------------------

import datetime as _dt

BACKUP_FORMAT_VERSION = 2

@app.get("/api/backup")
async def create_backup():
    """
    Returns a single JSON bundle containing current settings, library, and
    connection config (AIOStreams URL/UUID/password, Plex URL/token).

    SECURITY NOTE: the connection config block contains real secrets
    (AIOSTREAMS_PASSWORD, PLEX_TOKEN) in plaintext. These can't be restored
    automatically into a running container — env vars are fixed at container
    start, so restore only displays them back for you to paste into
    docker-compose.yml yourself before a restart. Anyone with this file has
    full access to both services; store/share it accordingly.

    Deliberately excludes live resolve state (stream_url/headers/size) —
    a restored library comes back as fresh stubs that re-resolve on next
    play, since old CDN links would likely be expired anyway.
    """
    from gateway import settings as _settings
    bundle = {
        "format_version": BACKUP_FORMAT_VERSION,
        "created_at":     _dt.datetime.now(_dt.timezone.utc).isoformat(),
        "settings":       _settings.get_all(),
        "library":        _stubs.export_all(),
        "connection": {
            "aiostreams_url":      os.environ.get("AIOSTREAMS_URL", ""),
            "aiostreams_uuid":     os.environ.get("AIOSTREAMS_UUID", ""),
            "aiostreams_password": os.environ.get("AIOSTREAMS_PASSWORD", ""),
            "plex_url":            os.environ.get("PLEX_URL", ""),
            "plex_token":          os.environ.get("PLEX_TOKEN", ""),
        },
    }
    filename = f"aiogateway-backup-{_dt.datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    return JSONResponse(
        content=bundle,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


class RestoreReq(BaseModel):
    bundle:  dict
    replace: bool = False   # False = merge (skip existing), True = wipe library first


@app.post("/api/restore")
async def restore_backup(req: RestoreReq):
    """
    Restore settings and/or library from a previously downloaded backup
    bundle. Settings are always applied if present (last-write-wins on
    each key). Library stubs are imported as fresh PLACEHOLDERs — replace
    controls whether the current library is wiped first or merged into.
    """
    from gateway import settings as _settings
    bundle = req.bundle

    if not isinstance(bundle, dict) or "format_version" not in bundle:
        raise HTTPException(400, "Not a valid AIOGateway backup file")

    results = {"settings_restored": False, "library": None}

    settings_data = bundle.get("settings")
    if isinstance(settings_data, dict) and settings_data:
        try:
            _settings.update(settings_data)
            results["settings_restored"] = True
        except ValueError as exc:
            raise HTTPException(400, f"Invalid settings in backup: {exc}")

    library_data = bundle.get("library")
    if isinstance(library_data, list):
        import_result = await _stubs.import_all(library_data, replace=req.replace)
        results["library"] = import_result
        logger.info("Restore: %s", import_result)

    return results


@app.get("/api/test")
async def test_connection():
    return await _client.connection_test()


# ---------------------------------------------------------------------------
# Add media — movies and series (series only stubs aired episodes with streams)
# ---------------------------------------------------------------------------

import asyncio as _asyncio
from datetime import datetime, timezone as _tz

class AddReq(BaseModel):
    imdb_id:    str
    title:      str
    year:       Optional[int] = None
    media_type: str = "movie"
    season:     Optional[int] = None        # None = all seasons
    seasons:    Optional[list[int]] = None  # takes priority over `season` when set — multiple specific seasons in one call
    episode:    Optional[int] = None        # None = all episodes
    poster:     Optional[str] = None
    # force: search NOW, even for content that hasn't reached its release
    # date yet — a movie still inside the theatrical+digital_release_delay_days
    # window, or an episode Cinemeta says hasn't aired. Both of those gates
    # exist to stop the AUTOMATIC paths from wasting queries (and from
    # catching pre-digital cam/TS leaks) on things that can't plausibly have
    # a real release yet. They're the right default and stay the default,
    # but they're heuristics — release dates are wrong or late often enough
    # that "I know it's out, go look anyway" needs to be possible.
    #
    # Only ever set from an explicit user action (the Search buttons on the
    # Calendar and on tracked/upcoming cards). Every background sweep leaves
    # it False, so the automatic behaviour is completely unchanged.
    force:      bool = False


def _is_aired(released: Optional[str]) -> bool:
    """True if episode released date exists and is in the past."""
    if not released:
        return False
    try:
        dt = datetime.fromisoformat(released.replace("Z", "+00:00"))
        return dt <= datetime.now(_tz.utc)
    except Exception:
        return False


def _extract_year(value) -> Optional[int]:
    """
    Extract a clean 4-digit start year from a Cinemeta "year" or
    "releaseInfo" value, which can come back as a plain int (1994), a
    plain year string ("1994"), or — very commonly for SERIES, including
    ongoing ones — a range string like "2024-2026" or "2024-" (open-ended,
    still airing). Using such a value directly as a folder-name suffix
    previously produced folders literally named "(2024-)" instead of
    "(2024)". This always returns just the leading 4 digits, or None if
    nothing parseable is found.
    """
    if value is None:
        return None
    if isinstance(value, int):
        return value
    m = re.match(r"(\d{4})", str(value))
    return int(m.group(1)) if m else None


async def _movie_release_dt(imdb_id: str):
    """Returns the movie's Cinemeta `released` date as an aware datetime, or
    None if unknown/unparseable. Reuses the same cached Cinemeta fetch the
    calendar uses (see _cinemeta_cached), so this doesn't cost an extra
    request beyond what's already being fetched/cached elsewhere."""
    from datetime import datetime, timezone as _tz
    try:
        meta = await _cinemeta_cached("movie", imdb_id)
    except Exception as exc:
        logger.warning("Could not fetch release date for %s: %s", imdb_id, exc)
        return None
    released = meta.get("released")
    if not released:
        return None
    try:
        dt = datetime.fromisoformat(released.replace("Z", "+00:00"))
        if not dt.tzinfo:
            dt = dt.replace(tzinfo=_tz.utc)
        return dt
    except Exception:
        return None


async def _movie_searchable_at(imdb_id: str):
    """
    Returns the datetime a movie should first be searched at all — the
    Cinemeta theatrical release date plus digital_release_delay_days.
    None if the release date itself is unknown (in which case there's
    nothing to delay against, so callers should just search normally).

    This is a heuristic, not an exact digital-release check: there's no
    reliable free API for the actual digital/VOD date, which varies a lot
    by title and studio. The delay is the practical way to cut down on
    catching pre-digital cam/TS leaks before they'd normally show up on
    debrid — see the exclude_words setting for the complementary,
    per-result-filename version of this same problem.
    """
    from datetime import timedelta
    from gateway import settings as _settings
    released_dt = await _movie_release_dt(imdb_id)
    if not released_dt:
        return None
    delay_days = _settings.get("digital_release_delay_days", 0) or 0
    return released_dt + timedelta(days=delay_days) if delay_days else released_dt


async def _add_movie(req: AddReq) -> dict:
    # Don't even search yet if the movie hasn't reached its (theatrical +
    # digital delay) searchable date — anything that shows up this early
    # is essentially always a low-quality cam/TS/screener leak (see the
    # exclude_words setting), not a real encode. Skip the AIOStreams query
    # entirely and just track it as pending — same "keep checking
    # automatically" flow as a movie that's past that date but genuinely
    # has nothing available yet.
    #
    # req.force bypasses this — an explicit "search for it now" from the UI.
    # The gate is a date heuristic, and Cinemeta's theatrical date plus a
    # fixed delay is regularly wrong for a given title (early digital
    # windows, streaming-first releases, straight-to-VOD, plain bad
    # metadata). When the person can see it's actually out, refusing to
    # even look is the wrong answer, so the manual path skips straight to
    # the real query. Automatic paths never set force.
    from datetime import datetime, timezone as _tz
    searchable_at = await _movie_searchable_at(req.imdb_id)
    if searchable_at and searchable_at > datetime.now(_tz.utc) and not req.force:
        from gateway import pending_movies as _pending_mv
        await _pending_mv.add(req.imdb_id, req.title, req.year, req.poster or "")
        return {
            "media_id": req.imdb_id, "title": req.title, "media_type": "movie",
            "pending": True, "not_released_yet": True,
            "streams_found": 0, "has_4k": False,
            "episodes_with_streams": 0, "episodes_no_streams": 0,
            "episodes_future": 0, "episodes_skipped": 0,
            "stubs_created": [],
        }

    if req.force and searchable_at and searchable_at > datetime.now(_tz.utc):
        logger.info(
            "Manual search for %s (%s) overriding release-date gate "
            "(not searchable until %s)",
            req.title, req.imdb_id, searchable_at.date(),
        )

    item = MediaItem(
        id=req.imdb_id, imdb_id=req.imdb_id, title=req.title,
        year=req.year, media_type=MediaType.MOVIE,
    )
    item._poster = req.poster or ""
    item.streams = await _client.resolve_all(item)
    if not item.streams:
        # Not resolvable right now — most commonly nothing's cached at the
        # debrid backend yet (release date already checked above). Track it
        # instead of failing outright: the pending-movies sweep (gateway/
        # pending_movies.py) retries it automatically on the same schedule
        # as the auto-episode sweep until a stream shows up, the same
        # "keep checking" philosophy already used for not-yet-aired
        # episodes.
        from gateway import pending_movies as _pending_mv
        await _pending_mv.add(req.imdb_id, req.title, req.year, req.poster or "")
        return {
            "media_id": item.id, "title": item.title, "media_type": "movie",
            "pending": True, "streams_found": 0, "has_4k": False,
            "episodes_with_streams": 0, "episodes_no_streams": 0,
            "episodes_future": 0, "episodes_skipped": 0,
            "stubs_created": [],
        }
    stubs = await _stubs.create_stubs(item)
    return {
        "media_id": item.id, "title": item.title, "media_type": "movie",
        "pending": False,
        "streams_found": len(item.streams), "has_4k": item.has_4k,
        "episodes_with_streams": 0, "episodes_no_streams": 0,
        "episodes_future": 0, "episodes_skipped": 0,
        "stubs_created": [{"stub_id": s.stub_id, "quality": s.quality.value, "path": s.abs_path} for s in stubs],
    }


async def _query_movie(imdb_id: str, title: str, year, poster: str) -> bool:
    """Used by the pending-movies sweep to retry one tracked movie. Returns
    True if it now has a stub (streams were found), False otherwise."""
    from datetime import datetime, timezone as _tz
    searchable_at = await _movie_searchable_at(imdb_id)
    if searchable_at and searchable_at > datetime.now(_tz.utc):
        return False   # still inside the theatrical/digital delay window — don't waste a query, stays pending

    item = MediaItem(id=imdb_id, imdb_id=imdb_id, title=title, year=year, media_type=MediaType.MOVIE)
    item._poster = poster or ""
    try:
        item.streams = await _client.resolve_all(item)
    except Exception as exc:
        logger.warning("Pending movie resolve failed for %s: %s", imdb_id, exc)
        return False
    if not item.streams:
        return False
    await _stubs.create_stubs(item)
    return True


# Active background scans: imdb_id → asyncio.Task
_bg_scans: dict = {}

# ---------------------------------------------------------------------------
# Play priority: pause every background scan for the exact duration a
# Plex-triggered stub resolve is in flight, then let them resume — not a
# fixed courtesy sleep, a real pause-and-wait.
# ---------------------------------------------------------------------------
# Previously this was a single bool flag, set for the ENTIRE webhook
# handling call (including stop/pause events and the "already resolved"
# fast path that don't need any pause at all), and background loops only
# reacted to it with one fixed 1.5s sleep — which meant a scan could still
# be mid-query when Plex's playback request needed the exact same
# AIOStreams budget, and after the sleep the scan just carried on
# regardless of whether the real resolve had actually finished.
#
# This is a proper readers-writers pattern instead: a play-triggered
# resolve calls _play_priority_enter()/_exit() (via webhook/handler.py,
# scoped to just the _resolve() call, not the whole webhook), and every
# background loop (series scans, auto-episode discovery, pending-movie
# retries, migration) calls _yield_to_play_priority() before
# each per-item AIOStreams query — which now genuinely blocks until the
# resolve is done, not just once, and resumes immediately after rather
# than on a fixed timer. A counter (not a bool) handles the case where
# more than one play event resolves at once.
_play_priority_count = 0
_play_priority_clear = _asyncio.Event()
_play_priority_clear.set()   # nothing in flight yet — scans may proceed


def _play_priority_enter() -> None:
    global _play_priority_count
    _play_priority_count += 1
    _play_priority_clear.clear()


def _play_priority_exit() -> None:
    global _play_priority_count
    _play_priority_count = max(0, _play_priority_count - 1)
    if _play_priority_count == 0:
        _play_priority_clear.set()


async def _yield_to_play_priority():
    """Called by every background loop before each AIOStreams query. Blocks
    here — for as long as it takes, not a fixed sleep — while a
    play-triggered resolve is in flight, then returns immediately once
    it's done."""
    await _play_priority_clear.wait()


async def _query_episode(
    imdb_id: str, show_title: str, year, poster: str,
    v: dict, sem: "_asyncio.Semaphore"
) -> tuple:
    """
    Query AIOStreams for one episode. Returns (stubbed, has_4k, pack_info).

    pack_info is (pack_kind, pack_season) — detect_pack_type() run on
    whichever stream actually got used for the HD stub — ('episode', None)
    if not stubbed, or if the winning stream isn't pack-derived at all.
    Callers use this to fast-track the rest of a season when a pack shows
    up — see _fast_track_pack_season.
    """
    s_num = v.get("season")
    e_num = v.get("number")
    if s_num is None or e_num is None:
        return False, False, ('episode', None)

    # Don't re-stub an episode whose sources were confirmed dead recently.
    # This is the discovery half of the churn loop: prewarm removes the
    # dead stub, this path re-creates it minutes later, and the new stub
    # looks brand-new to everything. Checked against the SAME deterministic
    # stub_id the stub would get, so the record survives the removal.
    #
    # Only automatic callers reach this; manual add and manual search go
    # through create_stub_for_quality/create_stub_from_candidate, which
    # deliberately bypass this and clear the record.
    try:
        from gateway import stub_history as _hist
        from gateway.stub_manager import _stub_id as _sid_for
        media_id = f"{imdb_id}_s{s_num}e{e_num}"
        if _hist.suppressed(_sid_for(media_id, Quality.HD)):
            logger.debug(
                "Skipping %s S%02dE%02d — sources confirmed dead, still in backoff",
                imdb_id, s_num, e_num,
            )
            return False, False, ('episode', None)
    except Exception as exc:
        logger.debug("Could not check stub history for %s S%02dE%02d: %s",
                     imdb_id, s_num, e_num, exc)

    async with sem:
        item = MediaItem(
            id=f"{imdb_id}_s{s_num}e{e_num}", imdb_id=imdb_id,
            title=show_title, show_title=show_title, episode_title="",
            year=year, media_type=MediaType.SERIES,
            season=s_num, episode=e_num,
        )
        streams = []
        for attempt in range(1, 5):
            try:
                streams = await _client.resolve_all(item)
                break
            except Exception as exc:
                exc_str = str(exc)
                is_429  = "429" in exc_str
                if attempt < 4:
                    wait = (attempt * 5) if is_429 else (attempt * 2)
                    logger.warning(
                        "S%02dE%02d attempt %d/4 — %s — retrying in %ds",
                        s_num, e_num, attempt,
                        "rate limited (429)" if is_429 else exc_str[:60], wait
                    )
                    await _asyncio.sleep(wait)
                else:
                    logger.warning("S%02dE%02d all 4 attempts failed", s_num, e_num)
                    return False, False, ('episode', None)

        if not streams:
            return False, False, ('episode', None)

        item.streams = streams
        item._poster = poster
        await _stubs.create_stubs(item)
        q = " +4K" if item.has_4k else ""
        logger.info("S%02dE%02d: stubbed%s", s_num, e_num, q)

        winning = item.best_stream(Quality.HD)
        pack_info = winning.pack_type if winning else ('episode', None)

        return True, item.has_4k, pack_info


def _pack_covers_season(stream, season: int) -> bool:
    """True if this stream is a pack that should contain `season`."""
    kind, num = stream.pack_type
    return kind == "series" or (kind == "season" and num == season)


def _summarize_pack_coverage(streams: list, require_cached: bool = True) -> dict:
    """
    Count the pack candidates in a result list, split by quality tier and
    by which season they cover.

    Note this looks at EVERY candidate, not just whichever one happens to
    sort first — the previous pack detection only ever ran detect_pack_type
    on the single winning stream, so a season pack sitting two rows down
    was invisible and the show fell into the slow per-episode path.

    On `cached`: AIOStream.cached is Optional[bool], so it has three
    states, and the third one matters. True and False are claims from the
    addon; None means the addon never reported cache status at all, which
    is common. Excluding None along with False would mean pack filling
    silently never fires on such a setup. So require_cached only rejects
    an explicit False — consistent with the rest of the client, where
    cached is a ranking preference (best_stream, best_working_for_quality)
    and never a hard filter. The actual proof that a pack is usable is the
    live probe in _pack_first_fill, not this flag.
    """
    out = {"series_hd": 0, "series_uhd": 0, "season_hd": {}, "season_uhd": {}}
    for s in streams:
        if not s.url:
            continue
        if require_cached and s.cached is False:
            continue
        kind, num = s.pack_type
        if kind == "series":
            out["series_uhd" if s.is_4k else "series_hd"] += 1
        elif kind == "season" and num is not None:
            d = out["season_uhd" if s.is_4k else "season_hd"]
            d[num] = d.get(num, 0) + 1
    return out


async def _pack_first_fill(
    imdb_id: str, show_title: str, year, poster: str,
    candidates: list, skip_keys: set
) -> set:
    """
    Probe one sentinel episode per season and, wherever a season or series
    pack turns up, stub that entire season straight from the pack — no
    further AIOStreams queries.

    Why this is sound: create_stubs() builds PLACEHOLDER stubs. It does not
    store a stream URL; the URL is resolved lazily at play time by the Plex
    webhook. So a per-episode query during an add is only ever proving
    "this episode is obtainable" — nothing it fetches is kept. A cached
    season pack already proves that for every episode in the season, which
    means the query is redundant once the pack is in hand.

    That is the whole difference for an ended series. Before, a finished
    8-season show meant one AIOStreams query per episode (times up to 3
    retry passes) before the library looked complete. Now a complete-series
    pack settles the entire show in one query, and a show with per-season
    packs takes one query per season.

    Sizes are deliberately dropped from the streams handed to create_stubs:
    a pack's reported size is the whole season/series, and writing that into
    stream_size would have Plex reporting a 60GB episode. Leaving it unset
    falls back to the normal placeholder behaviour until the real stream is
    resolved on first play.

    Seasons where no pack is found are left completely untouched, so they
    fall through to the existing per-episode background scan.

    Returns the set of (season, episode) keys stubbed here.
    """
    from gateway import settings as _settings
    from dataclasses import replace as _dc_replace

    if not _settings.get("pack_first_fill", True):
        return set()

    require_cached = bool(_settings.get("pack_fill_require_cached", True))
    min_pack       = max(1, int(_settings.get("pack_fill_min_candidates", 1) or 1))
    min_4k         = max(1, int(_settings.get("min_4k_candidates", 2) or 1))

    by_season: dict = {}
    for v in candidates:
        sn = v.get("season")
        if sn and v.get("number") is not None:
            by_season.setdefault(sn, []).append(v)
    for eps in by_season.values():
        eps.sort(key=lambda v: v.get("number") or 0)

    if not by_season:
        return set()

    filled: set = set()
    covered_seasons: set = set()

    for sn in sorted(by_season):
        if sn in covered_seasons:
            continue

        sentinel = next(
            (v for v in by_season[sn] if (sn, v.get("number")) not in skip_keys),
            None,
        )
        if sentinel is None:
            continue

        await _yield_to_play_priority()
        probe = MediaItem(
            id=f"{imdb_id}_s{sn}e{sentinel.get('number')}", imdb_id=imdb_id,
            title=show_title, show_title=show_title, episode_title="",
            year=year, media_type=MediaType.SERIES,
            season=sn, episode=sentinel.get("number"),
        )
        try:
            streams = await _client.resolve_all(probe)
        except Exception as exc:
            logger.warning("Pack probe failed for %s S%02d: %s", imdb_id, sn, exc)
            continue

        if not streams:
            logger.info("Pack probe %s S%02d: no streams — leaving to the per-episode scan", imdb_id, sn)
            continue

        # The sentinel itself gets stubbed the normal way — its real stream
        # info (including a genuine per-file size) is right here.
        probe.streams = streams
        probe._poster = poster
        await _stubs.create_stubs(probe)
        filled.add((sn, sentinel.get("number")))

        cov = _summarize_pack_coverage(streams, require_cached)

        if cov["series_hd"] >= min_pack:
            targets = set(by_season)          # a series pack settles the whole show
            scope = "series"
        else:
            targets = {
                s for s, n in cov["season_hd"].items()
                if n >= min_pack and s in by_season
            }
            scope = "season"

        targets -= covered_seasons
        if not targets:
            continue

        for tgt in sorted(targets):
            pack_streams = [
                _dc_replace(s, size=None)
                for s in streams
                if _pack_covers_season(s, tgt)
            ]
            if not pack_streams:
                continue

            # Prove the pack before filling a whole season from it. The
            # `cached` flag is only the addon's claim — _probe_stream is
            # what the play path uses to establish a link is really alive
            # (status code, plus a Content-Range size sanity check that
            # catches debrid backends returning 200s for expired links
            # backed by tiny placeholder files). One probe per season is
            # cheap next to the per-episode queries this replaces, and
            # without it a single dead pack would stub an entire season
            # that fails on first play.
            probed_ok = False
            for cand in pack_streams[:3]:
                if not cand.url:
                    continue
                try:
                    if await _probe_stream(cand):
                        probed_ok = True
                        break
                except Exception:
                    continue
            if not probed_ok:
                logger.info(
                    "Pack fill: %s S%02d — pack candidates failed the live probe, "
                    "leaving this season to the per-episode scan", imdb_id, tgt
                )
                continue
            # 4K only rides along if the 4K PACKS themselves clear the same
            # threshold create_stubs applies. An HD season pack says nothing
            # about whether a 4K one exists.
            uhd_packs = sum(1 for s in pack_streams if s.is_4k)
            if uhd_packs < min_4k:
                pack_streams = [s for s in pack_streams if not s.is_4k]

            pending = [
                v for v in by_season.get(tgt, [])
                if (tgt, v.get("number")) not in skip_keys
                and (tgt, v.get("number")) not in filled
            ]
            if not pending:
                covered_seasons.add(tgt)
                continue

            items = []
            for v in pending:
                ep_item = MediaItem(
                    id=f"{imdb_id}_s{tgt}e{v.get('number')}", imdb_id=imdb_id,
                    title=show_title, show_title=show_title, episode_title="",
                    year=year, media_type=MediaType.SERIES,
                    season=tgt, episode=v.get("number"),
                )
                ep_item.streams = pack_streams
                ep_item._poster = poster
                items.append(ep_item)

            await _stubs.create_stubs_bulk(items)
            for v in pending:
                filled.add((tgt, v.get("number")))
            covered_seasons.add(tgt)

            logger.info(
                "Pack fill: %s S%02d — stubbed %d episode(s) from a %s pack found on S%02dE%02d "
                "(no per-episode queries)",
                imdb_id, tgt, len(pending), scope, sn, sentinel.get("number")
            )

        covered_seasons.add(sn)

    if filled:
        logger.info("Pack-first fill for %s: %d episode(s) stubbed across %d season(s)",
                    imdb_id, len(filled), len(covered_seasons))
    return filled


async def _fast_track_pack_season(
    imdb_id: str, show_title: str, year, poster: str,
    season: int, videos: list, already_stubbed: set
) -> set:
    """
    Called when an episode resolves via a season/series pack — since a
    pack, once debrid-cached, usually resolves the rest of its season
    quickly too (same underlying cached torrent, not a fresh scrape), this
    immediately tries every other aired-but-unstubbed episode in that
    season right away, instead of waiting through the slower multi-pass
    background scan built for genuinely hard-to-find content.

    Shared by every code path that can discover a pack: the add-flow's
    background scan (_scan_series_bg, below), the auto-episode sweep
    (gateway/auto_episodes.py, passed in as fast_track_pack_fn), and —
    for STUBS that already exist but haven't been played yet — the
    webhook's own play-triggered fast-track (webhook/handler.py's
    _fast_track_pack, a separate function since it resolves existing
    stubs directly rather than discovering new ones from a Cinemeta
    episode list).

    This does NOT skip any AIOStreams queries or guess at a pack's
    contents — every episode here is still resolved through the exact
    same safe per-episode query (imdb_id:season:episode) as always, so
    there's no risk of mislabeling an episode. "Verifying the pack" means
    checking, after each of those normal queries resolves, whether the
    winning stream is ALSO detected as part of the same season/series
    pack — confirming it's genuinely from the pack rather than just
    coincidentally available. Episodes that resolve via some other,
    non-pack source are still stubbed (a real stream is a real stream),
    just not counted as pack-confirmed.

    Every request still goes through the same global AIOStreams rate gate
    as everything else — this doesn't bypass that, it just skips the
    EXTRA local courtesy pacing/multi-pass retry structure _scan_series_bg
    normally adds on top, since a debrid-cached pack is expected to
    resolve quickly and doesn't need that same patience.

    Returns the set of (season, episode) keys stubbed here, so the caller
    can exclude them from any further processing.
    """
    targets = [
        v for v in videos
        if v.get("season") == season and v.get("number") is not None
        and _is_aired(v.get("released"))
        and (season, v.get("number")) not in already_stubbed
    ]
    if not targets:
        return set()

    logger.info(
        "Season %d of %s: pack detected — fast-tracking %d remaining episode(s)",
        season, imdb_id, len(targets)
    )

    sem = _asyncio.Semaphore(1)
    stubbed_keys = set()
    pack_confirmed = 0

    for v in targets:
        await _yield_to_play_priority()
        try:
            stubbed, _, pack_info = await _query_episode(imdb_id, show_title, year, poster, v, sem)
        except Exception as exc:
            logger.warning("Pack fast-track: S%02dE%02d failed: %s",
                          season, v.get("number"), exc)
            continue
        if stubbed:
            ep_num = v.get("number")
            stubbed_keys.add((season, ep_num))
            pack_kind, pack_season = pack_info
            if pack_kind in ("season", "series") and (pack_kind == "series" or pack_season == season):
                pack_confirmed += 1

    logger.info(
        "Season %d of %s: fast-track complete — %d/%d stubbed (%d confirmed from the pack)",
        season, imdb_id, len(stubbed_keys), len(targets), pack_confirmed
    )
    return stubbed_keys


async def _scan_series_bg(
    imdb_id: str, show_title: str, year, poster: str,
    candidates: list, skip_keys: set, known_pack_season: Optional[int] = None
) -> None:
    """
    Background task — sequential scan with 1s delay, repeated up to 3 passes
    until no new episodes are found. Each pass only retries episodes that
    previously returned no streams, ensuring all cached episodes are captured
    even when AIOStreams is inconsistent.

    known_pack_season: if the fast-path E01 query (in _add_series) already
    came back as a season/series pack, its season number is passed in here
    so the fast-track kicks in immediately, before pass 1 even starts,
    rather than waiting to organically rediscover the pack on whichever
    episode happens to run first in the normal loop.
    """
    # Track which episodes already have stubs
    def _already_stubbed(v: dict) -> bool:
        s = v.get("season"); e = v.get("number")
        return (s, e) in skip_keys or any(
            st.imdb_id == imdb_id and
            st.aiostreams_id == f"{imdb_id}:{s}:{e}"
            for st in _stubs.all()
        )

    remaining = [v for v in candidates if not _already_stubbed(v)]
    if not remaining:
        logger.info("BG scan %s: nothing to do", imdb_id)
        _bg_scans.pop(imdb_id, None)
        return

    logger.info("BG scan %s: %d episodes to check", imdb_id, len(remaining))
    sem        = _asyncio.Semaphore(1)
    total_found = 0
    pack_fast_tracked_seasons: set = set()   # avoid re-triggering fast-track for the same season twice

    if known_pack_season is not None:
        pack_fast_tracked_seasons.add(known_pack_season)
        already = set(skip_keys) | {
            (st.season, st.episode) for st in _stubs.all()
            if st.imdb_id == imdb_id and st.season is not None
        }
        fast_keys = await _fast_track_pack_season(
            imdb_id, show_title, year, poster, known_pack_season, candidates, already
        )
        total_found += len(fast_keys)
        remaining = [v for v in remaining if (v.get("season"), v.get("number")) not in fast_keys]
        if not remaining:
            logger.info("BG scan %s complete: %d total episodes stubbed (all via pack fast-track)",
                       imdb_id, total_found)
            _bg_scans.pop(imdb_id, None)
            return

    for pass_num in range(1, 4):   # up to 3 passes
        no_stream_this_pass = []
        found_this_pass     = 0
        skip_in_this_pass: set = set()   # (season, episode) keys handled mid-pass via fast-track

        logger.info("BG scan %s pass %d/%d: checking %d episodes",
                    imdb_id, pass_num, 3, len(remaining))

        for v in remaining:
            key = (v.get("season"), v.get("number"))
            if key in skip_in_this_pass:
                continue

            await _yield_to_play_priority()
            try:
                stubbed, _, pack_info = await _query_episode(
                    imdb_id, show_title, year, poster, v, sem
                )
                if stubbed:
                    found_this_pass += 1
                    total_found     += 1

                    pack_kind, _pack_season = pack_info
                    season = v.get("season")
                    if pack_kind in ("season", "series") and season not in pack_fast_tracked_seasons:
                        pack_fast_tracked_seasons.add(season)
                        already = {key} | {
                            (st.season, st.episode) for st in _stubs.all()
                            if st.imdb_id == imdb_id and st.season is not None
                        }
                        fast_keys = await _fast_track_pack_season(
                            imdb_id, show_title, year, poster, season, candidates, already
                        )
                        for fk in fast_keys:
                            skip_in_this_pass.add(fk)
                        found_this_pass += len(fast_keys)
                        total_found     += len(fast_keys)
                else:
                    no_stream_this_pass.append(v)
            except Exception as exc:
                logger.warning("BG scan episode error: %s", exc)
                no_stream_this_pass.append(v)
            await _asyncio.sleep(1.0)   # 1s between each query

        # Anything the mid-pass fast-track already picked up shouldn't be
        # retried again in the next pass.
        no_stream_this_pass = [
            v for v in no_stream_this_pass
            if (v.get("season"), v.get("number")) not in skip_in_this_pass
        ]

        logger.info("BG scan %s pass %d done: %d new stubs, %d still missing",
                    imdb_id, pass_num, found_this_pass, len(no_stream_this_pass))

        if not no_stream_this_pass:
            break   # everything found — no need for another pass

        remaining = no_stream_this_pass

        if pass_num < 3:
            # Wait a bit longer before the next pass
            wait = pass_num * 5
            logger.info("BG scan %s: waiting %ds before pass %d",
                        imdb_id, wait, pass_num + 1)
            await _asyncio.sleep(wait)

    if remaining:
        logger.info("BG scan %s: %d episode(s) had no streams after 3 passes: %s",
                    imdb_id, len(remaining),
                    [f"S{v.get('season'):02d}E{v.get('number'):02d}" for v in remaining])

    logger.info("BG scan %s complete: %d total episodes stubbed", imdb_id, total_found)
    _bg_scans.pop(imdb_id, None)


async def _add_series(req: AddReq) -> dict:
    """
    Fast path: query E01 immediately, return as soon as stub is created.
    Background task scans all remaining episodes concurrently.
    """
    try:
        async with _http.get(
            f"https://v3-cinemeta.strem.io/meta/series/{req.imdb_id}.json",
            headers={"User-Agent": "AIOGateway/0.3"},
            timeout=aiohttp.ClientTimeout(total=20),
        ) as resp:
            data = await resp.json(content_type=None)
    except Exception as exc:
        raise HTTPException(502, f"Cinemeta fetch failed: {exc}")

    meta   = data.get("meta") or {}
    videos = meta.get("videos") or []
    if not videos:
        raise HTTPException(404, f"No episode data found for {req.imdb_id}")

    poster     = req.poster or meta.get("poster") or ""
    show_title = req.title

    # Always resolve a year server-side rather than trusting the request to
    # supply one consistently. A missing/None year produces a folder name
    # with no "(Year)" suffix — and since the same show gets re-added via
    # several different UI flows (initial add, rescan, per-season request),
    # any one of them omitting the year fragments the show into two
    # differently-named folders for the same series.
    year = req.year
    if not year:
        # Cinemeta's meta endpoint returns "year" directly; releaseInfo is
        # a fallback for older/alternate response shapes. Both can be range
        # strings ("2024-2026" or open-ended "2024-") — _extract_year always
        # pulls just the leading 4 digits.
        year = _extract_year(meta.get("year")) or _extract_year(meta.get("releaseInfo"))
        if year:
            logger.info("Series %s: request had no year, using Cinemeta's %s",
                       req.imdb_id, year)

    if not year:
        # Cinemeta gave nothing usable — fall back to any existing stub for
        # this same show, so a rescan/season-request never accidentally
        # creates a second, differently-named folder just because this one
        # response happened to omit year data.
        existing = next((s for s in _stubs.all() if s.imdb_id == req.imdb_id and s.year), None)
        if existing:
            year = existing.year
            logger.info("Series %s: Cinemeta had no year, reusing %s from existing stub",
                       req.imdb_id, year)

    if not year:
        raise HTTPException(
            502,
            f"Could not determine release year for {req.imdb_id} — refusing to create "
            "stubs that would land in a differently-named folder than the rest of this "
            "show. Try again shortly."
        )

    aired_all  = [v for v in videos if _is_aired(v.get("released"))]
    future_cnt = len(videos) - len(aired_all)

    candidates = aired_all
    if req.seasons is not None:
        wanted_seasons = set(req.seasons)
        candidates = [v for v in candidates if v.get("season") in wanted_seasons]
    elif req.season is not None:
        candidates = [v for v in candidates if v.get("season") == req.season]
    if req.episode is not None:
        candidates = [v for v in candidates if v.get("number") == req.episode]

    if not candidates:
        # If this was a request for one specific season (not the whole
        # show, not a specific episode), register it as "wanted" so the
        # recurring auto-episode sweep picks it up automatically once its
        # first episode actually airs — instead of just failing here and
        # forgetting the request entirely, which is what happened before
        # this existed. Works whether Cinemeta already lists the season
        # with zero aired episodes (announced, dated), OR has literally
        # nothing for it at all yet (renewed but not yet scheduled — the
        # sweep re-fetches Cinemeta fresh every cycle, so it'll notice
        # the moment real episode data shows up either way). A specific-
        # episode request, or a whole-show request with genuinely nothing
        # aired anywhere, still just fails — there's no single season to
        # register in those cases.
        if req.season is not None and req.episode is None and req.seasons is None:
            season_videos = [v for v in videos if v.get("season") == req.season]
            from gateway import wanted_seasons as _ws
            _ws.add(req.imdb_id, req.season, show_title, poster, year)
            return {
                "media_id": req.imdb_id, "title": show_title, "media_type": "series",
                "wanted": True, "season": req.season,
                "streams_found": 0, "has_4k": False,
                "episodes_with_streams": 0, "episodes_no_streams": 0,
                "episodes_future": len(season_videos), "episodes_skipped": 0,
                "stubs_created": [],
            }
        raise HTTPException(404, f"No aired episodes found. {future_cnt} not yet released.")

    # Sort so E01 of lowest season is first
    candidates.sort(key=lambda v: (v.get("season") or 0, v.get("number") or 0))

    logger.info("Series %s '%s': fast E01 + bg scan %d eps",
                req.imdb_id, show_title, len(candidates))

    # Pack-first pass: one probe per season, and any season covered by a
    # season/series pack gets stubbed in full right here. For an ended
    # series this is usually the entire add — a complete-series pack means
    # a single AIOStreams query instead of one per episode. Skipped for a
    # single-episode request, where there's nothing to fill.
    pack_keys: set = set()
    if req.episode is None:
        try:
            pack_keys = await _pack_first_fill(
                req.imdb_id, show_title, year, poster, candidates, set()
            )
        except Exception as exc:
            logger.warning("Pack-first fill failed for %s (falling back to per-episode): %s",
                           req.imdb_id, exc)
            pack_keys = set()

    remaining = [
        v for v in candidates
        if (v.get("season"), v.get("number")) not in pack_keys
    ]

    if not remaining:
        # Whole request satisfied by packs — nothing left to scan.
        logger.info("Series %s '%s': fully stubbed from packs (%d episodes, no per-episode queries)",
                    req.imdb_id, show_title, len(pack_keys))
        return {
            "media_id":    req.imdb_id,
            "title":       req.title,
            "media_type":  "series",
            "streams_found": len(pack_keys),
            "has_4k":      False,
            "scanning":    False,
            "total_candidates": len(candidates),
            "pack_filled": len(pack_keys),
            "stubs_created": [],
        }

    # Query first remaining episode immediately
    sem_one = _asyncio.Semaphore(1)
    stubbed, has_4k, pack_info = await _query_episode(
        req.imdb_id, show_title, year, poster, remaining[0], sem_one
    )
    fast_key = (remaining[0].get("season"), remaining[0].get("number"))

    # Only skip E01 in the background scan if it was actually stubbed
    skip_keys = set(pack_keys) | ({fast_key} if stubbed else set())

    # If E01 came back as a season/series pack, seed the background scan
    # with that so it fast-tracks the rest of the season immediately
    # instead of waiting to organically rediscover the pack later.
    pack_kind, _pack_season = pack_info
    known_pack_season = fast_key[0] if (stubbed and pack_kind in ("season", "series")) else None

    # Cancel any existing scan and start a new one for all remaining episodes
    if req.imdb_id in _bg_scans:
        _bg_scans[req.imdb_id].cancel()
    task = _asyncio.create_task(
        _scan_series_bg(req.imdb_id, show_title, year, poster, candidates, skip_keys, known_pack_season)
    )
    _bg_scans[req.imdb_id] = task

    return {
        "media_id":    req.imdb_id,
        "title":       req.title,
        "media_type":  "series",
        "streams_found": (1 if stubbed else 0) + len(pack_keys),
        "has_4k":      has_4k,
        "scanning":    True,
        "total_candidates": len(candidates),
        "pack_filled": len(pack_keys),
        "stubs_created": [],
    }


@app.post("/api/add")
async def add_media(req: AddReq, request: Request):
    # Stamp the requester before doing the work: this is the only layer
    # with the session user in scope. Stub creation calls
    # library_items.touch() several frames further down and has no
    # request context, so attribution happens here or not at all.
    # Best-effort — failing to note who asked must never block the add.
    try:
        user = getattr(request.state, "user", None)
        if user and req.imdb_id:
            from gateway import library_items as _lib_items
            _lib_items.set_requester(
                req.imdb_id,
                user.get("username", ""),
                str(user.get("plex_user_id", "")),
                user.get("thumb", "") or "",
            )
    except Exception as exc:
        logger.warning("Could not record requester for %s: %s", req.imdb_id, exc)

    try:
        if req.media_type == "movie":
            return await _add_movie(req)
        else:
            return await _add_series(req)
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Add failed: %s", exc)
        raise HTTPException(502, str(exc))

# ---------------------------------------------------------------------------
# Migrate (Radarr/Sonarr)
# ---------------------------------------------------------------------------

from gateway import migrate_client as _migrate

_migrate_jobs: dict[str, dict] = {}          # job_id → progress state, see start_migration()
_migrate_tasks: dict[str, "asyncio.Task"] = {}   # job_id → the running task, so cancel can actually interrupt it

# One Radarr/Sonarr library snapshot per service, shared between "Load
# library" (preview) and "Start migration" (run) so a migration only ever
# costs Radarr/Sonarr a single /api/v3/movie or /api/v3/series call — not
# one for the preview and another when the run kicks off, which is what
# was happening before this cache existed. Cleared once the migration job
# that used it finishes, so the next "Load library" click always gets a
# fresh read rather than serving stale data indefinitely.
_migrate_cache: dict[str, list[dict]] = {}
_MIGRATE_CACHE_MAX_AGE = 3600   # safety net: don't serve a snapshot older than this even mid-session
_migrate_cache_fetched_at: dict[str, float] = {}


async def _get_migrate_items(service: str, url: str, key: str) -> list[dict]:
    """Returns this service's movie/series list, fetching from Radarr/Sonarr
    only if nothing cached (or the cache is stale). Callers get their own
    deep copy so annotating it (e.g. in_library flags) never corrupts the
    shared cache for the next caller."""
    cached = _migrate_cache.get(service)
    fetched_at = _migrate_cache_fetched_at.get(service, 0)
    if cached is not None and (time.time() - fetched_at) < _MIGRATE_CACHE_MAX_AGE:
        return copy.deepcopy(cached)

    if service == "radarr":
        items = await _migrate.fetch_radarr_movies(url, key)
    else:
        items = await _migrate.fetch_sonarr_series(url, key)

    _migrate_cache[service] = items
    _migrate_cache_fetched_at[service] = time.time()
    return copy.deepcopy(items)


def _clear_migrate_cache(service: str) -> None:
    _migrate_cache.pop(service, None)
    _migrate_cache_fetched_at.pop(service, None)


def _migrate_service_settings(service: str) -> tuple[str, str]:
    from gateway import settings as _settings
    s = _settings.get_all()
    return s.get(f"{service}_url", ""), s.get(f"{service}_api_key", "")


class MigrateSettingsReq(BaseModel):
    service: str                       # "radarr" | "sonarr"
    url:     str
    api_key: Optional[str] = None      # omitted/blank keeps whatever key is already saved


@app.get("/api/migrate/settings")
async def get_migrate_settings():
    from gateway import settings as _settings
    s = _settings.get_all()
    return {
        "radarr_url":        s.get("radarr_url", ""),
        "radarr_configured": bool(s.get("radarr_api_key")),
        "sonarr_url":        s.get("sonarr_url", ""),
        "sonarr_configured": bool(s.get("sonarr_api_key")),
    }


@app.post("/api/migrate/settings")
async def save_migrate_settings(req: MigrateSettingsReq):
    from gateway import settings as _settings
    if req.service not in ("radarr", "sonarr"):
        raise HTTPException(400, "service must be 'radarr' or 'sonarr'")
    patch = {f"{req.service}_url": req.url}
    if req.api_key:
        patch[f"{req.service}_api_key"] = req.api_key
    try:
        _settings.update(patch)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    _clear_migrate_cache(req.service)
    return {"ok": True}


class MigrateTestReq(BaseModel):
    service: str


@app.post("/api/migrate/test")
async def test_migrate_connection(req: MigrateTestReq):
    if req.service not in ("radarr", "sonarr"):
        raise HTTPException(400, "service must be 'radarr' or 'sonarr'")
    url, key = _migrate_service_settings(req.service)
    if not url or not key:
        raise HTTPException(400, f"Set the {req.service.title()} URL and API key first")
    try:
        return await _migrate.test_connection(url, key, req.service)
    except _migrate.MigrateAPIError as exc:
        raise HTTPException(502, str(exc))


@app.get("/api/migrate/preview")
async def preview_migrate(service: str):
    if service not in ("radarr", "sonarr"):
        raise HTTPException(400, "service must be 'radarr' or 'sonarr'")
    url, key = _migrate_service_settings(service)
    if not url or not key:
        raise HTTPException(400, f"Set the {service.title()} URL and API key first")

    try:
        items = await _get_migrate_items(service, url, key)
        if service == "radarr":
            have = {s.imdb_id for s in _stubs.all() if s.media_type == MediaType.MOVIE}
            for it in items:
                it["in_library"] = it["imdb_id"] in have
        else:
            have_seasons: dict[str, set] = {}
            for s in _stubs.all():
                if s.media_type == MediaType.SERIES and s.season is not None:
                    have_seasons.setdefault(s.imdb_id, set()).add(s.season)
            for it in items:
                already = have_seasons.get(it["imdb_id"], set())
                for season in it["seasons"]:
                    season["in_library"] = season["season_number"] in already
                it["in_library"] = all(sn["in_library"] for sn in it["seasons"])
    except _migrate.MigrateAPIError as exc:
        raise HTTPException(502, str(exc))

    return {"service": service, "items": items}


class MigrateRunReq(BaseModel):
    service:       str
    imdb_ids:      Optional[list[str]] = None   # None = migrate everything found
    skip_existing: bool = True


_MIGRATE_CONCURRENCY = 3   # AIOStreams requests allowed in flight at once during migration


async def _add_with_429_retry(kind: str, req: "AddReq", job: dict, label: str):
    """
    Bulk migration fires far more AIOStreams requests than the normal
    one-at-a-time "Add to Plex" click ever does, so it's much more likely
    to outrun AIOStreams' own rate limit — as seen in practice, a large
    library migration can 429 on nearly every item. Retry a 429 a few
    times with real backoff before giving up on that item; anything else
    (404/no results, etc.) is passed straight through to the caller —
    see _add_with_retry, which handles that case separately.
    """
    for attempt, wait in enumerate((0, 5, 15, 30, 60)):
        if wait:
            job["errors_transient"] = job.get("errors_transient", 0) + 1
            logger.warning("[migrate] %s: rate limited, retrying in %ds (attempt %d/5)",
                           label, wait, attempt + 1)
            await asyncio.sleep(wait)
        try:
            if kind == "movie":
                return await _add_movie(req)
            return await _add_series(req)
        except Exception as exc:
            is_429 = "429" in str(exc) or "Too Many Requests" in str(exc)
            if not is_429 or attempt == 4:
                raise



async def _run_migration(job_id: str, service: str, imdb_ids: Optional[list], skip_existing: bool):
    job = _migrate_jobs[job_id]
    try:
        url, key = _migrate_service_settings(service)
        try:
            items = await _get_migrate_items(service, url, key)
        except _migrate.MigrateAPIError as exc:
            job["status"] = "error"
            job["errors"].append(str(exc))
            return

        if imdb_ids is not None:
            wanted = set(imdb_ids)
            items = [it for it in items if it["imdb_id"] in wanted]

        have_movie = {s.imdb_id for s in _stubs.all() if s.media_type == MediaType.MOVIE}
        have_seasons: dict[str, set] = {}
        for s in _stubs.all():
            if s.media_type == MediaType.SERIES and s.season is not None:
                have_seasons.setdefault(s.imdb_id, set()).add(s.season)

        # ONE work item per movie, and — importantly — ONE work item per
        # series covering every season Sonarr has that isn't already
        # stubbed, not one item per season. _add_series only synchronously
        # resolves the first episode of the earliest requested season and
        # hands the rest to a background scan; batching every wanted
        # season into a single call means one fast resolve gets the whole
        # show moving, instead of the previous approach of calling
        # _add_series once per season and having to block for up to 15
        # minutes between each so the next season's call didn't cancel the
        # previous one's still-running background scan (_bg_scans is keyed
        # per imdb_id — two overlapping calls for the SAME show step on
        # each other, but one call already covering every season sidesteps
        # that entirely).
        work = []
        if service == "radarr":
            for it in items:
                if skip_existing and it["imdb_id"] in have_movie:
                    continue
                work.append(("movie", it, None))
        else:
            for it in items:
                already = have_seasons.get(it["imdb_id"], set())
                wanted_seasons = [
                    s2["season_number"] for s2 in it["seasons"]
                    if not (skip_existing and s2["season_number"] in already)
                ]
                if wanted_seasons:
                    work.append(("series", it, wanted_seasons))

        job["total"]  = len(work)
        job["status"] = "running"

        # Bounded concurrency instead of one item at a time with a fixed
        # delay between each — the 429 retry above already backs off
        # reactively when AIOStreams actually asks us to slow down, so a
        # small worker pool gets real throughput on the common case
        # (no rate limiting) while still recovering cleanly on the
        # uncommon case (it does get rate limited).
        sem = asyncio.Semaphore(_MIGRATE_CONCURRENCY)
        in_flight: dict[int, str] = {}

        def _update_current_title():
            job["current_title"] = " · ".join(in_flight.values()) if in_flight else ""

        async def _run_one(idx: int, kind: str, it: dict, seasons_or_none):
            label = (
                it["title"] if kind == "movie"
                else f"{it['title']} ({len(seasons_or_none)} season{'s' if len(seasons_or_none) != 1 else ''})"
            )
            async with sem:
                in_flight[idx] = label
                _update_current_title()
                await _yield_to_play_priority()
                try:
                    req = AddReq(
                        imdb_id=it["imdb_id"], title=it["title"], year=it.get("year"),
                        media_type=kind, poster=it.get("poster"),
                        seasons=seasons_or_none if kind == "series" else None,
                    )
                    result = await _add_with_429_retry(kind, req, job, label)
                    if isinstance(result, dict) and result.get("pending"):
                        # Not resolvable right now (commonly not released
                        # yet) — _add_movie already queued it in the
                        # pending-movies tracker rather than failing, so
                        # this isn't an error, just worth surfacing as
                        # informational.
                        job["pending_count"] = job.get("pending_count", 0) + 1
                except HTTPException as exc:
                    job["errors"].append(f"{label}: {exc.detail}")
                except Exception as exc:
                    job["errors"].append(f"{label}: {exc}")
                finally:
                    in_flight.pop(idx, None)
                    _update_current_title()
                    job["done"] += 1

        await asyncio.gather(*[
            _run_one(idx, kind, it, seasons_or_none)
            for idx, (kind, it, seasons_or_none) in enumerate(work)
        ])

        if job["status"] == "running":
            job["status"] = "done"
    except asyncio.CancelledError:
        # Task.cancel() (see cancel_migration below) raises this inside
        # whatever await was actually in flight at the moment — e.g. mid
        # AIOStreams request — which is what makes Cancel stop immediately
        # instead of only taking effect once the current item finishes.
        # Cancelling the task that's awaiting asyncio.gather() propagates
        # into every in-flight _run_one() call too, so nothing keeps
        # running in the background after cancel.
        job["status"] = "cancelled"
    finally:
        job["finished"]      = True
        job["current_title"] = ""
        _migrate_tasks.pop(job_id, None)
        _clear_migrate_cache(service)


@app.post("/api/migrate/run")
async def start_migration(req: MigrateRunReq):
    if req.service not in ("radarr", "sonarr"):
        raise HTTPException(400, "service must be 'radarr' or 'sonarr'")
    url, key = _migrate_service_settings(req.service)
    if not url or not key:
        raise HTTPException(400, f"Set the {req.service.title()} URL and API key first")

    job_id = uuid.uuid4().hex[:12]
    _migrate_jobs[job_id] = {
        "job_id": job_id, "service": req.service,
        "total": 0, "done": 0, "current_title": "",
        "status": "starting", "finished": False,
        "cancel_requested": False, "errors": [],
    }
    task = asyncio.create_task(_run_migration(job_id, req.service, req.imdb_ids, req.skip_existing))
    _migrate_tasks[job_id] = task
    return {"job_id": job_id}


@app.get("/api/migrate/status/{job_id}")
async def migrate_status(job_id: str):
    job = _migrate_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    return job


@app.post("/api/migrate/cancel/{job_id}")
async def cancel_migration(job_id: str):
    job = _migrate_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    job["cancel_requested"] = True
    task = _migrate_tasks.get(job_id)
    if task and not task.done():
        task.cancel()   # interrupts the in-flight await immediately, see _run_migration
    return {"ok": True}


# ---------------------------------------------------------------------------
# Stubs
# ---------------------------------------------------------------------------

@app.get("/api/scan/{imdb_id}")
async def scan_status(imdb_id: str):
    running = imdb_id in _bg_scans and not _bg_scans[imdb_id].done()
    count   = sum(1 for s in _stubs.all() if s.imdb_id == imdb_id)
    return {"imdb_id": imdb_id, "scanning": running, "stubs": count}


@app.get("/api/series/{imdb_id}/episodes")
async def series_episodes(imdb_id: str):
    """Full aired episode list from Cinemeta with stub status."""
    import re as _re
    try:
        async with _http.get(
            f"https://v3-cinemeta.strem.io/meta/series/{imdb_id}.json",
            headers={"User-Agent": "AIOGateway/0.3"},
            timeout=aiohttp.ClientTimeout(total=15),
        ) as resp:
            data = await resp.json(content_type=None)
    except Exception as exc:
        raise HTTPException(502, f"Cinemeta fetch failed: {exc}")

    videos = (data.get("meta") or {}).get("videos") or []

    # Build stubbed sets from aiostreams_id pattern "imdb:season:episode"
    stubbed_hd, stubbed_4k = {}, {}
    for s in _stubs.all():
        if s.imdb_id != imdb_id:
            continue
        m = _re.search(r':(\d+):(\d+)$', s.aiostreams_id)
        if m:
            key = (int(m.group(1)), int(m.group(2)))
            (stubbed_4k if s.quality == Quality.UHD else stubbed_hd)[key] = s.stub_id

    episodes = []
    for v in videos:
        sn = v.get("season"); ep = v.get("number")
        if sn is None or ep is None or sn == 0:
            continue
        key = (sn, ep)
        episodes.append({
            "season":  sn, "episode": ep,
            "name":    v.get("name") or f"S{sn:02d}E{ep:02d}",
            "aired":   _is_aired(v.get("released")),
            "has_hd":  key in stubbed_hd,
            "has_4k":  key in stubbed_4k,
            "hd_stub_id":  stubbed_hd.get(key),
            "uhd_stub_id": stubbed_4k.get(key),
        })
    return {
        "imdb_id":  imdb_id,
        "episodes": episodes,
        "scanning": imdb_id in _bg_scans and not _bg_scans[imdb_id].done(),
        # Cinemeta's series status — "Ended"/"Canceled" vs "Continuing"/
        # "In Production". Used to disable the Library modal's "New"
        # button for a show that will never air another season, rather
        # than leaving it enabled (or worse, letting it register a
        # wanted-season that can never resolve) for something already
        # confirmed over.
        "status": (data.get("meta") or {}).get("status"),
    }


@app.post("/api/series/{imdb_id}/episode/{season}/{episode}")
async def add_single_episode(imdb_id: str, season: int, episode: int, req: AddReq):
    """Search for and stub a single missing episode."""
    year = req.year
    if not year:
        # First fallback: reuse the year from any existing stub of this same
        # show, if one exists — avoids a network round-trip and is exactly
        # consistent with whatever folder name is already in use on disk.
        existing = next((s for s in _stubs.all() if s.imdb_id == imdb_id and s.year), None)
        if existing:
            year = existing.year
            logger.info("Episode S%02dE%02d (%s): reusing year %s from existing stub",
                       season, episode, imdb_id, year)

    if not year:
        # Second fallback: fetch from Cinemeta directly.
        try:
            async with _http.get(
                f"https://v3-cinemeta.strem.io/meta/series/{imdb_id}.json",
                headers={"User-Agent": "AIOGateway/0.3"},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                cm_meta = (await resp.json(content_type=None)).get("meta") or {}
            year = _extract_year(cm_meta.get("year")) or _extract_year(cm_meta.get("releaseInfo"))
            if year:
                logger.info("Episode S%02dE%02d (%s): request had no year, using Cinemeta's %s",
                           season, episode, imdb_id, year)
        except Exception as exc:
            logger.warning("Could not fetch fallback year from Cinemeta for %s: %s", imdb_id, exc)

    if not year:
        # Both fallbacks failed (network error + no existing stub to copy
        # from). Refuse rather than silently creating a year-less stub that
        # would fragment the show into a second, differently-named folder —
        # the caller can retry once Cinemeta is reachable again.
        raise HTTPException(
            502,
            f"Could not determine release year for {imdb_id} (Cinemeta unreachable and "
            "no existing stub to infer it from) — refusing to create a stub that would "
            "land in a differently-named folder. Try again shortly."
        )

    # Verify this specific episode has actually aired before ever touching
    # AIOStreams — every other add/scan path in the app (requestSeason,
    # the background scan and auto-episode discovery's
    # phase, pack fast-track) already filters to _is_aired() episodes
    # before calling _query_episode; this endpoint was the one gap, since
    # it resolves a single specific (season, episode) directly rather than
    # iterating a pre-filtered list. A not-yet-aired episode should never
    # get a stub automatically — anything that shows up for one this early
    # would usually be a mismatched or bogus result, not the real thing.
    #
    # req.force overrides this for an explicit manual search. Cinemeta air
    # dates are frequently stale or wrong by a timezone for simulcast and
    # streaming-first shows, and an episode that's demonstrably out
    # shouldn't be unsearchable because the metadata hasn't caught up. The
    # override only skips the DATE check — the resolved result still goes
    # through the same candidate filtering, size bounds, exclude_words and
    # live probing as any other search, so a bogus early result is still
    # rejected on its merits rather than on its date.
    try:
        meta = await _cinemeta_cached("series", imdb_id)
        target = next(
            (v for v in (meta.get("videos") or [])
             if v.get("season") == season and v.get("number") == episode),
            None
        )
        if target is not None and not _is_aired(target.get("released")):
            if not req.force:
                raise HTTPException(
                    400,
                    f"S{season:02d}E{episode:02d} hasn't aired yet "
                    f"({target.get('released', 'no date available')}) — refusing to search for it."
                )
            logger.info(
                "Manual search for %s S%02dE%02d overriding air-date gate (air date: %s)",
                imdb_id, season, episode, target.get("released", "unknown"),
            )
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("Could not verify air date for %s S%02dE%02d, proceeding anyway: %s",
                       imdb_id, season, episode, exc)

    sem = _asyncio.Semaphore(1)
    v = {"season": season, "number": episode}
    stubbed, has_4k, pack_info = await _query_episode(
        imdb_id, req.title, year, req.poster or "", v, sem
    )
    if not stubbed:
        raise HTTPException(404, f"No streams found for S{season:02d}E{episode:02d}")

    # If this single-episode search happened to land on a season/series
    # pack, opportunistically fast-track the rest of that season in the
    # background — same reasoning as the fast-path E01 case, just
    # triggered from a manual search instead. Doesn't block
    # this response; runs as a detached task.
    pack_kind, _pack_season = pack_info
    if pack_kind in ("season", "series"):
        try:
            meta = await _cinemeta_cached("series", imdb_id)
            videos = meta.get("videos") or []
            already = {(season, episode)} | {
                (st.season, st.episode) for st in _stubs.all()
                if st.imdb_id == imdb_id and st.season is not None
            }
            _asyncio.create_task(_fast_track_pack_season(
                imdb_id, req.title, year, req.poster or "", season, videos, already
            ))
        except Exception as exc:
            logger.warning("Could not kick off pack fast-track for %s: %s", imdb_id, exc)

    return {"stubbed": True, "has_4k": has_4k, "season": season, "episode": episode}


@app.get("/api/stubs")
async def list_stubs():
    all_s = _stubs.all()
    return {"count": len(all_s), "stubs": [
        {"stub_id": s.stub_id, "media_id": s.media_id, "title": s.title,
         "quality": s.quality.value, "state": s.state.value, "path": s.abs_path,
         "poster": getattr(s, "_poster", ""),
         "media_type": s.aiostreams_type,
         "year": s.year,
         "stream_url": (s.stream_url[:80]+"…") if s.stream_url else None}
        for s in all_s
    ]}


@app.get("/api/stubs/{stub_id}")
async def get_stub(stub_id: str):
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Not found")
    return {"stub_id": s.stub_id, "media_id": s.media_id, "title": s.title,
            "quality": s.quality.value, "state": s.state.value, "path": s.abs_path,
            "imdb_id": s.imdb_id, "aiostreams_id": s.aiostreams_id,
            "stream_url": s.stream_url, "created_at": s.created_at, "resolved_at": s.resolved_at}


# ---------------------------------------------------------------------------
# Calendar — upcoming and recent releases for tracked content
# ---------------------------------------------------------------------------


# Cinemeta cache for the calendar. Two things make this meaningfully
# faster than a plain short-lived in-memory cache:
#
# 1. Persisted to disk, so a restart doesn't throw away everything and
#    force a full cold re-fetch of every tracked title on the next load —
#    which, for a library with hundreds/thousands of tracked titles (e.g.
#    after a large Radarr/Sonarr migration), was the actual source of
#    "still slow" even with the concurrent-fetch fix from before.
#
# 2. Adaptive TTL instead of one fixed short window: a movie released
#    years ago, or a series with no upcoming/recently-aired episodes, is
#    essentially static — Cinemeta's data for it isn't going to change
#    meaningfully, so it's cached for days. Anything upcoming or recently
#    active still refreshes on the old short window, since that's exactly
#    the content whose air/release dates can actually change. Since most
#    of a large tracked library is old, already-released content, this is
#    the change that actually matters at scale — it means most calendar
#    loads do close to zero Cinemeta calls at all, not just fewer.
_calendar_meta_cache: dict[str, tuple] = {}   # "{kind}:{imdb_id}" -> (fetched_at, ttl_seconds, meta)
_CALENDAR_CACHE_SHORT_TTL = 600          # upcoming/recently-active — refresh often
_CALENDAR_CACHE_MID_TTL   = 6 * 3600     # ongoing series between seasons — see below
_CALENDAR_CACHE_LONG_TTL  = 7 * 86400    # long-settled — essentially static
_CALENDAR_CACHE_EMPTY_TTL = 300          # failed/empty fetch — retry soon, never cache a gap for days


def _calendar_cache_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_calendar_cache.json"


_calendar_cache_loaded = False


def _load_calendar_cache() -> None:
    global _calendar_meta_cache, _calendar_cache_loaded
    if _calendar_cache_loaded:
        return
    path = _calendar_cache_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text())
            _calendar_meta_cache = {k: tuple(v) for k, v in raw.items()}
            logger.info("Loaded %d cached calendar title(s) from %s", len(_calendar_meta_cache), path)
    except Exception as exc:
        logger.warning("Could not load calendar cache from %s: %s", path, exc)
        _calendar_meta_cache = {}
    _calendar_cache_loaded = True


def _persist_calendar_cache() -> None:
    path = _calendar_cache_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(_calendar_meta_cache))
    except Exception as exc:
        logger.warning("Could not persist calendar cache to %s: %s", path, exc)


def _calendar_cache_ttl(kind: str, meta: dict) -> int:
    from datetime import datetime, timezone as _tz, timedelta

    def _parse(s):
        if not s: return None
        try:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            if not dt.tzinfo: dt = dt.replace(tzinfo=_tz.utc)
            return dt
        except Exception:
            return None

    now = datetime.now(_tz.utc)

    # An empty meta means the fetch failed, 404'd, or came back malformed —
    # NOT that the title is settled. Caching that under the long TTL (which
    # is what the old "no videos -> LONG" branch did) hid the title from the
    # calendar for a full week off the back of one bad response, and was a
    # real source of "the calendar is missing/wrong for this show". Retry it
    # on the next load instead.
    if not meta:
        return _CALENDAR_CACHE_EMPTY_TTL

    if kind == "movie":
        dt = _parse(meta.get("released"))
        if dt and dt < now - timedelta(days=60):
            return _CALENDAR_CACHE_LONG_TTL
        return _CALENDAR_CACHE_SHORT_TTL

    videos = meta.get("videos") or []
    if not videos:
        return _CALENDAR_CACHE_EMPTY_TTL

    # series: short TTL if anything is upcoming or aired recently enough
    # that its date could still be corrected.
    has_upcoming_or_recent = any(
        (dt := _parse(v.get("released"))) and dt > now - timedelta(days=14)
        for v in videos
    )
    if has_upcoming_or_recent:
        return _CALENDAR_CACHE_SHORT_TTL

    # Nothing upcoming and nothing recent — but that does NOT mean static.
    # A show that's still running is exactly the case where Cinemeta ADDS
    # rows we don't have yet (next season announced, dates attached to
    # already-listed episodes). Under the old flat 7-day TTL, a between-
    # seasons show could stay wrong for a week after the schedule dropped.
    # Cinemeta reports this as status "Continuing"/"Returning Series", and
    # an open-ended releaseInfo ("2024-") says the same thing.
    status = str(meta.get("status") or "").strip().lower()
    release_info = str(meta.get("releaseInfo") or meta.get("year") or "")
    ongoing = (
        status in ("continuing", "returning series", "in production", "planned")
        or release_info.rstrip().endswith("-")
    )
    return _CALENDAR_CACHE_MID_TTL if ongoing else _CALENDAR_CACHE_LONG_TTL


# How many Cinemeta requests are allowed in flight at once, SHARED across
# every caller (calendar, missing-counts) — this used to be a
# constant that each caller turned into its OWN separate Semaphore(40),
# which meant they never actually coordinated: if the calendar, the
# missing-counts endpoint both happened to run around the
# same time, real concurrent load could hit 3×40=120 requests, not 40 —
# exactly the same class of bug already fixed once for AIOStreams. Cinemeta
# is a more tolerant service than AIOStreams, but not infinitely so; 120
# concurrent connections was enough to cause a wave of timeouts (visible as
# "failed to fetch ... :" with nothing after the colon — asyncio.TimeoutError
# stringifies to an empty string, which is why those log lines look blank).
_CALENDAR_FETCH_CONCURRENCY = 15
_cinemeta_gate = asyncio.Semaphore(_CALENDAR_FETCH_CONCURRENCY)


def _calendar_meta_age(kind: str, imdb_id: str) -> Optional[int]:
    """Seconds since this title's Cinemeta metadata was last actually
    fetched. Lets the UI distinguish "this date is fresh" from "this date
    is what we were told six days ago", which is the difference between a
    calendar you can trust and one you can't."""
    cached = _calendar_meta_cache.get(f"{kind}:{imdb_id}")
    return int(time.time() - cached[0]) if cached else None


async def _cinemeta_cached(kind: str, imdb_id: str, refresh: bool = False) -> dict:
    """
    Cached Cinemeta meta fetch.

    `refresh=True` ignores the cached copy and re-fetches — this is what
    backs the Calendar's Refresh button. Without it there was no way at
    all to correct a wrong date from the UI: the button re-requested
    /api/calendar, which served the same cached metadata straight back,
    so a title with a stale air date stayed stale until its TTL expired
    (up to a week).

    On a failed fetch this now RETURNS THE STALE COPY rather than raising.
    Previously any error propagated to the caller, which logged it and
    dropped the title from the response entirely — so a transient Cinemeta
    blip made shows silently vanish from the calendar rather than just
    show slightly old dates. Stale-but-present beats absent.
    """
    _load_calendar_cache()
    key = f"{kind}:{imdb_id}"
    cached = _calendar_meta_cache.get(key)
    if cached and not refresh and (time.time() - cached[0]) < cached[1]:
        return cached[2]

    try:
        async with _cinemeta_gate:
            async with _http.get(
                f"https://v3-cinemeta.strem.io/meta/{kind}/{imdb_id}.json",
                headers={"User-Agent": "AIOGateway/0.3"},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                # An error page is not metadata. Without this check a 5xx
                # body parsed to {} and was then cached as though Cinemeta
                # had authoritatively told us the show has no episodes.
                if resp.status >= 400:
                    raise RuntimeError(f"Cinemeta HTTP {resp.status}")
                data = await resp.json(content_type=None)
    except Exception:
        if cached:
            # Keep serving the old copy, but re-arm a short retry so we
            # try again on the next load instead of pinning the stale
            # value for whatever its original TTL was.
            _calendar_meta_cache[key] = (time.time(), _CALENDAR_CACHE_EMPTY_TTL, cached[2])
            return cached[2]
        raise

    meta = data.get("meta") or {}
    ttl  = _calendar_cache_ttl(kind, meta)
    _calendar_meta_cache[key] = (time.time(), ttl, meta)
    return meta


@app.get("/api/calendar")
async def get_calendar(days_back: int = 14, days_ahead: int = 30, refresh: bool = False):
    """
    Returns calendar entries for all tracked movies and series episodes
    releasing within [days_back, days_ahead] of today.

    `refresh=1` bypasses the Cinemeta cache and re-fetches every tracked
    title's metadata. This is the "the calendar is wrong, go check again"
    path — without it the UI could only ever redisplay whatever was
    already cached.

    For series: fetches real per-episode air dates from Cinemeta — accurate
    because streaming shows air and go digital on the same date.

    For movies: uses Cinemeta's `released` field, which is the theatrical
    release date for most movies, not the digital/VOD date. Labeled clearly.
    Digital dates vary by title and aren't available in any free no-auth API.

    Each entry includes `release_ts` (Unix timestamp) so the frontend can
    sort and group by date without timezone issues, plus `stub_exists`
    indicating whether the content is already in the library (so the UI
    can show "in library" vs "upcoming").

    Every tracked title's Cinemeta metadata is fetched CONCURRENTLY (bounded
    by a semaphore) rather than one at a time — with a few hundred tracked
    titles, doing this sequentially was the actual bottleneck behind a slow
    calendar load, not anything AIOStreams-related. Results are also cached
    for a few minutes (see _cinemeta_cached above) so repeat loads of the
    same window are close to instant.
    """
    from datetime import datetime, timezone as _tz, timedelta

    now = datetime.now(_tz.utc)
    window_start = now - timedelta(days=days_back)
    window_end   = now + timedelta(days=days_ahead)

    def _parse_date(s: Optional[str]):
        if not s: return None
        try:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            if not dt.tzinfo:
                dt = dt.replace(tzinfo=_tz.utc)
            return dt
        except Exception:
            return None

    def _in_window(dt) -> bool:
        if not dt: return False
        return window_start <= dt <= window_end

    entries = []

    # Single pass over all stubs to build every lookup the loops below need,
    # instead of each title re-scanning the full stub list from scratch.
    all_stubs = _stubs.all()
    series_imdb_ids: set = set()
    movie_imdb_ids: set = set()
    stubbed_episodes: set = set()
    stubbed_movies: set = set()
    poster_by_imdb: dict = {}
    show_title_by_imdb: dict = {}
    movie_stub_by_imdb: dict = {}

    for s in all_stubs:
        if not s.imdb_id:
            continue
        if s.aiostreams_type == "series":
            series_imdb_ids.add(s.imdb_id)
            if s.season and s.episode:
                stubbed_episodes.add((s.imdb_id, s.season, s.episode))
            if s.imdb_id not in poster_by_imdb and getattr(s, "_poster", ""):
                poster_by_imdb[s.imdb_id] = s._poster
            if s.imdb_id not in show_title_by_imdb and (s.show_title or s.title):
                show_title_by_imdb[s.imdb_id] = s.show_title or s.title
        elif s.aiostreams_type == "movie":
            movie_imdb_ids.add(s.imdb_id)
            stubbed_movies.add(s.imdb_id)
            movie_stub_by_imdb.setdefault(s.imdb_id, s)

    # Titles whose metadata could not be fetched at all. These used to be
    # logged and then silently omitted, which is the worst possible failure
    # mode for a calendar: the page looks complete and correct while a show
    # is simply missing from it. Surfaced in the response so the UI can say so.
    unavailable: list = []

    async def _fetch_series(imdb_id: str) -> list:
        out = []
        try:
            meta = await _cinemeta_cached("series", imdb_id, refresh=refresh)
            videos = meta.get("videos") or []
            poster = meta.get("poster") or poster_by_imdb.get(imdb_id, "")
            show_title = show_title_by_imdb.get(imdb_id) or meta.get("name", imdb_id)
            for v in videos:
                sn, ep = v.get("season"), v.get("number")
                if not sn or not ep or sn == 0:
                    continue
                dt = _parse_date(v.get("released"))
                if not _in_window(dt):
                    continue
                key = (imdb_id, sn, ep)
                out.append({
                    "_key":         key,
                    "type":         "episode",
                    "imdb_id":      imdb_id,
                    "title":        show_title,
                    "episode_name": v.get("name") or f"S{sn:02d}E{ep:02d}",
                    "season":       sn,
                    "episode":      ep,
                    "poster":       poster,
                    # Needed by the manual-search picker opened from the
                    # calendar — search-candidates takes a year to
                    # disambiguate reboots/remakes with the same title.
                    "year":         _extract_year(meta.get("releaseInfo") or meta.get("year")),
                    "meta_age":     _calendar_meta_age("series", imdb_id),
                    "release_date": dt.date().isoformat(),
                    "release_ts":   int(dt.timestamp()),
                    "stub_exists":  key in stubbed_episodes,
                    "in_library":   key in stubbed_episodes,
                    "date_type":    "air_date",  # accurate — air date = digital for streaming
                })
        except Exception as exc:
            logger.warning("Calendar: failed to fetch episodes for %s: %s (%s)",
                          imdb_id, exc, type(exc).__name__)
            unavailable.append({
                "imdb_id": imdb_id, "type": "series",
                "title": show_title_by_imdb.get(imdb_id) or imdb_id,
                "error": str(exc) or type(exc).__name__,
            })
        return out

    async def _fetch_movie(imdb_id: str) -> Optional[dict]:
        try:
            meta = await _cinemeta_cached("movie", imdb_id, refresh=refresh)
            dt = _parse_date(meta.get("released"))
            if not _in_window(dt):
                return None
            stub = movie_stub_by_imdb.get(imdb_id)
            return {
                "_key":         imdb_id,
                "type":         "movie",
                "imdb_id":      imdb_id,
                "title":        meta.get("name") or (stub.title if stub else imdb_id),
                "poster":       meta.get("poster") or (getattr(stub, "_poster", "") if stub else ""),
                "year":         _extract_year(meta.get("year") or meta.get("releaseInfo")),
                "meta_age":     _calendar_meta_age("movie", imdb_id),
                "release_date": dt.date().isoformat(),
                "release_ts":   int(dt.timestamp()),
                "stub_exists":  imdb_id in stubbed_movies,
                "in_library":   imdb_id in stubbed_movies,
                "date_type":    "theatrical",  # Cinemeta gives theatrical, not digital/VOD
            }
        except Exception as exc:
            logger.warning("Calendar: failed to fetch movie meta for %s: %s (%s)",
                          imdb_id, exc, type(exc).__name__)
            stub = movie_stub_by_imdb.get(imdb_id)
            unavailable.append({
                "imdb_id": imdb_id, "type": "movie",
                "title": (stub.title if stub else None) or imdb_id,
                "error": str(exc) or type(exc).__name__,
            })
            return None

    series_results, movie_results = await asyncio.gather(
        asyncio.gather(*[_fetch_series(i) for i in series_imdb_ids]),
        asyncio.gather(*[_fetch_movie(i) for i in movie_imdb_ids]),
    )

    seen_keys = set()
    for ep_list in series_results:
        for e in ep_list:
            if e["_key"] in seen_keys:
                continue
            seen_keys.add(e["_key"])
            del e["_key"]
            entries.append(e)
    for m in movie_results:
        if not m or m["_key"] in seen_keys:
            continue
        seen_keys.add(m["_key"])
        del m["_key"]
        entries.append(m)

    entries.sort(key=lambda e: e["release_ts"])
    asyncio.create_task(asyncio.to_thread(_persist_calendar_cache))

    ages = [e["meta_age"] for e in entries if e.get("meta_age") is not None]
    return {
        "entries":    entries,
        "days_back":  days_back,
        "days_ahead": days_ahead,
        "generated_at": int(now.timestamp()),
        "refreshed":  refresh,
        # Oldest metadata backing anything on screen. If this is large, the
        # dates shown are old news regardless of how recently the page loaded.
        "oldest_meta_age": max(ages) if ages else None,
        "unavailable": unavailable,
    }


@app.get("/api/library/missing-counts")
async def get_missing_counts():
    """
    Returns {imdb_id: missing_episode_count} for every tracked series,
    scoped to seasons that are actually requested — same definition used
    everywhere else in the app (Library's series detail modal): a
    season counts as requested if it has at least one existing
    stub. A season never requested doesn't count toward "missing" just
    because Cinemeta lists it. Powers the "N missing" banner on library
    cover art. Reuses the same cached Cinemeta fetch the calendar and
    the calendar uses, so repeat calls are cheap.
    """
    series_info: dict = {}
    for s in _stubs.all():
        if s.media_type == MediaType.SERIES and s.imdb_id:
            info = series_info.setdefault(s.imdb_id, {"seasons": set(), "have": set()})
            if s.season is not None:
                info["seasons"].add(s.season)
                if s.episode is not None:
                    info["have"].add((s.season, s.episode))

    counts: dict = {}

    async def _count_one(imdb_id: str, info: dict):
        try:
            meta = await _cinemeta_cached("series", imdb_id)
            videos = meta.get("videos") or []
            missing = 0
            for v in videos:
                sn, ep = v.get("season"), v.get("number")
                if not sn or not ep or sn == 0:
                    continue
                if sn not in info["seasons"]:
                    continue
                if not _is_aired(v.get("released")):
                    continue
                if (sn, ep) in info["have"]:
                    continue
                missing += 1
            if missing:
                counts[imdb_id] = missing
        except Exception as exc:
            logger.warning("Missing-count check failed for %s: %s (%s)",
                          imdb_id, exc, type(exc).__name__)

    await asyncio.gather(*[_count_one(i, info) for i, info in series_info.items()])
    return {"counts": counts}


# ---------------------------------------------------------------------------
# Prewarm new content — proactively resolve recently-added / recently-released
# placeholder stubs to real streams, ahead of the first actual play
# ---------------------------------------------------------------------------
# Every stub normally sits as a lightweight placeholder until Plex actually
# tries to play it, at which point the webhook triggers a live resolve —
# that's deliberate (resolving everything eagerly would waste AIOStreams
# budget on things that might never get watched). But for something that
# just got added — a new episode auto-discovered minutes after it aired, a
# movie you just requested — there's a good chance it's about to be
# watched soon, and the very first playback shouldn't also be the moment it
# has to wait on AIOStreams resolution + probing. This proactively runs
# that exact same resolve (best_working_for_quality → set_active) for
# whatever qualifies, one at a time through the same rate gate and
# play-priority pausing as every other background loop.
#
# ELIGIBILITY — "new" means either newly ADDED or newly RELEASED:
#
#   * added within the window  (stub.created_at), or
#   * released within the window  (Cinemeta `released` for a movie, the
#     per-episode air date for an episode)
#
# Either one qualifies. This is deliberately an OR, not a release-date-only
# test. Release date alone silently excluded the single most common case
# this feature exists for: a movie you request today usually released
# theatrically weeks or months ago, so its release date is far outside any
# sane window and it would never prewarm no matter how freshly added it
# was. Conversely created_at alone can't tell a brand-new release apart
# from back-catalog, so both are checked and either is enough.
#
# The bulk-import problem release-date-only was solving is handled directly
# instead, by _prewarm_bulk_import_ids(): a Radarr/Sonarr migration
# stamps a fresh created_at on years of library within a few minutes of
# each other, which is a shape nothing organic produces. Stubs created in
# such a burst don't get the "recently added" pass and must qualify on
# release date — so the migration's genuinely-new titles still prewarm
# while its 2011 back catalog doesn't.
#
# Future-dated content is still skipped (nothing can resolve before it
# exists), but with a grace margin: per-episode air timestamps routinely
# sit a few hours ahead of when a release actually lands, and a hard
# "<= now" comparison excluded exactly the just-aired episodes this is
# most useful for.
#
# TRIGGERS — three, all feeding the same job:
#
#   1. Event-driven (the important one): StubManager fires a callback on
#      every newly-created stub; those are debounced for a few seconds and
#      then prewarmed as a batch. This is what makes "new items get
#      prewarmed" true without anyone watching the UI — previously the
#      only automatic path was the interval loop, and the "prewarm right
#      now" calls after an add/scan were browser-side JS, so anything
#      discovered by a background sweep (auto-episodes, pending movies)
#      with no browser open was never prewarmed at all.
#   2. A periodic full sweep (prewarm_interval_hours), as a backstop, plus
#      one pass shortly after startup to catch anything added while the
#      service was down.
#   3. The manual "Prewarm new content now" button.
#
# All prewarming runs behind a single gate (_prewarm_gate) so overlapping
# triggers queue rather than resolving the same stub twice in parallel,
# and each stub is re-checked immediately before resolving — if a play (or
# an earlier pass) already resolved it, it's skipped rather than
# re-resolved.
#
# Failures are remembered in _prewarm_last_attempt and not retried until
# prewarm_retry_cooldown_hours has passed. Without that, a handful of
# titles with no working sources get re-attempted on every single pass
# forever, and on a large library they crowd out the newly-added items
# this is supposed to prioritise.
#
# Anything this resolves goes through the normal set_active() path, which
# stamps resolved_at — so prewarmed stubs are governed by the global
# active_ttl_days TTL exactly like a stub resolved by an actual play, and
# revert to placeholder on the same schedule rather than holding a debrid
# link open indefinitely.

# How far ahead of "now" a release/air timestamp may sit and still count as
# released. Cinemeta episode dates are nominal air times and a release is
# often on debrid before (or shortly around) them; a strict cutoff dropped
# exactly the just-aired episodes prewarming is most valuable for.
_PREWARM_FUTURE_GRACE_S = 86400          # 1 day

# Stubs created within this many seconds of each other are treated as one
# creation burst for bulk-import detection.
_PREWARM_BURST_WINDOW_S = 900            # 15 min

# How long to wait for the flow of newly-created stubs to go quiet before
# prewarming them as a batch. A season scan creates stubs in a rapid
# stream; batching them means one pass rather than one per episode.
_PREWARM_DEBOUNCE_S = 15

# Delay before the post-startup catch-up sweep, so it doesn't compete with
# restore/mount/scan work during boot.
_PREWARM_STARTUP_DELAY_S = 120

_prewarm_jobs: dict[str, dict] = {}
_prewarm_tasks: dict[str, "asyncio.Task"] = {}

# Only one prewarm pass resolves at a time. Triggers can overlap freely
# (an add, a scan finishing, and the interval sweep can all land at once);
# they queue here instead of racing each other onto the same stubs.
_prewarm_gate = asyncio.Lock()

# Stub IDs reported by StubManager's creation callback, waiting to be
# prewarmed once the burst settles.
_prewarm_new_stubs: set[str] = set()
_prewarm_new_stub_event = asyncio.Event()

# stub_id → timestamp of the last UNSUCCESSFUL prewarm attempt.
_prewarm_last_attempt: dict[str, float] = {}


def _prewarm_enabled() -> bool:
    """
    Prewarming requires BOTH its own toggle and a live TTL.

    The TTL condition isn't a nicety. Prewarming resolves content nobody
    has played, and set_active() opens a real debrid/CDN link for each.
    With the TTL disabled (active_ttl_enabled=False) nothing ever reverts
    those to placeholders — sweep_expired only runs when the effective
    TTL is positive — so every prewarmed stub holds its link permanently,
    for something that may never be watched. A resolve triggered by an
    actual play at least corresponds to something someone wanted; a
    speculative one with no expiry is a link leak.

    So with the TTL off, resolving is play-driven only: stubs stay
    placeholders until Plex asks for them.
    """
    from gateway import settings as _settings
    if not bool(_settings.get("prewarm_enabled", True)):
        return False
    return _prewarm_ttl_ok()


def _prewarm_ttl_ok() -> bool:
    """True when active_ttl_enabled is on — see _prewarm_enabled for why
    prewarming depends on it. Reads the *effective* TTL
    (get_effective_ttl_days()), which is 0 whenever the toggle is off,
    since the day count itself (ACTIVE_TTL_DAYS) is fixed and always
    positive."""
    from gateway import settings as _settings
    try:
        return _settings.get_effective_ttl_days() > 0
    except Exception:
        return False


def _note_new_stub_for_prewarm(stub) -> None:
    """
    StubManager creation callback — registered at startup, called once per
    genuinely-new stub (it's fired from the single _create_one() funnel,
    after the idempotency check, so re-creating an existing stub doesn't
    re-trigger it).

    Deliberately does no work beyond recording the ID: this runs inline
    with stub creation, which happens in the middle of adds and scans, so
    the actual resolving is left to _prewarm_new_stub_worker.
    """
    try:
        if getattr(stub, "state", None) != StubState.PLACEHOLDER:
            return
        _prewarm_new_stubs.add(stub.stub_id)
        _prewarm_new_stub_event.set()
    except Exception as exc:                     # never break stub creation
        logger.debug("Prewarm: could not queue new stub: %s", exc)


async def _stub_release_ts(s) -> Optional[float]:
    """
    The Unix timestamp the CONTENT behind this stub released/aired, or
    None if it can't be determined (Cinemeta unreachable, no date
    published, unparseable value).

    Movies use Cinemeta's `released` field; episodes use the matching
    entry in the series' `videos` list, which is the same per-episode air
    date the calendar and _is_aired() already work from. Both go through
    _cinemeta_cached, so a prewarm pass over a season of one show costs a
    single Cinemeta fetch rather than one per episode.
    """
    from datetime import datetime, timezone as _tz2
    if not s.imdb_id:
        return None
    try:
        if s.media_type == MediaType.MOVIE:
            dt = await _movie_release_dt(s.imdb_id)
            return dt.timestamp() if dt else None

        if s.season is None or s.episode is None:
            return None
        meta = await _cinemeta_cached("series", s.imdb_id)
        target = next(
            (v for v in (meta.get("videos") or [])
             if v.get("season") == s.season and v.get("number") == s.episode),
            None,
        )
        released = (target or {}).get("released")
        if not released:
            return None
        dt = datetime.fromisoformat(released.replace("Z", "+00:00"))
        if not dt.tzinfo:
            dt = dt.replace(tzinfo=_tz2.utc)
        return dt.timestamp()
    except Exception as exc:
        logger.debug("Prewarm: could not determine release date for %s: %s", s.stub_id, exc)
        return None


def _prewarm_bulk_import_ids(stubs: list, threshold: int) -> set[str]:
    """
    Stub IDs that look like part of a bulk import rather than an organic
    add, identified by creation-time clustering: `threshold` or more
    distinct TITLES created within _PREWARM_BURST_WINDOW_S of each other.

    A Radarr/Sonarr migration dumps hundreds of separate titles in one
    burst; an organic add is one title, however many files it expands to.
    Stubs in such a burst lose the "recently added" fast path and have to
    qualify on release date instead.

    Counting distinct titles rather than raw stubs matters, because one
    add is not one stub. Each episode creates up to two (HD and 4K), so
    the old stub count crossed a 25 threshold at a 13-episode season —
    every season add of an ordinary length was misread as a migration,
    dropped to the release-date rule, and then failed it unless the show
    had aired in the last few days. That is the "newly added content
    never prewarms" case. Season length no longer affects this; only the
    number of separate titles arriving at once does.

    threshold <= 0 disables the check entirely.
    """
    if threshold <= 0:
        return set()

    def _title_key(s) -> str:
        # imdb_id groups a whole show (all seasons, both qualities) as one
        # title. Falls back so a stub missing it can't be counted as many.
        return (getattr(s, "imdb_id", None)
                or getattr(s, "media_id", None)
                or s.stub_id)

    if len({_title_key(s) for s in stubs}) < threshold:
        return set()

    ordered = sorted(stubs, key=lambda s: s.created_at)
    times   = [s.created_at for s in ordered]
    keys    = [_title_key(s) for s in ordered]
    flagged: set[str] = set()

    # Sliding window with a running count of distinct titles inside it.
    from collections import Counter
    window: Counter = Counter()
    lo = 0
    flagged_upto = 0
    for hi in range(len(ordered)):
        window[keys[hi]] += 1
        while times[hi] - times[lo] > _PREWARM_BURST_WINDOW_S:
            window[keys[lo]] -= 1
            if window[keys[lo]] == 0:
                del window[keys[lo]]
            lo += 1
        if len(window) >= threshold:
            # Whole window is one burst. `lo` only ever moves forward, so
            # a high-water mark keeps this linear instead of re-adding the
            # same prefix on every step of a long burst.
            start = max(lo, flagged_upto)
            for s in ordered[start:hi + 1]:
                flagged.add(s.stub_id)
            flagged_upto = max(flagged_upto, hi + 1)
    return flagged


async def _prewarm_eligible(s, *, days: float, now: float, bulk_ids: set[str]) -> bool:
    """
    Whether this placeholder stub should be prewarmed. See the module
    comment above — newly added OR newly released qualifies.
    """
    from gateway import settings as _settings

    # Already resolved once and expired by the TTL. Checked BEFORE the
    # days<=0 shortcut, because that shortcut is exactly the configuration
    # where the expire/prewarm loop was worst.
    #
    # Without this, expiry and prewarming cancelled out: the TTL sweep
    # reverted the stub, then the backstop sweep re-resolved it on the
    # same created_at/release-date grounds that qualified it originally,
    # and round it went — so a stub inside the new-content window never
    # actually released its debrid link no matter what the TTL said.
    # Something that has already had a link and lost it to the TTL now
    # waits for a real play, which is the whole point of having a TTL.
    if getattr(s, "ttl_expired_at", None) and bool(
        _settings.get("prewarm_skip_ttl_expired", True)
    ):
        return False

    # Confirmed dead recently — every candidate stream failed, the stub
    # was removed, and something (usually the auto-episode sweep) has
    # since rebuilt it. Probing again now just repeats the removal, which
    # is exactly the loop this check exists to break. Backs off on an
    # escalating schedule and eventually stops; see gateway/stub_history.
    from gateway import stub_history as _hist
    if _hist.suppressed(s.stub_id):
        return False

    if days < 0:
        return True                              # -1 = "prewarm every placeholder"
    if days == 0:
        return False                             # 0 = age filtering off = nothing qualifies

    cutoff = now - (days * 86400)

    # Newly ADDED. Uses first_seen_at, not created_at: a stub rebuilt
    # after a dead removal has created_at=now but inherits its original
    # first_seen_at, so a decades-old episode doesn't masquerade as new
    # content every time it's re-discovered.
    added_at = getattr(s, "first_seen_at", None) or s.created_at
    if added_at >= cutoff and s.stub_id not in bulk_ids:
        return True

    # Newly RELEASED. Also the only path available to bulk-imported stubs,
    # so a migration's actually-current titles still prewarm.
    rel_ts = await _stub_release_ts(s)
    if rel_ts is None:
        return False
    return cutoff <= rel_ts <= (now + _PREWARM_FUTURE_GRACE_S)


async def _prewarm_select_targets(job: dict, stub_ids: Optional[set[str]] = None) -> list:
    """
    Resolve the current placeholder set down to what actually needs
    prewarming. `stub_ids` restricts the pass to specific stubs (the
    event-driven path); None means a full sweep.
    """
    from gateway import settings as _settings

    days      = _settings.get("prewarm_new_content_days", 3) or 0
    threshold = _settings.get("prewarm_bulk_import_threshold", 25) or 0
    cooldown  = (_settings.get("prewarm_retry_cooldown_hours", 6) or 0) * 3600
    now       = time.time()

    all_placeholders = [s for s in _stubs.all() if s.state == StubState.PLACEHOLDER]

    # Bulk detection always looks at every placeholder, not just this
    # pass's subset — a migration is only recognisable against the whole
    # picture, and the event-driven path sees it a handful at a time.
    bulk_ids = _prewarm_bulk_import_ids(all_placeholders, threshold)

    candidates = [s for s in all_placeholders if stub_ids is None or s.stub_id in stub_ids]

    # Cheap local filters first, so Cinemeta lookups only happen for stubs
    # that could actually still qualify.
    pending = []
    for s in candidates:
        if _stubs.in_error_cooldown(s.stub_id):
            continue
        last = _prewarm_last_attempt.get(s.stub_id)
        if cooldown and last and (now - last) < cooldown:
            continue
        pending.append(s)

    job["phase"]  = "selecting"
    job["total"]  = len(pending)
    job["done"]   = 0
    job["status"] = "running"

    targets = []
    for s in pending:
        await _yield_to_play_priority()
        if await _prewarm_eligible(s, days=days, now=now, bulk_ids=bulk_ids):
            targets.append(s)
        job["done"] += 1

    # Newest first: if a pass gets cancelled or the process restarts
    # partway through, the things most likely to be watched imminently
    # have already been done.
    targets.sort(key=lambda s: s.created_at, reverse=True)
    return targets


async def _run_prewarm_new_content(job_id: str, stub_ids: Optional[set[str]] = None):
    """
    One prewarm pass. `stub_ids` limits it to specific stubs (used by the
    event-driven new-stub path); None sweeps every placeholder.
    """
    job = _prewarm_jobs[job_id]
    try:
        from gateway import settings as _settings
        from gateway.aiostreams_client import AllCandidatesDeadError

        job["ttl_days"]    = _settings.get_effective_ttl_days()
        job["window_days"] = _settings.get("prewarm_new_content_days", 3) or 0

        # Wait our turn behind any pass already resolving, so two triggers
        # landing together don't both resolve the same stub.
        if _prewarm_gate.locked():
            job["status"] = "queued"
            job["phase"]  = "queued"
        async with _prewarm_gate:
            targets = await _prewarm_select_targets(job, stub_ids)

            job["phase"]  = "resolving"
            job["total"]  = len(targets)
            job["done"]   = 0
            job["status"] = "running"

            resolved, dead_removed, still_placeholder = [], [], []

            # One TTL lease per pack, within this pass.
            #
            # A season added as a pack is one cached source, so its
            # episodes should hold one lease on it and expire together —
            # the same rule the play-triggered fast-track follows (see
            # webhook/handler.py's _fast_track_pack). Prewarm resolves
            # each episode on its own, so without this a 30-episode
            # season stamped timestamps across however long the pass ran
            # and then dribbled out of ACTIVE over that same spread.
            #
            # Keyed on the pack the winning stream actually came from,
            # not on the season we asked for: an episode that resolved
            # from some other, non-pack source is genuinely a separate
            # lease and keeps its own timestamp.
            pack_leases: dict = {}

            for s in targets:
                # Re-check right before resolving: this pass may have sat
                # behind another one, or an actual play may have resolved
                # the stub in the meantime. Prewarming is a
                # nice-to-have — never redo work that's already done.
                cur = _stubs.get(s.stub_id)
                if cur is None or cur.state != StubState.PLACEHOLDER:
                    job["total"] = max(0, job["total"] - 1)
                    continue

                label = (
                    s.title if s.media_type == MediaType.MOVIE
                    else f"{s.show_title or s.title} S{s.season:02d}E{s.episode:02d}"
                         if s.season is not None and s.episode is not None
                         else (s.show_title or s.title)
                )
                job["current_title"] = label
                await _yield_to_play_priority()

                try:
                    item = MediaItem(
                        id=s.media_id, imdb_id=s.imdb_id, title=s.title,
                        show_title=s.show_title, episode_title="",
                        year=s.year, media_type=s.media_type,
                        season=s.season, episode=s.episode,
                    )
                    item._poster = getattr(s, "_poster", "") or ""

                    stream = await _client.best_working_for_quality(item, s.quality)
                    if stream and stream.url:
                        pack_kind, pack_season = stream.pack_type
                        lease = None
                        # Movies never legitimately have a season/series
                        # pack — gate on media_type rather than trusting
                        # pack_kind alone, since a movie's filename can
                        # accidentally match the pack regex (e.g. "DS4K"
                        # reading as "S4") and would otherwise register a
                        # spurious one-stub "pack lease" for itself.
                        if pack_kind in ("season", "series") and s.media_type == MediaType.SERIES:
                            key = (s.imdb_id, s.quality,
                                   "series" if pack_kind == "series" else pack_season)
                            lease = pack_leases.setdefault(key, time.time())
                        await _stubs.set_active(s.stub_id, stream.url, stream.request_headers,
                                                size=stream.size, resolved_at=lease)
                        _prewarm_last_attempt.pop(s.stub_id, None)
                        resolved.append({"stub_id": s.stub_id, "title": label, "poster": item._poster})
                    else:
                        # Nothing available yet. Remember it so the next
                        # pass doesn't immediately retry the same dead end
                        # ahead of genuinely new content.
                        _prewarm_last_attempt[s.stub_id] = time.time()
                        still_placeholder.append({"stub_id": s.stub_id, "title": label, "reason": "no stream URL"})
                except AllCandidatesDeadError:
                    # Same "confirmed dead, clean it up now" behavior as every
                    # other live resolve path — see the earlier removal logic
                    # in webhook/handler.py and the /proxy fallback.
                    logger.warning("Prewarm: all candidates dead for %s — removing stub", label)
                    await _stubs.remove_stub(s.stub_id, dead=True)
                    _prewarm_last_attempt.pop(s.stub_id, None)
                    dead_removed.append({"stub_id": s.stub_id, "title": label})
                except Exception as exc:
                    _prewarm_last_attempt[s.stub_id] = time.time()
                    still_placeholder.append({"stub_id": s.stub_id, "title": label, "reason": str(exc)})

                job["done"] += 1

        job["resolved"]          = resolved
        job["dead_removed"]      = dead_removed
        job["still_placeholder"] = still_placeholder
        job["status"] = "done"
        if resolved:
            if pack_leases:
                logger.info(
                    "Prewarm: %d pack(s) detected — their episodes share one "
                    "TTL lease each and will expire together",
                    len(pack_leases),
                )
            # set_active() stamped resolved_at on each of these, so the
            # normal TTL sweep governs them from here — no separate expiry
            # path for prewarmed stubs.
            logger.info(
                "Prewarm resolved %d stub(s); active_ttl_days=%g applies to them "
                "(they revert to placeholder on the same sweep as any other resolve)",
                len(resolved), job["ttl_days"],
            )
            if not job["ttl_days"]:
                # Shouldn't be reachable — every trigger checks the TTL
                # first — but the line above reads as reassurance and
                # would be a lie at 0, so say the true thing instead.
                logger.warning(
                    "Prewarm ran with active_ttl_days=0: the %d stub(s) just "
                    "resolved will stay active indefinitely, as no expiry sweep "
                    "will release them.", len(resolved),
                )
    except asyncio.CancelledError:
        job["status"] = "cancelled"
        raise
    except Exception as exc:
        logger.warning("Prewarm pass failed: %s", exc)
        job["status"] = "error"
        job["error"]  = str(exc)
    finally:
        job["finished"]      = True
        job["current_title"] = ""
        _prewarm_tasks.pop(job_id, None)
        _prewarm_prune_jobs()


def _prewarm_prune_jobs(keep: int = 20) -> None:
    """Keep _prewarm_jobs from growing without bound — every trigger
    creates one, and the event-driven path can fire many times a day."""
    if len(_prewarm_jobs) <= keep:
        return
    finished = [(j.get("started_at", 0), jid) for jid, j in _prewarm_jobs.items() if j.get("finished")]
    finished.sort()
    for _, jid in finished[:max(0, len(_prewarm_jobs) - keep)]:
        _prewarm_jobs.pop(jid, None)


def _new_prewarm_job(trigger: str) -> str:
    job_id = uuid.uuid4().hex[:12]
    _prewarm_jobs[job_id] = {
        "job_id": job_id, "phase": "selecting", "total": 0, "done": 0, "current_title": "",
        "status": "starting", "finished": False, "trigger": trigger,
        "started_at": time.time(), "ttl_days": 0, "window_days": 0,
        "resolved": [], "dead_removed": [], "still_placeholder": [],
    }
    return job_id


async def _prewarm_new_stub_worker():
    """
    The event-driven trigger: prewarms stubs as they're created, whatever
    created them (a manual add, a season scan, the auto-episode sweep, the
    pending-movie sweep) and whether or not anyone has the UI open.

    Waits for the creation burst to go quiet (_PREWARM_DEBOUNCE_S) before
    running, so a season scan produces one pass rather than one per
    episode.
    """
    while True:
        try:
            await _prewarm_new_stub_event.wait()

            # Debounce: keep extending while stubs are still arriving.
            while True:
                pending = len(_prewarm_new_stubs)
                await asyncio.sleep(_PREWARM_DEBOUNCE_S)
                if len(_prewarm_new_stubs) == pending:
                    break

            batch = set(_prewarm_new_stubs)
            _prewarm_new_stubs.clear()
            _prewarm_new_stub_event.clear()

            if not batch or not _prewarm_enabled():
                continue

            job_id = _new_prewarm_job("new-content")
            await _run_prewarm_new_content(job_id, stub_ids=batch)
            job = _prewarm_jobs.get(job_id, {})
            if job.get("resolved") or job.get("still_placeholder"):
                logger.info(
                    "Prewarm (new content): %d resolved, %d dead removed, %d still placeholder",
                    len(job.get("resolved", [])), len(job.get("dead_removed", [])),
                    len(job.get("still_placeholder", [])),
                )
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("Prewarm new-stub worker error: %s", exc)
            await asyncio.sleep(30)


async def _prewarm_sweep_loop():
    """
    Backstop full sweep. Runs once shortly after startup (catching
    anything added while the service was down, which the event-driven
    path by definition can't see), then every prewarm_interval_hours if
    that's set to a positive number.

    Sleeps in short slices and compares against the last run time rather
    than sleeping the whole interval in one go, so changing the interval
    in Config takes effect promptly instead of only after the current
    sleep — a 24h interval previously meant a change could sit unapplied
    for a day.
    """
    from gateway import settings as _settings

    await asyncio.sleep(_PREWARM_STARTUP_DELAY_S)
    last_run = 0.0

    while True:
        try:
            if not _prewarm_enabled():
                await asyncio.sleep(60)
                continue

            interval_hours = _settings.get("prewarm_interval_hours", 0) or 0
            # last_run == 0 is the post-startup catch-up pass, which runs
            # regardless of whether a repeating interval is configured.
            due = (last_run == 0.0) or (
                interval_hours > 0 and (time.time() - last_run) >= interval_hours * 3600
            )
            if not due:
                await asyncio.sleep(60)
                continue

            last_run = time.time()
            job_id = _new_prewarm_job("scheduled")
            await _run_prewarm_new_content(job_id)
            job = _prewarm_jobs.get(job_id, {})
            logger.info("Scheduled prewarm complete: %d resolved, %d dead removed, %d still placeholder",
                        len(job.get("resolved", [])), len(job.get("dead_removed", [])),
                        len(job.get("still_placeholder", [])))
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.warning("Scheduled prewarm error: %s", exc)
            await asyncio.sleep(60)


@app.post("/api/prewarm-new-content/run")
async def start_prewarm_new_content():
    """
    Manual "Prewarm new content now". Deliberately ignores
    prewarm_enabled — it's an explicit action, and the toggle governs the
    automatic triggers.

    It does NOT ignore the TTL precondition, though: with
    active_ttl_days=0 there's no sweep to ever release what this resolves,
    so a single click would permanently activate every eligible
    placeholder. Refused with an explanation rather than silently doing
    nothing, so the button doesn't just appear broken.
    """
    if not _prewarm_ttl_ok():
        raise HTTPException(
            400,
            "Prewarming needs a non-zero Active file TTL. With expiry off, "
            "prewarmed files would stay active forever — set a TTL first, or "
            "let content resolve on first play.",
        )

    job_id = _new_prewarm_job("manual")
    task = asyncio.create_task(_run_prewarm_new_content(job_id))
    _prewarm_tasks[job_id] = task
    return {"job_id": job_id}


@app.get("/api/stub-history/dead")
async def list_dead_history():
    """
    Titles whose sources were confirmed dead and are currently held back
    from automatic re-stubbing. Suppression is otherwise invisible — an
    episode simply stops reappearing — so this is how to see what's being
    held and why.
    """
    from gateway import stub_history as _hist
    records = _hist.all_dead()
    return {
        "count": len(records),
        "permanently_dead": sum(1 for r in records if r["permanently_dead"]),
        "records": records,
    }


@app.post("/api/stub-history/clear-dead")
async def clear_dead_history(stub_id: Optional[str] = None):
    """
    Reset dead-source suppression — for one stub with ?stub_id=, or all
    of them. Use after fixing the underlying cause (an expired debrid
    token, say), which is the common case: a batch of titles all going
    dead at once usually means the backend was broken, not the sources.
    """
    from gateway import stub_history as _hist
    if stub_id:
        _hist.clear_dead(stub_id)
        return {"ok": True, "cleared": 1, "stub_id": stub_id}
    n = _hist.clear_all_dead()
    logger.info("Cleared dead-source suppression on %d record(s)", n)
    return {"ok": True, "cleared": n}


@app.get("/api/prewarm-new-content/status/{job_id}")
async def prewarm_new_content_status(job_id: str):
    job = _prewarm_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    return job


@app.post("/api/prewarm-new-content/cancel/{job_id}")
async def cancel_prewarm_new_content(job_id: str):
    job = _prewarm_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    task = _prewarm_tasks.get(job_id)
    if task and not task.done():
        task.cancel()
    return {"ok": True}


@app.delete("/api/series/{imdb_id}/season/{season}")
async def remove_season(imdb_id: str, season: int):
    """
    Deletes every stub (HD and 4K) for one season of a tracked series —
    the "un-request a season" counterpart to requestSeason(). Uses
    StubManager.remove_stub() per stub rather than deleting files directly,
    so each removal also triggers the scoped Plex rescan that cleans the
    now-gone episodes out of Plex's library, not just off disk.
    """
    to_remove = [
        s.stub_id for s in _stubs.all()
        if s.imdb_id == imdb_id and s.season == season
    ]
    if not to_remove:
        raise HTTPException(404, "No stubs found for that season")

    removed = 0
    for sid in to_remove:
        if await _stubs.remove_stub(sid):
            removed += 1

    logger.info("Removed season %d of %s: %d stub(s)", season, imdb_id, removed)
    return {"removed": removed, "season": season, "imdb_id": imdb_id}


async def _resolve_one_quality(item: MediaItem, quality: Quality):
    """Resolve just one quality tier for an item, reusing the same probing
    best_working_for_quality already does for live playback (skips dead
    links, applies exclude-words/size filters) — a more thorough check
    than resolve_all's raw "did anything come back at all". Manual scans
    and the manual quality re-search just want "found something or
    not", so AllCandidatesDeadError collapses to the same None return as
    the plain "nothing found" case here — the special immediate-removal
    handling for that error is specific to the live playback resolve
    path in webhook/handler.py, not these deliberate manual actions."""
    from gateway.aiostreams_client import AllCandidatesDeadError
    try:
        return await _client.best_working_for_quality(item, quality)
    except AllCandidatesDeadError:
        return None


@app.post("/api/movies/{imdb_id}/scan/{quality}")
async def scan_movie_quality(imdb_id: str, quality: str):
    """Manually search for just one quality tier of a movie — for when a
    title has HD but you specifically want to check for 4K (or vice
    versa) right now, rather than waiting on the pending-movies sweep."""
    if quality not in ("hd", "4k"):
        raise HTTPException(400, "quality must be 'hd' or '4k'")
    q = Quality.UHD if quality == "4k" else Quality.HD

    # Prefer metadata from an existing stub for this movie; fall back to
    # Cinemeta if nothing's stubbed yet (e.g. still in the pending list).
    existing = next(
        (s for s in _stubs.all() if s.imdb_id == imdb_id and s.media_type == MediaType.MOVIE),
        None
    )
    if existing:
        title, year, poster = existing.title, existing.year, getattr(existing, "_poster", "")
    else:
        try:
            meta = await _cinemeta_cached("movie", imdb_id)
        except Exception:
            meta = {}
        title  = meta.get("name", imdb_id)
        poster = meta.get("poster", "")
        year   = None
        try:
            if meta.get("year"):
                year = int(str(meta["year"])[:4])
            elif meta.get("released"):
                year = int(meta["released"][:4])
        except Exception:
            pass

    item = MediaItem(id=imdb_id, imdb_id=imdb_id, title=title, year=year, media_type=MediaType.MOVIE)
    item._poster = poster or ""

    stream = await _resolve_one_quality(item, q)
    if not stream:
        raise HTTPException(404, f"No {quality.upper()} stream found")

    stub = await _stubs.create_stub_for_quality(item, q, stream)
    if q == Quality.UHD:
        from gateway import quality_unavailable as _qu
        _qu.unmark(imdb_id)   # found one — clear any earlier "confirmed unavailable" mark
    logger.info("Manual %s scan for movie %s: %s", quality.upper(), imdb_id, stub.stub_id)
    return {"imdb_id": imdb_id, "quality": quality, "stub_id": stub.stub_id}


@app.post("/api/series/{imdb_id}/season/{season}/scan/{quality}")
async def scan_season_quality(imdb_id: str, season: int, quality: str):
    """
    Manually search for just one quality tier across every aired episode
    of one season — the "Scan HD" / "Scan 4K" counterpart to Request
    season, for when a season has (say) HD for most episodes but you want
    to specifically push for 4K right now rather than waiting on the next
    automatic pass.

    Runs synchronously (not handed off to a background task like the
    fast-E01-then-background-scan pattern elsewhere) since this is a
    smaller, deliberate, already-narrow-scoped action — a full season can
    still take a while given the AIOStreams pacing settings, but that's
    expected for an explicit "scan this now" click.
    """
    if quality not in ("hd", "4k"):
        raise HTTPException(400, "quality must be 'hd' or '4k'")
    q = Quality.UHD if quality == "4k" else Quality.HD

    try:
        meta = await _cinemeta_cached("series", imdb_id)
    except Exception as exc:
        raise HTTPException(502, f"Cinemeta fetch failed: {exc}")

    videos = meta.get("videos") or []
    aired_eps = [
        v for v in videos
        if v.get("season") == season and v.get("number") is not None and _is_aired(v.get("released"))
    ]
    if not aired_eps:
        raise HTTPException(404, "No aired episodes found for that season")

    show_title = next(
        (s.show_title or s.title for s in _stubs.all() if s.imdb_id == imdb_id and (s.show_title or s.title)),
        meta.get("name", imdb_id)
    )
    poster = next(
        (getattr(s, "_poster", "") for s in _stubs.all() if s.imdb_id == imdb_id and getattr(s, "_poster", "")),
        meta.get("poster", "")
    )
    year = next((s.year for s in _stubs.all() if s.imdb_id == imdb_id and s.year), None)

    # Skip episodes that already have this exact quality stubbed.
    have = {
        s.episode for s in _stubs.all()
        if s.imdb_id == imdb_id and s.season == season and s.quality == q
    }
    to_scan = [v for v in aired_eps if v.get("number") not in have]

    found = 0
    checked = 0
    for v in to_scan:
        ep_num = v.get("number")
        item = MediaItem(
            id=f"{imdb_id}_s{season}e{ep_num}", imdb_id=imdb_id,
            title=show_title, show_title=show_title, episode_title="",
            year=year, media_type=MediaType.SERIES, season=season, episode=ep_num,
        )
        item._poster = poster or ""
        checked += 1
        try:
            stream = await _resolve_one_quality(item, q)
        except Exception as exc:
            logger.warning("Season %s scan: S%02dE%02d failed: %s", quality, season, ep_num, exc)
            continue
        if stream:
            await _stubs.create_stub_for_quality(item, q, stream)
            found += 1
            if q == Quality.UHD:
                from gateway import quality_unavailable as _qu
                _qu.unmark(imdb_id, season, ep_num)   # found one — clear any earlier mark for this episode

    logger.info("Manual %s scan for %s season %d: %d/%d episodes found",
               quality.upper(), imdb_id, season, found, checked)
    return {
        "imdb_id": imdb_id, "season": season, "quality": quality,
        "checked": checked, "found": found, "already_had": len(aired_eps) - len(to_scan),
    }


class EpisodeQualityScanReq(BaseModel):
    title: str
    poster: str = ""
    year: Optional[int] = None


@app.post("/api/series/{imdb_id}/episode/{season}/{episode}/scan/{quality}")
async def scan_episode_quality(imdb_id: str, season: int, episode: int, quality: str, req: EpisodeQualityScanReq):
    """
    Search for just one specific quality tier of one specific episode —
    the single-episode counterpart to scan_season_quality/
    scan_movie_quality, and what powers the HD/4K choice on a missing
    episode chip in the series detail modal (add_single_episode, by
    contrast, always does HD plus 4K-if-available and has no way to
    target just one tier).

    Same air-date guard as add_single_episode — refuses outright if this
    specific episode hasn't aired yet, for the same reason: anything
    that showed up for an unaired episode would only ever be a bogus or
    mismatched result.
    """
    if quality not in ("hd", "4k"):
        raise HTTPException(400, "quality must be 'hd' or '4k'")
    q = Quality.UHD if quality == "4k" else Quality.HD

    try:
        meta = await _cinemeta_cached("series", imdb_id)
        target = next(
            (v for v in (meta.get("videos") or [])
             if v.get("season") == season and v.get("number") == episode),
            None
        )
        if target is not None and not _is_aired(target.get("released")):
            raise HTTPException(
                400,
                f"S{season:02d}E{episode:02d} hasn't aired yet "
                f"({target.get('released', 'no date available')}) — refusing to search for it."
            )
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("Could not verify air date for %s S%02dE%02d, proceeding anyway: %s",
                       imdb_id, season, episode, exc)

    item = MediaItem(
        id=f"{imdb_id}_s{season}e{episode}", imdb_id=imdb_id,
        title=req.title, show_title=req.title, episode_title="",
        year=req.year, media_type=MediaType.SERIES, season=season, episode=episode,
    )
    item._poster = req.poster or ""

    stream = await _resolve_one_quality(item, q)
    if not stream:
        raise HTTPException(404, f"No {quality.upper()} stream found for S{season:02d}E{episode:02d}")

    stub = await _stubs.create_stub_for_quality(item, q, stream)
    if q == Quality.UHD:
        from gateway import quality_unavailable as _qu
        _qu.unmark(imdb_id, season, episode)   # found one — clear any earlier mark for this episode
    logger.info("Manual %s scan for %s S%02dE%02d: %s", quality.upper(), imdb_id, season, episode, stub.stub_id)
    return {"imdb_id": imdb_id, "season": season, "episode": episode, "quality": quality, "stub_id": stub.stub_id}


@app.get("/api/stubs/{stub_id}/candidates")
async def get_stub_candidates(stub_id: str):
    """
    Lists every available stream AIOStreams currently returns for this
    stub's quality — the same pool best_working_for_quality picks from
    automatically, but shown here so a person can look at filenames/size/
    cache status directly and manually pick a specific one, instead of
    trusting the automatic ranking. Used by Library's "Active stream" tab.
    """
    s = _stubs.get(stub_id)
    if not s:
        raise HTTPException(404, "Not found")

    if s.media_type == MediaType.MOVIE:
        item = MediaItem(
            id=s.imdb_id, imdb_id=s.imdb_id, title=s.title,
            year=s.year, media_type=MediaType.MOVIE,
        )
    else:
        item = MediaItem(
            id=f"{s.imdb_id}_s{s.season}e{s.episode}", imdb_id=s.imdb_id,
            title=s.title, show_title=s.show_title, episode_title="",
            year=s.year, media_type=MediaType.SERIES,
            season=s.season, episode=s.episode,
        )

    try:
        streams = await _client.resolve_all(item)
    except Exception as exc:
        logger.exception("get_stub_candidates: resolve_all failed for stub %s (%s)", stub_id, item.title)
        raise HTTPException(502, f"Could not fetch candidates: {exc}")

    matching = [st for st in streams if st.quality == s.quality][:40]

    def _fmt(st):
        size_gb = round(st.size / (1024**3), 2) if st.size else None
        pack_kind, pack_season = st.pack_type
        # "Season pack"/"series pack" is a TV-only concept, but
        # detect_pack_type works off the filename alone and has no way to
        # know that — a movie release tagged e.g. "DS4K" or "S3D" reads as
        # "S4"/"S3" to the regex and would otherwise get mislabeled as a
        # pack in the UI. Suppress it outright for movie stubs regardless
        # of what the filename-based detector thinks it saw.
        is_pack = pack_kind in ("season", "series") and s.media_type == MediaType.SERIES
        return {
            "url": st.url,
            "headers": st.request_headers or {},
            "size": st.size,
            "size_gb": size_gb,
            "filename": st.filename,
            "service": st.service,
            "cached": bool(st.cached),
            "stream_type": st.stream_type,
            "resolution": st.parsed_file.resolution if st.parsed_file else None,
            "encode": st.parsed_file.encode if st.parsed_file else None,
            "hdr": st.parsed_file.hdr if st.parsed_file else None,
            "languages": (st.parsed_file.languages or []) if st.parsed_file else [],
            "pack": pack_kind if is_pack else None,
            "is_current": bool(s.stream_url and st.url == s.stream_url),
        }

    return {
        "stub_id": stub_id, "quality": s.quality.value,
        "current_url": s.stream_url,
        "candidates": [_fmt(st) for st in matching],
    }


class SelectStreamReq(BaseModel):
    url: str
    headers: dict = {}
    size: Optional[int] = None


@app.post("/api/stubs/{stub_id}/select-stream")
async def select_stub_stream(stub_id: str, req: SelectStreamReq):
    """
    Manually overrides which specific stream a stub points at — the same
    effect a normal resolve has (set_active), just with a person picking
    the exact candidate instead of best_working_for_quality's automatic
    ranking. Does NOT probe the chosen URL first — this is a deliberate
    manual choice, so it's applied as given; if it turns out dead, the
    normal dead-candidate handling on the next play will catch it same as
    any other stream.
    """
    s = _stubs.get(stub_id)
    if not s:
        raise HTTPException(404, "Not found")
    await _stubs.set_active(stub_id, req.url, req.headers, size=req.size)
    logger.info("Manually selected stream for stub %s: %s…", stub_id, req.url[:80])
    return {"ok": True, "stub_id": stub_id}


def _fmt_candidate(st, media_type: MediaType) -> dict:
    """Shared formatter for a raw AIOStream candidate — same shape
    get_stub_candidates' local _fmt produces, minus the is_current flag
    (which only makes sense once a stub already exists). Used by the
    no-stub-yet manual search endpoints below.

    `media_type` gates the "pack" label the same way _fmt does: a movie
    release's filename can accidentally match detect_pack_type's
    season/series patterns (e.g. "DS4K" reading as "S4"), so it's only
    ever reported as a pack when the search itself was for a series."""
    size_gb = round(st.size / (1024**3), 2) if st.size else None
    pack_kind, _pack_season = st.pack_type
    is_pack = pack_kind in ("season", "series") and media_type == MediaType.SERIES
    return {
        "url": st.url,
        "headers": st.request_headers or {},
        "size": st.size,
        "size_gb": size_gb,
        "filename": st.filename,
        "service": st.service,
        "cached": bool(st.cached),
        "stream_type": st.stream_type,
        "resolution": st.parsed_file.resolution if st.parsed_file else None,
        "encode": st.parsed_file.encode if st.parsed_file else None,
        "hdr": st.parsed_file.hdr if st.parsed_file else None,
        "languages": (st.parsed_file.languages or []) if st.parsed_file else [],
        "pack": pack_kind if is_pack else None,
        "quality": st.quality.value,
    }


class SearchCandidatesReq(BaseModel):
    title: str
    poster: str = ""
    year: Optional[int] = None
    quality: Optional[str] = None   # "hd" | "4k" | None for both


class ManualStubReq(BaseModel):
    title: str
    poster: str = ""
    year: Optional[int] = None
    quality: str            # "hd" | "4k" — which stub this candidate becomes
    url: str
    headers: dict = {}
    size: Optional[int] = None
    filename: str = ""


@app.post("/api/movies/{imdb_id}/search-candidates")
async def search_movie_candidates(imdb_id: str, req: SearchCandidatesReq):
    """
    Manual-search counterpart to scan_movie_quality: rather than trusting
    best_working_for_quality's automatic pick, this returns every raw
    candidate AIOStreams has right now for this movie (same underlying
    pool get_stub_candidates shows for an already-existing stub) so a
    person can browse and choose one by hand — exactly the fallback
    needed when the automatic scan came back with "no stream found" and
    the title still has no stub at all yet. Doesn't create anything;
    pair with /manual-stub once a candidate is picked.
    """
    if req.quality is not None and req.quality not in ("hd", "4k"):
        raise HTTPException(400, "quality must be 'hd' or '4k'")
    item = MediaItem(
        id=imdb_id, imdb_id=imdb_id, title=req.title,
        year=req.year, media_type=MediaType.MOVIE,
    )
    try:
        streams = await _client.resolve_all(item)
    except Exception as exc:
        logger.exception("search_movie_candidates: resolve_all failed for %s", imdb_id)
        raise HTTPException(502, f"Could not fetch candidates: {exc}")
    if req.quality:
        want = Quality.UHD if req.quality == "4k" else Quality.HD
        streams = [st for st in streams if st.quality == want]
    return {"candidates": [_fmt_candidate(st, MediaType.MOVIE) for st in streams[:60]]}


@app.post("/api/movies/{imdb_id}/manual-stub")
async def create_manual_movie_stub(imdb_id: str, req: ManualStubReq):
    """Creates (or reuses) the movie's stub for the given quality and
    points it directly at the person-picked candidate from
    search-candidates — the "not found, so let me pick one myself"
    counterpart to scan_movie_quality's automatic search."""
    if req.quality not in ("hd", "4k"):
        raise HTTPException(400, "quality must be 'hd' or '4k'")
    q = Quality.UHD if req.quality == "4k" else Quality.HD
    item = MediaItem(
        id=imdb_id, imdb_id=imdb_id, title=req.title,
        year=req.year, media_type=MediaType.MOVIE,
    )
    item._poster = req.poster or ""
    stub = await _stubs.create_stub_from_candidate(item, q, req.url, req.headers, size=req.size)
    if q == Quality.UHD:
        from gateway import quality_unavailable as _qu
        _qu.unmark(imdb_id)
    logger.info("Manually stubbed %s (%s) from picked candidate: %s", imdb_id, req.quality, stub.stub_id)
    return {"imdb_id": imdb_id, "quality": req.quality, "stub_id": stub.stub_id}


@app.post("/api/series/{imdb_id}/episode/{season}/{episode}/search-candidates")
async def search_episode_candidates(imdb_id: str, season: int, episode: int, req: SearchCandidatesReq):
    """Episode counterpart to search_movie_candidates — every raw
    candidate AIOStreams has right now for this one episode, quality-
    filterable, for hand-picking when the automatic per-episode scan
    turns up nothing (the "E01 not found" case)."""
    if req.quality is not None and req.quality not in ("hd", "4k"):
        raise HTTPException(400, "quality must be 'hd' or '4k'")
    item = MediaItem(
        id=f"{imdb_id}_s{season}e{episode}", imdb_id=imdb_id,
        title=req.title, show_title=req.title, episode_title="",
        year=req.year, media_type=MediaType.SERIES, season=season, episode=episode,
    )
    try:
        streams = await _client.resolve_all(item)
    except Exception as exc:
        logger.exception("search_episode_candidates: resolve_all failed for %s S%02dE%02d", imdb_id, season, episode)
        raise HTTPException(502, f"Could not fetch candidates: {exc}")
    if req.quality:
        want = Quality.UHD if req.quality == "4k" else Quality.HD
        streams = [st for st in streams if st.quality == want]
    return {"candidates": [_fmt_candidate(st, MediaType.SERIES) for st in streams[:60]]}


@app.post("/api/series/{imdb_id}/episode/{season}/{episode}/manual-stub")
async def create_manual_episode_stub(imdb_id: str, season: int, episode: int, req: ManualStubReq):
    """Creates (or reuses) this episode's stub for the given quality and
    points it directly at the person-picked candidate — the manual-search
    counterpart to scan_episode_quality."""
    if req.quality not in ("hd", "4k"):
        raise HTTPException(400, "quality must be 'hd' or '4k'")
    q = Quality.UHD if req.quality == "4k" else Quality.HD
    item = MediaItem(
        id=f"{imdb_id}_s{season}e{episode}", imdb_id=imdb_id,
        title=req.title, show_title=req.title, episode_title="",
        year=req.year, media_type=MediaType.SERIES, season=season, episode=episode,
    )
    item._poster = req.poster or ""
    stub = await _stubs.create_stub_from_candidate(item, q, req.url, req.headers, size=req.size)
    if q == Quality.UHD:
        from gateway import quality_unavailable as _qu
        _qu.unmark(imdb_id, season, episode)
    logger.info("Manually stubbed %s S%02dE%02d (%s) from picked candidate: %s",
                imdb_id, season, episode, req.quality, stub.stub_id)
    return {"imdb_id": imdb_id, "season": season, "episode": episode, "quality": req.quality, "stub_id": stub.stub_id}


class ClearActiveReq(BaseModel):
    # "movie" or "series" to scope the sweep to one Library section;
    # omitted/None clears every active stub regardless of type.
    media_type: Optional[str] = None


class ExpireAllReq(BaseModel):
    media_type: Optional[str] = None
    # Also clear the expiry marker instead of setting it — the undo.
    unmark: bool = False


@app.get("/api/apikey")
async def get_api_key():
    """Current API key and where it comes from. Admin-only, like all of /api."""
    from gateway import auth as _auth
    return {"key": _auth.api_key(), "source": _auth.api_key_source()}


@app.post("/api/apikey/generate")
async def generate_api_key_ep():
    from gateway import auth as _auth
    if _auth.api_key_source() == "env":
        raise HTTPException(
            400,
            "AIOGW_API_KEY is set in the environment and takes precedence. "
            "Remove it from docker-compose.yml to manage the key here instead.",
        )
    return {"key": _auth.generate_api_key(), "source": "stored"}


@app.delete("/api/apikey")
async def revoke_api_key_ep():
    from gateway import auth as _auth
    if _auth.api_key_source() == "env":
        raise HTTPException(400, "AIOGW_API_KEY is set in the environment — remove it there.")
    return {"revoked": _auth.revoke_api_key(), "source": "none"}


@app.post("/api/stubs/expire-all")
async def expire_all_stubs(req: ExpireAllReq):
    """
    Force every ACTIVE stub back to PLACEHOLDER and mark it TTL-expired,
    so prewarming leaves it alone until it's genuinely played again.

    Differs from clear-active, which also reverts stubs but deliberately
    does NOT mark them: that action means "get me a fresh link", so
    prewarming is free to pick those straight back up. This one means
    "release these and stay released".

    With unmark=true it does the opposite — clears ttl_expired_at from
    every placeholder, making them prewarm-eligible again. That's the
    undo, for when this was run by mistake.
    """
    if req.media_type is not None and req.media_type not in ("movie", "series"):
        raise HTTPException(400, "media_type must be 'movie' or 'series'")

    if req.unmark:
        cleared = 0
        for s in list(_stubs.all()):
            if req.media_type and s.aiostreams_type != req.media_type:
                continue
            if getattr(s, "ttl_expired_at", None):
                s.ttl_expired_at = None
                await _stubs._persist_sidecar(s)
                cleared += 1
        logger.info("Cleared the TTL-expired marker on %d stub(s)", cleared)
        return {"ok": True, "unmarked": cleared, "expired": 0}

    expired = 0
    by_folder: dict = {}
    for s in list(_stubs.all()):
        if s.state != StubState.ACTIVE:
            continue
        if req.media_type and s.aiostreams_type != req.media_type:
            continue
        from gateway.stub_manager import FOLDER_MAP as _FOLDER_MAP
        folder = _FOLDER_MAP.get((s.media_type, s.quality), "?")
        await _stubs.revert_to_placeholder(s.stub_id, mark_expired=True)
        by_folder[folder] = by_folder.get(folder, 0) + 1
        expired += 1

    logger.info("Expire-all: reverted and marked %d stub(s)%s — %s",
                expired, f" (media_type={req.media_type})" if req.media_type else "",
                ", ".join(f"{k} {v}" for k, v in sorted(by_folder.items())) or "none")
    return {"ok": True, "expired": expired, "by_folder": by_folder, "unmarked": 0}


@app.get("/api/ttl/status")
async def ttl_status_detail():
    """
    TTL configuration plus the state of every stub against it.

    Distinct from /api/ttl-status, which backs the coverage line in the
    settings UI and only reports active counts per library. This one is
    the diagnostic view: overdue stubs, expiry markers, and stubs with no
    resolved_at that the TTL can never apply to.
    """
    from gateway import settings as _settings
    ttl_days_configured = _settings.ACTIVE_TTL_DAYS
    ttl_enabled_setting = bool(_settings.get("active_ttl_enabled", True))
    ttl_days = _settings.get_effective_ttl_days()
    now = time.time()
    cutoff = now - (ttl_days * 86400) if ttl_days > 0 else None

    active = placeholder = error = 0
    expired_marked = overdue = missing_stamp = 0
    oldest = None
    for s in _stubs.all():
        if s.state == StubState.ACTIVE:
            active += 1
            if not s.resolved_at:
                missing_stamp += 1
            else:
                if oldest is None or s.resolved_at < oldest:
                    oldest = s.resolved_at
                if cutoff is not None and s.resolved_at < cutoff:
                    overdue += 1
        elif s.state == StubState.PLACEHOLDER:
            placeholder += 1
            if getattr(s, "ttl_expired_at", None):
                expired_marked += 1
        else:
            error += 1

    return {
        "active_ttl_days": ttl_days_configured,
        "active_ttl_enabled": ttl_enabled_setting,
        "ttl_enabled": ttl_days > 0,
        "prewarm_enabled": bool(_settings.get("prewarm_enabled", True)),
        "prewarm_skip_ttl_expired": bool(_settings.get("prewarm_skip_ttl_expired", True)),
        "prewarm_new_content_days": _settings.get("prewarm_new_content_days", 3),
        "prewarm_interval_hours": _settings.get("prewarm_interval_hours", 6),
        "counts": {
            "active": active, "placeholder": placeholder, "error": error,
            "placeholder_ttl_expired": expired_marked,
            "active_overdue": overdue,
            "active_missing_resolved_at": missing_stamp,
        },
        "oldest_active_age_days": round((now - oldest) / 86400, 2) if oldest else None,
        "active_by_folder": _stubs.active_breakdown(),
    }


@app.post("/api/stubs/clear-active")
async def clear_active_stubs(req: ClearActiveReq):
    """
    Bulk version of clear-stream: reverts EVERY currently-active stub
    (optionally scoped to media_type "movie" or "series") back to a
    placeholder. Nothing is deleted — same semantics as the single-stub
    clear-stream, just applied across the board: each title simply
    resolves a fresh stream the next time it's played. Backs the
    "Clear active" button shown on the Library's Active filter.
    """
    if req.media_type is not None and req.media_type not in ("movie", "series"):
        raise HTTPException(400, "media_type must be 'movie' or 'series'")
    cleared = 0
    for s in list(_stubs.all()):
        if s.state != StubState.ACTIVE:
            continue
        if req.media_type and s.aiostreams_type != req.media_type:
            continue
        await _stubs.revert_to_placeholder(s.stub_id)
        cleared += 1
    logger.info("Bulk-cleared %d active stub(s)%s", cleared,
                f" (media_type={req.media_type})" if req.media_type else "")
    return {"ok": True, "cleared": cleared}


@app.post("/api/stubs/{stub_id}/clear-stream")
async def clear_stub_stream(stub_id: str):
    """
    Removes the stub's currently active link, reverting it back to a
    placeholder — the "remove the link" half of the Active Stream modal.
    The stub itself (and the series/movie it belongs to) is untouched;
    it'll simply resolve a fresh stream next time it's played, or a new
    one can be set immediately via select-stream.
    """
    s = _stubs.get(stub_id)
    if not s:
        raise HTTPException(404, "Not found")
    await _stubs.revert_to_placeholder(stub_id)
    logger.info("Cleared active stream for stub %s", stub_id)
    return {"ok": True, "stub_id": stub_id}


@app.delete("/api/stubs/{stub_id}")
async def delete_stub(stub_id: str):
    """
    Delete a single stub (one quality's stream) only. This deliberately
    does NOT touch gateway/library_items — the series/movie itself stays
    in the Library (as a shell with no active stream for that quality
    until rescanned) even if this was its last remaining stub. The only
    way to remove a title from the Library entirely is the explicit
    "Delete series"/"Delete movie" action — see /api/series/{imdb_id}
    and /api/movie/{imdb_id} below.
    """
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Not found")
    await _stubs.remove_stub(stub_id)
    return {"deleted": stub_id}


def _purge_tracking_for(imdb_id: str) -> None:
    """Clear every other piece of tracking state tied to this title, as
    part of a full "Delete series"/"Delete movie" — pending-movie
    tracking, wanted seasons, indefinite season-watch, and any
    4K-unavailable marks. Each is independently best-effort so one
    failing doesn't stop the others or the caller's own deletion."""
    try:
        from gateway import pending_movies as _pending_mv
        _pending_mv.remove(imdb_id)
    except Exception as exc:
        logger.warning("Could not clear pending-movie tracking for %s: %s", imdb_id, exc)
    try:
        from gateway import wanted_seasons as _ws
        for season in list(_ws.seasons_for(imdb_id)):
            _ws.remove(imdb_id, season)
    except Exception as exc:
        logger.warning("Could not clear wanted-season tracking for %s: %s", imdb_id, exc)
    try:
        from gateway import season_watch as _sw
        _sw.disable(imdb_id)
    except Exception as exc:
        logger.warning("Could not clear season-watch tracking for %s: %s", imdb_id, exc)
    try:
        from gateway import quality_unavailable as _qu
        for entry in list(_qu.list_all()):
            if entry.get("imdb_id") == imdb_id:
                _qu.unmark(imdb_id, entry.get("season"), entry.get("episode"))
    except Exception as exc:
        logger.warning("Could not clear quality-unavailable marks for %s: %s", imdb_id, exc)


@app.post("/api/series/{imdb_id}/cancel-scan")
async def cancel_series_scan(imdb_id: str):
    """Cancel a running background scan without deleting anything else —
    used when bulk-removing quality stubs for a series (Delete HD/4K/both
    stub) so the scan doesn't just immediately recreate what was just
    deleted, while still leaving the series itself in the Library."""
    if imdb_id in _bg_scans:
        task = _bg_scans.pop(imdb_id)
        task.cancel()
        try:
            await task
        except Exception:
            pass
        logger.info("Cancelled background scan for %s", imdb_id)
        return {"cancelled": True}
    return {"cancelled": False}


@app.delete("/api/series/{imdb_id}")
async def delete_series(imdb_id: str):
    """
    Fully delete a series from the Library: all of its stubs (every
    season/episode, both qualities), any active background scan, and
    every other piece of tracking (wanted seasons, season-watch,
    4K-unavailable marks) plus its gateway/library_items record. This is
    the only way a series is removed from the Library entirely — deleting
    individual quality stubs (Delete HD/4K stub) never does this on its
    own, no matter how many stubs that leaves at zero.
    """
    # Cancel background scan first
    if imdb_id in _bg_scans:
        task = _bg_scans.pop(imdb_id)
        task.cancel()
        try:
            await task
        except Exception:
            pass
        logger.info("Cancelled background scan for %s", imdb_id)

    # Delete all stubs for this series
    deleted = 0
    for s in list(_stubs.all()):
        if s.imdb_id != imdb_id:
            continue
        await _stubs.remove_stub(s.stub_id)
        deleted += 1

    _purge_tracking_for(imdb_id)
    try:
        from gateway import library_items as _lib_items
        _lib_items.remove(imdb_id)
    except Exception as exc:
        logger.warning("Could not clear library-item record for %s: %s", imdb_id, exc)

    logger.info("Deleted series %s entirely (%d stubs)", imdb_id, deleted)
    return {"deleted": deleted, "imdb_id": imdb_id}


@app.delete("/api/movie/{imdb_id}")
async def delete_movie(imdb_id: str):
    """
    Fully delete a movie from the Library: both quality stubs plus every
    other piece of tracking (pending-movie retry, 4K-unavailable marks)
    and its gateway/library_items record. This is the only way a movie is
    removed from the Library entirely — deleting individual quality
    stubs (Delete HD/4K stub) never does this on its own.
    """
    deleted = 0
    for s in list(_stubs.all()):
        if s.imdb_id != imdb_id:
            continue
        await _stubs.remove_stub(s.stub_id)
        deleted += 1

    _purge_tracking_for(imdb_id)
    try:
        from gateway import library_items as _lib_items
        _lib_items.remove(imdb_id)
    except Exception as exc:
        logger.warning("Could not clear library-item record for %s: %s", imdb_id, exc)

    logger.info("Deleted movie %s entirely (%d stubs)", imdb_id, deleted)
    return {"deleted": deleted, "imdb_id": imdb_id}


@app.get("/api/library/items")
async def list_library_items():
    """Every title gateway/library_items considers 'in the library' —
    used by the frontend to keep a title's card visible even after its
    last stub has been deleted (e.g. via 'Delete HD stub'), so a title
    only ever disappears via the explicit Delete series/movie action."""
    from gateway import library_items as _lib_items
    return {"items": _lib_items.list_all()}


# ---------------------------------------------------------------------------
# Plex webhook
# ---------------------------------------------------------------------------

@app.post("/webhook/plex")
async def plex_webhook(request: Request):
    ct = request.headers.get("content-type", "")
    if "multipart/form-data" in ct:
        form = await request.form()
        raw = form.get("payload", "{}")
    else:
        raw = (await request.body()).decode()
    result = await _webhook.handle(raw)
    logger.info("Webhook: %s", result)
    return JSONResponse(result)


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

@app.get("/proxy/{stub_id}")
async def proxy_get(stub_id: str, request: Request):
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Stub not found")

    # If not yet resolved, resolve now (webhook may have been missed)
    if s.state == StubState.PLACEHOLDER or (not s.stream_url and s.state != StubState.ERROR):
        logger.info("Proxy resolving stub %s on-demand (webhook not received)", s.stub_id)
        await _stubs.set_resolving(s.stub_id)
        try:
            from gateway.models import MediaItem, MediaType
            media_type = MediaType.MOVIE if s.aiostreams_type == "movie" else MediaType.SERIES
            parts = s.aiostreams_id.split(":")
            item = MediaItem(
                id=s.media_id, imdb_id=s.imdb_id, title=s.title,
                year=None, media_type=media_type,
                season=int(parts[1]) if len(parts) >= 3 else None,
                episode=int(parts[2]) if len(parts) >= 3 else None,
            )
            stream_obj = await _client.best_working_for_quality(item, s.quality)
            if stream_obj and stream_obj.url:
                await _stubs.set_active(s.stub_id, stream_obj.url, stream_obj.request_headers,
                                        size=stream_obj.size)
                logger.info("On-demand resolved stub %s → %s…", s.stub_id, stream_obj.url[:60])
            else:
                await _stubs.set_error(s.stub_id)
                raise HTTPException(502, "No stream URL returned from AIOStreams")
        except HTTPException:
            raise
        except Exception as exc:
            from gateway.aiostreams_client import AllCandidatesDeadError
            if isinstance(exc, AllCandidatesDeadError):
                logger.warning(
                    "Proxy on-demand resolve: all %s candidates dead for %s — removing stub immediately",
                    s.quality.value.upper(), s.stub_id
                )
                await _stubs.remove_stub(s.stub_id, dead=True)
                raise HTTPException(404, f"This {s.quality.value.upper()} stub had no working sources and has been removed")
            await _stubs.set_error(s.stub_id)
            raise HTTPException(502, f"Stream resolution failed: {exc}")

    if s.state == StubState.ERROR or not s.stream_url:
        raise HTTPException(502, "Stream resolution failed")

    status, headers, body = await _proxy.proxy(s, request.headers.get("Range"))
    return StreamingResponse(body, status_code=status, headers=headers,
                             media_type=headers.get("Content-Type", "video/x-matroska"))


@app.head("/proxy/{stub_id}")
async def proxy_head(stub_id: str):
    s = _stubs.get(stub_id)
    if not s or not s.stream_url: raise HTTPException(404)
    status, headers = await _proxy.head(s)
    return StreamingResponse(b"", status_code=status, headers=headers)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    all_s = _stubs.all()
    return {"status": "ok", "stubs": len(all_s),
            "active": sum(1 for s in all_s if s.state == StubState.ACTIVE),
            "aiostreams_url": os.environ.get("AIOSTREAMS_URL", "not set")}
