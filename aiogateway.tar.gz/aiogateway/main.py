"""
main.py
~~~~~~~
Wiring and lifecycle.

Startup order matters in one place: the filesystem mounts only after the
library has loaded, so Plex never sees an empty tree and decide the
library vanished.
"""
from __future__ import annotations

import asyncio
import atexit
import logging
import os
import signal
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse

from api import config_routes, media_routes, request_routes, setup_routes, state
from gateway import (auth, cinemeta, config, debrid, fusefs,
                     library as library_mod, plex, repair,
                     requests as reqs, settings)
from gateway.aiostreams import AIOStreamsClient
from gateway.library import Library
from gateway.paths import mountpoint
from gateway.repair import Repairer
from gateway.service import MediaService, acquire_loop, request_sweep_loop
from webhook.handler import PlexWebhook

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("aiogateway")

UI_DIR = Path(__file__).parent / "ui"
_background: list[asyncio.Task] = []


def _emergency_unmount() -> None:
    """A FUSE mount outlives the process that made it. Left behind, the
    next start finds a mountpoint that answers every call with ENOTCONN
    and cannot be mounted over — so this runs on every way out."""
    try:
        fusefs.unmount(mountpoint())
    except Exception as exc:
        logger.warning("Emergency unmount error: %s", exc)


# Normal interpreter exit always unmounts.
atexit.register(_emergency_unmount)


def _signal_handler(signum, frame):
    logger.info("Signal %d received — unmounting and exiting", signum)
    _emergency_unmount()
    # Restore the default disposition and re-raise, so the process exits
    # with the signal that killed it. Calling sys.exit() here instead
    # raises SystemExit inside the event loop's select(), which takes
    # uvicorn down with a traceback on every ordinary stop.
    signal.signal(signum, signal.SIG_DFL)
    os.kill(os.getpid(), signum)


# SIGTERM is docker stop; SIGINT is Ctrl-C.
for _sig in (signal.SIGTERM, signal.SIGINT):
    try:
        signal.signal(_sig, _signal_handler)
    except (OSError, ValueError):
        pass   # can fail outside the main thread


@asynccontextmanager
async def lifespan(app: FastAPI):
    config.load()
    settings.load()
    auth.load()
    reqs.load()

    state.library = Library()
    state.library.load()

    state.client = AIOStreamsClient()
    await state.client.open()

    state.media = MediaService(state.library, state.client)
    state.repairer = Repairer(state.library, state.media)
    state.webhook = PlexWebhook(state.library, state.media)

    state.mounted = fusefs.mount(state.library, mountpoint())
    if not state.mounted:
        logger.error(
            "The filesystem did not mount. Check that /dev/fuse is passed "
            "through and SYS_ADMIN is granted in docker-compose.yml."
        )

    due = repair.next_run_at()
    state.repairer.next_due = due.timestamp() if due else None

    _background.extend([
        asyncio.create_task(library_mod.autosave_loop(state.library)),
        asyncio.create_task(repair.scheduler_loop(state.repairer)),
        asyncio.create_task(request_sweep_loop(state.media)),
        asyncio.create_task(acquire_loop(state.media)),
    ])

    counts = state.library.counts()
    logger.info("Ready — %d file(s), %d activated, mounted at %s",
                counts["total"], counts["activated"], mountpoint())

    try:
        yield
    finally:
        for task in _background:
            task.cancel()
        await asyncio.gather(*_background, return_exceptions=True)
        # Cleared, not just cancelled. The list is module-level, so a
        # second lifespan in the same process (tests, an embedded run)
        # would otherwise try to gather tasks belonging to the previous
        # event loop and fail on the way down.
        _background.clear()
        # Any scan still sitting in the debounce window would
        # otherwise be lost when the process stops.
        plex.flush_scans_now()
        cinemeta.persist()
        reqs.save()
        state.library.save()
        await debrid.shutdown()
        if state.client:
            await state.client.close()
        # Explicit, though atexit covers it too — this is the path an
        # ordinary stop takes, and doing it here means the mount is gone
        # before the process starts tearing itself down.
        _emergency_unmount()
        state.mounted = False
        logger.info("Stopped")


app = FastAPI(title="AIOGateway", lifespan=lifespan, docs_url=None, redoc_url=None)

app.include_router(setup_routes.router)
app.include_router(config_routes.router)
app.include_router(media_routes.router)
app.include_router(media_routes.admin_router)
app.include_router(request_routes.router)
app.include_router(request_routes.admin_router)


@app.middleware("http")
async def guard(request: Request, call_next):
    """Sign-in, the setup wizard and the webhook stay open; everything
    else needs a session.

    The webhook is exempt because Plex has no way to hold one. It is
    protected instead by only ever acting on events that match a file
    already in the library — the worst an unauthenticated caller can do
    is make something they can't see activate slightly early.
    """
    path = request.url.path
    open_paths = (
        path == "/" or path.startswith("/static/")
        or path.startswith("/api/auth/") or path.startswith("/api/setup/")
        or path.startswith("/webhook/") or path == "/health"
    )
    if open_paths:
        return await call_next(request)

    if state.current_user(request) is None:
        return JSONResponse({"detail": "Sign in to continue"}, status_code=401)
    return await call_next(request)


@app.get("/health")
async def health():
    return {"ok": True, "mounted": state.mounted}


@app.post("/webhook/plex")
async def plex_webhook(request: Request):
    """Plex posts multipart form data with the payload in a `payload`
    field. Reverse proxies sometimes re-encode that as
    application/x-www-form-urlencoded, and a few forward the JSON on its
    own, so all three are accepted — a webhook that silently ignores a
    play event is very hard to notice and stops anything activating."""
    raw = ""
    content_type = request.headers.get("content-type", "")
    try:
        if "form-data" in content_type or "x-www-form-urlencoded" in content_type:
            form = await request.form()
            raw = form.get("payload", "")
        else:
            raw = (await request.body()).decode("utf-8", errors="replace")
    except Exception as exc:
        logger.warning("Could not read the webhook payload: %s", exc)
        return {"action": "ignored", "reason": "unreadable payload"}

    if not raw or state.webhook is None:
        return {"action": "ignored"}
    return await state.webhook.handle(raw)


@app.get("/", response_class=HTMLResponse)
async def index():
    return FileResponse(UI_DIR / "index.html")


@app.get("/static/{filename}")
async def static_file(filename: str):
    # Resolved and checked against the UI directory so a crafted path
    # can't walk out of it.
    target = (UI_DIR / filename).resolve()
    if not str(target).startswith(str(UI_DIR.resolve())) or not target.is_file():
        return JSONResponse({"detail": "Not found"}, status_code=404)
    return FileResponse(target)
