"""
AIOGateway — FastAPI + NuvioWeb-style UI using Cinemeta for metadata.

Cinemeta (v3-cinemeta.strem.io) is the same free metadata source used by
NuvioWeb/NuvioTV. No API key needed. Returns IMDb IDs, posters/backdrops
from TMDB CDN. Endpoints:
  /catalog/movie/top.json  → popular movies
  /catalog/series/top.json → popular series
  /meta/{type}/{imdb_id}.json → single item detail

Endpoints
---------
GET  /                           NuvioWeb-style browse UI
GET  /api/config                 Env config
GET  /api/test                   AIOStreams connectivity test
GET  /api/cinemeta/{path}        Cinemeta proxy (no CORS issues from browser)
POST /api/add                    Add media → AIOStreams → stub files
GET  /api/stubs                  List stubs
DELETE /api/stubs/{id}           Delete stub + file

POST /webhook/plex               Plex play event
GET  /proxy/{stub_id}            Stream proxy → Plex
HEAD /proxy/{stub_id}            HEAD pre-flight
GET  /health                     Health
"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

import aiohttp
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from pydantic import BaseModel

from gateway.aiostreams_client import AIOStreamsClient
from gateway.models import MediaItem, MediaType, Quality, StubState
from gateway.proxy import StreamProxy
from gateway.stub_manager import StubManager
from webhook.handler import PlexWebhookHandler

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s — %(message)s")
logger = logging.getLogger("aiogateway")

_stubs   = StubManager()
_proxy   = StreamProxy()
_client  = AIOStreamsClient()
_webhook: PlexWebhookHandler | None = None
_http:    aiohttp.ClientSession | None = None

CINEMETA = "https://v3-cinemeta.strem.io"


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _webhook, _http
    await _proxy.open()
    await _client.open()
    _http    = aiohttp.ClientSession(headers={"User-Agent": "AIOGateway/0.3"})
    _webhook = PlexWebhookHandler(_stubs, _client)
    restored = await _stubs.restore()
    logger.info("AIOGateway started — %d stubs restored", restored)
    yield
    await _proxy.close()
    await _client.close()
    if _http: await _http.close()


app = FastAPI(title="AIOGateway", version="0.3.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ---------------------------------------------------------------------------
# Cinemeta proxy  —  /api/cinemeta/{path}
# ---------------------------------------------------------------------------

@app.get("/api/cinemeta/{path:path}")
async def cinemeta_proxy(path: str):
    """Proxy Cinemeta requests from the browser to avoid any CORS issues."""
    assert _http
    url = f"{CINEMETA}/{path}"
    try:
        async with _http.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
            data = await resp.json(content_type=None)
            return JSONResponse(data, status_code=resp.status)
    except Exception as exc:
        logger.error("Cinemeta proxy error %s: %s", url, exc)
        raise HTTPException(502, f"Cinemeta unreachable: {exc}")


# ---------------------------------------------------------------------------
# Embedded NuvioWeb-style UI
# ---------------------------------------------------------------------------

UI_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>AIOGateway</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet"/>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#080810;--sur:#10101a;--card:#14141f;--card2:#1a1a28;
  --bor:rgba(255,255,255,.08);--bor2:rgba(255,255,255,.14);
  --txt:#f0f0f8;--mut:#7878a0;--acc:#e8a020;--acc2:#f5b840;
  --blue:#4a9eff;--grn:#3dd68c;--red:#ff5555;
  --navh:64px;--f:'Inter',system-ui,sans-serif;
}
html,body{height:100%;background:var(--bg);color:var(--txt);font-family:var(--f);font-size:15px;line-height:1.5;-webkit-font-smoothing:antialiased;overflow-x:hidden;scroll-behavior:smooth}

/* ── Nav pill ───────────────────────────────────────────────── */
.nav{
  position:fixed;top:18px;left:50%;transform:translateX(-50%);z-index:100;
  display:flex;align-items:center;gap:2px;
  background:rgba(8,8,16,.85);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);
  border:1px solid var(--bor2);border-radius:50px;padding:5px 6px;
}
.ni{
  display:flex;align-items:center;gap:6px;padding:8px 20px;
  border-radius:40px;font-size:14px;font-weight:600;cursor:pointer;
  border:none;background:none;color:var(--mut);font-family:var(--f);
  transition:all 150ms;white-space:nowrap;
}
.ni:hover{color:var(--txt);background:rgba(255,255,255,.07)}
.ni.on{background:rgba(255,255,255,.12);color:var(--txt)}

/* ── Hero ───────────────────────────────────────────────────── */
.hero{position:relative;height:100vh;max-height:600px;min-height:420px;overflow:hidden;display:flex;align-items:flex-end}
.hero-bg{
  position:absolute;inset:0;
  background-size:cover;background-position:center 20%;
  transition:background-image .5s ease;
}
.hero-ov{
  position:absolute;inset:0;
  background:linear-gradient(to bottom,
    rgba(8,8,16,.2) 0%,
    rgba(8,8,16,.0) 20%,
    rgba(8,8,16,.5) 55%,
    rgba(8,8,16,.95) 85%,
    var(--bg) 100%);
}
.hero-body{position:relative;z-index:2;padding:0 56px 48px;max-width:620px}
.hero-logo{max-height:64px;max-width:280px;margin-bottom:14px;object-fit:contain;filter:drop-shadow(0 2px 12px rgba(0,0,0,.8));display:none}
.hero-title{font-size:56px;font-weight:900;letter-spacing:-2px;line-height:1;margin-bottom:10px;text-shadow:0 2px 20px rgba(0,0,0,.9)}
.hero-meta{display:flex;align-items:center;gap:10px;font-size:14px;color:rgba(255,255,255,.7);font-weight:500;margin-bottom:10px}
.hero-sep{opacity:.4}
.hero-rating{background:rgba(255,255,255,.15);border-radius:5px;padding:2px 8px;font-size:12px;font-weight:700;color:var(--acc2)}
.hero-desc{font-size:14px;color:rgba(255,255,255,.65);line-height:1.6;margin-bottom:20px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.hero-dots{display:flex;gap:5px;margin-bottom:22px}
.hero-dot{width:24px;height:3px;border-radius:2px;background:rgba(255,255,255,.25);cursor:pointer;transition:all 200ms}
.hero-dot.on{background:#fff;width:32px}
.hero-acts{display:flex;gap:10px}
.btn-hero{
  display:flex;align-items:center;gap:8px;padding:12px 28px;border-radius:8px;
  font-family:var(--f);font-size:14px;font-weight:700;cursor:pointer;border:none;transition:all 150ms;
}
.btn-add{background:var(--acc);color:#000}
.btn-add:hover{background:var(--acc2);transform:translateY(-1px)}
.btn-add.added{background:var(--grn);color:#000}
.btn-info{background:rgba(255,255,255,.16);color:#fff;backdrop-filter:blur(8px)}
.btn-info:hover{background:rgba(255,255,255,.26)}

/* ── Content rows ───────────────────────────────────────────── */
.rows{padding-bottom:48px}
.sec{margin-bottom:8px}
.sec-hd{display:flex;align-items:center;justify-content:space-between;padding:0 56px;margin-bottom:16px}
.sec-title{font-size:18px;font-weight:700;letter-spacing:-.3px;border-left:3px solid var(--acc);padding-left:12px}
.view-all{font-size:13px;font-weight:600;color:var(--mut);cursor:pointer;background:none;border:none;font-family:var(--f);display:flex;align-items:center;gap:3px}
.view-all:hover{color:var(--txt)}
.row{display:flex;gap:14px;overflow-x:auto;overflow-y:visible;padding:4px 56px 14px;scrollbar-width:none}
.row::-webkit-scrollbar{display:none}

/* ── Card ───────────────────────────────────────────────────── */
.card{flex:0 0 138px;cursor:pointer;position:relative;transition:transform 200ms}
.card:hover{transform:scale(1.07) translateY(-2px)}
.card.inlib{outline:2px solid var(--grn);border-radius:10px}
.cposter{width:138px;height:207px;border-radius:10px;overflow:hidden;background:var(--card2);position:relative;box-shadow:0 4px 16px rgba(0,0,0,.4)}
.cposter img{width:100%;height:100%;object-fit:cover;display:block;opacity:0;transition:opacity .3s}
.cposter img.loaded{opacity:1}
.crating{position:absolute;top:7px;right:7px;background:rgba(0,0,0,.78);backdrop-filter:blur(4px);border-radius:5px;padding:2px 7px;font-size:11px;font-weight:700;color:var(--acc2)}
.ccheck{position:absolute;top:7px;right:7px;width:22px;height:22px;border-radius:50%;background:var(--grn);display:none;align-items:center;justify-content:center;font-size:12px;color:#000;font-weight:800}
.card.inlib .ccheck{display:flex}
.card.inlib .crating{display:none}
.cname{font-size:12px;font-weight:600;margin-top:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cyear{font-size:11px;color:var(--mut);margin-top:2px}

/* ── Skeleton ───────────────────────────────────────────────── */
.skel{background:linear-gradient(90deg,var(--card) 25%,var(--card2) 50%,var(--card) 75%);background-size:200% 100%;animation:shim 1.5s infinite;border-radius:10px}
@keyframes shim{0%{background-position:200% 0}100%{background-position:-200% 0}}

/* ── Modal ──────────────────────────────────────────────────── */
.mbg{position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);z-index:200;display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;transition:opacity 180ms}
.mbg.open{opacity:1;pointer-events:all}
.modal{background:var(--card);border:1px solid var(--bor2);border-radius:18px;width:92%;max-width:520px;overflow:hidden;transform:scale(.94) translateY(12px);transition:transform 180ms}
.mbg.open .modal{transform:scale(1) translateY(0)}
.mhero{height:220px;background-size:cover;background-position:center;position:relative}
.mhero-ov{position:absolute;inset:0;background:linear-gradient(to bottom,rgba(20,20,31,.2) 0%,var(--card) 100%)}
.mbody{padding:20px 24px 26px}
.mtitle{font-size:22px;font-weight:800;letter-spacing:-.5px;margin-bottom:6px}
.mmeta{display:flex;gap:9px;font-size:13px;color:var(--mut);margin-bottom:10px;flex-wrap:wrap;align-items:center}
.mrating{background:var(--card2);border:1px solid var(--bor);padding:2px 8px;border-radius:5px;font-size:11px;font-weight:700;color:var(--acc2)}
.mpills{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:14px}
.mpill{background:var(--card2);border:1px solid var(--bor);padding:3px 11px;border-radius:20px;font-size:12px;font-weight:500}
.moverview{font-size:13px;color:var(--mut);line-height:1.7;margin-bottom:22px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.macts{display:flex;gap:10px}
.mbtn{flex:1;display:flex;align-items:center;justify-content:center;gap:7px;padding:12px;border-radius:9px;font-family:var(--f);font-size:13px;font-weight:700;cursor:pointer;border:none;transition:all 150ms}
.mbtn-add{background:var(--acc);color:#000}
.mbtn-add:hover{background:var(--acc2)}
.mbtn-add.added{background:var(--grn);color:#000}
.mbtn-close{background:var(--card2);color:var(--mut);border:1px solid var(--bor2)}
.mbtn-close:hover{color:var(--txt)}
.mclose{position:absolute;top:14px;right:14px;z-index:10;width:30px;height:30px;border-radius:50%;background:rgba(0,0,0,.6);border:none;color:#fff;font-size:15px;cursor:pointer;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px)}
.mclose:hover{background:rgba(0,0,0,.9)}

/* ── Library page ───────────────────────────────────────────── */
.libpage{padding:calc(var(--navh) + 28px) 56px 48px}
.libhd{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px}
.libtitle{font-size:28px;font-weight:800;letter-spacing:-.5px}
.libgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(138px,1fr));gap:22px 14px}
.stub-state{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;margin-top:5px}
.ss-ph{background:#2a2a14;color:#c8a030}
.ss-ac{background:#0d2a18;color:var(--grn)}
.ss-er{background:#2a0d0d;color:var(--red)}
.ss-rs{background:#141e2e;color:var(--blue);animation:sblink 1.1s infinite}
@keyframes sblink{0%,100%{opacity:1}50%{opacity:.35}}
.del-btn{width:26px;height:26px;border-radius:50%;background:rgba(0,0,0,.7);border:none;color:#888;font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all 130ms}
.del-btn:hover{background:var(--red);color:#fff}

/* ── Search ─────────────────────────────────────────────────── */
.searchbar{display:flex;align-items:center;gap:9px;background:var(--card2);border:1px solid var(--bor2);border-radius:10px;padding:9px 15px}
.searchbar input{background:none;border:none;outline:none;font-family:var(--f);font-size:14px;color:var(--txt);width:100%}
.searchbar input::placeholder{color:var(--mut)}

/* ── Config page ─────────────────────────────────────────────── */
.cfgpage{padding:calc(var(--navh) + 28px) 56px 48px}
.cfgsec{background:var(--card);border:1px solid var(--bor);border-radius:14px;padding:22px;margin-bottom:16px}
.cfgsec h3{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--mut);margin-bottom:16px}
.chips{display:flex;flex-wrap:wrap;gap:8px}
.chip{background:var(--card2);border:1px solid var(--bor);border-radius:8px;padding:7px 14px;font-size:12px;display:flex;gap:8px}
.cl{color:var(--mut);font-weight:600}
.cv{font-family:monospace;color:var(--txt)}
.cv.ok{color:var(--grn)}
.cv.er{color:var(--red)}
.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 20px;border-radius:8px;font-family:var(--f);font-size:13px;font-weight:700;cursor:pointer;border:none;transition:all 150ms}
.bp{background:var(--acc);color:#000}.bp:hover{background:var(--acc2)}
.bg2{background:var(--card2);color:var(--mut);border:1px solid var(--bor2)}.bg2:hover{color:var(--txt)}
.tresult{font-size:13px;color:var(--mut);margin-bottom:14px;min-height:20px}
.checklist{font-size:13px;color:var(--mut);line-height:2.2}
.checklist code{background:var(--card2);color:var(--acc2);padding:1px 7px;border-radius:5px;font-size:12px}

/* ── Toast ───────────────────────────────────────────────────── */
.toast{position:fixed;bottom:26px;right:26px;z-index:500;background:var(--card);border:1px solid var(--bor2);border-radius:12px;padding:12px 18px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;animation:tin .2s ease}
@keyframes tin{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.toast.ok{border-color:var(--grn);color:var(--grn)}
.toast.er{border-color:var(--red);color:var(--red)}
.toast.in{border-color:var(--blue);color:var(--blue)}
</style>
</head>
<body>

<!-- Nav -->
<nav class="nav">
  <button class="ni on" onclick="nav('home',this)">🏠 Home</button>
  <button class="ni"    onclick="nav('library',this)">☰ Library</button>
  <button class="ni"    onclick="nav('config',this)">⚙ Config</button>
</nav>

<!-- HOME -->
<div id="pHome">
  <div class="hero" id="hero">
    <div class="hero-bg" id="heroBg"></div>
    <div class="hero-ov"></div>
    <div class="hero-body">
      <img class="hero-logo" id="heroLogo" alt=""/>
      <div class="hero-title" id="heroTitle">…</div>
      <div class="hero-meta" id="heroMeta"></div>
      <div class="hero-desc" id="heroDesc"></div>
      <div class="hero-dots" id="heroDots"></div>
      <div class="hero-acts">
        <button class="btn-hero btn-add" id="heroBtn" onclick="heroAdd()">＋ Add to Plex</button>
        <button class="btn-hero btn-info" onclick="heroInfo()">ⓘ More Info</button>
      </div>
    </div>
  </div>

  <div class="rows">
    <div class="sec">
      <div class="sec-hd">
        <span class="sec-title">Popular — Movie</span>
        <button class="view-all">View All ›</button>
      </div>
      <div class="row" id="rowM">
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
      </div>
    </div>
    <div class="sec">
      <div class="sec-hd">
        <span class="sec-title">Popular — Series</span>
        <button class="view-all">View All ›</button>
      </div>
      <div class="row" id="rowS">
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
        <div class="card"><div class="skel" style="width:138px;height:207px"></div></div>
      </div>
    </div>
  </div>
</div>

<!-- LIBRARY -->
<div id="pLibrary" style="display:none">
  <div class="libpage">
    <div class="libhd">
      <span class="libtitle">My Library</span>
      <div class="searchbar" style="max-width:300px">
        <span style="color:var(--mut)">⌕</span>
        <input placeholder="Filter…" oninput="filterLib(this.value)" id="libFilter"/>
      </div>
    </div>
    <div class="libgrid" id="libGrid">
      <div style="color:var(--mut);grid-column:1/-1">Loading…</div>
    </div>
  </div>
</div>

<!-- CONFIG -->
<div id="pConfig" style="display:none">
  <div class="cfgpage">
    <h2 style="font-size:26px;font-weight:800;margin-bottom:24px;letter-spacing:-.5px">Config</h2>
    <div class="cfgsec">
      <h3>AIOStreams connection</h3>
      <div class="chips" id="cfgChips">…</div>
      <div class="tresult" id="tresult" style="margin-top:14px"></div>
      <button class="btn bp" onclick="runTest()">▶ Test connection</button>
    </div>
    <div class="cfgsec">
      <h3>Plex setup</h3>
      <div class="checklist">
        <div>1. Add library folders in Plex:<br>
          <code>/library/Movies</code>&nbsp;&nbsp;<code>/library/Movies4K</code>&nbsp;&nbsp;<code>/library/Series</code>&nbsp;&nbsp;<code>/library/Series4K</code>
        </div>
        <div>2. Plex → Settings → Webhooks → Add:<br>
          <code id="wurl">http://&lt;host&gt;:8001/webhook/plex</code>
        </div>
        <div>3. AIOStreams debrid credentials must return direct stream <code>url</code> fields.</div>
      </div>
    </div>
  </div>
</div>

<!-- MODAL -->
<div class="mbg" id="modal" onclick="bgClose(event)">
  <div class="modal">
    <div class="mhero" id="mhero" style="position:relative">
      <div class="mhero-ov"></div>
      <button class="mclose" onclick="closeModal()">✕</button>
    </div>
    <div class="mbody">
      <div class="mtitle" id="mtitle"></div>
      <div class="mmeta" id="mmeta"></div>
      <div class="mpills" id="mpills"></div>
      <div class="moverview" id="moverview"></div>
      <div class="macts">
        <button class="mbtn mbtn-add" id="maddBtn" onclick="modalAdd()">＋ Add to Plex</button>
        <button class="mbtn mbtn-close" onclick="closeModal()">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
// ── State ──────────────────────────────────────────────────────
let heroItems = [], heroIdx = 0, heroTimer = null;
let stubs = [], allStubs = [], libImdb = new Set();
let modalItem = null;
const C = '/api/cinemeta';

// ── Nav ────────────────────────────────────────────────────────
function nav(page, el) {
  ['Home','Library','Config'].forEach(p => {
    document.getElementById('p'+p).style.display = 'none';
  });
  document.querySelectorAll('.ni').forEach(n => n.classList.remove('on'));
  document.getElementById('p'+page.charAt(0).toUpperCase()+page.slice(1)).style.display = '';
  el.classList.add('on');
  if (page === 'library') loadLib();
  if (page === 'config')  loadCfg();
}

// ── Cinemeta fetch ─────────────────────────────────────────────
async function cmFetch(path) {
  const r = await fetch(`${C}/${path}`);
  if (!r.ok) throw new Error(`Cinemeta ${r.status}: ${path}`);
  return r.json();
}

// ── Hero ───────────────────────────────────────────────────────
async function loadHero() {
  const data = await cmFetch('catalog/movie/top.json');
  const items = (data.metas || []).filter(m => m.background || m.poster).slice(0, 9);
  if (!items.length) return;
  heroItems = items;
  buildDots();
  setHero(0);
  heroTimer = setInterval(() => setHero((heroIdx+1) % heroItems.length), 7000);
}

function buildDots() {
  document.getElementById('heroDots').innerHTML =
    heroItems.map((_,i) => `<div class="hero-dot${i===0?' on':''}" onclick="setHero(${i})"></div>`).join('');
}

function setHero(i) {
  heroIdx = i;
  const m = heroItems[i];
  if (!m) return;

  // Backdrop
  const bg = m.background || m.poster || '';
  document.getElementById('heroBg').style.backgroundImage = bg ? `url(${bg})` : 'none';

  // Logo
  const logoEl = document.getElementById('heroLogo');
  if (m.logo) {
    logoEl.src = m.logo;
    logoEl.style.display = 'block';
    document.getElementById('heroTitle').style.display = 'none';
  } else {
    logoEl.style.display = 'none';
    document.getElementById('heroTitle').style.display = 'block';
    document.getElementById('heroTitle').textContent = m.name || '';
  }

  // Meta
  const year = m.releaseInfo ? m.releaseInfo.split('–')[0] : '';
  const rating = m.imdbRating ? `★ ${m.imdbRating}` : '';
  const genres = (m.genres || []).slice(0,2).join(' · ');
  const metaParts = [year, genres].filter(Boolean);
  document.getElementById('heroMeta').innerHTML =
    metaParts.map(p=>`<span>${p}</span>`).join('<span class="hero-sep">•</span>') +
    (rating ? `<span class="hero-sep">•</span><span class="hero-rating">${rating}</span>` : '');

  document.getElementById('heroDesc').textContent = m.description || '';

  // Dots
  document.querySelectorAll('.hero-dot').forEach((d,j) => d.classList.toggle('on', j===i));

  // Add button state
  const btn = document.getElementById('heroBtn');
  const inLib = libImdb.has(m.id);
  btn.textContent = inLib ? '✓ In Library' : '＋ Add to Plex';
  btn.className = 'btn-hero btn-add' + (inLib ? ' added' : '');
}

function heroAdd()  { if (heroItems[heroIdx]) openModal(heroItems[heroIdx], 'movie'); }
function heroInfo() { if (heroItems[heroIdx]) openModal(heroItems[heroIdx], 'movie'); }

// ── Card rows ──────────────────────────────────────────────────
function card(m, type) {
  const inLib = libImdb.has(m.id);
  const year = m.releaseInfo ? m.releaseInfo.split('–')[0] : '';
  const rating = m.imdbRating || '';
  const name = (m.name || '').replace(/'/g,"&#39;").replace(/"/g,'&quot;');
  const safeM = JSON.stringify(m).replace(/\\/g,'\\\\').replace(/'/g,"\\'");
  return `<div class="card${inLib?' inlib':''}" id="c${m.id}" onclick='openModal(${safeM},"${type}")'>
    <div class="cposter">
      ${m.poster ? `<img src="${m.poster}" loading="lazy" onload="this.classList.add('loaded')" onerror="this.parentNode.style.background='#1a1a28'"/>` : ''}
      ${rating ? `<div class="crating">★ ${rating}</div>` : ''}
      <div class="ccheck">✓</div>
    </div>
    <div class="cname">${name}</div>
    <div class="cyear">${year}</div>
  </div>`;
}

async function loadRow(elId, path, type) {
  try {
    const data = await cmFetch(path);
    const items = (data.metas || []).slice(0, 20);
    document.getElementById(elId).innerHTML = items.map(m => card(m, type)).join('');
    return items;
  } catch(e) {
    document.getElementById(elId).innerHTML = `<div style="color:var(--red);font-size:13px;padding:20px">Failed to load: ${e.message}</div>`;
    return [];
  }
}

// ── Modal ──────────────────────────────────────────────────────
async function openModal(item, type) {
  modalItem = { ...item, _type: type };

  // Try to get full meta if we only have preview
  if (!item.description && item.id) {
    try {
      const full = await cmFetch(`meta/${type}/${item.id}.json`);
      if (full.meta) { modalItem = { ...full.meta, _type: type }; item = modalItem; }
    } catch {}
  }

  document.getElementById('mtitle').textContent = item.name || '';
  const year = item.releaseInfo ? item.releaseInfo.split('–')[0] : '';
  const rating = item.imdbRating ? `<span class="mrating">★ ${item.imdbRating}</span>` : '';
  document.getElementById('mmeta').innerHTML =
    `<span>${type==='series'?'Series':'Movie'}</span>` +
    (year ? `<span>•</span><span>${year}</span>` : '') +
    rating;
  document.getElementById('mpills').innerHTML = (item.genres||[]).slice(0,4).map(g=>`<span class="mpill">${g}</span>`).join('');
  document.getElementById('moverview').textContent = item.description || '';
  document.getElementById('mhero').style.backgroundImage =
    `url(${item.background || item.poster || ''})`;

  const inLib = libImdb.has(item.id);
  const btn = document.getElementById('maddBtn');
  btn.textContent = inLib ? '✓ In Library' : '＋ Add to Plex';
  btn.className = 'mbtn mbtn-add' + (inLib ? ' added' : '');
  btn.disabled = false;

  document.getElementById('modal').classList.add('open');
}

function closeModal() { document.getElementById('modal').classList.remove('open'); }
function bgClose(e) { if (e.target === document.getElementById('modal')) closeModal(); }

async function modalAdd() {
  if (!modalItem) return;
  const btn = document.getElementById('maddBtn');
  const imdbId = modalItem.id;

  if (!imdbId || !imdbId.startsWith('tt')) {
    toast('No IMDb ID for this title', 'er'); return;
  }
  if (libImdb.has(imdbId)) { toast('Already in library', 'in'); return; }

  btn.textContent = '⏳ Fetching streams…';
  btn.disabled = true;

  const title = modalItem.name || '';
  const year  = parseInt((modalItem.releaseInfo||'').slice(0,4)) || null;
  const type  = modalItem._type === 'series' ? 'series' : 'movie';

  try {
    const r = await fetch('/api/add', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ imdb_id:imdbId, title, year, media_type:type }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || JSON.stringify(d));

    libImdb.add(imdbId);
    btn.textContent = '✓ In Library'; btn.className = 'mbtn mbtn-add added'; btn.disabled = false;

    // Update hero button
    const hm = heroItems[heroIdx];
    if (hm && hm.id === imdbId) {
      const hb = document.getElementById('heroBtn');
      hb.textContent = '✓ In Library'; hb.className = 'btn-hero btn-add added';
    }

    // Mark card
    const c = document.getElementById('c'+modalItem.id);
    if (c) c.classList.add('inlib');

    toast(`Added "${title}" — ${d.streams_found} streams${d.has_4k?' (HD+4K)':''}`, 'ok');
    await syncStubs();
  } catch(e) {
    btn.textContent = '＋ Add to Plex'; btn.disabled = false;
    toast(e.message, 'er');
  }
}

// ── Stubs / Library ────────────────────────────────────────────
async function syncStubs() {
  try {
    const r = await fetch('/api/stubs');
    const d = await r.json();
    stubs = d.stubs || [];
    libImdb = new Set(stubs.map(s => s.media_id.split('_')[0]));
  } catch {}
}

async function loadLib() {
  await syncStubs();
  allStubs = [...stubs];
  renderLib(stubs);
}

function filterLib(q) {
  const f = q ? allStubs.filter(s=>(s.title||s.media_id).toLowerCase().includes(q.toLowerCase())) : allStubs;
  renderLib(f);
}

function renderLib(items) {
  const el = document.getElementById('libGrid');
  if (!items.length) {
    el.innerHTML = `<div style="color:var(--mut);font-size:14px;grid-column:1/-1">
      No stubs yet. Browse the Home tab and add media.
    </div>`; return;
  }
  el.innerHTML = items.map(s => {
    const sc = {placeholder:'ss-ph',active:'ss-ac',error:'ss-er',resolving:'ss-rs'}[s.state]||'ss-ph';
    const qc = s.quality==='4k'?'color:var(--acc2)':'color:var(--blue)';
    return `<div>
      <div style="width:138px;height:207px;border-radius:10px;background:var(--card2);position:relative;display:flex;align-items:center;justify-content:center;font-size:38px">
        🎬
        <div style="position:absolute;top:7px;right:7px;background:rgba(0,0,0,.8);border-radius:5px;padding:2px 7px;font-size:10px;font-weight:700;${qc}">${s.quality.toUpperCase()}</div>
        <button class="del-btn" style="position:absolute;top:7px;left:7px" onclick="delStub('${s.stub_id}')" title="Delete">✕</button>
      </div>
      <div style="margin-top:8px;max-width:138px">
        <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${s.title||s.media_id}</div>
        <span class="stub-state ${sc}">${s.state}</span>
      </div>
    </div>`;
  }).join('');
}

async function delStub(id) {
  if (!confirm('Delete stub and file?')) return;
  await fetch(`/api/stubs/${id}`, {method:'DELETE'});
  toast('Stub deleted','ok');
  loadLib();
}

// ── Config ────────────────────────────────────────────────────
async function loadCfg() {
  try {
    const d = await (await fetch('/api/config')).json();
    document.getElementById('cfgChips').innerHTML =
      chip('AIOSTREAMS_URL', d.aiostreams_url, true) +
      chip('UUID',           d.uuid_set ? '✓ set':'✗ missing', d.uuid_set) +
      chip('PASSWORD',       d.password_set ? '✓ set':'✗ missing', d.password_set) +
      chip('LIBRARY_ROOT',   d.library_root, true);
    document.getElementById('wurl').textContent = `http://${location.hostname}:8001/webhook/plex`;
  } catch {}
}
function chip(l,v,ok){return`<div class="chip"><span class="cl">${l}</span><span class="cv ${ok?'ok':'er'}">${v}</span></div>`}

async function runTest() {
  const el = document.getElementById('tresult');
  el.textContent='Testing…';el.style.color='var(--mut)';
  try {
    const d = await (await fetch('/api/test')).json();
    el.style.color = d.ok?'var(--grn)':'var(--red)';
    el.textContent = d.ok ? `✓ Connected (HTTP ${d.status_code})` : `✗ ${d.error||'Failed'} — ${d.url}`;
  } catch(e) { el.style.color='var(--red)'; el.textContent='✗ '+e.message; }
}

// ── Toast ─────────────────────────────────────────────────────
function toast(msg, type='ok') {
  const el=document.createElement('div');
  el.className=`toast ${type}`;
  el.textContent=(type==='ok'?'✓ ':type==='er'?'✗ ':'ℹ ')+msg;
  document.body.appendChild(el);
  setTimeout(()=>el.remove(), 3500);
}

// ── Init ─────────────────────────────────────────────────────
(async()=>{
  await syncStubs();
  await Promise.all([
    loadHero(),
    loadRow('rowM','catalog/movie/top.json','movie'),
    loadRow('rowS','catalog/series/top.json','series'),
  ]);
})();
setInterval(syncStubs, 5000);
</script>
</body>
</html>"""


@app.get("/", response_class=HTMLResponse)
async def ui():
    return HTMLResponse(UI_HTML)


# ---------------------------------------------------------------------------
# Config + test
# ---------------------------------------------------------------------------

@app.get("/api/config")
async def get_config():
    return {
        "aiostreams_url":  os.environ.get("AIOSTREAMS_URL", "http://localhost:3001"),
        "uuid_set":        bool(os.environ.get("AIOSTREAMS_UUID")),
        "password_set":    bool(os.environ.get("AIOSTREAMS_PASSWORD")),
        "library_root":    os.environ.get("LIBRARY_ROOT", "/library"),
    }


@app.get("/api/test")
async def test_connection():
    return await _client.connection_test()


# ---------------------------------------------------------------------------
# Add media
# ---------------------------------------------------------------------------

class AddReq(BaseModel):
    imdb_id:    str
    title:      str
    year:       Optional[int] = None
    media_type: str = "movie"
    season:     Optional[int] = None
    episode:    Optional[int] = None


@app.post("/api/add")
async def add_media(req: AddReq):
    media_id   = req.imdb_id
    if req.season and req.episode:
        media_id += f"_s{req.season}e{req.episode}"
    media_type = MediaType.MOVIE if req.media_type == "movie" else MediaType.SERIES

    item = MediaItem(
        id=media_id, imdb_id=req.imdb_id, title=req.title,
        year=req.year, media_type=media_type,
        season=req.season, episode=req.episode,
    )

    try:
        item.streams = await _client.resolve_all(item)
    except Exception as exc:
        logger.error("AIOStreams query failed: %s", exc)
        raise HTTPException(status_code=502, detail=str(exc))

    if not item.streams:
        raise HTTPException(
            status_code=404,
            detail="AIOStreams returned no results with a direct URL. Check debrid config.",
        )

    stubs = await _stubs.create_stubs(item)
    return {
        "media_id": media_id, "title": item.title,
        "streams_found": len(item.streams), "has_4k": item.has_4k,
        "stubs_created": [
            {"stub_id": s.stub_id, "quality": s.quality.value, "path": s.abs_path}
            for s in stubs
        ],
    }


# ---------------------------------------------------------------------------
# Stubs
# ---------------------------------------------------------------------------

@app.get("/api/stubs")
async def list_stubs():
    all_s = _stubs.all()
    return {"count": len(all_s), "stubs": [
        {"stub_id": s.stub_id, "media_id": s.media_id, "title": s.title,
         "quality": s.quality.value, "state": s.state.value, "path": s.abs_path,
         "stream_url": (s.stream_url[:80]+"…") if s.stream_url else None}
        for s in all_s
    ]}


@app.get("/api/stubs/{stub_id}")
async def get_stub(stub_id: str):
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Not found")
    return {"stub_id": s.stub_id, "media_id": s.media_id, "title": s.title,
            "quality": s.quality.value, "state": s.state.value, "path": s.abs_path,
            "imdb_id": s.imdb_id, "aiostreams_id": s.aiostreams_id,
            "stream_url": s.stream_url, "created_at": s.created_at, "resolved_at": s.resolved_at}


@app.delete("/api/stubs/{stub_id}")
async def delete_stub(stub_id: str):
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Not found")
    p = Path(s.abs_path)
    for f in (p, p.with_suffix(".aiogateway.json")):
        try:
            if f.exists(): f.unlink()
        except Exception: pass
    _stubs._stubs.pop(stub_id, None)
    _stubs._path_index.pop(s.abs_path, None)
    return {"deleted": stub_id}


# ---------------------------------------------------------------------------
# Plex webhook
# ---------------------------------------------------------------------------

@app.post("/webhook/plex")
async def plex_webhook(request: Request):
    ct = request.headers.get("content-type", "")
    if "multipart/form-data" in ct:
        form = await request.form()
        raw = form.get("payload", "{}")
    else:
        raw = (await request.body()).decode()
    result = await _webhook.handle(raw)
    logger.info("Webhook: %s", result)
    return JSONResponse(result)


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

@app.get("/proxy/{stub_id}")
async def proxy_get(stub_id: str, request: Request):
    s = _stubs.get(stub_id)
    if not s: raise HTTPException(404, "Stub not found")
    if s.state == StubState.PLACEHOLDER: raise HTTPException(503, "Waiting for Plex play event")
    if s.state == StubState.ERROR or not s.stream_url: raise HTTPException(502, "Stream resolution failed")
    status, headers, body = await _proxy.proxy(s, request.headers.get("Range"))
    return StreamingResponse(body, status_code=status, headers=headers,
                             media_type=headers.get("Content-Type", "video/x-matroska"))


@app.head("/proxy/{stub_id}")
async def proxy_head(stub_id: str):
    s = _stubs.get(stub_id)
    if not s or not s.stream_url: raise HTTPException(404)
    status, headers = await _proxy.head(s)
    return StreamingResponse(b"", status_code=status, headers=headers)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    all_s = _stubs.all()
    return {"status": "ok", "stubs": len(all_s),
            "active": sum(1 for s in all_s if s.state == StubState.ACTIVE),
            "aiostreams_url": os.environ.get("AIOSTREAMS_URL", "not set")}
