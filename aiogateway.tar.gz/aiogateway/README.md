# AIOGateway — TorBox edition

Cinemeta browse UI, a Plex library over FUSE, auto-episodes, pending movies,
spot check, Radarr/Sonarr migration and backup. **AIOStreams finds releases**
(your addons, filters and sorting); **TorBox adds and serves them** from cached
torrents, through a TorBox layer built around the API-saving techniques from
[warpbox](https://github.com/mainlink0435/warpbox).

## Setup

1. `docker-compose.yml`: set `PLEX_URL`, `PLEX_TOKEN`.
2. `mkdir -p /docker/aiogateway && docker compose up --build`
3. Open `http://<host>:8001`, **Sign in with Plex** as the server owner, then in Config →
   Connections enter your AIOStreams URL, UUID and password (**Save & test**)
   and paste your TorBox API key
   (torbox.app → Settings → API) → **Save**. The key is checked with TorBox
   before it's stored; it's never shown again in the UI. `TORBOX_API_KEY` in
   the environment still works as a fallback — a key saved in the UI wins.
   Switching to a different account clears the cached torrent list and links;
   library files re-add their torrents to the new account automatically.
4. Add `Movies`, `Movies4K`, `Series`, `Series4K` under the mountpoint to Plex, add the webhook.
5. Recommended in Plex → Settings → Library: disable *extensive media analysis*,
   set *video preview* and *chapter thumbnails* to **Never** (they read entire files).

## AIOStreams + TorBox

- AIOStreams is queried at `/api/v1/search` with your UUID/password. Only
  torrent results (those with an `infoHash`) are used; usenet/HTTP-only results
  are skipped because TorBox can't add them as torrents.
- A release is added only if TorBox has it cached. AIOStreams' own "cached"
  flag is trusted when its service is TorBox; results checked against another
  debrid service are treated as "unknown" and verified by TorBox when added.
- Settings are tested with a real search before they're saved, the UUID and
  password are never sent back to the browser, and `AIOSTREAMS_URL/_UUID/_PASSWORD`
  still work as a fallback. Without AIOStreams, TorBox's own search is used.
- AIOStreams requests have their own rate limit (`aiostreams_per_minute`,
  default 30) since each query fans out to all your addons. Results are cached
  like before.

### Unreleased movies

Adding a movie before its release date (plus the digital delay) tracks it
without searching, and it's searched automatically after release. You can also:

- **Search anyway** (add dialog, or **Search now** on a tracked movie): runs a
  fresh search right away and adds it if TorBox has something cached. Your
  exclude words still apply, so add `CAM`, `TS`, `TELESYNC` there if you don't
  want early low-quality releases.
- **Show releases**: lists everything AIOStreams finds right now, released or
  not, with resolution, size, seeders and whether TorBox has it cached or it's
  excluded by your filters. Admins can add a specific release; it replaces
  whatever is in that quality tier.

## Plex library scans

New, rebound and removed files are announced to Plex with partial scans, in
batches rather than one per file:

- A scan is sent once nothing new has arrived for the **quiet period**
  (default 30 s), or at most every **max wait** (default 5 min) during a long
  add, so a big series still shows up in Plex as it goes.
- Several seasons of one show share a single scan of the show folder.
- The list of Plex libraries is looked up once an hour, and early only if a
  folder doesn't belong to any known library.

Adding a 10-season, 250-episode show sends 2 scans instead of ~90. Tune both
values in Config → Connections → Plex setup; the API saver stats show scans
sent vs. changes queued.

## Users & sign-in (Plex)

People sign in to the web UI with their **Plex account** ("Sign in with Plex").
Plex's own sign-in page opens in a popup, so nobody's Plex password ever
reaches this app.

**Who can sign in:** the owner of the Plex server at `PLEX_URL` and anyone
that server is shared with (friends and Plex Home users). Everyone else is
refused with a message to ask the owner to share the server. `PLEX_URL` must
be reachable from the container; Config → Connections shows whether the
sign-in server was found. (`PLEX_SERVER_ID` can override the detected server.)

| Role | Can |
|---|---|
| **Admin** | everything: Config, Migrate, Backup/Restore, AIOStreams + TorBox settings, deleting titles/seasons, forcing HD/4K scans, choosing streams or specific releases, spot check, repair, managing users |
| **User** | browse, search, calendar, view the library, see available releases, and request titles — add movies (including "Search anyway"), series, seasons and episodes, and turn on "watch for new seasons" |

- The Plex **server owner is always an admin** and can't be demoted or blocked.
  Everyone else starts as a user the first time they sign in; admins can
  promote them in **Config → Users**.
- **Block** keeps someone out even while they have Plex access. **Remove**
  forgets them and signs them out (they can sign in again as a user).
  Changing a role or blocking signs the person out.
- Server access is **re-checked with Plex every 6 hours** while someone is
  signed in; unsharing the server in Plex signs them out. If plex.tv is down,
  existing sessions keep working.
- Sessions are HttpOnly cookies lasting 30 days of inactivity. Each person's
  Plex token is kept server-side (0600 file) only to re-check access, and is
  never sent to the browser. Accounts live in `/docker/aiogateway/aiogateway_users.json`
  (not included in backups).
- Permissions are enforced on every request; any endpoint not explicitly
  opened to users is admin-only. The Plex webhook and `/health` need no login.
- Serving the UI over HTTPS (reverse proxy)? Set `AIOGATEWAY_COOKIE_SECURE=1`.

**From the host:**

```
docker exec -it aiogateway python -m gateway.auth list
docker exec -it aiogateway python -m gateway.auth set-role <username|email> admin|user
docker exec -it aiogateway python -m gateway.auth enable <username|email>
docker exec -it aiogateway python -m gateway.auth signout-all
```

## No placeholders — cached torrents only

Nothing is added to the library until it is a real file inside a torrent that
is **cached on TorBox**. When you add a movie or a season, AIOGateway searches
TorBox, adds the best cached torrent to your account (`add_only_if_cached`),
picks the exact file (episodes out of a season pack, samples skipped) and only
then creates the entry. Plex's very first scan sees the real file, real size,
real audio/subtitle tracks. There are no stub `.mkv` files, no "- Ready"
renames, no resolve-on-play, no prewarm, no TTL reverts.

| Situation | What happens |
|---|---|
| Add a title | search (cached 6h) → add cached torrent → pin file. Torrents already in your account (e.g. the season pack an earlier episode came from) are preferred and cost nothing. The CDN link isn't requested until the first read. |
| Nothing cached yet | no entry. Movies are tracked as pending; missing episodes are picked up by auto-episodes / spot check once something is cached. |
| Play / seek / Plex scan | real bytes via the cached link; head/tail from the probe cache |
| Link expires | refreshed in place (1 API call), same file |
| File stops working (TorBox dropped the torrent) | read returns an I/O error (never fake data), entry is marked **repairing** but stays in Plex. The repair loop re-checks it, and if it's really gone swaps in another cached torrent of the same quality **at the same Plex path**. |
| TorBox has nothing cached left for it | entry removed; the normal sweeps re-add it when something appears |

Repair runs every `repair_interval_minutes` (Config → Streams → Library
repair, default 10) and is woken immediately by a failed read or by Plex
playing a broken item. `POST /api/repair/run` forces a pass.

## The API saver (Config → Streams → TorBox API saver)

- **One shared, blocking rate limiter** (default 250/min main API, 120/min
  search, 60 adds/hour). Nothing fails fast — calls queue. **Playback jumps
  the queue** ahead of scans, sweeps, spot check and migration. A 429 pauses
  the lane for `torbox_429_backoff_seconds`.
- **SQLite caches (WAL)** at `<mountpoint>_data/torbox_cache.sqlite3`: CDN
  links, search results, and a mirror of your account's torrent list (synced
  every 15 min).
- **Negative cache**: failed link fetches remembered 30s; "not cached on
  TorBox" remembered 6h so dead candidates aren't retried every scan.
- **Per-torrent circuit breaker** with escalating quarantine; a TorBox-wide
  outage doesn't escalate items.
- **Hang/poll**: while TorBox is rate limiting, a Plex read is held (up to
  `torbox_hang_max_seconds`) rather than failing, so Plex sees a slow disk.
- **Plex probe cache**: the first/last 16 MB of every active file are kept on
  disk (`<mountpoint>_data/probe_cache`, 4 GB cap, LRU). Plex scanning,
  Analyze, intro/credit detection and header reads never hit TorBox after the
  first time — which also avoids looking like "access" to TorBox's
  inactivity/retention checks.
- **Smart redirect**: `/proxy/{stub}` answers a full-file GET (no Range) with a
  302 straight to the CDN.
- **Transient ≠ dead**: a stub is only removed as "all candidates dead" when
  TorBox definitively says no (not cached / no matching file / dead link) —
  never because of a rate limit.

Live counters: Config → Streams (or `GET /api/torbox/stats`).
Other endpoints: `POST /api/torbox/sync-now`, `POST /api/torbox/clear-search-cache[?imdb_id=tt…]`.

## Upgrading an existing install

Settings and library records carry over. Entries from the placeholder design
(and anything restored from a backup) load as **unbound**: hidden from Plex
while the repair loop binds each one to a cached torrent in the background,
then they appear at their normal paths. Titles TorBox has nothing cached for
are dropped. The old placeholder `.mkv` files in `<mountpoint>_data` are
deleted on startup. Because the " - Ready" suffix is gone, Plex will see
previously resolved files at their plain names after its next scan — run a
library scan once after upgrading. The removed settings (`active_ttl_days`,
`prewarm_*`, `dead_stub_max_errors`, `plex_analyze_cooldown_hours`) are
dropped automatically.
