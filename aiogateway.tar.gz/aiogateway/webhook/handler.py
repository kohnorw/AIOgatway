"""webhook/handler.py — Handles Plex webhook play events."""
from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from gateway.stub_manager import StubManager
    from gateway.aiostreams_client import AIOStreamsClient

logger = logging.getLogger("aiogateway.webhook")
PLAY_EVENTS = {"media.play", "media.resume"}


class PlexWebhookHandler:
    def __init__(self, stubs: "StubManager", client: "AIOStreamsClient") -> None:
        self.stubs  = stubs
        self.client = client

    async def handle(self, raw: str) -> dict:
        try:
            payload = json.loads(raw)
        except Exception:
            return {"action": "ignored", "reason": "invalid json"}

        event = payload.get("event", "")
        if event not in PLAY_EVENTS:
            return {"action": "ignored", "event": event}

        file_path = self._file_path(payload)
        if not file_path:
            return {"action": "ignored", "reason": "no file path"}

        stub = self.stubs.by_path(file_path)
        if not stub:
            return {"action": "ignored", "reason": f"unknown path: {file_path}"}

        logger.info("Play event: %s | stub=%s quality=%s", event, stub.stub_id, stub.quality.value)

        if stub.stream_url:
            return {"action": "already_active", "stub_id": stub.stub_id}

        self.stubs.set_resolving(stub.stub_id)

        try:
            stream_obj = await self._resolve(stub)
        except Exception as exc:
            logger.error("Resolve failed for %s: %s", stub.stub_id, exc)
            self.stubs.set_error(stub.stub_id)
            return {"action": "error", "stub_id": stub.stub_id, "error": str(exc)}

        if not stream_obj or not stream_obj.url:
            self.stubs.set_error(stub.stub_id)
            return {"action": "error", "stub_id": stub.stub_id, "error": "no url"}

        self.stubs.set_active(stub.stub_id, stream_obj.url, stream_obj.request_headers)
        logger.info("Resolved stub %s → %s…", stub.stub_id, stream_obj.url[:60])
        return {"action": "resolved", "stub_id": stub.stub_id, "quality": stub.quality.value}

    def _file_path(self, payload: dict) -> str | None:
        try:
            return payload["Metadata"]["Media"][0]["Part"][0]["file"]
        except (KeyError, IndexError, TypeError):
            return None

    async def _resolve(self, stub):
        from gateway.models import MediaItem, MediaType, Quality
        media_type = MediaType.MOVIE if stub.aiostreams_type == "movie" else MediaType.SERIES
        parts = stub.aiostreams_id.split(":")
        item = MediaItem(
            id=stub.media_id, imdb_id=stub.imdb_id, title=stub.title,
            year=None, media_type=media_type,
            season=int(parts[1]) if len(parts) >= 3 else None,
            episode=int(parts[2]) if len(parts) >= 3 else None,
        )
        return await self.client.best_for_quality(item, stub.quality)
