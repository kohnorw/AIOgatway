"""webhook/handler.py — Handles Plex webhook play events."""
from __future__ import annotations

import json
import logging
import os
import re
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from gateway.stub_manager import StubManager
    from gateway.aiostreams_client import AIOStreamsClient

logger = logging.getLogger("aiogateway.webhook")
PLAY_EVENTS = {"media.play", "media.resume", "media.play.start"}


class PlexWebhookHandler:
    def __init__(self, stubs: "StubManager", client: "AIOStreamsClient") -> None:
        self.stubs  = stubs
        self.client = client

    async def handle(self, raw: str) -> dict:
        try:
            payload = json.loads(raw)
        except Exception:
            return {"action": "ignored", "reason": "invalid json"}

        event = payload.get("event", "")
        logger.info("Plex event: %s", event)

        if event not in PLAY_EVENTS:
            return {"action": "ignored", "event": event}

        meta = payload.get("Metadata", {})

        # ── Strategy 1: file path from Media.Part (standard) ────────────────
        stub = self._stub_by_file_path(payload)

        # ── Strategy 2: match by IMDb ID + season/episode from Guid array ───
        if not stub:
            stub = self._stub_by_guid(meta)

        # ── Strategy 3: match by ratingKey via Plex API ─────────────────────
        if not stub:
            rating_key = meta.get("ratingKey")
            if rating_key:
                stub = await self._stub_by_rating_key(rating_key, meta)

        if not stub:
            logger.warning(
                "No stub matched for play event. "
                "title=%r type=%r guid=%r season=%r ep=%r",
                meta.get("title"), meta.get("type"),
                meta.get("Guid"), meta.get("parentIndex"), meta.get("index")
            )
            return {"action": "ignored", "reason": "no matching stub"}

        logger.info("Matched stub=%s quality=%s", stub.stub_id, stub.quality.value)

        if stub.stream_url:
            return {"action": "already_active", "stub_id": stub.stub_id}

        self.stubs.set_resolving(stub.stub_id)

        try:
            stream_obj = await self._resolve(stub)
        except Exception as exc:
            logger.error("Resolve failed for %s: %s", stub.stub_id, exc)
            self.stubs.set_error(stub.stub_id)
            return {"action": "error", "stub_id": stub.stub_id, "error": str(exc)}

        if not stream_obj or not stream_obj.url:
            self.stubs.set_error(stub.stub_id)
            return {"action": "error", "stub_id": stub.stub_id, "error": "no url"}

        self.stubs.set_active(stub.stub_id, stream_obj.url, stream_obj.request_headers)
        logger.info("Resolved stub %s → %s…", stub.stub_id, stream_obj.url[:60])
        return {"action": "resolved", "stub_id": stub.stub_id, "quality": stub.quality.value}

    # ── Matching strategies ──────────────────────────────────────────────────

    def _stub_by_file_path(self, payload: dict):
        """Standard: Plex includes Media[0].Part[0].file in webhook."""
        try:
            path = payload["Metadata"]["Media"][0]["Part"][0]["file"]
            return self.stubs.by_path(path) if path else None
        except (KeyError, IndexError, TypeError):
            return None

    def _stub_by_guid(self, meta: dict):
        """
        Match using Guid array + parentIndex (season) + index (episode).
        Plex sends Guid entries like:
          [{"id": "imdb://tt1234567"}, {"id": "tmdb://12345"}, ...]
        """
        guids = meta.get("Guid") or []
        imdb_id = None
        for g in guids:
            gid = g.get("id", "")
            if gid.startswith("imdb://"):
                imdb_id = gid.replace("imdb://", "").strip()
                break

        if not imdb_id:
            # Also try the top-level guid field (older Plex versions)
            top_guid = meta.get("guid", "")
            m = re.search(r'tt\d+', top_guid)
            if m:
                imdb_id = m.group(0)

        if not imdb_id:
            return None

        media_type = meta.get("type", "")  # "movie", "episode"
        season  = meta.get("parentIndex")  # season number for episodes
        episode = meta.get("index")        # episode number

        logger.info(
            "Guid match attempt: imdb=%s type=%s season=%s ep=%s",
            imdb_id, media_type, season, episode
        )

        # Find matching stubs by imdb_id
        candidates = [s for s in self.stubs.all() if s.imdb_id == imdb_id]
        if not candidates:
            return None

        if media_type == "episode" and season is not None and episode is not None:
            # Match specific episode stub
            ep_id = f"{imdb_id}:{season}:{episode}"
            for s in candidates:
                if s.aiostreams_id == ep_id:
                    return s
            return None
        elif media_type == "movie":
            # Return first (should only be one per quality — pick HD preference)
            hd = [s for s in candidates if s.quality.value == "hd"]
            return hd[0] if hd else candidates[0]

        return None

    async def _stub_by_rating_key(self, rating_key: str, meta: dict):
        """
        Last resort: query Plex API directly for the item's file path.
        Requires PLEX_URL and PLEX_TOKEN env vars.
        """
        plex_url   = os.environ.get("PLEX_URL", "")
        plex_token = os.environ.get("PLEX_TOKEN", "")
        if not plex_url or not plex_token:
            return None

        import aiohttp
        try:
            url = f"{plex_url}/library/metadata/{rating_key}"
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    headers={"X-Plex-Token": plex_token, "Accept": "application/json"},
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    if resp.status != 200:
                        return None
                    data = await resp.json()
                    items = (data.get("MediaContainer", {})
                             .get("Metadata", [{}]))
                    if not items:
                        return None
                    path = (items[0].get("Media", [{}])[0]
                            .get("Part", [{}])[0]
                            .get("file"))
                    if path:
                        logger.info("Plex API file path: %s", path)
                        return self.stubs.by_path(path)
        except Exception as exc:
            logger.warning("Plex API fallback failed: %s", exc)
        return None

    # ── Stream resolution ────────────────────────────────────────────────────

    async def _resolve(self, stub):
        from gateway.models import MediaItem, MediaType
        media_type = MediaType.MOVIE if stub.aiostreams_type == "movie" else MediaType.SERIES
        parts = stub.aiostreams_id.split(":")
        item = MediaItem(
            id=stub.media_id, imdb_id=stub.imdb_id, title=stub.title,
            year=None, media_type=media_type,
            season=int(parts[1]) if len(parts) >= 3 else None,
            episode=int(parts[2]) if len(parts) >= 3 else None,
        )
        return await self.client.best_for_quality(item, stub.quality)
