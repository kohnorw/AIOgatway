"""webhook/handler.py — Handles Plex webhook play events."""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from gateway.stub_manager import StubManager
    from gateway.aiostreams_client import AIOStreamsClient

logger = logging.getLogger("aiogateway.webhook")
PLAY_EVENTS = {"media.play", "media.resume", "media.play.start"}


class PlexWebhookHandler:
    def __init__(
        self, stubs: "StubManager", client: "AIOStreamsClient",
        on_resolve_start=None, on_resolve_end=None, resolver=None,
    ) -> None:
        self.stubs  = stubs
        self.client = client
        # All link finding goes through gateway/resolver.py. Built here if
        # the caller didn't pass one, so the class stays usable on its own.
        if resolver is None:
            from gateway.resolver import LinkResolver
            resolver = LinkResolver(stubs, client, on_resolve_start, on_resolve_end)
        self.resolver = resolver
        # Called around just the _resolve() call below (not the whole
        # webhook request — stop/pause events and the already-resolved
        # fast path never need to pause anything) so every background
        # scan loop can pause for exactly as long as a real Plex playback
        # resolve takes, then resume immediately once it's done. Optional
        # so this class stays usable/testable without main.py's specific
        # coordination wiring.
        self._on_resolve_start = on_resolve_start or (lambda: None)
        self._on_resolve_end   = on_resolve_end or (lambda: None)

        # stub_id → last time we triggered a Plex analyze for it. Plex's
        # Analyze step actually reads chunks of the file to determine
        # audio/subtitle/bitrate info — for a FUSE-proxied debrid stream
        # that means real download traffic, not a local disk read. This
        # cooldown (see plex_analyze_cooldown_hours) stops repeat plays of
        # the same episode from re-downloading data on every single play
        # once it's already been analyzed correctly. In-memory only — a
        # restart just means the next play re-analyzes once, which is a
        # fine, cheap tradeoff for not persisting this.
        self._last_analyzed: dict = {}

    def _maybe_analyze(self, stub, rating_key: Optional[str]) -> None:
        """Triggers a Plex analyze for this ratingKey (from the webhook
        payload's Metadata — the item Plex is telling us it's playing),
        unless one already ran for this stub within
        plex_analyze_cooldown_hours — see self._last_analyzed above for
        why this cooldown exists at all."""
        if not rating_key:
            return
        try:
            from gateway import settings as _settings
            cooldown_hours = _settings.get("plex_analyze_cooldown_hours", 24) or 0
        except Exception:
            cooldown_hours = 24

        now = time.time()
        if cooldown_hours:
            last = self._last_analyzed.get(stub.stub_id, 0)
            if (now - last) < cooldown_hours * 3600:
                return   # analyzed recently enough — skip, save the bandwidth

        try:
            from gateway.plex_scan import analyze_item_async
            analyze_item_async(rating_key)
            self._last_analyzed[stub.stub_id] = now
        except Exception as exc:
            logger.warning("Could not trigger Plex analyze for %s: %s", rating_key, exc)

    @staticmethod
    def _prewarm_enabled() -> bool:
        """
        The "Keep new content active" toggle (prewarm_enabled). Governs
        every path that resolves a stub nobody asked for — including the
        two play-triggered ones below, which for a long time ran
        unconditionally and were the reason turning the setting off still
        left episodes going active on their own.

        Also requires the active-file TTL to be enabled, mirroring
        main.py's _prewarm_enabled: with active_ttl_enabled off nothing
        ever reverts a prewarmed stub, so speculatively resolving the
        next few episodes would hold their links permanently. The play
        that triggered this is a real play and keeps its own link either
        way — it's only the look-ahead that's suppressed.

        Defaults to True on a settings failure for the toggle itself, but
        False for a missing/disabled TTL, since the default is enabled
        and a reading that says otherwise is more likely to be
        deliberate than accidental.
        """
        try:
            from gateway import settings as _settings
        except Exception:
            return True
        try:
            if not bool(_settings.get("prewarm_enabled", True)):
                return False
            return _settings.get_effective_ttl_days() > 0
        except Exception:
            return True

    async def handle(self, raw: str) -> dict:
        try:
            payload = json.loads(raw)
        except Exception:
            return {"action": "ignored", "reason": "invalid json"}

        event = payload.get("event", "")
        logger.info("Plex event: %s", event)

        if event not in PLAY_EVENTS:
            return {"action": "ignored", "event": event}

        meta = payload.get("Metadata", {})

        # ── Strategy 1: virtual FUSE path from Media.Part ───────────────────
        # Most reliable when present: the path itself contains "Movies4K" vs
        # "Movies", so quality is unambiguous. But Plex's media.play payload
        # doesn't always include the Media/Part array.
        stub = self._stub_by_fuse_path(payload)

        # ── Strategy 2: ratingKey via Plex API ──────────────────────────────
        # Also file-path-based (queries Plex's own metadata endpoint, which
        # reliably returns Media/Part even when the webhook payload omits
        # it), so still unambiguous about quality. Tried BEFORE the GUID
        # guess below — this used to run last, which meant the unreliable
        # GUID-based guess always "succeeded" first (it never returns None
        # once any candidate exists) and this never got a chance to run.
        if not stub:
            rating_key = meta.get("ratingKey")
            if rating_key:
                stub = await self._stub_by_rating_key(rating_key, meta)

        # ── Strategy 3: match by IMDb ID + season/episode from Guid array ───
        # Last resort. When HD and 4K stubs share the same Plex library
        # section, librarySectionID can't disambiguate them, and Plex's
        # self-reported videoResolution reflects the small stub file's own
        # encoded resolution (not the real quality tier) until the stream
        # actually resolves — so this can guess wrong. Only used if both
        # file-path-based strategies above failed to find anything.
        if not stub:
            stub = self._stub_by_guid(meta)

        if not stub:
            logger.warning(
                "No stub matched for play event. "
                "title=%r type=%r guid=%r season=%r ep=%r",
                meta.get("title"), meta.get("type"),
                meta.get("Guid"), meta.get("parentIndex"), meta.get("index")
            )
            return {"action": "ignored", "reason": "no matching stub"}

        logger.info("Matched stub=%s quality=%s state=%s", stub.stub_id, stub.quality.value, stub.state.value)

        # The placeholder switch: a placeholder (or errored) stub gets a
        # freshly found, probed link right now; an active stub whose link
        # is older than link_refresh_hours gets a background refresh; a
        # fresh active stub is left alone. See gateway/resolver.py.
        result = await self.resolver.on_play(stub.stub_id)
        action = result.get("action")

        if action in ("resolved", "already_active", "refreshing"):
            # Plex cached the placeholder's tracks/bitrate; analyze makes it
            # re-read the real file (cooldown-limited, since analysis pulls
            # real data through the debrid link).
            self._maybe_analyze(stub, meta.get("ratingKey"))
            if stub.media_type.value == "series":
                asyncio.create_task(self._prewarm_next(stub))

        return result

    # ── Pre-warm next N episodes ─────────────────────────────────────────────

    @staticmethod
    def _ttl_expired(stub) -> bool:
        """True if this stub already held a link and lost it to the TTL —
        look-ahead leaves those for a real play (prewarm_skip_ttl_expired)."""
        if not getattr(stub, "ttl_expired_at", None):
            return False
        try:
            from gateway import settings as _settings
            return bool(_settings.get("prewarm_skip_ttl_expired", True))
        except Exception:
            return True

    async def _prewarm_next(self, played_stub, count: Optional[int] = None) -> None:
        """
        Look-ahead: switch the next `lookahead_episodes` placeholders of the
        same show/quality right after one is played, so a binge doesn't hit
        a placeholder on every episode. Each one goes through the normal
        placeholder switch (resolver.activate) at this moment, so the links
        are exactly as fresh as the play that triggered them.

        Gated on prewarm_enabled + an enabled TTL (_prewarm_enabled).
        Replaces the old whole-season "pack fast-track", which resolved
        every episode of a season at once — links that were then days old
        by the time most of them were watched.
        """
        if not self._prewarm_enabled():
            return
        if count is None:
            try:
                from gateway import settings as _settings
                count = int(_settings.get("lookahead_episodes", 2) or 0)
            except Exception:
                count = 2
        if count <= 0 or played_stub.season is None or played_stub.episode is None:
            return

        here = (played_stub.season, played_stub.episode)
        upcoming = sorted(
            (s for s in self.stubs.all()
             if s.imdb_id == played_stub.imdb_id
             and s.quality == played_stub.quality
             and s.season is not None and s.episode is not None
             and (s.season, s.episode) > here),
            key=lambda s: (s.season, s.episode),
        )[:count]

        for s in upcoming:
            if s.stream_url or self._ttl_expired(s) or self.stubs.in_error_cooldown(s.stub_id):
                continue
            try:
                await self.resolver.activate(s.stub_id, "look-ahead")
            except Exception as exc:
                logger.warning("Look-ahead failed for %s: %s", s.aiostreams_id, exc)

    # ── Matching strategies ──────────────────────────────────────────────────

    def _stub_by_fuse_path(self, payload: dict):
        """
        Match using the virtual FUSE path Plex reports in Media[0].Part[0].file.
        e.g. /docker/aiogateway/mnt/Movies/Title (2026)/Title (2026).mkv

        We ask fuse_fs to derive each stub's virtual path and compare.
        """
        try:
            path = payload["Metadata"]["Media"][0]["Part"][0]["file"]
            if not path:
                return None
        except (KeyError, IndexError, TypeError):
            return None

        try:
            from gateway.fuse_fs import _fs_instance
            if _fs_instance is None:
                return None
            mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt").rstrip("/")
            # Strip the mountpoint prefix to get the virtual path
            if path.startswith(mountpoint):
                virtual_path = path[len(mountpoint):]
            else:
                virtual_path = path
            # The FUSE path index maps both the placeholder name and the
            # " - Ready" name of every stub — an O(1) lookup instead of
            # formatting two paths for every stub in the library.
            return _fs_instance._stub_for_path(virtual_path)
        except Exception as exc:
            logger.warning("fuse path match failed: %s", exc)
        return None

    def _stub_by_guid(self, meta: dict):
        """
        Match using Guid array + parentIndex (season) + index (episode).
        """
        guids = meta.get("Guid") or []
        imdb_id = None
        for g in guids:
            gid = g.get("id", "")
            if gid.startswith("imdb://"):
                imdb_id = gid.replace("imdb://", "").strip()
                break

        if not imdb_id:
            top_guid = meta.get("guid", "")
            m = re.search(r'tt\d+', top_guid)
            if m:
                imdb_id = m.group(0)

        if not imdb_id:
            return None

        media_type = meta.get("type", "")
        season  = meta.get("parentIndex")
        episode = meta.get("index")

        logger.info(
            "Guid match attempt: imdb=%s type=%s season=%s ep=%s",
            imdb_id, media_type, season, episode
        )

        candidates = [s for s in self.stubs.all() if s.imdb_id == imdb_id]
        if not candidates:
            return None

        if media_type == "episode" and season is not None and episode is not None:
            ep_id = f"{imdb_id}:{season}:{episode}"
            # Multiple stubs can share the same aiostreams_id only if they
            # differ in quality (HD vs 4K stub created separately) — but
            # aiostreams_id doesn't encode quality, so when more than one
            # candidate matches, disambiguate by library section the same
            # way as the movie branch below.
            ep_candidates = [s for s in candidates if s.aiostreams_id == ep_id]
            if not ep_candidates:
                return None
            if len(ep_candidates) == 1:
                return ep_candidates[0]
            return self._disambiguate_by_section(ep_candidates, meta)
        elif media_type == "movie":
            return self._disambiguate_by_section(candidates, meta)

        return None

    def _disambiguate_by_section(self, candidates: list, meta: dict):
        """
        Last-resort quality guess, only reached if neither the FUSE-path nor
        Plex-API-by-ratingKey strategies could determine the real file path.

        Tries librarySectionID first (only useful if HD and 4K are split
        into separate Plex library sections — if they share one section,
        as is common, this can't disambiguate and falls through to the
        videoResolution guess below, which itself is unreliable since it
        reflects the stub file's own small encoded resolution rather than
        the real quality tier until the stream actually resolves).

        Every path through here logs clearly, since reaching this function
        at all means the reliable strategies above failed — see
        _stub_by_rating_key for why that's usually a PLEX_URL/PLEX_TOKEN
        configuration problem, not something wrong with this logic itself.
        """
        logger.warning(
            "Falling back to ambiguous HD/4K guess for %s — the reliable "
            "FUSE-path and Plex-API-ratingKey strategies both failed to "
            "resolve a file path. Check PLEX_URL/PLEX_TOKEN if this happens "
            "often, especially for 4K plays.", meta.get("title", "?")
        )
        section_id = meta.get("librarySectionID")
        if section_id is not None:
            try:
                from gateway.plex_scan import folder_for_section_id
                folder = folder_for_section_id(int(section_id))
                if folder:
                    is_4k_section = "4k" in folder.lower()
                    logger.info("librarySectionID=%s → folder=%s → 4k=%s",
                               section_id, folder, is_4k_section)
                    if is_4k_section:
                        k4 = [s for s in candidates if s.quality.value == "4k"]
                        if k4:
                            return k4[0]
                    else:
                        hd = [s for s in candidates if s.quality.value == "hd"]
                        if hd:
                            return hd[0]
            except Exception as exc:
                logger.warning("Section-based quality disambiguation failed: %s", exc)

        # Fallback: videoResolution metadata (unreliable pre-resolution, but
        # better than nothing if PLEX_URL/PLEX_TOKEN aren't configured or
        # the section lookup failed).
        media_list = meta.get("Media") or []
        is_4k = False
        if media_list:
            res = str(media_list[0].get("videoResolution", "")).lower()
            is_4k = res in ("4k", "2160", "uhd") or "2160" in res
        logger.warning(
            "Section-based disambiguation inconclusive for %s — guessing "
            "from videoResolution=%r (is_4k=%s). This reflects the STUB "
            "placeholder's own encoded resolution pre-resolve, not the "
            "real quality tier, so it's biased toward guessing HD.",
            meta.get("title", "?"),
            media_list[0].get("videoResolution") if media_list else None,
            is_4k,
        )
        if is_4k:
            k4 = [s for s in candidates if s.quality.value == "4k"]
            return k4[0] if k4 else candidates[0]
        else:
            hd = [s for s in candidates if s.quality.value == "hd"]
            return hd[0] if hd else candidates[0]

    async def _stub_by_rating_key(self, rating_key: str, meta: dict):
        """
        Query Plex's own metadata API for the real file path (reliably
        includes Media/Part even when the webhook payload itself omits it).
        Requires PLEX_URL/PLEX_TOKEN to be configured.

        This is the ONLY strategy that's unambiguous about HD vs 4K without
        relying on librarySectionID or videoResolution guesses (see
        _disambiguate_by_section) — so every silent failure here is a
        silent step down to a guess that's frequently wrong for 4K
        specifically. All failure modes are logged clearly for exactly
        that reason, not just as debug noise.
        """
        plex_url   = os.environ.get("PLEX_URL", "")
        plex_token = os.environ.get("PLEX_TOKEN", "")
        if not plex_url or not plex_token or "your-plex" in plex_url or "your-plex" in plex_token:
            logger.warning(
                "PLEX_URL/PLEX_TOKEN not configured (still using the docker-compose.yml "
                "placeholder values, or unset) — the reliable ratingKey-based stub match "
                "is disabled, so HD/4K disambiguation falls back to a guess that's known "
                "to be biased toward HD. Set real values to fix this."
            )
            return None

        import aiohttp
        try:
            url = f"{plex_url}/library/metadata/{rating_key}"
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    headers={"X-Plex-Token": plex_token, "Accept": "application/json"},
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    if resp.status != 200:
                        logger.warning("Plex API metadata lookup returned HTTP %d for ratingKey=%s",
                                       resp.status, rating_key)
                        return None
                    data = await resp.json()
                    items = (data.get("MediaContainer", {}).get("Metadata", [{}]))
                    if not items:
                        logger.warning("Plex API metadata lookup returned no items for ratingKey=%s", rating_key)
                        return None
                    path = (items[0].get("Media", [{}])[0]
                            .get("Part", [{}])[0]
                            .get("file"))
                    if not path:
                        logger.warning("Plex API metadata for ratingKey=%s had no file path", rating_key)
                        return None
                    logger.info("Plex API file path: %s", path)
                    matched = self._stub_by_fuse_path(
                        {"Metadata": {"Media": [{"Part": [{"file": path}]}]}}
                    )
                    if matched is None:
                        logger.warning(
                            "Plex API returned file path %s but it didn't match any known stub", path
                        )
                    return matched
        except Exception as exc:
            logger.warning("Plex API fallback failed for ratingKey=%s: %s", rating_key, exc)
        return None
