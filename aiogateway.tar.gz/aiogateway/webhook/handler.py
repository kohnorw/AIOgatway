"""
webhook/handler.py
~~~~~~~~~~~~~~~~~~
The Plex webhook, which is the one signal that means a person pressed
play.

Everything else — open(), read patterns, scanner activity — is ambiguous
at the filesystem layer, which is why activation lives here and nowhere
else.

Matching a Plex event to a library entry, in order of reliability:

  1. The file path from Media.Part. Unambiguous when present, because
     the path itself says Movies4K or Movies, so the quality is settled.
     Plex doesn't always include the Media array, though.
  2. The GUID, which carries the IMDb id and, for episodes, the season
     and episode numbers.
  3. Title, year and episode numbers from the metadata.

Quality only has to be guessed at step 3. When it can't be determined,
the activated entry is whichever of the two the library holds, preferring
one that is already activated — rewatching is far more common than a 4K
file quietly standing in for an HD one.
"""
from __future__ import annotations

import json
import logging
import re
import time
from typing import Optional

from gateway import plex, settings
from gateway.library import Library
from gateway.models import MediaType, Quality
from gateway.service import MediaService

logger = logging.getLogger("aiogateway.webhook")

PLAY_EVENTS = {"media.play", "media.resume", "media.scrobble"}

_IMDB = re.compile(r"(tt\d{7,10})")
_SEASON_EPISODE = re.compile(r"[:/](\d{1,3})[:/](\d{1,4})\s*$")


class PlexWebhook:
    def __init__(self, library: Library, media: MediaService) -> None:
        self.library = library
        self.media = media
        # entry_id -> when Plex last analysed it. In memory only: after a
        # restart the next play re-analyses once, which is a cheap thing
        # to get wrong.
        self._analysed: dict[str, float] = {}

    async def handle(self, raw: str) -> dict:
        try:
            payload = json.loads(raw)
        except Exception:
            return {"action": "ignored", "reason": "payload wasn't JSON"}

        event = payload.get("event", "")
        if event not in PLAY_EVENTS:
            return {"action": "ignored", "event": event}

        meta = payload.get("Metadata") or {}
        entry = (self._by_path(meta)
                 or self._by_guid(meta)
                 or self._by_title(meta))

        if entry is None:
            logger.info("Play event didn't match anything in the library: %r",
                        meta.get("title") or meta.get("grandparentTitle"))
            return {"action": "no match", "event": event}

        logger.info("Play: %s [%s]", entry.display_name, entry.quality.value)
        activated = await self.media.activate(entry.entry_id)
        self._maybe_analyse(entry.entry_id, meta.get("ratingKey"))

        return {
            "action": "activated" if activated else "activation failed",
            "entry_id": entry.entry_id,
            "title": entry.display_name,
            "quality": entry.quality.value,
        }

    # ── matching ────────────────────────────────────────────────────
    def _by_path(self, meta: dict):
        for media in meta.get("Media") or []:
            for part in media.get("Part") or []:
                path = part.get("file")
                if not path:
                    continue
                for prefix in ("/Movies4K/", "/Movies/", "/Series4K/", "/Series/"):
                    index = path.find(prefix)
                    if index != -1:
                        entry = self.library.by_path(path[index:])
                        if entry is not None:
                            return entry
        return None

    def _by_guid(self, meta: dict):
        guids = [meta.get("guid", "")]
        guids += [g.get("id", "") for g in meta.get("Guid") or []]

        imdb_id = None
        for guid in guids:
            match = _IMDB.search(guid or "")
            if match:
                imdb_id = match.group(1)
                break
        if not imdb_id:
            return None

        season = episode = None
        for guid in guids:
            match = _SEASON_EPISODE.search(guid or "")
            if match:
                season, episode = int(match.group(1)), int(match.group(2))
                break
        if season is None:
            season = _as_int(meta.get("parentIndex"))
            episode = _as_int(meta.get("index"))

        return self._pick(imdb_id, season, episode)

    def _by_title(self, meta: dict):
        title = meta.get("grandparentTitle") or meta.get("title") or ""
        if not title:
            return None
        season = _as_int(meta.get("parentIndex"))
        episode = _as_int(meta.get("index"))
        wanted = title.strip().lower()

        matches = []
        for entry in self.library.all():
            name = (entry.show_title or entry.title).strip().lower()
            if name != wanted:
                continue
            if entry.media_type == MediaType.SERIES:
                if season is not None and entry.season != season:
                    continue
                if episode is not None and entry.episode != episode:
                    continue
            matches.append(entry)
        return _prefer(matches)

    def _pick(self, imdb_id: str, season: Optional[int], episode: Optional[int]):
        candidates = []
        for entry in self.library.for_imdb(imdb_id):
            if entry.media_type == MediaType.SERIES:
                if season is not None and entry.season != season:
                    continue
                if episode is not None and entry.episode != episode:
                    continue
            candidates.append(entry)
        return _prefer(candidates)

    # ── analysis ────────────────────────────────────────────────────
    def _maybe_analyse(self, entry_id: str, rating_key: Optional[str]) -> None:
        """Plex's analysis reads chunks of the file, which here means real
        traffic over a debrid CDN rather than a local disk read. Worth
        doing once so the audio and subtitle tracks are right; not worth
        repeating every time someone rewatches an episode."""
        if not rating_key:
            return
        cooldown = float(settings.get("plex_analyze_cooldown_hours", 24) or 0)
        now = time.time()
        if cooldown and now - self._analysed.get(entry_id, 0) < cooldown * 3600:
            return
        self._analysed[entry_id] = now
        plex.analyze_async(str(rating_key))


def _as_int(value) -> Optional[int]:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _prefer(entries: list):
    """Prefer an already-activated entry, then HD.

    When quality is genuinely unknown, an activated file is the one
    someone has watched before, so it's the better guess than silently
    starting the 4K copy of something they've been watching in HD.
    """
    if not entries:
        return None
    if len(entries) == 1:
        return entries[0]
    return sorted(
        entries,
        key=lambda e: (not e.activated, e.quality != Quality.HD),
    )[0]
