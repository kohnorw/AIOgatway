"""webhook/handler.py — Handles Plex webhook play events."""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from gateway.stub_manager import StubManager
    from gateway.aiostreams_client import AIOStreamsClient

logger = logging.getLogger("aiogateway.webhook")
PLAY_EVENTS = {"media.play", "media.resume", "media.play.start"}


class PlexWebhookHandler:
    def __init__(
        self, stubs: "StubManager", client: "AIOStreamsClient",
        on_resolve_start=None, on_resolve_end=None,
    ) -> None:
        self.stubs  = stubs
        self.client = client
        # Called around just the _resolve() call below (not the whole
        # webhook request — stop/pause events and the already-resolved
        # fast path never need to pause anything) so every background
        # scan loop can pause for exactly as long as a real Plex playback
        # resolve takes, then resume immediately once it's done. Optional
        # so this class stays usable/testable without main.py's specific
        # coordination wiring.
        self._on_resolve_start = on_resolve_start or (lambda: None)
        self._on_resolve_end   = on_resolve_end or (lambda: None)

        # stub_id → last time we triggered a Plex analyze for it. Plex's
        # Analyze step actually reads chunks of the file to determine
        # audio/subtitle/bitrate info — for a FUSE-proxied debrid stream
        # that means real download traffic, not a local disk read. This
        # cooldown (see plex_analyze_cooldown_hours) stops repeat plays of
        # the same episode from re-downloading data on every single play
        # once it's already been analyzed correctly. In-memory only — a
        # restart just means the next play re-analyzes once, which is a
        # fine, cheap tradeoff for not persisting this.
        self._last_analyzed: dict = {}

    def _maybe_analyze(self, stub, rating_key: Optional[str]) -> None:
        """Triggers a Plex analyze for this ratingKey (from the webhook
        payload's Metadata — the item Plex is telling us it's playing),
        unless one already ran for this stub within
        plex_analyze_cooldown_hours — see self._last_analyzed above for
        why this cooldown exists at all."""
        if not rating_key:
            return
        try:
            from gateway import settings as _settings
            cooldown_hours = _settings.get("plex_analyze_cooldown_hours", 24) or 0
        except Exception:
            cooldown_hours = 24

        now = time.time()
        if cooldown_hours:
            last = self._last_analyzed.get(stub.stub_id, 0)
            if (now - last) < cooldown_hours * 3600:
                return   # analyzed recently enough — skip, save the bandwidth

        try:
            from gateway.plex_scan import analyze_item_async
            analyze_item_async(rating_key)
            self._last_analyzed[stub.stub_id] = now
        except Exception as exc:
            logger.warning("Could not trigger Plex analyze for %s: %s", rating_key, exc)

    @staticmethod
    def _prewarm_enabled() -> bool:
        """
        The "Keep new content active" toggle (prewarm_enabled). Governs
        every path that resolves a stub nobody asked for — including the
        two play-triggered ones below, which for a long time ran
        unconditionally and were the reason turning the setting off still
        left episodes going active on their own.

        Also requires a positive active_ttl_days, mirroring main.py's
        _prewarm_enabled: with expiry off nothing ever reverts a prewarmed
        stub, so speculatively resolving the next few episodes would hold
        their links permanently. The play that triggered this is a real
        play and keeps its own link either way — it's only the
        look-ahead that's suppressed.

        Defaults to True on a settings failure for the toggle itself, but
        False for a missing/zero TTL, since the default TTL is 7 and a
        zero reading is more likely to be deliberate than accidental.
        """
        try:
            from gateway import settings as _settings
        except Exception:
            return True
        try:
            if not bool(_settings.get("prewarm_enabled", True)):
                return False
            return (_settings.get("active_ttl_days", 0) or 0) > 0
        except Exception:
            return True

    async def handle(self, raw: str) -> dict:
        try:
            payload = json.loads(raw)
        except Exception:
            return {"action": "ignored", "reason": "invalid json"}

        event = payload.get("event", "")
        logger.info("Plex event: %s", event)

        if event not in PLAY_EVENTS:
            return {"action": "ignored", "event": event}

        meta = payload.get("Metadata", {})

        # ── Strategy 1: virtual FUSE path from Media.Part ───────────────────
        # Most reliable when present: the path itself contains "Movies4K" vs
        # "Movies", so quality is unambiguous. But Plex's media.play payload
        # doesn't always include the Media/Part array.
        stub = self._stub_by_fuse_path(payload)

        # ── Strategy 2: ratingKey via Plex API ──────────────────────────────
        # Also file-path-based (queries Plex's own metadata endpoint, which
        # reliably returns Media/Part even when the webhook payload omits
        # it), so still unambiguous about quality. Tried BEFORE the GUID
        # guess below — this used to run last, which meant the unreliable
        # GUID-based guess always "succeeded" first (it never returns None
        # once any candidate exists) and this never got a chance to run.
        if not stub:
            rating_key = meta.get("ratingKey")
            if rating_key:
                stub = await self._stub_by_rating_key(rating_key, meta)

        # ── Strategy 3: match by IMDb ID + season/episode from Guid array ───
        # Last resort. When HD and 4K stubs share the same Plex library
        # section, librarySectionID can't disambiguate them, and Plex's
        # self-reported videoResolution reflects the small stub file's own
        # encoded resolution (not the real quality tier) until the stream
        # actually resolves — so this can guess wrong. Only used if both
        # file-path-based strategies above failed to find anything.
        if not stub:
            stub = self._stub_by_guid(meta)

        if not stub:
            logger.warning(
                "No stub matched for play event. "
                "title=%r type=%r guid=%r season=%r ep=%r",
                meta.get("title"), meta.get("type"),
                meta.get("Guid"), meta.get("parentIndex"), meta.get("index")
            )
            return {"action": "ignored", "reason": "no matching stub"}

        logger.info("Matched stub=%s quality=%s", stub.stub_id, stub.quality.value)

        if stub.stream_url:
            # Already resolved — pre-warm next episodes in background.
            # Still trigger analyze here too, not just on first resolve:
            # this is actually the MORE common path (most plays are of
            # already-resolved episodes), and it's what makes Plex's
            # audio/subtitle/file info self-heal on every play rather
            # than only ever getting a chance to be corrected once —
            # _maybe_analyze applies the cooldown so repeat plays within
            # the window don't re-trigger a real download for nothing.
            asyncio.create_task(self._prewarm_next(stub, count=3))
            self._maybe_analyze(stub, meta.get("ratingKey"))
            return {"action": "already_active", "stub_id": stub.stub_id}

        await self.stubs.set_resolving(stub.stub_id)

        self._on_resolve_start()
        try:
            stream_obj = await self._resolve(stub)
        except Exception as exc:
            from gateway.aiostreams_client import AllCandidatesDeadError
            if isinstance(exc, AllCandidatesDeadError):
                # Every single candidate (HD or 4K) was tried and confirmed
                # dead — a much stronger signal than a generic resolve
                # failure (which could just mean nothing's cached yet,
                # worth waiting on). Rather than waiting for
                # dead_stub_max_errors to accumulate across several
                # separate future play attempts, remove it right now:
                # deletes the placeholder and triggers a scoped Plex
                # rescan so it stops showing as "available" when it
                # demonstrably isn't — for either quality.
                logger.warning(
                    "[%s] All %s candidates dead for %s — removing stub immediately",
                    stub.stub_id[:8], stub.quality.value.upper(), stub.title
                )
                await self.stubs.remove_stub(stub.stub_id, dead=True)
                return {"action": "removed", "stub_id": stub.stub_id,
                        "reason": f"all {stub.quality.value} candidates dead"}
            logger.error("Resolve failed for %s: %s", stub.stub_id, exc)
            await self.stubs.set_error(stub.stub_id)
            return {"action": "error", "stub_id": stub.stub_id, "error": str(exc)}
        finally:
            self._on_resolve_end()

        if not stream_obj or not stream_obj.url:
            await self.stubs.set_error(stub.stub_id)
            return {"action": "error", "stub_id": stub.stub_id, "error": "no url"}

        await self.stubs.set_active(stub.stub_id, stream_obj.url, stream_obj.request_headers,
                                    size=stream_obj.size)
        logger.info("Resolved stub %s → %s…", stub.stub_id, stream_obj.url[:60])

        # Force Plex to re-read this item now that it's a real stream, not
        # the placeholder — otherwise Plex keeps showing the placeholder's
        # audio/subtitle/stream info until its next scheduled full scan.
        # meta["ratingKey"] is the same item Plex is about to play, taken
        # straight from this webhook's own payload — no lookup needed.
        # Goes through the same cooldown-aware helper as the already-
        # active branch for consistency, though this being the first
        # resolve means the cooldown check will always pass here.
        self._maybe_analyze(stub, meta.get("ratingKey"))

        # Invalidate any cached CDN blocks for this stub (URL just changed)
        try:
            from gateway.fuse_fs import invalidate_stub
            invalidate_stub(stub.stub_id)
        except Exception:
            pass

        # If this resolved via a season/series pack, the rest of that
        # season (or the whole show, for a series pack) is likely just as
        # fast to resolve right now — a cached pack doesn't get slower per
        # episode the way a from-scratch search would. Fast-track ALL of
        # it immediately instead of only pre-warming the next few, so a
        # binge doesn't keep re-discovering the same pack one episode at
        # a time. Falls back to the narrower "next 3" pre-warm otherwise.
        pack_kind, pack_season = stream_obj.pack_type
        if pack_kind in ("season", "series"):
            asyncio.create_task(
                self._fast_track_pack(stub, pack_kind, pack_season)
            )
        else:
            asyncio.create_task(self._prewarm_next(stub, count=3))

        return {"action": "resolved", "stub_id": stub.stub_id, "quality": stub.quality.value}

    # ── Pack fast-track ───────────────────────────────────────────────────────

    @staticmethod
    def _ttl_expired(stub) -> bool:
        """
        True if this stub already held a link and lost it to the TTL
        sweep (revert_to_placeholder stamped ttl_expired_at).

        Such a stub is indistinguishable from a never-resolved one by
        `not stream_url` alone, which is why both selection filters below
        have to test this explicitly. main.py's _prewarm_eligible has the
        same guard for the same reason: expiring a link and then
        speculatively re-resolving it cancels the TTL out entirely.

        Honours the same prewarm_skip_ttl_expired setting, defaulting to
        True on a settings failure — the safe direction here is to leave
        an expired stub alone.
        """
        if not getattr(stub, "ttl_expired_at", None):
            return False
        try:
            from gateway import settings as _settings
            return bool(_settings.get("prewarm_skip_ttl_expired", True))
        except Exception:
            return True

    async def _fast_track_pack(self, played_stub, pack_kind: str, pack_season: Optional[int]) -> None:
        """
        Called right after a play-triggered resolve turns out to be a
        season or series pack. Once one episode resolves from a pack, the
        rest of that season (season pack) — or every other season of the
        show (series pack) — is expected to resolve just as fast, since
        it's the same underlying cached source, not a fresh scrape. This
        immediately resolves every other still-placeholder stub the pack
        covers through the exact same per-stub AIOStreams query every
        other resolve uses (no shortcuts, no guessing at pack contents —
        see gateway/main.py's _fast_track_pack_season for the equivalent
        used by the add-flow's background scan), instead of leaving them
        to be discovered one at a time on their own future play events or
        whatever background sweep gets to them next.

        Only ever targets the SAME quality tier that actually resolved as
        a pack — an HD season pack says nothing about whether a 4K pack
        also exists, so 4K stubs for this show are left untouched here.

        Gated on "Keep new content active": cheap as a cached pack is to
        resolve, this still puts a whole season of never-played episodes
        into ACTIVE and holds a live link for each, which is exactly what
        that toggle exists to control.
        """
        if not self._prewarm_enabled():
            logger.debug(
                "Pack fast-track skipped for %s — prewarm_enabled is off",
                played_stub.imdb_id,
            )
            return

        targets = [
            s for s in self.stubs.all()
            if s.imdb_id == played_stub.imdb_id
            and s.quality == played_stub.quality
            and not s.stream_url
            and not self._ttl_expired(s)
            and s.stub_id != played_stub.stub_id
            and (pack_kind == "series" or s.season == pack_season)
        ]
        if not targets:
            return

        logger.info(
            "Pack detected (%s%s) for %s — fast-tracking %d other placeholder stub(s)",
            pack_kind, f" S{pack_season:02d}" if pack_season else "",
            played_stub.imdb_id, len(targets)
        )

        for s in targets:
            if s.stream_url:
                continue   # resolved by something else (e.g. a real play) while we were working through the list
            await self.stubs.set_resolving(s.stub_id)
            try:
                stream_obj = await self._resolve(s)
                if stream_obj and stream_obj.url:
                    await self.stubs.set_active(s.stub_id, stream_obj.url, stream_obj.request_headers,
                                                size=stream_obj.size)
                    try:
                        from gateway.fuse_fs import invalidate_stub
                        invalidate_stub(s.stub_id)
                    except Exception:
                        pass
                    logger.info("Pack fast-track resolved %s → %s…", s.aiostreams_id, stream_obj.url[:50])
                else:
                    await self.stubs.set_error(s.stub_id)
                    logger.warning("Pack fast-track: no URL for %s", s.aiostreams_id)
            except Exception as exc:
                from gateway.aiostreams_client import AllCandidatesDeadError
                if isinstance(exc, AllCandidatesDeadError):
                    logger.warning(
                        "Pack fast-track: all %s candidates dead for %s — removing stub immediately",
                        s.quality.value.upper(), s.aiostreams_id
                    )
                    await self.stubs.remove_stub(s.stub_id, dead=True)
                    continue
                await self.stubs.set_error(s.stub_id)
                logger.warning("Pack fast-track failed for %s: %s", s.aiostreams_id, exc)

    # ── Pre-warm next N episodes ─────────────────────────────────────────────

    async def _prewarm_next(self, played_stub, count: int = 3) -> None:
        """
        Resolve the next `count` episode stubs after the played one so they're
        ready before Plex asks for them. Only applies to series.

        Gated on "Keep new content active" — this is prewarming in the
        same sense as main.py's sweeps (episodes nobody has played going
        ACTIVE on their own), so it answers to the same setting rather
        than running unconditionally on every play event.
        """
        if not self._prewarm_enabled():
            return

        parts = played_stub.aiostreams_id.split(":")
        if len(parts) < 3:
            return   # movie — nothing to prewarm

        imdb_id = played_stub.imdb_id
        quality = played_stub.quality
        season  = int(parts[1])
        episode = int(parts[2])

        all_series = [
            s for s in self.stubs.all()
            if s.imdb_id == imdb_id
            and s.quality == quality
            and not s.stream_url
            and not self._ttl_expired(s)
            and s.aiostreams_id != played_stub.aiostreams_id
        ]

        def _ep_key(s):
            p = s.aiostreams_id.split(":")
            if len(p) < 3:
                return (9999, 9999)
            return (int(p[1]), int(p[2]))

        next_eps = sorted(
            [s for s in all_series if _ep_key(s) > (season, episode)],
            key=_ep_key
        )

        targets = next_eps[:count]
        if not targets:
            return

        logger.info(
            "Pre-warming %d episode(s) after S%02dE%02d (%s): %s",
            len(targets), season, episode, quality.value,
            [s.aiostreams_id for s in targets]
        )

        for s in targets:
            if s.stream_url:
                continue
            await self.stubs.set_resolving(s.stub_id)
            try:
                stream_obj = await self._resolve(s)
                if stream_obj and stream_obj.url:
                    await self.stubs.set_active(s.stub_id, stream_obj.url, stream_obj.request_headers,
                                                size=stream_obj.size)
                    try:
                        from gateway.fuse_fs import invalidate_stub
                        invalidate_stub(s.stub_id)
                    except Exception:
                        pass
                    logger.info("Pre-warmed %s → %s…", s.aiostreams_id, stream_obj.url[:50])

                    pack_kind, pack_season = stream_obj.pack_type
                    if pack_kind in ("season", "series"):
                        # Broader than this narrow next-3 loop — covers the
                        # whole season (or show) at once, so hand off and
                        # stop here rather than keep working through just
                        # the next few.
                        await self._fast_track_pack(s, pack_kind, pack_season)
                        return
                else:
                    await self.stubs.set_error(s.stub_id)
                    logger.warning("Pre-warm no URL for %s", s.aiostreams_id)
            except Exception as exc:
                from gateway.aiostreams_client import AllCandidatesDeadError
                if isinstance(exc, AllCandidatesDeadError):
                    logger.warning(
                        "Pre-warm: all %s candidates dead for %s — removing stub immediately",
                        s.quality.value.upper(), s.aiostreams_id
                    )
                    await self.stubs.remove_stub(s.stub_id, dead=True)
                    continue
                await self.stubs.set_error(s.stub_id)
                logger.warning("Pre-warm failed for %s: %s", s.aiostreams_id, exc)

    # ── Matching strategies ──────────────────────────────────────────────────

    def _stub_by_fuse_path(self, payload: dict):
        """
        Match using the virtual FUSE path Plex reports in Media[0].Part[0].file.
        e.g. /docker/aiogateway/mnt/Movies/Title (2026)/Title (2026).mkv

        We ask fuse_fs to derive each stub's virtual path and compare.
        """
        try:
            path = payload["Metadata"]["Media"][0]["Part"][0]["file"]
            if not path:
                return None
        except (KeyError, IndexError, TypeError):
            return None

        try:
            from gateway.fuse_fs import _fs_instance
            if _fs_instance is None:
                return None
            mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt").rstrip("/")
            # Strip the mountpoint prefix to get the virtual path
            if path.startswith(mountpoint):
                virtual_path = path[len(mountpoint):]
            else:
                virtual_path = path
            for stub in self.stubs.all():
                if _fs_instance._build_path_for_state(stub, resolved=True) == virtual_path:
                    return stub
                if _fs_instance._build_path_for_state(stub, resolved=False) == virtual_path:
                    return stub
        except Exception as exc:
            logger.warning("fuse path match failed: %s", exc)
        return None

    def _stub_by_guid(self, meta: dict):
        """
        Match using Guid array + parentIndex (season) + index (episode).
        """
        guids = meta.get("Guid") or []
        imdb_id = None
        for g in guids:
            gid = g.get("id", "")
            if gid.startswith("imdb://"):
                imdb_id = gid.replace("imdb://", "").strip()
                break

        if not imdb_id:
            top_guid = meta.get("guid", "")
            m = re.search(r'tt\d+', top_guid)
            if m:
                imdb_id = m.group(0)

        if not imdb_id:
            return None

        media_type = meta.get("type", "")
        season  = meta.get("parentIndex")
        episode = meta.get("index")

        logger.info(
            "Guid match attempt: imdb=%s type=%s season=%s ep=%s",
            imdb_id, media_type, season, episode
        )

        candidates = [s for s in self.stubs.all() if s.imdb_id == imdb_id]
        if not candidates:
            return None

        if media_type == "episode" and season is not None and episode is not None:
            ep_id = f"{imdb_id}:{season}:{episode}"
            # Multiple stubs can share the same aiostreams_id only if they
            # differ in quality (HD vs 4K stub created separately) — but
            # aiostreams_id doesn't encode quality, so when more than one
            # candidate matches, disambiguate by library section the same
            # way as the movie branch below.
            ep_candidates = [s for s in candidates if s.aiostreams_id == ep_id]
            if not ep_candidates:
                return None
            if len(ep_candidates) == 1:
                return ep_candidates[0]
            return self._disambiguate_by_section(ep_candidates, meta)
        elif media_type == "movie":
            return self._disambiguate_by_section(candidates, meta)

        return None

    def _disambiguate_by_section(self, candidates: list, meta: dict):
        """
        Last-resort quality guess, only reached if neither the FUSE-path nor
        Plex-API-by-ratingKey strategies could determine the real file path.

        Tries librarySectionID first (only useful if HD and 4K are split
        into separate Plex library sections — if they share one section,
        as is common, this can't disambiguate and falls through to the
        videoResolution guess below, which itself is unreliable since it
        reflects the stub file's own small encoded resolution rather than
        the real quality tier until the stream actually resolves).

        Every path through here logs clearly, since reaching this function
        at all means the reliable strategies above failed — see
        _stub_by_rating_key for why that's usually a PLEX_URL/PLEX_TOKEN
        configuration problem, not something wrong with this logic itself.
        """
        logger.warning(
            "Falling back to ambiguous HD/4K guess for %s — the reliable "
            "FUSE-path and Plex-API-ratingKey strategies both failed to "
            "resolve a file path. Check PLEX_URL/PLEX_TOKEN if this happens "
            "often, especially for 4K plays.", meta.get("title", "?")
        )
        section_id = meta.get("librarySectionID")
        if section_id is not None:
            try:
                from gateway.plex_scan import folder_for_section_id
                folder = folder_for_section_id(int(section_id))
                if folder:
                    is_4k_section = "4k" in folder.lower()
                    logger.info("librarySectionID=%s → folder=%s → 4k=%s",
                               section_id, folder, is_4k_section)
                    if is_4k_section:
                        k4 = [s for s in candidates if s.quality.value == "4k"]
                        if k4:
                            return k4[0]
                    else:
                        hd = [s for s in candidates if s.quality.value == "hd"]
                        if hd:
                            return hd[0]
            except Exception as exc:
                logger.warning("Section-based quality disambiguation failed: %s", exc)

        # Fallback: videoResolution metadata (unreliable pre-resolution, but
        # better than nothing if PLEX_URL/PLEX_TOKEN aren't configured or
        # the section lookup failed).
        media_list = meta.get("Media") or []
        is_4k = False
        if media_list:
            res = str(media_list[0].get("videoResolution", "")).lower()
            is_4k = res in ("4k", "2160", "uhd") or "2160" in res
        logger.warning(
            "Section-based disambiguation inconclusive for %s — guessing "
            "from videoResolution=%r (is_4k=%s). This reflects the STUB "
            "placeholder's own encoded resolution pre-resolve, not the "
            "real quality tier, so it's biased toward guessing HD.",
            meta.get("title", "?"),
            media_list[0].get("videoResolution") if media_list else None,
            is_4k,
        )
        if is_4k:
            k4 = [s for s in candidates if s.quality.value == "4k"]
            return k4[0] if k4 else candidates[0]
        else:
            hd = [s for s in candidates if s.quality.value == "hd"]
            return hd[0] if hd else candidates[0]

    async def _stub_by_rating_key(self, rating_key: str, meta: dict):
        """
        Query Plex's own metadata API for the real file path (reliably
        includes Media/Part even when the webhook payload itself omits it).
        Requires PLEX_URL/PLEX_TOKEN to be configured.

        This is the ONLY strategy that's unambiguous about HD vs 4K without
        relying on librarySectionID or videoResolution guesses (see
        _disambiguate_by_section) — so every silent failure here is a
        silent step down to a guess that's frequently wrong for 4K
        specifically. All failure modes are logged clearly for exactly
        that reason, not just as debug noise.
        """
        plex_url   = os.environ.get("PLEX_URL", "")
        plex_token = os.environ.get("PLEX_TOKEN", "")
        if not plex_url or not plex_token or "your-plex" in plex_url or "your-plex" in plex_token:
            logger.warning(
                "PLEX_URL/PLEX_TOKEN not configured (still using the docker-compose.yml "
                "placeholder values, or unset) — the reliable ratingKey-based stub match "
                "is disabled, so HD/4K disambiguation falls back to a guess that's known "
                "to be biased toward HD. Set real values to fix this."
            )
            return None

        import aiohttp
        try:
            url = f"{plex_url}/library/metadata/{rating_key}"
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    headers={"X-Plex-Token": plex_token, "Accept": "application/json"},
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    if resp.status != 200:
                        logger.warning("Plex API metadata lookup returned HTTP %d for ratingKey=%s",
                                       resp.status, rating_key)
                        return None
                    data = await resp.json()
                    items = (data.get("MediaContainer", {}).get("Metadata", [{}]))
                    if not items:
                        logger.warning("Plex API metadata lookup returned no items for ratingKey=%s", rating_key)
                        return None
                    path = (items[0].get("Media", [{}])[0]
                            .get("Part", [{}])[0]
                            .get("file"))
                    if not path:
                        logger.warning("Plex API metadata for ratingKey=%s had no file path", rating_key)
                        return None
                    logger.info("Plex API file path: %s", path)
                    matched = self._stub_by_fuse_path(
                        {"Metadata": {"Media": [{"Part": [{"file": path}]}]}}
                    )
                    if matched is None:
                        logger.warning(
                            "Plex API returned file path %s but it didn't match any known stub", path
                        )
                    return matched
        except Exception as exc:
            logger.warning("Plex API fallback failed for ratingKey=%s: %s", rating_key, exc)
        return None

    # ── Stream resolution ────────────────────────────────────────────────────

    # Retry schedule for AIOStreams 429s during play-triggered resolution.
    # The background series-add scan also queries AIOStreams (with its own
    # throttle) and can be mid-burst when someone presses play on an episode
    # that's still being scanned — this isn't optional retry-for-niceness,
    # it's needed because that collision is a normal, expected occurrence
    # whenever a user starts watching while a series add is still running.
    #
    # Kept deliberately short (total ~6s worst case) so it comfortably fits
    # within FUSE's RESOLVE_WAIT_TIMEOUT (default 15s) — if every attempt
    # blew past that window, read() would already have given up and served
    # stub bytes for the first read, even though resolution succeeds soon
    # after. A tight retry budget gives a real shot at a clean first read.
    _RESOLVE_MAX_ATTEMPTS = 4
    _RESOLVE_BACKOFF = [1, 2, 3]   # seconds between attempts 1→2, 2→3, 3→4

    async def _resolve(self, stub):
        from gateway.models import MediaItem, MediaType
        media_type = MediaType.MOVIE if stub.aiostreams_type == "movie" else MediaType.SERIES
        parts = stub.aiostreams_id.split(":")
        item = MediaItem(
            id=stub.media_id, imdb_id=stub.imdb_id, title=stub.title,
            year=stub.year, media_type=media_type,
            season=int(parts[1]) if len(parts) >= 3 else None,
            episode=int(parts[2]) if len(parts) >= 3 else None,
        )

        last_exc = None
        for attempt in range(self._RESOLVE_MAX_ATTEMPTS):
            try:
                return await self.client.best_working_for_quality(item, stub.quality)
            except Exception as exc:
                last_exc = exc
                is_429 = "429" in str(exc) or "Too Many Requests" in str(exc)
                if not is_429:
                    raise   # only retry rate limits — anything else is a real error
                if attempt < self._RESOLVE_MAX_ATTEMPTS - 1:
                    wait = self._RESOLVE_BACKOFF[attempt]
                    logger.warning(
                        "[%s] AIOStreams rate limited (429), retrying in %ds (attempt %d/%d)",
                        stub.stub_id[:8], wait, attempt + 1, self._RESOLVE_MAX_ATTEMPTS
                    )
                    await asyncio.sleep(wait)
        raise last_exc
