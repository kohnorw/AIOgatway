"""webhook/handler.py — Handles Plex webhook play events."""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from gateway.stub_manager import StubManager
    from gateway.aiostreams_client import AIOStreamsClient

logger = logging.getLogger("aiogateway.webhook")
PLAY_EVENTS = {"media.play", "media.resume", "media.play.start"}


class PlexWebhookHandler:
    def __init__(self, stubs: "StubManager", client: "AIOStreamsClient") -> None:
        self.stubs  = stubs
        self.client = client

    async def handle(self, raw: str) -> dict:
        try:
            payload = json.loads(raw)
        except Exception:
            return {"action": "ignored", "reason": "invalid json"}

        event = payload.get("event", "")
        logger.info("Plex event: %s", event)

        if event not in PLAY_EVENTS:
            return {"action": "ignored", "event": event}

        meta = payload.get("Metadata", {})

        # ── Strategy 1: virtual FUSE path from Media.Part ───────────────────
        # Most reliable when present: the path itself contains "Movies4K" vs
        # "Movies", so quality is unambiguous. But Plex's media.play payload
        # doesn't always include the Media/Part array.
        stub = self._stub_by_fuse_path(payload)

        # ── Strategy 2: ratingKey via Plex API ──────────────────────────────
        # Also file-path-based (queries Plex's own metadata endpoint, which
        # reliably returns Media/Part even when the webhook payload omits
        # it), so still unambiguous about quality. Tried BEFORE the GUID
        # guess below — this used to run last, which meant the unreliable
        # GUID-based guess always "succeeded" first (it never returns None
        # once any candidate exists) and this never got a chance to run.
        if not stub:
            rating_key = meta.get("ratingKey")
            if rating_key:
                stub = await self._stub_by_rating_key(rating_key, meta)

        # ── Strategy 3: match by IMDb ID + season/episode from Guid array ───
        # Last resort. When HD and 4K stubs share the same Plex library
        # section, librarySectionID can't disambiguate them, and Plex's
        # self-reported videoResolution reflects the small stub file's own
        # encoded resolution (not the real quality tier) until the stream
        # actually resolves — so this can guess wrong. Only used if both
        # file-path-based strategies above failed to find anything.
        if not stub:
            stub = self._stub_by_guid(meta)

        if not stub:
            logger.warning(
                "No stub matched for play event. "
                "title=%r type=%r guid=%r season=%r ep=%r",
                meta.get("title"), meta.get("type"),
                meta.get("Guid"), meta.get("parentIndex"), meta.get("index")
            )
            return {"action": "ignored", "reason": "no matching stub"}

        logger.info("Matched stub=%s quality=%s", stub.stub_id, stub.quality.value)

        if stub.stream_url:
            # Already resolved — pre-warm next episodes in background
            asyncio.create_task(self._prewarm_next(stub, count=3))
            return {"action": "already_active", "stub_id": stub.stub_id}

        self.stubs.set_resolving(stub.stub_id)

        try:
            stream_obj = await self._resolve(stub)
        except Exception as exc:
            logger.error("Resolve failed for %s: %s", stub.stub_id, exc)
            self.stubs.set_error(stub.stub_id)
            return {"action": "error", "stub_id": stub.stub_id, "error": str(exc)}

        if not stream_obj or not stream_obj.url:
            self.stubs.set_error(stub.stub_id)
            return {"action": "error", "stub_id": stub.stub_id, "error": "no url"}

        self.stubs.set_active(stub.stub_id, stream_obj.url, stream_obj.request_headers,
                              size=stream_obj.size)
        logger.info("Resolved stub %s → %s…", stub.stub_id, stream_obj.url[:60])

        # Invalidate any cached CDN blocks for this stub (URL just changed)
        try:
            from gateway.fuse_fs import invalidate_stub
            invalidate_stub(stub.stub_id)
        except Exception:
            pass

        # Pre-warm next 3 episodes in the background
        asyncio.create_task(self._prewarm_next(stub, count=3))

        return {"action": "resolved", "stub_id": stub.stub_id, "quality": stub.quality.value}

    # ── Pre-warm next N episodes ─────────────────────────────────────────────

    async def _prewarm_next(self, played_stub, count: int = 3) -> None:
        """
        Resolve the next `count` episode stubs after the played one so they're
        ready before Plex asks for them. Only applies to series.
        """
        parts = played_stub.aiostreams_id.split(":")
        if len(parts) < 3:
            return   # movie — nothing to prewarm

        imdb_id = played_stub.imdb_id
        quality = played_stub.quality
        season  = int(parts[1])
        episode = int(parts[2])

        all_series = [
            s for s in self.stubs.all()
            if s.imdb_id == imdb_id
            and s.quality == quality
            and not s.stream_url
            and s.aiostreams_id != played_stub.aiostreams_id
        ]

        def _ep_key(s):
            p = s.aiostreams_id.split(":")
            if len(p) < 3:
                return (9999, 9999)
            return (int(p[1]), int(p[2]))

        next_eps = sorted(
            [s for s in all_series if _ep_key(s) > (season, episode)],
            key=_ep_key
        )

        targets = next_eps[:count]
        if not targets:
            return

        logger.info(
            "Pre-warming %d episode(s) after S%02dE%02d (%s): %s",
            len(targets), season, episode, quality.value,
            [s.aiostreams_id for s in targets]
        )

        for s in targets:
            if s.stream_url:
                continue
            self.stubs.set_resolving(s.stub_id)
            try:
                stream_obj = await self._resolve(s)
                if stream_obj and stream_obj.url:
                    self.stubs.set_active(s.stub_id, stream_obj.url, stream_obj.request_headers,
                                          size=stream_obj.size)
                    try:
                        from gateway.fuse_fs import invalidate_stub
                        invalidate_stub(s.stub_id)
                    except Exception:
                        pass
                    logger.info("Pre-warmed %s → %s…", s.aiostreams_id, stream_obj.url[:50])
                else:
                    self.stubs.set_error(s.stub_id)
                    logger.warning("Pre-warm no URL for %s", s.aiostreams_id)
            except Exception as exc:
                self.stubs.set_error(s.stub_id)
                logger.warning("Pre-warm failed for %s: %s", s.aiostreams_id, exc)

    # ── Matching strategies ──────────────────────────────────────────────────

    def _stub_by_fuse_path(self, payload: dict):
        """
        Match using the virtual FUSE path Plex reports in Media[0].Part[0].file.
        e.g. /docker/aiogateway/mnt/Movies/Title (2026)/Title (2026).mkv

        We ask fuse_fs to derive each stub's virtual path and compare.
        """
        try:
            path = payload["Metadata"]["Media"][0]["Part"][0]["file"]
            if not path:
                return None
        except (KeyError, IndexError, TypeError):
            return None

        try:
            from gateway.fuse_fs import _fs_instance
            if _fs_instance is None:
                return None
            mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt").rstrip("/")
            # Strip the mountpoint prefix to get the virtual path
            if path.startswith(mountpoint):
                virtual_path = path[len(mountpoint):]
            else:
                virtual_path = path
            for stub in self.stubs.all():
                if _fs_instance._build_path_for_state(stub, resolved=True) == virtual_path:
                    return stub
                if _fs_instance._build_path_for_state(stub, resolved=False) == virtual_path:
                    return stub
        except Exception as exc:
            logger.warning("fuse path match failed: %s", exc)
        return None

    def _stub_by_guid(self, meta: dict):
        """
        Match using Guid array + parentIndex (season) + index (episode).
        """
        guids = meta.get("Guid") or []
        imdb_id = None
        for g in guids:
            gid = g.get("id", "")
            if gid.startswith("imdb://"):
                imdb_id = gid.replace("imdb://", "").strip()
                break

        if not imdb_id:
            top_guid = meta.get("guid", "")
            m = re.search(r'tt\d+', top_guid)
            if m:
                imdb_id = m.group(0)

        if not imdb_id:
            return None

        media_type = meta.get("type", "")
        season  = meta.get("parentIndex")
        episode = meta.get("index")

        logger.info(
            "Guid match attempt: imdb=%s type=%s season=%s ep=%s",
            imdb_id, media_type, season, episode
        )

        candidates = [s for s in self.stubs.all() if s.imdb_id == imdb_id]
        if not candidates:
            return None

        if media_type == "episode" and season is not None and episode is not None:
            ep_id = f"{imdb_id}:{season}:{episode}"
            # Multiple stubs can share the same aiostreams_id only if they
            # differ in quality (HD vs 4K stub created separately) — but
            # aiostreams_id doesn't encode quality, so when more than one
            # candidate matches, disambiguate by library section the same
            # way as the movie branch below.
            ep_candidates = [s for s in candidates if s.aiostreams_id == ep_id]
            if not ep_candidates:
                return None
            if len(ep_candidates) == 1:
                return ep_candidates[0]
            return self._disambiguate_by_section(ep_candidates, meta)
        elif media_type == "movie":
            return self._disambiguate_by_section(candidates, meta)

        return None

    def _disambiguate_by_section(self, candidates: list, meta: dict):
        """
        Last-resort quality guess, only reached if neither the FUSE-path nor
        Plex-API-by-ratingKey strategies could determine the real file path.

        Tries librarySectionID first (only useful if HD and 4K are split
        into separate Plex library sections — if they share one section,
        as is common, this can't disambiguate and falls through to the
        videoResolution guess below, which itself is unreliable since it
        reflects the stub file's own small encoded resolution rather than
        the real quality tier until the stream actually resolves).
        """
        section_id = meta.get("librarySectionID")
        if section_id is not None:
            try:
                from gateway.plex_scan import folder_for_section_id
                folder = folder_for_section_id(int(section_id))
                if folder:
                    is_4k_section = "4k" in folder.lower()
                    logger.info("librarySectionID=%s → folder=%s → 4k=%s",
                               section_id, folder, is_4k_section)
                    if is_4k_section:
                        k4 = [s for s in candidates if s.quality.value == "4k"]
                        if k4:
                            return k4[0]
                    else:
                        hd = [s for s in candidates if s.quality.value == "hd"]
                        if hd:
                            return hd[0]
            except Exception as exc:
                logger.warning("Section-based quality disambiguation failed: %s", exc)

        # Fallback: videoResolution metadata (unreliable pre-resolution, but
        # better than nothing if PLEX_URL/PLEX_TOKEN aren't configured or
        # the section lookup failed).
        media_list = meta.get("Media") or []
        is_4k = False
        if media_list:
            res = str(media_list[0].get("videoResolution", "")).lower()
            is_4k = res in ("4k", "2160", "uhd") or "2160" in res
        if is_4k:
            k4 = [s for s in candidates if s.quality.value == "4k"]
            return k4[0] if k4 else candidates[0]
        else:
            hd = [s for s in candidates if s.quality.value == "hd"]
            return hd[0] if hd else candidates[0]

    async def _stub_by_rating_key(self, rating_key: str, meta: dict):
        """Query Plex's own metadata API for the real file path (reliably
        includes Media/Part even when the webhook payload itself omits it).
        Requires PLEX_URL/PLEX_TOKEN to be configured."""
        plex_url   = os.environ.get("PLEX_URL", "")
        plex_token = os.environ.get("PLEX_TOKEN", "")
        if not plex_url or not plex_token:
            return None

        import aiohttp
        try:
            url = f"{plex_url}/library/metadata/{rating_key}"
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    headers={"X-Plex-Token": plex_token, "Accept": "application/json"},
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    if resp.status != 200:
                        return None
                    data = await resp.json()
                    items = (data.get("MediaContainer", {}).get("Metadata", [{}]))
                    if not items:
                        return None
                    path = (items[0].get("Media", [{}])[0]
                            .get("Part", [{}])[0]
                            .get("file"))
                    if path:
                        logger.info("Plex API file path: %s", path)
                        return self._stub_by_fuse_path(
                            {"Metadata": {"Media": [{"Part": [{"file": path}]}]}}
                        )
        except Exception as exc:
            logger.warning("Plex API fallback failed: %s", exc)
        return None

    # ── Stream resolution ────────────────────────────────────────────────────

    async def _resolve(self, stub):
        from gateway.models import MediaItem, MediaType
        media_type = MediaType.MOVIE if stub.aiostreams_type == "movie" else MediaType.SERIES
        parts = stub.aiostreams_id.split(":")
        item = MediaItem(
            id=stub.media_id, imdb_id=stub.imdb_id, title=stub.title,
            year=stub.year, media_type=media_type,
            season=int(parts[1]) if len(parts) >= 3 else None,
            episode=int(parts[2]) if len(parts) >= 3 else None,
        )
        return await self.client.best_working_for_quality(item, stub.quality)
