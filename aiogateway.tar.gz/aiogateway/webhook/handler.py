"""webhook/handler.py — Handles Plex webhook play events.

Every file in the library is already a real TorBox file, so a play event
doesn't have to resolve anything. The webhook is only a health signal: if
the item being played is marked broken, the repair loop is woken so it gets
re-verified or rebound right away instead of on the next scheduled cycle.
"""
from __future__ import annotations

import json
import logging
import os
import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from gateway.stub_manager import StubManager
    from gateway.torbox_client import TorBoxClient

logger = logging.getLogger("aiogateway.webhook")
PLAY_EVENTS = {"media.play", "media.resume", "media.play.start"}


class PlexWebhookHandler:
    def __init__(self, stubs: "StubManager", client: "TorBoxClient") -> None:
        self.stubs  = stubs
        self.client = client

    async def handle(self, raw: str) -> dict:
        try:
            payload = json.loads(raw)
        except Exception:
            return {"action": "ignored", "reason": "invalid json"}

        event = payload.get("event", "")
        logger.info("Plex event: %s", event)

        if event not in PLAY_EVENTS:
            return {"action": "ignored", "event": event}

        meta = payload.get("Metadata", {})

        # ── Strategy 1: virtual FUSE path from Media.Part ───────────────────
        # Most reliable when present: the path itself contains "Movies4K" vs
        # "Movies", so quality is unambiguous. But Plex's media.play payload
        # doesn't always include the Media/Part array.
        stub = self._stub_by_fuse_path(payload)

        # ── Strategy 2: ratingKey via Plex API ──────────────────────────────
        # Also file-path-based (queries Plex's own metadata endpoint, which
        # reliably returns Media/Part even when the webhook payload omits
        # it), so still unambiguous about quality. Tried BEFORE the GUID
        # guess below — this used to run last, which meant the unreliable
        # GUID-based guess always "succeeded" first (it never returns None
        # once any candidate exists) and this never got a chance to run.
        if not stub:
            rating_key = meta.get("ratingKey")
            if rating_key:
                stub = await self._stub_by_rating_key(rating_key, meta)

        # ── Strategy 3: match by IMDb ID + season/episode from Guid array ───
        # Last resort. When HD and 4K stubs share the same Plex library
        # section, librarySectionID can't disambiguate them, and Plex's
        # self-reported videoResolution reflects the small stub file's own
        # encoded resolution (not the real quality tier) until the stream
        # actually resolves — so this can guess wrong. Only used if both
        # file-path-based strategies above failed to find anything.
        if not stub:
            stub = self._stub_by_guid(meta)

        if not stub:
            logger.warning(
                "No stub matched for play event. "
                "title=%r type=%r guid=%r season=%r ep=%r",
                meta.get("title"), meta.get("type"),
                meta.get("Guid"), meta.get("parentIndex"), meta.get("index")
            )
            return {"action": "ignored", "reason": "no matching stub"}

        logger.info("Matched stub=%s quality=%s state=%s", stub.stub_id, stub.quality.value, stub.state.value)

        from gateway.models import StubState
        if stub.state != StubState.ACTIVE:
            stub.last_error_at = None          # skip the backoff: someone wants to watch it now
            self.stubs.wake_repair()
            return {"action": "repair_queued", "stub_id": stub.stub_id}
        return {"action": "playing", "stub_id": stub.stub_id}

    # ── Matching strategies ──────────────────────────────────────────────────

    def _stub_by_fuse_path(self, payload: dict):
        """
        Match using the virtual FUSE path Plex reports in Media[0].Part[0].file.
        e.g. /docker/aiogateway/mnt/Movies/Title (2026)/Title (2026).mkv

        Compared against each bound entry's virtual path.
        """
        try:
            path = payload["Metadata"]["Media"][0]["Part"][0]["file"]
            if not path:
                return None
        except (KeyError, IndexError, TypeError):
            return None

        from gateway.stub_manager import virtual_path
        mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt").rstrip("/")
        target = path[len(mountpoint):] if path.startswith(mountpoint) else path
        for stub in self.stubs.listed():
            if virtual_path(stub) == target:
                return stub
        return None

    def _stub_by_guid(self, meta: dict):
        """
        Match using Guid array + parentIndex (season) + index (episode).
        """
        guids = meta.get("Guid") or []
        imdb_id = None
        for g in guids:
            gid = g.get("id", "")
            if gid.startswith("imdb://"):
                imdb_id = gid.replace("imdb://", "").strip()
                break

        if not imdb_id:
            top_guid = meta.get("guid", "")
            m = re.search(r'tt\d+', top_guid)
            if m:
                imdb_id = m.group(0)

        if not imdb_id:
            return None

        media_type = meta.get("type", "")
        season  = meta.get("parentIndex")
        episode = meta.get("index")

        logger.info(
            "Guid match attempt: imdb=%s type=%s season=%s ep=%s",
            imdb_id, media_type, season, episode
        )

        candidates = [s for s in self.stubs.listed() if s.imdb_id == imdb_id]
        if not candidates:
            return None

        if media_type == "episode" and season is not None and episode is not None:
            ep_id = f"{imdb_id}:{season}:{episode}"
            # Multiple stubs can share the same aiostreams_id only if they
            # differ in quality (HD vs 4K stub created separately) — but
            # aiostreams_id doesn't encode quality, so when more than one
            # candidate matches, disambiguate by library section the same
            # way as the movie branch below.
            ep_candidates = [s for s in candidates if s.aiostreams_id == ep_id]
            if not ep_candidates:
                return None
            if len(ep_candidates) == 1:
                return ep_candidates[0]
            return self._disambiguate_by_section(ep_candidates, meta)
        elif media_type == "movie":
            return self._disambiguate_by_section(candidates, meta)

        return None

    def _disambiguate_by_section(self, candidates: list, meta: dict):
        """
        Last-resort quality guess, only reached if neither the FUSE-path nor
        Plex-API-by-ratingKey strategies could determine the real file path.

        Tries librarySectionID first (only useful if HD and 4K are split
        into separate Plex library sections — if they share one section,
        as is common, this can't disambiguate and falls through to the
        videoResolution guess below, which itself is unreliable since it
        reflects the stub file's own small encoded resolution rather than
        the real quality tier until the stream actually resolves).

        Every path through here logs clearly, since reaching this function
        at all means the reliable strategies above failed — see
        _stub_by_rating_key for why that's usually a PLEX_URL/PLEX_TOKEN
        configuration problem, not something wrong with this logic itself.
        """
        logger.warning(
            "Falling back to ambiguous HD/4K guess for %s — the reliable "
            "FUSE-path and Plex-API-ratingKey strategies both failed to "
            "resolve a file path. Check PLEX_URL/PLEX_TOKEN if this happens "
            "often, especially for 4K plays.", meta.get("title", "?")
        )
        section_id = meta.get("librarySectionID")
        if section_id is not None:
            try:
                from gateway.plex_scan import folder_for_section_id
                folder = folder_for_section_id(int(section_id))
                if folder:
                    is_4k_section = "4k" in folder.lower()
                    logger.info("librarySectionID=%s → folder=%s → 4k=%s",
                               section_id, folder, is_4k_section)
                    if is_4k_section:
                        k4 = [s for s in candidates if s.quality.value == "4k"]
                        if k4:
                            return k4[0]
                    else:
                        hd = [s for s in candidates if s.quality.value == "hd"]
                        if hd:
                            return hd[0]
            except Exception as exc:
                logger.warning("Section-based quality disambiguation failed: %s", exc)

        # Fallback: videoResolution metadata (unreliable pre-resolution, but
        # better than nothing if PLEX_URL/PLEX_TOKEN aren't configured or
        # the section lookup failed).
        media_list = meta.get("Media") or []
        is_4k = False
        if media_list:
            res = str(media_list[0].get("videoResolution", "")).lower()
            is_4k = res in ("4k", "2160", "uhd") or "2160" in res
        logger.warning(
            "Section-based disambiguation inconclusive for %s — guessing "
            "from videoResolution=%r (is_4k=%s).",
            meta.get("title", "?"),
            media_list[0].get("videoResolution") if media_list else None,
            is_4k,
        )
        if is_4k:
            k4 = [s for s in candidates if s.quality.value == "4k"]
            return k4[0] if k4 else candidates[0]
        else:
            hd = [s for s in candidates if s.quality.value == "hd"]
            return hd[0] if hd else candidates[0]

    async def _stub_by_rating_key(self, rating_key: str, meta: dict):
        """
        Query Plex's own metadata API for the real file path (reliably
        includes Media/Part even when the webhook payload itself omits it).
        Requires PLEX_URL/PLEX_TOKEN to be configured.

        This is the ONLY strategy that's unambiguous about HD vs 4K without
        relying on librarySectionID or videoResolution guesses (see
        _disambiguate_by_section) — so every silent failure here is a
        silent step down to a guess that's frequently wrong for 4K
        specifically. All failure modes are logged clearly for exactly
        that reason, not just as debug noise.
        """
        plex_url   = os.environ.get("PLEX_URL", "")
        plex_token = os.environ.get("PLEX_TOKEN", "")
        if not plex_url or not plex_token or "your-plex" in plex_url or "your-plex" in plex_token:
            logger.warning(
                "PLEX_URL/PLEX_TOKEN not configured (still using the docker-compose.yml "
                "placeholder values, or unset) — the reliable ratingKey-based stub match "
                "is disabled, so HD/4K disambiguation falls back to a guess that's known "
                "to be biased toward HD. Set real values to fix this."
            )
            return None

        import aiohttp
        try:
            url = f"{plex_url}/library/metadata/{rating_key}"
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    headers={"X-Plex-Token": plex_token, "Accept": "application/json"},
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    if resp.status != 200:
                        logger.warning("Plex API metadata lookup returned HTTP %d for ratingKey=%s",
                                       resp.status, rating_key)
                        return None
                    data = await resp.json()
                    items = (data.get("MediaContainer", {}).get("Metadata", [{}]))
                    if not items:
                        logger.warning("Plex API metadata lookup returned no items for ratingKey=%s", rating_key)
                        return None
                    path = (items[0].get("Media", [{}])[0]
                            .get("Part", [{}])[0]
                            .get("file"))
                    if not path:
                        logger.warning("Plex API metadata for ratingKey=%s had no file path", rating_key)
                        return None
                    logger.info("Plex API file path: %s", path)
                    matched = self._stub_by_fuse_path(
                        {"Metadata": {"Media": [{"Part": [{"file": path}]}]}}
                    )
                    if matched is None:
                        logger.warning(
                            "Plex API returned file path %s but it didn't match any known stub", path
                        )
                    return matched
        except Exception as exc:
            logger.warning("Plex API fallback failed for ratingKey=%s: %s", rating_key, exc)
        return None
