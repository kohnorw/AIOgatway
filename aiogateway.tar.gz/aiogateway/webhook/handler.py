"""
webhook/handler.py
~~~~~~~~~~~~~~~~~~
Handles Plex webhooks (requires Plex Pass).

Plex sends a multipart/form-data POST to our webhook URL when playback events
occur. We listen for "media.play" events, identify which stub is playing
by matching the file path, then resolve the real AIOStreams URL.

Plex webhook event payload (the parts we care about):
  {
    "event": "media.play",
    "Metadata": {
      "type": "movie" | "episode",
      "title": "...",
      "year": ...,
      "guid": "...",            ← contains imdb id sometimes
      "Media": [
        {
          "Part": [
            { "file": "/library/Movies/Inception (2010)/Inception (2010).mkv" }
          ]
        }
      ]
    },
    "Player": { "uuid": "...", "title": "..." }
  }

Setup in Plex:
  Settings → Webhooks → Add Webhook → http://<gateway-ip>:8001/webhook/plex
"""
from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..gateway.stub_manager import StubManager
    from ..gateway.aiostreams_client import AIOStreamsClient
    from ..gateway.models import Quality

logger = logging.getLogger("aiogateway.webhook")

PLAY_EVENTS = {"media.play", "media.resume"}


class PlexWebhookHandler:
    """
    Processes incoming Plex webhook payloads.
    On a play event: identifies the stub → resolves AIOStreams URL → marks active.
    """

    def __init__(
        self,
        stub_manager: "StubManager",
        aiostreams_client: "AIOStreamsClient",
    ) -> None:
        self.stubs = stub_manager
        self.client = aiostreams_client

    async def handle(self, payload_json: str) -> dict:
        """
        Process a Plex webhook payload string.
        Returns a dict describing what action was taken.
        """
        try:
            payload = json.loads(payload_json)
        except json.JSONDecodeError:
            return {"action": "ignored", "reason": "invalid JSON"}

        event = payload.get("event", "")
        if event not in PLAY_EVENTS:
            return {"action": "ignored", "event": event}

        # Extract file path from Metadata.Media[0].Part[0].file
        file_path = self._extract_file_path(payload)
        if not file_path:
            return {"action": "ignored", "reason": "no file path in payload"}

        stub = self.stubs.get_by_path(file_path)
        if not stub:
            return {"action": "ignored", "reason": f"unknown stub path: {file_path}"}

        logger.info(
            "Plex play event: %s | stub=%s quality=%s",
            event, stub.stub_id, stub.quality.value
        )

        # Already active → nothing to do
        if stub.stream_url:
            return {"action": "already_active", "stub_id": stub.stub_id}

        # Mark resolving immediately
        self.stubs.mark_resolving(stub.stub_id)

        # Resolve the real stream URL from AIOStreams
        try:
            stream_obj = await self._resolve_stream(stub)
        except Exception as exc:
            logger.error("Failed to resolve stream for stub %s: %s", stub.stub_id, exc)
            self.stubs.mark_error(stub.stub_id)
            return {"action": "error", "stub_id": stub.stub_id, "error": str(exc)}

        if not stream_obj or not stream_obj.url:
            self.stubs.mark_error(stub.stub_id)
            return {"action": "error", "stub_id": stub.stub_id, "error": "no url returned"}

        self.stubs.mark_active(
            stub.stub_id,
            stream_obj.url,
            stream_obj.request_headers,
        )

        logger.info(
            "Stub %s resolved → %s...", stub.stub_id, stream_obj.url[:60]
        )

        return {
            "action": "resolved",
            "stub_id": stub.stub_id,
            "quality": stub.quality.value,
            "url": stream_obj.url[:80] + "...",
        }

    def _extract_file_path(self, payload: dict) -> str | None:
        try:
            metadata = payload.get("Metadata", {})
            media = metadata.get("Media", [])
            if not media:
                return None
            parts = media[0].get("Part", [])
            if not parts:
                return None
            return parts[0].get("file")
        except (IndexError, KeyError, TypeError):
            return None

    async def _resolve_stream(self, stub):
        """Re-query AIOStreams at play time to get a fresh URL."""
        try:
            from ..gateway.models import MediaItem, MediaType, Quality
        except ImportError:
            from gateway.models import MediaItem, MediaType, Quality

        # Reconstruct a minimal MediaItem from what's in the stub
        media_type = (
            MediaType.MOVIE if stub.aiostreams_type == "movie" else MediaType.SERIES
        )

        # Parse series id  e.g. "tt1234567:1:3" → season=1, episode=3
        parts = stub.aiostreams_id.split(":")
        item = MediaItem(
            id=stub.media_id,
            imdb_id=stub.imdb_id,
            title="",          # not needed for AIOStreams query
            year=None,
            media_type=media_type,
            season=int(parts[1]) if len(parts) >= 3 else None,
            episode=int(parts[2]) if len(parts) >= 3 else None,
        )

        return await self.client.best_for_quality(item, stub.quality)
