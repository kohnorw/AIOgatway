# AIOGateway — playback audit & rebuild

## What was wrong

| # | Problem | Effect on playback |
|---|---------|--------------------|
| 1 | Pack detection only looked at `filename`. Inside a pack the file is named `Show.S02E05…`, and an `SxxEyy` match wins outright, so season/series packs were almost always classed as single episodes. AIOStreams already returns `folderName`, `folderSize`, `infoHash`, `fileIdx` and `parsedFile.folderSeasons/seasonPack`, but none of it was read. | Pack-first ranking, pack fill and pack fast-track rarely fired. Series resolved from whatever single-episode file happened to sort first. |
| 2 | Pack regexes had no token boundary (`DTS5.1` → "season 5", `DS4K` → "season 4"). | Single-episode releases could be ranked as packs. |
| 3 | The known-good-pack memory keyed on the per-episode `filename`. | It could never match the next episode, so it never helped. |
| 4 | Play-time resolution (`search_for_stream`) took the top search result **without probing it and with no fallback**. | A dead top result put the stub ACTIVE on a dead link: the switch "succeeded", Plex rescanned, and the next play failed. |
| 5 | Links were found on request: the UI called `/api/prewarm-new-content/run` after every add, a worker resolved every new stub, and a 6-hourly sweep resolved more. Pack fill also live-probed links at add time. | Links were hours or days old by the time anything was played. |
| 6 | A link that died mid-playback was quietly reverted to placeholder, and the read then returned **placeholder bytes / zeros at the current offset of a real file**. Nothing found a new link until the next play webhook. | Garbled or frozen playback, then a dead "Ready" file. |
| 7 | Playing an already-active stub never refreshed its link, however old. | Old links on rewatch. |
| 8 | No per-stub serialisation: `media.play` and `media.resume` (or the webhook plus prewarm) could resolve the same stub at once. | Duplicate AIOStreams queries and racing state writes. |
| 9 | Network failures retried 5 × 15 s before giving up, and then served placeholder bytes anyway. | Up to 75 s of frozen player, followed by garbage. |
| 10 | `/proxy` never closed upstream responses. | One leaked socket per request or seek. |
| 11 | `fuse_fs` caught only `ImportError`; fusepy raises `OSError` when libfuse is missing. | The whole app crashed on import instead of just disabling the mount. |

## How it works now

All link finding goes through `gateway/resolver.py`. A per-stub lock serialises every operation on a stub.

* **Requests only create placeholders, plus one 4K existence check.** Adding a movie or series (including Radarr/Sonarr migration, the pending-movie sweep, single-episode adds) never keeps, probes or activates a link. The only AIOStreams call is a yes/no "does 4K exist":
  * movie: 1 search; series: 1 search per season (its first episode), run in the background after the HD placeholders are created — or just 1 for the whole show if a 4K series pack turns up; single-episode add: 1 search.
  * a 4K placeholder is created when at least `min_4k_candidates` 4K sources are seen. Turn `check_4k_on_request` off for zero calls (HD only).
  * the auto-episode sweep reuses its season's answer (no search), and only checks when an episode starts a new season.
  * a 4K placeholder whose first play finds no 4K source is removed and 4K marked unavailable for it, so it isn't recreated (Scan 4K clears that).
  * the old per-episode background scan, pack-first fill, pack fast-track and the sweep's 3-per-run throttle are gone — they existed to find/spread out link queries. Scan HD/4K buttons now just create the placeholder.
* **Placeholder switch** (`activate`) runs on a Plex play webhook, a `/proxy` hit, or look-ahead. It does a fresh AIOStreams search and orders the candidates:
  1. Cached (playable now), then unknown, then uncached.
  2. Within each of those, for series: **series pack → season pack (this season) → single episode**. A pack that already worked for this show goes first in its tier.
  3. Language, audio and subtitle preferences.

  Candidates are live-probed in that order. A probe batch never spans two tiers, so a season pack is only tried after every series pack has failed. The first working candidate wins.
* **24-hour refresh** (`refresh`): when an active stub whose link is older than `link_refresh_hours` (default 24) is played, the first FUSE read or the play webhook starts a background refresh. Only a link to the **same file** (matched by infoHash + fileIdx, or by exact size) is swapped in, because Plex already has the old file open. If none exists, the old link is kept while it still works; if it doesn't work, the refresh becomes a repair.
* **Real-time repair** (`repair`): a block fetch that gets 401/403/404/410/451, an error page served as 200, a CDN that stops honouring Range, or 3 failed attempts counts as a broken link. The reading FUSE thread blocks (up to `FUSE_REPAIR_TIMEOUT`, default 45 s) while the event loop finds a new link, then retries the read. Prefetch threads start the repair early without blocking.
  * Same file → playback continues seamlessly.
  * Different release → that file handle gets `EIO` (never mixed bytes), and the stub now points at the new release, so the next play works.
  * Nothing works → `EIO`, and the stub goes to ERROR, which counts toward `dead_stub_max_errors`.
* **Look-ahead**: when "Switch the next episodes when one is played" is on, playing an episode switches the next `lookahead_episodes` (default 2). This replaces the old whole-season fast-track, which created links that were days old by the time most episodes were watched.

## New settings / env

| Name | Default | Meaning |
|------|---------|---------|
| `link_refresh_hours` (setting) | 24 | Age at which an active link is replaced on its next playback. 0 = only replace broken links. |
| `lookahead_episodes` (setting) | 2 | Following episodes switched on play (needs `prewarm_enabled` + TTL on). Each costs one AIOStreams search; set 0 for exactly one search per play. |
| `check_4k_on_request` (setting) | true | Run the single 4K existence check per request (see above). Off = HD placeholders only, zero API calls. |
| `FUSE_READ_ATTEMPTS` (env) | 3 | Attempts per block before a link counts as broken (was a hard-coded 5). |
| `FUSE_REPAIR_TIMEOUT` (env) | 45 | Longest a read waits for a repair. |

Sidecars now also store `stream_file_id` and `stream_filename`. Older sidecars load fine, and same-file matching then falls back to size.
