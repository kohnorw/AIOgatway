"""
gateway/requests.py
~~~~~~~~~~~~~~~~~~~
What someone asked for, but couldn't have yet.

Adding a title normally ends with a file in the library. Sometimes it
can't: the film isn't out, the season hasn't started airing, the episode
aired an hour ago and nothing has been uploaded. Without somewhere to
record the intent, those requests just fail once and are forgotten, and
the person has to remember to come back and ask again — which is exactly
the thing they were trying to avoid by asking in the first place.

Four trackers, each covering a different gap:

**Pending movies** — asked for, nothing findable. Usually unreleased,
sometimes just not cached anywhere yet. Retried on a schedule until a
source turns up or the retry window runs out.

**Waiting episodes** — aired, but no source yet. Uploads routinely lag
broadcast by hours, so this is the common case for anything current.
Same shape as pending movies, keyed per episode.

**Wanted seasons** — a season was requested while *nothing in it had
aired*. This one exists because "requested" everywhere else in the app
means "has at least one file", which a season with no aired episodes can
never satisfy. Episode discovery only reaches into requested seasons, so
without this tracker a purely upcoming season would fail once and never
be picked up when it finally started airing. An entry here clears itself
the moment the season gets its first real file.

**Season watch** — a standing instruction: always track whatever the
next season turns out to be, indefinitely. Distinct from a wanted season,
which is one specific number registered once. This is re-evaluated on
every sweep, so when a show is renewed and a new season appears, it gets
registered without anyone noticing the gap. It is never cleared
automatically — the whole point is that it keeps working through every
future gap, not just the next one.

All four live in one file. They are read together on every sweep and
written together, so splitting them across four files bought nothing but
four chances to end up inconsistent.
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Optional

from .paths import data_dir

logger = logging.getLogger("aiogateway.requests")

_lock = threading.RLock()
_loaded = False

# imdb_id -> record
_pending_movies: dict[str, dict] = {}
# "imdb_id:season:episode" -> record
_waiting_episodes: dict[str, dict] = {}
# "imdb_id:season" -> record
_wanted_seasons: dict[str, dict] = {}
# imdb_id -> record
_season_watch: dict[str, dict] = {}


def _path():
    return data_dir() / "requests.json"


def load() -> None:
    global _loaded
    with _lock:
        if _loaded:
            return
        path = _path()
        if path.exists():
            try:
                data = json.loads(path.read_text())
                _pending_movies.update(data.get("pending_movies") or {})
                _waiting_episodes.update(data.get("waiting_episodes") or {})
                _wanted_seasons.update(data.get("wanted_seasons") or {})
                _season_watch.update(data.get("season_watch") or {})
                logger.info(
                    "Requests: %d pending film(s), %d waiting episode(s), "
                    "%d wanted season(s), %d show(s) watched",
                    len(_pending_movies), len(_waiting_episodes),
                    len(_wanted_seasons), len(_season_watch),
                )
            except Exception as exc:
                logger.error("requests.json unreadable (%s) — starting empty", exc)
        _loaded = True


def save() -> None:
    with _lock:
        payload = {
            "version": 1,
            "pending_movies": _pending_movies,
            "waiting_episodes": _waiting_episodes,
            "wanted_seasons": _wanted_seasons,
            "season_watch": _season_watch,
        }
    path = _path()
    try:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, indent=2))
        os.replace(tmp, path)
    except Exception as exc:
        logger.warning("Could not write requests.json: %s", exc)


# ── pending movies ──────────────────────────────────────────────────────
def add_pending_movie(imdb_id: str, title: str, year: Optional[int] = None,
                      poster: str = "", requested_by: str = "") -> dict:
    """Track a film that couldn't be found yet.

    Re-requesting an already-tracked film is a no-op rather than a reset.
    Otherwise clicking Add a second time would quietly restart its
    give-up clock, and a film nobody can find would be retried forever.
    """
    load()
    with _lock:
        existing = _pending_movies.get(imdb_id)
        if existing:
            return existing
        record = {
            "imdb_id": imdb_id, "title": title, "year": year, "poster": poster,
            "requested_by": requested_by,
            "requested_at": time.time(), "first_missed_at": time.time(),
            "attempts": 0, "last_attempt_at": None, "last_reason": "",
        }
        _pending_movies[imdb_id] = record
    save()
    logger.info("Tracking pending film: %s (%s)", title, imdb_id)
    return record


def remove_pending_movie(imdb_id: str) -> bool:
    load()
    with _lock:
        gone = _pending_movies.pop(imdb_id, None) is not None
    if gone:
        save()
    return gone


def is_pending_movie(imdb_id: str) -> bool:
    load()
    with _lock:
        return imdb_id in _pending_movies


def list_pending_movies() -> list[dict]:
    load()
    with _lock:
        return sorted(_pending_movies.values(), key=lambda r: -(r.get("requested_at") or 0))


# ── waiting episodes ────────────────────────────────────────────────────
def _episode_key(imdb_id: str, season: int, episode: int) -> str:
    return f"{imdb_id}:{season}:{episode}"


def add_waiting_episode(imdb_id: str, season: int, episode: int,
                        title: str = "", poster: str = "",
                        year: Optional[int] = None) -> None:
    load()
    key = _episode_key(imdb_id, season, episode)
    with _lock:
        record = _waiting_episodes.get(key)
        if record:
            record["attempts"] = record.get("attempts", 0) + 1
            record["last_attempt_at"] = time.time()
            return
        _waiting_episodes[key] = {
            "key": key, "imdb_id": imdb_id, "season": season, "episode": episode,
            "title": title, "poster": poster, "year": year,
            "first_missed_at": time.time(), "attempts": 1,
            "last_attempt_at": time.time(),
        }


def clear_waiting_episode(imdb_id: str, season: int, episode: int) -> None:
    load()
    with _lock:
        _waiting_episodes.pop(_episode_key(imdb_id, season, episode), None)


def waiting_episode(imdb_id: str, season: int, episode: int) -> Optional[dict]:
    load()
    with _lock:
        return _waiting_episodes.get(_episode_key(imdb_id, season, episode))


def list_waiting_episodes() -> list[dict]:
    load()
    with _lock:
        return sorted(_waiting_episodes.values(),
                      key=lambda r: (r["imdb_id"], r["season"], r["episode"]))


def gave_up_on_episode(record: dict, retry_days: float) -> bool:
    if not retry_days:
        return False
    return (time.time() - record.get("first_missed_at", 0)) > retry_days * 86400


# ── wanted seasons ──────────────────────────────────────────────────────
def _season_key(imdb_id: str, season: int) -> str:
    return f"{imdb_id}:{season}"


def add_wanted_season(imdb_id: str, season: int, title: str = "",
                      poster: str = "", year: Optional[int] = None,
                      requested_by: str = "") -> bool:
    """Register a season that was asked for before anything in it aired.

    Returns True when this is new, so callers can avoid logging the same
    speculative registration on every sweep.
    """
    load()
    key = _season_key(imdb_id, season)
    with _lock:
        if key in _wanted_seasons:
            return False
        _wanted_seasons[key] = {
            "key": key, "imdb_id": imdb_id, "season": season,
            "title": title, "poster": poster, "year": year,
            "requested_by": requested_by, "requested_at": time.time(),
        }
    save()
    logger.info("Wanted season registered: %s S%02d", title or imdb_id, season)
    return True


def remove_wanted_season(imdb_id: str, season: int) -> bool:
    load()
    with _lock:
        gone = _wanted_seasons.pop(_season_key(imdb_id, season), None) is not None
    if gone:
        save()
    return gone


def wanted_seasons_for(imdb_id: str) -> set[int]:
    load()
    with _lock:
        return {r["season"] for r in _wanted_seasons.values() if r["imdb_id"] == imdb_id}


def list_wanted_seasons() -> list[dict]:
    load()
    with _lock:
        return sorted(_wanted_seasons.values(), key=lambda r: (r["imdb_id"], r["season"]))


# ── season watch ────────────────────────────────────────────────────────
def enable_season_watch(imdb_id: str, title: str = "", poster: str = "",
                        year: Optional[int] = None, requested_by: str = "") -> bool:
    load()
    with _lock:
        if imdb_id in _season_watch:
            return False
        _season_watch[imdb_id] = {
            "imdb_id": imdb_id, "title": title, "poster": poster, "year": year,
            "requested_by": requested_by, "enabled_at": time.time(),
            "last_registered_season": None,
        }
    save()
    logger.info("Watching %s for new seasons", title or imdb_id)
    return True


def disable_season_watch(imdb_id: str) -> bool:
    load()
    with _lock:
        gone = _season_watch.pop(imdb_id, None) is not None
    if gone:
        save()
    return gone


def is_season_watched(imdb_id: str) -> bool:
    load()
    with _lock:
        return imdb_id in _season_watch


def season_watch_record(imdb_id: str) -> Optional[dict]:
    load()
    with _lock:
        return _season_watch.get(imdb_id)


def note_registered_season(imdb_id: str, season: int) -> None:
    load()
    with _lock:
        record = _season_watch.get(imdb_id)
        if record is not None:
            record["last_registered_season"] = season


def list_season_watch() -> list[dict]:
    load()
    with _lock:
        return sorted(_season_watch.values(), key=lambda r: (r.get("title") or "").lower())


# ── shared view ─────────────────────────────────────────────────────────
def tracked_series_ids() -> set[str]:
    """Shows the episode sweep must look at even though they may have no
    files at all — a show whose only interaction was "watch for new
    seasons" has nothing in the library to be discovered by."""
    load()
    with _lock:
        ids = {r["imdb_id"] for r in _wanted_seasons.values()}
        ids |= set(_season_watch)
        ids |= {r["imdb_id"] for r in _waiting_episodes.values()}
        return ids


def summary() -> dict:
    load()
    with _lock:
        return {
            "pending_movies": len(_pending_movies),
            "waiting_episodes": len(_waiting_episodes),
            "wanted_seasons": len(_wanted_seasons),
            "season_watch": len(_season_watch),
        }


def export() -> dict:
    load()
    with _lock:
        return {
            "pending_movies": dict(_pending_movies),
            "waiting_episodes": dict(_waiting_episodes),
            "wanted_seasons": dict(_wanted_seasons),
            "season_watch": dict(_season_watch),
        }


def import_all(data: dict, replace: bool = False) -> int:
    load()
    count = 0
    with _lock:
        if replace:
            _pending_movies.clear()
            _waiting_episodes.clear()
            _wanted_seasons.clear()
            _season_watch.clear()
        for name, target in (
            ("pending_movies", _pending_movies),
            ("waiting_episodes", _waiting_episodes),
            ("wanted_seasons", _wanted_seasons),
            ("season_watch", _season_watch),
        ):
            rows = data.get(name) or {}
            if isinstance(rows, dict):
                target.update(rows)
                count += len(rows)
    save()
    return count
