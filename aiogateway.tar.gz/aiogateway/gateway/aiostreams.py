"""
gateway/aiostreams.py
~~~~~~~~~~~~~~~~~~~~~
The only thing that talks to AIOStreams.

Every path that searches — a play activating a file, the episode sweep,
repair, migration — comes through `search()`, and therefore through one
process-wide rate gate. Each of those callers used to pace itself
independently, which sounds sufficient and isn't: a migration that kicks
off a dozen series scans produces a dozen well-behaved callers all
querying at once, and AIOStreams answers nearly all of it with 429.

Worth knowing when tuning: AIOStreams fans each query out to every addon
configured behind it, so a modest rate here can still be a much larger
burst at the addon layer. How often we query is the only lever this side
of the connection has.
"""
from __future__ import annotations

import asyncio
import base64
import logging
import re
from typing import Optional

import aiohttp

from . import config, debrid, settings
from .models import Candidate, MediaItem, Quality

logger = logging.getLogger("aiogateway.aiostreams")


class AIOStreamsError(RuntimeError):
    pass


class _RateGate:
    """Caps requests in flight and the rate new ones are dispatched.

    Concurrency is fixed when the gate is first used; the minimum gap is
    re-read every request, so it can be retuned from the UI without a
    restart.
    """

    def __init__(self) -> None:
        self._sem: Optional[asyncio.Semaphore] = None
        self._lock = asyncio.Lock()
        self._last = 0.0

    def _semaphore(self) -> asyncio.Semaphore:
        if self._sem is None:
            size = max(1, int(settings.get("aiostreams_max_concurrent", 1) or 1))
            self._sem = asyncio.Semaphore(size)
        return self._sem

    async def __aenter__(self):
        sem = self._semaphore()
        await sem.acquire()
        try:
            async with self._lock:
                gap = max(0.0, float(settings.get("aiostreams_min_interval_ms", 1500))) / 1000.0
                loop = asyncio.get_running_loop()
                wait = gap - (loop.time() - self._last)
                if wait > 0:
                    await asyncio.sleep(wait)
                self._last = loop.time()
        except BaseException:
            sem.release()
            raise
        return self

    async def __aexit__(self, *exc):
        self._semaphore().release()
        return False


_gate = _RateGate()

# Playback takes priority over everything else. While someone is waiting
# on a file to activate, background work yields rather than competing for
# the gate — a sweep can wait a few seconds; a person staring at a
# spinner notices.
_play_priority = 0
_play_lock = asyncio.Lock()


class play_priority:
    """`async with play_priority(): ...` around a play-triggered search."""

    async def __aenter__(self):
        global _play_priority
        async with _play_lock:
            _play_priority += 1
        return self

    async def __aexit__(self, *exc):
        global _play_priority
        async with _play_lock:
            _play_priority = max(0, _play_priority - 1)
        return False


async def yield_to_playback() -> None:
    """Background loops call this between items."""
    while _play_priority > 0:
        await asyncio.sleep(0.5)


# ── Filtering ───────────────────────────────────────────────────────────

def _word_pattern(word: str):
    escaped = re.escape(word.strip())
    if not escaped:
        return None
    return re.compile(rf"(?<![A-Za-z0-9]){escaped}(?![A-Za-z0-9])", re.I)


def _apply_exclusions(candidates: list[Candidate]) -> list[Candidate]:
    words = [w for w in (settings.get("exclude_words") or []) if str(w).strip()]
    if not words:
        return candidates
    patterns = [p for p in (_word_pattern(str(w)) for w in words) if p]
    if not patterns:
        return candidates

    kept = []
    for cand in candidates:
        haystack = " ".join(filter(None, [
            cand.filename or "",
            cand.parsed.quality if cand.parsed else "",
            cand.parsed.resolution if cand.parsed else "",
        ]))
        if any(p.search(haystack) for p in patterns):
            continue
        kept.append(cand)
    return kept


def _apply_size_bounds(candidates: list[Candidate]) -> list[Candidate]:
    gb = 1024 ** 3
    lo = float(settings.get("min_size_gb", 0) or 0) * gb
    hi = float(settings.get("max_size_gb", 0) or 0) * gb
    if not lo and not hi:
        return candidates
    kept = []
    for cand in candidates:
        # A candidate that didn't report a size is kept: dropping it
        # would silently discard whole addons that omit the field.
        if not cand.size:
            kept.append(cand)
            continue
        if lo and cand.size < lo:
            continue
        if hi and cand.size > hi:
            continue
        kept.append(cand)
    return kept


def _apply_usenet_gate(candidates: list[Candidate]) -> list[Candidate]:
    if settings.get("allow_usenet", True):
        return candidates
    return [c for c in candidates if not c.is_usenet]


async def _apply_cache_filter(candidates: list[Candidate],
                              enforce: bool = True) -> list[Candidate]:
    """Ask the configured debrid providers which candidates are really
    cached, then drop the ones that aren't."""
    if not candidates:
        return candidates

    verdicts = await debrid.verify_cached(candidates)
    for cand in candidates:
        if cand.info_hash and cand.info_hash.lower() in verdicts:
            cand.cached_verified = verdicts[cand.info_hash.lower()]

    if not enforce or not settings.get("cached_only", True):
        return candidates

    drop_unknown = bool(settings.get("drop_unknown_cache", False))
    kept = []
    for cand in candidates:
        if cand.cached_verified is True:
            kept.append(cand)
        elif cand.cached_verified is False:
            continue
        elif cand.cached is True:
            kept.append(cand)
        elif cand.cached is None and not drop_unknown:
            kept.append(cand)
    # Never hand back an empty list purely because of cache filtering: a
    # stream of unknown state is still better than no stream, and the
    # alternative is a title that silently refuses to be added.
    return kept or [c for c in candidates if c.cached_verified is not False]


def _rank(candidates: list[Candidate], media_type_is_series: bool) -> list[Candidate]:
    language = (settings.get("preferred_language") or "").strip().lower()
    audio = [str(a).strip().lower() for a in (settings.get("preferred_audio") or []) if str(a).strip()]
    want_subs = bool(settings.get("prefer_subtitles", False))
    want_packs = bool(settings.get("prefer_packs", True)) and media_type_is_series

    def score(cand: Candidate) -> tuple:
        cached = 1 if cand.is_cached else 0
        verified = 1 if cand.cached_verified is True else 0

        lang_hit = 0
        if language and cand.parsed and cand.parsed.languages:
            lang_hit = 1 if any(language in str(l).lower() for l in cand.parsed.languages) else 0

        audio_hit = 0
        if audio and cand.parsed and cand.parsed.audio_tags:
            tags = " ".join(str(t).lower() for t in cand.parsed.audio_tags)
            audio_hit = sum(1 for a in audio if a in tags)

        subs_hit = 1 if (want_subs and cand.subtitles) else 0

        pack_hit = 0
        if want_packs:
            kind, _ = cand.pack
            # Packs tend to be better seeded and more reliably cached, so
            # this is a reliability preference rather than a convenience.
            pack_hit = 2 if kind == "season" else 1 if kind == "series" else 0

        return (cached, verified, lang_hit, audio_hit, subs_hit, pack_hit, cand.size or 0)

    return sorted(candidates, key=score, reverse=True)


# ── Client ──────────────────────────────────────────────────────────────

class AIOStreamsClient:
    def __init__(self) -> None:
        self._session: Optional[aiohttp.ClientSession] = None

    async def open(self) -> None:
        self._session = aiohttp.ClientSession()

    async def close(self) -> None:
        if self._session:
            await self._session.close()
            self._session = None

    def _session_or_raise(self) -> aiohttp.ClientSession:
        if self._session is None:
            raise AIOStreamsError("AIOStreams client is not running")
        return self._session

    async def test(self, url: str = "", uuid: str = "", password: str = "") -> dict:
        """Used by the setup wizard and the Connections tab. Takes
        explicit credentials so the user can test before saving."""
        url = (url or config.secret("aiostreams_url")).rstrip("/")
        uuid = uuid or config.secret("aiostreams_uuid")
        password = password or config.secret("aiostreams_password")
        if not url or not uuid:
            raise AIOStreamsError("Enter the AIOStreams URL and UUID first")

        session = self._session_or_raise()
        endpoint = f"{url}/api/v1/search"
        params = {"type": "movie", "id": "tt0111161"}
        try:
            async with session.get(
                endpoint, params=params, headers=_auth_headers(uuid, password),
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                if resp.status == 401:
                    raise AIOStreamsError("AIOStreams rejected the UUID or password")
                if resp.status == 404:
                    raise AIOStreamsError(
                        f"No search API at {url}. Check the port — AIOStreams "
                        "usually serves on 3000."
                    )
                if resp.status >= 400:
                    raise AIOStreamsError(f"AIOStreams returned HTTP {resp.status}")
                data = await resp.json(content_type=None)
        except aiohttp.ClientConnectorError as exc:
            raise AIOStreamsError(f"Could not reach {url} — {exc}") from exc
        except asyncio.TimeoutError as exc:
            raise AIOStreamsError("AIOStreams did not answer within 30 seconds") from exc

        if not data.get("success"):
            message = ((data.get("error") or {}).get("message")) or "unknown error"
            raise AIOStreamsError(f"AIOStreams returned an error: {message}")

        results = (data.get("data") or {}).get("results", [])
        services = sorted({r.get("service") for r in results if r.get("service")})
        return {"ok": True, "results": len(results), "services": services}

    async def search(self, item: MediaItem, quality: Optional[Quality] = None,
                     enforce_cached: bool = True) -> list[Candidate]:
        """Find playable candidates for `item`, best first.

        Returns an empty list when there is genuinely nothing — the
        caller decides whether that means "not out yet" or "give up".

        `enforce_cached=False` keeps every candidate and only annotates
        its verified cache state. That's for the manual stream picker:
        when someone is choosing a release by hand, hiding the
        uncached ones removes the information they opened the list to
        see. Automatic paths keep the default.
        """
        url, uuid, password = config.aiostreams()
        if not url or not uuid:
            raise AIOStreamsError("AIOStreams is not configured")

        session = self._session_or_raise()
        endpoint = f"{url}/api/v1/search"
        params = {"type": item.search_type, "id": item.search_id}

        async with _gate:
            logger.info("AIOStreams search %s %s", item.search_type, item.search_id)
            try:
                async with session.get(
                    endpoint, params=params, headers=_auth_headers(uuid, password),
                    timeout=aiohttp.ClientTimeout(total=60),
                ) as resp:
                    if resp.status == 429:
                        raise AIOStreamsError("AIOStreams rate limited this search")
                    if resp.status == 401:
                        raise AIOStreamsError("AIOStreams rejected the UUID or password")
                    if resp.status >= 400:
                        raise AIOStreamsError(f"AIOStreams returned HTTP {resp.status}")
                    data = await resp.json(content_type=None)
            except aiohttp.ClientConnectorError as exc:
                raise AIOStreamsError(f"Could not reach AIOStreams at {url}") from exc
            except asyncio.TimeoutError as exc:
                raise AIOStreamsError(
                    f"AIOStreams took over 60s on {item.title}. That usually "
                    "means heavy addon fan-out for this title."
                ) from exc

        if not data.get("success"):
            message = ((data.get("error") or {}).get("message")) or "unknown error"
            raise AIOStreamsError(f"AIOStreams returned an error: {message}")

        payload = data.get("data") or {}
        for err in payload.get("errors") or []:
            logger.warning("AIOStreams addon error — %s: %s",
                           err.get("title", ""), err.get("description", ""))

        # Only results with a direct HTTP URL are usable: a magnet-only
        # result has nothing to hand to a media player.
        raw_results = [r for r in payload.get("results", []) if r.get("url")]
        candidates = [Candidate.from_api(r) for r in raw_results]

        candidates = _apply_usenet_gate(candidates)
        candidates = _apply_exclusions(candidates)
        candidates = _apply_size_bounds(candidates)
        candidates = await _apply_cache_filter(candidates, enforce=enforce_cached)

        if quality is not None:
            candidates = [c for c in candidates if c.quality == quality]

        ranked = _rank(candidates, item.search_type == "series")
        logger.info("AIOStreams: %d raw, %d usable for %s",
                    len(payload.get("results", [])), len(ranked), item.title)
        return ranked

    async def best(self, item: MediaItem, quality: Quality) -> Optional[Candidate]:
        candidates = await self.search(item, quality)
        if quality == Quality.UHD:
            # A lone 4K source is usually a rare, thinly-seeded release
            # that fails more often than it plays. Requiring a few means
            # the file that appears in Movies4K has somewhere to fall
            # back to when the first choice dies.
            minimum = max(1, int(settings.get("min_4k_sources", 4) or 1))
            if len(candidates) < minimum:
                logger.info("Only %d 4K source(s) for %s (need %d) — skipping 4K",
                            len(candidates), item.title, minimum)
                return None
        return candidates[0] if candidates else None


def _auth_headers(uuid: str, password: str) -> dict:
    """AIOStreams authenticates the search API with HTTP Basic, using the
    UUID as the username and the config password as the password."""
    token = base64.b64encode(f"{uuid}:{password}".encode()).decode()
    return {"Accept": "application/json", "Authorization": f"Basic {token}"}
