"""
gateway/torbox_guard.py
~~~~~~~~~~~~~~~~~~~~~~~
The "API saver" layer — a Python port of the techniques warpbox
(github.com/mainlink0435/warpbox) uses to keep a Plex library on TorBox
under the account's rate limit:

  1. Blocking, shared rate limiter  — every TorBox API call (search, add,
     list, requestdl) waits for a start slot instead of failing. One budget
     is shared app-wide; playback gets PRIORITY so background scans can never
     starve a user pressing play.
  2. Persistent SQLite caches (WAL) — CDN download URLs (TTL), the account's
     torrent list (hash → torrent_id + files), and search results. Browsing,
     rescans and repeat plays cost zero API calls.
  3. Negative cache                 — a failed lookup is remembered briefly so
     Plex/scan retry storms don't hammer the API.
  4. Per-torrent circuit breaker    — a torrent that keeps failing is
     quarantined, with an escalating cooldown, so a permanently broken item
     stops burning budget. A TorBox-wide outage never escalates items.
  5. Single-flight                  — N concurrent requests for the same CDN
     URL produce exactly one API call.

Everything here is thread-safe (FUSE read threads + the asyncio loop both
use it). Tunables are read live from gateway.settings.
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import time
from collections import deque
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Optional

log = logging.getLogger("aiogateway.torbox.guard")


def _setting(key: str, default):
    try:
        from gateway import settings as _s
        v = _s.get(key, default)
        return default if v is None else v
    except Exception:
        return default


def data_dir() -> Path:
    override = os.environ.get("LIBRARY_DATA_ROOT")
    if override:
        return Path(override)
    mp = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    return Path(mp.rstrip("/") + "_data")


# ─────────────────────────────────────────────────────────────────────────────
# Stats
# ─────────────────────────────────────────────────────────────────────────────

class _Stats:
    def __init__(self):
        self._lock = threading.Lock()
        self.counters: dict[str, int] = {}
        self._window: deque = deque()   # timestamps of real API calls

    def inc(self, name: str, n: int = 1):
        with self._lock:
            self.counters[name] = self.counters.get(name, 0) + n

    def api_call(self):
        now = time.time()
        with self._lock:
            self._window.append(now)
            while self._window and self._window[0] < now - 60:
                self._window.popleft()

    def snapshot(self) -> dict:
        now = time.time()
        with self._lock:
            while self._window and self._window[0] < now - 60:
                self._window.popleft()
            return {"calls_last_minute": len(self._window), **dict(self.counters)}


stats = _Stats()


# ─────────────────────────────────────────────────────────────────────────────
# 1. Priority rate limiter (start-to-start pacing, shared, thread-safe)
# ─────────────────────────────────────────────────────────────────────────────

HIGH = 0   # playback
LOW  = 1   # background (scans, sweeps, sync, migration)


class RateLimiter:
    """
    Paces call STARTS so the aggregate rate never exceeds `per_minute()`.
    Same model as warpbox's throttle.Limiter, plus a priority lane: while any
    HIGH waiter is queued, LOW callers keep waiting. Also supports a global
    pause after a 429 (TorBox wants breathing room once it rate-limits).
    """

    def __init__(self, name: str, per_minute: Callable[[], float]):
        self.name = name
        self._per_minute = per_minute
        self._cond = threading.Condition()
        self._last_start = 0.0
        self._paused_until = 0.0
        self._high_waiting = 0

    def pause(self, seconds: float):
        with self._cond:
            self._paused_until = max(self._paused_until, time.monotonic() + seconds)
            self._cond.notify_all()
        log.warning("%s limiter paused for %.0fs after rate limit", self.name, seconds)

    def _interval(self) -> float:
        rpm = max(1.0, float(self._per_minute()))
        return 60.0 / rpm

    def wait_time(self, priority: int) -> float:
        """Non-blocking: seconds until this caller could start (0 = now)."""
        with self._cond:
            now = time.monotonic()
            if priority == LOW and self._high_waiting:
                return 0.05
            return max(0.0, self._paused_until - now,
                       self._last_start + self._interval() - now)

    def try_take(self, priority: int) -> bool:
        with self._cond:
            now = time.monotonic()
            if priority == LOW and self._high_waiting:
                return False
            if now < self._paused_until:
                return False
            if now - self._last_start < self._interval():
                return False
            self._last_start = now
            return True

    def acquire(self, priority: int = LOW, cancel: Optional[threading.Event] = None):
        """Blocking acquire for worker threads (FUSE, requests-based calls)."""
        with self._cond:
            if priority == HIGH:
                self._high_waiting += 1
        try:
            while not self.try_take(priority):
                if cancel is not None and cancel.is_set():
                    raise TimeoutError("cancelled while waiting for rate limiter")
                time.sleep(min(max(self.wait_time(priority), 0.01), 1.0))
        finally:
            if priority == HIGH:
                with self._cond:
                    self._high_waiting -= 1


# Main API (api.torbox.app): one collective budget for everything.
api_limiter = RateLimiter("torbox-api", lambda: _setting("torbox_requests_per_minute", 250))
# Search API (search-api.torbox.app) is a separate host with its own limit.
search_limiter = RateLimiter("torbox-search", lambda: _setting("torbox_search_per_minute", 120))
# Adding torrents is limited far more strictly by TorBox than reads.
create_limiter = RateLimiter("torbox-create", lambda: _setting("torbox_create_per_hour", 60) / 60.0)


# ─────────────────────────────────────────────────────────────────────────────
# 2. SQLite store (WAL)
# ─────────────────────────────────────────────────────────────────────────────

_SCHEMA = """
CREATE TABLE IF NOT EXISTS cdn_urls (
    key TEXT PRIMARY KEY, url TEXT NOT NULL, expires_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS torrents (
    hash TEXT PRIMARY KEY, torrent_id INTEGER NOT NULL, name TEXT,
    files TEXT NOT NULL, cached INTEGER NOT NULL DEFAULT 1, synced_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS search_cache (
    key TEXT PRIMARY KEY, payload TEXT NOT NULL, expires_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS negative (
    key TEXT PRIMARY KEY, error TEXT, until REAL NOT NULL
);
"""


class Store:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self._path = str(path)
        self._local = threading.local()
        with self._conn() as c:
            c.executescript(_SCHEMA)

    @contextmanager
    def _conn(self):
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self._path, timeout=10, isolation_level=None,
                                   check_same_thread=False)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA busy_timeout=5000")
            self._local.conn = conn
        yield conn

    # CDN URLs ------------------------------------------------------------
    def get_cdn(self, key: str) -> Optional[str]:
        with self._conn() as c:
            row = c.execute("SELECT url, expires_at FROM cdn_urls WHERE key=?", (key,)).fetchone()
        if row and row[1] > time.time():
            return row[0]
        return None

    def put_cdn(self, key: str, url: str, ttl_seconds: float):
        with self._conn() as c:
            c.execute("INSERT OR REPLACE INTO cdn_urls VALUES (?,?,?)",
                      (key, url, time.time() + ttl_seconds))

    def drop_cdn(self, key: str):
        with self._conn() as c:
            c.execute("DELETE FROM cdn_urls WHERE key=?", (key,))

    # Torrent list (mirror of the account's mylist) ------------------------
    def get_torrent(self, h: str) -> Optional[dict]:
        with self._conn() as c:
            row = c.execute("SELECT torrent_id, name, files, synced_at FROM torrents WHERE hash=?",
                            (h.lower(),)).fetchone()
        if not row:
            return None
        return {"hash": h.lower(), "torrent_id": row[0], "name": row[1],
                "files": json.loads(row[2]), "synced_at": row[3]}

    def put_torrent(self, h: str, torrent_id: int, name: str, files: list[dict]):
        with self._conn() as c:
            c.execute("INSERT OR REPLACE INTO torrents VALUES (?,?,?,?,1,?)",
                      (h.lower(), int(torrent_id), name, json.dumps(files), time.time()))

    def drop_torrent(self, h: str):
        with self._conn() as c:
            c.execute("DELETE FROM torrents WHERE hash=?", (h.lower(),))

    def replace_torrents(self, rows: list[tuple[str, int, str, list]], started_at: float):
        """Mirror the account list. Rows written after the sync started
        (torrents added mid-sync) are kept even if the list didn't have them."""
        now = time.time()
        with self._conn() as c:
            c.execute("BEGIN")
            try:
                c.execute("DELETE FROM torrents WHERE synced_at < ?", (started_at,))
                c.executemany("INSERT OR REPLACE INTO torrents VALUES (?,?,?,?,1,?)",
                              [(h.lower(), int(t), n, json.dumps(f), now) for h, t, n, f in rows])
                c.execute("COMMIT")
            except Exception:
                c.execute("ROLLBACK")
                raise

    def torrent_count(self) -> int:
        with self._conn() as c:
            return c.execute("SELECT COUNT(*) FROM torrents").fetchone()[0]

    # Search cache ------------------------------------------------------------
    def get_search(self, key: str) -> Optional[Any]:
        with self._conn() as c:
            row = c.execute("SELECT payload, expires_at FROM search_cache WHERE key=?", (key,)).fetchone()
        if row and row[1] > time.time():
            return json.loads(row[0])
        return None

    def put_search(self, key: str, payload: Any, ttl_seconds: float):
        with self._conn() as c:
            c.execute("INSERT OR REPLACE INTO search_cache VALUES (?,?,?)",
                      (key, json.dumps(payload), time.time() + ttl_seconds))

    def drop_search(self, prefix: str):
        with self._conn() as c:
            c.execute("DELETE FROM search_cache WHERE key LIKE ?", (prefix + "%",))

    # Negative cache ----------------------------------------------------------
    def get_negative(self, key: str) -> Optional[str]:
        with self._conn() as c:
            row = c.execute("SELECT error, until FROM negative WHERE key=?", (key,)).fetchone()
        if row and row[1] > time.time():
            return row[0] or "recent failure"
        return None

    def put_negative(self, key: str, error: str, ttl_seconds: float):
        with self._conn() as c:
            c.execute("INSERT OR REPLACE INTO negative VALUES (?,?,?)",
                      (key, error[:300], time.time() + ttl_seconds))

    def drop_negative(self, key: str):
        with self._conn() as c:
            c.execute("DELETE FROM negative WHERE key=?", (key,))

    def reset_account_data(self):
        """Called when the API key changes: torrent ids, CDN links and
        "couldn't add" results belong to the old account. Search results
        (TorBox-wide cache status) are kept."""
        with self._conn() as c:
            c.execute("DELETE FROM torrents")
            c.execute("DELETE FROM cdn_urls")
            c.execute("DELETE FROM negative")

    # Maintenance -------------------------------------------------------------
    def sweep(self) -> int:
        now = time.time()
        n = 0
        with self._conn() as c:
            for table, col in (("cdn_urls", "expires_at"), ("search_cache", "expires_at"),
                               ("negative", "until")):
                n += c.execute(f"DELETE FROM {table} WHERE {col} < ?", (now,)).rowcount
        return n

    def counts(self) -> dict:
        now = time.time()
        with self._conn() as c:
            return {
                "cached_cdn_urls": c.execute("SELECT COUNT(*) FROM cdn_urls WHERE expires_at>?", (now,)).fetchone()[0],
                "cached_searches": c.execute("SELECT COUNT(*) FROM search_cache WHERE expires_at>?", (now,)).fetchone()[0],
                "negative_entries": c.execute("SELECT COUNT(*) FROM negative WHERE until>?", (now,)).fetchone()[0],
                "known_torrents": c.execute("SELECT COUNT(*) FROM torrents").fetchone()[0],
            }


_store: Optional[Store] = None
_store_lock = threading.Lock()


def store() -> Store:
    global _store
    if _store is None:
        with _store_lock:
            if _store is None:
                _store = Store(data_dir() / "torbox_cache.sqlite3")
    return _store


# ─────────────────────────────────────────────────────────────────────────────
# 4. Circuit breaker (per torrent hash)
# ─────────────────────────────────────────────────────────────────────────────

class CircuitBreaker:
    """
    Trips after N failures inside a sliding window, then short-circuits all
    calls for that torrent for a stale window. When the window expires one
    half-open probe is allowed. An item that keeps failing while the API is
    otherwise healthy has its stale window doubled each cycle (capped), so a
    permanently broken torrent stops being hammered. If lots of different
    items are failing at once it's a TorBox-wide problem, and nothing
    escalates.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._fail: dict[str, deque] = {}
        self._stale_until: dict[str, float] = {}
        self._stale_minutes: dict[str, float] = {}
        self._recent_ok: deque = deque(maxlen=50)

    def is_open(self, h: str) -> bool:
        h = h.lower()
        with self._lock:
            until = self._stale_until.get(h)
            if not until:
                return False
            if time.time() < until:
                stats.inc("breaker_short_circuits")
                return True
            # half-open: allow exactly one probe, re-arm a short lock
            self._stale_until[h] = time.time() + 30
            return False

    def success(self, h: str):
        h = h.lower()
        with self._lock:
            self._recent_ok.append(time.time())
            self._fail.pop(h, None)
            self._stale_until.pop(h, None)
            self._stale_minutes.pop(h, None)

    def failure(self, h: str, error: str = ""):
        h = h.lower()
        window = float(_setting("torbox_breaker_window_seconds", 600))
        threshold = int(_setting("torbox_breaker_failures", 5))
        base = float(_setting("torbox_breaker_stale_minutes", 5))
        cap = float(_setting("torbox_breaker_max_stale_minutes", 60))
        now = time.time()
        with self._lock:
            dq = self._fail.setdefault(h, deque())
            dq.append(now)
            while dq and dq[0] < now - window:
                dq.popleft()
            if len(dq) < threshold:
                return
            api_healthy = sum(1 for t in self._recent_ok if t > now - window) > 0
            prev = self._stale_minutes.get(h)
            minutes = min(cap, prev * 2) if (prev and api_healthy) else base
            self._stale_minutes[h] = minutes
            self._stale_until[h] = now + minutes * 60
            dq.clear()
        stats.inc("breaker_trips")
        log.warning("Circuit breaker: torrent %s… quarantined for %.0f min (%s)", h[:10], minutes, error[:120])

    def reset(self):
        with self._lock:
            self._fail.clear()
            self._stale_until.clear()
            self._stale_minutes.clear()

    def open_count(self) -> int:
        now = time.time()
        with self._lock:
            return sum(1 for u in self._stale_until.values() if u > now)


breaker = CircuitBreaker()


# ─────────────────────────────────────────────────────────────────────────────
# 5. Single-flight
# ─────────────────────────────────────────────────────────────────────────────

class SingleFlight:
    def __init__(self):
        self._lock = threading.Lock()
        self._calls: dict[str, tuple[threading.Event, list]] = {}

    def do(self, key: str, fn: Callable[[], Any]) -> Any:
        with self._lock:
            existing = self._calls.get(key)
            if existing is None:
                ev, box = threading.Event(), []
                self._calls[key] = (ev, box)
                leader = True
            else:
                ev, box = existing
                leader = False
        if not leader:
            stats.inc("singleflight_joins")
            ev.wait(timeout=180)
            if not box:
                raise TimeoutError(f"single-flight leader for {key} did not finish")
            ok, val = box[0]
            if ok:
                return val
            raise val
        try:
            result = fn()
            box.append((True, result))
            return result
        except BaseException as exc:   # noqa: BLE001 — re-raised to every waiter
            box.append((False, exc))
            raise
        finally:
            ev.set()
            with self._lock:
                self._calls.pop(key, None)


singleflight = SingleFlight()
