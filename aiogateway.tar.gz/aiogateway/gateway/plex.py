"""
gateway/plex.py
~~~~~~~~~~~~~~~
Everything that talks to the Plex Media Server.

Three jobs:

  test()          — the wizard's "Test" button, and the Connections tab.
  refresh_path()  — a scan scoped to one folder, run right after a file
                    activates so the real media shows up promptly.
  analyze()       — ask Plex to re-read a file it already knows about.

`analyze` is rate-limited per entry on purpose. Plex's analysis reads
chunks of the file to work out bitrate, audio and subtitle streams —
through this filesystem that is real traffic across a debrid CDN, not a
local disk read. Doing it on every play of an episode someone is
rewatching costs bandwidth and buys nothing, so it runs once and then
not again until the cooldown passes.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Optional

import aiohttp
import requests

from . import config

logger = logging.getLogger("aiogateway.plex")

TIMEOUT = 8


class PlexError(RuntimeError):
    pass


async def test(url: str = "", token: str = "") -> dict:
    """Confirm the server answers and the token is accepted."""
    url = (url or config.secret("plex_url")).rstrip("/")
    token = token or config.secret("plex_token")
    if not url or not token:
        raise PlexError("Enter the Plex URL and token first")

    headers = {"Accept": "application/json", "X-Plex-Token": token}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{url}/identity", headers=headers,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                if resp.status == 401:
                    raise PlexError("Plex rejected the token")
                if resp.status >= 400:
                    raise PlexError(f"Plex returned HTTP {resp.status}")
                identity = await resp.json(content_type=None)

            async with session.get(
                f"{url}/", headers=headers,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                root = await resp.json(content_type=None) if resp.status < 400 else {}
    except aiohttp.ClientConnectorError as exc:
        raise PlexError(f"Could not reach {url} — {exc}") from exc
    except TimeoutError as exc:
        raise PlexError("Plex did not answer within 15 seconds") from exc

    container = (identity.get("MediaContainer") or {})
    root_container = (root.get("MediaContainer") or {})
    return {
        "ok": True,
        "server": root_container.get("friendlyName") or "Plex Media Server",
        "version": container.get("version") or root_container.get("version", ""),
        "machine_id": container.get("machineIdentifier", ""),
    }


async def sections() -> list[dict]:
    url, token = config.plex()
    if not url or not token:
        return []
    headers = {"Accept": "application/json", "X-Plex-Token": token}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{url}/library/sections", headers=headers,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                if resp.status >= 400:
                    return []
                data = await resp.json(content_type=None)
    except Exception as exc:
        logger.warning("Could not list Plex sections: %s", exc)
        return []

    out = []
    for directory in (data.get("MediaContainer") or {}).get("Directory", []) or []:
        locations = [loc.get("path", "") for loc in directory.get("Location", []) or []]
        out.append({
            "id": directory.get("key"),
            "title": directory.get("title"),
            "type": directory.get("type"),
            "paths": locations,
        })
    return out


# ── scoped scanning ─────────────────────────────────────────────────────
_section_cache: dict[str, str] = {}
_section_cache_at = 0.0
_section_lock = threading.Lock()
_SECTION_TTL = 300


def _refresh_sections(url: str, token: str) -> None:
    global _section_cache_at
    try:
        response = requests.get(
            f"{url}/library/sections",
            params={"X-Plex-Token": token},
            headers={"Accept": "application/json"},
            timeout=TIMEOUT,
        )
        if response.status_code != 200:
            return
        directories = (response.json().get("MediaContainer") or {}).get("Directory", [])
    except Exception as exc:
        logger.warning("Could not refresh Plex sections: %s", exc)
        return

    with _section_lock:
        _section_cache.clear()
        for directory in directories:
            for location in directory.get("Location", []) or []:
                path = location.get("path")
                if path:
                    _section_cache[path.rstrip("/")] = directory.get("key")
        _section_cache_at = time.time()


def _section_for(folder: str) -> Optional[str]:
    url, token = config.plex()
    if not url or not token:
        return None
    if time.time() - _section_cache_at > _SECTION_TTL:
        _refresh_sections(url, token)
    with _section_lock:
        # Longest matching library root wins, so /library/Movies4K isn't
        # matched by a /library section that also happens to be mapped.
        best = None
        for root, section in _section_cache.items():
            if folder == root or folder.startswith(root + "/"):
                if best is None or len(root) > len(best[0]):
                    best = (root, section)
        return best[1] if best else None


def refresh_path(folder: str) -> None:
    """Scan one folder rather than a whole library section. Cheap enough
    to call on every activation."""
    url, token = config.plex()
    if not url or not token:
        return
    section = _section_for(folder)
    try:
        if section:
            requests.get(
                f"{url}/library/sections/{section}/refresh",
                params={"path": folder, "X-Plex-Token": token},
                timeout=TIMEOUT,
            )
            logger.debug("Plex scan requested for %s (section %s)", folder, section)
        else:
            # No section maps this path — the user hasn't added the
            # library folders to Plex yet. Nothing to scan, and a full
            # refresh would be the wrong thing to do about it.
            logger.debug("No Plex section covers %s — skipping scan", folder)
    except Exception as exc:
        logger.warning("Plex scan for %s failed: %s", folder, exc)


def refresh_path_async(folder: str) -> None:
    threading.Thread(target=refresh_path, args=(folder,), daemon=True).start()


def analyze(rating_key: str) -> None:
    url, token = config.plex()
    if not url or not token or not rating_key:
        return
    try:
        requests.put(
            f"{url}/library/metadata/{rating_key}/analyze",
            params={"X-Plex-Token": token},
            timeout=TIMEOUT,
        )
    except Exception as exc:
        logger.warning("Plex analyze for %s failed: %s", rating_key, exc)


def analyze_async(rating_key: str) -> None:
    threading.Thread(target=analyze, args=(rating_key,), daemon=True).start()


def find_by_path(virtual_path: str) -> Optional[str]:
    """Look up a ratingKey from a file path, for webhook payloads that
    arrive without one."""
    url, token = config.plex()
    if not url or not token:
        return None
    try:
        response = requests.get(
            f"{url}/library/all",
            params={"file": virtual_path, "X-Plex-Token": token},
            headers={"Accept": "application/json"},
            timeout=TIMEOUT,
        )
        if response.status_code != 200:
            return None
        items = (response.json().get("MediaContainer") or {}).get("Metadata", [])
        return items[0].get("ratingKey") if items else None
    except Exception:
        return None


# ── account membership ──────────────────────────────────────────────────
async def account_has_access(plex_account_id: str) -> bool:
    """True when this Plex account owns the configured server or has been
    shared into it.

    This is what stops any Plex.tv account on the internet from signing
    in. It asks the admin's own token for the server's identity and for
    its shared-user list, and matches the account against both.
    """
    url, token = config.plex()
    if not url or not token:
        return False

    headers = {"Accept": "application/json", "X-Plex-Token": token}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "https://plex.tv/api/v2/user", headers=headers,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                owner = await resp.json(content_type=None) if resp.status < 400 else {}
            if str(owner.get("id", "")) == str(plex_account_id):
                return True

            async with session.get(
                f"{url}/accounts", headers=headers,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                if resp.status < 400:
                    data = await resp.json(content_type=None)
                    accounts = (data.get("MediaContainer") or {}).get("Account", []) or []
                    if any(str(a.get("id")) == str(plex_account_id) for a in accounts):
                        return True

            # Shared users live on plex.tv, not on the server itself.
            async with session.get(
                "https://plex.tv/api/v2/home/users", headers=headers,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                if resp.status < 400:
                    data = await resp.json(content_type=None)
                    users = data.get("users") if isinstance(data, dict) else data
                    for user in users or []:
                        if str(user.get("id")) == str(plex_account_id):
                            return True
    except Exception as exc:
        logger.warning("Could not check Plex server access: %s", exc)
        return False
    return False
