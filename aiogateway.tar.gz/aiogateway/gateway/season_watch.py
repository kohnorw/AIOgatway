"""
gateway/season_watch.py
~~~~~~~~~~~~~~~~~~~~~~~~
Persistent per-show flag: "always speculatively track whatever the next
season turns out to be, indefinitely" — set once via the Library modal's
"New" button, never needs re-clicking again for this show.

This is a different concept from gateway/wanted_seasons.py, which tracks
one SPECIFIC season number at a time (registered by a single action, and
cleared once that season gets its first stub). This module instead
records a STANDING INTENT, re-evaluated fresh on every auto-episode sweep
cycle: whenever a watched show becomes caught up to the edge of what
Cinemeta currently knows (its highest tracked season is fully aired and
stubbed, with nothing scheduled beyond it), the sweep automatically
registers the next season number in wanted_seasons on its own — no
person needs to notice the gap and click anything.

A show stays in here until explicitly turned off (Config page, or a
future per-show "stop watching" action) — it is NOT auto-removed the way
wanted_seasons entries are, since the whole point is that it should keep
working through every future gap, not just the next one.
"""
from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger("aiogateway.seasonwatch")

# imdb_id -> {imdb_id, title, poster, year, enabled_at}
_watched: dict[str, dict] = {}
_loaded = False


def _state_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_season_watch.json"


def _load() -> None:
    global _watched, _loaded
    if _loaded:
        return
    path = _state_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text())
            _watched = {item["imdb_id"]: item for item in raw}
            logger.info("Loaded %d season-watch entries from %s", len(_watched), path)
    except Exception as exc:
        logger.warning("Could not load season-watch state from %s: %s", path, exc)
        _watched = {}
    _loaded = True


def _persist() -> None:
    path = _state_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(list(_watched.values()), indent=2))
    except Exception as exc:
        logger.warning("Could not persist season-watch state to %s: %s", path, exc)


def enable(imdb_id: str, title: str, poster: str = "", year: Optional[int] = None) -> None:
    _load()
    if imdb_id in _watched:
        return
    _watched[imdb_id] = {
        "imdb_id": imdb_id, "title": title, "poster": poster, "year": year,
        "enabled_at": time.time(),
    }
    _persist()
    logger.info("Enabled indefinite season-watch for %s (%s)", title, imdb_id)


def disable(imdb_id: str) -> bool:
    _load()
    if imdb_id in _watched:
        del _watched[imdb_id]
        _persist()
        return True
    return False


def is_enabled(imdb_id: str) -> bool:
    _load()
    return imdb_id in _watched


def list_all() -> list[dict]:
    _load()
    return list(_watched.values())
