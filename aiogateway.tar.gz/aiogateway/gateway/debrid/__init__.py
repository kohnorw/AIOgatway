"""
gateway/debrid/__init__.py
~~~~~~~~~~~~~~~~~~~~~~~~~~
The registry, and the one function the rest of the app calls.

`verify_cached()` takes the candidate streams AIOStreams returned and
asks the relevant provider which of them are actually cached. Candidates
are grouped by the service that produced them, so a library where some
results come from TorBox and others from AllDebrid asks each provider
only about its own.
"""
from __future__ import annotations

import logging
import time
from typing import Optional

import aiohttp

from .base import DebridError, DebridService, ServiceInfo
from .alldebrid import AllDebrid, shutdown as alldebrid_shutdown
from .providers import (
    DebridLink, EasyDebrid, Offcloud, PikPak, Premiumize,
    PutIo, RealDebrid, Seedr, TorBox,
)

logger = logging.getLogger("aiogateway.debrid")

_CLASSES: tuple[type[DebridService], ...] = (
    RealDebrid, AllDebrid, Premiumize, TorBox, DebridLink,
    EasyDebrid, Offcloud, PutIo, Seedr, PikPak,
)

SERVICES: dict[str, ServiceInfo] = {cls.info.key: cls.info for cls in _CLASSES}
_BY_KEY: dict[str, type[DebridService]] = {cls.info.key: cls for cls in _CLASSES}

# alias -> service key, so a result's `service` string can be matched to
# a configured provider.
_ALIASES: dict[str, str] = {}
for _cls in _CLASSES:
    _ALIASES[_cls.info.key] = _cls.info.key
    for _alias in _cls.info.aliases:
        _ALIASES[_alias] = _cls.info.key


def service_key_for(name: Optional[str]) -> Optional[str]:
    if not name:
        return None
    return _ALIASES.get(name.strip().lower())


def build(service_key: str, api_key: str) -> DebridService:
    return _BY_KEY[service_key](api_key)


def catalogue() -> list[dict]:
    """Everything the Streams tab needs to render the provider list."""
    from .. import config
    out = []
    for key, info in SERVICES.items():
        limits = config.debrid_limits(key)
        out.append({
            "key": key,
            "name": info.name,
            "short": info.short,
            "supports_cache_check": info.supports_cache_check,
            "note": info.cache_check_note,
            "enabled": bool(config.get(f"debrid_{key}_enabled")),
            "key_set": bool(config.debrid_key(key)),
            "key_masked": config.public_view().get(f"debrid_{key}_api_key", ""),
            "rpm": limits["rpm"],
            "concurrency": limits["concurrency"],
            "spacing_ms": limits["spacing_ms"],
            "default_rpm": info.default_rpm,
            "default_concurrency": info.default_concurrency,
            "default_spacing_ms": info.default_spacing_ms,
        })
    return out


async def test_service(service_key: str, api_key: str) -> dict:
    if service_key not in _BY_KEY:
        raise DebridError(f"Unknown service {service_key}")
    svc = build(service_key, api_key)
    async with aiohttp.ClientSession() as session:
        return await svc.test(session)


# ── verdict memo ────────────────────────────────────────────────────────
# Cache state moves, but not second to second, and a search for one
# episode routinely re-asks about hashes a neighbouring search just
# resolved. Memoising verdicts keeps a season scan from spending its
# whole rate budget re-confirming the same answers.
_memo: dict[tuple[str, str], tuple[float, bool]] = {}


def _memo_ttl() -> float:
    from .. import settings
    return float(settings.get("debrid_cache_ttl_seconds", 300) or 300)


def forget(hash_: str) -> None:
    """Drop memoised verdicts for a hash. Called when a link that was
    reported cached turns out to be dead, so the next search re-asks
    instead of trusting the stale yes."""
    h = (hash_ or "").lower()
    for key in [k for k in _memo if k[1] == h]:
        _memo.pop(key, None)


async def verify_cached(candidates: list) -> dict[str, bool]:
    """Ask each configured provider about the hashes it is responsible
    for. Returns hash -> cached for the hashes that got a verdict.

    Anything without a verdict is deliberately absent from the result,
    which callers read as "use whatever AIOStreams said".
    """
    from .. import config, settings

    if not settings.get("verify_cache_with_debrid", True):
        return {}

    by_service: dict[str, list] = {}
    names: dict[str, str] = {}
    for cand in candidates:
        if not cand.info_hash:
            continue
        key = service_key_for(cand.service)
        if not key or not config.debrid_enabled(key):
            continue
        if not SERVICES[key].supports_cache_check:
            continue
        by_service.setdefault(key, []).append(cand.info_hash.lower())
        names.setdefault(cand.info_hash.lower(), cand.filename or "")

    if not by_service:
        return {}

    max_probe = max(0, int(settings.get("debrid_max_probe", 12) or 0))
    ttl = _memo_ttl()
    now = time.time()
    verdicts: dict[str, bool] = {}

    async with aiohttp.ClientSession() as session:
        for service_key, hashes in by_service.items():
            # Preserve order (AIOStreams returns best-first) while
            # dropping duplicates, so the probe budget is spent on the
            # candidates most likely to be picked.
            ordered = list(dict.fromkeys(hashes))
            fresh = []
            for h in ordered:
                memo = _memo.get((service_key, h))
                if memo and now - memo[0] < ttl:
                    verdicts[h] = memo[1]
                else:
                    fresh.append(h)
            if max_probe:
                fresh = fresh[:max_probe]
            if not fresh:
                continue

            svc = build(service_key, config.debrid_key(service_key))
            try:
                result = await svc.check_cached(session, fresh, names)
            except DebridError as exc:
                logger.warning("%s cache check unavailable: %s", service_key, exc)
                continue
            except Exception as exc:
                logger.warning("%s cache check errored: %s", service_key, exc)
                continue

            for h, cached in result.items():
                _memo[(service_key, h)] = (now, bool(cached))
                verdicts[h] = bool(cached)

    return verdicts


async def shutdown() -> None:
    await alldebrid_shutdown()
