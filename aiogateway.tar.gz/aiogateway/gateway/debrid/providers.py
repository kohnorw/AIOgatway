"""
gateway/debrid/providers.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~
Every debrid service AIOStreams can be configured with, apart from
AllDebrid (see alldebrid.py, which needs the probe-and-clean dance).

Each one implements `test` so the Streams tab can confirm a key works,
and `check_cached` where the provider actually offers a way to ask.

Where it doesn't, `supports_cache_check` is False and `check_cached`
returns nothing. Real-Debrid is the significant case: it removed its
instant-availability endpoint outright, and there is no replacement that
reads cache state without adding the torrent to the account first — which
is a side effect nobody asked for on a stream that may not even get
picked. Those results keep using the AIOStreams flag, exactly as they
would if no key were configured.
"""
from __future__ import annotations

import logging
from typing import Optional

import aiohttp

from .base import DebridError, DebridService, ServiceInfo, magnet_for

logger = logging.getLogger("aiogateway.debrid.providers")


class RealDebrid(DebridService):
    info = ServiceInfo(
        key="realdebrid",
        name="Real-Debrid",
        short="RD",
        aliases=("realdebrid", "real-debrid", "rd"),
        supports_cache_check=False,
        cache_check_note=(
            "Real-Debrid removed its cache-check endpoint, and the only way "
            "left to read cache state is to add the torrent to your account. "
            "AIOGateway won't do that just to evaluate a candidate, so these "
            "results use the cache flag AIOStreams reports."
        ),
        default_rpm=200, default_concurrency=2, default_spacing_ms=300,
    )

    async def test(self, session: aiohttp.ClientSession) -> dict:
        data = await self._request(
            session, "GET", "https://api.real-debrid.com/rest/1.0/user",
            headers={"Authorization": f"Bearer {self.api_key}"},
        )
        return {
            "ok": True,
            "account": data.get("username", "Real-Debrid account"),
            "premium": data.get("type") == "premium",
            "expires": data.get("expiration"),
        }


class Premiumize(DebridService):
    info = ServiceInfo(
        key="premiumize",
        name="Premiumize",
        short="PM",
        aliases=("premiumize", "pm"),
        supports_cache_check=True,
        cache_check_note="Premiumize answers cache lookups directly, in one call per batch.",
        default_rpm=120, default_concurrency=2, default_spacing_ms=300,
    )

    async def test(self, session: aiohttp.ClientSession) -> dict:
        data = await self._request(
            session, "GET", "https://www.premiumize.me/api/account/info",
            params={"apikey": self.api_key},
        )
        if data.get("status") != "success":
            raise DebridError(data.get("message") or "Premiumize rejected the key")
        return {
            "ok": True,
            "account": data.get("customer_id", "Premiumize account"),
            "premium": True,
            "expires": data.get("premium_until"),
        }

    async def check_cached(
        self, session: aiohttp.ClientSession, hashes: list[str],
        names: Optional[dict[str, str]] = None,
    ) -> dict[str, bool]:
        if not hashes:
            return {}
        params = [("apikey", self.api_key)] + [("items[]", h) for h in hashes]
        try:
            data = await self._request(
                session, "GET", "https://www.premiumize.me/api/cache/check", params=params,
            )
        except DebridError as exc:
            logger.warning("Premiumize cache check failed: %s", exc)
            return {}
        if data.get("status") != "success":
            return {}
        response = data.get("response") or []
        # Positional: response[i] corresponds to hashes[i]. A short or
        # mismatched array means the mapping can't be trusted, so no
        # verdicts are returned rather than misattributed ones.
        if len(response) != len(hashes):
            logger.warning("Premiumize returned %d verdicts for %d hashes — ignoring",
                           len(response), len(hashes))
            return {}
        return {h.lower(): bool(v) for h, v in zip(hashes, response)}


class TorBox(DebridService):
    info = ServiceInfo(
        key="torbox",
        name="TorBox",
        short="TB",
        aliases=("torbox", "tb"),
        supports_cache_check=True,
        cache_check_note="TorBox has a dedicated cached-torrent lookup that takes a batch of hashes.",
        default_rpm=60, default_concurrency=1, default_spacing_ms=800,
    )

    async def test(self, session: aiohttp.ClientSession) -> dict:
        data = await self._request(
            session, "GET", "https://api.torbox.app/v1/api/user/me",
            headers={"Authorization": f"Bearer {self.api_key}"},
        )
        if not data.get("success", True):
            raise DebridError(data.get("detail") or "TorBox rejected the key")
        user = data.get("data") or {}
        return {
            "ok": True,
            "account": user.get("email", "TorBox account"),
            "premium": bool(user.get("plan")),
            "expires": user.get("premium_expires_at"),
        }

    async def check_cached(
        self, session: aiohttp.ClientSession, hashes: list[str],
        names: Optional[dict[str, str]] = None,
    ) -> dict[str, bool]:
        if not hashes:
            return {}
        params = [("format", "object"), ("list_files", "false")]
        params += [("hash", h) for h in hashes]
        try:
            data = await self._request(
                session, "GET", "https://api.torbox.app/v1/api/torrents/checkcached",
                params=params, headers={"Authorization": f"Bearer {self.api_key}"},
            )
        except DebridError as exc:
            logger.warning("TorBox cache check failed: %s", exc)
            return {}
        payload = data.get("data")
        # Absent hashes mean "not cached" here: TorBox answers with only
        # the hashes it holds, so a missing key is a real negative rather
        # than a missing verdict.
        if isinstance(payload, dict):
            found = {k.lower() for k in payload}
        elif isinstance(payload, list):
            found = {(e.get("hash") or "").lower() for e in payload if isinstance(e, dict)}
        else:
            return {}
        return {h.lower(): h.lower() in found for h in hashes}


class DebridLink(DebridService):
    info = ServiceInfo(
        key="debridlink",
        name="Debrid-Link",
        short="DL",
        aliases=("debridlink", "debrid-link", "dl"),
        supports_cache_check=True,
        cache_check_note="Debrid-Link exposes a seedbox cache lookup keyed by info hash.",
        default_rpm=120, default_concurrency=1, default_spacing_ms=500,
    )

    async def test(self, session: aiohttp.ClientSession) -> dict:
        data = await self._request(
            session, "GET", "https://debrid-link.com/api/v2/account/infos",
            headers={"Authorization": f"Bearer {self.api_key}"},
        )
        if not data.get("success", True):
            raise DebridError("Debrid-Link rejected the key")
        value = data.get("value") or {}
        return {
            "ok": True,
            "account": value.get("email", "Debrid-Link account"),
            "premium": bool(value.get("premiumLeft")),
            "expires": value.get("premiumLeft"),
        }

    async def check_cached(
        self, session: aiohttp.ClientSession, hashes: list[str],
        names: Optional[dict[str, str]] = None,
    ) -> dict[str, bool]:
        if not hashes:
            return {}
        try:
            data = await self._request(
                session, "GET", "https://debrid-link.com/api/v2/seedbox/cached",
                params={"url": ",".join(hashes)},
                headers={"Authorization": f"Bearer {self.api_key}"},
            )
        except DebridError as exc:
            logger.warning("Debrid-Link cache check failed: %s", exc)
            return {}
        if not data.get("success", True):
            return {}
        value = data.get("value") or {}
        if not isinstance(value, dict):
            return {}
        return {h.lower(): bool(value.get(h) or value.get(h.lower())) for h in hashes}


class EasyDebrid(DebridService):
    info = ServiceInfo(
        key="easydebrid",
        name="EasyDebrid",
        short="ED",
        aliases=("easydebrid", "easy-debrid", "ed"),
        supports_cache_check=True,
        cache_check_note="EasyDebrid answers a batch magnet lookup with per-item cache state.",
        default_rpm=90, default_concurrency=1, default_spacing_ms=500,
    )

    async def test(self, session: aiohttp.ClientSession) -> dict:
        data = await self._request(
            session, "GET", "https://easydebrid.com/api/v1/user/details",
            headers={"Authorization": f"Bearer {self.api_key}"},
        )
        return {
            "ok": True,
            "account": data.get("email") or "EasyDebrid account",
            "premium": bool(data.get("paid", True)),
            "expires": data.get("expiry"),
        }

    async def check_cached(
        self, session: aiohttp.ClientSession, hashes: list[str],
        names: Optional[dict[str, str]] = None,
    ) -> dict[str, bool]:
        if not hashes:
            return {}
        names = names or {}
        try:
            data = await self._request(
                session, "POST", "https://easydebrid.com/api/v1/link/lookup",
                json={"urls": [magnet_for(h, names.get(h, "")) for h in hashes]},
                headers={"Authorization": f"Bearer {self.api_key}"},
            )
        except DebridError as exc:
            logger.warning("EasyDebrid cache check failed: %s", exc)
            return {}
        cached = data.get("cached")
        if not isinstance(cached, list) or len(cached) != len(hashes):
            return {}
        return {h.lower(): bool(v) for h, v in zip(hashes, cached)}


class Offcloud(DebridService):
    info = ServiceInfo(
        key="offcloud",
        name="Offcloud",
        short="OC",
        aliases=("offcloud", "oc"),
        supports_cache_check=True,
        cache_check_note="Offcloud takes a batch of hashes and returns the ones it holds.",
        default_rpm=60, default_concurrency=1, default_spacing_ms=800,
    )

    async def test(self, session: aiohttp.ClientSession) -> dict:
        data = await self._request(
            session, "GET", "https://offcloud.com/api/account/stats",
            params={"key": self.api_key},
        )
        return {
            "ok": True,
            "account": data.get("email") or "Offcloud account",
            "premium": True,
            "expires": data.get("expirationDate"),
        }

    async def check_cached(
        self, session: aiohttp.ClientSession, hashes: list[str],
        names: Optional[dict[str, str]] = None,
    ) -> dict[str, bool]:
        if not hashes:
            return {}
        try:
            data = await self._request(
                session, "POST", "https://offcloud.com/api/cache",
                params={"key": self.api_key}, json={"hashes": hashes},
            )
        except DebridError as exc:
            logger.warning("Offcloud cache check failed: %s", exc)
            return {}
        found = {str(h).lower() for h in (data.get("cachedItems") or [])}
        if not found and "cachedItems" not in data:
            return {}
        return {h.lower(): h.lower() in found for h in hashes}


class PutIo(DebridService):
    info = ServiceInfo(
        key="putio",
        name="put.io",
        short="PI",
        aliases=("putio", "put.io", "put-io", "pi"),
        supports_cache_check=False,
        cache_check_note="put.io is personal cloud storage rather than a shared cache, so there is nothing to look a hash up in.",
        default_rpm=60, default_concurrency=1, default_spacing_ms=800,
    )

    async def test(self, session: aiohttp.ClientSession) -> dict:
        data = await self._request(
            session, "GET", "https://api.put.io/v2/account/info",
            headers={"Authorization": f"Bearer {self.api_key}"},
        )
        info = data.get("info") or {}
        return {"ok": True, "account": info.get("username", "put.io account"), "premium": True}


class Seedr(DebridService):
    info = ServiceInfo(
        key="seedr",
        name="Seedr",
        short="SE",
        aliases=("seedr", "se"),
        supports_cache_check=False,
        cache_check_note="Seedr downloads to your own space rather than serving from a shared cache, so there is no cache to check.",
        default_rpm=60, default_concurrency=1, default_spacing_ms=800,
    )

    async def test(self, session: aiohttp.ClientSession) -> dict:
        data = await self._request(
            session, "GET", "https://www.seedr.cc/api/folder",
            headers={"Authorization": f"Bearer {self.api_key}"},
        )
        return {"ok": True, "account": data.get("name") or "Seedr account", "premium": True}


class PikPak(DebridService):
    info = ServiceInfo(
        key="pikpak",
        name="PikPak",
        short="PP",
        aliases=("pikpak", "pp"),
        supports_cache_check=False,
        cache_check_note="PikPak has no public cache lookup, so these results use the cache flag AIOStreams reports.",
        default_rpm=60, default_concurrency=1, default_spacing_ms=800,
    )

    async def test(self, session: aiohttp.ClientSession) -> dict:
        # PikPak authenticates per session rather than with a standalone
        # key, so there is nothing to verify without a full login flow.
        # Accepting the value lets AIOStreams' own results be labelled
        # correctly without pretending a check happened.
        if not self.api_key:
            raise DebridError("Enter your PikPak token")
        return {"ok": True, "account": "PikPak token stored", "premium": True,
                "note": "Stored for labelling; PikPak has no key-verification endpoint."}
