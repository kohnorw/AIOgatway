"""
gateway/debrid/base.py
~~~~~~~~~~~~~~~~~~~~~~
The shape every debrid service implements.

A service does two things for AIOGateway:

  test()          — confirm the API key works, and report the account.
  check_cached()  — given info hashes, say which are cached right now.

Cache state is the whole point. AIOStreams marks each result `cached`,
but that flag is only as good as whatever addon produced it, and for
several providers it is routinely stale or simply absent. Asking the
provider directly is the difference between picking a stream that starts
instantly and picking one that hangs on a download nobody is waiting for.

Three-state verdicts, never two:

  True   — the provider confirmed it is cached.
  False  — the provider confirmed it is not.
  absent — no verdict (no endpoint, key missing, request failed).

An absent verdict falls back to whatever AIOStreams said. That fallback
is what makes this safe to enable everywhere: a provider with no cache
endpoint, or a transient API failure, degrades to exactly the behaviour
of not having configured the service at all. It never empties the
candidate list.
"""
from __future__ import annotations

import logging
import urllib.parse
from dataclasses import dataclass
from typing import Optional

import aiohttp

from .ratelimit import gate, limiter

logger = logging.getLogger("aiogateway.debrid")

TIMEOUT = aiohttp.ClientTimeout(total=20)


@dataclass
class ServiceInfo:
    key: str            # internal id, used in config keys
    name: str           # display name
    short: str          # two-letter badge, matching AIOStreams' own
    # AIOStreams reports a `service` string per result; these are the
    # values that mean this provider, lowercased.
    aliases: tuple[str, ...] = ()
    # Whether this provider exposes any way to ask about cache state.
    # False here is not a gap in this code — it means the provider has no
    # such endpoint, and results fall back to the AIOStreams flag.
    supports_cache_check: bool = True
    cache_check_note: str = ""
    # Conservative starting limits. Published ceilings are higher for
    # most of these, but AIOGateway is never the only client on an
    # account, so the defaults leave headroom for the user's Stremio,
    # their addons, and anything else sharing the key.
    default_rpm: int = 60
    default_concurrency: int = 1
    default_spacing_ms: int = 500


class DebridService:
    info: ServiceInfo

    def __init__(self, api_key: str) -> None:
        self.api_key = api_key

    # ── to implement ────────────────────────────────────────────────
    async def test(self, session: aiohttp.ClientSession) -> dict:
        """Return {"ok": True, "account": "..."} or raise DebridError."""
        raise NotImplementedError

    async def check_cached(
        self, session: aiohttp.ClientSession, hashes: list[str],
        names: Optional[dict[str, str]] = None,
    ) -> dict[str, bool]:
        """Map hash -> cached. Omit any hash with no verdict."""
        return {}

    # ── shared helpers ──────────────────────────────────────────────
    async def _request(
        self, session: aiohttp.ClientSession, method: str, url: str, **kw
    ) -> dict:
        """Every outbound call goes through the service's rate gate, and
        a 429 pauses the whole service rather than just failing this one
        request — retrying into a rate limit is what turns a brief limit
        into a sustained one."""
        async with gate(self.info.key):
            async with session.request(method, url, timeout=TIMEOUT, **kw) as resp:
                if resp.status == 429:
                    retry_after = None
                    try:
                        retry_after = float(resp.headers.get("Retry-After", ""))
                    except ValueError:
                        pass
                    limiter(self.info.key).note_429(retry_after)
                    raise DebridError(f"{self.info.name} rate limited this request")
                if resp.status in (401, 403):
                    raise DebridError(f"{self.info.name} rejected the API key")
                if resp.status >= 400:
                    raise DebridError(f"{self.info.name} returned HTTP {resp.status}")
                return await resp.json(content_type=None)


class DebridError(Exception):
    pass


def magnet_for(hash_: str, name: str = "") -> str:
    h = (hash_ or "").strip().lower()
    if not name:
        return f"magnet:?xt=urn:btih:{h}"
    return f"magnet:?xt=urn:btih:{h}&dn={urllib.parse.quote(name)}"
