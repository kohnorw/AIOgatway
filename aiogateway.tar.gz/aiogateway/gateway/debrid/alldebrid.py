"""
gateway/debrid/alldebrid.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~
AllDebrid, including the background cleanup the runbook asks for.

Why AllDebrid is the awkward one
--------------------------------
AllDebrid deprecated real-time instant-availability lookups, so the
`cached` flag addons report for it is frequently stale or invented. The
only thing that reflects AllDebrid's actual cache state today is the
upload response itself: post the magnet, read `ready` off the reply.

That is accurate, and it also leaves a magnet sitting in the user's
account. So every probe is followed by a delete. The delete runs as a
detached background task — the `ready` verdict is already known by then,
and making a playback decision wait on bookkeeping would add a round trip
per probe to the moment someone pressed play.

The one hazard, and the reason cleanup is configurable rather than
unconditional: if a magnet is *already* in the account, AllDebrid's
upload returns the existing entry's id. Deleting that id removes the
user's own item, not a probe. AIOGateway has no list of what the user
added by hand, so it cannot tell the two apart. Anyone who also keeps
torrents in the same AllDebrid account by hand should turn cleanup off
and accept the probe magnets instead.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Optional

import aiohttp

from .base import DebridError, DebridService, ServiceInfo, magnet_for

logger = logging.getLogger("aiogateway.debrid.alldebrid")

BASE = "https://api.alldebrid.com/v4"
AGENT = "aiogateway"

# Probe deletes that are still pending. Tracked so shutdown can wait for
# them briefly instead of orphaning magnets in the user's account.
_pending_cleanup: set[asyncio.Task] = set()


class AllDebrid(DebridService):
    info = ServiceInfo(
        key="alldebrid",
        name="AllDebrid",
        short="AD",
        aliases=("alldebrid", "ad", "all-debrid"),
        supports_cache_check=True,
        cache_check_note=(
            "AllDebrid retired instant-availability lookups, so addon cache "
            "labels for it are often wrong. AIOGateway uploads the magnet, "
            "reads its real state, then deletes the probe."
        ),
        default_rpm=180,
        default_concurrency=2,
        default_spacing_ms=250,
    )

    async def test(self, session: aiohttp.ClientSession) -> dict:
        data = await self._request(
            session, "GET", f"{BASE}/user",
            params={"agent": AGENT}, headers=self._headers(),
        )
        if data.get("status") != "success":
            raise DebridError(self._error(data))
        user = (data.get("data") or {}).get("user") or {}
        return {
            "ok": True,
            "account": user.get("username", "AllDebrid account"),
            "premium": bool(user.get("isPremium")),
            "expires": user.get("premiumUntil"),
        }

    async def check_cached(
        self, session: aiohttp.ClientSession, hashes: list[str],
        names: Optional[dict[str, str]] = None,
    ) -> dict[str, bool]:
        if not hashes:
            return {}
        names = names or {}
        from .. import settings

        chunk_size = max(1, int(settings.get("alldebrid_probe_chunk", 10)))
        verdicts: dict[str, bool] = {}
        probe_ids: list = []

        for start in range(0, len(hashes), chunk_size):
            chunk = hashes[start:start + chunk_size]
            magnets = [magnet_for(h, names.get(h, "")) for h in chunk]
            payload = [("agent", AGENT)] + [("magnets[]", m) for m in magnets]
            try:
                data = await self._request(
                    session, "POST", f"{BASE}/magnet/upload",
                    data=payload, headers=self._headers(),
                )
            except DebridError as exc:
                logger.warning("AllDebrid cache probe failed: %s", exc)
                break

            if data.get("status") != "success":
                logger.warning("AllDebrid cache probe: %s", self._error(data))
                break

            entries = (data.get("data") or {}).get("magnets") or []
            for entry in entries:
                h = (entry.get("hash") or "").lower()
                if not h:
                    continue
                # `error` on an individual magnet means AllDebrid could
                # not evaluate it. That is not the same as "not cached",
                # so it gets no verdict and falls back to the addon flag.
                if entry.get("error"):
                    continue
                verdicts[h] = bool(entry.get("ready"))
                if entry.get("id") is not None:
                    probe_ids.append(entry["id"])

            if settings.get("alldebrid_stop_on_hit", True) and any(verdicts.values()):
                break

        if probe_ids and settings.get("alldebrid_delete_probes", True):
            _schedule_cleanup(self.api_key, probe_ids)

        return verdicts

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self.api_key}"}

    @staticmethod
    def _error(data: dict) -> str:
        err = data.get("error") or {}
        return err.get("message") or err.get("code") or "unknown AllDebrid error"


async def _delete_probes(api_key: str, ids: list) -> None:
    headers = {"Authorization": f"Bearer {api_key}"}
    removed = 0
    try:
        async with aiohttp.ClientSession() as session:
            svc = AllDebrid(api_key)
            for mid in ids:
                try:
                    await svc._request(
                        session, "GET", f"{BASE}/magnet/delete",
                        params={"agent": AGENT, "id": str(mid)}, headers=headers,
                    )
                    removed += 1
                except DebridError as exc:
                    logger.debug("AllDebrid probe %s not deleted: %s", mid, exc)
    except asyncio.CancelledError:
        logger.warning(
            "AllDebrid cleanup cancelled — %d probe magnet(s) left in the account",
            len(ids) - removed,
        )
        raise
    except Exception as exc:
        logger.warning("AllDebrid cleanup failed: %s", exc)
    else:
        if removed:
            logger.debug("AllDebrid cleanup removed %d probe magnet(s)", removed)


def _schedule_cleanup(api_key: str, ids: list) -> None:
    try:
        task = asyncio.create_task(_delete_probes(api_key, ids))
    except RuntimeError:
        logger.warning("No running loop — %d AllDebrid probe(s) left in place", len(ids))
        return
    _pending_cleanup.add(task)
    task.add_done_callback(_pending_cleanup.discard)


async def shutdown(timeout: float = 10.0) -> None:
    """Give outstanding probe deletes a short grace period on the way
    down. Leftover probe magnets are untidy, not dangerous, so this is
    capped rather than allowed to hold up shutdown indefinitely."""
    if not _pending_cleanup:
        return
    pending = list(_pending_cleanup)
    logger.info("Waiting up to %.0fs for %d AllDebrid cleanup task(s)", timeout, len(pending))
    done, still_pending = await asyncio.wait(pending, timeout=timeout)
    for task in still_pending:
        task.cancel()
