"""
gateway/debrid/ratelimit.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~
One rate limiter per debrid service, shared by every caller in the
process.

Three separate limits, because debrid providers enforce three separate
things and any one of them alone is easy to slip past:

  concurrency  — how many requests may be in flight at once
  spacing      — the minimum gap between two request *starts*
  rpm          — a sliding-window cap on requests per minute

Concurrency alone doesn't bound rate (one slot, answered in 20ms, is 50
requests a second). Spacing alone doesn't bound a burst that arrives
after a quiet period. The per-minute window alone permits that whole
minute's budget to be spent in the first second, which is exactly the
shape that trips a provider's short-window burst detection. Enforcing all
three is what keeps sustained traffic under the published ceiling without
ever spiking through it.

Limits are read live from config on each acquire, so retuning them in the
Streams tab takes effect on the next request rather than at the next
container restart.
"""
from __future__ import annotations

import asyncio
import logging
import time
from collections import deque

logger = logging.getLogger("aiogateway.debrid.ratelimit")

_limiters: dict[str, "RateLimiter"] = {}


class RateLimiter:
    def __init__(self, service_key: str) -> None:
        self.service_key = service_key
        self._lock = asyncio.Lock()
        self._starts: deque[float] = deque()
        self._last_start = 0.0
        self._sem: asyncio.Semaphore | None = None
        self._sem_size = 0
        # Set by note_429(); every acquire waits until this passes.
        self._backoff_until = 0.0

    def _limits(self) -> dict:
        from .. import config
        try:
            return config.debrid_limits(self.service_key)
        except Exception:
            return {"rpm": 60.0, "concurrency": 1, "spacing_ms": 500.0}

    def _semaphore(self, size: int) -> asyncio.Semaphore:
        # Resized when the user changes concurrency in the UI. Requests
        # already holding the old semaphore release against it safely —
        # they kept their own reference through the `async with`.
        if self._sem is None or size != self._sem_size:
            self._sem = asyncio.Semaphore(max(1, size))
            self._sem_size = size
        return self._sem

    def note_429(self, retry_after: float | None = None) -> None:
        """Called when a provider actually says no. Pauses this service
        for the window it asked for (or 30s), which is the only response
        to a 429 that doesn't make the situation worse."""
        wait = retry_after if retry_after and retry_after > 0 else 30.0
        self._backoff_until = max(self._backoff_until, time.monotonic() + wait)
        logger.warning("%s rate limited — pausing %.0fs", self.service_key, wait)

    async def acquire(self) -> asyncio.Semaphore:
        limits = self._limits()
        sem = self._semaphore(int(limits["concurrency"]))
        await sem.acquire()
        try:
            async with self._lock:
                while True:
                    now = time.monotonic()

                    if now < self._backoff_until:
                        await asyncio.sleep(self._backoff_until - now)
                        continue

                    # Sliding one-minute window.
                    cutoff = now - 60.0
                    while self._starts and self._starts[0] < cutoff:
                        self._starts.popleft()
                    rpm = max(1.0, float(limits["rpm"]))
                    if len(self._starts) >= rpm:
                        await asyncio.sleep(max(0.05, self._starts[0] + 60.0 - now))
                        continue

                    # Minimum spacing between starts.
                    gap = max(0.0, float(limits["spacing_ms"])) / 1000.0
                    wait = gap - (now - self._last_start)
                    if wait > 0:
                        await asyncio.sleep(wait)
                        continue

                    self._last_start = now
                    self._starts.append(now)
                    return sem
        except BaseException:
            sem.release()
            raise

    def release(self, sem: asyncio.Semaphore) -> None:
        sem.release()


class _Guard:
    def __init__(self, limiter: RateLimiter) -> None:
        self._limiter = limiter
        self._sem: asyncio.Semaphore | None = None

    async def __aenter__(self) -> RateLimiter:
        self._sem = await self._limiter.acquire()
        return self._limiter

    async def __aexit__(self, *exc) -> bool:
        if self._sem is not None:
            self._limiter.release(self._sem)
        return False


def gate(service_key: str) -> _Guard:
    """`async with gate("alldebrid"): ...` around every outbound call."""
    if service_key not in _limiters:
        _limiters[service_key] = RateLimiter(service_key)
    return _Guard(_limiters[service_key])


def limiter(service_key: str) -> RateLimiter:
    if service_key not in _limiters:
        _limiters[service_key] = RateLimiter(service_key)
    return _limiters[service_key]
