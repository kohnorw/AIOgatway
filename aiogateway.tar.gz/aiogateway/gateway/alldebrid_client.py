"""
gateway/alldebrid_client.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~
AllDebrid as a second stream source, alongside TorBox.

Search is unchanged — AIOStreams (or TorBox's search API) still finds the
releases. What this module adds is the other half: turning a result that
AllDebrid has cached into a bound, playable file, and turning that binding
back into a CDN URL on demand.

Refs
----
Bound entries store a stable ref, never a CDN URL (those expire):

    alldebrid://<infohash>/<file index>/<url-quoted filename>

Same shape as the TorBox ref, different scheme, so the FUSE layer, the
proxy and the repair loop treat both identically — torbox_client dispatches
on the scheme. Candidates that aren't bound yet use the query form
``alldebrid://<infohash>?s=1&e=2``.

Cached only
-----------
Nothing here ever leaves AllDebrid downloading a torrent for us. A magnet is
uploaded only to ask "do you already have this?"; if the answer isn't an
immediate Ready, it's deleted again and remembered as uncached for
``alldebrid_uncached_negative_hours``. Combined with the search-side filter
in torbox_client (AllDebrid results are dropped entirely unless AllDebrid is
enabled, and only cached ones are kept when it is), the library only ever
shows AllDebrid links that are genuinely cached.
"""
from __future__ import annotations

import json
import logging
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Optional
from urllib.parse import quote

from . import alldebrid_api as ad
from . import torbox_guard as guard

log = logging.getLogger("aiogateway.alldebrid")

REF_SCHEME = "alldebrid://"


class NotCachedOnAllDebrid(Exception):
    """AllDebrid doesn't already have this torrent — we won't wait for it."""


def _setting(key, default):
    return guard._setting(key, default)


def enabled() -> bool:
    return ad.enabled()


# ─────────────────────────────────────────────────────────────────────────────
# Refs
# ─────────────────────────────────────────────────────────────────────────────

def is_ref(url: Optional[str]) -> bool:
    return bool(url) and url.startswith(REF_SCHEME)


def make_ref(h: str, file_id: int, name: str) -> str:
    return f"{REF_SCHEME}{h.lower()}/{int(file_id)}/{quote(name or '', safe='')}"


def make_query_ref(h: str, season: Optional[int], episode: Optional[int], name: str = "") -> str:
    q = []
    if season is not None:
        q.append(f"s={season}")
    if episode is not None:
        q.append(f"e={episode}")
    if name:
        q.append(f"name={quote(name, safe='')}")
    return f"{REF_SCHEME}{h.lower()}" + (("?" + "&".join(q)) if q else "")


def _link_key(h: str, name: str, file_id) -> str:
    base = name.rsplit("/", 1)[-1] if name else f"id{file_id}"
    return f"{h.lower()}:{base}"


# ─────────────────────────────────────────────────────────────────────────────
# Store (its own SQLite file — the TorBox mirror must not sweep these rows)
# ─────────────────────────────────────────────────────────────────────────────

_SCHEMA = """
CREATE TABLE IF NOT EXISTS magnets (
    hash TEXT PRIMARY KEY, magnet_id INTEGER NOT NULL, name TEXT,
    files TEXT NOT NULL, synced_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS links (
    key TEXT PRIMARY KEY, url TEXT NOT NULL, expires_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS negative (
    key TEXT PRIMARY KEY, error TEXT, until REAL NOT NULL
);
"""


class _Store:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self._path = str(path)
        self._local = threading.local()
        with self._conn() as c:
            c.executescript(_SCHEMA)

    @contextmanager
    def _conn(self):
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self._path, timeout=10, isolation_level=None,
                                   check_same_thread=False)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA busy_timeout=5000")
            self._local.conn = conn
        yield conn

    def get_magnet(self, h: str) -> Optional[dict]:
        with self._conn() as c:
            row = c.execute("SELECT magnet_id, name, files, synced_at FROM magnets WHERE hash=?",
                            (h.lower(),)).fetchone()
        if not row:
            return None
        return {"hash": h.lower(), "magnet_id": row[0], "name": row[1],
                "files": json.loads(row[2]), "synced_at": row[3]}

    def put_magnet(self, h: str, magnet_id: int, name: str, files: list[dict]):
        with self._conn() as c:
            c.execute("INSERT OR REPLACE INTO magnets VALUES (?,?,?,?,?)",
                      (h.lower(), int(magnet_id), name, json.dumps(files), time.time()))

    def drop_magnet(self, h: str):
        with self._conn() as c:
            c.execute("DELETE FROM magnets WHERE hash=?", (h.lower(),))

    def magnet_count(self) -> int:
        with self._conn() as c:
            return c.execute("SELECT COUNT(*) FROM magnets").fetchone()[0]

    def all_hashes(self) -> set:
        with self._conn() as c:
            return {r[0] for r in c.execute("SELECT hash FROM magnets").fetchall()}

    def get_link(self, key: str) -> Optional[str]:
        with self._conn() as c:
            row = c.execute("SELECT url, expires_at FROM links WHERE key=?", (key,)).fetchone()
        return row[0] if row and row[1] > time.time() else None

    def put_link(self, key: str, url: str, ttl_seconds: float):
        with self._conn() as c:
            c.execute("INSERT OR REPLACE INTO links VALUES (?,?,?)",
                      (key, url, time.time() + ttl_seconds))

    def drop_link(self, key: str):
        with self._conn() as c:
            c.execute("DELETE FROM links WHERE key=?", (key,))

    def get_negative(self, key: str) -> Optional[str]:
        with self._conn() as c:
            row = c.execute("SELECT error, until FROM negative WHERE key=?", (key,)).fetchone()
        return (row[0] or "recently failed") if row and row[1] > time.time() else None

    def put_negative(self, key: str, error: str, ttl_seconds: float):
        with self._conn() as c:
            c.execute("INSERT OR REPLACE INTO negative VALUES (?,?,?)",
                      (key, error[:300], time.time() + ttl_seconds))

    def sweep(self) -> int:
        now = time.time()
        with self._conn() as c:
            n = c.execute("DELETE FROM links WHERE expires_at < ?", (now,)).rowcount or 0
            n += c.execute("DELETE FROM negative WHERE until < ?", (now,)).rowcount or 0
        return n

    def reset(self):
        with self._conn() as c:
            c.execute("DELETE FROM magnets")
            c.execute("DELETE FROM links")
            c.execute("DELETE FROM negative")

    def counts(self) -> dict:
        with self._conn() as c:
            return {
                "alldebrid_magnets": c.execute("SELECT COUNT(*) FROM magnets").fetchone()[0],
                "alldebrid_links": c.execute("SELECT COUNT(*) FROM links").fetchone()[0],
            }


_store: Optional[_Store] = None
_store_lock = threading.Lock()


def store() -> _Store:
    global _store
    with _store_lock:
        if _store is None:
            _store = _Store(guard.data_dir() / "alldebrid.db")
        return _store


def in_account(h: Optional[str]) -> bool:
    try:
        return bool(h) and store().get_magnet(h) is not None
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────────────────────
# Materialize: hash → (magnet_id, files), cached torrents only
# ─────────────────────────────────────────────────────────────────────────────

def ensure_in_account(h: str, priority: int = guard.LOW) -> dict:
    """The local record for a hash, uploading the magnet only if we don't
    already have it. Raises NotCachedOnAllDebrid when AllDebrid doesn't
    already hold the torrent — it is never left downloading one for us."""
    st = store()
    rec = st.get_magnet(h)
    if rec and rec["files"]:
        guard.stats.inc("alldebrid_lookup_cache_hits")
        return rec

    neg = st.get_negative(f"add:{h}")
    if neg:
        guard.stats.inc("negative_cache_hits")
        raise NotCachedOnAllDebrid(f"not cached on AllDebrid: {neg}")

    def _add():
        again = st.get_magnet(h)
        if again and again["files"]:
            return again

        magnet_id = ad.upload_magnet(h, priority=priority)
        if not magnet_id:
            raise NotCachedOnAllDebrid("AllDebrid returned no magnet id")

        # Cached means Ready essentially straight away. Give it two short
        # looks (AllDebrid can take a beat to report on a fresh upload) and
        # no more — anything slower is a real download, not a cache hit.
        status = ad.magnet_status(magnet_id, priority=priority)
        code = int(status.get("statusCode", -1) or -1)
        grace = float(_setting("alldebrid_ready_grace_seconds", 2))
        if code != ad.ST_READY and grace > 0:
            time.sleep(grace)
            status = ad.magnet_status(magnet_id, priority=priority)
            code = int(status.get("statusCode", -1) or -1)

        if code != ad.ST_READY:
            ad.delete_magnet(magnet_id, priority=priority)
            st.put_negative(f"add:{h}", f"status {status.get('status') or code}",
                            float(_setting("alldebrid_uncached_negative_hours", 6)) * 3600)
            raise NotCachedOnAllDebrid(
                f"AllDebrid doesn't have {h[:10]}… cached (status: {status.get('status') or code})")

        files = ad.magnet_files(magnet_id, priority=priority)
        if not files:
            ad.delete_magnet(magnet_id, priority=priority)
            st.put_negative(f"add:{h}", "ready but no files",
                            float(_setting("alldebrid_uncached_negative_hours", 6)) * 3600)
            raise NotCachedOnAllDebrid("AllDebrid reported ready but returned no files")

        st.put_magnet(h, magnet_id, status.get("filename") or "", files)
        guard.stats.inc("alldebrid_magnets_added")
        return st.get_magnet(h)

    return guard.singleflight.do(f"ad:add:{h}", _add)


# ─────────────────────────────────────────────────────────────────────────────
# CDN URLs for refs (sync — used by FUSE threads and via to_thread)
# ─────────────────────────────────────────────────────────────────────────────

def _parse(ref: str) -> dict:
    from .torbox_client import parse_ref
    return parse_ref(ref)


def _pick(rec: dict, info: dict) -> dict:
    from .torbox_client import choose_file
    return choose_file(rec["files"], info["season"], info["episode"], info["name"], info["file_id"])


def cdn_url_for_ref(ref: str, priority: int = guard.HIGH, force_refresh: bool = False) -> str:
    info = _parse(ref)
    h = info["hash"]
    st = store()

    rec = ensure_in_account(h, priority)
    f = _pick(rec, info)
    key = _link_key(h, f["name"], f["id"])

    if force_refresh:
        st.drop_link(key)
    else:
        cached = st.get_link(key)
        if cached:
            guard.stats.inc("cdn_url_cache_hits")
            return cached

    neg = st.get_negative(f"link:{key}")
    if neg and not force_refresh:
        guard.stats.inc("negative_cache_hits")
        raise ad.AllDebridError(f"recent link failure: {neg}", status=503)
    if guard.breaker.is_open(h):
        raise ad.AllDebridError("torrent quarantined by circuit breaker", status=503)

    def _fetch():
        again = st.get_link(key)
        if again and not force_refresh:
            return again
        try:
            url = ad.unlock(f["link"], priority=priority)
        except ad.AllDebridError as exc:
            if not exc.retryable:
                # Usually: AllDebrid dropped the magnet, so the stored file
                # links are stale. Forget it and re-add once.
                log.info("unlock failed for %s… (%s) — re-adding magnet", h[:10], exc)
                st.drop_magnet(h)
                fresh = ensure_in_account(h, priority)
                ff = _pick(fresh, dict(info, file_id=None))
                try:
                    url = ad.unlock(ff["link"], priority=priority)
                except ad.AllDebridError as exc2:
                    guard.breaker.failure(h, str(exc2))
                    st.put_negative(f"link:{key}", str(exc2),
                                    float(_setting("alldebrid_negative_cache_seconds", 30)))
                    raise
            else:
                guard.breaker.failure(h, str(exc))
                st.put_negative(f"link:{key}", str(exc),
                                float(_setting("alldebrid_negative_cache_seconds", 30)))
                raise
        guard.breaker.success(h)
        st.put_link(key, url, float(_setting("alldebrid_link_ttl_minutes", 60)) * 60)
        return url

    return guard.singleflight.do(f"ad:link:{key}", _fetch)


def invalidate_ref(ref: str):
    """Forget the cached CDN URL for a ref (e.g. the CDN answered 403/404)."""
    try:
        info = _parse(ref)
        rec = store().get_magnet(info["hash"])
        if not rec:
            return
        f = _pick(rec, info)
        store().drop_link(_link_key(info["hash"], f["name"], f["id"]))
        guard.stats.inc("cdn_url_repairs")
    except Exception:
        pass


def ref_size(ref: str) -> Optional[int]:
    try:
        info = _parse(ref)
        rec = store().get_magnet(info["hash"])
        if not rec:
            return None
        return _pick(rec, info).get("size")
    except Exception:
        return None


def verify_ref_sync(ref: str) -> bool:
    """Fresh link + CDN probe for an existing bound ref."""
    from .torbox_client import _probe_cdn
    try:
        url = cdn_url_for_ref(ref, guard.LOW, force_refresh=True)
        return _probe_cdn(url, ref_size(ref))
    except Exception as exc:
        log.info("Existing AllDebrid ref %s… no longer works: %s", ref[12:28], exc)
        return False


# ─────────────────────────────────────────────────────────────────────────────
# Binding
# ─────────────────────────────────────────────────────────────────────────────

def bind_sync(h: str, season, episode, cand, verify: bool, priority: int):
    """Bind one candidate hash to a real file inside a cached AllDebrid
    magnet. Mirrors TorBoxClient._bind_sync so bind_for_quality can treat
    both providers the same way."""
    from .models import AIOStream
    from .torbox_client import _probe_cdn, choose_file, parse_release

    rec = ensure_in_account(h, priority)
    f = choose_file(rec["files"], season, episode)
    ref = make_ref(h, f["id"], f["name"])
    if verify:
        url = cdn_url_for_ref(ref, priority)
        if not _probe_cdn(url, f.get("size")):
            invalidate_ref(ref)
            guard.breaker.failure(h, "CDN probe failed")
            return None
    pf, _ = parse_release(f["name"])
    if not pf.resolution and getattr(cand, "parsed_file", None):
        pf.resolution = cand.parsed_file.resolution
    out = AIOStream(url=ref, filename=f["name"].rsplit("/", 1)[-1], size=f.get("size"),
                    service="alldebrid", cached=True, parsed_file=pf, addon="alldebrid")
    out._hash = h
    return out


def materialize_ref_sync(ref: str):
    """Query-form ref → full ref with a real size (manual stream selection)."""
    from .models import AIOStream
    from .torbox_client import choose_file, parse_release
    info = _parse(ref)
    rec = ensure_in_account(info["hash"], guard.HIGH)
    f = choose_file(rec["files"], info["season"], info["episode"], "", info["file_id"])
    full = make_ref(info["hash"], f["id"], f["name"])
    cdn_url_for_ref(full, guard.HIGH)
    return AIOStream(url=full, filename=f["name"], size=f.get("size"), service="alldebrid",
                     cached=True, parsed_file=parse_release(f["name"])[0])


# ─────────────────────────────────────────────────────────────────────────────
# Account mirror / diagnostics
# ─────────────────────────────────────────────────────────────────────────────

def sync_magnets_sync() -> int:
    """Mirror the account's magnet list so ranking knows what's already
    there. Only the hash/id/name are taken here; the file list is fetched
    lazily on first bind, one call per torrent we actually use."""
    st = store()
    known = st.all_hashes()
    n = 0
    for m in ad.all_magnets(guard.LOW):
        h = ad.hash_of(m)
        if not h or int(m.get("statusCode", -1) or -1) != ad.ST_READY:
            continue
        n += 1
        if h in known:
            continue
        st.put_magnet(h, int(m.get("id") or 0), m.get("filename") or "", [])
    guard.stats.inc("alldebrid_syncs")
    return n


def connection_test(key: Optional[str] = None) -> dict:
    from gateway import settings as _settings
    result = {"ok": False, "error": None, "diagnosis": None,
              "key_set": bool(key or ad.api_key()),
              "enabled": bool(_settings.get("alldebrid_enabled", False))}
    if not (key or ad.api_key()):
        result.update(error="No AllDebrid API key set", diagnosis="no_key")
        return result
    try:
        me = ad.user_me(guard.HIGH, key=key)
    except ad.AllDebridError as exc:
        result.update(error=str(exc),
                      diagnosis="bad_auth" if exc.code.startswith("AUTH_") else "unreachable")
        return result
    result["username"] = me.get("username")
    result["email"] = me.get("email")
    result["premium"] = bool(me.get("isPremium"))
    result["expires_at"] = me.get("premiumUntil")
    if not result["premium"]:
        result.update(ok=False, diagnosis="not_premium",
                      error="This AllDebrid account isn't premium — cached links can't be unlocked")
        return result
    result.update(ok=True, diagnosis="ok")
    return result


def stats() -> dict:
    out = {"enabled": enabled(), "key_set": bool(ad.api_key())}
    try:
        out.update(store().counts())
    except Exception:
        pass
    return out
