"""
gateway/arr.py
~~~~~~~~~~~~~~
Reads an existing Radarr or Sonarr library and brings it across.

Strictly read-only. Nothing is ever written back to Radarr or Sonarr, and
no files are copied — a migration only takes the list of titles.

For each title it searches AIOStreams and, if anything playable comes
back, creates the file with its stream link already attached. The search
had to happen either way to know the title is available, and it returns
the link along with the answer — so keeping it makes every migrated file
immediately real rather than something that goes looking for a stream
the first time somebody presses play.
"""
from __future__ import annotations

import asyncio
import logging
import time
import uuid
from typing import Optional

import aiohttp

from . import aiostreams, config
from .service import MediaService

logger = logging.getLogger("aiogateway.arr")

TIMEOUT = aiohttp.ClientTimeout(total=30)


class ArrError(RuntimeError):
    pass


def _headers(api_key: str) -> dict:
    return {"X-Api-Key": api_key, "Accept": "application/json"}


def _poster(images: list) -> str:
    for image in images or []:
        if image.get("coverType") == "poster" and image.get("remoteUrl"):
            # remoteUrl points at a public CDN. The plain `url` is a path
            # on the Radarr/Sonarr host, which the browser can't reach.
            return image["remoteUrl"]
    return ""


async def test(service: str, url: str, api_key: str) -> dict:
    if service not in ("radarr", "sonarr"):
        raise ArrError("Choose Radarr or Sonarr")
    if not url or not api_key:
        raise ArrError("Enter the URL and API key")

    endpoint = f"{url.rstrip('/')}/api/v3/system/status"
    try:
        async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
            async with session.get(endpoint, headers=_headers(api_key)) as resp:
                if resp.status == 401:
                    raise ArrError("Rejected — check the API key")
                if resp.status >= 400:
                    raise ArrError(f"{service.title()} returned HTTP {resp.status}")
                data = await resp.json(content_type=None)
    except aiohttp.ClientConnectorError as exc:
        raise ArrError(f"Could not reach {url} — {exc}") from exc
    except asyncio.TimeoutError as exc:
        raise ArrError(f"{service.title()} did not answer in time") from exc

    return {
        "ok": True,
        "name": data.get("instanceName") or service.title(),
        "version": data.get("version", ""),
    }


async def library(service: str) -> list[dict]:
    """Everything the configured instance tracks."""
    url = config.secret(f"{service}_url").rstrip("/")
    api_key = config.secret(f"{service}_api_key")
    if not url or not api_key:
        raise ArrError(f"{service.title()} is not configured")

    path = "movie" if service == "radarr" else "series"
    try:
        async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
            async with session.get(f"{url}/api/v3/{path}",
                                   headers=_headers(api_key)) as resp:
                if resp.status >= 400:
                    raise ArrError(f"{service.title()} returned HTTP {resp.status}")
                rows = await resp.json(content_type=None)
    except aiohttp.ClientConnectorError as exc:
        raise ArrError(f"Could not reach {url} — {exc}") from exc

    out = []
    for row in rows:
        imdb_id = row.get("imdbId")
        # Without an IMDb id there is nothing to search AIOStreams with.
        # Radarr and Sonarr both usually have one; the exceptions tend to
        # be items that never matched a metadata source in the first place.
        if not imdb_id:
            continue
        item = {
            "imdb_id": imdb_id,
            "title": row.get("title", ""),
            "year": row.get("year"),
            "poster": _poster(row.get("images")),
        }
        if service == "sonarr":
            seasons = []
            for season in row.get("seasons") or []:
                number = season.get("seasonNumber")
                if not number:
                    continue   # season 0 is specials
                stats = season.get("statistics") or {}
                if stats.get("episodeFileCount", 0) > 0:
                    seasons.append(number)
            if not seasons:
                continue   # nothing downloaded, so nothing to bring across
            item["seasons"] = sorted(seasons)
            item["episode_count"] = sum(
                (s.get("statistics") or {}).get("episodeFileCount", 0)
                for s in row.get("seasons") or []
            )
        else:
            item["has_file"] = bool(row.get("hasFile"))
        out.append(item)

    out.sort(key=lambda i: (i["title"] or "").lower())
    return out


class MigrationJob:
    def __init__(self, service: str, items: list[dict]) -> None:
        self.job_id = uuid.uuid4().hex[:12]
        self.service = service
        self.items = items
        self.started_at = time.time()
        self.finished_at: Optional[float] = None
        self.done = 0
        self.created = 0
        self.skipped = 0
        self.current = ""
        self.errors: list[str] = []
        self.cancelled = False

    def to_dict(self) -> dict:
        return {
            "job_id": self.job_id,
            "service": self.service,
            "total": len(self.items),
            "done": self.done,
            "created": self.created,
            "skipped": self.skipped,
            "current": self.current,
            "errors": self.errors[-20:],
            "running": self.finished_at is None and not self.cancelled,
            "cancelled": self.cancelled,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
        }


_jobs: dict[str, MigrationJob] = {}


def job(job_id: str) -> Optional[MigrationJob]:
    return _jobs.get(job_id)


def cancel(job_id: str) -> bool:
    running = _jobs.get(job_id)
    if running is None or running.finished_at is not None:
        return False
    running.cancelled = True
    return True


async def run_migration(service: str, items: list[dict],
                        media: MediaService) -> MigrationJob:
    running = MigrationJob(service, items)
    _jobs[running.job_id] = running
    asyncio.create_task(_execute(running, media))
    return running


async def _execute(running: MigrationJob, media: MediaService) -> None:
    try:
        for item in running.items:
            if running.cancelled:
                break
            running.current = item.get("title") or item.get("imdb_id", "")
            await aiostreams.yield_to_playback()
            try:
                if running.service == "radarr":
                    await media.add_movie(item["imdb_id"], added_by="migrate")
                else:
                    await media.add_series(item["imdb_id"], item.get("seasons"),
                                           added_by="migrate")
                running.created += 1
            except ValueError as exc:
                # Expected: nothing findable for this title right now.
                # Not an error worth stopping a migration over.
                running.skipped += 1
                running.errors.append(f"{running.current}: {exc}")
            except Exception as exc:
                running.skipped += 1
                running.errors.append(f"{running.current}: {exc}")
                logger.warning("Migration item failed (%s): %s", running.current, exc)
            finally:
                running.done += 1
    finally:
        running.current = ""
        running.finished_at = time.time()
        media.library.save()
        logger.info("Migration finished: %d created, %d skipped",
                    running.created, running.skipped)
        _prune_jobs()


def _prune_jobs(keep: int = 10) -> None:
    finished = sorted(
        (j for j in _jobs.values() if j.finished_at),
        key=lambda j: j.finished_at or 0,
    )
    for stale in finished[:-keep]:
        _jobs.pop(stale.job_id, None)
