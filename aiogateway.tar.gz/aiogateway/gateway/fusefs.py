"""
gateway/fusefs.py
~~~~~~~~~~~~~~~~~
The mounted filesystem. Read-only, entirely virtual, backed by the
library registry rather than by anything on disk.

    <mountpoint>/
      Movies/    Title (Year)/Title (Year).mkv
      Movies4K/  Title (Year)/Title (Year).mkv
      Series/    Show (Year)/Season 01/S01E01.mkv
      Series4K/  Show (Year)/Season 01/S01E01.mkv

Reads are served by range-requesting the entry's CDN link, through an
LRU block cache with read-ahead. A file whose link hasn't been fetched
yet serves a valid container header instead, so a player that opens it
gets a well-formed file rather than an error.

Why reading never fetches a link
--------------------------------
It is tempting to resolve on open(), or on the second or third read, and
both were tried. Neither works, because Plex's scanner legitimately opens
a newly added file and reads several chunks of it to fingerprint codecs
and duration — a pattern indistinguishable at this layer from playback
starting. The result was files activating minutes after being added with
nobody watching.

Activation comes from the Plex webhook, which is the only unambiguous
"a person pressed play" signal available. read() will wait for an
activation already in flight; it will never start one.
"""
from __future__ import annotations

import errno
import logging
import os
import stat
import threading
import time
from collections import OrderedDict
from typing import TYPE_CHECKING, Optional

import requests

from . import settings
from .models import Entry

if TYPE_CHECKING:
    from .library import Library

log = logging.getLogger("aiogateway.fuse")

try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except (ImportError, OSError) as _fuse_import_error:
    # ImportError means fusepy isn't installed. OSError is the one that
    # actually bites: fusepy locates libfuse through ctypes at import
    # time and raises EnvironmentError when it can't, so catching only
    # ImportError would take the whole application down at startup
    # rather than leaving it running with an explanation.
    FUSE_AVAILABLE = False
    Operations = object

    class FuseOSError(OSError):
        pass

    log.warning("Filesystem unavailable (%s) — install libfuse and pass "
                "through /dev/fuse", _fuse_import_error)


TOP_DIRS = ("Movies", "Movies4K", "Series", "Series4K")

# Reported size for an entry whose source never declared one. Large
# enough that a player won't truncate a real film, and only ever used
# until the first successful range response corrects it.
FALLBACK_SIZE = 40 * 1024 * 1024 * 1024


def _tuning() -> dict:
    return {
        "block_mb": int(settings.get("fuse_block_mb", 8)),
        "cache_blocks": int(settings.get("fuse_cache_blocks", 64)),
        "prefetch": int(settings.get("fuse_prefetch_ahead", 4)),
        "timeout": int(settings.get("fuse_read_timeout", 15)),
        "inflight": int(settings.get("fuse_max_inflight", 12)),
        "pool": int(settings.get("fuse_pool_maxsize", 20)),
    }


# ── minimal Matroska header ─────────────────────────────────────────────
def _mkv_header() -> bytes:
    """A structurally valid EBML/Matroska head plus an open Segment.

    Generated rather than shipped as a binary blob so there is no asset
    to lose, and so what a player sees before a link is fetched is
    documented in code rather than opaque bytes in the repository.
    """
    ebml = bytes([
        0x1A, 0x45, 0xDF, 0xA3, 0x9F,
        0x42, 0x86, 0x81, 0x01,              # EBMLVersion 1
        0x42, 0xF7, 0x81, 0x01,              # EBMLReadVersion 1
        0x42, 0xF2, 0x81, 0x04,              # EBMLMaxIDLength 4
        0x42, 0xF3, 0x81, 0x08,              # EBMLMaxSizeLength 8
        0x42, 0x82, 0x88,                    # DocType, 8 bytes
    ]) + b"matroska" + bytes([
        0x42, 0x87, 0x81, 0x04,              # DocTypeVersion 4
        0x42, 0x85, 0x81, 0x02,              # DocTypeReadVersion 2
    ])
    segment = bytes([0x18, 0x53, 0x80, 0x67, 0x01, 0xFF, 0xFF, 0xFF,
                     0xFF, 0xFF, 0xFF, 0xFF, 0xFF])   # unknown length
    return ebml + segment


_HEADER = _mkv_header()


# ── block cache ─────────────────────────────────────────────────────────
class _BlockCache:
    def __init__(self, max_blocks: int) -> None:
        self._max = max_blocks
        self._lock = threading.Lock()
        self._store: OrderedDict = OrderedDict()

    def resize(self, max_blocks: int) -> None:
        with self._lock:
            self._max = max(1, max_blocks)
            while len(self._store) > self._max:
                self._store.popitem(last=False)

    def get(self, key) -> Optional[bytes]:
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        return None

    def put(self, key, data: bytes) -> None:
        with self._lock:
            self._store[key] = data
            self._store.move_to_end(key)
            while len(self._store) > self._max:
                self._store.popitem(last=False)

    def invalidate_url(self, url: str) -> None:
        with self._lock:
            for key in [k for k in self._store if k[0] == url]:
                del self._store[key]


_cache = _BlockCache(64)

# One pooled session for all CDN reads. A fresh request per block opens a
# new TCP+TLS connection each time and, under seek and prefetch load,
# exhausts the process file-descriptor limit within minutes.
#
# pool_maxsize alone does not cap anything: urllib3's default is to stop
# reusing pooled connections once full and quietly open unpooled ones
# instead. pool_block=True is what actually enforces the ceiling.
_session = requests.Session()
_session.mount("https://", requests.adapters.HTTPAdapter(
    pool_connections=10, pool_maxsize=20, max_retries=0, pool_block=True))
_session.mount("http://", requests.adapters.HTTPAdapter(
    pool_connections=10, pool_maxsize=20, max_retries=0, pool_block=True))

_inflight = threading.Semaphore(12)
_prefetching: set = set()
_prefetch_lock = threading.Lock()

# Speculative prefetch stops entirely for a cooldown when file
# descriptors run out. Reads continue, because playback needs them; the
# prefetches are what turn one connection error into a cascade.
_prefetch_paused_until = 0.0
_pause_lock = threading.Lock()


def _pause_prefetch(seconds: float) -> None:
    global _prefetch_paused_until
    with _pause_lock:
        _prefetch_paused_until = max(_prefetch_paused_until, time.time() + seconds)


def _prefetch_paused() -> bool:
    with _pause_lock:
        return time.time() < _prefetch_paused_until


# ── activation handshake ────────────────────────────────────────────────
# A read that lands while the webhook is still fetching a link waits on
# this rather than serving header bytes into the start of a film.
_activation_events: dict[str, threading.Event] = {}
_activation_lock = threading.Lock()


def activation_event(entry_id: str) -> threading.Event:
    with _activation_lock:
        event = _activation_events.get(entry_id)
        if event is None:
            event = threading.Event()
            _activation_events[entry_id] = event
        return event


def begin_activation(entry_id: str) -> None:
    activation_event(entry_id).clear()


def finish_activation(entry_id: str) -> None:
    activation_event(entry_id).set()


class AIOGatewayFS(Operations):
    def __init__(self, library: "Library") -> None:
        self._library = library
        self._mtime = time.time()
        self._index_lock = threading.Lock()
        self._revision = -1
        self._files: dict[str, Entry] = {}
        self._dirs: dict[str, set] = {}

    # ── index ───────────────────────────────────────────────────────
    def _ensure_index(self) -> None:
        """Rebuild the path index only when the library actually changed.

        readdir() is called once per directory and getattr() once per
        entry in it, so scanning the whole library on every call made a
        listing cost O(entries x items) — enough to hang Plex's browser
        on a large library.
        """
        if self._revision == self._library.revision:
            return
        with self._index_lock:
            revision = self._library.revision
            if self._revision == revision:
                return
            files: dict[str, Entry] = {}
            dirs: dict[str, set] = {}
            for entry in self._library.all():
                path = entry.virtual_path
                files[path] = entry
                parts = path.strip("/").split("/")
                for i in range(1, len(parts)):
                    dirs.setdefault("/" + "/".join(parts[:i]), set()).add(parts[i])
            self._files = files
            self._dirs = dirs
            self._revision = revision
            _cache.resize(_tuning()["cache_blocks"])

    def _entry_for(self, path: str) -> Optional[Entry]:
        self._ensure_index()
        return self._files.get(path)

    def _children(self, path: str) -> set:
        self._ensure_index()
        return self._dirs.get(path.rstrip("/") or "/", set())

    # ── attributes ──────────────────────────────────────────────────
    def getattr(self, path, fh=None):
        base = {
            "st_uid": os.getuid(), "st_gid": os.getgid(),
            "st_atime": self._mtime, "st_mtime": self._mtime,
            "st_ctime": self._mtime, "st_nlink": 2,
        }
        if path == "/" or path.lstrip("/") in TOP_DIRS:
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        entry = self._entry_for(path)
        if entry is not None:
            mtime = entry.activated_at or entry.created_at
            return {
                **base,
                "st_mode": stat.S_IFREG | 0o444,
                "st_nlink": 1,
                "st_size": entry.size or FALLBACK_SIZE,
                "st_mtime": mtime,
                "st_ctime": mtime,
                "st_atime": mtime,
            }

        if self._children(path):
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
        raise FuseOSError(errno.ENOENT)

    def readdir(self, path, fh):
        if path == "/":
            return [".", "..", *TOP_DIRS]
        return [".", "..", *sorted(self._children(path))]

    def open(self, path, flags):
        if self._entry_for(path) is None:
            raise FuseOSError(errno.ENOENT)
        # Deliberately does not fetch a link. See the module docstring.
        return 0

    def release(self, path, fh):
        return 0

    # ── reads ───────────────────────────────────────────────────────
    def read(self, path, size, offset, fh):
        try:
            return self._read(path, size, offset)
        except FuseOSError:
            raise
        except Exception as exc:
            log.warning("read(%s) failed: %s", path, exc)
            raise FuseOSError(errno.EIO)

    def _read(self, path: str, size: int, offset: int) -> bytes:
        entry = self._entry_for(path)
        if entry is None:
            raise FuseOSError(errno.ENOENT)

        if not entry.url:
            # If the webhook is fetching a link right now, wait for it
            # rather than feeding header bytes into the opening seconds.
            event = activation_event(entry.entry_id)
            if not event.is_set():
                event.wait(timeout=float(settings.get("fuse_activation_wait", 20)))
            if not entry.url:
                return _placeholder_bytes(offset, size)

        if entry.size and offset >= entry.size:
            return b""   # real end of file

        block_size = _tuning()["block_mb"] * 1024 * 1024
        index = offset // block_size
        block = _cache.get((entry.url, index))
        if block is None:
            block = self._fetch_block(entry, index, block_size)
            if block is None:
                if entry.size and offset >= entry.size:
                    return b""
                return _placeholder_bytes(offset, size)

        start = index * block_size
        chunk = block[offset - start: offset - start + size]

        ahead = _tuning()["prefetch"]
        for step in range(1, ahead + 1):
            nxt = index + step
            if entry.size and nxt * block_size >= entry.size:
                break
            self._prefetch(entry, nxt, block_size)

        # Reads that straddle a block boundary.
        remaining = size - len(chunk)
        nxt = index + 1
        while remaining > 0:
            if entry.size and nxt * block_size >= entry.size:
                break
            more = _cache.get((entry.url, nxt))
            if more is None:
                more = self._fetch_block(entry, nxt, block_size)
                if more is None:
                    break
            take = more[:remaining]
            chunk += take
            remaining -= len(take)
            nxt += 1
        return chunk

    def _fetch_block(self, entry: Entry, index: int, block_size: int) -> Optional[bytes]:
        url = entry.url
        if not url:
            return None
        start = index * block_size
        headers = {**(entry.headers or {}), "Range": f"bytes={start}-{start + block_size - 1}"}
        timeout = _tuning()["timeout"]

        if not _inflight.acquire(timeout=timeout + 2):
            log.warning("%s: too many reads in flight, dropping block %d",
                        entry.display_name, index)
            return None
        try:
            for attempt in range(5):
                response = None
                try:
                    response = _session.get(url, headers=headers, timeout=timeout, stream=True)
                    if response.status_code in (200, 206):
                        data = response.content
                        if self._looks_like_error(entry, response, data, start):
                            self._link_failed(entry, url)
                            return None
                        _cache.put((url, index), data)
                        return data
                    if response.status_code == 416:
                        # Past the end. Deterministic, so don't retry —
                        # and take the chance to correct the size we've
                        # been reporting.
                        real = _parse_total(response.headers.get("Content-Range", ""))
                        if real and real != entry.size:
                            log.info("%s: correcting size %s -> %s",
                                     entry.display_name, entry.size, real)
                            entry.size = real
                            self._library.mark_dirty()
                        return None
                    if response.status_code in (401, 403, 410, 404):
                        log.warning("%s: link returned %d — needs repair",
                                    entry.display_name, response.status_code)
                        self._link_failed(entry, url)
                        return None
                    log.warning("%s: HTTP %d on block %d",
                                entry.display_name, response.status_code, index)
                except requests.RequestException as exc:
                    text = str(exc)
                    if "Too many open files" in text or "[Errno 24]" in text:
                        # Retrying immediately makes this worse, since
                        # descriptors are already gone. Back off harder
                        # and stop prefetching until pressure clears.
                        log.warning("%s: out of file descriptors — pausing prefetch",
                                    entry.display_name)
                        _pause_prefetch(5)
                        time.sleep(2.0)
                    else:
                        log.warning("%s: block %d attempt %d: %s",
                                    entry.display_name, index, attempt, exc)
                finally:
                    # Release the connection on every path. A streamed
                    # response left open holds its socket, which is the
                    # leak that produces the descriptor exhaustion above.
                    if response is not None:
                        response.close()
                if attempt < 4:
                    time.sleep(min(0.5 * (attempt + 1), 4.0))
            return None
        finally:
            _inflight.release()

    @staticmethod
    def _looks_like_error(entry: Entry, response, data: bytes, start: int) -> bool:
        """Some debrid backends answer a dead link with 200 OK and a JSON
        or HTML error body. Without this check that body gets cached and
        handed to the player as if it were video."""
        content_type = (response.headers.get("Content-Type") or "").lower()
        if any(t in content_type for t in ("json", "text/html", "text/plain")):
            log.warning("%s: got %s instead of media — treating the link as dead",
                        entry.display_name, content_type)
            return True
        near_eof = bool(entry.size and start + len(data) >= entry.size - 1)
        if len(data) < 4096 and not near_eof:
            log.warning("%s: %d-byte response mid-file — treating the link as dead",
                        entry.display_name, len(data))
            return True
        return False

    def _link_failed(self, entry: Entry, url: str) -> None:
        """Drop the dead link and let repair fetch a new one.

        The entry itself is untouched — it keeps its place in the library
        and its activation. From Plex's side the file never goes away;
        it just isn't readable until the next repair pass, which for an
        activated title is the next one to run.
        """
        _cache.invalidate_url(url)
        if entry.info_hash:
            from . import debrid
            debrid.forget(entry.info_hash)
        self._library.clear_link(entry.entry_id)
        from . import repair
        repair.request_urgent(entry.entry_id)

    def _prefetch(self, entry: Entry, index: int, block_size: int) -> None:
        if _prefetch_paused() or not entry.url:
            return
        key = (entry.url, index)
        if _cache.get(key) is not None:
            return
        with _prefetch_lock:
            if key in _prefetching:
                return
            _prefetching.add(key)

        def run():
            try:
                self._fetch_block(entry, index, block_size)
            finally:
                with _prefetch_lock:
                    _prefetching.discard(key)

        threading.Thread(target=run, daemon=True, name=f"prefetch-{index}").start()

    # ── read-only ───────────────────────────────────────────────────
    def write(self, *a):  raise FuseOSError(errno.EROFS)
    def create(self, *a): raise FuseOSError(errno.EROFS)
    def mkdir(self, *a):  raise FuseOSError(errno.EROFS)
    def rmdir(self, *a):  raise FuseOSError(errno.EROFS)
    def unlink(self, *a): raise FuseOSError(errno.EROFS)
    def rename(self, *a): raise FuseOSError(errno.EROFS)
    def truncate(self, *a): raise FuseOSError(errno.EROFS)


def _placeholder_bytes(offset: int, size: int) -> bytes:
    if offset >= len(_HEADER):
        return b"\x00" * size
    chunk = _HEADER[offset:offset + size]
    return chunk + b"\x00" * (size - len(chunk))


def _parse_total(content_range: str) -> Optional[int]:
    if not content_range or "/" not in content_range:
        return None
    total = content_range.rsplit("/", 1)[1].strip()
    if total == "*":
        return None
    try:
        return int(total)
    except ValueError:
        return None


# ── mount lifecycle ─────────────────────────────────────────────────────
_fs: Optional[AIOGatewayFS] = None
_thread: Optional[threading.Thread] = None


def mount(library: "Library", mountpoint: str) -> bool:
    global _fs, _thread
    if not FUSE_AVAILABLE:
        log.error("Cannot mount: fusepy or libfuse is missing")
        return False

    os.makedirs(mountpoint, exist_ok=True)
    _fs = AIOGatewayFS(library)

    def run():
        try:
            FUSE(_fs, mountpoint, nothreads=False, foreground=True,
                 allow_other=True, ro=True,
                 attr_timeout=30, entry_timeout=30)
        except Exception as exc:
            log.error("Filesystem exited: %s", exc)

    _thread = threading.Thread(target=run, daemon=True, name="fuse-mount")
    _thread.start()
    time.sleep(1.0)
    if not _thread.is_alive():
        log.error("Mount failed — check /dev/fuse and cap_add: SYS_ADMIN")
        return False
    log.info("Mounted at %s", mountpoint)
    return True


def unmount(mountpoint: str) -> None:
    """Unmount the filesystem. Safe to call more than once.

    Escalates through four attempts because which one works depends on
    the host: `fusermount` isn't always on PATH, and a mount that is
    still busy only comes off lazily. The lazy variants always succeed,
    which is why they come last — they detach the mount without waiting
    for anything still holding it.
    """
    import subprocess

    def attempt(cmd) -> bool:
        try:
            return subprocess.run(cmd, timeout=5, capture_output=True).returncode == 0
        except Exception:
            return False

    if (attempt(["fusermount", "-u", mountpoint])
            or attempt(["fusermount", "-uz", mountpoint])
            or attempt(["umount", mountpoint])
            or attempt(["umount", "-l", mountpoint])):
        log.info("Unmounted %s", mountpoint)
    else:
        log.warning("Could not unmount %s", mountpoint)


_warming: set = set()
_warm_lock = threading.Lock()


def warm(entry: Entry) -> None:
    """Pull the opening blocks of a file into the cache.

    Playback's worst moment is the first one: the player asks for the
    start of the file and waits on a cold CDN range request before a
    single frame appears. Fetching those blocks when the file is created
    moves that wait to a point where nobody is watching.

    Only the opening blocks. Warming further ahead would spend real
    bandwidth on files nobody may ever play, and the read-ahead in
    `_read` takes over from there once playback actually starts.
    """
    if not entry.url or not settings.get("prewarm_enabled", True):
        return
    blocks = max(0, int(settings.get("prewarm_blocks", 2) or 0))
    if blocks == 0:
        return

    key = entry.entry_id
    with _warm_lock:
        if key in _warming:
            return
        _warming.add(key)

    def run():
        try:
            if _fs is None:
                return
            block_size = _tuning()["block_mb"] * 1024 * 1024
            for index in range(blocks):
                if entry.size and index * block_size >= entry.size:
                    break
                if _cache.get((entry.url, index)) is not None:
                    continue
                if _fs._fetch_block(entry, index, block_size) is None:
                    # A link that won't serve its first block is dead.
                    # Stop rather than retrying the rest.
                    break
        except Exception as exc:
            log.debug("Prewarm failed for %s: %s", entry.display_name, exc)
        finally:
            with _warm_lock:
                _warming.discard(key)

    threading.Thread(target=run, daemon=True,
                     name=f"warm-{entry.entry_id[:8]}").start()


def invalidate(entry: Entry) -> None:
    if entry.url:
        _cache.invalidate_url(entry.url)


def folder_for(entry: Entry, mountpoint: str) -> str:
    """Real path of the directory holding this entry, for a scoped Plex
    scan of just that folder."""
    virtual_dir = "/".join(entry.virtual_path.split("/")[:-1])
    return f"{mountpoint.rstrip('/')}{virtual_dir}"
