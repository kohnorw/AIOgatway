"""gateway/proxy.py — Byte-range proxy between Plex and AIOStreams URLs."""
from __future__ import annotations

import logging
from typing import AsyncIterator, Optional

import aiohttp

from .models import Stub

logger = logging.getLogger("aiogateway.proxy")
CHUNK = 256 * 1024


class StreamProxy:
    def __init__(self) -> None:
        self._session: aiohttp.ClientSession | None = None

    async def open(self) -> None:
        self._session = aiohttp.ClientSession()

    async def close(self) -> None:
        if self._session:
            await self._session.close()

    async def proxy(
        self, stub: Stub, range_header: Optional[str] = None
    ) -> tuple[int, dict, AsyncIterator[bytes]]:
        assert self._session and stub.stream_url

        from .fuse_fs import STREAM_USER_AGENT
        headers = {"User-Agent": STREAM_USER_AGENT, **dict(stub.stream_headers)}
        if range_header:
            headers["Range"] = range_header

        logger.debug("Proxy GET stub=%s range=%s", stub.stub_id, range_header)
        resp = await self._session.get(stub.stream_url, headers=headers, allow_redirects=True)

        fwd = {k: resp.headers[k] for k in
               ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges")
               if k in resp.headers}
        fwd.setdefault("Accept-Ranges", "bytes")

        if resp.status >= 400:
            # Error responses are never streamed to the client (the caller
            # repairs or reports), so release the connection right away.
            resp.release()

            async def _empty() -> AsyncIterator[bytes]:
                if False:
                    yield b""
            return resp.status, fwd, _empty()

        async def _iter() -> AsyncIterator[bytes]:
            # Always release the upstream connection — previously the
            # response was never closed, leaking a socket per request
            # (and per aborted seek).
            try:
                async for chunk in resp.content.iter_chunked(CHUNK):
                    yield chunk
            finally:
                resp.release()

        return resp.status, fwd, _iter()

    async def head(self, stub: Stub) -> tuple[int, dict]:
        assert self._session and stub.stream_url
        from .fuse_fs import STREAM_USER_AGENT
        async with self._session.head(stub.stream_url, headers={"User-Agent": STREAM_USER_AGENT, **dict(stub.stream_headers)},
                                      allow_redirects=True) as resp:
            fwd = {k: resp.headers[k] for k in
                   ("Content-Type", "Content-Length", "Accept-Ranges")
                   if k in resp.headers}
            fwd.setdefault("Accept-Ranges", "bytes")
            return resp.status, fwd
