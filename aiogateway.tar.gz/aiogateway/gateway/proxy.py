"""gateway/proxy.py — Byte-range proxy between Plex and TorBox CDN links.

Stub stream_urls are stable torbox:// refs; the real CDN URL is looked up in
the TorBox cache per request. Like warpbox, a GET with NO Range header (a
full-file download) is answered with a 302 straight to the CDN so this
process drops out of the data path entirely.
"""
from __future__ import annotations

import asyncio
import logging
from typing import AsyncIterator, Optional

import aiohttp

from .models import Stub

logger = logging.getLogger("aiogateway.proxy")
CHUNK = 256 * 1024


async def real_url(stub: Stub, force_refresh: bool = False) -> str:
    from .torbox_client import is_ref, cdn_url_for_ref
    from .torbox_guard import HIGH
    if not is_ref(stub.stream_url):
        return stub.stream_url
    return await asyncio.to_thread(cdn_url_for_ref, stub.stream_url, HIGH, force_refresh)


class StreamProxy:
    def __init__(self) -> None:
        self._session: aiohttp.ClientSession | None = None

    async def open(self) -> None:
        self._session = aiohttp.ClientSession()

    async def close(self) -> None:
        if self._session:
            await self._session.close()

    async def proxy(
        self, stub: Stub, range_header: Optional[str] = None
    ) -> tuple[int, dict, AsyncIterator[bytes]]:
        assert self._session and stub.stream_url
        headers = dict(stub.stream_headers or {})
        if range_header:
            headers["Range"] = range_header

        url = await real_url(stub)
        resp = await self._session.get(url, headers=headers, allow_redirects=True)
        if resp.status in (401, 403, 404, 410):
            # expired link — repair once in place
            resp.release()
            from .torbox_client import is_ref, invalidate_ref
            if is_ref(stub.stream_url):
                await asyncio.to_thread(invalidate_ref, stub.stream_url)
                url = await real_url(stub, force_refresh=True)
                resp = await self._session.get(url, headers=headers, allow_redirects=True)

        fwd = {k: resp.headers[k] for k in
               ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges")
               if k in resp.headers}
        fwd.setdefault("Accept-Ranges", "bytes")

        async def _iter() -> AsyncIterator[bytes]:
            try:
                async for chunk in resp.content.iter_chunked(CHUNK):
                    yield chunk
            finally:
                resp.release()

        return resp.status, fwd, _iter()

    async def head(self, stub: Stub) -> tuple[int, dict]:
        assert self._session and stub.stream_url
        url = await real_url(stub)
        resp = await self._session.head(url, headers=stub.stream_headers or {}, allow_redirects=True)
        fwd = {k: resp.headers[k] for k in ("Content-Type", "Content-Length", "Accept-Ranges")
               if k in resp.headers}
        fwd.setdefault("Accept-Ranges", "bytes")
        resp.release()
        return resp.status, fwd
