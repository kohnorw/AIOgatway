"""
gateway/proxy.py
~~~~~~~~~~~~~~~~
Async HTTP proxy that pipes an AIOStreams URL to Plex.

When Plex requests a file it knows about (our stub .mkv), it first sends
a HEAD or GET with Range headers to check the file. Our proxy:

  1. Forwards the Range header to the AIOStreams URL
  2. Pipes the response bytes back to Plex
  3. Forwards response headers (Content-Type, Content-Length, Content-Range)

This makes Plex think it's reading a local file — seeking, buffering,
and direct play all work correctly.

The proxy endpoint is: GET /proxy/{stub_id}
Plex is pointed here by rewriting the stub .mkv symlink or via nginx.
"""
from __future__ import annotations

import asyncio
import logging
from typing import AsyncIterator, Optional

import aiohttp
from aiostream import operator

from .models import Stub

logger = logging.getLogger("aiogateway.proxy")

CHUNK_SIZE = 256 * 1024   # 256 KB chunks


@operator
async def _pipe_chunks(
    response: aiohttp.ClientResponse,
) -> AsyncIterator[bytes]:
    """Yield response chunks through an aiostream operator."""
    async for chunk in response.content.iter_chunked(CHUNK_SIZE):
        yield chunk


class StreamProxy:
    """
    Proxies an AIOStreams HTTP URL to a streaming FastAPI response.
    Handles Range requests so Plex can seek.
    """

    def __init__(self) -> None:
        self._session: aiohttp.ClientSession | None = None

    async def __aenter__(self) -> "StreamProxy":
        self._session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, *_: object) -> None:
        if self._session:
            await self._session.close()

    async def proxy_stream(
        self,
        stub: Stub,
        range_header: Optional[str] = None,
    ) -> tuple[int, dict, AsyncIterator[bytes]]:
        """
        Open the upstream AIOStreams URL and return:
          (status_code, response_headers, async_byte_iterator)

        The caller (FastAPI endpoint) streams the bytes directly to Plex.
        """
        assert self._session
        assert stub.stream_url, "Stub has no stream_url — not yet resolved"

        headers = dict(stub.stream_headers)
        if range_header:
            headers["Range"] = range_header

        logger.debug(
            "Proxying stub=%s url=%s... range=%s",
            stub.stub_id, stub.stream_url[:50], range_header
        )

        response = await self._session.get(
            stub.stream_url,
            headers=headers,
            allow_redirects=True,
        )

        # Forward relevant headers back to Plex
        forward_headers = {}
        for key in (
            "Content-Type",
            "Content-Length",
            "Content-Range",
            "Accept-Ranges",
        ):
            val = response.headers.get(key)
            if val:
                forward_headers[key] = val

        # Ensure Plex knows we accept range requests
        forward_headers.setdefault("Accept-Ranges", "bytes")

        status = response.status   # 200 or 206 (partial content)

        async def _iter() -> AsyncIterator[bytes]:
            async for chunk in response.content.iter_chunked(CHUNK_SIZE):
                yield chunk

        return status, forward_headers, _iter()

    async def head_stream(self, stub: Stub) -> tuple[int, dict]:
        """
        Handle a HEAD request from Plex (checks file size before playing).
        Returns (status, headers) with no body.
        """
        assert self._session
        assert stub.stream_url

        response = await self._session.head(
            stub.stream_url,
            headers=stub.stream_headers,
            allow_redirects=True,
        )

        forward_headers = {}
        for key in ("Content-Type", "Content-Length", "Accept-Ranges"):
            val = response.headers.get(key)
            if val:
                forward_headers[key] = val

        forward_headers.setdefault("Accept-Ranges", "bytes")
        return response.status, forward_headers
