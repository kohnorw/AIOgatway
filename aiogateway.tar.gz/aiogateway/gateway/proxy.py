"""gateway/proxy.py — Byte-range proxy between Plex and AIOStreams URLs."""
from __future__ import annotations

import logging
from typing import AsyncIterator, Optional

import aiohttp

from .models import Stub

logger = logging.getLogger("aiogateway.proxy")
CHUNK = 256 * 1024


class StreamProxy:
    def __init__(self) -> None:
        self._session: aiohttp.ClientSession | None = None

    async def open(self) -> None:
        self._session = aiohttp.ClientSession()

    async def close(self) -> None:
        if self._session:
            await self._session.close()

    async def proxy(
        self, stub: Stub, range_header: Optional[str] = None
    ) -> tuple[int, dict, AsyncIterator[bytes]]:
        assert self._session and stub.stream_url

        headers = dict(stub.stream_headers)
        if range_header:
            headers["Range"] = range_header

        logger.debug("Proxy GET stub=%s range=%s", stub.stub_id, range_header)
        resp = await self._session.get(stub.stream_url, headers=headers, allow_redirects=True)

        fwd = {k: resp.headers[k] for k in
               ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges")
               if k in resp.headers}
        fwd.setdefault("Accept-Ranges", "bytes")

        async def _iter() -> AsyncIterator[bytes]:
            async for chunk in resp.content.iter_chunked(CHUNK):
                yield chunk

        return resp.status, fwd, _iter()

    async def head(self, stub: Stub) -> tuple[int, dict]:
        assert self._session and stub.stream_url
        resp = await self._session.head(stub.stream_url, headers=stub.stream_headers, allow_redirects=True)
        fwd = {k: resp.headers[k] for k in
               ("Content-Type", "Content-Length", "Accept-Ranges")
               if k in resp.headers}
        fwd.setdefault("Accept-Ranges", "bytes")
        return resp.status, fwd
