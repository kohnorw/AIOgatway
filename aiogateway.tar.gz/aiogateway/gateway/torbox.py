"""
gateway/torbox.py
~~~~~~~~~~~~~~~~~
Cache verification against a TorBox account.

Why this exists
---------------
Same problem as AllDebrid: AIOStreams' `cached` flag is three-state, and
for TorBox it is very often simply absent. With cached-only mode on, an
absent flag means the candidate is dropped — so a library with TorBox
enabled could lose every TorBox result at once while AllDebrid (which
aiogateway verifies) survived. That looks like TorBox not working at
all.

The good news is that TorBox is far simpler to check than AllDebrid.
AllDebrid retired its instant-availability endpoint, which is why that
module has to upload a magnet and read back a `ready` flag, then clean
up after itself. TorBox still has a real one:

  GET /v1/api/torrents/checkcached?hash=<h1,h2,...>&format=list
      Authorization: Bearer <key>

It is read-only. Nothing is added to the account, nothing needs
deleting, and there is no cleanup machinery here at all — which is why
this module is a fraction of the size of alldebrid.py despite doing the
same job. Up to ~100 hashes per request, and TorBox caches the answer
its side for an hour.

Only hashes TorBox affirmatively reports are treated as cached. A hash
absent from the response is "not cached"; a FAILED REQUEST is "unknown"
and leaves the candidate's status untouched, so an outage can never
silently empty search results.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Iterable, Optional

import aiohttp

logger = logging.getLogger("aiogateway.torbox")

API_BASE = "https://api.torbox.app/v1/api"

# TorBox documents a practical ceiling of ~100 hashes per query (an HTTP
# query-length limit, not an API one). Stay under it.
_BATCH_SIZE = 80

_REQUEST_TIMEOUT = 20

# hash -> {"cached": bool, "at": float}
_cache: dict[str, dict] = {}

# Serialise requests. TorBox is fast (sub-second per 100 hashes), so
# there's nothing to gain from parallelism and this keeps a library scan
# from opening a burst of connections.
_gate = asyncio.Semaphore(1)


def _settings():
    from gateway import settings as _s
    return _s


def api_key() -> str:
    """The TorBox API key in effect (settings first, then env)."""
    return _settings().connection("torbox_api_key", "")


def is_enabled() -> bool:
    s = _settings()
    return bool(s.get("torbox_enabled", True)) and bool(api_key())


def is_torbox(service: Optional[str]) -> bool:
    """Whether a result's `service` field names TorBox."""
    s = (service or "").strip().lower().replace("-", "").replace("_", "")
    return s in ("torbox", "tb")


def _cache_ttl_seconds() -> float:
    try:
        return float(_settings().get("torbox_cache_ttl_minutes", 60)) * 60.0
    except (TypeError, ValueError):
        return 3600.0


def _cached_answer(info_hash: str) -> Optional[bool]:
    entry = _cache.get(info_hash)
    if not entry:
        return None
    ttl = _cache_ttl_seconds()
    if ttl and time.time() - entry["at"] > ttl:
        _cache.pop(info_hash, None)
        return None
    return entry["cached"]


def forget(info_hash: Optional[str]) -> None:
    """Drop a memoised answer — e.g. after a supposedly-cached link died."""
    _cache.pop((info_hash or "").lower(), None)


def clear_cache() -> int:
    n = len(_cache)
    _cache.clear()
    return n


async def _check_batch(session: aiohttp.ClientSession, hashes: list[str]) -> Optional[set]:
    """
    Ask TorBox about one batch. Returns the set of hashes it reports as
    cached, or None if the request failed (meaning "unknown", NOT "none
    are cached").
    """
    params = {
        "hash": ",".join(hashes),
        # "list" is the cheaper shape — TorBox doesn't have to rebuild
        # the response as a keyed object — and both are equally easy to
        # read here.
        "format": "list",
        "list_files": "false",
    }
    try:
        async with session.get(
            f"{API_BASE}/torrents/checkcached",
            params=params,
            headers={"Authorization": f"Bearer {api_key()}",
                     "Accept": "application/json"},
            timeout=aiohttp.ClientTimeout(total=_REQUEST_TIMEOUT),
        ) as resp:
            if resp.status in (401, 403):
                logger.warning("TorBox rejected the API key (HTTP %d) — check it "
                               "in Config → Connections", resp.status)
                return None
            payload = await resp.json(content_type=None)
            if resp.status != 200:
                logger.warning("TorBox checkcached returned HTTP %d: %s",
                               resp.status, str(payload)[:200])
                return None
    except asyncio.TimeoutError:
        logger.warning("TorBox checkcached timed out after %ds", _REQUEST_TIMEOUT)
        return None
    except Exception as exc:
        logger.warning("TorBox checkcached failed: %s", exc)
        return None

    if not isinstance(payload, dict) or not payload.get("success", True):
        logger.warning("TorBox checkcached error: %s",
                       str(payload.get("detail") if isinstance(payload, dict) else payload)[:200])
        return None

    data = payload.get("data")
    found: set = set()

    # format=list gives an array of records; format=object gives a dict
    # keyed by hash. Both are accepted so a future default change, or an
    # instance configured differently, doesn't silently return nothing.
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                h = (item.get("hash") or "").lower()
                if h:
                    found.add(h)
            elif isinstance(item, str):
                found.add(item.lower())
    elif isinstance(data, dict):
        for k, v in data.items():
            h = (k or "").lower()
            if h and v is not False:
                found.add(h)
    elif data is None:
        # A successful response with no data means nothing in this batch
        # is cached — a real answer, not a failure.
        return set()

    return found


async def verify(hashes: Iterable[str]) -> dict[str, bool]:
    """
    Resolve cached/not-cached for a set of infoHashes.

    Returns a hash → cached map covering only the hashes an answer could
    be obtained for. A hash absent from the result means "unknown"
    (request failed), which callers must treat differently from False.
    """
    wanted = {(h or "").lower() for h in hashes if h}
    wanted.discard("")
    if not wanted or not is_enabled():
        return {}

    result: dict[str, bool] = {}
    todo: list[str] = []
    for h in wanted:
        known = _cached_answer(h)
        if known is None:
            todo.append(h)
        else:
            result[h] = known

    if not todo:
        return result

    async with _gate:
        still = []
        for h in todo:
            known = _cached_answer(h)
            if known is None:
                still.append(h)
            else:
                result[h] = known
        if not still:
            return result

        logger.info("TorBox: checking %d hash(es)", len(still))
        now = time.time()
        async with aiohttp.ClientSession() as session:
            for i in range(0, len(still), _BATCH_SIZE):
                batch = still[i:i + _BATCH_SIZE]
                found = await _check_batch(session, batch)
                if found is None:
                    continue          # unknown — record nothing for this batch
                for h in batch:
                    cached = h in found
                    result[h] = cached
                    _cache[h] = {"cached": cached, "at": now}

    hits = sum(1 for v in result.values() if v)
    logger.info("TorBox: %d/%d cached", hits, len(result))
    return result


async def connection_test() -> dict:
    """Diagnostic for Config → Connections."""
    out = {"ok": False, "configured": bool(api_key()), "enabled": is_enabled(),
           "error": None, "username": None, "plan": None}
    if not api_key():
        out["error"] = "No TorBox API key set"
        return out
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{API_BASE}/user/me",
                headers={"Authorization": f"Bearer {api_key()}"},
                timeout=aiohttp.ClientTimeout(total=_REQUEST_TIMEOUT),
            ) as resp:
                payload = await resp.json(content_type=None)
                if resp.status != 200 or not isinstance(payload, dict):
                    out["error"] = f"TorBox returned HTTP {resp.status}"
                    return out
    except Exception as exc:
        out["error"] = f"Could not reach TorBox: {exc}"
        return out

    data = payload.get("data") or {}
    out["username"] = data.get("email") or data.get("customer")
    out["plan"] = data.get("plan")
    out["ok"] = True
    return out
