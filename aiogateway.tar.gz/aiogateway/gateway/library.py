"""
gateway/library.py
~~~~~~~~~~~~~~~~~~
The entry registry. Every file visible under the mountpoint is one entry
in here; nothing is written to a real disk.

Activation, stated once because it drives most of the design:

  - `add()` creates an entry the moment a usable source is confirmed.
    The file exists from that point and reports its real size.
  - `activate()` runs on the first play. It makes sure the entry has a
    live link, stamps `activated_at`, and that stamp is never cleared.
  - Nothing expires. There is no lease to renew and no state a file falls
    back to. Once a title has been played it stays playable, and keeping
    it that way is the repair job's responsibility.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import threading
import time
from typing import Callable, Iterable, Optional

from .models import Candidate, Entry, EntryState, MediaItem, MediaType, Quality
from .paths import library_file

logger = logging.getLogger("aiogateway.library")


def entry_id_for(media_id: str, quality: Quality) -> str:
    return hashlib.sha1(f"{media_id}:{quality.value}".encode()).hexdigest()[:16]


class Library:
    def __init__(self) -> None:
        self._entries: dict[str, Entry] = {}
        self._lock = threading.RLock()
        self._dirty = False
        self._listeners: list[Callable[[Entry], None]] = []
        # Bumped on every structural change. The filesystem watches this
        # instead of rescanning, so a directory listing costs nothing
        # when nothing has changed.
        self.revision = 0

    # ── persistence ─────────────────────────────────────────────────
    def load(self) -> int:
        path = library_file()
        if not path.exists():
            return 0
        try:
            data = json.loads(path.read_text())
        except Exception as exc:
            logger.error("library.json unreadable (%s) — starting empty", exc)
            return 0
        with self._lock:
            self._entries.clear()
            for raw in data.get("entries", []):
                try:
                    entry = Entry.from_dict(raw)
                    self._entries[entry.entry_id] = entry
                except Exception as exc:
                    logger.warning("Skipping malformed library row: %s", exc)
            self.revision += 1
        logger.info("Loaded %d library entries", len(self._entries))
        return len(self._entries)

    def save(self) -> None:
        with self._lock:
            payload = {
                "version": 2,
                "saved_at": time.time(),
                "entries": [e.to_dict() for e in self._entries.values()],
            }
            self._dirty = False
        path = library_file()
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload))
        os.replace(tmp, path)

    def mark_dirty(self) -> None:
        with self._lock:
            self._dirty = True

    @property
    def dirty(self) -> bool:
        return self._dirty

    # ── reads ───────────────────────────────────────────────────────
    def all(self) -> list[Entry]:
        with self._lock:
            return list(self._entries.values())

    def get(self, entry_id: str) -> Optional[Entry]:
        with self._lock:
            return self._entries.get(entry_id)

    def by_media(self, media_id: str, quality: Quality) -> Optional[Entry]:
        return self.get(entry_id_for(media_id, quality))

    def by_path(self, path: str) -> Optional[Entry]:
        with self._lock:
            for entry in self._entries.values():
                if entry.virtual_path == path:
                    return entry
        return None

    def for_imdb(self, imdb_id: str) -> list[Entry]:
        with self._lock:
            return [e for e in self._entries.values() if e.imdb_id == imdb_id]

    def series_ids(self) -> set[str]:
        with self._lock:
            return {e.imdb_id for e in self._entries.values()
                    if e.media_type == MediaType.SERIES}

    def counts(self) -> dict:
        with self._lock:
            entries = list(self._entries.values())
        return {
            "total": len(entries),
            "activated": sum(1 for e in entries if e.activated),
            "ready": sum(1 for e in entries if e.state == EntryState.READY),
            "missing": sum(1 for e in entries if e.state == EntryState.MISSING),
            "movies": sum(1 for e in entries if e.media_type == MediaType.MOVIE),
            "episodes": sum(1 for e in entries if e.media_type == MediaType.SERIES),
        }

    # ── change notification ─────────────────────────────────────────
    def on_change(self, callback: Callable[[Entry], None]) -> None:
        self._listeners.append(callback)

    def _notify(self, entry: Entry) -> None:
        for callback in self._listeners:
            try:
                callback(entry)
            except Exception as exc:
                logger.warning("Library listener failed: %s", exc)

    # ── writes ──────────────────────────────────────────────────────
    def upsert(
        self, item: MediaItem, quality: Quality,
        candidate: Optional[Candidate] = None,
        state: EntryState = EntryState.READY,
        size_hint: Optional[int] = None,
        added_by: str = "",
    ) -> Entry:
        """Create or refresh the entry for this media + quality.

        An existing entry keeps its activation and its current link — a
        re-add should never quietly swap out a file someone is watching.
        """
        eid = entry_id_for(item.media_id, quality)
        with self._lock:
            entry = self._entries.get(eid)
            if entry is None:
                entry = Entry(
                    entry_id=eid, media_id=item.media_id, imdb_id=item.imdb_id,
                    title=item.title, quality=quality, media_type=item.media_type,
                    show_title=item.show_title, year=item.year,
                    season=item.season, episode=item.episode, poster=item.poster,
                    state=state, added_by=added_by,
                )
                self._entries[eid] = entry
                new = True
            else:
                new = False
                if item.poster and not entry.poster:
                    entry.poster = item.poster

            if candidate is not None and not entry.activated:
                entry.url = candidate.url
                entry.headers = dict(candidate.headers or {})
                entry.size = candidate.size or entry.size
                entry.source_filename = candidate.filename
                entry.source_service = candidate.service
                entry.info_hash = candidate.info_hash
                entry.state = EntryState.READY
            elif size_hint and not entry.size:
                entry.size = size_hint

            if state == EntryState.MISSING and not entry.activated and not entry.url:
                entry.state = EntryState.MISSING

            self.revision += 1
            self._dirty = True

        if new:
            logger.info("Added %s [%s]", entry.display_name, quality.value)
        self._notify(entry)
        return entry

    def attach_source(self, entry_id: str, candidate: Candidate,
                      pinned: Optional[bool] = None) -> Optional[Entry]:
        """Point an entry at a (new) source. Used by activation, by repair
        when the previous link stopped working, and by a manual pick.

        `pinned` left as None preserves whatever the entry already had, so
        repair re-acquiring a pinned release doesn't un-pin it.
        """
        with self._lock:
            entry = self._entries.get(entry_id)
            if entry is None:
                return None
            if pinned is not None:
                entry.pinned = pinned
            entry.url = candidate.url
            entry.headers = dict(candidate.headers or {})
            entry.size = candidate.size or entry.size
            entry.source_filename = candidate.filename
            entry.source_service = candidate.service
            entry.info_hash = candidate.info_hash
            entry.repair_failures = 0
            entry.last_repair_at = time.time()
            if entry.state != EntryState.ACTIVE:
                entry.state = EntryState.ACTIVE if entry.activated else EntryState.READY
            self.revision += 1
            self._dirty = True
        self._notify(entry)
        return entry

    def mark_activated(self, entry_id: str) -> Optional[Entry]:
        """First play. Permanent — `activated_at` is never cleared."""
        with self._lock:
            entry = self._entries.get(entry_id)
            if entry is None:
                return None
            first_time = not entry.activated
            if first_time:
                entry.activated_at = time.time()
            entry.last_played_at = time.time()
            entry.state = EntryState.ACTIVE
            self.revision += 1
            self._dirty = True
        if first_time:
            logger.info("Activated %s [%s]", entry.display_name, entry.quality.value)
        self._notify(entry)
        return entry

    def mark_missing(self, entry_id: str) -> Optional[Entry]:
        with self._lock:
            entry = self._entries.get(entry_id)
            if entry is None:
                return None
            entry.url = None
            entry.headers = {}
            entry.state = EntryState.MISSING
            entry.repair_failures += 1
            entry.last_repair_at = time.time()
            self.revision += 1
            self._dirty = True
        self._notify(entry)
        return entry

    def clear_link(self, entry_id: str) -> Optional[Entry]:
        """Drop the current link but keep the entry and its activation,
        so the next play or repair fetches a fresh one."""
        with self._lock:
            entry = self._entries.get(entry_id)
            if entry is None:
                return None
            entry.url = None
            entry.headers = {}
            self.revision += 1
            self._dirty = True
        self._notify(entry)
        return entry

    def remove(self, entry_id: str) -> bool:
        with self._lock:
            entry = self._entries.pop(entry_id, None)
            if entry is None:
                return False
            self.revision += 1
            self._dirty = True
        logger.info("Removed %s [%s]", entry.display_name, entry.quality.value)
        self._notify(entry)
        return True

    def remove_many(self, entry_ids: Iterable[str]) -> int:
        removed = 0
        with self._lock:
            for eid in list(entry_ids):
                if self._entries.pop(eid, None) is not None:
                    removed += 1
            if removed:
                self.revision += 1
                self._dirty = True
        return removed

    def remove_title(self, imdb_id: str, quality: Optional[Quality] = None,
                     season: Optional[int] = None) -> int:
        with self._lock:
            targets = [
                e.entry_id for e in self._entries.values()
                if e.imdb_id == imdb_id
                and (quality is None or e.quality == quality)
                and (season is None or e.season == season)
            ]
        return self.remove_many(targets)

    # ── backup ──────────────────────────────────────────────────────
    def export(self) -> list[dict]:
        """What a backup carries. Links are deliberately excluded: they
        are short-lived, account-bound, and re-fetched on first play
        anyway, so storing them would put live credentials in a file
        people email to each other."""
        with self._lock:
            return [{
                "media_id": e.media_id, "imdb_id": e.imdb_id, "title": e.title,
                "quality": e.quality.value, "media_type": e.media_type.value,
                "show_title": e.show_title, "year": e.year, "season": e.season,
                "episode": e.episode, "poster": e.poster,
                "created_at": e.created_at, "activated_at": e.activated_at,
                "added_by": e.added_by,
            } for e in self._entries.values()]

    def import_entries(self, rows: list[dict], replace: bool = False) -> dict:
        added = skipped = 0
        with self._lock:
            if replace:
                self._entries.clear()
            for row in rows:
                try:
                    quality = Quality(row.get("quality", "hd"))
                    media_id = row["media_id"]
                    eid = entry_id_for(media_id, quality)
                    if eid in self._entries:
                        skipped += 1
                        continue
                    self._entries[eid] = Entry(
                        entry_id=eid, media_id=media_id, imdb_id=row["imdb_id"],
                        title=row["title"], quality=quality,
                        media_type=MediaType(row.get("media_type", "movie")),
                        show_title=row.get("show_title", ""), year=row.get("year"),
                        season=row.get("season"), episode=row.get("episode"),
                        poster=row.get("poster", ""),
                        # Restored entries have no link yet, so they come
                        # back as MISSING and the first repair pass (or
                        # the first play) fetches one.
                        state=EntryState.MISSING,
                        created_at=row.get("created_at", time.time()),
                        activated_at=row.get("activated_at"),
                        added_by=row.get("added_by", ""),
                    )
                    added += 1
                except Exception as exc:
                    logger.warning("Skipping backup row: %s", exc)
                    skipped += 1
            self.revision += 1
            self._dirty = True
        self.save()
        return {"added": added, "skipped": skipped}


async def autosave_loop(library: Library, interval: float = 20.0) -> None:
    """Batches writes instead of rewriting the file on every change — a
    season scan produces hundreds of changes in a few seconds."""
    while True:
        try:
            await asyncio.sleep(interval)
            if library.dirty:
                library.save()
        except asyncio.CancelledError:
            if library.dirty:
                library.save()
            raise
        except Exception as exc:
            logger.error("Library autosave failed: %s", exc)
