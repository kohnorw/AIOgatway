"""
gateway/auth.py
~~~~~~~~~~~~~~~
Web UI accounts.

  - Roles: "admin" (everything) and "user" (browse + request titles).
  - Passwords: scrypt (stdlib), per-user random salt, constant-time compare.
  - Sessions: random 256-bit tokens in an HttpOnly cookie. Only a SHA-256 of
    each token is stored, so the users file can't be used to hijack a session.
    30-day sliding expiry; changing a password, role or deleting a user signs
    that user out everywhere.
  - Login throttling: repeated failures for the same username or client IP
    are delayed with an escalating lockout.
  - The first account is created through a one-time setup screen and is
    always an admin. The last admin can't be deleted or demoted.

Stored as JSON next to the settings file (aiogateway_users.json).
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import threading
import time
from pathlib import Path
from typing import Optional

log = logging.getLogger("aiogateway.auth")

ROLES = ("admin", "user")
SESSION_TTL = 30 * 86400
SESSION_TOUCH_PERSIST = 600          # persist sliding expiry at most every 10 min
COOKIE_NAME = "aiog_session"

_USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")
_MIN_PASSWORD = 8

_SCRYPT_N, _SCRYPT_R, _SCRYPT_P = 2 ** 14, 8, 1


class AuthError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def _users_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_users.json"


# ── Passwords ─────────────────────────────────────────────────────────────────

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P, dklen=32)
    b64 = lambda b: base64.b64encode(b).decode()
    return f"scrypt${_SCRYPT_N}${_SCRYPT_R}${_SCRYPT_P}${b64(salt)}${b64(digest)}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, n, r, p, salt, digest = stored.split("$")
        if algo != "scrypt":
            return False
        calc = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt),
                              n=int(n), r=int(r), p=int(p), dklen=len(base64.b64decode(digest)))
        return hmac.compare_digest(calc, base64.b64decode(digest))
    except Exception:
        return False


# Used for unknown usernames so a failed login takes the same time either way.
_DUMMY_HASH = hash_password(secrets.token_hex(16))


def validate_username(username: str) -> str:
    username = (username or "").strip()
    if not _USERNAME_RE.match(username):
        raise AuthError("Username must be 3–32 characters: letters, numbers, dot, dash or underscore")
    return username


def validate_password(password: str) -> str:
    if not isinstance(password, str) or len(password) < _MIN_PASSWORD:
        raise AuthError(f"Password must be at least {_MIN_PASSWORD} characters")
    if len(password) > 1024:
        raise AuthError("Password is too long")
    return password


# ── Login throttling ──────────────────────────────────────────────────────────

class _Throttle:
    FREE_ATTEMPTS = 5
    WINDOW = 15 * 60
    MAX_LOCK = 15 * 60

    def __init__(self):
        self._lock = threading.Lock()
        self._fails: dict[str, list[float]] = {}

    def _prune(self, key: str, now: float) -> list[float]:
        fails = [t for t in self._fails.get(key, []) if t > now - self.WINDOW]
        if fails:
            self._fails[key] = fails
        else:
            self._fails.pop(key, None)
        return fails

    def retry_after(self, *keys: str) -> int:
        now = time.time()
        wait = 0.0
        with self._lock:
            for key in keys:
                fails = self._prune(key, now)
                extra = len(fails) - self.FREE_ATTEMPTS
                if extra >= 0:
                    lock = min(self.MAX_LOCK, 2 ** extra * 30)
                    wait = max(wait, fails[-1] + lock - now)
        return max(0, int(wait + 0.999))

    def fail(self, *keys: str):
        now = time.time()
        with self._lock:
            for key in keys:
                self._fails.setdefault(key, []).append(now)

    def clear(self, *keys: str):
        with self._lock:
            for key in keys:
                self._fails.pop(key, None)


throttle = _Throttle()


# ── Store ─────────────────────────────────────────────────────────────────────

def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


class UserStore:
    def __init__(self, path: Optional[Path] = None):
        self._path = path or _users_path()
        self._lock = threading.RLock()
        self._users: dict[str, dict] = {}       # lowercase username → record
        self._sessions: dict[str, dict] = {}    # token hash → {username, created, expires, persisted}
        self._mtime = 0.0
        self._load()

    # persistence
    def _load(self):
        try:
            if self._path.exists():
                self._mtime = self._path.stat().st_mtime
                data = json.loads(self._path.read_text())
                self._users = {u["username"].lower(): u for u in data.get("users", [])}
                now = time.time()
                self._sessions = {h: s for h, s in data.get("sessions", {}).items()
                                  if s.get("expires", 0) > now and s.get("username", "").lower() in self._users}
        except Exception as exc:
            log.error("Could not read %s: %s — starting with no accounts loaded", self._path, exc)

    def _save(self):
        payload = {"users": list(self._users.values()), "sessions": self._sessions}
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, indent=2))
        os.chmod(tmp, 0o600)
        tmp.replace(self._path)
        self._mtime = self._path.stat().st_mtime

    def _sync(self):
        """Pick up edits made outside this process (the recovery CLI) before
        reading or writing, so they're never overwritten."""
        try:
            m = self._path.stat().st_mtime if self._path.exists() else 0.0
        except OSError:
            return
        if m != self._mtime:
            self._users, self._sessions = {}, {}
            self._load()
            self._mtime = m

    # users
    @staticmethod
    def public(u: dict) -> dict:
        return {"username": u["username"], "role": u["role"], "created_at": u.get("created_at"),
                "last_login_at": u.get("last_login_at")}

    def setup_required(self) -> bool:
        with self._lock:
            self._sync()
            return not self._users

    def list(self) -> list[dict]:
        with self._lock:
            self._sync()
            return sorted((self.public(u) for u in self._users.values()), key=lambda u: u["username"].lower())

    def get(self, username: str) -> Optional[dict]:
        with self._lock:
            self._sync()
            u = self._users.get((username or "").lower())
            return self.public(u) if u else None

    def _admins(self) -> int:
        return sum(1 for u in self._users.values() if u["role"] == "admin")

    def create(self, username: str, password: str, role: str = "user") -> dict:
        username = validate_username(username)
        validate_password(password)
        if role not in ROLES:
            raise AuthError("Role must be admin or user")
        with self._lock:
            self._sync()
            if username.lower() in self._users:
                raise AuthError("That username is taken", 409)
            rec = {"username": username, "role": role, "password": hash_password(password),
                   "created_at": time.time(), "last_login_at": None}
            self._users[username.lower()] = rec
            self._save()
        log.info("Created %s account %s", role, username)
        return self.public(rec)

    def create_first_admin(self, username: str, password: str) -> dict:
        with self._lock:
            self._sync()
            if self._users:
                raise AuthError("Setup is already complete", 409)
            return self.create(username, password, "admin")

    def update(self, username: str, *, role: Optional[str] = None, password: Optional[str] = None,
               keep_session: Optional[str] = None) -> dict:
        with self._lock:
            self._sync()
            rec = self._users.get((username or "").lower())
            if not rec:
                raise AuthError("No such user", 404)
            if role is not None:
                if role not in ROLES:
                    raise AuthError("Role must be admin or user")
                if rec["role"] == "admin" and role != "admin" and self._admins() == 1:
                    raise AuthError("You can't demote the last admin")
                rec["role"] = role
            if password is not None:
                rec["password"] = hash_password(validate_password(password))
            self._revoke_user(rec["username"], keep=keep_session)
            self._save()
            return self.public(rec)

    def delete(self, username: str) -> None:
        with self._lock:
            self._sync()
            rec = self._users.get((username or "").lower())
            if not rec:
                raise AuthError("No such user", 404)
            if rec["role"] == "admin" and self._admins() == 1:
                raise AuthError("You can't delete the last admin")
            del self._users[username.lower()]
            self._revoke_user(rec["username"])
            self._save()
        log.info("Deleted account %s", username)

    # authentication
    def authenticate(self, username: str, password: str, client: str) -> dict:
        ukey, ckey = f"user:{(username or '').lower()}", f"ip:{client}"
        wait = throttle.retry_after(ukey, ckey)
        if wait:
            raise AuthError(f"Too many failed attempts — try again in {wait}s", 429)
        with self._lock:
            self._sync()
            rec = self._users.get((username or "").lower())
        ok = verify_password(password or "", rec["password"] if rec else _DUMMY_HASH)
        if not (rec and ok):
            throttle.fail(ukey, ckey)
            log.warning("Failed login for %r from %s", username, client)
            raise AuthError("Wrong username or password", 401)
        throttle.clear(ukey)
        with self._lock:
            self._sync()
            rec["last_login_at"] = time.time()
            self._save()
        return self.public(rec)

    # sessions
    def create_session(self, username: str) -> str:
        token = secrets.token_urlsafe(32)
        now = time.time()
        with self._lock:
            self._sync()
            self._sessions[_token_hash(token)] = {"username": username, "created": now,
                                                  "expires": now + SESSION_TTL, "persisted": now}
            self._save()
        return token

    def user_for_session(self, token: Optional[str]) -> Optional[dict]:
        if not token:
            return None
        h = _token_hash(token)
        now = time.time()
        with self._lock:
            self._sync()
            sess = self._sessions.get(h)
            if not sess:
                return None
            rec = self._users.get(sess["username"].lower())
            if not rec or sess["expires"] <= now:
                self._sessions.pop(h, None)
                self._save()
                return None
            sess["expires"] = now + SESSION_TTL
            if now - sess.get("persisted", 0) > SESSION_TOUCH_PERSIST:
                sess["persisted"] = now
                self._save()
            return self.public(rec)

    def end_session(self, token: Optional[str]):
        if not token:
            return
        with self._lock:
            self._sync()
            if self._sessions.pop(_token_hash(token), None):
                self._save()

    def _revoke_user(self, username: str, keep: Optional[str] = None):
        keep_h = _token_hash(keep) if keep else None
        for h in [h for h, s in self._sessions.items()
                  if s["username"].lower() == username.lower() and h != keep_h]:
            del self._sessions[h]


_store: Optional[UserStore] = None
_store_lock = threading.Lock()


def store() -> UserStore:
    global _store
    if _store is None:
        with _store_lock:
            if _store is None:
                _store = UserStore()
    return _store


# ── Route policy ──────────────────────────────────────────────────────────────
# Anything not matched below requires an admin (fail closed).

_PUBLIC = [
    ("GET",  r"/"),
    ("GET",  r"/health"),
    ("POST", r"/webhook/plex"),          # Plex can't log in; it only wakes the repair loop
    ("GET",  r"/api/auth/status"),
    ("POST", r"/api/auth/login"),
    ("POST", r"/api/auth/logout"),
    ("POST", r"/api/auth/setup"),
]

_USER = [
    # account
    ("POST", r"/api/auth/password"),
    # browse
    ("GET",  r"/api/cinemeta/.+"),
    ("GET",  r"/api/calendar"),
    ("GET",  r"/api/stubs"),
    ("GET",  r"/api/stubs/[^/]+"),
    ("GET",  r"/api/library/missing-counts"),
    ("GET",  r"/api/scan/[^/]+"),
    ("GET",  r"/api/series/[^/]+/episodes"),
    ("GET",  r"/api/series/[^/]+/season-watch"),
    ("GET",  r"/api/season-watch"),
    ("GET",  r"/api/pending-movies"),
    ("GET",  r"/api/wanted-seasons"),
    ("GET",  r"/api/quality-unavailable"),
    # request titles
    ("POST", r"/api/add"),
    ("POST", r"/api/series/[^/]+/episode/\d+/\d+"),
    ("POST", r"/api/series/[^/]+/season-watch"),
    ("GET",  r"/api/movies/[^/]+/releases"),   # browse what's out there (incl. unreleased titles)
    # stream a library file in the browser
    ("GET",  r"/proxy/[^/]+"),
    ("HEAD", r"/proxy/[^/]+"),
]

_PUBLIC_RE = [(m, re.compile(p + r"$")) for m, p in _PUBLIC]
_USER_RE = [(m, re.compile(p + r"$")) for m, p in _USER]


def required_role(method: str, path: str) -> str:
    """'public' | 'user' | 'admin' for a request."""
    method = "GET" if method == "HEAD" and not path.startswith("/proxy/") else method
    for m, rx in _PUBLIC_RE:
        if m == method and rx.match(path):
            return "public"
    for m, rx in _USER_RE:
        if m == method and rx.match(path):
            return "user"
    return "admin"


# ── Command line (account recovery) ───────────────────────────────────────────
#   docker exec -it aiogateway python -m gateway.auth list
#   docker exec -it aiogateway python -m gateway.auth reset-password <username>
#   docker exec -it aiogateway python -m gateway.auth create-admin <username>

def _cli(argv: list[str]) -> int:
    import getpass
    usage = "usage: python -m gateway.auth list | reset-password <username> | create-admin <username>"
    if not argv:
        print(usage)
        return 2
    st = UserStore()
    try:
        if argv[0] == "list":
            for u in st.list():
                print(f"{u['username']:32} {u['role']}")
            if st.setup_required():
                print("(no accounts — open the web UI to create the admin)")
            return 0
        if argv[0] in ("reset-password", "create-admin") and len(argv) == 2:
            pw = getpass.getpass("New password: ")
            if pw != getpass.getpass("Repeat: "):
                print("Passwords don't match")
                return 1
            if argv[0] == "reset-password":
                st.update(argv[1], password=pw)
                print(f"Password reset for {argv[1]}; their sessions were signed out.")
            else:
                st.create(argv[1], pw, "admin")
                print(f"Admin {argv[1]} created.")
            return 0
    except AuthError as exc:
        print(f"Error: {exc}")
        return 1
    print(usage)
    return 2


if __name__ == "__main__":
    import sys
    raise SystemExit(_cli(sys.argv[1:]))
