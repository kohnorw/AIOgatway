"""
gateway/auth.py
~~~~~~~~~~~~~~~~
Multi-user authentication via Plex's own login (Plex OAuth PIN flow) —
we never see or handle a password; Plex handles the actual credential
check entirely on their end, and hands us back a per-user Plex token
only after the person has approved the login on plex.tv itself.

Security model, spelled out explicitly since this is the part that
matters most:

- Session tokens are 256 bits of `secrets.token_urlsafe` randomness —
  not signed/derived from anything guessable, not JWTs (nothing to
  forge), just an opaque random key into a server-side session table.
  Stealing the cookie is the only way to steal the session; there is no
  way to compute or predict one.
- The cookie is httpOnly (invisible to any JS, including an XSS payload
  that manages to run on this origin), SameSite=Strict (never sent on
  a cross-site request, which covers the great majority of CSRF and
  session-riding attacks on its own), and Secure whenever the request
  actually arrived over HTTPS (checked per-request, including behind a
  reverse proxy via X-Forwarded-Proto — see cookie_secure_for_request).
- Every session is bound to a hash of the browser's User-Agent at
  login time. A request presenting a valid session token but a
  different UA hash is treated as a hijacked/replayed token and
  rejected — the session is destroyed, not just refused, so the real
  owner is forced to notice and re-login rather than the attacker
  quietly continuing to fail.
- Sessions carry a sliding expiry (SESSION_MAX_AGE_DAYS) and are
  re-issued (new token, old one destroyed) on login and on any
  privilege change (role edit) — so promoting/demoting a user can't
  leave a stale token with the old privilege level still valid anywhere.
- The raw Plex token for each user is stored server-side only (in the
  users file) — it is never sent to the browser in any API response,
  only used server-side to fetch the account's identity once at login.
- Plex PIN creation/polling is rate-limited per IP, since these
  endpoints proxy requests to plex.tv on the caller's behalf and
  shouldn't be usable as a free relay for hammering Plex's API.
- Server-membership check: after identifying the Plex account, we
  cross-check it against the actual Plex Media Server's own user list
  (via the admin-configured PLEX_URL/PLEX_TOKEN) rather than accepting
  any Plex.tv account on Earth. This specific check is the one part of
  this module I can't fully verify without a live Plex server to test
  against — it's built from Plex's documented endpoints, but if it
  ever misbehaves for your setup, PLEX_SERVER_CHECK below is the one
  place to relax it.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import secrets
import time
import uuid
from pathlib import Path
from typing import Optional

import aiohttp

logger = logging.getLogger("aiogateway.auth")

# ── Config ───────────────────────────────────────────────────────────────
SESSION_MAX_AGE_DAYS = float(os.environ.get("SESSION_MAX_AGE_DAYS", "30"))
SESSION_COOKIE_NAME = "aiogw_session"
# If false, any Plex.tv account can log in (still starts as role="user").
# If true (default), the logging-in Plex account must be either the
# owner of the configured Plex server or a user it's been shared with.
PLEX_SERVER_CHECK = os.environ.get("PLEX_SERVER_CHECK", "true").lower() != "false"

_PIN_RATE_LIMIT_PER_HOUR = 20
_pin_attempts: dict[str, list[float]] = {}   # ip -> [timestamps]


def _state_dir() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base


def _users_path() -> Path:
    return _state_dir() / "aiogateway_users.json"


def _sessions_path() -> Path:
    return _state_dir() / "aiogateway_sessions.json"


def _client_id_path() -> Path:
    return _state_dir() / "aiogateway_plex_client_id.json"


# ── Plex client identifier (persisted, stable per install) ──────────────
_client_id_cache: Optional[str] = None


def get_client_identifier() -> str:
    """A stable UUID identifying this aiogateway install to Plex — Plex
    requires a consistent clientIdentifier per app instance across the
    whole OAuth flow (PIN creation, polling, and the eventual token)."""
    global _client_id_cache
    if _client_id_cache:
        return _client_id_cache
    path = _client_id_path()
    try:
        if path.exists():
            _client_id_cache = json.loads(path.read_text())["client_id"]
            return _client_id_cache
    except Exception:
        pass
    new_id = str(uuid.uuid4())
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"client_id": new_id}))
    except Exception as exc:
        logger.warning("Could not persist Plex client identifier: %s", exc)
    _client_id_cache = new_id
    return new_id


# ── Users ─────────────────────────────────────────────────────────────
# plex_user_id (str) -> {plex_user_id, username, email, thumb, role,
#                         plex_token, created_at, last_login}
_users: dict[str, dict] = {}
_users_loaded = False


def _load_users() -> None:
    global _users, _users_loaded
    if _users_loaded:
        return
    path = _users_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text())
            _users = {u["plex_user_id"]: u for u in raw}
            logger.info("Loaded %d user(s) from %s", len(_users), path)
    except Exception as exc:
        logger.warning("Could not load users from %s: %s", path, exc)
        _users = {}
    _users_loaded = True


def _persist_users() -> None:
    path = _users_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        # Never let this hit a log/backup casually — still, keep the
        # actual file permissions tight where the OS allows it.
        path.write_text(json.dumps(list(_users.values()), indent=2))
        try:
            os.chmod(path, 0o600)
        except Exception:
            pass
    except Exception as exc:
        logger.warning("Could not persist users to %s: %s", path, exc)


def list_users() -> list[dict]:
    """Every user, WITHOUT their Plex token — this is what admin-facing
    API responses should return, never the raw dict with plex_token in it."""
    _load_users()
    return [
        {k: v for k, v in u.items() if k != "plex_token"}
        for u in _users.values()
    ]


def get_user(plex_user_id: str) -> Optional[dict]:
    _load_users()
    return _users.get(plex_user_id)


def set_role(plex_user_id: str, role: str) -> bool:
    _load_users()
    if role not in ("admin", "user"):
        raise ValueError("role must be 'admin' or 'user'")
    if plex_user_id not in _users:
        return False
    _users[plex_user_id]["role"] = role
    _persist_users()
    # Any live sessions for this user are rotated out — a role change
    # must not leave an old, differently-privileged session valid.
    _invalidate_sessions_for_user(plex_user_id)
    return True


def delete_user(plex_user_id: str) -> bool:
    _load_users()
    if plex_user_id not in _users:
        return False
    del _users[plex_user_id]
    _persist_users()
    _invalidate_sessions_for_user(plex_user_id)
    return True


def admin_count() -> int:
    _load_users()
    return sum(1 for u in _users.values() if u.get("role") == "admin")


def _upsert_user_from_plex(plex_id: str, username: str, email: str, thumb: str, plex_token: str) -> dict:
    _load_users()
    is_first_user_ever = len(_users) == 0
    now = time.time()
    if plex_id in _users:
        u = _users[plex_id]
        u["username"] = username
        u["email"] = email
        u["thumb"] = thumb
        u["plex_token"] = plex_token   # refresh — tokens can be reissued by Plex
        u["last_login"] = now
    else:
        u = {
            "plex_user_id": plex_id,
            "username": username,
            "email": email,
            "thumb": thumb,
            "plex_token": plex_token,
            # Bootstrapping: the very first person ever to log in becomes
            # admin, since there is no other way to get an admin account
            # started. Everyone after that starts as a plain user.
            "role": "admin" if is_first_user_ever else "user",
            "created_at": now,
            "last_login": now,
        }
        _users[plex_id] = u
    _persist_users()
    return u


# ── Sessions ─────────────────────────────────────────────────────────────
# session_token -> {plex_user_id, created_at, expires_at, ua_hash, ip}
_sessions: dict[str, dict] = {}
_sessions_loaded = False


def _load_sessions() -> None:
    global _sessions, _sessions_loaded
    if _sessions_loaded:
        return
    path = _sessions_path()
    try:
        if path.exists():
            _sessions = json.loads(path.read_text())
    except Exception as exc:
        logger.warning("Could not load sessions from %s: %s", path, exc)
        _sessions = {}
    _sessions_loaded = True


def _persist_sessions() -> None:
    path = _sessions_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(_sessions, indent=2))
        try:
            os.chmod(path, 0o600)
        except Exception:
            pass
    except Exception as exc:
        logger.warning("Could not persist sessions to %s: %s", path, exc)


def _ua_hash(user_agent: str) -> str:
    return hashlib.sha256((user_agent or "").encode()).hexdigest()[:32]


def create_session(plex_user_id: str, user_agent: str, ip: str) -> str:
    """Issues a brand new session token — 256 bits of randomness, no
    relation to anything guessable. Old sessions for this user are left
    alone here (multiple devices/browsers are expected); only a role
    change or explicit logout invalidates existing sessions."""
    _load_sessions()
    token = secrets.token_urlsafe(32)
    now = time.time()
    _sessions[token] = {
        "plex_user_id": plex_user_id,
        "created_at": now,
        "expires_at": now + SESSION_MAX_AGE_DAYS * 86400,
        "ua_hash": _ua_hash(user_agent),
        "ip": ip,
        "last_seen": now,
    }
    _persist_sessions()
    return token


def validate_session(token: Optional[str], user_agent: str) -> Optional[dict]:
    """Returns the user dict if the session is valid, else None. A
    mismatched User-Agent hash destroys the session outright rather than
    just refusing it — the token has clearly been used somewhere it
    wasn't issued for, which is exactly the hijack/replay scenario this
    is meant to catch."""
    if not token:
        return None
    _load_sessions()
    sess = _sessions.get(token)
    if not sess:
        return None
    now = time.time()
    if now > sess["expires_at"]:
        del _sessions[token]
        _persist_sessions()
        return None
    if sess["ua_hash"] != _ua_hash(user_agent):
        logger.warning("Session %s… used with a different User-Agent — destroying it", token[:8])
        del _sessions[token]
        _persist_sessions()
        return None

    user = get_user(sess["plex_user_id"])
    if not user:
        # User was deleted but a stray session survived somehow — kill it.
        del _sessions[token]
        _persist_sessions()
        return None

    # Sliding expiry: a session that's actually being used stays alive.
    sess["last_seen"] = now
    sess["expires_at"] = now + SESSION_MAX_AGE_DAYS * 86400
    return user


def destroy_session(token: str) -> None:
    _load_sessions()
    if token in _sessions:
        del _sessions[token]
        _persist_sessions()


def _invalidate_sessions_for_user(plex_user_id: str) -> None:
    _load_sessions()
    dead = [t for t, s in _sessions.items() if s.get("plex_user_id") == plex_user_id]
    for t in dead:
        del _sessions[t]
    if dead:
        _persist_sessions()


def cookie_secure_for_request(request) -> bool:
    """Whether to set the Secure cookie flag — true if this specific
    request actually arrived over HTTPS, including behind a reverse
    proxy that terminates TLS and forwards plain HTTP internally (the
    common case), checked via X-Forwarded-Proto. Getting this wrong in
    either direction is bad: Secure=True on a plain-HTTP LAN deployment
    means the cookie is silently never sent at all (dead login loop);
    Secure=False on a real HTTPS deployment needlessly weakens the
    cookie. Checked per-request rather than assumed once at startup."""
    if request.headers.get("x-forwarded-proto", "").lower() == "https":
        return True
    return request.url.scheme == "https"


# ── Plex OAuth PIN flow ───────────────────────────────────────────────────
_PLEX_PRODUCT = "AIOGateway"
_pins: dict[str, dict] = {}   # pin_id (str) -> {code, created_at}


def _rate_limit_ok(ip: str) -> bool:
    now = time.time()
    attempts = _pin_attempts.setdefault(ip, [])
    attempts[:] = [t for t in attempts if now - t < 3600]
    if len(attempts) >= _PIN_RATE_LIMIT_PER_HOUR:
        return False
    attempts.append(now)
    return True


async def start_plex_login(ip: str) -> dict:
    """Creates a Plex login PIN. Returns {pin_id, auth_url} — auth_url is
    what the browser should open (a real plex.tv page; Plex actively
    disallows embedding this in an iframe, so it has to be a popup or
    full navigation, not something we can render inline)."""
    if not _rate_limit_ok(ip):
        raise RuntimeError("Too many login attempts from this address — wait a bit and try again.")

    client_id = get_client_identifier()
    headers = {
        "X-Plex-Product": _PLEX_PRODUCT,
        "X-Plex-Client-Identifier": client_id,
        "Accept": "application/json",
    }
    async with aiohttp.ClientSession() as session:
        async with session.post(
            "https://plex.tv/api/v2/pins",
            params={"strong": "true"},
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            if resp.status != 201:
                raise RuntimeError(f"Plex rejected the login request (HTTP {resp.status})")
            data = await resp.json()

    pin_id = str(data["id"])
    code = data["code"]
    _pins[pin_id] = {"code": code, "created_at": time.time()}

    auth_url = (
        "https://app.plex.tv/auth#?"
        f"clientID={client_id}"
        f"&code={code}"
        f"&context%5Bdevice%5D%5Bproduct%5D={_PLEX_PRODUCT}"
    )
    return {"pin_id": pin_id, "auth_url": auth_url}


async def poll_plex_login(pin_id: str, user_agent: str, ip: str) -> Optional[dict]:
    """Checks whether the PIN has been claimed yet. Returns None while
    still waiting, or {session_token, user} once the person has approved
    the login on plex.tv and we've verified/created their local account."""
    if pin_id not in _pins:
        raise RuntimeError("Unknown or expired login attempt — start over.")

    client_id = get_client_identifier()
    headers = {
        "X-Plex-Client-Identifier": client_id,
        "Accept": "application/json",
    }
    async with aiohttp.ClientSession() as session:
        async with session.get(
            f"https://plex.tv/api/v2/pins/{pin_id}",
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            if resp.status != 200:
                return None
            data = await resp.json()

    auth_token = data.get("authToken")
    if not auth_token:
        return None   # not yet approved — caller keeps polling

    _pins.pop(pin_id, None)

    # Identify the account this token belongs to.
    async with aiohttp.ClientSession() as session:
        async with session.get(
            "https://plex.tv/api/v2/user",
            headers={
                "X-Plex-Token": auth_token,
                "X-Plex-Client-Identifier": client_id,
                "Accept": "application/json",
            },
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            if resp.status != 200:
                raise RuntimeError("Could not verify the Plex account after login.")
            account = await resp.json()

    plex_id = str(account.get("id"))
    username = account.get("username") or account.get("title") or account.get("email") or plex_id
    email = account.get("email", "")
    thumb = account.get("thumb", "")

    if PLEX_SERVER_CHECK and not await _account_has_server_access(plex_id, auth_token):
        raise RuntimeError(
            "This Plex account doesn't have access to the configured Plex server "
            "— ask the server owner to share it with you, or check PLEX_SERVER_CHECK."
        )

    user = _upsert_user_from_plex(plex_id, username, email, thumb, auth_token)
    token = create_session(plex_id, user_agent, ip)
    logger.info("Plex login: %s (%s) — role=%s", username, plex_id, user["role"])
    return {"session_token": token, "user": {k: v for k, v in user.items() if k != "plex_token"}}


async def _account_has_server_access(plex_id: str, logging_in_token: str) -> bool:
    """
    Cross-checks the logging-in Plex account against the actual Plex
    Media Server's own user list — via the admin-configured PLEX_URL/
    PLEX_TOKEN — rather than accepting any Plex.tv account. Two ways to
    pass: being the server owner (comparing against the admin token's
    own account), or being one of the server's shared users.

    This is the one part of this module built without a live Plex
    server to verify the exact response shape against — the endpoints
    used here are Plex's documented ones, but if this check ever
    misbehaves for a real setup, set PLEX_SERVER_CHECK=false to bypass
    it (logins still work, just without this extra allowlist).
    """
    plex_url = os.environ.get("PLEX_URL", "")
    plex_token = os.environ.get("PLEX_TOKEN", "")
    if not plex_url or not plex_token:
        logger.warning(
            "PLEX_SERVER_CHECK is on but PLEX_URL/PLEX_TOKEN aren't configured — "
            "cannot verify server membership, allowing login through. Set "
            "PLEX_URL/PLEX_TOKEN or PLEX_SERVER_CHECK=false to silence this."
        )
        return True

    client_id = get_client_identifier()
    try:
        # Is this the server owner? (their token's own account)
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "https://plex.tv/api/v2/user",
                headers={
                    "X-Plex-Token": plex_token,
                    "X-Plex-Client-Identifier": client_id,
                    "Accept": "application/json",
                },
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                if resp.status == 200:
                    owner = await resp.json()
                    if str(owner.get("id")) == plex_id:
                        return True

        # Otherwise, check the server's own shared-users list.
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{plex_url}/accounts",
                headers={"X-Plex-Token": plex_token, "Accept": "application/json"},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                if resp.status != 200:
                    return False
                data = await resp.json(content_type=None)
        accounts = (
            data.get("MediaContainer", {}).get("Account", [])
            if isinstance(data, dict) else []
        )
        for acc in accounts:
            if str(acc.get("id")) == plex_id or str(acc.get("key")) == plex_id:
                return True
        return False
    except Exception as exc:
        logger.warning("Could not verify Plex server membership for %s: %s", plex_id, exc)
        return False
