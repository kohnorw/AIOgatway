"""
gateway/auth.py
~~~~~~~~~~~~~~~
Sign-in through Plex's own PIN flow. AIOGateway never sees a password —
Plex checks the credentials and hands back a token only after the person
has approved the sign-in on plex.tv.

Session handling, since this is the part worth being explicit about:

  - Session tokens are 256 bits from `secrets.token_urlsafe`. They are
    opaque keys into a server-side table, not signed or derived from
    anything, so there is nothing to forge or predict. Stealing the
    cookie is the only way to take a session.
  - The cookie is httpOnly, SameSite=Strict, and Secure whenever the
    request arrived over HTTPS — checked per request, including behind a
    reverse proxy via X-Forwarded-Proto.
  - Each session is bound to a hash of the browser's User-Agent. A valid
    token presented with a different agent is destroyed rather than
    merely refused, so the real owner is forced to notice.
  - Sessions are reissued on sign-in and on any role change, so
    promoting or demoting someone can't leave a token carrying the old
    privileges alive somewhere.
  - The per-user Plex token stays server-side. It is never included in
    an API response.
  - PIN creation and polling are rate-limited per IP, because those
    endpoints relay to plex.tv and shouldn't be usable as a free relay.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import secrets
import threading
import time
import uuid as uuid_lib
from typing import Optional

import aiohttp

from . import plex, settings
from .paths import client_id_file, sessions_file, users_file

logger = logging.getLogger("aiogateway.auth")

SESSION_COOKIE = "aiogw_session"
SESSION_MAX_AGE_DAYS = 30
PIN_RATE_LIMIT_PER_HOUR = 20

_lock = threading.RLock()
_users: dict[str, dict] = {}
_sessions: dict[str, dict] = {}
_loaded = False
_pin_attempts: dict[str, list[float]] = {}
_client_id: Optional[str] = None

PRODUCT = "AIOGateway"


# ── stable client identifier ────────────────────────────────────────────
def client_identifier() -> str:
    """Plex requires one consistent identifier per app install across the
    whole PIN flow."""
    global _client_id
    if _client_id:
        return _client_id
    path = client_id_file()
    try:
        if path.exists():
            _client_id = json.loads(path.read_text())["client_id"]
            return _client_id
    except Exception:
        pass
    _client_id = str(uuid_lib.uuid4())
    try:
        path.write_text(json.dumps({"client_id": _client_id}))
    except Exception as exc:
        logger.warning("Could not persist the Plex client identifier: %s", exc)
    return _client_id


def _plex_headers() -> dict:
    return {
        "Accept": "application/json",
        "X-Plex-Product": PRODUCT,
        "X-Plex-Version": "2.0",
        "X-Plex-Client-Identifier": client_identifier(),
        "X-Plex-Device": "AIOGateway",
        "X-Plex-Platform": "Web",
    }


# ── storage ─────────────────────────────────────────────────────────────
def load() -> None:
    global _loaded
    with _lock:
        if _loaded:
            return
        for path, target in ((users_file(), _users), (sessions_file(), _sessions)):
            if path.exists():
                try:
                    target.update(json.loads(path.read_text()))
                except Exception as exc:
                    logger.error("%s unreadable (%s)", path.name, exc)
        _loaded = True
    _prune_sessions()


def _write(path, payload: dict) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, indent=2))
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _persist_users() -> None:
    _write(users_file(), _users)


def _persist_sessions() -> None:
    _write(sessions_file(), _sessions)


def _prune_sessions() -> None:
    cutoff = time.time() - SESSION_MAX_AGE_DAYS * 86400
    with _lock:
        stale = [t for t, s in _sessions.items() if s.get("last_seen", 0) < cutoff]
        for token in stale:
            _sessions.pop(token, None)
        if stale:
            _persist_sessions()


# ── users ───────────────────────────────────────────────────────────────
def _public_user(user: dict) -> dict:
    """Never includes plex_token."""
    return {
        "plex_user_id": user["plex_user_id"],
        "username": user.get("username", ""),
        "email": user.get("email", ""),
        "thumb": user.get("thumb", ""),
        "role": user.get("role", "user"),
        "created_at": user.get("created_at"),
        "last_login_at": user.get("last_login_at"),
    }


def list_users(page: int = 1, page_size: Optional[int] = None,
               query: str = "") -> dict:
    """Paginated, because a shared server can easily have more accounts
    than fit comfortably on a page."""
    load()
    size = int(page_size or settings.get("users_page_size", 25) or 25)
    size = max(1, min(size, 200))

    with _lock:
        rows = [_public_user(u) for u in _users.values()]

    needle = (query or "").strip().lower()
    if needle:
        rows = [r for r in rows
                if needle in r["username"].lower() or needle in r["email"].lower()]

    # Admins first, then oldest account first, so the list is stable as
    # people sign in rather than reshuffling on every load.
    rows.sort(key=lambda r: (r["role"] != "admin", r.get("created_at") or 0))

    total = len(rows)
    pages = max(1, (total + size - 1) // size)
    page = max(1, min(int(page or 1), pages))
    start = (page - 1) * size
    return {
        "users": rows[start:start + size],
        "page": page,
        "page_size": size,
        "pages": pages,
        "total": total,
        "admin_count": sum(1 for r in rows if r["role"] == "admin"),
    }


def get_user(plex_user_id: str) -> Optional[dict]:
    load()
    with _lock:
        user = _users.get(str(plex_user_id))
        return _public_user(user) if user else None


def admin_count() -> int:
    load()
    with _lock:
        return sum(1 for u in _users.values() if u.get("role") == "admin")


def set_role(plex_user_id: str, role: str) -> bool:
    if role not in ("admin", "user"):
        raise ValueError("role must be admin or user")
    load()
    with _lock:
        user = _users.get(str(plex_user_id))
        if not user:
            return False
        # Refuse to remove the last admin — there would be no way back
        # into the Config page afterwards.
        if user.get("role") == "admin" and role == "user":
            if sum(1 for u in _users.values() if u.get("role") == "admin") <= 1:
                raise ValueError("This is the only admin — promote someone else first")
        user["role"] = role
        _persist_users()
    _invalidate_user_sessions(plex_user_id)
    return True


def delete_user(plex_user_id: str) -> bool:
    load()
    with _lock:
        user = _users.get(str(plex_user_id))
        if not user:
            return False
        if user.get("role") == "admin":
            if sum(1 for u in _users.values() if u.get("role") == "admin") <= 1:
                raise ValueError("This is the only admin — promote someone else first")
        _users.pop(str(plex_user_id))
        _persist_users()
    _invalidate_user_sessions(plex_user_id)
    return True


def _upsert_user(plex_id: str, username: str, email: str,
                 thumb: str, plex_token: str) -> dict:
    with _lock:
        user = _users.get(str(plex_id))
        if user is None:
            # The first person to sign in becomes admin, because
            # otherwise nobody could ever reach the Config page to
            # promote anyone.
            first = not _users
            user = {
                "plex_user_id": str(plex_id),
                "role": "admin" if first else "user",
                "created_at": time.time(),
            }
            _users[str(plex_id)] = user
            logger.info("New account %s (%s)", username, user["role"])
        user.update({
            "username": username, "email": email, "thumb": thumb,
            "plex_token": plex_token, "last_login_at": time.time(),
        })
        _persist_users()
        return dict(user)


# ── sessions ────────────────────────────────────────────────────────────
def _agent_hash(user_agent: str) -> str:
    return hashlib.sha256((user_agent or "").encode()).hexdigest()[:32]


def create_session(plex_user_id: str, user_agent: str, ip: str) -> str:
    load()
    token = secrets.token_urlsafe(32)
    with _lock:
        # Drop this account's other sessions on sign-in, so a fresh login
        # can't leave an older token alive with different privileges.
        for old in [t for t, s in _sessions.items()
                    if s.get("plex_user_id") == str(plex_user_id)]:
            _sessions.pop(old, None)
        _sessions[token] = {
            "plex_user_id": str(plex_user_id),
            "agent": _agent_hash(user_agent),
            "ip": ip,
            "created_at": time.time(),
            "last_seen": time.time(),
        }
        _persist_sessions()
    return token


def validate_session(token: Optional[str], user_agent: str) -> Optional[dict]:
    if not token:
        return None
    load()
    with _lock:
        session = _sessions.get(token)
        if session is None:
            return None
        if time.time() - session.get("last_seen", 0) > SESSION_MAX_AGE_DAYS * 86400:
            _sessions.pop(token, None)
            _persist_sessions()
            return None
        if session.get("agent") != _agent_hash(user_agent):
            # Destroyed rather than refused: a token being replayed from
            # a different browser is a compromised token, and the owner
            # should be made to sign in again.
            logger.warning("Session for %s presented from a different browser — destroyed",
                           session.get("plex_user_id"))
            _sessions.pop(token, None)
            _persist_sessions()
            return None

        user = _users.get(session["plex_user_id"])
        if user is None:
            _sessions.pop(token, None)
            _persist_sessions()
            return None

        # Sliding expiry, persisted at most once a minute — writing the
        # session file on every request would be a lot of disk churn for
        # a timestamp nobody reads that precisely.
        now = time.time()
        if now - session.get("last_seen", 0) > 60:
            session["last_seen"] = now
            _persist_sessions()
        return _public_user(user)


def destroy_session(token: Optional[str]) -> None:
    if not token:
        return
    load()
    with _lock:
        if _sessions.pop(token, None) is not None:
            _persist_sessions()


def _invalidate_user_sessions(plex_user_id: str) -> None:
    with _lock:
        gone = [t for t, s in _sessions.items()
                if s.get("plex_user_id") == str(plex_user_id)]
        for token in gone:
            _sessions.pop(token, None)
        if gone:
            _persist_sessions()


def cookie_is_secure(request) -> bool:
    """Set Secure only when the request really arrived over HTTPS —
    marking it Secure on a plain-HTTP LAN setup means the browser
    silently drops the cookie and nobody can sign in."""
    forwarded = request.headers.get("x-forwarded-proto", "")
    if forwarded:
        return forwarded.split(",")[0].strip().lower() == "https"
    return request.url.scheme == "https"


# ── Plex PIN flow ───────────────────────────────────────────────────────
def _rate_limit_ok(ip: str) -> bool:
    now = time.time()
    with _lock:
        attempts = [t for t in _pin_attempts.get(ip, []) if now - t < 3600]
        if len(attempts) >= PIN_RATE_LIMIT_PER_HOUR:
            _pin_attempts[ip] = attempts
            return False
        attempts.append(now)
        _pin_attempts[ip] = attempts
    return True


async def start_login(ip: str) -> dict:
    if not _rate_limit_ok(ip):
        raise PermissionError("Too many sign-in attempts — wait an hour")

    async with aiohttp.ClientSession() as session:
        async with session.post(
            "https://plex.tv/api/v2/pins",
            headers=_plex_headers(), data={"strong": "true"},
            timeout=aiohttp.ClientTimeout(total=20),
        ) as resp:
            if resp.status >= 400:
                raise RuntimeError(f"Plex returned HTTP {resp.status} creating a sign-in code")
            data = await resp.json(content_type=None)

    code = data.get("code")
    auth_url = (
        "https://app.plex.tv/auth#?"
        f"clientID={client_identifier()}"
        f"&code={code}"
        f"&context%5Bdevice%5D%5Bproduct%5D={PRODUCT}"
    )
    return {"pin_id": data.get("id"), "code": code, "auth_url": auth_url}


async def poll_login(pin_id: str, user_agent: str, ip: str) -> Optional[dict]:
    """Returns None while the person hasn't finished signing in yet."""
    if not _rate_limit_ok(ip):
        raise PermissionError("Too many sign-in attempts — wait an hour")

    async with aiohttp.ClientSession() as session:
        async with session.get(
            f"https://plex.tv/api/v2/pins/{pin_id}",
            headers=_plex_headers(),
            timeout=aiohttp.ClientTimeout(total=20),
        ) as resp:
            if resp.status >= 400:
                raise RuntimeError("That sign-in code expired — start again")
            pin = await resp.json(content_type=None)

        token = pin.get("authToken")
        if not token:
            return None

        async with session.get(
            "https://plex.tv/api/v2/user",
            headers={**_plex_headers(), "X-Plex-Token": token},
            timeout=aiohttp.ClientTimeout(total=20),
        ) as resp:
            if resp.status >= 400:
                raise RuntimeError("Plex accepted the sign-in but wouldn't identify the account")
            account = await resp.json(content_type=None)

    plex_id = str(account.get("id"))
    load()

    # Existing accounts skip the membership check: they were verified
    # when they were first added, and re-checking on every sign-in would
    # lock everyone out during a plex.tv outage.
    known = bool(_users.get(plex_id))
    if not known and not await plex.account_has_access(plex_id):
        raise PermissionError(
            "That Plex account doesn't have access to this server. Ask the "
            "owner to share the library with you first."
        )

    user = _upsert_user(
        plex_id,
        account.get("username") or account.get("title") or "Plex user",
        account.get("email", ""),
        account.get("thumb", ""),
        token,
    )
    session_token = create_session(plex_id, user_agent, ip)
    return {"session_token": session_token, "user": _public_user(user)}
