"""
gateway/auth.py
~~~~~~~~~~~~~~~
Web UI accounts, backed by Plex sign-in (see gateway/plex_auth.py).

Who can sign in
  - The owner of the Plex server at PLEX_URL — always an admin.
  - Anyone that server is shared with (friends, Plex Home users) — a regular
    user by default; an admin can promote them or block them.
  - Nobody else.

Access is re-checked with Plex every VERIFY_INTERVAL while someone is signed
in. If the server is unshared with them, their sessions end. If plex.tv is
unreachable the existing session is kept (so a Plex outage doesn't lock
everyone out) and the check is retried later.

Sessions are random 256-bit tokens in an HttpOnly cookie; only a SHA-256 of
each is stored. A person's Plex token is stored (file mode 0600) solely to
re-check their server access — it is never sent to the browser.

Accounts live in aiogateway_users.json next to the settings file.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import secrets
import threading
import time
from pathlib import Path
from typing import Optional

from . import plex_auth

log = logging.getLogger("aiogateway.auth")

ROLES = ("admin", "user")
SESSION_TTL = 30 * 86400
SESSION_TOUCH_PERSIST = 600
VERIFY_INTERVAL = 6 * 3600
PIN_TTL = 10 * 60
COOKIE_NAME = "aiog_session"
PIN_COOKIE = "aiog_pin"


class AuthError(Exception):
    def __init__(self, message: str, status: int = 400, code: str = "error"):
        super().__init__(message)
        self.status = status
        self.code = code


def _users_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_users.json"


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


# ── Sign-in attempt throttling (per client IP) ────────────────────────────────

class _RateWindow:
    def __init__(self, limit: int, window: float):
        self.limit, self.window = limit, window
        self._lock = threading.Lock()
        self._hits: dict[str, list[float]] = {}

    def allow(self, key: str) -> bool:
        now = time.time()
        with self._lock:
            hits = [t for t in self._hits.get(key, []) if t > now - self.window]
            if len(hits) >= self.limit:
                self._hits[key] = hits
                return False
            hits.append(now)
            self._hits[key] = hits
            return True

    def clear(self):
        with self._lock:
            self._hits.clear()


pin_rate = _RateWindow(limit=20, window=600)


# ── Store ─────────────────────────────────────────────────────────────────────

class UserStore:
    def __init__(self, path: Optional[Path] = None):
        self._path = path or _users_path()
        self._lock = threading.RLock()
        self.client_id = ""
        self._users: dict[str, dict] = {}       # plex_id → record
        self._sessions: dict[str, dict] = {}    # token hash → {plex_id, created, expires, persisted}
        self._pins: dict[str, dict] = {}        # browser nonce hash → {pin_id, created}   (memory only)
        self._verifying: set = set()
        self._mtime = 0.0
        self._load()
        if not self.client_id:
            with self._lock:
                self.client_id = secrets.token_hex(16)
                self._save()

    # persistence -------------------------------------------------------------
    def _load(self):
        try:
            if not self._path.exists():
                return
            self._mtime = self._path.stat().st_mtime
            data = json.loads(self._path.read_text())
            if data.get("version") != 2:
                # Local username/password accounts from before Plex sign-in.
                log.warning("Discarding old local accounts in %s — sign in with Plex instead", self._path)
                self._users, self._sessions = {}, {}
                return
            self.client_id = data.get("client_id") or ""
            self._users = {u["plex_id"]: u for u in data.get("users", [])}
            now = time.time()
            self._sessions = {h: s for h, s in data.get("sessions", {}).items()
                              if s.get("expires", 0) > now and s.get("plex_id") in self._users}
        except Exception as exc:
            log.error("Could not read %s: %s", self._path, exc)

    def _save(self):
        payload = {"version": 2, "client_id": self.client_id,
                   "users": list(self._users.values()), "sessions": self._sessions}
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, indent=2))
        os.chmod(tmp, 0o600)
        tmp.replace(self._path)
        self._mtime = self._path.stat().st_mtime

    def _sync(self):
        """Pick up edits made outside this process (the CLI) before reading or
        writing, so they're never overwritten."""
        try:
            m = self._path.stat().st_mtime if self._path.exists() else 0.0
        except OSError:
            return
        if m != self._mtime:
            self._users, self._sessions = {}, {}
            self._load()
            self._mtime = m

    # views -----------------------------------------------------------------------
    @staticmethod
    def public(u: dict) -> dict:
        return {"plex_id": u["plex_id"], "username": u["username"], "email": u.get("email", ""),
                "thumb": u.get("thumb", ""), "role": u["role"], "owner": bool(u.get("owner")),
                "disabled": bool(u.get("disabled")), "created_at": u.get("created_at"),
                "last_login_at": u.get("last_login_at")}

    def list(self) -> list[dict]:
        with self._lock:
            self._sync()
            return sorted((self.public(u) for u in self._users.values()),
                          key=lambda u: (not u["owner"], u["role"] != "admin", u["username"].lower()))

    def get(self, plex_id: str) -> Optional[dict]:
        with self._lock:
            self._sync()
            u = self._users.get(str(plex_id))
            return self.public(u) if u else None

    def find(self, name_or_id: str) -> Optional[dict]:
        with self._lock:
            self._sync()
            key = (name_or_id or "").lower()
            for u in self._users.values():
                if u["plex_id"] == name_or_id or u["username"].lower() == key or (u.get("email") or "").lower() == key:
                    return self.public(u)
        return None

    # sign-in ---------------------------------------------------------------------
    def start_signin(self, client_ip: str) -> tuple[str, dict]:
        """Returns (browser nonce, {auth_url}). The nonce goes in a cookie so
        only the browser that started this sign-in can finish it."""
        if not pin_rate.allow(client_ip):
            raise AuthError("Too many sign-in attempts — wait a few minutes", 429, "rate_limited")
        try:
            plex_auth.server_id()          # fail early and clearly if PLEX_URL is wrong
            pin = plex_auth.create_pin(self.client_id)
        except plex_auth.PlexAuthError as exc:
            raise AuthError(str(exc), exc.status, exc.code) from exc
        nonce = secrets.token_urlsafe(24)
        now = time.time()
        with self._lock:
            self._pins = {k: v for k, v in self._pins.items() if v["created"] > now - PIN_TTL}
            self._pins[_token_hash(nonce)] = {"pin_id": pin["id"], "created": now}
        return nonce, {"auth_url": pin["auth_url"], "expires_in": PIN_TTL}

    def finish_signin(self, nonce: Optional[str]) -> Optional[tuple[dict, str]]:
        """None while the person hasn't approved yet; (user, session token) once
        they have and they're allowed in."""
        if not nonce:
            raise AuthError("No sign-in in progress — start again", 400, "no_signin")
        key = _token_hash(nonce)
        with self._lock:
            pending = self._pins.get(key)
        if not pending or pending["created"] < time.time() - PIN_TTL:
            raise AuthError("This sign-in attempt expired — start again", 410, "pin_expired")
        try:
            token = plex_auth.check_pin(self.client_id, pending["pin_id"])
        except plex_auth.PlexAuthError as exc:
            raise AuthError(str(exc), exc.status, exc.code) from exc
        if not token:
            return None
        with self._lock:
            self._pins.pop(key, None)

        try:
            acct = plex_auth.account(self.client_id, token)
            access = plex_auth.server_access(self.client_id, token)
        except plex_auth.PlexAuthError as exc:
            raise AuthError(str(exc), exc.status, exc.code) from exc
        if not access:
            log.warning("Plex account %s (%s) has no access to this server", acct["username"], acct["plex_id"])
            raise AuthError("Your Plex account doesn't have access to this Plex server. "
                            "Ask the server owner to share it with you.", 403, "no_server_access")

        now = time.time()
        with self._lock:
            self._sync()
            rec = self._users.get(acct["plex_id"])
            if rec and rec.get("disabled") and not access["owned"]:
                raise AuthError("Your access to this app has been turned off by an admin.", 403, "disabled")
            if not rec:
                rec = {"plex_id": acct["plex_id"], "role": "user", "created_at": now}
                self._users[acct["plex_id"]] = rec
                log.info("New Plex user %s (%s)", acct["username"], "owner" if access["owned"] else "shared")
            rec.update(username=acct["username"], email=acct["email"], thumb=acct["thumb"],
                       owner=access["owned"], plex_token=token, verified_at=now, last_login_at=now)
            if access["owned"]:
                rec["role"], rec["disabled"] = "admin", False
            session = self._new_session(rec["plex_id"])
            self._save()
            return self.public(rec), session

    # sessions --------------------------------------------------------------------
    def _new_session(self, plex_id: str) -> str:
        token = secrets.token_urlsafe(32)
        now = time.time()
        self._sessions[_token_hash(token)] = {"plex_id": plex_id, "created": now,
                                              "expires": now + SESSION_TTL, "persisted": now}
        return token

    def create_session(self, plex_id: str) -> str:
        with self._lock:
            self._sync()
            if plex_id not in self._users:
                raise AuthError("No such user", 404)
            token = self._new_session(plex_id)
            self._save()
            return token

    def user_for_session(self, token: Optional[str]) -> Optional[dict]:
        if not token:
            return None
        h = _token_hash(token)
        now = time.time()
        with self._lock:
            self._sync()
            sess = self._sessions.get(h)
            if not sess:
                return None
            rec = self._users.get(sess["plex_id"])
            if not rec or sess["expires"] <= now or (rec.get("disabled") and not rec.get("owner")):
                self._sessions.pop(h, None)
                self._save()
                return None
            sess["expires"] = now + SESSION_TTL
            if now - sess.get("persisted", 0) > SESSION_TOUCH_PERSIST:
                sess["persisted"] = now
                self._save()
            needs_verify = (now - rec.get("verified_at", 0) > VERIFY_INTERVAL
                            and rec["plex_id"] not in self._verifying)
            user = self.public(rec)
        if needs_verify and not self.reverify(user["plex_id"]):
            return None
        return self.get(user["plex_id"]) if needs_verify else user

    def reverify(self, plex_id: str) -> bool:
        """Re-check someone's Plex server access. False = access gone (their
        sessions are ended). Plex outages keep the session (True)."""
        with self._lock:
            rec = self._users.get(plex_id)
            if not rec or not rec.get("plex_token"):
                return bool(rec)
            self._verifying.add(plex_id)
            token, name = rec["plex_token"], rec["username"]
        try:
            access = plex_auth.server_access(self.client_id, token)
        except plex_auth.PlexAuthError as exc:
            if exc.code != "plex_token_invalid":
                log.info("Couldn't re-check Plex access for %s (%s) — keeping the session", name, exc)
                with self._lock:
                    self._verifying.discard(plex_id)
                return True
            access = None
        with self._lock:
            self._verifying.discard(plex_id)
            rec = self._users.get(plex_id)
            if not rec:
                return False
            if not access:
                log.warning("%s no longer has access to the Plex server — signing them out", rec["username"])
                self._revoke(plex_id)
                rec["plex_token"] = ""
                self._save()
                return False
            rec["verified_at"] = time.time()
            rec["owner"] = access["owned"]
            if access["owned"]:
                rec["role"] = "admin"
            self._save()
            return True

    def end_session(self, token: Optional[str]):
        if not token:
            return
        with self._lock:
            self._sync()
            if self._sessions.pop(_token_hash(token), None):
                self._save()

    def _revoke(self, plex_id: str):
        for h in [h for h, s in self._sessions.items() if s["plex_id"] == plex_id]:
            del self._sessions[h]

    # admin actions -----------------------------------------------------------------
    def update(self, plex_id: str, *, role: Optional[str] = None, disabled: Optional[bool] = None) -> dict:
        with self._lock:
            self._sync()
            rec = self._users.get(str(plex_id))
            if not rec:
                raise AuthError("No such user", 404)
            if rec.get("owner") and ((role is not None and role != "admin") or disabled):
                raise AuthError("The Plex server owner is always an admin")
            changed = False
            if role is not None:
                if role not in ROLES:
                    raise AuthError("Role must be admin or user")
                changed |= rec["role"] != role
                rec["role"] = role
            if disabled is not None:
                changed |= bool(rec.get("disabled")) != bool(disabled)
                rec["disabled"] = bool(disabled)
            if changed:
                self._revoke(rec["plex_id"])
            self._save()
            return self.public(rec)

    def forget(self, plex_id: str) -> None:
        """Remove someone's record (and sign them out). If they still have
        Plex access they can sign in again as a regular user — use disable to
        keep them out."""
        with self._lock:
            self._sync()
            rec = self._users.get(str(plex_id))
            if not rec:
                raise AuthError("No such user", 404)
            if rec.get("owner"):
                raise AuthError("The Plex server owner can't be removed")
            self._revoke(rec["plex_id"])
            del self._users[rec["plex_id"]]
            self._save()

    def signout_all(self):
        with self._lock:
            self._sync()
            self._sessions.clear()
            self._save()


_store: Optional[UserStore] = None
_store_lock = threading.Lock()


def store() -> UserStore:
    global _store
    if _store is None:
        with _store_lock:
            if _store is None:
                _store = UserStore()
    return _store


# ── Route policy ──────────────────────────────────────────────────────────────
# Anything not matched below requires an admin (fail closed).

_PUBLIC = [
    ("GET",  r"/"),
    ("GET",  r"/health"),
    ("POST", r"/webhook/plex"),          # Plex can't sign in; it only wakes the repair loop
    ("GET",  r"/api/auth/status"),
    ("POST", r"/api/auth/plex/start"),
    ("POST", r"/api/auth/plex/finish"),
    ("POST", r"/api/auth/logout"),
]

_USER = [
    # browse
    ("GET",  r"/api/cinemeta/.+"),
    ("GET",  r"/api/calendar"),
    ("GET",  r"/api/stubs"),
    ("GET",  r"/api/stubs/[^/]+"),
    ("GET",  r"/api/library/missing-counts"),
    ("GET",  r"/api/scan/[^/]+"),
    ("GET",  r"/api/series/[^/]+/episodes"),
    ("GET",  r"/api/series/[^/]+/season-watch"),
    ("GET",  r"/api/season-watch"),
    ("GET",  r"/api/pending-movies"),
    ("GET",  r"/api/wanted-seasons"),
    ("GET",  r"/api/quality-unavailable"),
    # request titles
    ("POST", r"/api/add"),
    ("POST", r"/api/series/[^/]+/episode/\d+/\d+"),
    ("POST", r"/api/series/[^/]+/season-watch"),
    ("GET",  r"/api/movies/[^/]+/releases"),
    # stream a library file in the browser
    ("GET",  r"/proxy/[^/]+"),
    ("HEAD", r"/proxy/[^/]+"),
]

_PUBLIC_RE = [(m, re.compile(p + r"$")) for m, p in _PUBLIC]
_USER_RE = [(m, re.compile(p + r"$")) for m, p in _USER]


def required_role(method: str, path: str) -> str:
    """'public' | 'user' | 'admin' for a request."""
    method = "GET" if method == "HEAD" and not path.startswith("/proxy/") else method
    for m, rx in _PUBLIC_RE:
        if m == method and rx.match(path):
            return "public"
    for m, rx in _USER_RE:
        if m == method and rx.match(path):
            return "user"
    return "admin"


# ── Command line ──────────────────────────────────────────────────────────────
#   docker exec -it aiogateway python -m gateway.auth list
#   docker exec -it aiogateway python -m gateway.auth set-role <username|email> admin|user
#   docker exec -it aiogateway python -m gateway.auth enable <username|email>
#   docker exec -it aiogateway python -m gateway.auth signout-all

def _cli(argv: list[str]) -> int:
    usage = "usage: python -m gateway.auth list | set-role <user> admin|user | enable <user> | signout-all"
    st = UserStore()
    try:
        if argv[:1] == ["list"]:
            users = st.list()
            for u in users:
                flags = " ".join(f for f in ("owner" if u["owner"] else "", "disabled" if u["disabled"] else "") if f)
                print(f"{u['username']:28} {u['email']:32} {u['role']:6} {flags}")
            if not users:
                print("(nobody has signed in yet — the Plex server owner should sign in first)")
            return 0
        if argv[:1] == ["set-role"] and len(argv) == 3:
            u = st.find(argv[1])
            if not u:
                print(f"No user {argv[1]!r} (they must sign in with Plex once first)")
                return 1
            st.update(u["plex_id"], role=argv[2])
            print(f"{u['username']} is now {argv[2]}.")
            return 0
        if argv[:1] == ["enable"] and len(argv) == 2:
            u = st.find(argv[1])
            if not u:
                print(f"No user {argv[1]!r}")
                return 1
            st.update(u["plex_id"], disabled=False)
            print(f"{u['username']} can sign in again.")
            return 0
        if argv[:1] == ["signout-all"]:
            st.signout_all()
            print("Everyone has been signed out.")
            return 0
    except AuthError as exc:
        print(f"Error: {exc}")
        return 1
    print(usage)
    return 2


if __name__ == "__main__":
    import sys
    raise SystemExit(_cli(sys.argv[1:]))
