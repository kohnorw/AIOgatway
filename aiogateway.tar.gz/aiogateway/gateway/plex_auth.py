"""
gateway/plex_auth.py
~~~~~~~~~~~~~~~~~~~~
Sign in with Plex (the PIN flow used by Overseerr, Tautulli, etc.):

  1. POST plex.tv/api/v2/pins?strong=true            → {id, code}
  2. The browser opens app.plex.tv/auth#?clientID=…&code=… where the person
     signs in to Plex (their password never touches this app).
  3. Poll GET plex.tv/api/v2/pins/{id}               → authToken once approved
  4. GET plex.tv/api/v2/user   (their token)         → id, username, email, avatar
  5. GET plex.tv/api/v2/resources (their token)      → is OUR server in their
     list? owned=true → server owner.

"Our server" is the one at PLEX_URL, identified by its machineIdentifier from
{PLEX_URL}/identity (or PLEX_SERVER_ID if set).
"""
from __future__ import annotations

import logging
import os
import threading
import time
from typing import Optional
from urllib.parse import urlencode

import requests

log = logging.getLogger("aiogateway.plexauth")

PRODUCT = "AIOGateway"


class PlexAuthError(Exception):
    def __init__(self, message: str, status: int = 502, code: str = "plex_error"):
        super().__init__(message)
        self.status = status
        self.code = code


def plex_tv() -> str:
    return os.environ.get("PLEX_TV_BASE", "https://plex.tv").rstrip("/")


def plex_app() -> str:
    return os.environ.get("PLEX_APP_BASE", "https://app.plex.tv").rstrip("/")


def _headers(client_id: str, token: Optional[str] = None) -> dict:
    h = {"Accept": "application/json", "X-Plex-Product": PRODUCT,
         "X-Plex-Client-Identifier": client_id, "X-Plex-Version": "1.0",
         "X-Plex-Device-Name": PRODUCT, "X-Plex-Platform": "Web"}
    if token:
        h["X-Plex-Token"] = token
    return h


def _request(method: str, url: str, **kw) -> requests.Response:
    try:
        return requests.request(method, url, timeout=kw.pop("timeout", 15), **kw)
    except requests.RequestException as exc:
        raise PlexAuthError(f"Couldn't reach Plex ({exc.__class__.__name__})", 503, "plex_unreachable") from exc


# ── PIN flow ──────────────────────────────────────────────────────────────────

def create_pin(client_id: str) -> dict:
    r = _request("POST", f"{plex_tv()}/api/v2/pins", params={"strong": "true"}, headers=_headers(client_id))
    if r.status_code not in (200, 201):
        raise PlexAuthError(f"Plex refused to start sign-in (HTTP {r.status_code})")
    d = r.json()
    auth_url = f"{plex_app()}/auth#?" + urlencode({
        "clientID": client_id, "code": d["code"], "context[device][product]": PRODUCT,
    })
    return {"id": d["id"], "code": d["code"], "auth_url": auth_url}


def check_pin(client_id: str, pin_id: int) -> Optional[str]:
    """The Plex token once the person has approved sign-in, else None."""
    r = _request("GET", f"{plex_tv()}/api/v2/pins/{int(pin_id)}", headers=_headers(client_id))
    if r.status_code == 404:
        raise PlexAuthError("This sign-in attempt expired — start again", 410, "pin_expired")
    if r.status_code != 200:
        raise PlexAuthError(f"Plex sign-in check failed (HTTP {r.status_code})")
    return r.json().get("authToken") or None


# ── Account + access ──────────────────────────────────────────────────────────

def account(client_id: str, token: str) -> dict:
    r = _request("GET", f"{plex_tv()}/api/v2/user", headers=_headers(client_id, token))
    if r.status_code in (401, 403):
        raise PlexAuthError("Plex rejected the sign-in", 401, "plex_token_invalid")
    if r.status_code != 200:
        raise PlexAuthError(f"Couldn't load your Plex account (HTTP {r.status_code})")
    d = r.json()
    return {"plex_id": str(d["id"]), "uuid": d.get("uuid"),
            "username": d.get("username") or d.get("title") or d.get("email") or f"plex-{d['id']}",
            "email": d.get("email") or "", "thumb": d.get("thumb") or ""}


_server_id_cache: dict = {"id": None, "at": 0.0, "error": None}
_server_id_lock = threading.Lock()


def server_id(refresh: bool = False) -> str:
    """machineIdentifier of the Plex server at PLEX_URL (cached for an hour)."""
    override = os.environ.get("PLEX_SERVER_ID", "").strip()
    if override:
        return override
    with _server_id_lock:
        if not refresh and _server_id_cache["id"] and time.time() - _server_id_cache["at"] < 3600:
            return _server_id_cache["id"]
        url = os.environ.get("PLEX_URL", "").rstrip("/")
        if not url or "your-plex" in url:
            raise PlexAuthError("PLEX_URL isn't set, so there's no Plex server to sign in against",
                                503, "no_server")
        try:
            r = requests.get(f"{url}/identity", headers={"Accept": "application/json"}, timeout=8)
            mid = (r.json().get("MediaContainer") or {}).get("machineIdentifier")
        except Exception as exc:
            raise PlexAuthError(f"Can't reach your Plex server at {url}", 503, "server_unreachable") from exc
        if not mid:
            raise PlexAuthError(f"{url} didn't identify itself as a Plex server", 503, "server_unreachable")
        _server_id_cache.update(id=mid, at=time.time())
        return mid


def server_access(client_id: str, token: str) -> Optional[dict]:
    """None if this Plex account has no access to our server, else
    {"owned": bool, "name": server name}."""
    mid = server_id()
    r = _request("GET", f"{plex_tv()}/api/v2/resources",
                 params={"includeHttps": "1", "includeRelay": "0"}, headers=_headers(client_id, token))
    if r.status_code in (401, 403):
        raise PlexAuthError("Plex rejected the sign-in", 401, "plex_token_invalid")
    if r.status_code != 200:
        raise PlexAuthError(f"Couldn't check your Plex server access (HTTP {r.status_code})")
    for res in r.json() or []:
        if res.get("clientIdentifier") == mid and "server" in (res.get("provides") or ""):
            return {"owned": bool(res.get("owned")), "name": res.get("name") or "Plex"}
    return None
