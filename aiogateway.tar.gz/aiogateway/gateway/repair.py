"""
gateway/repair.py
~~~~~~~~~~~~~~~~~
Keeps every file in the library playable, on a schedule.

Debrid links expire. That is normal and expected — they are short-lived
session URLs, not permanent addresses. Without something that renews
them, a library that worked last week is a library full of files that
open and then stall, and the person watching finds out at the worst
possible moment.

So repair runs on its own schedule, by default once a day at 4am, and
checks each file's link is still answering. A link that has died is
replaced by searching for the title again. The file itself never moves,
never changes name, and never disappears from Plex — from the outside
nothing happened at all, which is the point.

Ordering, since a large library can't all be checked at once:

  1. Files queued urgently, because a read just found one dead. Someone
     is very likely sitting in front of that one right now.
  2. Activated files with no link at all.
  3. Activated files, oldest check first.
  4. Everything else.

Playback always wins. When `repair_pause_on_playback` is on, the pass
yields between items for as long as an activation is in flight, so a
scheduled repair can never be the reason a film takes a while to start.
"""
from __future__ import annotations

import asyncio
import logging
import threading
import time
from datetime import datetime, timedelta
from typing import Optional

import aiohttp

from . import aiostreams, settings
from .library import Library
from .models import EntryState
from .service import MediaService

logger = logging.getLogger("aiogateway.repair")

# Entries a read found broken. Checked first on the next pass, and a
# short-cycle pass is woken to handle them promptly.
_urgent: set[str] = set()
_urgent_lock = threading.Lock()
_wake = threading.Event()


def request_urgent(entry_id: str) -> None:
    """Called from the filesystem when a link fails mid-read."""
    with _urgent_lock:
        _urgent.add(entry_id)
    _wake.set()


def _take_urgent() -> set[str]:
    with _urgent_lock:
        taken = set(_urgent)
        _urgent.clear()
    return taken


class RepairRun:
    """Progress for the pass currently running, shown in the Repair tab."""

    def __init__(self, trigger: str) -> None:
        self.trigger = trigger
        self.started_at = time.time()
        self.finished_at: Optional[float] = None
        self.total = 0
        self.checked = 0
        self.still_good = 0
        self.repaired = 0
        self.failed = 0
        self.removed = 0
        self.current = ""
        self.cancelled = False

    def to_dict(self) -> dict:
        return {
            "trigger": self.trigger,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "running": self.finished_at is None,
            "total": self.total,
            "checked": self.checked,
            "still_good": self.still_good,
            "repaired": self.repaired,
            "failed": self.failed,
            "removed": self.removed,
            "current": self.current,
        }


class Repairer:
    def __init__(self, library: Library, service: MediaService) -> None:
        self.library = library
        self.service = service
        self.current: Optional[RepairRun] = None
        self.last: Optional[RepairRun] = None
        self.next_due: Optional[float] = None
        self._lock = asyncio.Lock()

    # ── link probing ────────────────────────────────────────────────
    async def _link_alive(self, session: aiohttp.ClientSession, entry) -> bool:
        """A one-byte range request: cheap, and it proves the link both
        resolves and will serve ranges, which is what playback needs.

        A HEAD would be cheaper still, but several debrid CDNs answer
        HEAD differently from GET — sometimes 405, sometimes a success
        for a URL that then refuses a real range request. Asking for the
        first byte tests the thing we actually rely on.
        """
        if not entry.url:
            return False
        headers = {**(entry.headers or {}), "Range": "bytes=0-0"}
        try:
            async with session.get(
                entry.url, headers=headers, allow_redirects=True,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                if resp.status not in (200, 206):
                    return False
                content_type = (resp.headers.get("Content-Type") or "").lower()
                if any(t in content_type for t in ("json", "text/html")):
                    # A 200 carrying an error page, which several
                    # backends return instead of a 4xx.
                    return False
                await resp.content.read(1)
                return True
        except Exception:
            return False

    async def _reacquire_pinned(self, entry):
        """Look for the exact release this entry was pinned to."""
        from .models import MediaItem
        item = MediaItem(
            imdb_id=entry.imdb_id, title=entry.title, media_type=entry.media_type,
            show_title=entry.show_title, year=entry.year,
            season=entry.season, episode=entry.episode, poster=entry.poster,
        )
        wanted = entry.info_hash.lower()
        try:
            candidates = await self.service.client.search(
                item, entry.quality, enforce_cached=False)
        except Exception:
            return None
        for cand in candidates:
            if cand.info_hash and cand.info_hash.lower() == wanted:
                return cand
        return None

    async def _repair_entry(self, session: aiohttp.ClientSession,
                            entry, run: RepairRun) -> str:
        run.current = entry.display_name

        if entry.url and await self._link_alive(session, entry):
            entry.last_repair_at = time.time()
            entry.repair_failures = 0
            self.library.mark_dirty()
            return "good"

        if entry.info_hash:
            # The stored verdict said cached and the link is dead, so
            # don't let a memoised yes pick the same source again.
            from . import debrid
            debrid.forget(entry.info_hash)

        candidate = None
        try:
            if entry.pinned and entry.info_hash:
                # Someone chose this release by hand. Try to get that
                # exact one back before settling for whatever now ranks
                # best, or the next link expiry would quietly undo their
                # choice.
                candidate = await self._reacquire_pinned(entry)
                if candidate is None:
                    logger.info("%s: pinned release is gone, picking a new one",
                                entry.display_name)
                    self.library.get(entry.entry_id).pinned = False
            if candidate is None:
                candidate = await self.service._find_source(entry)
        except Exception as exc:
            logger.debug("Repair search failed for %s: %s", entry.display_name, exc)
            candidate = None

        if candidate is None:
            self.library.mark_missing(entry.entry_id)
            limit = int(settings.get("repair_max_failures", 5) or 0)
            if limit and entry.repair_failures >= limit:
                # Nothing has been findable for this title across
                # several passes. Leaving it in place means Plex keeps
                # offering a file that will never start, which is worse
                # than it not being there.
                self.library.remove(entry.entry_id)
                logger.info("Removed %s — no source after %d repair attempts",
                            entry.display_name, entry.repair_failures)
                return "removed"
            return "failed"

        self.library.attach_source(entry.entry_id, candidate)
        # Warm the new link. A file that just got repaired is very often
        # one somebody is sitting in front of waiting for.
        try:
            from . import fusefs
            fusefs.warm(self.library.get(entry.entry_id))
        except Exception:
            pass
        logger.info("Repaired %s", entry.display_name)
        return "repaired"

    # ── passes ──────────────────────────────────────────────────────
    def _order(self, urgent: set[str]) -> list:
        entries = self.library.all()
        urgent_entries = [e for e in entries if e.entry_id in urgent]
        rest = [e for e in entries if e.entry_id not in urgent]

        def rank(entry):
            return (
                0 if (entry.activated and not entry.url) else
                1 if entry.activated else
                2 if entry.state == EntryState.MISSING else 3,
                entry.last_repair_at or 0,
            )

        return urgent_entries + sorted(rest, key=rank)

    async def run_pass(self, trigger: str = "scheduled",
                       entry_ids: Optional[set[str]] = None) -> dict:
        if self._lock.locked():
            return {"skipped": "a repair pass is already running"}

        async with self._lock:
            urgent = _take_urgent()
            if entry_ids:
                targets = [e for e in self.library.all() if e.entry_id in entry_ids]
            else:
                targets = self._order(urgent)
                batch = int(settings.get("repair_batch_size", 40) or 0)
                if batch > 0 and trigger != "manual":
                    # A capped pass keeps each run short and predictable.
                    # Since passes are ordered oldest-check-first, the
                    # whole library still gets covered over successive
                    # runs without any one run taking hours.
                    targets = targets[:max(len(urgent), batch)]

            run = RepairRun(trigger)
            run.total = len(targets)
            self.current = run
            pause = bool(settings.get("repair_pause_on_playback", True))

            logger.info("Repair pass (%s): %d file(s)", trigger, run.total)
            try:
                async with aiohttp.ClientSession() as session:
                    for entry in targets:
                        if run.cancelled:
                            break
                        if pause:
                            await aiostreams.yield_to_playback()
                        result = await self._repair_entry(session, entry, run)
                        run.checked += 1
                        if result == "good":
                            run.still_good += 1
                        elif result == "repaired":
                            run.repaired += 1
                        elif result == "removed":
                            run.removed += 1
                        else:
                            run.failed += 1
            finally:
                run.current = ""
                run.finished_at = time.time()
                self.last = run
                self.current = None
                self.library.save()

            logger.info("Repair done: %d fine, %d repaired, %d unresolved, %d removed",
                        run.still_good, run.repaired, run.failed, run.removed)
            return run.to_dict()

    def cancel(self) -> bool:
        if self.current is None:
            return False
        self.current.cancelled = True
        return True

    def status(self) -> dict:
        return {
            "enabled": bool(settings.get("repair_enabled", True)),
            "mode": settings.get("repair_mode", "daily"),
            "times": settings.get("repair_times", ["04:00"]),
            "interval_hours": settings.get("repair_interval_hours", 6),
            "next_due": self.next_due,
            "current": self.current.to_dict() if self.current else None,
            "last": self.last.to_dict() if self.last else None,
            "urgent_queued": len(_urgent),
        }


# ── scheduling ──────────────────────────────────────────────────────────
def _parse_time(text: str) -> Optional[tuple[int, int]]:
    try:
        hour, minute = str(text).strip().split(":")
        hour, minute = int(hour), int(minute)
        if 0 <= hour < 24 and 0 <= minute < 60:
            return hour, minute
    except Exception:
        pass
    return None


def next_run_at(now: Optional[datetime] = None) -> Optional[datetime]:
    """When the next scheduled pass is due, in local time.

    Local rather than UTC deliberately: someone setting 4am means 4am
    where they live and are asleep, not 4am somewhere else.
    """
    if not settings.get("repair_enabled", True):
        return None
    now = now or datetime.now()

    times = [t for t in (_parse_time(v) for v in settings.get("repair_times", [])) if t]
    if not times:
        times = [(4, 0)]

    mode = settings.get("repair_mode", "daily")
    if mode == "interval":
        hours = max(0.25, float(settings.get("repair_interval_hours", 6) or 6))
        anchor_h, anchor_m = times[0]
        anchor = now.replace(hour=anchor_h, minute=anchor_m, second=0, microsecond=0)
        if anchor > now:
            anchor -= timedelta(days=1)
        step = timedelta(hours=hours)
        # Walk forward from the anchor so the run times stay pinned to
        # the chosen start rather than drifting by however long each
        # pass happened to take.
        elapsed = (now - anchor) / step
        return anchor + step * (int(elapsed) + 1)

    candidates = []
    for hour, minute in times:
        today = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        candidates.append(today if today > now else today + timedelta(days=1))
    return min(candidates)


async def scheduler_loop(repairer: Repairer) -> None:
    """Wakes on the earlier of the next scheduled pass and an urgent
    request from a failed read.

    The wait is a series of short sleeps rather than one long one. An
    earlier version blocked a thread-pool thread on `threading.Event.wait`
    so a urgent request could interrupt it, but a blocked pool thread
    can't be cancelled, so shutdown had to wait for the full sleep to
    expire before the process could exit. Polling a flag every second
    costs nothing measurable and cancels instantly.
    """
    while True:
        try:
            due = next_run_at()
            repairer.next_due = due.timestamp() if due else None

            deadline = (due - datetime.now()).total_seconds() if due else 300.0
            waited = 0.0
            woken = False
            while waited < max(1.0, deadline):
                await asyncio.sleep(1.0)
                waited += 1.0
                if _wake.is_set():
                    _wake.clear()
                    woken = True
                    break

            if woken and _urgent:
                await repairer.run_pass("urgent")
                continue

            due = next_run_at()
            if due is not None and datetime.now() >= due - timedelta(seconds=30):
                await repairer.run_pass("scheduled")
                # Sleep past the slot so a fast pass doesn't re-trigger
                # on the same minute.
                await asyncio.sleep(60)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.error("Repair scheduler error: %s", exc)
            await asyncio.sleep(60)
