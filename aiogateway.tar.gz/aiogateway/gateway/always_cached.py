"""
gateway/always_cached.py
~~~~~~~~~~~~~~~~~~~~~~~~
Titles (movies or whole series) flagged "Keep Cached" in the Library.

A kept title:
  * is exempt from the active-file TTL sweep (stub_manager.sweep_expired_*),
    so once a stream is resolved it stays resolved;
  * gets a repair pass every 24 hours (main.py's _always_cached_loop) that
    re-resolves placeholder/error stubs, re-verifies active streams,
    and rescans for any missing HD/4K stubs or episodes;
  * gets an immediate repair pass when it is first flagged.

Same persistence pattern as pending_movies.py / quality_unavailable.py:
a flat JSON file, loaded once, kept in memory, written on every change.
"""
from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger("aiogateway.alwayscached")

REPAIR_INTERVAL_SECONDS = 24 * 3600

# imdb_id -> {imdb_id, title, poster, year, media_type, added_at,
#             last_repair_at, last_repair_result}
_items: dict[str, dict] = {}
_loaded = False


def _state_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_always_cached.json"


def _load() -> None:
    global _items, _loaded
    if _loaded:
        return
    path = _state_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text())
            _items = {item["imdb_id"]: item for item in raw if item.get("imdb_id")}
            logger.info("Loaded %d always-cached title(s) from %s", len(_items), path)
    except Exception as exc:
        logger.warning("Could not load always-cached list from %s: %s", path, exc)
        _items = {}
    _loaded = True


def _persist() -> None:
    path = _state_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(list(_items.values()), indent=2))
        tmp.replace(path)
    except Exception as exc:
        logger.warning("Could not persist always-cached list to %s: %s", path, exc)


def add(imdb_id: str, title: str, media_type: str, poster: str = "",
        year: Optional[int] = None) -> dict:
    _load()
    existing = _items.get(imdb_id)
    if existing:
        return existing
    entry = {
        "imdb_id": imdb_id, "title": title or imdb_id, "poster": poster or "",
        "year": year, "media_type": media_type or "movie",
        "added_at": time.time(), "last_repair_at": None, "last_repair_result": None,
    }
    _items[imdb_id] = entry
    _persist()
    logger.info("Keep Cached enabled: %s (%s)", entry["title"], imdb_id)
    return entry


def remove(imdb_id: str) -> bool:
    _load()
    if imdb_id in _items:
        del _items[imdb_id]
        _persist()
        logger.info("Keep Cached disabled: %s", imdb_id)
        return True
    return False


def is_kept(imdb_id: Optional[str]) -> bool:
    if not imdb_id:
        return False
    _load()
    return imdb_id in _items


def get(imdb_id: str) -> Optional[dict]:
    _load()
    return _items.get(imdb_id)


def list_all() -> list[dict]:
    _load()
    return list(_items.values())


def due_for_repair(now: Optional[float] = None) -> list[dict]:
    """Entries whose last repair is older than REPAIR_INTERVAL_SECONDS
    (or that have never been repaired)."""
    _load()
    now = now or time.time()
    return [
        e for e in _items.values()
        if not e.get("last_repair_at") or now - e["last_repair_at"] >= REPAIR_INTERVAL_SECONDS
    ]


def record_repair(imdb_id: str, result: dict) -> None:
    _load()
    e = _items.get(imdb_id)
    if not e:
        return
    e["last_repair_at"] = time.time()
    e["last_repair_result"] = result
    _persist()
