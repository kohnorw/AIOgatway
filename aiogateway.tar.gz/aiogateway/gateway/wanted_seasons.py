"""
gateway/wanted_seasons.py
~~~~~~~~~~~~~~~~~~~~~~~~~~
Tracks a season that was explicitly requested via the Library modal's
"New" button (or manually) while it had zero aired episodes — i.e.
Cinemeta already lists it, but nothing in it has actually come out yet.

"Requested" everywhere else in this app means "has at least one stub" —
which a season with nothing aired can never have, so without this
tracker, asking for a purely upcoming season would just fail once (404,
nothing to stub) and be forgotten: auto-episode discovery only expands
into seasons that are already requested (see gateway/auto_episodes.py's
requested_seasons), so a season that was never successfully requested
would NOT get picked up automatically once it actually starts airing.

This closes that gap: a season landing here is checked by the same
auto-episode sweep as any other requested season, so once its first
episode actually airs, it gets stubbed on the next sweep without the
person needing to remember to come back and click anything again. Once
a season gets its first real stub, it satisfies the normal "requested"
definition on its own and is removed from here — this tracker only ever
covers the gap before that first stub exists.
"""
from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger("aiogateway.wantedseasons")

# key ("imdb_id:season") -> {imdb_id, season, title, poster, year, added_at}
_wanted: dict[str, dict] = {}
_loaded = False


def _key(imdb_id: str, season: int) -> str:
    return f"{imdb_id}:{season}"


def _state_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_wanted_seasons.json"


def _load() -> None:
    global _wanted, _loaded
    if _loaded:
        return
    path = _state_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text())
            _wanted = {item["key"]: item for item in raw}
            logger.info("Loaded %d wanted season(s) from %s", len(_wanted), path)
    except Exception as exc:
        logger.warning("Could not load wanted seasons from %s: %s", path, exc)
        _wanted = {}
    _loaded = True


def _persist() -> None:
    path = _state_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(list(_wanted.values()), indent=2))
    except Exception as exc:
        logger.warning("Could not persist wanted seasons to %s: %s", path, exc)


def add(imdb_id: str, season: int, title: str, poster: str = "", year: Optional[int] = None) -> None:
    _load()
    key = _key(imdb_id, season)
    if key in _wanted:
        return
    _wanted[key] = {
        "key": key, "imdb_id": imdb_id, "season": season,
        "title": title, "poster": poster, "year": year,
        "added_at": time.time(),
    }
    _persist()
    logger.info("Marked S%02d of %s (%s) as a wanted upcoming season", season, title, imdb_id)


def remove(imdb_id: str, season: int) -> bool:
    _load()
    key = _key(imdb_id, season)
    if key in _wanted:
        del _wanted[key]
        _persist()
        return True
    return False


def is_wanted(imdb_id: str, season: int) -> bool:
    _load()
    return _key(imdb_id, season) in _wanted


def seasons_for(imdb_id: str) -> set[int]:
    """All wanted (not-yet-aired) season numbers for one show."""
    _load()
    return {v["season"] for v in _wanted.values() if v["imdb_id"] == imdb_id}


def list_all() -> list[dict]:
    _load()
    return list(_wanted.values())
