"""
gateway/settings.py
~~~~~~~~~~~~~~~~~~~
Persisted, runtime-mutable settings (as opposed to env vars, which are
fixed at container start). Stored as a small JSON file alongside the
library data so changes survive restarts.

Currently holds:
  active_ttl_enabled — master on/off switch for the active-file TTL.
                    True (default) means a resolved stub reverts to a
                    placeholder ACTIVE_TTL_DAYS after it resolved. False
                    means it never does — the stub stays active and
                    playable forever, and no new placeholder is created
                    for it again. The day count itself (ACTIVE_TTL_DAYS,
                    fixed at 30) is a module constant, not a setting —
                    see get_effective_ttl_days() for the one place
                    callers should read the combined result from.
"""
from __future__ import annotations

import json
import logging
import os
import threading
from pathlib import Path
from typing import Any

logger = logging.getLogger("aiogateway.settings")

# Fixed active-file TTL, in days. Deliberately NOT part of _DEFAULTS /
# not persisted or user-configurable — the FUSE tab used to expose this
# as an editable number, but it's now a fixed constant, and the only
# knob left is active_ttl_enabled (on/off). Change this to change the
# TTL for everyone; there's no per-install override anymore.
ACTIVE_TTL_DAYS = 30

_DEFAULTS = {
    # Master on/off switch for the active-file TTL. The TTL itself is
    # fixed at ACTIVE_TTL_DAYS (see below) — the FUSE tab no longer lets
    # anyone configure the day count, only whether it applies at all.
    # True (default) means a resolved stub reverts to a placeholder
    # ACTIVE_TTL_DAYS after it resolved, releasing the debrid session /
    # CDN link. False means nothing ever reverts: a resolved stub stays
    # active and playable indefinitely, and no new placeholder is ever
    # created for it again. Always read the *effective* TTL via
    # get_effective_ttl_days() rather than this flag alone.
    "active_ttl_enabled": True,

    # ── Stream preferences ──────────────────────────────────────────────────
    # Applied as a post-fetch ranking/filter pass on top of whatever results
    # AIOStreams itself already returns (AIOStreams' own per-user config,
    # set via its /stremio/configure page, does the heavy lifting upstream —
    # these are an additional layer on top, not a replacement).
    #
    # preferred_language: ISO-ish display name to rank first when present
    # (e.g. "English"). Empty string = no preference, just use AIOStreams'
    # own ordering.
    "preferred_language": "",
    # preferred_audio: substrings to rank up when present in audioTags
    # (e.g. "Atmos", "TrueHD", "DTS"). Empty list = no preference.
    "preferred_audio": [],
    # require_subtitles: if true, candidates with no subtitles reported are
    # ranked behind ones that do (never hard-excluded, since a result with
    # no subtitles is still better than no stream at all).
    "require_subtitles": False,
    # exclude_words: candidates whose filename or parsed quality/resolution
    # tag matches any of these words are hard-excluded — never picked, and
    # never even counted as "found" for the purpose of creating a stub.
    # Case-insensitive, matched as a whole word (so "cam" won't false-
    # positive on "camera"). Common uses: "CAM", "TS", "TELESYNC", "HDCAM".
    # Empty list = no exclusions.
    "exclude_words": [],
    # min_4k_candidates: a 4K stub is only created if at least this many
    # independent 4K sources were found — a single 4K source tends to be a
    # rare/uncached torrent that's more likely to fail than one with
    # several to fall back on. Set to 1 to create a 4K stub whenever any
    # 4K source exists at all (the old behaviour).
    "min_4k_candidates": 6,
    # prefer_season_packs: rank candidates detected as a season/series pack
    # above individual-episode files when picking among otherwise-equal
    # options (see gateway/models.py detect_pack_type). Packs tend to be
    # more heavily seeded/cached, so this is a reliability preference, not
    # just a convenience one. Only affects series episode queries — movie
    # filenames never match the pack patterns.
    "prefer_season_packs": True,
    # pack_first_fill: when adding a series, probe one episode per season
    # first and, wherever a season or series pack turns up, stub that whole
    # season from it instead of querying every episode individually. Stubs
    # are placeholders — the real stream URL is resolved at play time — so
    # a cached pack is already proof every episode in it is obtainable, and
    # the per-episode query adds nothing but latency and rate-limit
    # pressure. This is what makes an ended series add in seconds rather
    # than one query per episode. Seasons with no pack fall through to the
    # normal per-episode background scan untouched.
    "pack_first_fill": True,
    # pack_fill_require_cached: skip packs the debrid service explicitly
    # reports as NOT cached when deciding whether to fill a season from
    # them. Note AIOStreams' cached field is three-state — a missing value
    # means the addon didn't report cache status, which is common, and is
    # treated as unknown rather than uncached (otherwise pack filling would
    # never fire at all on those setups). The real check is the live probe
    # every pack gets before a season is filled from it; this flag just
    # avoids wasting that probe on something already known to be uncached.
    "pack_fill_require_cached": True,
    # pack_fill_min_candidates: how many independent pack sources must
    # cover a season before it gets filled from them. 1 trusts a single
    # pack; raise it if you see packs that turn out to be mislabelled or
    # missing episodes (a filled-but-wrong episode surfaces as a failed
    # resolve on first play, and the stub is removed automatically).
    "pack_fill_min_candidates": 1,
    # allow_usenet: whether candidates AIOStreams reports as usenet-sourced
    # (its "type" field == "usenet" — e.g. served via its built-in NNTP
    # engine, Easynews, NzbDAV/AltMount, Stremio NNTP, or TorBox's usenet
    # side) are eligible to be picked at all. This is purely a client-side
    # gate on top of whatever AIOStreams already returns — it has no effect
    # unless usenet is itself configured/enabled on your AIOStreams
    # instance, since AIOStreams simply won't return usenet-typed results
    # otherwise. Defaults on: a usenet-sourced candidate is treated the
    # same as a debrid/P2P one everywhere else (ranking, size/exclude-word
    # filters, live probing) once it's let through this gate.
    "allow_usenet": True,
    # ── Prewarm new content ───────────────────────────────────────────────────
    # How recently the content itself RELEASED or AIRED — Cinemeta's
    # `released` date for a movie, the per-episode air date for an
    # episode — to count as "new" for the "Prewarm new content" job,
    # which resolves placeholder stubs to real streams proactively, ahead
    # of the first actual play, so the very first playback of something
    # new isn't the moment it also has to wait on AIOStreams resolution.
    #
    # Master on/off for AUTOMATIC prewarming — both the event-driven
    # "something was just added" trigger and the periodic backstop sweep.
    # The manual "Prewarm new content now" button always works regardless.
    #
    # This exists because there previously wasn't an actual enable flag:
    # automatic prewarming was gated entirely on prewarm_interval_hours,
    # which defaults to 0, so a configured window did nothing on its own
    # and newly-added content was only prewarmed if a browser happened to
    # be open on the UI at the time.
    "prewarm_enabled": True,
    # stable_stub_filenames: keep a stub's " - Ready" filename once it has
    # resolved, instead of renaming it back when the TTL expires it.
    #
    # The rename exists so Plex re-analyses a file whose content just went
    # from placeholder to real media — worth it once, on first resolve.
    # Renaming BACK on expiry bought nothing and cost a lot: Plex saw a
    # file disappear and another appear, so every TTL cycle repopulated
    # Recently Added with content that had been in the library for months.
    # Off restores the old state-tracking behaviour.
    "stable_stub_filenames": True,
    # prewarm_skip_ttl_expired: once a stub has been expired by the active
    # TTL, don't prewarm it again — wait for someone to actually play it.
    #
    # This is what makes the TTL mean anything. Previously the TTL sweep
    # reverted a stub to placeholder and the next prewarm backstop pass
    # re-resolved it immediately, because a TTL-expired placeholder was
    # indistinguishable from one that had never been resolved and still
    # matched on created_at or release date. The two loops cancelled out
    # and links were effectively held open forever. Turning this off
    # restores that old behaviour, which is almost never what you want.
    "prewarm_skip_ttl_expired": True,
    # An item is eligible if it was ADDED within this many days OR its
    # content RELEASED within this many days — either qualifies.
    #
    # Both are checked because neither alone works. Release date alone
    # excludes the commonest case: a movie requested today usually
    # released theatrically months ago, so it never falls in the window
    # however freshly added it is. created_at alone can't tell new
    # content from back catalog added today.
    #
    # Bulk imports (a Radarr/Sonarr migration stamping a fresh created_at
    # on years of library at once) are handled by burst detection rather
    # than by refusing to look at created_at at all — see
    # prewarm_bulk_import_threshold.
    #
    # 0 = age filtering off, meaning NOTHING qualifies on age grounds —
    # automatic prewarming effectively stops. This matches every
    # neighbouring setting (active_ttl_days, prewarm_interval_hours,
    # auto_episodes_retry_days), where 0 disables the feature.
    #
    # 0 used to mean the opposite — "no window, every placeholder is
    # eligible regardless of age" — which read as "off" and behaved as
    # "maximum". Setting it produced a sweep over the entire library
    # every interval. -1 now selects that behaviour explicitly, for
    # anyone who actually wants it.
    "prewarm_new_content_days": 3,
    # How often (hours) a full backstop sweep over every placeholder runs.
    # 0 = no repeating sweep; new content is still prewarmed as it's added
    # (that's the event-driven trigger, governed by prewarm_enabled), and
    # one catch-up sweep still runs shortly after startup to pick up
    # anything added while the service was down.
    #
    # Defaults to 6 rather than 0 because the event-driven trigger only
    # ever fires ONCE, at stub creation, and so covers "newly ADDED" but
    # not "newly RELEASED". A film added while it's still unreleased, or
    # an episode stubbed before a release lands on debrid, fails that one
    # attempt and would then sit as a placeholder forever — the release
    # side of prewarm_new_content_days can only ever be evaluated by a
    # repeating sweep that re-examines existing placeholders. Six hours
    # is frequent enough that something releasing overnight is active by
    # morning, and each pass is cheap: placeholders failing repeatedly
    # are held off by prewarm_retry_cooldown_hours, and anything already
    # resolved is skipped outright.
    "prewarm_interval_hours": 6,
    # How many stubs created within ~15 minutes of each other count as a
    # bulk import. Stubs in such a burst have to qualify on release date
    # alone — being "recently added" doesn't count for them, since a
    # migration makes the entire back catalog look freshly added. Normal
    # activity doesn't come close: adding a movie is 1–2 stubs, scanning a
    # full season is a couple of dozen at most. 0 disables the check.
    "prewarm_bulk_import_threshold": 25,
    # After a prewarm attempt fails to find a working stream, don't retry
    # that item for this many hours. Without a cooldown, a handful of
    # titles with no sources get re-attempted on every pass forever and,
    # on a large library, crowd out the newly-added items prewarming is
    # meant to prioritise. 0 disables the cooldown (retry every pass).
    "prewarm_retry_cooldown_hours": 6,

    # ── Plex analyze cooldown ─────────────────────────────────────────────────
    # Plex's "Analyze" step actually reads chunks of the file to determine
    # audio/subtitle/bitrate info — for a FUSE-proxied debrid stream, that
    # means real download traffic through the debrid CDN, not just a local
    # disk read. Triggering it on every single play (rather than only when
    # it's likely to actually change something) burns bandwidth on repeat
    # plays for no benefit. This is the minimum time between two analyze
    # calls for the SAME stub — a play within the cooldown window still
    # plays normally, it just skips the analyze/refresh call. 0 disables
    # the cooldown (analyze on every play, the previous behavior).
    "plex_analyze_cooldown_hours": 24,

    # min/max size bounds in GB. 0 = no bound. Candidates outside the range
    # are filtered out entirely (not just ranked down) — these are hard
    # limits, since "too small to be real" and "too big for available
    # bandwidth/storage" are both genuine deal-breakers, not preferences.
    "min_size_gb": 0,
    "max_size_gb": 0,

    # ── Auto new-episode discovery ──────────────────────────────────────────
    # When enabled, a background sweep periodically checks every series you
    # already have at least one stub for, looking for newly-aired episodes
    # that haven't been stubbed yet — and stubs them (HD always, +4K if
    # available) the moment a real stream shows up, with no manual rescan
    # needed. See gateway/auto_episodes.py for the actual sweep/retry logic.
    "auto_episodes_enabled": True,
    # How often (minutes) to check tracked shows for newly-aired episodes.
    "auto_episodes_interval_minutes": 30,
    # How many days to keep retrying an aired-but-no-stream-yet episode
    # before giving up on it (it'll still show as "missing" in the UI and
    # can be searched manually at any time — this just stops the automatic
    # background retries after this window).
    "auto_episodes_retry_days": 3,

    # ── Dead stub cleanup ────────────────────────────────────────────────────
    # A stub that fails resolution (no working stream found) this many times
    # in a row is treated as permanently dead: its placeholder file is
    # deleted and Plex is told to rescan, so it disappears from the library
    # instead of sitting there forever as a false-positive "available" file
    # that can never actually play. 0 disables cleanup entirely (a dead stub
    # just stays in ERROR state and keeps showing up in Plex, the original
    # behaviour).
    "dead_stub_max_errors": 3,

    # ── AIOStreams request pacing ────────────────────────────────────────────
    # Every code path that queries AIOStreams (webhook resolves, background
    # episode scans, auto-episode discovery, migration) funnels through a
    # single global rate gate — see gateway/aiostreams_client.py. These two
    # numbers are the actual throttle. min_interval_ms is read live on every
    # request (no restart needed to retune it); max_concurrent is read once
    # at first use, so changing it does need a restart to take effect.
    #
    # AIOStreams fans a single query out to every addon you have configured
    # (Comet, MediaFusion, etc.) in parallel, so even a modest top-level
    # request rate from us can still burst much higher at the addon level —
    # that's outside our control, which is why these defaults are
    # deliberately conservative rather than aggressive.
    "aiostreams_max_concurrent":  1,      # requests in flight at once, app-wide
    "aiostreams_min_interval_ms": 3000,   # minimum gap between dispatching requests

    # ── Radarr/Sonarr migration ──────────────────────────────────────────────
    # Connection details for the "Migrate" tool, which reads your existing
    # Radarr/Sonarr library and stubs the same movies/seasons through our own
    # AIOStreams-backed pipeline. Kept here (not env vars) since this is a
    # one-time-setup-then-occasionally-used tool a user configures from the
    # UI, same as the stream preferences above.
    "radarr_url":     "",
    "radarr_api_key": "",
    "sonarr_url":     "",
    "sonarr_api_key": "",

    # ── Pending movies (upcoming / not-yet-cached) ───────────────────────────
    # When a movie add can't be resolved right away — most commonly because
    # it hasn't released yet, sometimes just because nothing's cached at the
    # debrid backend yet — it's tracked here instead of failing outright,
    # and retried automatically on the same schedule as the auto-episode
    # sweep (auto_episodes_interval_minutes) until a stream turns up.
    "pending_movies_enabled":    True,
    # How many days to keep retrying before giving up on a pending movie
    # (it stays visible/searchable manually — this only governs the
    # automatic background retries). Movies can sit unavailable for a
    # while after theatrical release before showing up on debrid, so this
    # defaults longer than the equivalent episode retry window.
    "pending_movies_retry_days": 30,

    # digital_release_delay_days: additional days to wait AFTER the
    # theatrical release date before searching a movie at all. This is a
    # heuristic, not an exact check — Cinemeta's `released` field is the
    # theatrical date, and there's no reliable free API for the actual
    # digital/VOD date, which varies a lot by title and studio. A delay
    # window is the practical way to cut down on catching pre-digital cam/
    # TS leaks before they'd normally show up on debrid. 0 disables this
    # (falls back to just the theatrical-release check).
    "digital_release_delay_days": 21,
}

_lock = threading.Lock()
_settings: dict[str, Any] = dict(_DEFAULTS)
_loaded = False


def _settings_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    # Store next to the mountpoint's parent (the project dir), not inside
    # the virtual FUSE filesystem itself — settings must persist independent
    # of whatever stubs exist, and the FUSE tree has no real backing file.
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_settings.json"


def _migrate(data: dict) -> dict:
    """
    One-time migrations for settings files from earlier versions.
    """
    # active_ttl_days (and, before that, active_ttl_minutes) used to be a
    # user-configurable number. It's now the fixed ACTIVE_TTL_DAYS
    # constant — drop whatever an older install had persisted so it
    # doesn't linger in the settings file or get echoed back by
    # get_all()/the /api/settings response as if it still meant
    # something.
    if "active_ttl_days" in data or "active_ttl_minutes" in data:
        old = data.pop("active_ttl_days", None)
        data.pop("active_ttl_minutes", None)
        logger.info(
            "active_ttl_days is no longer configurable (was %r) — the "
            "active-file TTL is now fixed at %d days; use "
            "active_ttl_enabled to turn it on/off", old, ACTIVE_TTL_DAYS
        )

    # One-time: the FUSE tab used to expose prewarm_interval_hours as a
    # number box, and it defaulted to 0 (no repeating sweep). That box is
    # gone — the TTL is now the only knob on that tab — so an existing
    # settings file with 0 persisted would be stuck with no backstop
    # sweep and no way to change it from the UI, meaning newly RELEASED
    # content would never be picked up (see the default's comment above).
    # Bump those installs to the new default exactly once; the marker key
    # means a deliberate later 0 (set via the API) is left alone.
    if not data.get("_prewarm_backstop_migrated"):
        try:
            if float(data.get("prewarm_interval_hours", 0) or 0) <= 0:
                data["prewarm_interval_hours"] = _DEFAULTS["prewarm_interval_hours"]
                logger.info(
                    "Enabled the prewarm backstop sweep (prewarm_interval_hours 0 → %g) "
                    "so newly-released placeholders are picked up",
                    data["prewarm_interval_hours"],
                )
        except (TypeError, ValueError):
            data["prewarm_interval_hours"] = _DEFAULTS["prewarm_interval_hours"]
        data["_prewarm_backstop_migrated"] = True

    # One-time: prewarm_new_content_days used to treat 0 as "no window —
    # every placeholder is eligible", the opposite of what 0 means in
    # every other setting here. It now means "disabled". A settings file
    # carrying a 0 was almost certainly set by someone reading it as
    # "off", and got a full-library sweep every interval instead — so
    # move it to the default rather than leave it meaning something new.
    #
    # Deliberately not migrated to -1: preserving the old behaviour would
    # preserve the surprise. Anyone who genuinely wants every placeholder
    # can set -1 explicitly, and the marker key means we only ever do
    # this once.
    if not data.get("_prewarm_window_migrated"):
        try:
            if float(data.get("prewarm_new_content_days", 0) or 0) == 0:
                data["prewarm_new_content_days"] = _DEFAULTS["prewarm_new_content_days"]
                logger.info(
                    "prewarm_new_content_days was 0, which used to mean 'prewarm "
                    "every placeholder regardless of age' — set to %g days. "
                    "Use -1 if you actually want every placeholder.",
                    data["prewarm_new_content_days"],
                )
        except (TypeError, ValueError):
            data["prewarm_new_content_days"] = _DEFAULTS["prewarm_new_content_days"]
        data["_prewarm_window_migrated"] = True

    return data


def load() -> dict:
    """Load settings from disk once. Safe to call repeatedly."""
    global _settings, _loaded
    with _lock:
        if _loaded:
            return dict(_settings)
        path = _settings_path()
        try:
            if path.exists():
                on_disk = _migrate(json.loads(path.read_text()))
                _settings = {**_DEFAULTS, **on_disk}
                logger.info("Loaded settings from %s: %s", path, _settings)
            else:
                _settings = dict(_DEFAULTS)
        except Exception as exc:
            logger.warning("Could not load settings from %s: %s — using defaults", path, exc)
            _settings = dict(_DEFAULTS)
        _loaded = True
        return dict(_settings)


def get_all() -> dict:
    if not _loaded:
        load()
    with _lock:
        return dict(_settings)


def get(key: str, default=None):
    if not _loaded:
        load()
    with _lock:
        return _settings.get(key, default)


def get_effective_ttl_days() -> float:
    """
    The TTL actually in effect right now: ACTIVE_TTL_DAYS when
    active_ttl_enabled is on, 0 (never expire) when it's off.

    The day count is a fixed constant, not a per-install setting — this
    is the one place that combines it with the toggle, and every caller
    that needs to decide "does a stub expire, and after how long" should
    read it from here rather than reading ACTIVE_TTL_DAYS directly, so
    the toggle can't be silently bypassed by code that forgot to check it.
    """
    if not get("active_ttl_enabled", True):
        return 0
    return ACTIVE_TTL_DAYS


def update(patch: dict) -> dict:
    """Merge `patch` into settings, validate, and persist to disk."""
    global _settings
    if not _loaded:
        load()
    with _lock:
        candidate = {**_settings, **patch}

        # active_ttl_days is no longer a real setting — fixed at
        # ACTIVE_TTL_DAYS above. Drop it unconditionally so it can never
        # be reintroduced via the API and left dangling in the settings
        # file (see _migrate for the same cleanup on load).
        candidate.pop("active_ttl_days", None)

        # Validation — active_ttl_enabled
        if "active_ttl_enabled" in candidate and not isinstance(candidate["active_ttl_enabled"], bool):
            raise ValueError("active_ttl_enabled must be a boolean")

        # Validation — stream preferences
        if "preferred_language" in candidate:
            v = candidate["preferred_language"]
            if not isinstance(v, str):
                raise ValueError("preferred_language must be a string")
            candidate["preferred_language"] = v.strip()

        if "preferred_audio" in candidate:
            v = candidate["preferred_audio"]
            if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
                raise ValueError("preferred_audio must be a list of strings")
            candidate["preferred_audio"] = [x.strip() for x in v if x.strip()]

        if "require_subtitles" in candidate:
            candidate["require_subtitles"] = bool(candidate["require_subtitles"])

        if "exclude_words" in candidate:
            v = candidate["exclude_words"]
            if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
                raise ValueError("exclude_words must be a list of strings")
            candidate["exclude_words"] = [x.strip() for x in v if x.strip()]

        if "min_4k_candidates" in candidate:
            try:
                v = int(candidate["min_4k_candidates"])
            except (TypeError, ValueError):
                raise ValueError("min_4k_candidates must be an integer")
            if v < 1:
                raise ValueError("min_4k_candidates must be at least 1")
            candidate["min_4k_candidates"] = v

        if "prefer_season_packs" in candidate:
            candidate["prefer_season_packs"] = bool(candidate["prefer_season_packs"])

        if "pack_first_fill" in candidate:
            candidate["pack_first_fill"] = bool(candidate["pack_first_fill"])

        if "pack_fill_require_cached" in candidate:
            candidate["pack_fill_require_cached"] = bool(candidate["pack_fill_require_cached"])

        if "pack_fill_min_candidates" in candidate:
            try:
                v = int(candidate["pack_fill_min_candidates"])
            except (TypeError, ValueError):
                raise ValueError("pack_fill_min_candidates must be an integer")
            if v < 1:
                raise ValueError("pack_fill_min_candidates must be at least 1")
            candidate["pack_fill_min_candidates"] = v

        if "allow_usenet" in candidate:
            candidate["allow_usenet"] = bool(candidate["allow_usenet"])

        if "plex_analyze_cooldown_hours" in candidate:
            try:
                v = float(candidate["plex_analyze_cooldown_hours"])
            except (TypeError, ValueError):
                raise ValueError("plex_analyze_cooldown_hours must be a number")
            if v < 0:
                raise ValueError("plex_analyze_cooldown_hours cannot be negative")
            candidate["plex_analyze_cooldown_hours"] = int(v) if v == int(v) else v

        if "prewarm_new_content_days" in candidate:
            try:
                v = float(candidate["prewarm_new_content_days"])
            except (TypeError, ValueError):
                raise ValueError("prewarm_new_content_days must be a number")
            # -1 is the explicit "every placeholder, ignore age" opt-in.
            # Anything below that is meaningless.
            if v < -1:
                raise ValueError(
                    "prewarm_new_content_days must be -1 (every placeholder), "
                    "0 (disabled), or a positive number of days"
                )
            candidate["prewarm_new_content_days"] = int(v) if v == int(v) else v

        if "prewarm_interval_hours" in candidate:
            try:
                v = float(candidate["prewarm_interval_hours"])
            except (TypeError, ValueError):
                raise ValueError("prewarm_interval_hours must be a number")
            if v < 0:
                raise ValueError("prewarm_interval_hours cannot be negative")
            candidate["prewarm_interval_hours"] = int(v) if v == int(v) else v

        if "prewarm_enabled" in candidate:
            candidate["prewarm_enabled"] = bool(candidate["prewarm_enabled"])

        if "prewarm_bulk_import_threshold" in candidate:
            try:
                v = int(candidate["prewarm_bulk_import_threshold"])
            except (TypeError, ValueError):
                raise ValueError("prewarm_bulk_import_threshold must be a whole number")
            if v < 0:
                raise ValueError("prewarm_bulk_import_threshold cannot be negative")
            candidate["prewarm_bulk_import_threshold"] = v

        if "prewarm_retry_cooldown_hours" in candidate:
            try:
                v = float(candidate["prewarm_retry_cooldown_hours"])
            except (TypeError, ValueError):
                raise ValueError("prewarm_retry_cooldown_hours must be a number")
            if v < 0:
                raise ValueError("prewarm_retry_cooldown_hours cannot be negative")
            candidate["prewarm_retry_cooldown_hours"] = int(v) if v == int(v) else v

        for key in ("min_size_gb", "max_size_gb"):
            if key in candidate:
                try:
                    v = float(candidate[key])
                except (TypeError, ValueError):
                    raise ValueError(f"{key} must be a number")
                if v < 0:
                    raise ValueError(f"{key} cannot be negative")
                candidate[key] = int(v) if v == int(v) else v

        min_gb = candidate.get("min_size_gb", 0) or 0
        max_gb = candidate.get("max_size_gb", 0) or 0
        if min_gb and max_gb and min_gb > max_gb:
            raise ValueError("min_size_gb cannot be greater than max_size_gb")

        # Validation — auto episode discovery
        if "auto_episodes_enabled" in candidate:
            candidate["auto_episodes_enabled"] = bool(candidate["auto_episodes_enabled"])

        if "auto_episodes_interval_minutes" in candidate:
            try:
                v = int(candidate["auto_episodes_interval_minutes"])
            except (TypeError, ValueError):
                raise ValueError("auto_episodes_interval_minutes must be an integer")
            if v < 5:
                raise ValueError("auto_episodes_interval_minutes must be at least 5")
            candidate["auto_episodes_interval_minutes"] = v

        if "auto_episodes_retry_days" in candidate:
            try:
                v = float(candidate["auto_episodes_retry_days"])
            except (TypeError, ValueError):
                raise ValueError("auto_episodes_retry_days must be a number")
            if v < 0:
                raise ValueError("auto_episodes_retry_days cannot be negative")
            candidate["auto_episodes_retry_days"] = int(v) if v == int(v) else v

        if "dead_stub_max_errors" in candidate:
            try:
                v = int(candidate["dead_stub_max_errors"])
            except (TypeError, ValueError):
                raise ValueError("dead_stub_max_errors must be an integer")
            if v < 0:
                raise ValueError("dead_stub_max_errors cannot be negative")
            candidate["dead_stub_max_errors"] = v

        if "aiostreams_max_concurrent" in candidate:
            try:
                v = int(candidate["aiostreams_max_concurrent"])
            except (TypeError, ValueError):
                raise ValueError("aiostreams_max_concurrent must be an integer")
            if v < 1:
                raise ValueError("aiostreams_max_concurrent must be at least 1")
            candidate["aiostreams_max_concurrent"] = v

        if "aiostreams_min_interval_ms" in candidate:
            try:
                v = float(candidate["aiostreams_min_interval_ms"])
            except (TypeError, ValueError):
                raise ValueError("aiostreams_min_interval_ms must be a number")
            if v < 0:
                raise ValueError("aiostreams_min_interval_ms cannot be negative")
            candidate["aiostreams_min_interval_ms"] = int(v) if v == int(v) else v

        for key in ("radarr_url", "radarr_api_key", "sonarr_url", "sonarr_api_key"):
            if key in candidate:
                v = candidate[key]
                if not isinstance(v, str):
                    raise ValueError(f"{key} must be a string")
                candidate[key] = v.strip().rstrip("/") if key.endswith("_url") else v.strip()

        if "pending_movies_enabled" in candidate:
            candidate["pending_movies_enabled"] = bool(candidate["pending_movies_enabled"])

        if "pending_movies_retry_days" in candidate:
            try:
                v = float(candidate["pending_movies_retry_days"])
            except (TypeError, ValueError):
                raise ValueError("pending_movies_retry_days must be a number")
            if v < 0:
                raise ValueError("pending_movies_retry_days cannot be negative")
            candidate["pending_movies_retry_days"] = int(v) if v == int(v) else v

        if "digital_release_delay_days" in candidate:
            try:
                v = float(candidate["digital_release_delay_days"])
            except (TypeError, ValueError):
                raise ValueError("digital_release_delay_days must be a number")
            if v < 0:
                raise ValueError("digital_release_delay_days cannot be negative")
            candidate["digital_release_delay_days"] = int(v) if v == int(v) else v

        _settings = candidate
        path = _settings_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(_settings, indent=2))
        except Exception as exc:
            logger.warning("Could not persist settings to %s: %s", path, exc)
        return dict(_settings)
