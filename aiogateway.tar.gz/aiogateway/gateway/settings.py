"""
gateway/settings.py
~~~~~~~~~~~~~~~~~~~
Persisted, runtime-mutable settings (as opposed to env vars, which are
fixed at container start). Stored as a small JSON file alongside the
library data so changes survive restarts.

Currently holds:
  active_ttl_days — how long a resolved (ACTIVE) stub stays active before
                    automatically reverting to a stub/placeholder. 0
                    disables the TTL entirely (stays active forever, the
                    original behaviour).
"""
from __future__ import annotations

import json
import logging
import os
import threading
from pathlib import Path
from typing import Any

logger = logging.getLogger("aiogateway.settings")

_DEFAULTS = {
    # Days a resolved stub stays ACTIVE before automatically reverting
    # to PLACEHOLDER. 0 = never expire (matches original behaviour).
    "active_ttl_days": 0,

    # ── Stream preferences ──────────────────────────────────────────────────
    # Applied as a post-fetch ranking/filter pass on top of whatever results
    # AIOStreams itself already returns (AIOStreams' own per-user config,
    # set via its /stremio/configure page, does the heavy lifting upstream —
    # these are an additional layer on top, not a replacement).
    #
    # preferred_language: ISO-ish display name to rank first when present
    # (e.g. "English"). Empty string = no preference, just use AIOStreams'
    # own ordering.
    "preferred_language": "",
    # preferred_audio: substrings to rank up when present in audioTags
    # (e.g. "Atmos", "TrueHD", "DTS"). Empty list = no preference.
    "preferred_audio": [],
    # require_subtitles: if true, candidates with no subtitles reported are
    # ranked behind ones that do (never hard-excluded, since a result with
    # no subtitles is still better than no stream at all).
    "require_subtitles": False,
    # exclude_words: candidates whose filename or parsed quality/resolution
    # tag matches any of these words are hard-excluded — never picked, and
    # never even counted as "found" for the purpose of creating a stub.
    # Case-insensitive, matched as a whole word (so "cam" won't false-
    # positive on "camera"). Common uses: "CAM", "TS", "TELESYNC", "HDCAM".
    # Empty list = no exclusions.
    "exclude_words": [],
    # min/max size bounds in GB. 0 = no bound. Candidates outside the range
    # are filtered out entirely (not just ranked down) — these are hard
    # limits, since "too small to be real" and "too big for available
    # bandwidth/storage" are both genuine deal-breakers, not preferences.
    "min_size_gb": 0,
    "max_size_gb": 0,

    # ── Auto new-episode discovery ──────────────────────────────────────────
    # When enabled, a background sweep periodically checks every series you
    # already have at least one stub for, looking for newly-aired episodes
    # that haven't been stubbed yet — and stubs them (HD always, +4K if
    # available) the moment a real stream shows up, with no manual rescan
    # needed. See gateway/auto_episodes.py for the actual sweep/retry logic.
    "auto_episodes_enabled": True,
    # How often (minutes) to check tracked shows for newly-aired episodes.
    "auto_episodes_interval_minutes": 10,
    # How many days to keep retrying an aired-but-no-stream-yet episode
    # before giving up on it (it'll still show as "missing" in the UI and
    # can be searched manually at any time — this just stops the automatic
    # background retries after this window).
    "auto_episodes_retry_days": 3,

    # ── Dead stub cleanup ────────────────────────────────────────────────────
    # A stub that fails resolution (no working stream found) this many times
    # in a row is treated as permanently dead: its placeholder file is
    # deleted and Plex is told to rescan, so it disappears from the library
    # instead of sitting there forever as a false-positive "available" file
    # that can never actually play. 0 disables cleanup entirely (a dead stub
    # just stays in ERROR state and keeps showing up in Plex, the original
    # behaviour).
    "dead_stub_max_errors": 3,

    # ── AIOStreams request pacing ────────────────────────────────────────────
    # Every code path that queries AIOStreams (webhook resolves, background
    # episode scans, auto-episode discovery, migration) funnels through a
    # single global rate gate — see gateway/aiostreams_client.py. These two
    # numbers are the actual throttle. min_interval_ms is read live on every
    # request (no restart needed to retune it); max_concurrent is read once
    # at first use, so changing it does need a restart to take effect.
    #
    # AIOStreams fans a single query out to every addon you have configured
    # (Comet, MediaFusion, etc.) in parallel, so even a modest top-level
    # request rate from us can still burst much higher at the addon level —
    # that's outside our control, which is why these defaults are
    # deliberately conservative rather than aggressive.
    "aiostreams_max_concurrent":  1,      # requests in flight at once, app-wide
    "aiostreams_min_interval_ms": 1500,   # minimum gap between dispatching requests

    # ── Radarr/Sonarr migration ──────────────────────────────────────────────
    # Connection details for the "Migrate" tool, which reads your existing
    # Radarr/Sonarr library and stubs the same movies/seasons through our own
    # AIOStreams-backed pipeline. Kept here (not env vars) since this is a
    # one-time-setup-then-occasionally-used tool a user configures from the
    # UI, same as the stream preferences above.
    "radarr_url":     "",
    "radarr_api_key": "",
    "sonarr_url":     "",
    "sonarr_api_key": "",

    # ── Pending movies (upcoming / not-yet-cached) ───────────────────────────
    # When a movie add can't be resolved right away — most commonly because
    # it hasn't released yet, sometimes just because nothing's cached at the
    # debrid backend yet — it's tracked here instead of failing outright,
    # and retried automatically on the same schedule as the auto-episode
    # sweep (auto_episodes_interval_minutes) until a stream turns up.
    "pending_movies_enabled":    True,
    # How many days to keep retrying before giving up on a pending movie
    # (it stays visible/searchable manually — this only governs the
    # automatic background retries). Movies can sit unavailable for a
    # while after theatrical release before showing up on debrid, so this
    # defaults longer than the equivalent episode retry window.
    "pending_movies_retry_days": 30,
}

_lock = threading.Lock()
_settings: dict[str, Any] = dict(_DEFAULTS)
_loaded = False


def _settings_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    # Store next to the mountpoint's parent (the project dir), not inside
    # the virtual FUSE filesystem itself — settings must persist independent
    # of whatever stubs exist, and the FUSE tree has no real backing file.
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_settings.json"


def _migrate(data: dict) -> dict:
    """
    One-time migration: earlier versions stored active_ttl_minutes instead
    of active_ttl_days. Convert it if present and the new key is missing,
    so existing settings files don't silently lose the configured value.
    """
    if "active_ttl_days" not in data and "active_ttl_minutes" in data:
        try:
            old_minutes = int(data.pop("active_ttl_minutes"))
            # Round up so a previously-configured non-zero TTL doesn't
            # collapse to 0 days and silently become "never expire".
            data["active_ttl_days"] = max(1, -(-old_minutes // 1440)) if old_minutes > 0 else 0
            logger.info("Migrated active_ttl_minutes=%d → active_ttl_days=%d",
                       old_minutes, data["active_ttl_days"])
        except (TypeError, ValueError):
            data.pop("active_ttl_minutes", None)
    return data


def load() -> dict:
    """Load settings from disk once. Safe to call repeatedly."""
    global _settings, _loaded
    with _lock:
        if _loaded:
            return dict(_settings)
        path = _settings_path()
        try:
            if path.exists():
                on_disk = _migrate(json.loads(path.read_text()))
                _settings = {**_DEFAULTS, **on_disk}
                logger.info("Loaded settings from %s: %s", path, _settings)
            else:
                _settings = dict(_DEFAULTS)
        except Exception as exc:
            logger.warning("Could not load settings from %s: %s — using defaults", path, exc)
            _settings = dict(_DEFAULTS)
        _loaded = True
        return dict(_settings)


def get_all() -> dict:
    if not _loaded:
        load()
    with _lock:
        return dict(_settings)


def get(key: str, default=None):
    if not _loaded:
        load()
    with _lock:
        return _settings.get(key, default)


def update(patch: dict) -> dict:
    """Merge `patch` into settings, validate, and persist to disk."""
    global _settings
    if not _loaded:
        load()
    with _lock:
        candidate = {**_settings, **patch}

        # Validation — active_ttl_days
        ttl = candidate.get("active_ttl_days", 0)
        try:
            ttl = float(ttl)
        except (TypeError, ValueError):
            raise ValueError("active_ttl_days must be a number")
        if ttl < 0:
            raise ValueError("active_ttl_days cannot be negative")
        # Store as int when it's a whole number for a cleaner JSON file /
        # API response, otherwise keep the fraction (e.g. 0.5 = 12 hours).
        candidate["active_ttl_days"] = int(ttl) if ttl == int(ttl) else ttl

        # Validation — stream preferences
        if "preferred_language" in candidate:
            v = candidate["preferred_language"]
            if not isinstance(v, str):
                raise ValueError("preferred_language must be a string")
            candidate["preferred_language"] = v.strip()

        if "preferred_audio" in candidate:
            v = candidate["preferred_audio"]
            if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
                raise ValueError("preferred_audio must be a list of strings")
            candidate["preferred_audio"] = [x.strip() for x in v if x.strip()]

        if "require_subtitles" in candidate:
            candidate["require_subtitles"] = bool(candidate["require_subtitles"])

        if "exclude_words" in candidate:
            v = candidate["exclude_words"]
            if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
                raise ValueError("exclude_words must be a list of strings")
            candidate["exclude_words"] = [x.strip() for x in v if x.strip()]

        for key in ("min_size_gb", "max_size_gb"):
            if key in candidate:
                try:
                    v = float(candidate[key])
                except (TypeError, ValueError):
                    raise ValueError(f"{key} must be a number")
                if v < 0:
                    raise ValueError(f"{key} cannot be negative")
                candidate[key] = int(v) if v == int(v) else v

        min_gb = candidate.get("min_size_gb", 0) or 0
        max_gb = candidate.get("max_size_gb", 0) or 0
        if min_gb and max_gb and min_gb > max_gb:
            raise ValueError("min_size_gb cannot be greater than max_size_gb")

        # Validation — auto episode discovery
        if "auto_episodes_enabled" in candidate:
            candidate["auto_episodes_enabled"] = bool(candidate["auto_episodes_enabled"])

        if "auto_episodes_interval_minutes" in candidate:
            try:
                v = int(candidate["auto_episodes_interval_minutes"])
            except (TypeError, ValueError):
                raise ValueError("auto_episodes_interval_minutes must be an integer")
            if v < 5:
                raise ValueError("auto_episodes_interval_minutes must be at least 5")
            candidate["auto_episodes_interval_minutes"] = v

        if "auto_episodes_retry_days" in candidate:
            try:
                v = float(candidate["auto_episodes_retry_days"])
            except (TypeError, ValueError):
                raise ValueError("auto_episodes_retry_days must be a number")
            if v < 0:
                raise ValueError("auto_episodes_retry_days cannot be negative")
            candidate["auto_episodes_retry_days"] = int(v) if v == int(v) else v

        if "dead_stub_max_errors" in candidate:
            try:
                v = int(candidate["dead_stub_max_errors"])
            except (TypeError, ValueError):
                raise ValueError("dead_stub_max_errors must be an integer")
            if v < 0:
                raise ValueError("dead_stub_max_errors cannot be negative")
            candidate["dead_stub_max_errors"] = v

        if "aiostreams_max_concurrent" in candidate:
            try:
                v = int(candidate["aiostreams_max_concurrent"])
            except (TypeError, ValueError):
                raise ValueError("aiostreams_max_concurrent must be an integer")
            if v < 1:
                raise ValueError("aiostreams_max_concurrent must be at least 1")
            candidate["aiostreams_max_concurrent"] = v

        if "aiostreams_min_interval_ms" in candidate:
            try:
                v = float(candidate["aiostreams_min_interval_ms"])
            except (TypeError, ValueError):
                raise ValueError("aiostreams_min_interval_ms must be a number")
            if v < 0:
                raise ValueError("aiostreams_min_interval_ms cannot be negative")
            candidate["aiostreams_min_interval_ms"] = int(v) if v == int(v) else v

        for key in ("radarr_url", "radarr_api_key", "sonarr_url", "sonarr_api_key"):
            if key in candidate:
                v = candidate[key]
                if not isinstance(v, str):
                    raise ValueError(f"{key} must be a string")
                candidate[key] = v.strip().rstrip("/") if key.endswith("_url") else v.strip()

        if "pending_movies_enabled" in candidate:
            candidate["pending_movies_enabled"] = bool(candidate["pending_movies_enabled"])

        if "pending_movies_retry_days" in candidate:
            try:
                v = float(candidate["pending_movies_retry_days"])
            except (TypeError, ValueError):
                raise ValueError("pending_movies_retry_days must be a number")
            if v < 0:
                raise ValueError("pending_movies_retry_days cannot be negative")
            candidate["pending_movies_retry_days"] = int(v) if v == int(v) else v

        _settings = candidate
        path = _settings_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(_settings, indent=2))
        except Exception as exc:
            logger.warning("Could not persist settings to %s: %s", path, exc)
        return dict(_settings)
