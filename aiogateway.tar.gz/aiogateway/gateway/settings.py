"""
gateway/settings.py
~~~~~~~~~~~~~~~~~~~
Persisted, runtime-mutable settings (as opposed to env vars, which are
fixed at container start). Stored as a small JSON file alongside the
library data so changes survive restarts.

Currently holds:
  active_ttl_minutes — how long a resolved (ACTIVE) stub stays active
                       before automatically reverting to a stub/placeholder.
                       0 disables the TTL entirely (stays active forever,
                       the original behaviour).
"""
from __future__ import annotations

import json
import logging
import os
import threading
from pathlib import Path
from typing import Any

logger = logging.getLogger("aiogateway.settings")

_DEFAULTS = {
    # Minutes a resolved stub stays ACTIVE before automatically reverting
    # to PLACEHOLDER. 0 = never expire (matches original behaviour).
    "active_ttl_minutes": 0,
}

_lock = threading.Lock()
_settings: dict[str, Any] = dict(_DEFAULTS)
_loaded = False


def _settings_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    # Store next to the mountpoint's parent (the project dir), not inside
    # the virtual FUSE filesystem itself — settings must persist independent
    # of whatever stubs exist, and the FUSE tree has no real backing file.
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_settings.json"


def load() -> dict:
    """Load settings from disk once. Safe to call repeatedly."""
    global _settings, _loaded
    with _lock:
        if _loaded:
            return dict(_settings)
        path = _settings_path()
        try:
            if path.exists():
                on_disk = json.loads(path.read_text())
                _settings = {**_DEFAULTS, **on_disk}
                logger.info("Loaded settings from %s: %s", path, _settings)
            else:
                _settings = dict(_DEFAULTS)
        except Exception as exc:
            logger.warning("Could not load settings from %s: %s — using defaults", path, exc)
            _settings = dict(_DEFAULTS)
        _loaded = True
        return dict(_settings)


def get_all() -> dict:
    if not _loaded:
        load()
    with _lock:
        return dict(_settings)


def get(key: str, default=None):
    if not _loaded:
        load()
    with _lock:
        return _settings.get(key, default)


def update(patch: dict) -> dict:
    """Merge `patch` into settings, validate, and persist to disk."""
    if not _loaded:
        load()
    with _lock:
        candidate = {**_settings, **patch}

        # Validation
        ttl = candidate.get("active_ttl_minutes", 0)
        try:
            ttl = int(ttl)
        except (TypeError, ValueError):
            raise ValueError("active_ttl_minutes must be an integer")
        if ttl < 0:
            raise ValueError("active_ttl_minutes cannot be negative")
        candidate["active_ttl_minutes"] = ttl

        _settings = candidate
        path = _settings_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(_settings, indent=2))
        except Exception as exc:
            logger.warning("Could not persist settings to %s: %s", path, exc)
        return dict(_settings)
