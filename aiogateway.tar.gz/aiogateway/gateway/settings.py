"""
gateway/settings.py
~~~~~~~~~~~~~~~~~~~
Persisted, runtime-mutable settings (as opposed to env vars, which are
fixed at container start). Stored as a small JSON file alongside the
library data so changes survive restarts.

See _DEFAULTS below for every key and what it does.
"""
from __future__ import annotations

import json
import logging
import os
import threading
from pathlib import Path
from typing import Any

logger = logging.getLogger("aiogateway.settings")

_DEFAULTS = {
    # ── Release selection ────────────────────────────────────────────────────
    # Applied to TorBox search results (cached torrents only). The built-in
    # order prefers higher resolution, better source (Remux > BluRay > WEB-DL
    # > WEBRip > HDTV), torrents already in your account, and more seeders;
    # these preferences rank above that.
    "preferred_language": "",        # e.g. "English" — ranked first when tagged in the release name
    "preferred_audio": [],           # e.g. ["Atmos", "TrueHD"] — ranked up when tagged
    "prefer_season_packs": True,     # one pack covers a whole season: fewer torrent adds
    # Hard filters: releases matching these are never added.
    "exclude_words": [],             # whole-word, case-insensitive, e.g. ["CAM", "TS", "TELESYNC"]
    "min_size_gb": 0,                # 0 = no bound
    "max_size_gb": 0,                # 0 = no bound
    # Only add a 4K version when at least this many cached 4K releases exist.
    "min_4k_candidates": 1,

    # ── Auto new-episode discovery ───────────────────────────────────────────
    # Checks every series in the library for newly-aired episodes and adds
    # them as soon as a cached torrent exists (HD, plus 4K when available).
    "auto_episodes_enabled": True,
    "auto_episodes_interval_minutes": 10,
    "auto_episodes_retry_days": 3,   # stop automatic retries for an aired episode after this

    # ── Pending movies ───────────────────────────────────────────────────────
    # Movies with nothing cached on TorBox yet (commonly: not released) are
    # tracked and retried on the auto-episode schedule until one is.
    "pending_movies_enabled": True,
    "pending_movies_retry_days": 30,
    # Don't search until this many days after the theatrical release date
    # (Cinemeta has no digital release date) — avoids early cam/TS releases.
    "digital_release_delay_days": 21,

    # ── Library repair ───────────────────────────────────────────────────────
    # How often entries whose TorBox file stopped working, and unbound
    # records from restored backups, are re-checked / rebound. A failed read
    # or a Plex play of a broken item wakes the loop immediately.
    "repair_interval_minutes": 10,

    # ── Spot check ───────────────────────────────────────────────────────────
    "spot_check_interval_hours": 0,          # 0 = manual only
    "spot_check_scheduled_scope": "both",    # "both" | "movies" | "series"
    # Also replace entries whose file name clearly shows the wrong quality
    # (e.g. filed as 4K but the file is 1080p).
    "spot_check_verify_quality": True,

    # ── AIOStreams (release search) ─────────────────────────────────────────
    # Set from Config → Connections (tested before saving). Override the
    # AIOSTREAMS_URL / _UUID / _PASSWORD environment variables. When not set,
    # TorBox's own search API is used instead. UUID and password are never
    # returned by GET /api/settings.
    "aiostreams_url": "",
    "aiostreams_uuid": "",
    "aiostreams_password": "",
    "aiostreams_per_minute": 30,        # AIOStreams fans each query out to all your addons
    "aiostreams_timeout_seconds": 60,

    # ── TorBox account ───────────────────────────────────────────────────────
    # Set from Config → Connections (validated against TorBox before it's
    # saved). Overrides TORBOX_API_KEY from the environment when non-empty.
    # Never returned by GET /api/settings.
    "torbox_api_key": "",

    # ── TorBox API saver (warpbox-style) ─────────────────────────────────────
    # Every TorBox call waits on one shared limiter; reads for playback jump
    # the queue ahead of adds, scans, repair and migration. TorBox allows
    # 300 req/min on the main API. All values apply live.
    "torbox_requests_per_minute":   250,
    "torbox_search_per_minute":     120,   # search-api.torbox.app (separate host)
    "torbox_create_per_hour":       60,    # adding torrents is limited much harder
    "torbox_429_backoff_seconds":   30,    # pause the lane after TorBox answers 429
    "torbox_max_candidates":        3,     # cached releases tried per add/repair
    # Caches
    "torbox_cdn_url_ttl_minutes":   120,   # TorBox CDN links expire after a few hours
    "torbox_cdn_repair_retries":    2,     # in-place link refreshes per read on 403/404/410
    "torbox_search_cache_minutes":  360,   # search results reused by rescans/spot checks
    "torbox_search_empty_cache_minutes": 30,   # "nothing cached yet" re-checked sooner
    "torbox_negative_cache_seconds": 30,   # remember a failed link fetch briefly
    "torbox_uncached_negative_hours": 6,   # remember "not cached on TorBox" longer
    "torbox_sync_minutes":          15,    # mirror the account's torrent list
    "torbox_list_page_size":        1000,
    # Circuit breaker (per torrent)
    "torbox_breaker_failures":      5,
    "torbox_breaker_window_seconds": 600,
    "torbox_breaker_stale_minutes": 5,
    "torbox_breaker_max_stale_minutes": 60,
    # Hold a Plex read while TorBox is rate limiting instead of failing it
    "torbox_hang_max_seconds":      120,
    # Probe cache: first/last MB of every file kept on disk so Plex scans
    # and analysis never cost CDN traffic or API calls twice
    "probe_cache_enabled":          True,
    "probe_cache_head_mb":          16,
    "probe_cache_tail_mb":          16,
    "probe_cache_max_mb":           4096,

    # ── Radarr/Sonarr migration ──────────────────────────────────────────────
    "radarr_url":     "",
    "radarr_api_key": "",
    "sonarr_url":     "",
    "sonarr_api_key": "",
}

# Keys from earlier versions (AIOStreams / placeholder design). Stripped from
# the settings file on load and ignored in updates.
_LEGACY_KEYS = (
    "aiostreams_max_concurrent", "aiostreams_min_interval_ms",
    "active_ttl_days", "active_ttl_minutes", "prewarm_new_releases_days",
    "prewarm_interval_hours", "plex_analyze_cooldown_hours", "dead_stub_max_errors",
    "require_subtitles", "torbox_only_cached",
)

_lock = threading.Lock()
_settings: dict[str, Any] = dict(_DEFAULTS)
_loaded = False


def _settings_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    # Stored next to the mountpoint (the project dir), never inside the
    # read-only virtual FUSE tree.
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_settings.json"


def _migrate(data: dict) -> dict:
    for key in _LEGACY_KEYS:
        data.pop(key, None)
    return data


def load() -> dict:
    """Load settings from disk once. Safe to call repeatedly."""
    global _settings, _loaded
    with _lock:
        if _loaded:
            return dict(_settings)
        path = _settings_path()
        try:
            if path.exists():
                on_disk = _migrate(json.loads(path.read_text()))
                _settings = {**_DEFAULTS, **on_disk}
                logger.info("Loaded settings from %s: %s", path, _settings)
            else:
                _settings = dict(_DEFAULTS)
        except Exception as exc:
            logger.warning("Could not load settings from %s: %s — using defaults", path, exc)
            _settings = dict(_DEFAULTS)
        _loaded = True
        return dict(_settings)


def get_all() -> dict:
    if not _loaded:
        load()
    with _lock:
        return dict(_settings)


def get(key: str, default=None):
    if not _loaded:
        load()
    with _lock:
        return _settings.get(key, default)


def update(patch: dict) -> dict:
    """Merge `patch` into settings, validate, and persist to disk."""
    global _settings
    if not _loaded:
        load()
    with _lock:
        candidate = {**_settings, **patch}

        # Validation — stream preferences
        if "preferred_language" in candidate:
            v = candidate["preferred_language"]
            if not isinstance(v, str):
                raise ValueError("preferred_language must be a string")
            candidate["preferred_language"] = v.strip()

        if "preferred_audio" in candidate:
            v = candidate["preferred_audio"]
            if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
                raise ValueError("preferred_audio must be a list of strings")
            candidate["preferred_audio"] = [x.strip() for x in v if x.strip()]

        if "exclude_words" in candidate:
            v = candidate["exclude_words"]
            if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
                raise ValueError("exclude_words must be a list of strings")
            candidate["exclude_words"] = [x.strip() for x in v if x.strip()]

        if "min_4k_candidates" in candidate:
            try:
                v = int(candidate["min_4k_candidates"])
            except (TypeError, ValueError):
                raise ValueError("min_4k_candidates must be an integer")
            if v < 1:
                raise ValueError("min_4k_candidates must be at least 1")
            candidate["min_4k_candidates"] = v

        if "prefer_season_packs" in candidate:
            candidate["prefer_season_packs"] = bool(candidate["prefer_season_packs"])

        if "spot_check_interval_hours" in candidate:
            try:
                v = float(candidate["spot_check_interval_hours"])
            except (TypeError, ValueError):
                raise ValueError("spot_check_interval_hours must be a number")
            if v < 0:
                raise ValueError("spot_check_interval_hours cannot be negative")
            candidate["spot_check_interval_hours"] = int(v) if v == int(v) else v

        if "spot_check_scheduled_scope" in candidate:
            v = candidate["spot_check_scheduled_scope"]
            if v not in ("both", "movies", "series"):
                raise ValueError("spot_check_scheduled_scope must be 'both', 'movies', or 'series'")
            candidate["spot_check_scheduled_scope"] = v

        if "spot_check_verify_quality" in candidate:
            candidate["spot_check_verify_quality"] = bool(candidate["spot_check_verify_quality"])

        for key in ("min_size_gb", "max_size_gb"):
            if key in candidate:
                try:
                    v = float(candidate[key])
                except (TypeError, ValueError):
                    raise ValueError(f"{key} must be a number")
                if v < 0:
                    raise ValueError(f"{key} cannot be negative")
                candidate[key] = int(v) if v == int(v) else v

        min_gb = candidate.get("min_size_gb", 0) or 0
        max_gb = candidate.get("max_size_gb", 0) or 0
        if min_gb and max_gb and min_gb > max_gb:
            raise ValueError("min_size_gb cannot be greater than max_size_gb")

        # Validation — auto episode discovery
        if "auto_episodes_enabled" in candidate:
            candidate["auto_episodes_enabled"] = bool(candidate["auto_episodes_enabled"])

        if "auto_episodes_interval_minutes" in candidate:
            try:
                v = int(candidate["auto_episodes_interval_minutes"])
            except (TypeError, ValueError):
                raise ValueError("auto_episodes_interval_minutes must be an integer")
            if v < 5:
                raise ValueError("auto_episodes_interval_minutes must be at least 5")
            candidate["auto_episodes_interval_minutes"] = v

        if "auto_episodes_retry_days" in candidate:
            try:
                v = float(candidate["auto_episodes_retry_days"])
            except (TypeError, ValueError):
                raise ValueError("auto_episodes_retry_days must be a number")
            if v < 0:
                raise ValueError("auto_episodes_retry_days cannot be negative")
            candidate["auto_episodes_retry_days"] = int(v) if v == int(v) else v

        _int_bounds = {
            "torbox_requests_per_minute": (10, 300), "torbox_search_per_minute": (1, 300),
            "torbox_create_per_hour": (1, 1000), "torbox_max_candidates": (1, 10),
            "repair_interval_minutes": (1, 1440),
            "aiostreams_per_minute": (1, 300), "aiostreams_timeout_seconds": (5, 300),
            "torbox_cdn_repair_retries": (0, 5), "torbox_sync_minutes": (1, 1440),
            "torbox_list_page_size": (100, 10000), "torbox_breaker_failures": (1, 100),
        }
        _num_bounds = {
            "torbox_429_backoff_seconds": (1, 300), "torbox_cdn_url_ttl_minutes": (1, 1440),
            "torbox_search_cache_minutes": (0, 10080), "torbox_search_empty_cache_minutes": (0, 1440),
            "torbox_negative_cache_seconds": (1, 300), "torbox_uncached_negative_hours": (0, 168),
            "torbox_breaker_window_seconds": (10, 86400), "torbox_breaker_stale_minutes": (1, 1440),
            "torbox_breaker_max_stale_minutes": (5, 1440), "torbox_hang_max_seconds": (0, 900),
            "probe_cache_head_mb": (0, 512), "probe_cache_tail_mb": (0, 512),
            "probe_cache_max_mb": (0, 1024 * 1024),
        }
        for key, (lo, hi) in {**_int_bounds, **_num_bounds}.items():
            if key not in candidate:
                continue
            try:
                v = float(candidate[key])
            except (TypeError, ValueError):
                raise ValueError(f"{key} must be a number")
            if not lo <= v <= hi:
                raise ValueError(f"{key} must be between {lo} and {hi}")
            candidate[key] = int(v) if (key in _int_bounds or v == int(v)) else v
        for key in ("probe_cache_enabled",):
            if key in candidate:
                candidate[key] = bool(candidate[key])
        for key in _LEGACY_KEYS:
            candidate.pop(key, None)

        for key in ("torbox_api_key", "aiostreams_url", "aiostreams_uuid", "aiostreams_password",
                    "radarr_url", "radarr_api_key", "sonarr_url", "sonarr_api_key"):
            if key in candidate:
                v = candidate[key]
                if not isinstance(v, str):
                    raise ValueError(f"{key} must be a string")
                candidate[key] = v.strip().rstrip("/") if key.endswith("_url") else v.strip()

        if "pending_movies_enabled" in candidate:
            candidate["pending_movies_enabled"] = bool(candidate["pending_movies_enabled"])

        if "pending_movies_retry_days" in candidate:
            try:
                v = float(candidate["pending_movies_retry_days"])
            except (TypeError, ValueError):
                raise ValueError("pending_movies_retry_days must be a number")
            if v < 0:
                raise ValueError("pending_movies_retry_days cannot be negative")
            candidate["pending_movies_retry_days"] = int(v) if v == int(v) else v

        if "digital_release_delay_days" in candidate:
            try:
                v = float(candidate["digital_release_delay_days"])
            except (TypeError, ValueError):
                raise ValueError("digital_release_delay_days must be a number")
            if v < 0:
                raise ValueError("digital_release_delay_days cannot be negative")
            candidate["digital_release_delay_days"] = int(v) if v == int(v) else v

        _settings = candidate
        path = _settings_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(_settings, indent=2))
        except Exception as exc:
            logger.warning("Could not persist settings to %s: %s", path, exc)
        return dict(_settings)
