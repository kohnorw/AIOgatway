"""
gateway/settings.py
~~~~~~~~~~~~~~~~~~~
Persisted, runtime-mutable settings (as opposed to env vars, which are
fixed at container start). Stored as a small JSON file alongside the
library data so changes survive restarts.

Currently holds:
  active_ttl_days — how long a resolved (ACTIVE) stub stays active before
                    automatically reverting to a stub/placeholder. 0
                    disables the TTL entirely (stays active forever, the
                    original behaviour).
"""
from __future__ import annotations

import json
import logging
import os
import threading
from pathlib import Path
from typing import Any

logger = logging.getLogger("aiogateway.settings")

_DEFAULTS = {
    # Days a resolved stub stays ACTIVE before automatically reverting
    # to PLACEHOLDER. 0 = never expire (matches original behaviour).
    "active_ttl_days": 0,
}

_lock = threading.Lock()
_settings: dict[str, Any] = dict(_DEFAULTS)
_loaded = False


def _settings_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    # Store next to the mountpoint's parent (the project dir), not inside
    # the virtual FUSE filesystem itself — settings must persist independent
    # of whatever stubs exist, and the FUSE tree has no real backing file.
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_settings.json"


def _migrate(data: dict) -> dict:
    """
    One-time migration: earlier versions stored active_ttl_minutes instead
    of active_ttl_days. Convert it if present and the new key is missing,
    so existing settings files don't silently lose the configured value.
    """
    if "active_ttl_days" not in data and "active_ttl_minutes" in data:
        try:
            old_minutes = int(data.pop("active_ttl_minutes"))
            # Round up so a previously-configured non-zero TTL doesn't
            # collapse to 0 days and silently become "never expire".
            data["active_ttl_days"] = max(1, -(-old_minutes // 1440)) if old_minutes > 0 else 0
            logger.info("Migrated active_ttl_minutes=%d → active_ttl_days=%d",
                       old_minutes, data["active_ttl_days"])
        except (TypeError, ValueError):
            data.pop("active_ttl_minutes", None)
    return data


def load() -> dict:
    """Load settings from disk once. Safe to call repeatedly."""
    global _settings, _loaded
    with _lock:
        if _loaded:
            return dict(_settings)
        path = _settings_path()
        try:
            if path.exists():
                on_disk = _migrate(json.loads(path.read_text()))
                _settings = {**_DEFAULTS, **on_disk}
                logger.info("Loaded settings from %s: %s", path, _settings)
            else:
                _settings = dict(_DEFAULTS)
        except Exception as exc:
            logger.warning("Could not load settings from %s: %s — using defaults", path, exc)
            _settings = dict(_DEFAULTS)
        _loaded = True
        return dict(_settings)


def get_all() -> dict:
    if not _loaded:
        load()
    with _lock:
        return dict(_settings)


def get(key: str, default=None):
    if not _loaded:
        load()
    with _lock:
        return _settings.get(key, default)


def update(patch: dict) -> dict:
    """Merge `patch` into settings, validate, and persist to disk."""
    global _settings
    if not _loaded:
        load()
    with _lock:
        candidate = {**_settings, **patch}

        # Validation
        ttl = candidate.get("active_ttl_days", 0)
        try:
            ttl = float(ttl)
        except (TypeError, ValueError):
            raise ValueError("active_ttl_days must be a number")
        if ttl < 0:
            raise ValueError("active_ttl_days cannot be negative")
        # Store as int when it's a whole number for a cleaner JSON file /
        # API response, otherwise keep the fraction (e.g. 0.5 = 12 hours).
        candidate["active_ttl_days"] = int(ttl) if ttl == int(ttl) else ttl

        _settings = candidate
        path = _settings_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(_settings, indent=2))
        except Exception as exc:
            logger.warning("Could not persist settings to %s: %s", path, exc)
        return dict(_settings)
