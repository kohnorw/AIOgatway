"""
gateway/settings.py
~~~~~~~~~~~~~~~~~~~
Preferences the user changes from the Config page. Nothing secret lives
here — credentials are in gateway/config.py, encrypted.
"""
from __future__ import annotations

import json
import logging
import os
import threading
from typing import Any

from .paths import settings_file

logger = logging.getLogger("aiogateway.settings")

DEFAULTS: dict[str, Any] = {
    # ── Stream preferences ──────────────────────────────────────────
    # Applied on top of whatever AIOStreams returns. Its own filters and
    # sort order, set in its configure page, still run first.
    "preferred_language": "",
    "preferred_audio": [],
    "prefer_subtitles": False,
    "exclude_words": [],
    "min_size_gb": 0,
    "max_size_gb": 0,
    "prefer_packs": True,
    "allow_usenet": True,
    "min_4k_sources": 4,

    # ── Cache checking ──────────────────────────────────────────────
    "cached_only": True,
    "verify_cache_with_debrid": True,
    # How many hashes one search will ask a provider about. The list
    # arrives best-first, so a cached result usually turns up in the
    # first few; probing everything spends the rate budget producing a
    # cache census nobody reads.
    "debrid_max_probe": 12,
    "debrid_cache_ttl_seconds": 300,
    # Drop candidates nobody could give a verdict on. Off by default:
    # on a setup where no addon reports cache state and no hash is
    # exposed, turning this on empties the candidate list entirely.
    "drop_unknown_cache": False,

    # ── AllDebrid probe behaviour ───────────────────────────────────
    "alldebrid_probe_chunk": 10,
    "alldebrid_stop_on_hit": True,
    "alldebrid_delete_probes": True,

    # ── AIOStreams pacing ───────────────────────────────────────────
    "aiostreams_max_concurrent": 1,
    "aiostreams_min_interval_ms": 1500,

    # ── Repair ──────────────────────────────────────────────────────
    "repair_enabled": True,
    # "daily" runs at each time in repair_times; "interval" runs every
    # repair_interval_hours starting from the first entry in repair_times.
    "repair_mode": "daily",
    "repair_times": ["04:00"],
    "repair_interval_hours": 6,
    # Repair works in batches so a large library doesn't fire thousands
    # of probes at once, and so playback always has bandwidth spare.
    "repair_batch_size": 40,
    "repair_pause_on_playback": True,
    # A file that fails this many repair passes in a row is treated as
    # having no working source and removed, so it stops appearing in
    # Plex as something that can be played but never starts.
    "repair_max_failures": 5,

    # ── New episode discovery ───────────────────────────────────────
    "auto_episodes_enabled": True,
    "auto_episodes_interval_minutes": 30,
    "auto_episodes_retry_days": 7,
    # Per sweep, don't reach more than this many episodes past the
    # highest one already in a season. A show left unchecked for a while
    # then catches up gradually instead of firing a whole backlog of
    # searches at AIOStreams in one pass.
    "episode_lookahead": 3,

    # ── Pending films ───────────────────────────────────────────────
    # A film that can't be found when it's asked for is tracked and
    # retried rather than the request just failing.
    "pending_movies_enabled": True,
    # Films can sit unavailable for a while after release, so this is
    # longer than the episode equivalent.
    "pending_movies_retry_days": 30,
    # Wait this long after the cinema release date before searching at
    # all. Metadata only carries the theatrical date, never the digital
    # one, so this is a rough guard against picking up a camrip in the
    # gap between the two rather than an exact check. 0 searches as soon
    # as the theatrical date passes.
    "digital_release_delay_days": 21,

    # ── Plex ────────────────────────────────────────────────────────
    "plex_analyze_cooldown_hours": 24,

    # ── Users ───────────────────────────────────────────────────────
    "users_page_size": 25,

    # ── FUSE tuning ─────────────────────────────────────────────────
    # Read live by the filesystem, so these take effect on the next read
    # rather than needing a container restart.
    #
    # block_mb x cache_blocks is roughly the memory ceiling for cached
    # video: 8 x 64 is about 512MB. Raising the block size helps
    # sequential playback and hurts seeking, since every seek pulls a
    # whole block.
    "fuse_block_mb": 8,
    "fuse_cache_blocks": 64,
    "fuse_prefetch_ahead": 4,
    "fuse_read_timeout": 15,
    "fuse_max_inflight": 12,
    "fuse_pool_maxsize": 20,
    # How long a read waits when a play-triggered link fetch is already
    # under way, before giving up and serving header bytes.
    "fuse_activation_wait": 20,
}

_lock = threading.Lock()
_cache: dict[str, Any] = dict(DEFAULTS)
_loaded = False


def load() -> dict[str, Any]:
    global _loaded
    with _lock:
        if _loaded:
            return dict(_cache)
        path = settings_file()
        if path.exists():
            try:
                stored = json.loads(path.read_text())
                # Only keys we still recognise — a setting removed in a
                # later version shouldn't linger in the file or come back
                # out of the API as if it still did something.
                _cache.update({k: v for k, v in stored.items() if k in DEFAULTS})
            except Exception as exc:
                logger.error("settings.json unreadable (%s) — using defaults", exc)
        _loaded = True
        return dict(_cache)


def _persist() -> None:
    path = settings_file()
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(_cache, indent=2))
    os.replace(tmp, path)


def get(key: str, default: Any = None) -> Any:
    load()
    with _lock:
        return _cache.get(key, DEFAULTS.get(key, default))


def all_settings() -> dict[str, Any]:
    return load()


def update(patch: dict[str, Any]) -> dict[str, Any]:
    load()
    with _lock:
        for key, value in patch.items():
            if key in DEFAULTS:
                _cache[key] = value
        _persist()
        return dict(_cache)
