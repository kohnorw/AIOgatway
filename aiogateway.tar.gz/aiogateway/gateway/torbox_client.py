"""
gateway/torbox_client.py
~~~~~~~~~~~~~~~~~~~~~~~~
TorBox-only stream source. Drop-in replacement for the old AIOStreamsClient
(same public methods), so every caller — adds, background scans, auto-episode
discovery, spot check, migration, the webhook — works unchanged.

How a title becomes a stream
----------------------------
  1. SEARCH   AIOStreams (your addons, filters and sorting) by IMDb id
              (+ season/episode); torrent results carry an infoHash. Falls
              back to search-api.torbox.app if AIOStreams isn't set up.
              Results are cached in SQLite (hours), so rescans, spot checks
              and the candidate picker don't re-query.        → 0-1 calls
  2. PICK     rank by resolution/source/preferences — no network.
  3. BIND     at add time: add the cached torrent to the account
              (add_only_if_cached), read its file list, pin the file.
              Torrents already in the account — e.g. the season pack the
              previous episode came from — are preferred and cost nothing.
                                                              → 0-2 API calls
  4. LINK     first read: requestdl → CDN URL, cached in SQLite for its
              lifetime and single-flighted.                   → 0-1 API calls

No placeholders
---------------
A library entry is only created once it is BOUND: the torrent is cached on
TorBox, present in the account, and the exact file is known. Every entry Plex
sees is therefore a real, playable file from the first scan. Binding happens
at add time (add torrent + read its file list); the CDN link itself is only
requested on the first read.

Stable stream refs
------------------
A bound entry stores a stable ref instead of a CDN URL (those expire):

    torbox://<infohash>/<file_id>/<url-quoted filename>

The FUSE layer turns the ref into a CDN URL through the cache on demand and
repairs it in place when it expires. Search candidates that aren't bound yet
use the query form ``torbox://<infohash>?s=1&e=2``.
"""
from __future__ import annotations

import asyncio
import logging
import re
from typing import Optional
from urllib.parse import parse_qs, quote, unquote, urlsplit

import requests

from . import torbox_api as tb
from . import torbox_guard as guard
from .models import AIOStream, MediaItem, MediaType, ParsedFile, Quality

log = logging.getLogger("aiogateway.torbox")

REF_SCHEME = "torbox://"


class AllCandidatesDeadError(Exception):
    """Every candidate that was tried definitively failed (not cached, no
    matching file, dead link). Distinct from a transient TorBox problem,
    which raises TorBoxUnavailableError instead so callers never delete a
    stub just because TorBox was briefly rate limiting."""
    def __init__(self, count: int):
        self.count = count
        super().__init__(f"All {count} candidate(s) were dead")


class TorBoxUnavailableError(RuntimeError):
    pass


class FileNotInTorrent(Exception):
    pass


def _setting(key, default):
    return guard._setting(key, default)


# ─────────────────────────────────────────────────────────────────────────────
# Refs
# ─────────────────────────────────────────────────────────────────────────────

def provider_of(url: Optional[str]) -> Optional[str]:
    """Which debrid service a ref belongs to, from its scheme."""
    if not url:
        return None
    if url.startswith(REF_SCHEME):
        return "torbox"
    if url.startswith(_ad_client().REF_SCHEME):
        return "alldebrid"
    return None


def _ad_client():
    from . import alldebrid_client
    return alldebrid_client


def is_ref(url: Optional[str]) -> bool:
    """True for a ref of ANY configured provider — callers (FUSE, the proxy,
    the repair loop, stub_manager) stay provider-agnostic."""
    return provider_of(url) is not None


def is_torbox_ref(url: Optional[str]) -> bool:
    return bool(url) and url.startswith(REF_SCHEME)


def make_ref(h: str, file_id: int, name: str) -> str:
    return f"{REF_SCHEME}{h.lower()}/{int(file_id)}/{quote(name or '', safe='')}"


def make_query_ref(h: str, season: Optional[int], episode: Optional[int], name: str = "") -> str:
    q = []
    if season is not None:
        q.append(f"s={season}")
    if episode is not None:
        q.append(f"e={episode}")
    if name:
        q.append(f"name={quote(name, safe='')}")
    return f"{REF_SCHEME}{h.lower()}" + (("?" + "&".join(q)) if q else "")


def parse_ref(url: str) -> dict:
    parts = urlsplit(url)
    h = parts.netloc.lower()
    segs = [s for s in parts.path.split("/") if s]
    qs = parse_qs(parts.query)
    out = {"hash": h, "file_id": None, "name": "", "season": None, "episode": None}
    if segs:
        try:
            out["file_id"] = int(segs[0])
        except ValueError:
            pass
        if len(segs) > 1:
            out["name"] = unquote("/".join(segs[1:]))
    if "s" in qs:
        out["season"] = int(qs["s"][0])
    if "e" in qs:
        out["episode"] = int(qs["e"][0])
    if "name" in qs and not out["name"]:
        out["name"] = unquote(qs["name"][0])
    return out


def ref_hash(url: Optional[str]) -> Optional[str]:
    return parse_ref(url)["hash"] if is_ref(url) else None


def _cdn_key(h: str, name: str, file_id) -> str:
    base = name.rsplit("/", 1)[-1] if name else f"id{file_id}"
    return f"{h.lower()}:{base}"


# ─────────────────────────────────────────────────────────────────────────────
# Release-name parsing (replaces AIOStreams' parsedFile)
# ─────────────────────────────────────────────────────────────────────────────

_RES = [
    ("2160p", re.compile(r"(?i)\b(2160p|4k|uhd)\b")),
    ("1440p", re.compile(r"(?i)\b1440p\b")),
    ("1080p", re.compile(r"(?i)\b1080[pi]\b")),
    ("720p",  re.compile(r"(?i)\b720p\b")),
    ("480p",  re.compile(r"(?i)\b(480p|576p|sd)\b")),
]
_SOURCES = [
    ("REMUX",  re.compile(r"(?i)\bremux\b"), 6),
    ("BluRay", re.compile(r"(?i)\b(blu-?ray|bdrip|brrip)\b"), 5),
    ("WEB-DL", re.compile(r"(?i)\bweb-?dl\b"), 4),
    ("WEBRip", re.compile(r"(?i)\bweb-?rip\b|\bweb\b"), 3),
    ("HDTV",   re.compile(r"(?i)\bhdtv\b"), 2),
    ("DVDRip", re.compile(r"(?i)\bdvd-?rip\b"), 1),
    ("CAM",    re.compile(r"(?i)\b(cam|hdcam|camrip)\b"), -5),
    ("TS",     re.compile(r"(?i)\b(ts|telesync|hdts)\b"), -5),
    ("SCR",    re.compile(r"(?i)\b(screener|scr|dvdscr)\b"), -4),
]
_ENCODES = [("AV1", r"\bav1\b"), ("HEVC", r"\b(x265|h\.?265|hevc)\b"), ("AVC", r"\b(x264|h\.?264|avc)\b")]
_HDR = [("DV", r"\b(dv|dovi|dolby[ ._-]?vision)\b"), ("HDR10+", r"\bhdr10(\+|plus)\b"),
        ("HDR10", r"\bhdr10\b"), ("HDR", r"\bhdr\b")]
_AUDIO = [("Atmos", r"\batmos\b"), ("TrueHD", r"\btruehd\b"), ("DTS-HD MA", r"\bdts-?hd[ ._-]?ma\b"),
          ("DTS", r"\bdts\b"), ("DD+", r"\b(ddp|dd\+|eac3|e-ac-3)\b"), ("DD", r"\b(dd|ac3)\b"),
          ("AAC", r"\baac\b")]
_CHANNELS = re.compile(r"\b([257]\.1|2\.0)\b")
_LANGS = {"English": r"\b(eng|english)\b", "French": r"\b(fre|french|vff|truefrench)\b",
          "Spanish": r"\b(spa|spanish|latino|castellano)\b", "German": r"\b(ger|german)\b",
          "Italian": r"\b(ita|italian)\b", "Japanese": r"\b(jpn|japanese)\b",
          "Hindi": r"\b(hin|hindi)\b", "Russian": r"\b(rus|russian)\b",
          "Portuguese": r"\b(por|portuguese|dublado)\b", "Korean": r"\b(kor|korean)\b",
          "Multi": r"\b(multi|dual[ ._-]?audio)\b"}


def parse_release(name: str) -> tuple[ParsedFile, int]:
    """Returns (ParsedFile, source_rank)."""
    n = name or ""
    res = next((label for label, rx in _RES if rx.search(n)), None)
    src, src_rank = None, 0
    for label, rx, rank in _SOURCES:
        if rx.search(n):
            src, src_rank = label, rank
            break
    enc = next((l for l, p in _ENCODES if re.search(p, n, re.I)), None)
    hdr = [l for l, p in _HDR if re.search(p, n, re.I)]
    if "HDR10+" in hdr or "HDR10" in hdr:
        hdr = [h for h in hdr if h != "HDR"]
    if "HDR10+" in hdr:
        hdr = [h for h in hdr if h != "HDR10"]
    audio = [l for l, p in _AUDIO if re.search(p, n, re.I)]
    if "DTS-HD MA" in audio:
        audio = [a for a in audio if a != "DTS"]
    if "DD+" in audio:
        audio = [a for a in audio if a != "DD"]
    langs = [l for l, p in _LANGS.items() if re.search(p, n, re.I)]
    return ParsedFile(
        resolution=res, quality=src, encode=enc, hdr=hdr or None,
        languages=langs or None, audio_tags=audio or None,
        audio_channels=_CHANNELS.findall(n) or None,
    ), src_rank


# ─────────────────────────────────────────────────────────────────────────────
# Filters / ranking (same settings semantics as before)
# ─────────────────────────────────────────────────────────────────────────────

def _filter_by_size(streams: list[AIOStream]) -> list[AIOStream]:
    min_gb = _setting("min_size_gb", 0) or 0
    max_gb = _setting("max_size_gb", 0) or 0
    if not min_gb and not max_gb:
        return streams
    lo = min_gb * 1024 ** 3
    hi = max_gb * 1024 ** 3 if max_gb else None
    return [s for s in streams if not s.size or ((not lo or s.size >= lo) and (hi is None or s.size <= hi))]


_EXCL_CACHE: dict = {}


def _filter_by_exclude_words(streams: list[AIOStream]) -> list[AIOStream]:
    words = [w.strip().lower() for w in (_setting("exclude_words", []) or []) if w.strip()]
    if not words:
        return streams
    pats = []
    for w in words:
        if w not in _EXCL_CACHE:
            _EXCL_CACHE[w] = re.compile(rf"(?<![a-z0-9]){re.escape(w)}(?![a-z0-9])")
        pats.append(_EXCL_CACHE[w])
    out = []
    for s in streams:
        pf = s.parsed_file
        hay = " ".join([s.filename or "", (pf.quality or "") if pf else "",
                        (pf.resolution or "") if pf else "", (pf.encode or "") if pf else ""]).lower()
        if not any(p.search(hay) for p in pats):
            out.append(s)
    return out


_RES_RANK = {"2160p": 5, "1440p": 4, "1080p": 3, "720p": 2, "480p": 1}


def _in_account(h: Optional[str], service: str = "torbox") -> bool:
    """Is this hash already in the account of the service that would serve
    it? Already-present torrents cost nothing to bind, so they rank up."""
    try:
        if service == "alldebrid":
            return _ad_client().in_account(h)
        return bool(h) and guard.store().get_torrent(h) is not None
    except Exception:
        return False


def _rank(streams: list[AIOStream]) -> list[AIOStream]:
    pref_lang    = (_setting("preferred_language", "") or "").lower()
    pref_audio   = [a.lower() for a in (_setting("preferred_audio", []) or [])]
    prefer_packs = bool(_setting("prefer_season_packs", True))
    pref_service = (_setting("preferred_debrid", "torbox") or "torbox").lower()

    def score(s: AIOStream):
        pf = s.parsed_file
        langs = [l.lower() for l in (pf.languages or [])] if pf else []
        tags  = [a.lower() for a in (pf.audio_tags or [])] if pf else []
        pack_kind, _ = s.pack_type
        return (
            1 if pref_lang and pref_lang in langs else 0,
            1 if prefer_packs and pack_kind in ("season", "series") else 0,
            sum(1 for a in pref_audio if any(a in t for t in tags)),
            {True: 2, None: 1, False: 0}[s.cached],
            _RES_RANK.get((pf.resolution if pf else "") or "", 0),
            1 if (s.service or "").lower() == pref_service else 0,
            1 if _in_account(getattr(s, "_hash", None), s.service or "torbox") else 0,
            getattr(s, "_source_rank", 0),
            getattr(s, "_seeders", 0),
            s.size or 0,
        )

    return sorted(streams, key=score, reverse=True)


# ─────────────────────────────────────────────────────────────────────────────
# File selection inside a torrent
# ─────────────────────────────────────────────────────────────────────────────

_VIDEO = re.compile(r"(?i)\.(mkv|mp4|m4v|avi|mov|ts|m2ts|webm|wmv)$")
_MIN_MEDIA = 50 * 1024 * 1024


def _episode_patterns(season: int, episode: int) -> list[re.Pattern]:
    return [
        re.compile(rf"(?i)\bs0*{season}[ ._-]?e0*{episode}(?!\d)"),
        re.compile(rf"(?i)\bs0*{season}(?:[ ._-]?e\d+)*[ ._-]?e0*{episode}(?!\d)"),  # S01E01E02
        re.compile(rf"(?i)(?<!\d){season}x0*{episode}(?!\d)"),
        re.compile(rf"(?i)season[ ._-]?0*{season}\D+episode[ ._-]?0*{episode}(?!\d)"),
    ]


def choose_file(files: list[dict], season: Optional[int], episode: Optional[int],
                name_hint: str = "", file_id_hint: Optional[int] = None) -> dict:
    videos = [f for f in files
              if _VIDEO.search(f.get("name") or "") and "sample" not in (f.get("name") or "").lower()
              and (f.get("size") or 0) >= _MIN_MEDIA]
    if not videos:
        raise FileNotInTorrent("torrent has no playable video files")

    if name_hint:
        base = name_hint.rsplit("/", 1)[-1]
        for f in videos:
            if (f.get("name") or "").rsplit("/", 1)[-1] == base:
                return f
    if file_id_hint is not None:
        for f in videos:
            if f.get("id") == file_id_hint:
                return f

    if season is not None and episode is not None:
        pats = _episode_patterns(season, episode)
        matches = [f for f in videos if any(p.search((f.get("name") or "")) for p in pats)]
        if matches:
            return max(matches, key=lambda f: f.get("size") or 0)
        if len(videos) == 1:
            # single-episode release with an unconventional filename
            return videos[0]
        raise FileNotInTorrent(f"no file for S{season:02d}E{episode:02d} in this torrent")

    return max(videos, key=lambda f: f.get("size") or 0)


# ─────────────────────────────────────────────────────────────────────────────
# Materialize: hash → (torrent_id, files) in the account
# ─────────────────────────────────────────────────────────────────────────────

def _slim_files(raw: list[dict]) -> list[dict]:
    return [{"id": f.get("id"), "name": f.get("name") or f.get("short_name") or "",
             "size": f.get("size") or 0} for f in (raw or [])]


def ensure_in_account(h: str, priority: int) -> dict:
    """Returns the local torrent record, adding it to TorBox only if the
    account doesn't already have it."""
    st = guard.store()
    rec = st.get_torrent(h)
    if rec and rec["files"]:
        guard.stats.inc("torrent_lookup_cache_hits")
        return rec

    neg = st.get_negative(f"add:{h}")
    if neg:
        guard.stats.inc("negative_cache_hits")
        raise tb.TorBoxError(f"recently failed to add: {neg}", status=409)

    def _add():
        rec2 = st.get_torrent(h)
        if rec2 and rec2["files"]:
            return rec2
        magnet = f"magnet:?xt=urn:btih:{h}"
        try:
            data = tb.create_torrent(magnet, only_cached=True, priority=priority)
        except tb.TorBoxError as exc:
            if not exc.retryable:
                ttl = float(_setting("torbox_uncached_negative_hours", 6)) * 3600
                st.put_negative(f"add:{h}", str(exc), ttl)
            raise
        tid = data.get("torrent_id") or data.get("id")
        if not tid:
            raise tb.TorBoxError("createtorrent returned no torrent_id", status=502)
        info = tb.torrent_info(int(tid), priority=priority)
        files = _slim_files((info or {}).get("files") or [])
        if not files:
            raise tb.TorBoxError("torrent added but has no files yet (not cached?)", status=409)
        st.put_torrent(h, int(tid), (info or {}).get("name") or "", files)
        return st.get_torrent(h)

    return guard.singleflight.do(f"add:{h}", _add)


# ─────────────────────────────────────────────────────────────────────────────
# CDN URLs for refs (sync — used by FUSE threads and via to_thread)
# ─────────────────────────────────────────────────────────────────────────────

def _tb_cdn_url_for_ref(ref: str, priority: int = guard.HIGH, force_refresh: bool = False) -> str:
    info = parse_ref(ref)
    h = info["hash"]
    st = guard.store()

    rec = ensure_in_account(h, priority)
    f = choose_file(rec["files"], info["season"], info["episode"], info["name"], info["file_id"])
    key = _cdn_key(h, f["name"], f["id"])

    if force_refresh:
        st.drop_cdn(key)
    else:
        cached = st.get_cdn(key)
        if cached:
            guard.stats.inc("cdn_url_cache_hits")
            return cached

    neg = st.get_negative(f"cdn:{key}")
    if neg and not force_refresh:
        guard.stats.inc("negative_cache_hits")
        raise tb.TorBoxError(f"recent CDN URL failure: {neg}", status=503)
    if guard.breaker.is_open(h):
        raise tb.TorBoxError("torrent quarantined by circuit breaker", status=503)

    def _fetch():
        again = st.get_cdn(key)
        if again and not force_refresh:
            return again
        cur = st.get_torrent(h) or rec
        try:
            url = tb.request_download_url(cur["torrent_id"], f["id"], priority=priority)
        except tb.TorBoxError as exc:
            if not exc.retryable:
                # Most common cause: TorBox removed the torrent from the
                # account (inactivity). Forget it and re-add once.
                log.info("requestdl failed for %s… (%s) — re-adding torrent", h[:10], exc)
                st.drop_torrent(h)
                fresh = ensure_in_account(h, priority)
                ff = choose_file(fresh["files"], info["season"], info["episode"], info["name"], None)
                try:
                    url = tb.request_download_url(fresh["torrent_id"], ff["id"], priority=priority)
                except tb.TorBoxError as exc2:
                    guard.breaker.failure(h, str(exc2))
                    st.put_negative(f"cdn:{key}", str(exc2),
                                    float(_setting("torbox_negative_cache_seconds", 30)))
                    raise
            else:
                guard.breaker.failure(h, str(exc))
                st.put_negative(f"cdn:{key}", str(exc), float(_setting("torbox_negative_cache_seconds", 30)))
                raise
        guard.breaker.success(h)
        st.put_cdn(key, url, float(_setting("torbox_cdn_url_ttl_minutes", 120)) * 60)
        return url

    return guard.singleflight.do(f"cdn:{key}", _fetch)


def _tb_invalidate_ref(ref: str):
    """Forget the cached CDN URL for a TorBox ref."""
    try:
        info = parse_ref(ref)
        rec = guard.store().get_torrent(info["hash"])
        if not rec:
            return
        f = choose_file(rec["files"], info["season"], info["episode"], info["name"], info["file_id"])
        guard.store().drop_cdn(_cdn_key(info["hash"], f["name"], f["id"]))
        guard.stats.inc("cdn_url_repairs")
    except Exception:
        pass


def _tb_ref_size(ref: str) -> Optional[int]:
    try:
        info = parse_ref(ref)
        rec = guard.store().get_torrent(info["hash"])
        if not rec:
            return None
        return choose_file(rec["files"], info["season"], info["episode"], info["name"], info["file_id"]).get("size")
    except Exception:
        return None


# ── Provider dispatch ───────────────────────────────────────────────────────
# One ref in, the right backend out. Everything above this line is TorBox;
# everything below routes by scheme so a library can hold both.

def cdn_url_for_ref(ref: str, priority: int = guard.HIGH, force_refresh: bool = False) -> str:
    if provider_of(ref) == "alldebrid":
        return _ad_client().cdn_url_for_ref(ref, priority, force_refresh)
    return _tb_cdn_url_for_ref(ref, priority, force_refresh)


def invalidate_ref(ref: str):
    if provider_of(ref) == "alldebrid":
        return _ad_client().invalidate_ref(ref)
    return _tb_invalidate_ref(ref)


def ref_size(ref: str) -> Optional[int]:
    if provider_of(ref) == "alldebrid":
        return _ad_client().ref_size(ref)
    return _tb_ref_size(ref)


def link_errors() -> tuple:
    """Every exception type a cdn_url_for_ref call can raise across providers
    — so FUSE and the proxy can handle a link failure without caring which
    service produced it."""
    from . import alldebrid_api as _ad
    return (tb.TorBoxError, _ad.AllDebridError, _ad_client().NotCachedOnAllDebrid)


def is_retryable(exc: Exception) -> bool:
    """Is this link failure worth holding the read for (busy / rate limited),
    as opposed to definitively broken?"""
    if isinstance(exc, _ad_client().NotCachedOnAllDebrid):
        return False
    return bool(getattr(exc, "retryable", False)) or getattr(exc, "status", 0) == 503


def _probe_cdn(url: str, expected_size: Optional[int]) -> bool:
    """1-byte ranged GET against the CDN (not the API — costs no budget)."""
    try:
        with requests.get(url, headers={"Range": "bytes=0-0"}, timeout=10, stream=True) as r:
            if r.status_code not in (200, 206):
                return False
            ctype = (r.headers.get("Content-Type") or "").lower()
            if "json" in ctype or "text/html" in ctype:
                return False
            total = None
            cr = r.headers.get("Content-Range", "")
            if "/" in cr and not cr.endswith("*"):
                total = int(cr.rsplit("/", 1)[1])
            if total is not None and total < _MIN_MEDIA:
                return False
            if expected_size and total and abs(total - expected_size) > expected_size * 0.1:
                return False
            return True
    except Exception as exc:
        log.debug("CDN probe failed: %s", exc)
        return False


# ─────────────────────────────────────────────────────────────────────────────
# Public client
# ─────────────────────────────────────────────────────────────────────────────

def _provider_for_result(r: dict) -> Optional[tuple[str, Optional[bool]]]:
    """Which service should serve this search result, and what we know about
    its cache status there — or None when the result isn't usable at all.

    AIOStreams reports which debrid service checked each result (`service`)
    and whether that service has it cached. The rules:

      * AllDebrid results are only ever used when AllDebrid is switched on
        in Config → Connections, and then only when AllDebrid says the
        release is cached. A disabled (or keyless) AllDebrid means its
        results are dropped here and never reach ranking, the release
        browser or a bind — so no uncached AllDebrid link can be shown.
      * TorBox results are used when a TorBox key is set, cached flag as
        reported.
      * A result checked against some *other* debrid service, or not checked
        at all (P2P results, TorBox's own search API), is a plain info-hash:
        cache status unknown, handed to whichever provider is configured and
        confirmed at bind time. TorBox first when both are available.
    """
    tb_on = bool(tb.api_key())
    ad_on = _ad_client().enabled()
    service = (r.get("service") or "").lower()

    if service == "alldebrid":
        if not ad_on or not r.get("cached"):
            return None
        return "alldebrid", True

    if service == "torbox":
        if not tb_on:
            return None
        return "torbox", bool(r.get("cached"))

    if r.get("source") != "aiostreams":
        # TorBox's own search API already answers for TorBox.
        return ("torbox", bool(r.get("cached", True))) if tb_on else (
            ("alldebrid", None) if ad_on else None)

    # Another service's cache answer tells us nothing about ours.
    known = True if (r.get("cached") and not service) else None
    if tb_on:
        return "torbox", known
    if ad_on:
        return "alldebrid", known
    return None


def _stream_from_result(r: dict, item: MediaItem) -> Optional[AIOStream]:
    h = tb.hash_of(r)
    if not h:
        return None
    chosen = _provider_for_result(r)
    if not chosen:
        return None
    service, cached = chosen
    name = r.get("raw_title") or r.get("title") or r.get("name") or ""
    pf, src_rank = parse_release(name)
    if r.get("file_hint"):
        fpf, frank = parse_release(r["file_hint"])
        pf.resolution = pf.resolution or fpf.resolution
        pf.encode = pf.encode or fpf.encode
        pf.hdr = pf.hdr or fpf.hdr
        pf.audio_tags = pf.audio_tags or fpf.audio_tags
        pf.languages = pf.languages or fpf.languages
        src_rank = src_rank or frank
    if not pf.resolution and r.get("resolution"):
        pf.resolution = str(r["resolution"])
    season = item.season if item.media_type == MediaType.SERIES else None
    episode = item.episode if item.media_type == MediaType.SERIES else None
    query_ref = (_ad_client().make_query_ref if service == "alldebrid" else make_query_ref)
    s = AIOStream(
        url=query_ref(h, season, episode, name),
        filename=name,
        size=int(r.get("size") or 0) or None,
        service=service,
        cached=cached,
        parsed_file=pf,
        addon=r.get("indexer") or r.get("source") or "torbox-search",
    )
    s._source_rank = src_rank
    s._seeders = int(r.get("last_known_seeders") or r.get("seeders") or 0)
    s._hash = h
    return s


class TorBoxClient:
    def __init__(self) -> None:
        self._bg_task: Optional[asyncio.Task] = None

    async def open(self) -> None:
        await asyncio.to_thread(guard.store)

    async def close(self) -> None:
        if self._bg_task:
            self._bg_task.cancel()

    # ── Search ──────────────────────────────────────────────────────────────
    @staticmethod
    def search_source() -> str:
        from . import aiostreams_api
        return "aiostreams" if aiostreams_api.is_configured() else "torbox"

    def _search_sync(self, item: MediaItem, priority: int, fresh: bool = False) -> list[dict]:
        from . import aiostreams_api
        season = item.season if item.media_type == MediaType.SERIES else None
        episode = item.episode if item.media_type == MediaType.SERIES else None
        source = self.search_source()
        key = f"search:{item.imdb_id}:{season}:{episode}:{source}"
        st = guard.store()
        if not fresh:
            cached = st.get_search(key)
            if cached is not None:
                guard.stats.inc("search_cache_hits")
                return cached

        def _do():
            if not fresh:
                again = st.get_search(key)
                if again is not None:
                    return again
            if source == "aiostreams":
                try:
                    results = aiostreams_api.search(item.imdb_id, season, episode, priority=priority)
                except aiostreams_api.AIOStreamsError as exc:
                    # Surface as a transient TorBox-layer error so callers keep
                    # entries and retry later instead of treating it as "dead".
                    raise tb.TorBoxError(str(exc), status=503 if exc.diagnosis != "bad_auth" else 401) from exc
            else:
                results = tb.search_torrents(item.imdb_id, season, episode, priority=priority)
            ttl_min = (_setting("torbox_search_cache_minutes", 360) if results
                       else _setting("torbox_search_empty_cache_minutes", 30))
            st.put_search(key, results, float(ttl_min) * 60)
            return results

        return guard.singleflight.do(key + (":fresh" if fresh else ""), _do)

    async def _streams(self, item: MediaItem, priority: int = guard.LOW,
                       fresh: bool = False, include_uncached: bool = False) -> list[AIOStream]:
        raw = await asyncio.to_thread(self._search_sync, item, priority, fresh)
        seen, out = set(), []
        for r in raw:
            s = _stream_from_result(r, item)
            if not s:
                continue
            # The same release can come back once per debrid service; keep
            # one entry per (service, hash) so both remain bindable.
            key = (s.service, s._hash)
            if key in seen:
                continue
            if s.cached is False and not include_uncached:
                continue
            seen.add(key)
            out.append(s)
        log.info("Search (%s) %s → %d result(s), %d usable", self.search_source(),
                 item.aiostreams_id, len(raw), len(out))
        return out

    async def releases(self, item: MediaItem, fresh: bool = True,
                       limit: Optional[int] = None) -> tuple[list[dict], int]:
        """The cached releases found for a title, best first, for browsing.

        Only releases a configured service has cached (or hasn't ruled out)
        are listed — the ones you could actually add. Releases nothing has
        cached are counted but not returned, and the list is capped at
        `releases_max_results` so a title with hundreds of hits, or one
        checked against two debrid services at once, stays readable.

        Returns (rows, total_cached) so the caller can say how many were
        found beyond the ones shown.
        """
        limit = int(limit if limit is not None else _setting("releases_max_results", 15))
        streams = await self._streams(item, guard.HIGH, fresh=fresh, include_uncached=True)
        allowed = {id(s) for s in _filter_by_exclude_words(_filter_by_size(streams))}
        # cached is False only when a service positively said "not cached";
        # None means nobody has checked, and those are still addable.
        addable = [s for s in _rank(streams) if s.cached is not False]
        total = len(addable)
        out = []
        for s in (addable[:limit] if limit > 0 else addable):
            pf = s.parsed_file
            out.append({
                "hash": s._hash, "name": s.filename, "size": s.size,
                "quality": s.quality.value, "resolution": pf.resolution if pf else None,
                "source": pf.quality if pf else None, "encode": pf.encode if pf else None,
                "hdr": pf.hdr if pf else None, "seeders": getattr(s, "_seeders", 0),
                "cached": s.cached, "service": s.service,
                "in_account": _in_account(s._hash, s.service or "torbox"),
                "excluded": id(s) not in allowed, "indexer": s.addon,
            })
        return out, total

    async def bind_hash(self, item: MediaItem, h: str, service: Optional[str] = None) -> AIOStream:
        """Bind one specific release (picked by an admin) to this title.

        `service` names the provider to bind through; without it, whichever
        one is configured (TorBox first) is used."""
        season = item.season if item.media_type == MediaType.SERIES else None
        episode = item.episode if item.media_type == MediaType.SERIES else None
        service = (service or ("torbox" if tb.api_key() else
                               ("alldebrid" if _ad_client().enabled() else "torbox"))).lower()
        cand = AIOStream(url=None, filename="", size=None, service=service, cached=None,
                         parsed_file=None)
        return await asyncio.to_thread(self._bind_any, service, h.lower(), season, episode,
                                       cand, False, guard.HIGH)

    async def resolve_all(self, item: MediaItem, fresh: bool = False) -> list[AIOStream]:
        streams = await self._streams(item, guard.HIGH if fresh else guard.LOW, fresh=fresh)
        return _rank(_filter_by_exclude_words(streams))

    async def best_for_quality(self, item: MediaItem, quality: Quality) -> Optional[AIOStream]:
        streams = [s for s in await self.resolve_all(item) if s.quality == quality]
        return streams[0] if streams else None

    async def bind_for_quality(self, item: MediaItem, quality: Quality, *, verify: bool = False,
                               exclude_hashes: Optional[set] = None,
                               max_candidates: Optional[int] = None,
                               priority: int = guard.LOW) -> Optional[AIOStream]:
        """
        Bind a title to a real file in a cached torrent: add the torrent to
        the account if needed, pick the right file. Returns a stream whose
        url is a full ref and whose size is the real file size.

        verify=True also fetches the CDN link and probes it (used when
        repairing an entry that stopped working, not for plain adds).

        Returns None when there's nothing to try; raises AllCandidatesDeadError
        when every candidate tried definitively failed, TorBoxUnavailableError
        when TorBox was rate limiting/unavailable (try again later).
        """
        max_candidates = int(max_candidates or _setting("torbox_max_candidates", 3))
        try:
            found = await self._streams(item, priority)
        except tb.TorBoxError as exc:
            raise TorBoxUnavailableError(f"Release search failed: {exc}") from exc
        streams = [s for s in found if s.quality == quality]
        if exclude_hashes:
            streams = [s for s in streams if s._hash not in exclude_hashes]
        streams = _filter_by_exclude_words(_filter_by_size(streams))
        if not streams:
            return None
        candidates = _rank(streams)

        season = item.season if item.media_type == MediaType.SERIES else None
        episode = item.episode if item.media_type == MediaType.SERIES else None
        tried = definitive = 0
        for cand in candidates:
            if tried >= max_candidates:
                break
            if guard.breaker.is_open(cand._hash):
                continue
            tried += 1
            try:
                result = await asyncio.to_thread(self._bind_any, cand.service, cand._hash,
                                                 season, episode, cand, verify, priority)
            except (FileNotInTorrent, tb.TorBoxError) as exc:
                if not (isinstance(exc, tb.TorBoxError) and exc.retryable):
                    definitive += 1
                log.warning("Candidate %d (%s…) failed: %s", tried, (cand.filename or cand._hash)[:60], exc)
                if isinstance(exc, tb.TorBoxError) and exc.rate_limited:
                    break
                continue
            if result:
                return result
            definitive += 1

        if tried and definitive == tried:
            raise AllCandidatesDeadError(tried)
        if tried:
            raise TorBoxUnavailableError("TorBox is temporarily unavailable or rate limiting — try again later")
        return None

    # Old name, kept for callers doing a verified (repair/play-time) bind.
    async def best_working_for_quality(self, item: MediaItem, quality: Quality,
                                       max_candidates: Optional[int] = None) -> Optional[AIOStream]:
        return await self.bind_for_quality(item, quality, verify=True, max_candidates=max_candidates,
                                           priority=guard.HIGH)

    def _bind_any(self, service: str, h: str, season, episode, cand: AIOStream,
                  verify: bool, priority: int) -> Optional[AIOStream]:
        """Bind through whichever provider owns this candidate, translating
        its failures into the two kinds the callers already understand:
        FileNotInTorrent / tb.TorBoxError(not retryable) = definitively dead,
        tb.TorBoxError(retryable) = try again later."""
        if (service or "").lower() != "alldebrid":
            return self._bind_sync(h, season, episode, cand, verify, priority)

        adc = _ad_client()
        from . import alldebrid_api as ad
        try:
            return adc.bind_sync(h, season, episode, cand, verify, priority)
        except adc.NotCachedOnAllDebrid as exc:
            raise tb.TorBoxError(str(exc), status=409, code="NOT_CACHED") from exc
        except ad.AllDebridError as exc:
            raise tb.TorBoxError(str(exc), status=exc.status or (429 if exc.rate_limited else 400),
                                 code=exc.code) from exc

    def _bind_sync(self, h: str, season, episode, cand: AIOStream, verify: bool,
                   priority: int) -> Optional[AIOStream]:
        rec = ensure_in_account(h, priority)
        f = choose_file(rec["files"], season, episode)
        ref = make_ref(h, f["id"], f["name"])
        if verify:
            url = cdn_url_for_ref(ref, priority)
            if not _probe_cdn(url, f.get("size")):
                invalidate_ref(ref)
                guard.breaker.failure(h, "CDN probe failed")
                return None
        pf, _ = parse_release(f["name"])
        if not pf.resolution and cand.parsed_file:
            pf.resolution = cand.parsed_file.resolution
        out = AIOStream(url=ref, filename=f["name"].rsplit("/", 1)[-1], size=f.get("size"),
                        service="torbox", cached=True, parsed_file=pf, addon="torbox")
        out._hash = h
        return out

    def verify_ref_sync(self, ref: str) -> bool:
        """Fresh link + CDN probe for an existing bound ref, either provider."""
        if provider_of(ref) == "alldebrid":
            return _ad_client().verify_ref_sync(ref)
        try:
            url = cdn_url_for_ref(ref, guard.LOW, force_refresh=True)
            return _probe_cdn(url, ref_size(ref))
        except Exception as exc:
            log.info("Existing ref %s… no longer works: %s", ref[9:25], exc)
            return False

    async def materialize_ref(self, ref: str) -> AIOStream:
        """Turn any ref (query form from the candidate picker, or full) into
        a full ref with a real size — used by manual stream selection."""
        if provider_of(ref) == "alldebrid":
            return await asyncio.to_thread(_ad_client().materialize_ref_sync, ref)
        info = parse_ref(ref)

        def _do():
            rec = ensure_in_account(info["hash"], guard.HIGH)
            f = choose_file(rec["files"], info["season"], info["episode"], "", info["file_id"])
            full = make_ref(info["hash"], f["id"], f["name"])
            cdn_url_for_ref(full, guard.HIGH)
            return AIOStream(url=full, filename=f["name"], size=f.get("size"), service="torbox",
                             cached=True, parsed_file=parse_release(f["name"])[0])
        return await asyncio.to_thread(_do)

    # ── Account mirror ──────────────────────────────────────────────────────
    def sync_torrents_sync(self) -> int:
        import time as _time
        started = _time.time()
        items = tb.list_all_torrents(page_size=int(_setting("torbox_list_page_size", 1000)))
        rows = []
        for t in items:
            h = (t.get("hash") or "").lower()
            files = _slim_files(t.get("files") or [])
            if h and t.get("id") and files and (t.get("download_present") or t.get("download_finished")):
                rows.append((h, int(t["id"]), t.get("name") or "", files))
        guard.store().replace_torrents(rows, started)
        guard.stats.inc("mylist_syncs")
        return len(rows)

    async def background_loop(self):
        """Mirrors the account's torrent list, sweeps expired cache rows and
        trims the probe cache. Runs on the LOW lane."""
        from . import probe_cache
        await asyncio.sleep(20)
        while True:
            try:
                if tb.api_key():
                    n = await asyncio.to_thread(self.sync_torrents_sync)
                    log.info("TorBox account mirror synced: %d torrent(s)", n)
                if _ad_client().enabled():
                    try:
                        n = await asyncio.to_thread(_ad_client().sync_magnets_sync)
                        log.info("AllDebrid account mirror synced: %d ready magnet(s)", n)
                        await asyncio.to_thread(_ad_client().store().sweep)
                    except Exception as exc:
                        log.warning("AllDebrid sync error: %s", exc)
                removed = await asyncio.to_thread(guard.store().sweep)
                if removed:
                    log.debug("TorBox cache sweep removed %d expired row(s)", removed)
                await asyncio.to_thread(probe_cache.evict)
            except asyncio.CancelledError:
                break
            except Exception as exc:
                log.warning("TorBox background sync error: %s", exc)
            await asyncio.sleep(max(60, float(_setting("torbox_sync_minutes", 15)) * 60))

    def start_background(self):
        self._bg_task = asyncio.create_task(self.background_loop())

    # ── Diagnostics ─────────────────────────────────────────────────────────
    async def connection_test(self) -> dict:
        result = {"ok": False, "error": None, "diagnosis": None, "key_set": bool(tb.api_key())}
        if not tb.api_key():
            result.update(error="No TorBox API key set", diagnosis="no_key")
            return result
        try:
            me = await asyncio.to_thread(tb.user_me, guard.HIGH)
            result["plan"] = me.get("plan")
            result["email"] = me.get("email")
            result["subscribed"] = me.get("is_subscribed")
        except tb.TorBoxError as exc:
            result.update(error=str(exc), diagnosis="bad_auth" if exc.status in (401, 403) else "unreachable")
            return result
        try:
            raw = await asyncio.to_thread(tb.search_torrents, "tt0068646", None, None, guard.HIGH)
            result["total_results"] = len(raw)
            result["cached_results"] = sum(1 for r in raw if r.get("cached"))
            result["ok"] = True
            result["diagnosis"] = "ok" if raw else "no_results"
        except tb.TorBoxError as exc:
            result.update(error=f"Account OK but search failed: {exc}", diagnosis="search_failed")
        return result

    def stats(self) -> dict:
        from . import probe_cache
        out = guard.stats.snapshot()
        try:
            out.update(guard.store().counts())
        except Exception:
            pass
        out["breaker_open"] = guard.breaker.open_count()
        out["probe_cache"] = probe_cache.usage()
        try:
            out["alldebrid"] = _ad_client().stats()
        except Exception:
            pass
        return out

