"""
gateway/pipe_worker.py
~~~~~~~~~~~~~~~~~~~~~~
After the webhook resolves a stub's stream URL, this module:

1. Replaces the stub .mkv file on disk with a named pipe (FIFO)
2. Starts a background thread that opens the pipe and streams bytes
   from the CDN URL through it whenever Plex opens the pipe for reading

This means when Plex opens the file path, it reads the real stream
rather than the small stub video — no FUSE required.

Limitation: named pipes don't support seeking. Plex will play from
start but can't seek. For a fully seekable solution, FUSE is needed.
"""
from __future__ import annotations

import logging
import os
import threading
import time
from pathlib import Path
from typing import Optional

import aiohttp

logger = logging.getLogger("aiogateway.pipe")

# Chunk size for streaming from CDN → pipe
CHUNK = 256 * 1024   # 256 KB


class PipeWorker:
    """Manages named-pipe file replacements for resolved stubs."""

    def __init__(self) -> None:
        self._workers: dict[str, threading.Thread] = {}   # stub_id → thread
        self._stop:    dict[str, threading.Event]  = {}
        self._session: Optional[aiohttp.ClientSession] = None

    def attach_session(self, session: aiohttp.ClientSession) -> None:
        self._session = session

    def activate(self, stub_id: str, file_path: str,
                 stream_url: str, request_headers: dict) -> None:
        """
        Replace file_path with a named pipe and start a worker thread
        that serves stream_url through it when Plex opens the pipe.
        """
        # Stop any existing worker for this stub
        self.deactivate(stub_id)

        path = Path(file_path)
        if not path.parent.exists():
            logger.warning("Pipe: parent dir missing: %s", path.parent)
            return

        # Replace the regular file with a named pipe
        try:
            if path.exists() or path.is_symlink():
                path.unlink()
            os.mkfifo(str(path))
            logger.info("Pipe created: %s", file_path)
        except Exception as exc:
            logger.error("Pipe creation failed for %s: %s", file_path, exc)
            return

        stop_event = threading.Event()
        self._stop[stub_id] = stop_event

        t = threading.Thread(
            target=self._serve_loop,
            args=(stub_id, str(path), stream_url, request_headers, stop_event),
            daemon=True,
            name=f"pipe-{stub_id[:8]}",
        )
        self._workers[stub_id] = t
        t.start()

    def deactivate(self, stub_id: str) -> None:
        """Stop the worker for a stub (called on delete)."""
        ev = self._stop.pop(stub_id, None)
        if ev:
            ev.set()
        self._workers.pop(stub_id, None)

    def _serve_loop(self, stub_id: str, path: str,
                    stream_url: str, req_headers: dict,
                    stop: threading.Event) -> None:
        """
        Loop: wait for Plex to open the pipe, stream the CDN URL through it,
        repeat (Plex may open the pipe multiple times for different requests).
        """
        import urllib.request
        logger.info("Pipe worker started: %s", path)

        while not stop.is_set():
            # Opening a FIFO for writing blocks until a reader opens the other end.
            # Plex will open it when the user hits Play.
            try:
                # Use O_NONBLOCK to check if the pipe still exists
                if not os.path.exists(path):
                    logger.info("Pipe removed, worker exiting: %s", path)
                    return

                logger.info("Pipe: waiting for Plex to open %s", path)
                # This blocks until Plex opens the read end
                fd = os.open(path, os.O_WRONLY)
                logger.info("Pipe: Plex opened %s — streaming from CDN", path)

                try:
                    with os.fdopen(fd, 'wb', buffering=0) as pipe_out:
                        # Stream from CDN URL into the pipe
                        headers = dict(req_headers) if req_headers else {}
                        req = urllib.request.Request(stream_url, headers=headers)
                        with urllib.request.urlopen(req, timeout=30) as resp:
                            bytes_sent = 0
                            while not stop.is_set():
                                chunk = resp.read(CHUNK)
                                if not chunk:
                                    break
                                try:
                                    pipe_out.write(chunk)
                                    bytes_sent += len(chunk)
                                except BrokenPipeError:
                                    # Plex closed the pipe (paused, seeked, stopped)
                                    logger.info(
                                        "Pipe: Plex closed pipe after %d MB — ready for next open",
                                        bytes_sent // 1_000_000
                                    )
                                    break
                            logger.info("Pipe: stream ended (%d MB sent)", bytes_sent // 1_000_000)
                except Exception as exc:
                    logger.warning("Pipe: stream error: %s", exc)

            except FileNotFoundError:
                logger.info("Pipe: file removed, worker exiting")
                return
            except Exception as exc:
                if stop.is_set():
                    return
                logger.warning("Pipe: error in serve loop: %s", exc)
                time.sleep(1)

        logger.info("Pipe worker stopped: %s", path)
