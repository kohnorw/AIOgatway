"""
gateway/pending_movies.py
~~~~~~~~~~~~~~~~~~~~~~~~~~
Tracks movies that were "added" but couldn't be resolved right away —
either because they haven't been released yet, or because nothing's
cached at the debrid backend at that moment. Instead of the add just
failing outright, the movie is tracked here and a periodic background
sweep keeps retrying it automatically (same stubbing path as every other
add flow) until either a stream shows up or the retry window elapses.

This is the movie equivalent of gateway/auto_episodes.py — same shape,
same persistence pattern, same give-up-after-N-days logic — just for
whole movies instead of individual episodes of an already-tracked show.
"""
from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger("aiogateway.pendingmovies")

# imdb_id -> {imdb_id, title, year, poster, added_at, first_seen_unresolved_at}
_pending: dict[str, dict] = {}
_loaded = False


def _state_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_pending_movies.json"


def _load() -> None:
    global _pending, _loaded
    if _loaded:
        return
    path = _state_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text())
            _pending = {item["imdb_id"]: item for item in raw}
            logger.info("Loaded %d pending movie(s) from %s", len(_pending), path)
    except Exception as exc:
        logger.warning("Could not load pending movies from %s: %s", path, exc)
        _pending = {}
    _loaded = True


def _persist() -> None:
    path = _state_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(list(_pending.values()), indent=2))
    except Exception as exc:
        logger.warning("Could not persist pending movies to %s: %s", path, exc)


async def add(imdb_id: str, title: str, year: Optional[int], poster: str) -> None:
    """Start tracking a movie that couldn't be resolved yet. No-op if
    already tracked — repeated add attempts (e.g. clicking a calendar
    entry more than once) don't reset its retry-window clock."""
    _load()
    if imdb_id in _pending:
        return
    _pending[imdb_id] = {
        "imdb_id": imdb_id, "title": title, "year": year, "poster": poster,
        "added_at": time.time(), "first_seen_unresolved_at": time.time(),
    }
    _persist()
    logger.info("Tracking pending movie: %s (%s)", title, imdb_id)


def remove(imdb_id: str) -> bool:
    _load()
    if imdb_id in _pending:
        del _pending[imdb_id]
        _persist()
        return True
    return False


def list_all() -> list[dict]:
    _load()
    return list(_pending.values())


def is_pending(imdb_id: str) -> bool:
    _load()
    return imdb_id in _pending


async def run_sweep(query_movie_fn, force: bool = False, yield_fn=None) -> dict:
    """
    One sweep cycle. `query_movie_fn(imdb_id, title, year, poster)` should
    attempt to resolve+stub that movie and return True if it now has a
    stub, False otherwise — see main.py's _query_movie.

    force bypasses the pending_movies_enabled setting, for the manual
    "check now" API trigger — a deliberate one-off action distinct from
    the recurring background behaviour the setting controls.

    yield_fn, if given, is awaited before each per-movie check — main.py
    passes in _yield_to_play_priority so this sweep pauses for the
    duration of any in-flight Plex-triggered resolve, same as every other
    background loop, rather than competing with it for TorBox budget.
    """
    from gateway import settings as _settings
    _load()

    if not force and not _settings.get("pending_movies_enabled", True):
        return {"skipped": "disabled"}

    if not _pending:
        return {"checked": 0, "resolved": 0, "pending": 0}

    retry_days = _settings.get("pending_movies_retry_days", 30)
    retry_cutoff = time.time() - (retry_days * 86400) if retry_days else None

    checked = 0
    resolved = []
    for imdb_id, entry in list(_pending.items()):
        if retry_cutoff and entry["first_seen_unresolved_at"] < retry_cutoff:
            continue   # gave up — still visible/searchable manually, just no more auto-retries
        if yield_fn:
            await yield_fn()
        checked += 1
        try:
            ok = await query_movie_fn(imdb_id, entry["title"], entry.get("year"), entry.get("poster", ""))
        except Exception as exc:
            logger.warning("Pending movie check failed for %s: %s", imdb_id, exc)
            ok = False
        if ok:
            resolved.append(imdb_id)
            del _pending[imdb_id]
            logger.info("Pending movie resolved: %s (%s)", entry["title"], imdb_id)

    if resolved:
        _persist()

    return {"checked": checked, "resolved": len(resolved), "pending": len(_pending)}
