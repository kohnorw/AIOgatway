"""
gateway/auto_episodes.py
~~~~~~~~~~~~~~~~~~~~~~~~
Background sweep that automatically discovers and stubs newly-aired
episodes for any series already tracked in the library — no manual
rescan needed.

On each sweep cycle:
  1. Enumerate every distinct show (imdb_id) that has at least one
     existing series stub.
  2. Fetch that show's current episode list from Cinemeta.
  3. For every aired episode that has no stub yet, try to stub it
     (HD always, +4K if AIOStreams has a 2160p result) using the same
     create_stubs()/_query_episode() path every other add flow uses.
  4. Episodes that have no stream available yet (common right at air
     time — uploads lag behind by hours) are tracked with a first-seen
     timestamp and retried on every subsequent sweep, until either a
     stream appears or auto_episodes_retry_days elapses, at which point
     automatic retries stop (the episode is still visible and
     manually-searchable in the UI — this only governs the background
     polling).

Scoping — this only ever touches seasons that are actually requested (at
least one existing stub) OR "wanted" (registered via gateway/wanted_seasons
— the Library modal's "New" button uses this when a season hasn't aired
at all yet, since there's nothing to stub and therefore no way for it to
satisfy the normal "has a stub" definition of requested). It will never
reach into a season nobody asked for just because Cinemeta lists it. The
one exception is a natural rollover: once every aired episode of a
requested season already has a stub (i.e. that season is fully caught up
— "on its last episode"), the immediately next season becomes eligible
too, so a show transitioning into a new season doesn't need a manual
"Request season" click. Within any eligible season, discovery is also
capped to at most 3 episodes ahead of the highest episode already
stubbed there per sweep, so a show that's been unchecked for a while
catches up gradually instead of bursting through a whole backlog of
episodes in one pass.

This intentionally reuses the exact same stubbing call (_query_episode,
which calls StubManager.create_stubs) used by every other add/rescan
path in the app, so there is no separate/divergent logic for what
"stub HD and 4K if available" means here.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import aiohttp

logger = logging.getLogger("aiogateway.autoepisodes")

# In-memory: {(imdb_id, season, episode): first_seen_unresolved_at}
# Persisted to disk so the retry-window give-up logic survives restarts.
_pending: dict[tuple, float] = {}
_loaded = False


def _state_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_auto_episodes.json"


def _load() -> None:
    global _pending, _loaded
    if _loaded:
        return
    path = _state_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text())
            _pending = {
                (item["imdb_id"], item["season"], item["episode"]): item["first_seen_at"]
                for item in raw
            }
            logger.info("Loaded %d pending auto-episode entries from %s", len(_pending), path)
    except Exception as exc:
        logger.warning("Could not load auto-episode state from %s: %s", path, exc)
        _pending = {}
    _loaded = True


def _persist() -> None:
    path = _state_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        raw = [
            {"imdb_id": k[0], "season": k[1], "episode": k[2], "first_seen_at": v}
            for k, v in _pending.items()
        ]
        path.write_text(json.dumps(raw, indent=2))
    except Exception as exc:
        logger.warning("Could not persist auto-episode state to %s: %s", path, exc)


def _is_aired(released: Optional[str]) -> bool:
    """Self-contained copy of main.py's _is_aired — kept in sync manually
    since it's a tiny, stable function; avoids a circular import between
    this module and main.py."""
    if not released:
        return False
    try:
        dt = datetime.fromisoformat(released.replace("Z", "+00:00"))
        return dt <= datetime.now(timezone.utc)
    except Exception:
        return False


async def run_sweep(stubs, http_session, query_episode_fn, yield_to_play_priority_fn, force: bool = False) -> dict:
    """
    One full sweep cycle. Returns a small summary dict for logging.

    Args:
      stubs: the StubManager instance (used to enumerate tracked shows
             and check which episodes already have stubs).
      http_session: shared aiohttp.ClientSession for Cinemeta requests.
      query_episode_fn: main.py's _query_episode — the single function
             every other code path uses to query AIOStreams and call
             create_stubs() for one episode. Reused here unchanged.
      yield_to_play_priority_fn: main.py's _yield_to_play_priority, so
             this sweep backs off the same way the existing background
             scan does when a real user is mid-resolve.
      force: bypass the auto_episodes_enabled setting — used by the manual
             "sweep now" API trigger, which is a deliberate one-off action
             distinct from the recurring background behaviour the setting
             controls.
    """
    from gateway import settings as _settings
    from gateway import wanted_seasons as _wanted_seasons

    _load()

    if not force and not _settings.get("auto_episodes_enabled", True):
        return {"skipped": "disabled"}

    retry_days = _settings.get("auto_episodes_retry_days", 3)
    retry_cutoff = time.time() - (retry_days * 86400) if retry_days else None

    all_stubs = stubs.all()
    series_stubs = [s for s in all_stubs if s.aiostreams_type == "series" and s.imdb_id]
    wanted_all = _wanted_seasons.list_all()
    # Union of shows with an existing stub AND shows that only have a
    # wanted future season registered (zero stubs yet) — without this,
    # a show whose sole interaction was "New" on a purely-upcoming season
    # would never even get checked here at all, since it has no stub to
    # be discovered by in the first place.
    tracked_imdb_ids = sorted({s.imdb_id for s in series_stubs} | {w["imdb_id"] for w in wanted_all})

    if not tracked_imdb_ids:
        return {"shows_checked": 0, "new_stubs": 0}

    new_stubs_total = 0
    shows_checked = 0
    errors = []

    for imdb_id in tracked_imdb_ids:
        try:
            await yield_to_play_priority_fn()

            async with http_session.get(
                f"https://v3-cinemeta.strem.io/meta/series/{imdb_id}.json",
                headers={"User-Agent": "AIOGateway/0.3"},
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                data = await resp.json(content_type=None)
            meta = data.get("meta") or {}
            videos = meta.get("videos") or []
            if not videos:
                continue

            this_show_stubs = [s for s in series_stubs if s.imdb_id == imdb_id]
            existing_keys = {
                (s.season, s.episode)
                for s in this_show_stubs
                if s.season is not None and s.episode is not None
            }
            this_show_wanted = [w for w in wanted_all if w["imdb_id"] == imdb_id]
            # Title/poster/year: prefer an existing stub's (most reliable,
            # matches the actual folder already on disk), fall back to
            # whatever was captured when the wanted season was registered
            # — a show with zero stubs has no other source for these.
            show_title = (
                next((s.show_title or s.title for s in this_show_stubs if s.show_title), None)
                or next((w["title"] for w in this_show_wanted if w.get("title")), None)
                or meta.get("name", imdb_id)
            )
            poster = (
                next((getattr(s, "_poster", "") for s in this_show_stubs if getattr(s, "_poster", "")), None)
                or next((w.get("poster") for w in this_show_wanted if w.get("poster")), None)
                or meta.get("poster", "")
            )
            year = (
                next((s.year for s in this_show_stubs if s.year), None)
                or next((w.get("year") for w in this_show_wanted if w.get("year")), None)
            )

            # Requested seasons — same definition used everywhere else in
            # the app (Library's series detail modal, spot check): a
            # season counts as requested if it has at least one existing
            # stub. Auto-episode discovery should never wander into a
            # season nobody asked for just because Cinemeta lists it.
            # Wanted seasons (registered via "New" while nothing had
            # aired yet) are folded in here too — that's the whole point
            # of tracking them, so they get picked up the moment their
            # first episode actually airs instead of needing a second
            # manual click later.
            requested_seasons = {s.season for s in this_show_stubs if s.season is not None}
            wanted_season_nums = {w["season"] for w in this_show_wanted}
            requested_or_wanted_seasons = requested_seasons | wanted_season_nums

            videos_by_season: dict = {}
            for v in videos:
                sn = v.get("season")
                if sn:
                    videos_by_season.setdefault(sn, []).append(v)

            def _season_fully_caught_up(sn: int) -> bool:
                """True if every aired episode of this season already has
                a stub — i.e. we're at (or past) the last episode of it."""
                aired = [vv for vv in videos_by_season.get(sn, []) if _is_aired(vv.get("released"))]
                if not aired:
                    return False
                return all((sn, vv.get("number")) in existing_keys for vv in aired)

            # A season is eligible this sweep if it's already requested or
            # wanted, OR it's the very next season after one that's fully
            # caught up — a natural rollover once a requested season has
            # run its course, rather than auto-stub reaching ahead into
            # seasons with no relation to what's actually being tracked.
            eligible_seasons = set(requested_or_wanted_seasons)
            for sn in requested_seasons:
                if (sn + 1) not in requested_or_wanted_seasons and _season_fully_caught_up(sn):
                    eligible_seasons.add(sn + 1)

            # Per-season lookahead cap: don't stub more than 3 episodes
            # ahead of the highest episode already stubbed in that season
            # per sweep — so a show that's been unchecked for a while (or
            # a season just becoming eligible via rollover) catches up
            # gradually rather than bursting through a whole backlog of
            # episodes in one sweep. Advances as episodes get stubbed
            # within this same sweep, so a caught-up show still keeps
            # pace with new episodes one sweep at a time.
            highest_stubbed_in_season: dict = {}
            for (s_sn, s_ep) in existing_keys:
                highest_stubbed_in_season[s_sn] = max(highest_stubbed_in_season.get(s_sn, 0), s_ep)

            shows_checked += 1
            sem = asyncio.Semaphore(1)

            for v in videos:
                sn, ep = v.get("season"), v.get("number")
                if sn is None or ep is None or sn == 0:
                    continue
                if sn not in eligible_seasons:
                    continue
                if (sn, ep) in existing_keys:
                    continue
                if not _is_aired(v.get("released")):
                    continue
                if ep > highest_stubbed_in_season.get(sn, 0) + 3:
                    continue

                pending_key = (imdb_id, sn, ep)
                first_seen = _pending.get(pending_key)
                if first_seen and retry_cutoff and first_seen < retry_cutoff:
                    continue  # gave up on this one — still visible/searchable manually

                await yield_to_play_priority_fn()
                try:
                    stubbed, _, _ = await query_episode_fn(imdb_id, show_title, year, poster, v, sem)
                except Exception as exc:
                    logger.warning("Auto-episode check failed for %s S%02dE%02d: %s",
                                   imdb_id, sn, ep, exc)
                    stubbed = False

                if stubbed:
                    new_stubs_total += 1
                    _pending.pop(pending_key, None)
                    highest_stubbed_in_season[sn] = max(highest_stubbed_in_season.get(sn, 0), ep)
                    logger.info("Auto-stubbed new episode: %s S%02dE%02d", imdb_id, sn, ep)
                    if sn in wanted_season_nums:
                        # Now has a real stub, which is the normal
                        # "requested" definition everywhere else — no
                        # longer needs the wanted-season workaround.
                        _wanted_seasons.remove(imdb_id, sn)
                        wanted_season_nums.discard(sn)
                        logger.info("S%02d of %s got its first stub — cleared wanted-season mark", sn, imdb_id)
                else:
                    if pending_key not in _pending:
                        _pending[pending_key] = time.time()

                await asyncio.sleep(1.0)

        except Exception as exc:
            errors.append(f"{imdb_id}: {exc}")
            logger.warning("Auto-episode sweep error for %s: %s", imdb_id, exc)

    _persist()
    return {
        "shows_checked": shows_checked,
        "new_stubs": new_stubs_total,
        "pending": len(_pending),
        "errors": errors,
    }
