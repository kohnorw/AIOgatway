"""
gateway/crypto.py
~~~~~~~~~~~~~~~~~
At-rest encryption for every URL and credential AIOGateway stores.

Everything the user types into the GUI — AIOStreams URL/UUID/password,
Plex URL/token, each debrid API key, Radarr/Sonarr URLs and keys — is
written to disk as AES-256-GCM ciphertext, never as plaintext.

Key management
--------------
The data key lives in a single file (`.aiogateway.key`, mode 0600) inside
the data directory, generated with `os.urandom` on first start. It is
deliberately NOT derived from a user password: there is nobody present to
type one at container start, and a password baked into an env var or
compose file would just be plaintext one layer further out.

What this protects against is the realistic threat for a self-hosted
media box: config files getting copied around — into a backup archive, a
synced folder, a pasted bug report, a git repo — and taking live debrid
keys with them. An attacker who already has root on the host and can read
the key file can decrypt, and no scheme that starts unattended can change
that.

Format: `enc:v1:<base64(nonce || ciphertext || tag)>`. Plaintext that
predates encryption is returned as-is by `decrypt`, so an older config
file keeps working and gets rewritten encrypted on the next save.
"""
from __future__ import annotations

import base64
import logging
import os
import threading
from pathlib import Path
from typing import Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

logger = logging.getLogger("aiogateway.crypto")

_PREFIX = "enc:v1:"
_NONCE_BYTES = 12
_KEY_BYTES = 32

_lock = threading.Lock()
_key: Optional[bytes] = None


def _key_path() -> Path:
    from .paths import data_dir
    return data_dir() / ".aiogateway.key"


def _load_or_create_key() -> bytes:
    global _key
    if _key is not None:
        return _key
    with _lock:
        if _key is not None:
            return _key
        path = _key_path()
        try:
            if path.exists():
                raw = path.read_bytes().strip()
                key = base64.urlsafe_b64decode(raw)
                if len(key) != _KEY_BYTES:
                    raise ValueError(f"expected {_KEY_BYTES} bytes, got {len(key)}")
                _key = key
                return _key
        except Exception as exc:
            # Refusing to silently mint a new key here matters: a new key
            # would make every stored secret undecryptable while looking
            # like a clean start, and the user would only find out when
            # AIOStreams and Plex both stopped authenticating.
            raise RuntimeError(
                f"Encryption key at {path} is unreadable ({exc}). Restore it "
                "from a backup, or delete it and re-enter your URLs and keys."
            ) from exc

        key = os.urandom(_KEY_BYTES)
        path.parent.mkdir(parents=True, exist_ok=True)
        # Write with restrictive permissions from the outset rather than
        # chmod-ing after — otherwise the key is briefly world-readable.
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            os.write(fd, base64.urlsafe_b64encode(key))
        finally:
            os.close(fd)
        logger.info("Generated a new encryption key at %s", path)
        _key = key
        return _key


def is_encrypted(value: object) -> bool:
    return isinstance(value, str) and value.startswith(_PREFIX)


def encrypt(plaintext: str) -> str:
    """Encrypt a secret. Empty strings pass through — an unset field is
    not a secret, and encrypting it would make 'is this configured yet?'
    impossible to answer without decrypting."""
    if not plaintext:
        return ""
    if is_encrypted(plaintext):
        return plaintext
    aes = AESGCM(_load_or_create_key())
    nonce = os.urandom(_NONCE_BYTES)
    blob = nonce + aes.encrypt(nonce, plaintext.encode("utf-8"), None)
    return _PREFIX + base64.urlsafe_b64encode(blob).decode("ascii")


def decrypt(value: object) -> str:
    """Decrypt a stored secret. Plaintext (pre-encryption config) is
    returned unchanged."""
    if not isinstance(value, str) or not value:
        return ""
    if not is_encrypted(value):
        return value
    try:
        blob = base64.urlsafe_b64decode(value[len(_PREFIX):])
        nonce, ct = blob[:_NONCE_BYTES], blob[_NONCE_BYTES:]
        aes = AESGCM(_load_or_create_key())
        return aes.decrypt(nonce, ct, None).decode("utf-8")
    except Exception as exc:
        logger.error("Could not decrypt a stored value: %s", exc)
        return ""


def mask(plaintext: str, keep: int = 4) -> str:
    """A display form for the UI: enough to recognise which key is set,
    not enough to use it. The API never returns decrypted secrets."""
    if not plaintext:
        return ""
    if len(plaintext) <= keep:
        return "•" * len(plaintext)
    return "•" * (len(plaintext) - keep) + plaintext[-keep:]
