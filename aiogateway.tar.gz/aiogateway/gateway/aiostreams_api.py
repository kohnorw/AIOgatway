"""
gateway/aiostreams_api.py
~~~~~~~~~~~~~~~~~~~~~~~~~
AIOStreams as the release finder. TorBox still adds and serves everything.

AIOStreams runs your addons with your filters/sorting and returns results
from GET /api/v1/search?type=movie|series&id=tt…[:S:E] (HTTP Basic auth
with your AIOStreams UUID + password). Torrent results carry `infoHash`;
those are handed to the TorBox layer, which adds the torrent to your account
only if TorBox has it cached. Usenet/HTTP-only results have no hash and are
skipped.

Credentials come from Config → Connections (stored in settings), falling back
to AIOSTREAMS_URL / AIOSTREAMS_UUID / AIOSTREAMS_PASSWORD in the environment.
"""
from __future__ import annotations

import base64
import logging
import os
import re
from typing import Optional

import requests

from . import torbox_guard as guard

log = logging.getLogger("aiogateway.aiostreams")

aiostreams_limiter = guard.RateLimiter(
    "aiostreams", lambda: guard._setting("aiostreams_per_minute", 30))

_HEX40 = re.compile(r"^[a-fA-F0-9]{40}$")


class AIOStreamsError(Exception):
    def __init__(self, message: str, diagnosis: str = "error", status: int = 0):
        super().__init__(message)
        self.diagnosis = diagnosis
        self.status = status


def config() -> dict:
    """Effective credentials: Config page first, environment second."""
    def pick(setting_key: str, env_key: str) -> tuple[str, str]:
        v = (guard._setting(setting_key, "") or "").strip()
        if v:
            return v, "config"
        v = os.environ.get(env_key, "").strip()
        return (v, "env") if v else ("", "")

    url, url_src = pick("aiostreams_url", "AIOSTREAMS_URL")
    uuid, uuid_src = pick("aiostreams_uuid", "AIOSTREAMS_UUID")
    pw, _ = pick("aiostreams_password", "AIOSTREAMS_PASSWORD")
    source = "config" if "config" in (url_src, uuid_src) else ("env" if url_src or uuid_src else "")
    return {"url": url.rstrip("/"), "uuid": uuid, "password": pw, "source": source}


def is_configured(cfg: Optional[dict] = None) -> bool:
    cfg = cfg or config()
    return bool(cfg["url"] and cfg["uuid"] and cfg["password"])


def _auth(uuid: str, password: str) -> dict:
    token = base64.b64encode(f"{uuid}:{password}".encode()).decode()
    return {"Authorization": f"Basic {token}"}


def _get(cfg: dict, kind: str, media_id: str, timeout: float, priority: int) -> dict:
    aiostreams_limiter.acquire(priority)
    guard.stats.inc("aiostreams_calls")
    try:
        r = requests.get(f"{cfg['url']}/api/v1/search", params={"type": kind, "id": media_id},
                         headers=_auth(cfg["uuid"], cfg["password"]), timeout=timeout)
    except requests.ConnectionError as exc:
        raise AIOStreamsError(f"Can't reach AIOStreams at {cfg['url']}", "unreachable") from exc
    except requests.Timeout as exc:
        raise AIOStreamsError(f"AIOStreams didn't answer within {int(timeout)}s", "timeout") from exc
    except requests.RequestException as exc:
        raise AIOStreamsError(f"AIOStreams request failed: {exc}", "unreachable") from exc

    if r.status_code in (401, 403):
        raise AIOStreamsError("AIOStreams rejected the UUID/password", "bad_auth", r.status_code)
    if r.status_code == 404:
        raise AIOStreamsError("No AIOStreams search API at that URL — check the address and port",
                              "not_found", 404)
    if r.status_code == 429:
        guard.stats.inc("aiostreams_429")
        aiostreams_limiter.pause(float(guard._setting("torbox_429_backoff_seconds", 30)))
        raise AIOStreamsError("AIOStreams is rate limiting", "rate_limited", 429)
    try:
        body = r.json()
    except ValueError as exc:
        raise AIOStreamsError(f"AIOStreams returned a non-JSON response (HTTP {r.status_code})",
                              "bad_response", r.status_code) from exc
    if r.status_code >= 400 or not body.get("success", False):
        err = body.get("error") or {}
        msg = err.get("message") if isinstance(err, dict) else str(err)
        raise AIOStreamsError(f"AIOStreams error: {msg or body.get('detail') or r.status_code}",
                              "error", r.status_code)
    data = body.get("data") or {}
    for e in data.get("errors") or []:
        log.warning("AIOStreams addon error — %s: %s", e.get("title", ""), e.get("description", ""))
    return data


def _map_result(r: dict) -> Optional[dict]:
    """AIOStreams SearchResult → the dict shape the TorBox layer ranks/binds."""
    h = (r.get("infoHash") or "").strip()
    if not _HEX40.match(h):
        return None
    pf = r.get("parsedFile") or {}
    folder = r.get("folderName") or ""
    filename = r.get("filename") or ""
    # The torrent's own name drives pack detection; the file name is the
    # better source for resolution/codec tags when there's no folder.
    title = folder or filename
    return {
        "hash": h.lower(),
        "raw_title": title,
        "file_hint": filename,
        "size": r.get("size") or 0,
        "cached": bool(r.get("cached")),
        "seeders": r.get("seeders") or 0,
        "resolution": pf.get("resolution"),
        "service": r.get("service"),
        "indexer": r.get("indexer") or r.get("addon"),
        "source": "aiostreams",
    }


def search(imdb_id: str, season: Optional[int] = None, episode: Optional[int] = None,
           priority: int = guard.LOW, cfg: Optional[dict] = None) -> list[dict]:
    cfg = cfg or config()
    if not is_configured(cfg):
        raise AIOStreamsError("AIOStreams isn't set up (Config → Connections)", "not_configured")
    kind, media_id = ("series", f"{imdb_id}:{season}:{episode}") if season is not None else ("movie", imdb_id)
    data = _get(cfg, kind, media_id, timeout=float(guard._setting("aiostreams_timeout_seconds", 60)),
                priority=priority)
    raw = data.get("results") or []
    mapped = [m for m in (_map_result(r) for r in raw) if m]
    log.info("AIOStreams %s %s → %d result(s), %d torrent(s) with a hash",
             kind, media_id, len(raw), len(mapped))
    return mapped


def test(url: str, uuid: str, password: str) -> dict:
    """Check credentials with a real search for a very widely indexed title."""
    cfg = {"url": url.strip().rstrip("/"), "uuid": uuid.strip(), "password": password}
    if not (cfg["url"] and cfg["uuid"] and cfg["password"]):
        raise AIOStreamsError("URL, UUID and password are all required", "not_configured")
    if not re.match(r"^https?://", cfg["url"]):
        raise AIOStreamsError("URL must start with http:// or https://", "not_found")
    data = _get(cfg, "movie", "tt0068646", timeout=30, priority=guard.HIGH)
    raw = data.get("results") or []
    torrents = [m for m in (_map_result(r) for r in raw) if m]
    return {
        "total_results": len(raw),
        "torrent_results": len(torrents),
        "cached_torrents": sum(1 for t in torrents if t["cached"]),
        "addon_errors": len(data.get("errors") or []),
    }
