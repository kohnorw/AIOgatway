"""
gateway/library_items.py
~~~~~~~~~~~~~~~~~~~~~~~~~
Tracks which titles have been added to the library, independent of
whatever stubs currently happen to exist for them.

Every other piece of "is this in the library" logic in this app (the
Library grid, missing-episode counts, etc.) is derived by grouping
whatever stubs are currently on disk — which is normally fine, but it
means deleting the last stub for a title (e.g. "Delete HD stub" on a
movie that only ever had an HD stub) makes the title vanish from the
library entirely, with no way to tell it was ever added. That's an
accident of implementation, not something anyone asked for: removing a
stream shouldn't be the same action as removing the title.

This module is the fix — a small, deliberately dumb record of
"imdb_id → this title is in the library", written once when the first
stub for a title is created and only ever removed by an explicit
"Delete series"/"Delete movie" action (see /api/movie/{imdb_id} and
/api/series/{imdb_id} in main.py). Same persistence shape as
pending_movies.py / wanted_seasons.py.
"""
from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger("aiogateway.libraryitems")

# imdb_id -> {imdb_id, title, media_type, year, poster, added_at}
_items: dict[str, dict] = {}
_loaded = False


def _state_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_library_items.json"


def _load() -> None:
    global _items, _loaded
    if _loaded:
        return
    path = _state_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text())
            _items = {item["imdb_id"]: item for item in raw}
            logger.info("Loaded %d library item(s) from %s", len(_items), path)
    except Exception as exc:
        logger.warning("Could not load library items from %s: %s", path, exc)
        _items = {}
    _loaded = True


def _persist() -> None:
    path = _state_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(list(_items.values()), indent=2))
    except Exception as exc:
        logger.warning("Could not persist library items to %s: %s", path, exc)


def touch(imdb_id: str, title: str, media_type: str,
          year: Optional[int] = None, poster: str = "") -> None:
    """
    Record that this title is in the library. Safe to call every time a
    stub is created (see StubManager._create_one) — a no-op cost-wise
    once the entry already exists, but it does fill in title/poster/year
    if an earlier call didn't have them yet (e.g. an episode stub created
    before Cinemeta metadata was fully resolved).
    """
    _load()
    existing = _items.get(imdb_id)
    if existing:
        if title and not existing.get("title"):
            existing["title"] = title
        if poster and not existing.get("poster"):
            existing["poster"] = poster
        if year and not existing.get("year"):
            existing["year"] = year
        # Backfilled for the same reason as the rest: set_requester() can
        # create the entry first (it runs at the top of an add, before any
        # stub exists) with no media_type, and a series left blank here
        # would fall back to "movie" in the Library grid.
        if media_type and not existing.get("media_type"):
            existing["media_type"] = media_type
        _persist()
        return
    _items[imdb_id] = {
        "imdb_id": imdb_id, "title": title, "media_type": media_type,
        "year": year, "poster": poster, "added_at": time.time(),
    }
    _persist()


def set_requester(imdb_id: str, username: str, plex_user_id: str = "",
                  thumb: str = "") -> None:
    """
    Record who asked for this title. Called from the add endpoints, which
    are the only place with a request (and therefore a logged-in user) in
    scope — touch() runs deep inside stub creation, where there's no way
    to know who triggered it.

    First requester wins: re-adding a title someone else already
    requested, or a rescan that recreates its stubs, doesn't reassign
    credit. Titles added before this existed simply have no requester and
    display as such rather than being attributed to whoever touches them
    next.

    Tolerates being called before touch() — an entry is created and the
    metadata filled in by the touch() that follows.
    """
    _load()
    if not imdb_id or not username:
        return
    entry = _items.get(imdb_id)
    if entry is None:
        entry = _items[imdb_id] = {
            "imdb_id": imdb_id, "title": "", "media_type": "",
            "year": None, "poster": "", "added_at": time.time(),
        }
    if entry.get("requested_by"):
        return
    entry["requested_by"]    = username
    entry["requested_by_id"] = plex_user_id
    entry["requested_by_thumb"] = thumb
    entry["requested_at"]    = time.time()
    _persist()
    logger.info("Recorded %s as the requester of %s", username, imdb_id)


def remove(imdb_id: str) -> bool:
    """Fully forget this title — the deliberate "Delete series"/"Delete
    movie" action, distinct from removing an individual stub/quality."""
    _load()
    if imdb_id in _items:
        del _items[imdb_id]
        _persist()
        return True
    return False


def get(imdb_id: str) -> Optional[dict]:
    _load()
    return _items.get(imdb_id)


def contains(imdb_id: str) -> bool:
    _load()
    return imdb_id in _items


def list_all() -> list[dict]:
    _load()
    return list(_items.values())
