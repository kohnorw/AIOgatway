"""
gateway/cinemeta.py
~~~~~~~~~~~~~~~~~~~
Metadata: titles, posters, years, episode lists and air dates.

Cinemeta is the same catalogue Stremio uses, so what AIOGateway shows
lines up with what AIOStreams can actually find.

Responses are cached on disk with a TTL that depends on how settled the
data is. A finished series never gains an episode, so re-fetching it
daily is pure waste; a currently-airing show needs checking often enough
that a new episode appears the same day it does.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from datetime import datetime, timezone
from typing import Optional

import aiohttp

from .paths import meta_cache_file

logger = logging.getLogger("aiogateway.cinemeta")

BASE = "https://v3-cinemeta.strem.io"

_cache: dict[str, dict] = {}
_lock = asyncio.Lock()
_loaded = False
_dirty = False


def _load() -> None:
    global _loaded
    if _loaded:
        return
    path = meta_cache_file()
    if path.exists():
        try:
            _cache.update(json.loads(path.read_text()))
        except Exception as exc:
            logger.warning("Metadata cache unreadable (%s) — starting fresh", exc)
    _loaded = True


def persist() -> None:
    global _dirty
    if not _dirty:
        return
    path = meta_cache_file()
    try:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(_cache))
        os.replace(tmp, path)
        _dirty = False
    except Exception as exc:
        logger.warning("Could not write the metadata cache: %s", exc)


def _ttl_for(kind: str, meta: dict) -> int:
    """How long this record can be trusted."""
    day = 86400
    if kind == "movie":
        released = _parse_date(meta.get("released") or meta.get("releaseInfo"))
        if released and released < time.time() - 180 * day:
            return 30 * day     # long out; nothing left to change
        return 2 * day

    status = (meta.get("status") or "").lower()
    if status in ("ended", "canceled", "cancelled"):
        return 30 * day
    # Airing, or status unknown. Check often enough that a new episode
    # shows up the day it airs.
    return 6 * 3600


def _parse_date(value) -> Optional[float]:
    if not value:
        return None
    text = str(value)[:10]
    for fmt in ("%Y-%m-%d", "%Y"):
        try:
            return datetime.strptime(text[:len(fmt) + 2] if fmt == "%Y" else text, fmt) \
                .replace(tzinfo=timezone.utc).timestamp()
        except ValueError:
            continue
    return None


async def meta(kind: str, imdb_id: str, refresh: bool = False) -> dict:
    """Fetch metadata for one title, from cache when it's still fresh."""
    _load()
    key = f"{kind}:{imdb_id}"
    now = time.time()

    if not refresh:
        entry = _cache.get(key)
        if entry and now - entry.get("fetched_at", 0) < entry.get("ttl", 0):
            return entry.get("meta") or {}

    url = f"{BASE}/meta/{kind}/{imdb_id}.json"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=20)) as resp:
                if resp.status >= 400:
                    raise RuntimeError(f"HTTP {resp.status}")
                data = await resp.json(content_type=None)
    except Exception as exc:
        logger.warning("Cinemeta %s failed: %s", url, exc)
        # Stale beats empty: an expired record still has the right title
        # and poster, and losing those mid-render is worse than showing
        # something slightly out of date.
        entry = _cache.get(key)
        return (entry or {}).get("meta") or {}

    record = data.get("meta") or {}
    global _dirty
    async with _lock:
        _cache[key] = {"meta": record, "fetched_at": now, "ttl": _ttl_for(kind, record)}
        _dirty = True
    return record


def age_of(kind: str, imdb_id: str) -> Optional[int]:
    """Seconds since this record was fetched, or None if it never was.

    The calendar shows this. A calendar built entirely from week-old
    metadata is showing week-old dates however recently the page loaded,
    and there is no way to tell from looking at it.
    """
    _load()
    entry = _cache.get(f"{kind}:{imdb_id}")
    if not entry:
        return None
    return int(time.time() - entry.get("fetched_at", 0))


async def meta_many(kind: str, imdb_ids: list[str], refresh: bool = False,
                    concurrency: int = 8) -> tuple[dict[str, dict], list[dict]]:
    """Fetch many records at once, returning (by_id, failures).

    Sequential fetching was the actual reason a large calendar took a
    long time to draw — a few hundred tracked titles at one round trip
    each. The semaphore keeps that from turning into a few hundred
    simultaneous connections instead.

    Failures come back rather than being logged and dropped. A calendar
    that silently omits a show looks complete and correct while being
    neither, which is the worst way for this to fail.
    """
    if not imdb_ids:
        return {}, []

    limiter = asyncio.Semaphore(max(1, concurrency))
    results: dict[str, dict] = {}
    failures: list[dict] = []

    async def one(imdb_id: str) -> None:
        async with limiter:
            try:
                record = await meta(kind, imdb_id, refresh=refresh)
            except Exception as exc:
                failures.append({"imdb_id": imdb_id, "kind": kind, "error": str(exc)})
                return
            if record:
                results[imdb_id] = record
            else:
                failures.append({"imdb_id": imdb_id, "kind": kind,
                                 "error": "no metadata available"})

    await asyncio.gather(*(one(i) for i in imdb_ids))
    return results, failures


async def catalog(kind: str, name: str = "top", skip: int = 0) -> list[dict]:
    url = f"{BASE}/catalog/{kind}/{name}.json"
    params = {"skip": str(skip)} if skip else None
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params,
                                   timeout=aiohttp.ClientTimeout(total=20)) as resp:
                if resp.status >= 400:
                    return []
                data = await resp.json(content_type=None)
    except Exception as exc:
        logger.warning("Cinemeta catalog %s/%s failed: %s", kind, name, exc)
        return []
    return data.get("metas") or []


async def search(kind: str, query: str) -> list[dict]:
    url = f"{BASE}/catalog/{kind}/top/search={query}.json"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=20)) as resp:
                if resp.status >= 400:
                    return []
                data = await resp.json(content_type=None)
    except Exception as exc:
        logger.warning("Cinemeta search failed: %s", exc)
        return []
    return data.get("metas") or []


def episodes_of(record: dict) -> list[dict]:
    """Normalised episode list. Specials (season 0) are dropped — Plex
    files them separately and they rarely map cleanly onto releases."""
    out = []
    for video in record.get("videos") or []:
        season = video.get("season")
        number = video.get("episode") or video.get("number")
        if not season or not number:
            continue
        out.append({
            "season": int(season),
            "episode": int(number),
            "title": video.get("name") or video.get("title") or "",
            "released": video.get("released") or video.get("firstAired") or "",
            "overview": video.get("overview", ""),
            "thumbnail": video.get("thumbnail", ""),
        })
    return sorted(out, key=lambda e: (e["season"], e["episode"]))


def has_aired(released: str) -> bool:
    timestamp = _parse_date(released)
    if timestamp is None:
        # No air date recorded. Treating it as aired lets the search
        # decide — if there's genuinely no release yet, nothing comes
        # back and it gets retried later.
        return True
    return timestamp <= time.time()


def year_of(record: dict) -> Optional[int]:
    raw = record.get("year") or record.get("releaseInfo") or ""
    match = str(raw)[:4]
    return int(match) if match.isdigit() else None
