"""
gateway/alldebrid_api.py
~~~~~~~~~~~~~~~~~~~~~~~~
Thin, synchronous AllDebrid API client — the AllDebrid counterpart to
torbox_api.py. Same shape: one shared rate limiter, one error type, sync
(requests) so FUSE read threads can refresh an expired link inline.

Endpoints used (v4 / v4.1):
  POST /v4/magnet/upload      add a magnet, returns its magnet id
  GET  /v4.1/magnet/status    status of one magnet, or the whole library
  GET  /v4/magnet/files       file tree of a ready magnet (each file has a link)
  GET  /v4/link/unlock        one file link -> a direct CDN URL
  POST /v4/magnet/delete      remove a magnet we only added to test the cache
  GET  /v4/user               account check for the Connections page

Cached-only semantics
---------------------
AllDebrid retired the old instant-availability endpoint, so "is this cached?"
is answered the way their API allows now: upload the magnet and look at its
status. statusCode 4 (Ready) immediately (or within a couple of seconds)
means AllDebrid already had it. Anything still queued/downloading is NOT
cached — alldebrid_client deletes it again so the account isn't left pulling
a torrent down, and records a negative so we don't retry it for a while.
"""
from __future__ import annotations

import logging
import os
import threading
import urllib.parse
from typing import Any, Optional

import requests

from . import torbox_guard as guard

log = logging.getLogger("aiogateway.alldebrid.api")

API_BASE = os.environ.get("ALLDEBRID_API_BASE", "https://api.alldebrid.com").rstrip("/")
V4 = f"{API_BASE}/v4"
# magnet/status lives on v4.1 — v4's version is deprecated and returns a
# different envelope for the "whole library" form.
STATUS_URL = f"{API_BASE}/v4.1/magnet/status"
UPLOAD_URL = f"{V4}/magnet/upload"
DELETE_URL = f"{V4}/magnet/delete"
FILES_URL = f"{V4}/magnet/files"
UNLOCK_URL = f"{V4}/link/unlock"
USER_URL = f"{V4}/user"

_UA = "AIOGateway-AllDebrid/1.0"

# AllDebrid marks `agent` required on every v4 endpoint (AUTH_MISSING_AGENT
# is a real error code) — calls fail without it even with a valid key.
AGENT = os.environ.get("ALLDEBRID_AGENT", "aiogateway")

# Status codes from magnet/status. 4 = Ready; below that it's still working
# on it (i.e. not cached); above that it failed.
ST_READY = 4

api_limiter = guard.RateLimiter(
    "alldebrid-api", lambda: guard._setting("alldebrid_requests_per_minute", 200))


def enabled() -> bool:
    """AllDebrid is only used when it's switched on AND a key is present."""
    try:
        from gateway import settings as _settings
        if not bool(_settings.get("alldebrid_enabled", False)):
            return False
    except Exception:
        return False
    return bool(api_key())


def api_key() -> str:
    return key_source()[0]


def key_source() -> tuple[str, str]:
    """(key, source) where source is "config", "env" or "" (not set)."""
    try:
        from gateway import settings as _settings
        k = (_settings.get("alldebrid_api_key", "") or "").strip()
        if k:
            return k, "config"
    except Exception:
        pass
    k = os.environ.get("ALLDEBRID_API_KEY", "").strip()
    return (k, "env") if k else ("", "")


class AllDebridError(Exception):
    def __init__(self, message: str, status: int = 0, code: str = ""):
        super().__init__(message)
        self.status = status
        self.code = code

    @property
    def retryable(self) -> bool:
        # AllDebrid reports most failures as HTTP 200 with an error code, so
        # the code matters as much as the status here.
        if self.code in ("AUTH_BAD_APIKEY", "AUTH_BLOCKED", "AUTH_USER_BANNED",
                         "MAGNET_INVALID_URI", "MAGNET_INVALID_ID", "MAGNET_MUST_BE_PREMIUM",
                         "LINK_IS_MISSING", "LINK_HOST_NOT_SUPPORTED", "NOT_CACHED"):
            return False
        if self.code in ("AUTH_MISSING_APIKEY", "AUTH_MISSING_AGENT"):
            return False
        return self.status == 429 or self.status >= 500 or self.status == 0

    @property
    def rate_limited(self) -> bool:
        return self.status == 429 or self.code == "AUTH_TOO_MANY_REQUESTS"


_session_lock = threading.Lock()
_session: Optional[requests.Session] = None


def _http() -> requests.Session:
    global _session
    with _session_lock:
        if _session is None:
            s = requests.Session()
            adapter = requests.adapters.HTTPAdapter(pool_connections=8, pool_maxsize=16)
            s.mount("https://", adapter)
            s.mount("http://", adapter)
            s.headers["User-Agent"] = _UA
            _session = s
        return _session


def _call(method: str, url: str, *, priority: int, params: Optional[list] = None,
          data: Optional[list] = None, timeout: float = 30, retries: int = 2,
          key: Optional[str] = None) -> Any:
    """One logical API call: limiter -> request -> envelope decode.

    Params and data are lists of pairs, not dicts: AllDebrid takes repeated
    `id[]` / `magnets[]` keys.
    """
    key = key or api_key()
    if not key:
        raise AllDebridError("No AllDebrid API key set (Config → Connections)",
                             status=401, code="AUTH_MISSING_APIKEY")

    headers = {"Authorization": f"Bearer {key}"}
    last: Optional[AllDebridError] = None

    for attempt in range(retries + 1):
        api_limiter.acquire(priority)
        guard.stats.api_call()
        guard.stats.inc("api_calls_alldebrid")
        try:
            if method == "POST":
                r = _http().post(
                    url,
                    params=[("agent", AGENT)],
                    data=urllib.parse.urlencode(list(data or [])),
                    headers={**headers, "Content-Type": "application/x-www-form-urlencoded"},
                    timeout=timeout,
                )
            else:
                r = _http().get(url, params=[("agent", AGENT)] + list(params or []),
                                headers=headers, timeout=timeout)
        except requests.RequestException as exc:
            last = AllDebridError(f"AllDebrid unreachable: {exc}", status=0)
            continue

        if r.status_code == 429:
            guard.stats.inc("alldebrid_429")
            api_limiter.pause(float(guard._setting("alldebrid_429_backoff_seconds", 30)))
            last = AllDebridError("AllDebrid is rate limiting", status=429,
                                  code="AUTH_TOO_MANY_REQUESTS")
            continue
        if r.status_code >= 500:
            last = AllDebridError(f"AllDebrid returned HTTP {r.status_code}", status=r.status_code)
            continue
        if r.status_code >= 400:
            raise AllDebridError(f"AllDebrid returned HTTP {r.status_code}", status=r.status_code)

        try:
            body = r.json()
        except ValueError as exc:
            raise AllDebridError("AllDebrid returned a non-JSON response", status=r.status_code) from exc

        if body.get("status") == "error":
            err = body.get("error") or {}
            code = err.get("code", "") if isinstance(err, dict) else ""
            msg = (err.get("message") if isinstance(err, dict) else str(err)) or code or "unknown error"
            exc = AllDebridError(f"AllDebrid: {msg}", status=r.status_code, code=code)
            if exc.rate_limited:
                api_limiter.pause(float(guard._setting("alldebrid_429_backoff_seconds", 30)))
            if exc.retryable and attempt < retries:
                last = exc
                continue
            raise exc

        return body.get("data") or {}

    raise last or AllDebridError("AllDebrid call failed", status=0)


# ── Endpoints ────────────────────────────────────────────────────────────────

def user_me(priority: int = guard.HIGH, key: Optional[str] = None) -> dict:
    return (_call("GET", USER_URL, priority=priority, key=key) or {}).get("user") or {}


def upload_magnet(h: str, name: str = "", priority: int = guard.LOW) -> Optional[int]:
    """Add a magnet. Returns its AllDebrid id, or None if it was rejected."""
    magnet = f"magnet:?xt=urn:btih:{h.lower()}"
    if name:
        magnet += f"&dn={urllib.parse.quote(name, safe='')}"
    data = _call("POST", UPLOAD_URL, priority=priority, data=[("magnets[]", magnet)])
    for m in (data.get("magnets") or []):
        if m.get("error"):
            err = m["error"]
            raise AllDebridError(f"AllDebrid rejected the magnet: {err.get('message', err)}",
                                 status=400, code=err.get("code", "") if isinstance(err, dict) else "")
        mid = m.get("id")
        if mid:
            return int(mid)
    return None


def magnet_status(magnet_id: int, priority: int = guard.LOW) -> dict:
    data = _call("GET", STATUS_URL, priority=priority, params=[("id[]", int(magnet_id))])
    magnets = data.get("magnets")
    if isinstance(magnets, dict):          # single-id form can return the object directly
        return magnets
    return (magnets or [{}])[0] if magnets else {}


def all_magnets(priority: int = guard.LOW) -> list[dict]:
    """The whole library in one call — each entry carries id, filename, size,
    statusCode and the real info-hash."""
    data = _call("GET", STATUS_URL, priority=priority, params=[])
    magnets = data.get("magnets") or []
    return magnets if isinstance(magnets, list) else [magnets]


def delete_magnet(magnet_id: int, priority: int = guard.LOW) -> None:
    try:
        _call("POST", DELETE_URL, priority=priority, data=[("id", int(magnet_id))])
    except AllDebridError as exc:
        log.debug("Could not delete AllDebrid magnet %s: %s", magnet_id, exc)


_VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".m2ts", ".wmv", ".flv", ".webm"}


def magnet_files(magnet_id: int, priority: int = guard.LOW) -> list[dict]:
    """Flattened file list for a ready magnet.

    AllDebrid returns a nested tree: `n` name, `s` size, `l` link on leaves,
    `e` children on folders. Flattened into the same {id, name, size} shape
    the TorBox path uses, plus the per-file `link` needed to unlock it. `id`
    is the index in this list — AllDebrid has no stable per-file id, which is
    why refs also carry the file name and the name is matched first.
    """
    data = _call("GET", FILES_URL, priority=priority, params=[("id[]", int(magnet_id))])
    out: list[dict] = []

    def collect(node, prefix: str = ""):
        if isinstance(node, list):
            for child in node:
                collect(child, prefix)
            return
        if not isinstance(node, dict):
            return
        name = node.get("n") or ""
        path = f"{prefix}/{name}" if prefix else name
        if node.get("l"):
            out.append({"id": len(out), "name": path, "size": int(node.get("s") or 0),
                        "link": node["l"]})
        if node.get("e"):
            collect(node["e"], path)

    for m in (data.get("magnets") or []):
        collect(m.get("files") or [])
    return out


def unlock(link: str, priority: int = guard.HIGH) -> str:
    """Turn a file link into a direct, time-limited CDN URL."""
    data = _call("GET", UNLOCK_URL, priority=priority, params=[("link", link)])
    url = data.get("link")
    if not url:
        raise AllDebridError("AllDebrid returned no download link", status=502)
    return url


def hash_of(m: dict) -> str:
    return (m.get("hash") or "").strip().lower()
