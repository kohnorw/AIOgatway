"""
gateway/plex_scan.py
~~~~~~~~~~~~~~~~~~~~
Triggers a scoped Plex partial library scan for just the folder containing
a resolved stub, so Plex picks up the renamed " - Ready" file quickly
instead of waiting for its next periodic full scan.

Uses Plex's documented partial-scan endpoint:
  GET /library/sections/{id}/refresh?path={folder}&X-Plex-Token={token}

This only scans the one folder, not the whole library section, so it's
cheap to call on every resolution.
"""
from __future__ import annotations

import logging
import os
import threading
import time
from typing import Optional
from urllib.parse import quote

import requests

log = logging.getLogger("aiogateway.plexscan")

_REQUEST_TIMEOUT = 5

# Cache of {mount-prefix-path-on-plex : section_id} so we don't have to
# call /library/sections on every single resolution.
_section_cache: dict[str, int] = {}
_section_cache_lock = threading.Lock()
_section_cache_ttl = 300   # seconds
_section_cache_at: float = 0


def _plex_config() -> Optional[tuple[str, str]]:
    url   = os.environ.get("PLEX_URL", "").rstrip("/")
    token = os.environ.get("PLEX_TOKEN", "")
    if not url or not token:
        return None
    return url, token


def _refresh_section_cache(plex_url: str, token: str) -> None:
    """Populate _section_cache: library content-root path → section id."""
    global _section_cache_at
    try:
        r = requests.get(
            f"{plex_url}/library/sections",
            params={"X-Plex-Token": token},
            headers={"Accept": "application/json"},
            timeout=_REQUEST_TIMEOUT,
        )
        if r.status_code != 200:
            log.warning("plex /library/sections returned %d", r.status_code)
            return
        data = r.json()
        dirs = data.get("MediaContainer", {}).get("Directory", [])
        with _section_cache_lock:
            _section_cache.clear()
            for d in dirs:
                sid = d.get("key")
                for loc in d.get("Location", []):
                    path = loc.get("path")
                    if path and sid is not None:
                        _section_cache[path] = int(sid)
            _section_cache_at = time.time()
        log.info("Plex section cache refreshed: %s", _section_cache)
    except Exception as exc:
        log.warning("Could not refresh Plex section cache: %s", exc)


def _section_id_for_path(plex_url: str, token: str, folder: str) -> Optional[int]:
    """Find the library section whose content root is a prefix of `folder`."""
    global _section_cache_at
    with _section_cache_lock:
        stale = (time.time() - _section_cache_at) > _section_cache_ttl
        cache_snapshot = dict(_section_cache)
    if not cache_snapshot or stale:
        _refresh_section_cache(plex_url, token)
        with _section_cache_lock:
            cache_snapshot = dict(_section_cache)

    # Find the longest matching root prefix
    best_root, best_sid = None, None
    for root, sid in cache_snapshot.items():
        if folder.startswith(root.rstrip("/") + "/") or folder == root:
            if best_root is None or len(root) > len(best_root):
                best_root, best_sid = root, sid
    return best_sid


def scan_folder_async(folder: str) -> None:
    """
    Fire-and-forget: trigger a Plex partial scan of `folder`.
    Safe to call from sync or async contexts — runs in a daemon thread.
    `folder` should be the directory containing the resolved file, e.g.
    /docker/aiogateway/mnt/Movies/Title (2026)
    """
    cfg = _plex_config()
    if not cfg:
        return  # PLEX_URL/PLEX_TOKEN not configured — nothing to do

    def _run():
        plex_url, token = cfg
        try:
            sid = _section_id_for_path(plex_url, token, folder)
            if sid is None:
                log.warning("No Plex library section found for %s — skipping scan", folder)
                return
            r = requests.get(
                f"{plex_url}/library/sections/{sid}/refresh",
                params={"path": folder, "X-Plex-Token": token},
                timeout=_REQUEST_TIMEOUT,
            )
            if r.status_code in (200, 0):
                log.info("Triggered Plex partial scan: section=%s path=%s", sid, folder)
            else:
                log.warning("Plex partial scan returned %d for %s", r.status_code, folder)
        except Exception as exc:
            log.warning("Plex partial scan failed for %s: %s", folder, exc)

    threading.Thread(target=_run, daemon=True, name="plex-scan").start()
