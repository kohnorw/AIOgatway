"""
gateway/plex_scan.py
~~~~~~~~~~~~~~~~~~~~
Triggers scoped Plex partial scans for just the folders that changed (a new
entry was added, rebound to another torrent, or removed), so Plex notices
without waiting for its periodic full scan. Scans wait for a quiet
period (with a cap), and seasons of one show collapse into one scan, so adding
a big series costs a handful of Plex requests instead of one every few seconds.

  GET /library/sections/{id}/refresh?path={folder}&X-Plex-Token={token}
"""
from __future__ import annotations

import logging
import os
import threading
import time
from typing import Optional

import requests

log = logging.getLogger("aiogateway.plexscan")

_REQUEST_TIMEOUT = 5

# Cache of {mount-prefix-path-on-plex : section_id} so we don't have to
# call /library/sections on every single resolution.
_section_cache: dict[str, int] = {}
_section_cache_lock = threading.Lock()
_section_cache_ttl = 3600  # libraries rarely change; a folder that matches none triggers an early refresh
_SECTION_MISS_REFRESH = 60 # …but at most once a minute
_section_cache_at: float = 0


def _plex_config() -> Optional[tuple[str, str]]:
    url   = os.environ.get("PLEX_URL", "").rstrip("/")
    token = os.environ.get("PLEX_TOKEN", "")
    if not url or not token:
        return None
    return url, token


def _refresh_section_cache(plex_url: str, token: str) -> None:
    """Populate _section_cache: library content-root path → section id."""
    global _section_cache_at
    try:
        r = requests.get(
            f"{plex_url}/library/sections",
            params={"X-Plex-Token": token},
            headers={"Accept": "application/json"},
            timeout=_REQUEST_TIMEOUT,
        )
        if r.status_code != 200:
            log.warning("plex /library/sections returned %d", r.status_code)
            return
        data = r.json()
        dirs = data.get("MediaContainer", {}).get("Directory", [])
        with _section_cache_lock:
            _section_cache.clear()
            for d in dirs:
                sid = d.get("key")
                for loc in d.get("Location", []):
                    path = loc.get("path")
                    if path and sid is not None:
                        _section_cache[path] = int(sid)
            _section_cache_at = time.time()
        log.info("Plex section cache refreshed: %s", _section_cache)
    except Exception as exc:
        log.warning("Could not refresh Plex section cache: %s", exc)


def _section_id_for_path(plex_url: str, token: str, folder: str) -> Optional[int]:
    """Find the library section whose content root is a prefix of `folder`."""
    with _section_cache_lock:
        stale = (time.time() - _section_cache_at) > _section_cache_ttl
        cache_snapshot = dict(_section_cache)
    if not cache_snapshot or stale:
        _refresh_section_cache(plex_url, token)
        with _section_cache_lock:
            cache_snapshot = dict(_section_cache)

    def _match(snapshot):
        best_root, best_sid = None, None
        for root, sid in snapshot.items():
            if folder.startswith(root.rstrip("/") + "/") or folder == root:
                if best_root is None or len(root) > len(best_root):
                    best_root, best_sid = root, sid
        return best_sid

    sid = _match(cache_snapshot)
    if sid is None and time.time() - _section_cache_at > _SECTION_MISS_REFRESH:
        # A library may have been added in Plex since the last lookup.
        _refresh_section_cache(plex_url, token)
        with _section_cache_lock:
            sid = _match(dict(_section_cache))
    return sid


def folder_for_section_id(section_id: int) -> Optional[str]:
    """
    Reverse lookup: given a Plex librarySectionID (always present and
    reliable in webhook payloads, unlike Media/Part file paths or
    videoResolution metadata), return the content-root folder path for
    that section, e.g. "/docker/aiogateway/mnt/Movies4K".

    Used to disambiguate which quality tier (HD vs 4K) a play event is for,
    since the section a title lives in is unambiguous — far more reliable
    than inferring quality from Plex's self-reported videoResolution, which
    reflects the (always small, always similar) stub file's actual encoded
    resolution rather than the real quality tier, until the file resolves.
    """
    cfg = _plex_config()
    if not cfg:
        return None
    plex_url, token = cfg
    with _section_cache_lock:
        stale = (time.time() - _section_cache_at) > _section_cache_ttl
        cache_snapshot = dict(_section_cache)
    if not cache_snapshot or stale:
        _refresh_section_cache(plex_url, token)
        with _section_cache_lock:
            cache_snapshot = dict(_section_cache)
    for path, sid in cache_snapshot.items():
        if sid == section_id:
            return path
    return None


# ── Scan scheduling ───────────────────────────────────────────────────────────
#
# Adding a big series binds episodes one at a time over many minutes (every
# release search is rate limited), so "scan N seconds after the first new
# file" turns into a Plex scan every few seconds for the whole add. Instead:
#
#   quiet period   a scan fires once no new files have arrived for
#                  plex_scan_quiet_seconds (default 30) …
#   max wait       … or plex_scan_max_wait_seconds (default 300) after the
#                  first pending change, so a long add still shows progress.
#   collapse       several season folders of one show → one scan of the show
#                  folder; a folder inside another pending folder is dropped.
#
# One worker thread owns the timer, so there's never more than one flush
# (and one set of Plex requests) in flight.

_pending_folders: dict[str, float] = {}      # folder → first time it became pending
_pending_lock = threading.Condition()
_last_event_at = 0.0
_worker: Optional[threading.Thread] = None
_stats = {"requests_queued": 0, "scans_sent": 0, "flushes": 0, "folders_collapsed": 0}


def _setting(key: str, default: float) -> float:
    try:
        from gateway import settings as _settings
        return float(_settings.get(key, default) or default)
    except Exception:
        return default


def stats() -> dict:
    with _pending_lock:
        return {**_stats, "pending_folders": len(_pending_folders)}


def scan_folder_async(folder: str) -> None:
    """Queue a Plex partial scan of `folder` (see scheduling notes above)."""
    global _last_event_at, _worker
    if not _plex_config():
        return
    with _pending_lock:
        now = time.time()
        _pending_folders.setdefault(folder, now)
        _last_event_at = now
        _stats["requests_queued"] += 1
        if _worker is None or not _worker.is_alive():
            _worker = threading.Thread(target=_worker_loop, name="plex-scan", daemon=True)
            _worker.start()
        _pending_lock.notify_all()


def _due_at() -> float:
    quiet = _setting("plex_scan_quiet_seconds", 30)
    max_wait = _setting("plex_scan_max_wait_seconds", 300)
    first = min(_pending_folders.values())
    return min(_last_event_at + quiet, first + max(max_wait, quiet))


def _worker_loop() -> None:
    while True:
        with _pending_lock:
            while not _pending_folders:
                _pending_lock.wait()
            while _pending_folders:
                wait = _due_at() - time.time()
                if wait <= 0:
                    break
                _pending_lock.wait(timeout=min(wait, 5.0))   # re-evaluate on new events / setting changes
            folders = list(_pending_folders)
            _pending_folders.clear()
            _stats["flushes"] += 1
        try:
            _flush(folders)
        except Exception as exc:
            log.warning("Plex scan flush failed: %s", exc)


_SEASON_RE = __import__("re").compile(r"/Season \d+$")


def collapse_folders(folders: list[str]) -> list[str]:
    """Fewest folders that cover every change: seasons of the same show →
    the show folder when more than one is pending; nested folders dropped."""
    by_show: dict[str, list[str]] = {}
    out: set[str] = set()
    for f in folders:
        f = f.rstrip("/")
        if _SEASON_RE.search(f):
            by_show.setdefault(f.rsplit("/", 1)[0], []).append(f)
        else:
            out.add(f)
    for show, seasons in by_show.items():
        if len(set(seasons)) > 1:
            out.add(show)
        else:
            out.add(seasons[0])
    return sorted(f for f in out if not any(f != o and f.startswith(o + "/") for o in out))


def _flush(folders: list[str]) -> None:
    roots = collapse_folders(folders)
    with _pending_lock:
        _stats["folders_collapsed"] += max(0, len(set(folders)) - len(roots))
    for f in roots:
        _scan_now(f)


def flush_now() -> None:
    """Send every pending scan immediately (used on shutdown and by tests)."""
    with _pending_lock:
        folders = list(_pending_folders)
        _pending_folders.clear()
        if folders:
            _stats["flushes"] += 1
    if folders:
        _flush(folders)


def _scan_now(folder: str) -> None:
    cfg = _plex_config()
    if not cfg:
        return
    plex_url, token = cfg
    try:
        sid = _section_id_for_path(plex_url, token, folder)
        if sid is None:
            log.warning("No Plex library section found for %s — skipping scan", folder)
            return
        r = requests.get(
            f"{plex_url}/library/sections/{sid}/refresh",
            params={"path": folder, "X-Plex-Token": token},
            timeout=_REQUEST_TIMEOUT,
        )
        with _pending_lock:
            _stats["scans_sent"] += 1
        if r.status_code in (200, 0):
            log.info("Triggered Plex partial scan: section=%s path=%s", sid, folder)
        else:
            log.warning("Plex partial scan returned %d for %s", r.status_code, folder)
    except Exception as exc:
        log.warning("Plex partial scan failed for %s: %s", folder, exc)
