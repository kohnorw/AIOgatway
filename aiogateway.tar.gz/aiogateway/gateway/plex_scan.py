"""
gateway/plex_scan.py
~~~~~~~~~~~~~~~~~~~~
Triggers a scoped Plex partial library scan for just the folder containing
a resolved stub, so Plex picks up the renamed " - Ready" file quickly
instead of waiting for its next periodic full scan.

Uses Plex's documented partial-scan endpoint:
  GET /library/sections/{id}/refresh?path={folder}&X-Plex-Token={token}

This only scans the one folder, not the whole library section, so it's
cheap to call on every resolution.
"""
from __future__ import annotations

import logging
import os
import threading
import time
from typing import Optional

import requests

log = logging.getLogger("aiogateway.plexscan")

_REQUEST_TIMEOUT = 5

# Cache of {mount-prefix-path-on-plex : section_id} so we don't have to
# call /library/sections on every single resolution.
_section_cache: dict[str, int] = {}
_section_cache_lock = threading.Lock()
_section_cache_ttl = 300   # seconds
_section_cache_at: float = 0


def _plex_config() -> Optional[tuple[str, str]]:
    url   = os.environ.get("PLEX_URL", "").rstrip("/")
    token = os.environ.get("PLEX_TOKEN", "")
    if not url or not token:
        return None
    return url, token


def _refresh_section_cache(plex_url: str, token: str) -> None:
    """Populate _section_cache: library content-root path → section id."""
    global _section_cache_at
    try:
        r = requests.get(
            f"{plex_url}/library/sections",
            params={"X-Plex-Token": token},
            headers={"Accept": "application/json"},
            timeout=_REQUEST_TIMEOUT,
        )
        if r.status_code != 200:
            log.warning("plex /library/sections returned %d", r.status_code)
            return
        data = r.json()
        dirs = data.get("MediaContainer", {}).get("Directory", [])
        with _section_cache_lock:
            _section_cache.clear()
            for d in dirs:
                sid = d.get("key")
                for loc in d.get("Location", []):
                    path = loc.get("path")
                    if path and sid is not None:
                        _section_cache[path] = int(sid)
            _section_cache_at = time.time()
        log.info("Plex section cache refreshed: %s", _section_cache)
    except Exception as exc:
        log.warning("Could not refresh Plex section cache: %s", exc)


def _section_id_for_path(plex_url: str, token: str, folder: str) -> Optional[int]:
    """Find the library section whose content root is a prefix of `folder`."""
    # Read-only here; _refresh_section_cache() owns the write.
    with _section_cache_lock:
        stale = (time.time() - _section_cache_at) > _section_cache_ttl
        cache_snapshot = dict(_section_cache)
    if not cache_snapshot or stale:
        _refresh_section_cache(plex_url, token)
        with _section_cache_lock:
            cache_snapshot = dict(_section_cache)

    # Find the longest matching root prefix
    best_root, best_sid = None, None
    for root, sid in cache_snapshot.items():
        if folder.startswith(root.rstrip("/") + "/") or folder == root:
            if best_root is None or len(root) > len(best_root):
                best_root, best_sid = root, sid
    return best_sid


def folder_for_section_id(section_id: int) -> Optional[str]:
    """
    Reverse lookup: given a Plex librarySectionID (always present and
    reliable in webhook payloads, unlike Media/Part file paths or
    videoResolution metadata), return the content-root folder path for
    that section, e.g. "/docker/aiogateway/mnt/Movies4K".

    Used to disambiguate which quality tier (HD vs 4K) a play event is for,
    since the section a title lives in is unambiguous — far more reliable
    than inferring quality from Plex's self-reported videoResolution, which
    reflects the (always small, always similar) stub file's actual encoded
    resolution rather than the real quality tier, until the file resolves.
    """
    cfg = _plex_config()
    if not cfg:
        return None
    plex_url, token = cfg
    with _section_cache_lock:
        stale = (time.time() - _section_cache_at) > _section_cache_ttl
        cache_snapshot = dict(_section_cache)
    if not cache_snapshot or stale:
        _refresh_section_cache(plex_url, token)
        with _section_cache_lock:
            cache_snapshot = dict(_section_cache)
    for path, sid in cache_snapshot.items():
        if sid == section_id:
            return path
    return None


def analyze_item_async(rating_key: str, refresh: bool = True) -> None:
    """
    Fire-and-forget: trigger Plex to re-analyze a specific item (by its
    ratingKey) right after its stub has just been resolved from a
    placeholder to a real stream.

    Why this is needed: Plex's cached media info — audio tracks, subtitle
    tracks, bitrate, codec — was read from the tiny placeholder .mkv when
    Plex first scanned it. Swapping the stub's served content over to the
    real stream (via FUSE) doesn't retroactively fix what Plex already
    has cached for that item; Plex needs to be told to re-read the file,
    which is what "Analyze" does. Without this, Plex keeps showing
    placeholder-derived audio/subtitle info until its next scheduled full
    library scan, which can be hours away.

    refresh also triggers a metadata refresh (poster/summary/etc from the
    configured agent) — not the primary reason this exists, but cheap to
    include while already touching this item.
    """
    cfg = _plex_config()
    if not cfg or not rating_key:
        return

    def _run():
        plex_url, token = cfg
        try:
            r = requests.put(
                f"{plex_url}/library/metadata/{rating_key}/analyze",
                params={"X-Plex-Token": token},
                timeout=_REQUEST_TIMEOUT,
            )
            if r.status_code in (200, 0):
                log.info("Triggered Plex analyze for ratingKey=%s", rating_key)
            else:
                log.warning("Plex analyze returned %d for ratingKey=%s", r.status_code, rating_key)
        except Exception as exc:
            log.warning("Plex analyze failed for ratingKey=%s: %s", rating_key, exc)

        if refresh:
            try:
                r = requests.put(
                    f"{plex_url}/library/metadata/{rating_key}/refresh",
                    params={"X-Plex-Token": token},
                    timeout=_REQUEST_TIMEOUT,
                )
                if r.status_code in (200, 0):
                    log.info("Triggered Plex metadata refresh for ratingKey=%s", rating_key)
                else:
                    log.warning("Plex refresh returned %d for ratingKey=%s", r.status_code, rating_key)
            except Exception as exc:
                log.warning("Plex refresh failed for ratingKey=%s: %s", rating_key, exc)

    threading.Thread(target=_run, daemon=True, name="plex-analyze").start()


def scan_folder_async(folder: str) -> None:
    """
    Fire-and-forget: trigger a Plex partial scan of `folder`.
    Safe to call from sync or async contexts — runs in a daemon thread.
    `folder` should be the directory containing the resolved file, e.g.
    /docker/aiogateway/mnt/Movies/Title (2026)
    """
    cfg = _plex_config()
    if not cfg:
        return  # PLEX_URL/PLEX_TOKEN not configured — nothing to do

    def _run():
        plex_url, token = cfg
        try:
            sid = _section_id_for_path(plex_url, token, folder)
            if sid is None:
                log.warning("No Plex library section found for %s — skipping scan", folder)
                return
            r = requests.get(
                f"{plex_url}/library/sections/{sid}/refresh",
                params={"path": folder, "X-Plex-Token": token},
                timeout=_REQUEST_TIMEOUT,
            )
            if r.status_code in (200, 0):
                log.info("Triggered Plex partial scan: section=%s path=%s", sid, folder)
            else:
                log.warning("Plex partial scan returned %d for %s", r.status_code, folder)
        except Exception as exc:
            log.warning("Plex partial scan failed for %s: %s", folder, exc)

    threading.Thread(target=_run, daemon=True, name="plex-scan").start()
