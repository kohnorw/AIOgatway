"""gateway/stub_manager.py — Creates and tracks placeholder .mkv files."""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

from .models import MediaItem, MediaType, Quality, Stub, StubState

logger = logging.getLogger("aiogateway.stubs")


def _library_root() -> Path:
    """
    Where stub files are physically written.

    When FUSE is in use, this is the real backing directory (separate
    from the FUSE mountpoint that Plex/Sonarr actually browse) so that
    FUSE is never mounted on top of the same directory it reads from.
    Falls back to LIBRARY_ROOT itself when FUSE is unavailable, since
    in that case stubs are served directly with no mount in the way.
    """
    mount_root = os.environ.get("LIBRARY_ROOT", "/library")
    real_root  = os.environ.get("LIBRARY_REAL_ROOT")
    if real_root:
        return Path(real_root)
    try:
        from .fuse_fs import FUSE_AVAILABLE
    except Exception:
        FUSE_AVAILABLE = False
    if FUSE_AVAILABLE:
        return Path(mount_root.rstrip("/") + "_real")
    return Path(mount_root)


FOLDER_MAP = {
    (MediaType.MOVIE,  Quality.HD):  "Movies",
    (MediaType.MOVIE,  Quality.UHD): "Movies4K",
    (MediaType.SERIES, Quality.HD):  "Series",
    (MediaType.SERIES, Quality.UHD): "Series4K",
}


# Real stub MKV files — valid Matroska files with proper duration/tracks
# so Plex accepts them without immediately stopping playback.
# Located in stubs/ directory next to this package.
_STUBS_DIR = Path(__file__).parent.parent / "stubs"
_STUB_HD   = _STUBS_DIR / "hd.mkv"
_STUB_4K   = _STUBS_DIR / "4k.mkv"


def _get_stub_bytes(quality: Quality) -> bytes:
    """Return the real stub MKV bytes for the given quality tier."""
    stub_path = _STUB_4K if quality == Quality.UHD else _STUB_HD
    if stub_path.exists():
        return stub_path.read_bytes()
    # Fallback: try the other stub
    fallback = _STUB_HD if quality == Quality.UHD else _STUB_4K
    if fallback.exists():
        return fallback.read_bytes()
    # Last resort: minimal EBML header (original approach)
    logger.warning("Real stub files not found in %s — using minimal EBML header", _STUBS_DIR)
    ebml = bytes([
        0x1A,0x45,0xDF,0xA3, 0x9F,
        0x42,0x86,0x81,0x01, 0x42,0xF7,0x81,0x01,
        0x42,0xF2,0x81,0x04, 0x42,0xF3,0x81,0x08,
        0x42,0x82,0x88,
        0x6D,0x61,0x74,0x72,0x6F,0x73,0x6B,0x61,
        0x42,0x87,0x81,0x04, 0x42,0x85,0x81,0x02,
    ])
    segment = bytes([0x18,0x53,0x80,0x67,0x01,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF])
    return ebml + segment


def _stub_id(media_id: str, quality: Quality) -> str:
    return hashlib.sha256(f"{media_id}:{quality.value}".encode()).hexdigest()[:16]


class StubManager:
    def __init__(self) -> None:
        self._stubs: dict[str, Stub] = {}
        self._path_index: dict[str, str] = {}

    def _build_path(self, item: MediaItem, quality: Quality) -> Path:
        folder_name = FOLDER_MAP[(item.media_type, quality)]
        base = _library_root() / folder_name

        if item.media_type == MediaType.MOVIE:
            return base / item.folder_name / f"{item.file_stem}.mkv"
        else:
            # Series: /library/Series/Show Title (Year)/Season 01/S01E01 - Episode Title.mkv
            return base / item.folder_name / item.season_folder / f"{item.file_stem}.mkv"

    async def create_stubs(self, item: MediaItem) -> list[Stub]:
        """Create HD stub always; 4K stub only if item.has_4k."""
        qualities = [Quality.HD]
        if item.has_4k:
            qualities.append(Quality.UHD)

        created = []
        for q in qualities:
            # Pass the best stream for this quality so size is known immediately
            best = item.best_stream(q)
            stub = await self._create_one(item, q, best)
            created.append(stub)
        return created

    async def _create_one(self, item: MediaItem, quality: Quality, best_stream=None) -> Stub:
        sid = _stub_id(item.id, quality)
        if sid in self._stubs:
            return self._stubs[sid]

        path = self._build_path(item, quality)
        await asyncio.to_thread(path.parent.mkdir, parents=True, exist_ok=True)
        await asyncio.to_thread(path.write_bytes, _get_stub_bytes(quality))

        stub = Stub(
            stub_id         = sid,
            media_id        = item.id,
            title           = item.title,
            quality         = quality,
            abs_path        = str(path),
            imdb_id         = item.imdb_id,
            aiostreams_type = item.aiostreams_type,
            aiostreams_id   = item.aiostreams_id,
            # Path-derivation fields
            media_type      = item.media_type,
            show_title      = item.show_title,
            year            = item.year,
            season          = item.season,
            episode         = item.episode,
            # Store real file size immediately so getattr() never reports stub size
            stream_size     = best_stream.size if best_stream and best_stream.size else None,
        )
        self._stubs[sid] = stub
        self._path_index[str(path)] = sid

        # Sidecar for restart persistence
        poster = getattr(item, "_poster", "")
        stub._poster = poster
        sidecar = path.with_suffix(".aiogateway.json")
        await asyncio.to_thread(sidecar.write_text, json.dumps({
            "stub_id":        sid,
            "media_id":       item.id,
            "title":          item.title,
            "imdb_id":        item.imdb_id,
            "quality":        quality.value,
            "media_type":     item.media_type.value,
            "aiostreams_type": item.aiostreams_type,
            "aiostreams_id":  item.aiostreams_id,
            "poster":         poster,
            "created_at":     stub.created_at,
            # Path-derivation fields
            "show_title":     item.show_title,
            "year":           item.year,
            "season":         item.season,
            "episode":        item.episode,
            # Real file size — avoids stub-size getattr() on restart
            "stream_size":    stub.stream_size,
        }, indent=2))

        logger.info("Created stub: %s → %s", sid, path)
        return stub

    # -- Lookups --------------------------------------------------------------

    def get(self, stub_id: str) -> Optional[Stub]:
        return self._stubs.get(stub_id)

    def by_path(self, path: str) -> Optional[Stub]:
        sid = self._path_index.get(path)
        return self._stubs.get(sid) if sid else None

    def all(self) -> list[Stub]:
        return list(self._stubs.values())

    # -- TTL expiry -------------------------------------------------------------

    def revert_to_placeholder(self, sid: str) -> None:
        """
        Revert a resolved stub back to PLACEHOLDER, dropping its stream URL,
        headers, and real file size so it goes back to being a virtual stub
        until next played. Used by the active-TTL sweep, and safe to call
        manually (e.g. a future "force re-resolve" UI action).
        """
        if s := self._stubs.get(sid):
            if s.state != StubState.ACTIVE:
                return
            old_url = s.stream_url
            s.state          = StubState.PLACEHOLDER
            s.stream_url     = None
            s.stream_headers = {}
            s.stream_size    = None
            s.resolved_at    = None
            if old_url:
                try:
                    from .fuse_fs import _block_cache
                    _block_cache.invalidate(old_url)
                except Exception:
                    pass
            # The virtual filename drops its "- Ready" suffix the moment
            # state != ACTIVE (see fuse_fs._stub_path), so Plex's existing
            # library entry now points at a path readdir() no longer lists.
            # Trigger a scoped rescan so Plex notices and cleans it up,
            # rather than leaving a stale/broken entry until its next
            # periodic full scan.
            try:
                from .fuse_fs import _fs_instance
                from .plex_scan import scan_folder_async
                if _fs_instance is not None:
                    folder = _fs_instance._resolved_folder(s)
                    scan_folder_async(folder)
            except Exception as exc:
                logger.warning("Could not trigger Plex rescan after revert for %s: %s", sid, exc)
            logger.info("[%s] reverted to stub (active TTL expired)", sid)

    def sweep_expired(self, ttl_minutes: int) -> int:
        """
        Revert any ACTIVE stub whose resolved_at is older than ttl_minutes
        back to PLACEHOLDER. Returns the number reverted. ttl_minutes <= 0
        disables the sweep entirely (nothing is ever reverted).
        """
        if ttl_minutes <= 0:
            return 0
        cutoff = time.time() - (ttl_minutes * 60)
        count = 0
        for s in list(self._stubs.values()):
            if s.state == StubState.ACTIVE and s.resolved_at and s.resolved_at < cutoff:
                self.revert_to_placeholder(s.stub_id)
                count += 1
        return count

    # -- State ----------------------------------------------------------------

    def set_resolving(self, sid: str) -> None:
        if s := self._stubs.get(sid):
            s.state = StubState.RESOLVING
            # Reset the event so the next read() waits fresh
            try:
                from .fuse_fs import _get_resolve_event
                _get_resolve_event(sid).clear()
            except Exception:
                pass

    # Minimum plausible size for real movie/episode media — mirrors the
    # same guard in aiostreams_client._probe_stream(). Applied here too as
    # defense in depth: if a candidate somehow reached set_active() with an
    # implausibly small size, reject the resolution rather than activating
    # a stub that will only ever serve a near-empty file.
    _MIN_PLAUSIBLE_MEDIA_BYTES = 50 * 1024 * 1024   # 50MB

    def set_active(self, sid: str, url: str, headers: dict, size: Optional[int] = None) -> None:
        if s := self._stubs.get(sid):
            resolved_size = size

            if not resolved_size:
                # AIOStreams didn't return a size — try a HEAD request to get
                # Content-Length from the CDN so getattr() can report the real size
                r = None
                try:
                    import requests as _req
                    r = _req.head(url, headers=headers, timeout=5, allow_redirects=True)
                    cl = r.headers.get("Content-Length") or r.headers.get("content-length")
                    if cl:
                        resolved_size = int(cl)
                except Exception:
                    pass
                finally:
                    if r is not None:
                        r.close()

            if resolved_size and resolved_size < self._MIN_PLAUSIBLE_MEDIA_BYTES:
                logger.warning(
                    "[%s] rejecting resolution: reported size %d bytes (%.1f MB) "
                    "is implausibly small for real media — treating as a bad link",
                    sid, resolved_size, resolved_size / 1024 / 1024
                )
                self.set_error(sid)
                return

            s.state, s.stream_url, s.stream_headers = StubState.ACTIVE, url, headers
            s.error_count   = 0   # successful resolution clears any prior failure streak
            s.last_error_at = None
            if resolved_size:
                s.stream_size = resolved_size
            s.resolved_at = time.time()
            # Wake any FUSE read() that's waiting for this stub to resolve
            try:
                from .fuse_fs import signal_resolved
                signal_resolved(sid)
            except Exception:
                pass
            # Trigger a scoped Plex partial scan of just this stub's folder
            # so Plex picks up the renamed " - Ready" file quickly, instead
            # of waiting for the next periodic/full library scan.
            try:
                from .fuse_fs import _fs_instance
                from .plex_scan import scan_folder_async
                if _fs_instance is not None:
                    folder = _fs_instance._resolved_folder(s)
                    scan_folder_async(folder)
            except Exception as exc:
                logger.warning("Could not trigger Plex partial scan for %s: %s", sid, exc)

    def set_error(self, sid: str) -> None:
        if s := self._stubs.get(sid):
            s.state         = StubState.ERROR
            s.error_count  += 1
            s.last_error_at = time.time()
            # Wake any waiting read() so it falls back to stub bytes immediately
            try:
                from .fuse_fs import signal_resolved
                signal_resolved(sid)
            except Exception:
                pass

    # Backoff schedule (seconds) by error_count, capped at the last value.
    _ERROR_COOLDOWNS = [30, 60, 300, 900, 3600]   # 30s, 1m, 5m, 15m, 1h

    def in_error_cooldown(self, sid: str) -> bool:
        """
        True if this stub recently failed resolution and is still within its
        backoff window — callers should skip re-probing AIOStreams/CDN links
        and just serve stub bytes instead. Prevents hammering a permanently
        dead title's sources on every single play attempt.
        """
        s = self._stubs.get(sid)
        if not s or s.state != StubState.ERROR or not s.last_error_at:
            return False
        idx = min(s.error_count - 1, len(self._ERROR_COOLDOWNS) - 1)
        cooldown = self._ERROR_COOLDOWNS[max(idx, 0)]
        return (time.time() - s.last_error_at) < cooldown

    # -- Restore from disk on restart -----------------------------------------

    async def restore(self) -> int:
        count = 0
        root = _library_root()
        if not root.exists():
            return 0
        for sidecar in root.rglob("*.aiogateway.json"):
            try:
                data = json.loads(sidecar.read_text())
                mkv = sidecar.with_suffix("").with_suffix(".mkv")
                if not mkv.exists():
                    continue
                quality = Quality(data["quality"])
                stub = Stub(
                    stub_id         = data["stub_id"],
                    media_id        = data["media_id"],
                    title           = data.get("title", ""),
                    quality         = quality,
                    abs_path        = str(mkv),
                    imdb_id         = data["imdb_id"],
                    aiostreams_type = data["aiostreams_type"],
                    aiostreams_id   = data["aiostreams_id"],
                    created_at      = data.get("created_at", time.time()),
                    # Path-derivation fields (may be absent in old sidecars)
                    media_type      = MediaType(data.get("media_type", "movie")),
                    show_title      = data.get("show_title", ""),
                    year            = data.get("year"),
                    season          = data.get("season"),
                    episode         = data.get("episode"),
                    stream_size     = data.get("stream_size"),
                )
                stub._poster = data.get("poster", "")
                self._stubs[stub.stub_id] = stub
                self._path_index[stub.abs_path] = stub.stub_id
                count += 1
            except Exception as exc:
                logger.warning("Could not restore sidecar %s: %s", sidecar, exc)
        return count
