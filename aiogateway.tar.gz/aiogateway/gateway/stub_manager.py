"""gateway/stub_manager.py — Creates and tracks placeholder .mkv files."""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

from .models import MediaItem, MediaType, Quality, Stub, StubState
from . import settings as _settings

logger = logging.getLogger("aiogateway.stubs")


def _library_root() -> Path:
    """
    Where stub sidecar files (.json metadata + tiny placeholder .mkv bytes)
    are physically written for persistence across restarts.

    This is independent of FUSE_MOUNTPOINT (the virtual filesystem Plex
    actually browses) — it's purely an on-disk metadata store, a sibling
    directory next to the mountpoint, e.g. /docker/aiogateway/mnt_data.

    LIBRARY_DATA_ROOT can override this explicitly. (Older LIBRARY_ROOT /
    LIBRARY_REAL_ROOT env vars were used by a previous passthrough-FUSE
    architecture and are no longer read — this app is now fully virtual.)
    """
    override = os.environ.get("LIBRARY_DATA_ROOT")
    if override:
        return Path(override)
    mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    return Path(mountpoint.rstrip("/") + "_data")


FOLDER_MAP = {
    (MediaType.MOVIE,  Quality.HD):  "Movies",
    (MediaType.MOVIE,  Quality.UHD): "Movies4K",
    (MediaType.SERIES, Quality.HD):  "Series",
    (MediaType.SERIES, Quality.UHD): "Series4K",
}


# Real stub MKV files — valid Matroska files with proper duration/tracks
# so Plex accepts them without immediately stopping playback.
# Located in stubs/ directory next to this package.
_STUBS_DIR = Path(__file__).parent.parent / "stubs"
_STUB_HD   = _STUBS_DIR / "hd.mkv"
_STUB_4K   = _STUBS_DIR / "4k.mkv"


def _get_stub_bytes(quality: Quality) -> bytes:
    """Return the real stub MKV bytes for the given quality tier."""
    stub_path = _STUB_4K if quality == Quality.UHD else _STUB_HD
    if stub_path.exists():
        return stub_path.read_bytes()
    # Fallback: try the other stub
    fallback = _STUB_HD if quality == Quality.UHD else _STUB_4K
    if fallback.exists():
        return fallback.read_bytes()
    # Last resort: minimal EBML header (original approach)
    logger.warning("Real stub files not found in %s — using minimal EBML header", _STUBS_DIR)
    ebml = bytes([
        0x1A,0x45,0xDF,0xA3, 0x9F,
        0x42,0x86,0x81,0x01, 0x42,0xF7,0x81,0x01,
        0x42,0xF2,0x81,0x04, 0x42,0xF3,0x81,0x08,
        0x42,0x82,0x88,
        0x6D,0x61,0x74,0x72,0x6F,0x73,0x6B,0x61,
        0x42,0x87,0x81,0x04, 0x42,0x85,0x81,0x02,
    ])
    segment = bytes([0x18,0x53,0x80,0x67,0x01,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF])
    return ebml + segment


def _stub_id(media_id: str, quality: Quality) -> str:
    return hashlib.sha256(f"{media_id}:{quality.value}".encode()).hexdigest()[:16]


class StubManager:
    def __init__(self) -> None:
        self._stubs: dict[str, Stub] = {}
        self._path_index: dict[str, str] = {}

    def _build_path(self, item: MediaItem, quality: Quality) -> Path:
        folder_name = FOLDER_MAP[(item.media_type, quality)]
        base = _library_root() / folder_name

        if item.media_type == MediaType.MOVIE:
            return base / item.folder_name / f"{item.file_stem}.mkv"
        else:
            # Series: /library/Series/Show Title (Year)/Season 01/S01E01 - Episode Title.mkv
            return base / item.folder_name / item.season_folder / f"{item.file_stem}.mkv"

    async def create_stubs(self, item: MediaItem) -> list[Stub]:
        """
        Create HD stub always; 4K stub only if there are enough
        independent 4K candidates to be reasonably confident one will
        actually work. A single 4K source — as opposed to HD, which
        usually has many — tends to be a rare/uncached torrent that's
        more likely to be dead, slow, or unstable than a title with
        several 4K sources to fall back on. min_4k_candidates (default 2)
        governs the threshold; set to 1 to restore the old "any 4K source
        at all" behaviour.

        Also skips 4K entirely if spot check has already confirmed it's
        unavailable for this exact item (see gateway/quality_unavailable)
        — every automatic caller of create_stubs() (normal adds, the
        background scan, auto-episode discovery, the pending-movies
        sweep) goes through this one function, so gating it here covers
        all of them without needing to special-case each one. The manual
        "Scan 4K" action bypasses this entirely by calling
        create_stub_for_quality() directly instead.
        """
        from gateway import settings as _settings
        from gateway import quality_unavailable as _qu

        min_4k = max(1, _settings.get("min_4k_candidates", 2) or 1)
        uhd_count = sum(1 for s in item.streams if s.is_4k)
        already_marked = _qu.is_marked(item.imdb_id, item.season, item.episode)

        qualities = [Quality.HD]
        if already_marked:
            logger.info("%s: 4K previously confirmed unavailable — skipping (manual Scan 4K to re-check)",
                       item.title)
        elif uhd_count >= min_4k:
            qualities.append(Quality.UHD)
        elif uhd_count > 0:
            logger.info(
                "%s: found %d 4K source(s), below the min_4k_candidates "
                "threshold of %d — skipping 4K stub", item.title, uhd_count, min_4k
            )

        created = []
        for q in qualities:
            # Pass the best stream for this quality so size is known immediately
            best = item.best_stream(q)
            stub = await self._create_one(item, q, best)
            created.append(stub)
        return created

    async def create_stub_for_quality(self, item: MediaItem, quality: Quality, stream) -> Stub:
        """Create just ONE quality's stub, given an already-resolved stream —
        used by the manual "Scan HD" / "Scan 4K" actions, which target a
        single quality tier deliberately rather than create_stubs()'s
        always-HD-plus-4K-if-available behaviour. Idempotent like
        _create_one — a no-op if this exact stub already exists. This is
        a deliberate manual action, so it intentionally does NOT apply
        the min_4k_candidates threshold create_stubs() does — if you
        clicked "Scan 4K" you already know there's only whatever's
        available and want it anyway."""
        return await self._create_one(item, quality, stream)

    async def create_stub_from_candidate(
        self, item: MediaItem, quality: Quality, url: str, headers: dict, size: Optional[int] = None
    ) -> Stub:
        """Create (or reuse) a stub for this item/quality and immediately
        point it at a specific, person-chosen stream — the "manual search"
        counterpart to create_stub_for_quality: instead of resolving via
        best_working_for_quality, this is used when an automatic scan
        found nothing (or the person just wants to hand-pick a source) and
        a candidate was chosen from the raw AIOStreams list themselves.
        Like select-stream on an existing stub, this does NOT probe the
        URL first — it's a deliberate manual choice, applied as given.
        """
        stub = await self._create_one(item, quality)
        await self.set_active(stub.stub_id, url, headers, size=size)
        return self._stubs[stub.stub_id]

    async def _create_one(self, item: MediaItem, quality: Quality, best_stream=None) -> Stub:
        sid = _stub_id(item.id, quality)
        if sid in self._stubs:
            return self._stubs[sid]

        path = self._build_path(item, quality)
        await asyncio.to_thread(path.parent.mkdir, parents=True, exist_ok=True)
        await asyncio.to_thread(path.write_bytes, _get_stub_bytes(quality))

        stub = Stub(
            stub_id         = sid,
            media_id        = item.id,
            title           = item.title,
            quality         = quality,
            abs_path        = str(path),
            imdb_id         = item.imdb_id,
            aiostreams_type = item.aiostreams_type,
            aiostreams_id   = item.aiostreams_id,
            # Path-derivation fields
            media_type      = item.media_type,
            show_title      = item.show_title,
            year            = item.year,
            season          = item.season,
            episode         = item.episode,
            # Store real file size immediately so getattr() never reports stub size
            stream_size     = best_stream.size if best_stream and best_stream.size else None,
        )
        self._stubs[sid] = stub
        self._path_index[str(path)] = sid

        # Sidecar for restart persistence
        poster = getattr(item, "_poster", "")
        stub._poster = poster

        # Record this title as "in the library" independent of stubs —
        # see gateway/library_items.py. Every stub-creation path (normal
        # adds, manual Scan HD/4K, background scan, auto-episode
        # discovery, migration) funnels through here, so this is the one
        # place that needs to know about it. Best-effort: a failure here
        # shouldn't stop the stub itself from being created.
        try:
            from . import library_items as _lib_items
            _lib_items.touch(
                item.imdb_id,
                item.show_title or item.title,
                item.media_type.value,
                item.year,
                poster,
            )
        except Exception as exc:
            logger.warning("Could not record library item for %s: %s", item.imdb_id, exc)
        sidecar = path.with_suffix(".aiogateway.json")
        await asyncio.to_thread(sidecar.write_text, json.dumps({
            "stub_id":        sid,
            "media_id":       item.id,
            "title":          item.title,
            "imdb_id":        item.imdb_id,
            "quality":        quality.value,
            "media_type":     item.media_type.value,
            "aiostreams_type": item.aiostreams_type,
            "aiostreams_id":  item.aiostreams_id,
            "poster":         poster,
            "created_at":     stub.created_at,
            # Path-derivation fields
            "show_title":     item.show_title,
            "year":           item.year,
            "season":         item.season,
            "episode":        item.episode,
            # Real file size — avoids stub-size getattr() on restart
            "stream_size":    stub.stream_size,
        }, indent=2))

        logger.info("Created stub: %s → %s", sid, path)
        return stub

    # -- Lookups --------------------------------------------------------------

    def get(self, stub_id: str) -> Optional[Stub]:
        return self._stubs.get(stub_id)

    def by_path(self, path: str) -> Optional[Stub]:
        sid = self._path_index.get(path)
        return self._stubs.get(sid) if sid else None

    def all(self) -> list[Stub]:
        return list(self._stubs.values())

    def _build_sidecar_payload(self, stub: Stub) -> dict:
        return {
            "stub_id":         stub.stub_id,
            "media_id":        stub.media_id,
            "title":           stub.title,
            "imdb_id":         stub.imdb_id,
            "quality":         stub.quality.value,
            "media_type":      stub.media_type.value,
            "aiostreams_type": stub.aiostreams_type,
            "aiostreams_id":   stub.aiostreams_id,
            "poster":          getattr(stub, "_poster", ""),
            "created_at":      stub.created_at,
            "show_title":      stub.show_title,
            "year":            stub.year,
            "season":          stub.season,
            "episode":         stub.episode,
            "stream_size":     stub.stream_size,
            # Resolve state — the actual fix: these were never persisted
            # before, so every restart reverted every ACTIVE stub back to
            # PLACEHOLDER regardless of reality.
            "state":           stub.state.value,
            "stream_url":      stub.stream_url,
            "stream_headers":  stub.stream_headers,
            "resolved_at":     stub.resolved_at,
            "error_count":     stub.error_count,
            "last_error_at":   stub.last_error_at,
        }

    def persist_sidecar_sync(self, stub: Stub) -> None:
        """
        Synchronous, blocking version of sidecar persistence — for callers
        already running in a plain (non-event-loop) worker thread, such as
        FUSE's _fetch_block retry loop, which detects expired CDN links
        (403/410) or bad responses and reverts the stub's state directly.
        That code can't safely bridge back into asyncio from inside its own
        worker thread, so it calls this instead of the async version. The
        write itself is a tiny JSON file — sub-millisecond, safe to block
        briefly on the calling thread.
        """
        try:
            path = Path(stub.abs_path)
            sidecar = path.with_suffix(".aiogateway.json")
            sidecar.write_text(json.dumps(self._build_sidecar_payload(stub), indent=2))
        except Exception as exc:
            logger.warning("[%s] Could not persist sidecar state: %s", stub.stub_id, exc)

    async def _persist_sidecar(self, stub: Stub) -> None:
        """
        Rewrite this stub's sidecar JSON with its FULL current state,
        including resolve state (state/stream_url/stream_headers/
        resolved_at) — not just the creation-time metadata the sidecar
        originally held.

        Without this, the sidecar was only ever written once at creation
        time (always PLACEHOLDER), so restore() on every container restart
        reconstructed every stub as freshly-unresolved regardless of
        whether it had actually been ACTIVE for weeks. Called from every
        state-changing method (set_active, set_error, set_resolving,
        revert_to_placeholder) so the on-disk record always reflects
        reality at the moment of any restart.
        """
        try:
            path = Path(stub.abs_path)
            sidecar = path.with_suffix(".aiogateway.json")
            await asyncio.to_thread(
                sidecar.write_text, json.dumps(self._build_sidecar_payload(stub), indent=2)
            )
        except Exception as exc:
            logger.warning("[%s] Could not persist sidecar state: %s", stub.stub_id, exc)

    # -- TTL expiry -------------------------------------------------------------

    async def revert_to_placeholder(self, sid: str) -> None:
        """
        Revert a resolved stub back to PLACEHOLDER, dropping its stream URL,
        headers, and real file size so it goes back to being a virtual stub
        until next played. Used by the active-TTL sweep, and safe to call
        manually (e.g. a future "force re-resolve" UI action).
        """
        if s := self._stubs.get(sid):
            if s.state != StubState.ACTIVE:
                return
            old_url = s.stream_url
            s.state          = StubState.PLACEHOLDER
            s.stream_url     = None
            s.stream_headers = {}
            s.stream_size    = None
            s.resolved_at    = None
            if old_url:
                try:
                    from .fuse_fs import _block_cache
                    _block_cache.invalidate(old_url)
                except Exception:
                    pass
            # The virtual filename drops its "- Ready" suffix the moment
            # state != ACTIVE (see fuse_fs._stub_path), so Plex's existing
            # library entry now points at a path readdir() no longer lists.
            # Trigger a scoped rescan so Plex notices and cleans it up,
            # rather than leaving a stale/broken entry until its next
            # periodic full scan.
            try:
                from .fuse_fs import _fs_instance
                from .plex_scan import scan_folder_async
                if _fs_instance is not None:
                    folder = _fs_instance._resolved_folder(s)
                    scan_folder_async(folder)
            except Exception as exc:
                logger.warning("Could not trigger Plex rescan after revert for %s: %s", sid, exc)
            await self._persist_sidecar(s)
            logger.info("[%s] reverted to stub (active TTL expired)", sid)

    async def sweep_expired(self, ttl_days: float) -> int:
        """
        Revert any ACTIVE stub whose resolved_at is older than ttl_days
        back to PLACEHOLDER. Returns the number reverted. ttl_days <= 0
        disables the sweep entirely (nothing is ever reverted).
        """
        if ttl_days <= 0:
            return 0
        cutoff = time.time() - (ttl_days * 86400)
        count = 0
        for s in list(self._stubs.values()):
            if s.state == StubState.ACTIVE and s.resolved_at and s.resolved_at < cutoff:
                await self.revert_to_placeholder(s.stub_id)
                count += 1
        return count

    # -- State ----------------------------------------------------------------

    async def set_resolving(self, sid: str) -> None:
        if s := self._stubs.get(sid):
            s.state = StubState.RESOLVING
            # Reset the event so the next read() waits fresh
            try:
                from .fuse_fs import _get_resolve_event
                _get_resolve_event(sid).clear()
            except Exception:
                pass
            await self._persist_sidecar(s)

    # Minimum plausible size for real movie/episode media — mirrors the
    # same guard in aiostreams_client._probe_stream(). Applied here too as
    # defense in depth: if a candidate somehow reached set_active() with an
    # implausibly small size, reject the resolution rather than activating
    # a stub that will only ever serve a near-empty file.
    _MIN_PLAUSIBLE_MEDIA_BYTES = 50 * 1024 * 1024   # 50MB

    async def set_active(self, sid: str, url: str, headers: dict, size: Optional[int] = None) -> None:
        if s := self._stubs.get(sid):
            resolved_size = size

            if not resolved_size:
                # AIOStreams didn't return a size — try a HEAD request to get
                # Content-Length from the CDN so getattr() can report the
                # real size. Run via to_thread — this is a blocking
                # requests.head() call and set_active is now a coroutine
                # awaited from async call sites, so running it inline would
                # block the event loop for the duration of the HEAD request.
                resolved_size = await asyncio.to_thread(self._head_for_size, url, headers)

            if resolved_size and resolved_size < self._MIN_PLAUSIBLE_MEDIA_BYTES:
                logger.warning(
                    "[%s] rejecting resolution: reported size %d bytes (%.1f MB) "
                    "is implausibly small for real media — treating as a bad link",
                    sid, resolved_size, resolved_size / 1024 / 1024
                )
                await self.set_error(sid)
                return

            s.state, s.stream_url, s.stream_headers = StubState.ACTIVE, url, headers
            s.error_count   = 0   # successful resolution clears any prior failure streak
            s.last_error_at = None
            if resolved_size:
                s.stream_size = resolved_size
            s.resolved_at = time.time()
            # Wake any FUSE read() that's waiting for this stub to resolve
            try:
                from .fuse_fs import signal_resolved
                signal_resolved(sid)
            except Exception:
                pass
            # Trigger a scoped Plex partial scan of just this stub's folder
            # so Plex picks up the renamed " - Ready" file quickly, instead
            # of waiting for the next periodic/full library scan.
            try:
                from .fuse_fs import _fs_instance
                from .plex_scan import scan_folder_async
                if _fs_instance is not None:
                    folder = _fs_instance._resolved_folder(s)
                    scan_folder_async(folder)
            except Exception as exc:
                logger.warning("Could not trigger Plex partial scan for %s: %s", sid, exc)
            await self._persist_sidecar(s)

    @staticmethod
    def _head_for_size(url: str, headers: dict) -> Optional[int]:
        """Blocking HEAD request to recover Content-Length. Run via to_thread."""
        r = None
        try:
            import requests as _req
            r = _req.head(url, headers=headers, timeout=5, allow_redirects=True)
            cl = r.headers.get("Content-Length") or r.headers.get("content-length")
            return int(cl) if cl else None
        except Exception:
            return None
        finally:
            if r is not None:
                r.close()

    async def set_error(self, sid: str) -> None:
        if s := self._stubs.get(sid):
            s.state         = StubState.ERROR
            s.error_count  += 1
            s.last_error_at = time.time()
            # Wake any waiting read() so it falls back to stub bytes immediately
            try:
                from .fuse_fs import signal_resolved
                signal_resolved(sid)
            except Exception:
                pass

            # A stub that's failed resolution this many times in a row is
            # treated as permanently dead rather than just temporarily
            # unavailable — leaving it in place would keep showing Plex a
            # "this exists in 4K" entry that can never actually play, which
            # is a worse false positive than just not having stubbed it.
            max_errors = _settings.get("dead_stub_max_errors", 0)
            if max_errors and s.error_count >= max_errors:
                logger.warning(
                    "[%s] %s failed resolution %d time(s) in a row — "
                    "removing as a dead stub",
                    sid, s.title, s.error_count
                )
                await self.remove_stub(sid)
                return

            await self._persist_sidecar(s)

    async def remove_stub(self, sid: str) -> bool:
        """
        Permanently remove a stub: deletes its placeholder .mkv and sidecar
        .json from disk, drops it from the in-memory index, and triggers a
        scoped Plex rescan so the now-vanished file is cleaned out of Plex's
        library too (rather than lingering as a broken/missing item until
        the next periodic full scan).

        Safe to call directly (e.g. a future "remove dead stub" UI action),
        not just from the auto-cleanup path in set_error.
        """
        s = self._stubs.pop(sid, None)
        if not s:
            return False
        self._path_index.pop(s.abs_path, None)

        path = Path(s.abs_path)
        sidecar = path.with_suffix(".aiogateway.json")
        for f in (path, sidecar):
            try:
                await asyncio.to_thread(f.unlink, missing_ok=True)
            except Exception as exc:
                logger.warning("[%s] Could not delete %s: %s", sid, f, exc)

        # Same scoped-rescan pattern used by set_active/revert_to_placeholder —
        # readdir() no longer lists this stub at all now that it's gone from
        # _stubs, so Plex's existing library entry needs a nudge to notice.
        try:
            from .fuse_fs import _fs_instance
            from .plex_scan import scan_folder_async
            if _fs_instance is not None:
                folder = _fs_instance._resolved_folder(s)
                scan_folder_async(folder)
        except Exception as exc:
            logger.warning("[%s] Could not trigger Plex rescan after removal: %s", sid, exc)

        logger.info("[%s] Removed dead stub: %s", sid, s.title)
        return True

    # Backoff schedule (seconds) by error_count, capped at the last value.
    _ERROR_COOLDOWNS = [30, 60, 300, 900, 3600]   # 30s, 1m, 5m, 15m, 1h

    def in_error_cooldown(self, sid: str) -> bool:
        """
        True if this stub recently failed resolution and is still within its
        backoff window — callers should skip re-probing AIOStreams/CDN links
        and just serve stub bytes instead. Prevents hammering a permanently
        dead title's sources on every single play attempt.
        """
        s = self._stubs.get(sid)
        if not s or s.state != StubState.ERROR or not s.last_error_at:
            return False
        idx = min(s.error_count - 1, len(self._ERROR_COOLDOWNS) - 1)
        cooldown = self._ERROR_COOLDOWNS[max(idx, 0)]
        return (time.time() - s.last_error_at) < cooldown

    # -- Backup / restore -------------------------------------------------------

    def export_all(self) -> list[dict]:
        """
        Serialize every known stub's metadata for backup. Deliberately does
        NOT include resolve state (stream_url/headers/stream_size) — a
        restored backup should come back as fresh stubs that re-resolve on
        next play, not with old (likely expired) CDN URLs baked in.
        """
        out = []
        for s in self._stubs.values():
            out.append({
                "stub_id":         s.stub_id,
                "media_id":        s.media_id,
                "title":           s.title,
                "quality":         s.quality.value,
                "imdb_id":         s.imdb_id,
                "aiostreams_type": s.aiostreams_type,
                "aiostreams_id":   s.aiostreams_id,
                "media_type":      s.media_type.value,
                "show_title":      s.show_title,
                "year":            s.year,
                "season":          s.season,
                "episode":         s.episode,
                "poster":          getattr(s, "_poster", ""),
                "created_at":      s.created_at,
            })
        return out

    async def import_all(self, items: list[dict], replace: bool = False) -> dict:
        """
        Restore stubs from a backup export. Each item becomes a fresh
        PLACEHOLDER stub (re-resolves on next play — no stale CDN URLs are
        imported). Also (re)writes the sidecar files to disk so they
        persist the same way newly-created stubs do.

        replace=True clears all current stubs first (full restore).
        replace=False merges, skipping any stub_id that already exists
        (safe "add missing" import).

        Returns {"imported": N, "skipped": N, "errors": [...]}.
        """
        if replace:
            self._stubs.clear()
            self._path_index.clear()

        imported, skipped, errors = 0, 0, []

        for data in items:
            try:
                sid = data["stub_id"]
                if not replace and sid in self._stubs:
                    skipped += 1
                    continue

                quality    = Quality(data["quality"])
                media_type = MediaType(data.get("media_type", "movie"))
                title = data.get("title", "")
                show_title = data.get("show_title", "")
                year = data.get("year")
                season = data.get("season")
                episode = data.get("episode")

                from .models import MediaItem
                item = MediaItem(
                    id=data["media_id"], imdb_id=data["imdb_id"], title=title,
                    year=year, media_type=media_type,
                    season=season, episode=episode,
                )
                if media_type == MediaType.SERIES:
                    item.show_title = show_title or title
                path = self._build_path(item, quality)

                await asyncio.to_thread(path.parent.mkdir, parents=True, exist_ok=True)
                if not path.exists():
                    await asyncio.to_thread(path.write_bytes, _get_stub_bytes(quality))

                stub = Stub(
                    stub_id         = sid,
                    media_id        = data["media_id"],
                    title           = title,
                    quality         = quality,
                    abs_path        = str(path),
                    imdb_id         = data["imdb_id"],
                    aiostreams_type = data["aiostreams_type"],
                    aiostreams_id   = data["aiostreams_id"],
                    created_at      = data.get("created_at", time.time()),
                    media_type      = media_type,
                    show_title      = show_title,
                    year            = year,
                    season          = season,
                    episode         = episode,
                )
                poster = data.get("poster", "")
                stub._poster = poster
                self._stubs[sid] = stub
                self._path_index[str(path)] = sid

                sidecar = path.with_suffix(".aiogateway.json")
                await asyncio.to_thread(sidecar.write_text, json.dumps({
                    "stub_id": sid, "media_id": data["media_id"], "title": title,
                    "imdb_id": data["imdb_id"], "quality": quality.value,
                    "media_type": media_type.value,
                    "aiostreams_type": data["aiostreams_type"],
                    "aiostreams_id": data["aiostreams_id"],
                    "poster": poster, "created_at": stub.created_at,
                    "show_title": show_title, "year": year,
                    "season": season, "episode": episode,
                    "stream_size": None,
                }, indent=2))

                imported += 1
            except Exception as exc:
                errors.append(f"{data.get('stub_id', '?')}: {exc}")
                logger.warning("Import failed for stub %s: %s", data.get("stub_id"), exc)

        return {"imported": imported, "skipped": skipped, "errors": errors}

    # -- Restore from disk on restart -----------------------------------------

    async def restore(self) -> int:
        count = 0
        root = _library_root()
        if not root.exists():
            return 0
        for sidecar in root.rglob("*.aiogateway.json"):
            try:
                data = json.loads(sidecar.read_text())
                mkv = sidecar.with_suffix("").with_suffix(".mkv")
                if not mkv.exists():
                    continue
                quality = Quality(data["quality"])

                # Resolve state — these fields are only present in sidecars
                # written after the persistence fix (see _persist_sidecar).
                # Older sidecars from before that fix simply won't have
                # them, and fall back to PLACEHOLDER (the original
                # behaviour) via StubState's own default.
                saved_state = data.get("state")
                state = StubState(saved_state) if saved_state else StubState.PLACEHOLDER
                # A stub saved mid-RESOLVING (e.g. container killed during
                # an in-flight resolution) can never actually still be
                # resolving after a restart — nothing is running anymore.
                # Restart it as PLACEHOLDER so the next play attempt
                # re-triggers resolution cleanly, rather than getting stuck
                # waiting on a resolve event that will never fire.
                if state == StubState.RESOLVING:
                    state = StubState.PLACEHOLDER

                stub = Stub(
                    stub_id         = data["stub_id"],
                    media_id        = data["media_id"],
                    title           = data.get("title", ""),
                    quality         = quality,
                    abs_path        = str(mkv),
                    imdb_id         = data["imdb_id"],
                    aiostreams_type = data["aiostreams_type"],
                    aiostreams_id   = data["aiostreams_id"],
                    created_at      = data.get("created_at", time.time()),
                    # Path-derivation fields (may be absent in old sidecars)
                    media_type      = MediaType(data.get("media_type", "movie")),
                    show_title      = data.get("show_title", ""),
                    year            = data.get("year"),
                    season          = data.get("season"),
                    episode         = data.get("episode"),
                    stream_size     = data.get("stream_size"),
                    # Resolve state restored from the sidecar instead of
                    # always defaulting to PLACEHOLDER — this is the actual
                    # fix for "active stubs turn into placeholders on
                    # restart". If the CDN URL has since expired, the
                    # existing 403/410/416 handling in fuse_fs.py will
                    # detect that on next read and revert it cleanly, the
                    # same as it would for any other expired link.
                    state           = state,
                    stream_url      = data.get("stream_url") if state == StubState.ACTIVE else None,
                    stream_headers  = data.get("stream_headers") or {},
                    resolved_at     = data.get("resolved_at") if state == StubState.ACTIVE else None,
                    error_count     = data.get("error_count", 0),
                    last_error_at   = data.get("last_error_at"),
                )
                stub._poster = data.get("poster", "")
                self._stubs[stub.stub_id] = stub
                self._path_index[stub.abs_path] = stub.stub_id
                count += 1

                # Backfill gateway/library_items for titles that already
                # existed before that module did — _create_one() only ever
                # touches it for genuinely new stubs, so anything restored
                # here from a pre-existing sidecar would otherwise have no
                # library_items record at all, making it vanish from the
                # Library page entirely the moment its last stub is deleted
                # instead of staying as a rescannable shell. Best-effort,
                # same as the _create_one call.
                try:
                    from . import library_items as _lib_items
                    _lib_items.touch(
                        stub.imdb_id,
                        stub.show_title or stub.title,
                        stub.media_type.value,
                        stub.year,
                        stub._poster,
                    )
                except Exception as exc:
                    logger.warning("Could not backfill library item for %s: %s", stub.imdb_id, exc)

            except Exception as exc:
                logger.warning("Could not restore sidecar %s: %s", sidecar, exc)
        return count
