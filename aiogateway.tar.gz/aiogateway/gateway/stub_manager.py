"""
gateway/stub_manager.py
~~~~~~~~~~~~~~~~~~~~~~~
Creates and manages placeholder .mkv files that Plex indexes.

Folder structure:
  LIBRARY_ROOT/
    Movies/    {Title (Year)}/{Title (Year)}.mkv
    Movies4K/  {Title (Year)}/{Title (Year)}.mkv   ← if 4K stream exists
    Series/    {Show Title}/Season {N}/{Show Title} - S01E01 - {Episode Title}.mkv
    Series4K/  ...                                  ← if 4K stream exists

The .mkv files are tiny but valid — just enough for Plex to detect them
as video files and add them to the library. The proxy server handles
actual playback by intercepting the file path in the Plex webhook.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import struct
import time
from pathlib import Path
from typing import Optional

from .models import MediaItem, MediaType, Quality, Stub, StubState

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
LIBRARY_ROOT = Path(os.getenv("LIBRARY_ROOT", "/library"))

FOLDER_MAP = {
    (MediaType.MOVIE,  Quality.HD):  LIBRARY_ROOT / "Movies",
    (MediaType.MOVIE,  Quality.UHD): LIBRARY_ROOT / "Movies4K",
    (MediaType.SERIES, Quality.HD):  LIBRARY_ROOT / "Series",
    (MediaType.SERIES, Quality.UHD): LIBRARY_ROOT / "Series4K",
}


# ---------------------------------------------------------------------------
# Minimal valid MKV header
# Creates a file Plex will recognise as a video container.
# This is a valid EBML/Matroska header with no actual media data.
# ---------------------------------------------------------------------------

def _make_minimal_mkv() -> bytes:
    """
    Return a minimal but valid MKV file (EBML header + Segment element).
    Plex will open it, read no tracks, and mark it as 'unknown duration' —
    but it WILL add it to the library and show the title.
    """
    # EBML header
    ebml_header = bytes([
        0x1A, 0x45, 0xDF, 0xA3,   # EBML element ID
        0x9F,                      # size = 31
        0x42, 0x86, 0x81, 0x01,   # EBMLVersion = 1
        0x42, 0xF7, 0x81, 0x01,   # EBMLReadVersion = 1
        0x42, 0xF2, 0x81, 0x04,   # EBMLMaxIDLength = 4
        0x42, 0xF3, 0x81, 0x08,   # EBMLMaxSizeLength = 8
        0x42, 0x82, 0x88,         # DocType element (size=8)
        0x6D, 0x61, 0x74, 0x72, 0x6F, 0x73, 0x6B, 0x61,  # "matroska"
        0x42, 0x87, 0x81, 0x04,   # DocTypeVersion = 4
        0x42, 0x85, 0x81, 0x02,   # DocTypeReadVersion = 2
    ])
    # Segment element (unknown size — valid in MKV)
    segment = bytes([0x18, 0x53, 0x80, 0x67, 0x01, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF])
    return ebml_header + segment


# ---------------------------------------------------------------------------
# StubManager
# ---------------------------------------------------------------------------

class StubManager:
    """
    Creates placeholder .mkv files in the Plex library folders.
    Maintains an in-memory registry of stubs keyed by stub_id.
    """

    def __init__(self) -> None:
        self._stubs: dict[str, Stub] = {}   # stub_id → Stub
        self._path_index: dict[str, str] = {}  # abs_path → stub_id

    # -- Creation ----------------------------------------------------------

    def _stub_id(self, media_id: str, quality: Quality) -> str:
        key = f"{media_id}:{quality.value}"
        return hashlib.sha256(key.encode()).hexdigest()[:16]

    def _build_path(self, item: MediaItem, quality: Quality) -> Path:
        base = FOLDER_MAP[(item.media_type, quality)]

        if item.media_type == MediaType.MOVIE:
            folder = base / item.folder_name
            filename = f"{item.folder_name}.mkv"
        else:
            season_str = f"Season {item.season:02d}" if item.season else "Season 01"
            folder = base / item.folder_name / season_str
            filename = f"{item.file_stem}.mkv"

        return folder / filename

    async def create_stubs(self, item: MediaItem) -> list[Stub]:
        """
        Create placeholder .mkv files for the item.
        Always creates an HD stub. Creates a 4K stub if item.has_4k is True.
        Returns list of Stub objects that were created.
        """
        created: list[Stub] = []
        qualities = [Quality.HD]
        if item.has_4k:
            qualities.append(Quality.UHD)

        for quality in qualities:
            stub = await self._create_stub(item, quality)
            created.append(stub)

        return created

    async def _create_stub(self, item: MediaItem, quality: Quality) -> Stub:
        stub_id = self._stub_id(item.id, quality)

        # Return existing stub if already created
        if stub_id in self._stubs:
            return self._stubs[stub_id]

        path = self._build_path(item, quality)
        path.parent.mkdir(parents=True, exist_ok=True)

        # Write the minimal MKV file
        await asyncio.to_thread(path.write_bytes, _make_minimal_mkv())

        stub = Stub(
            stub_id=stub_id,
            media_id=item.id,
            quality=quality,
            abs_path=str(path),
            imdb_id=item.imdb_id,
            aiostreams_type=item.aiostreams_type,
            aiostreams_id=item.aiostreams_id,
        )

        self._stubs[stub_id] = stub
        self._path_index[str(path)] = stub_id

        # Write a sidecar JSON so the gateway can reconstruct state on restart
        await asyncio.to_thread(
            (path.parent / f"{path.stem}.aiogateway.json").write_text,
            json.dumps({
                "stub_id": stub_id,
                "media_id": item.id,
                "imdb_id": item.imdb_id,
                "title": item.title,
                "year": item.year,
                "media_type": item.media_type.value,
                "quality": quality.value,
                "aiostreams_type": item.aiostreams_type,
                "aiostreams_id": item.aiostreams_id,
                "created_at": stub.created_at,
            }, indent=2)
        )

        return stub

    # -- Lookup ------------------------------------------------------------

    def get_by_id(self, stub_id: str) -> Optional[Stub]:
        return self._stubs.get(stub_id)

    def get_by_path(self, path: str) -> Optional[Stub]:
        sid = self._path_index.get(path)
        return self._stubs.get(sid) if sid else None

    def get_by_media(self, media_id: str, quality: Quality) -> Optional[Stub]:
        sid = self._stub_id(media_id, quality)
        return self._stubs.get(sid)

    def all_stubs(self) -> list[Stub]:
        return list(self._stubs.values())

    # -- State updates -----------------------------------------------------

    def mark_resolving(self, stub_id: str) -> None:
        if stub := self._stubs.get(stub_id):
            stub.state = StubState.RESOLVING

    def mark_active(self, stub_id: str, stream_url: str, headers: dict) -> None:
        if stub := self._stubs.get(stub_id):
            stub.state = StubState.ACTIVE
            stub.stream_url = stream_url
            stub.stream_headers = headers
            stub.resolved_at = time.time()

    def mark_error(self, stub_id: str) -> None:
        if stub := self._stubs.get(stub_id):
            stub.state = StubState.ERROR

    # -- Restore from disk -------------------------------------------------

    async def restore_from_disk(self) -> int:
        """
        On startup, scan library folders for .aiogateway.json sidecars
        and restore stub registry without recreating files.
        """
        count = 0
        for root, dirs, files in os.walk(LIBRARY_ROOT):
            for fname in files:
                if not fname.endswith(".aiogateway.json"):
                    continue
                sidecar = Path(root) / fname
                try:
                    data = json.loads(sidecar.read_text())
                    mkv_path = sidecar.with_suffix("").with_suffix(".mkv")
                    if not mkv_path.exists():
                        continue
                    quality = Quality(data["quality"])
                    stub = Stub(
                        stub_id=data["stub_id"],
                        media_id=data["media_id"],
                        quality=quality,
                        abs_path=str(mkv_path),
                        imdb_id=data["imdb_id"],
                        aiostreams_type=data["aiostreams_type"],
                        aiostreams_id=data["aiostreams_id"],
                        created_at=data.get("created_at", time.time()),
                    )
                    self._stubs[stub.stub_id] = stub
                    self._path_index[stub.abs_path] = stub.stub_id
                    count += 1
                except Exception:
                    pass
        return count
