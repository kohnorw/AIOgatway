"""gateway/stub_manager.py — Creates and tracks placeholder .mkv files."""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

from .models import MediaItem, MediaType, Quality, Stub, StubState
from . import settings as _settings

logger = logging.getLogger("aiogateway.stubs")


def _library_root() -> Path:
    """
    Where stub sidecar files (.json metadata + tiny placeholder .mkv bytes)
    are physically written for persistence across restarts.

    This is independent of FUSE_MOUNTPOINT (the virtual filesystem Plex
    actually browses) — it's purely an on-disk metadata store, a sibling
    directory next to the mountpoint, e.g. /docker/aiogateway/mnt_data.

    LIBRARY_DATA_ROOT can override this explicitly. (Older LIBRARY_ROOT /
    LIBRARY_REAL_ROOT env vars were used by a previous passthrough-FUSE
    architecture and are no longer read — this app is now fully virtual.)
    """
    override = os.environ.get("LIBRARY_DATA_ROOT")
    if override:
        return Path(override)
    mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    return Path(mountpoint.rstrip("/") + "_data")


FOLDER_MAP = {
    (MediaType.MOVIE,  Quality.HD):  "Movies",
    (MediaType.MOVIE,  Quality.UHD): "Movies4K",
    (MediaType.SERIES, Quality.HD):  "Series",
    (MediaType.SERIES, Quality.UHD): "Series4K",
}


# Real stub MKV files — valid Matroska files with proper duration/tracks
# so Plex accepts them without immediately stopping playback.
# Located in stubs/ directory next to this package.
_STUBS_DIR = Path(__file__).parent.parent / "stubs"
_STUB_HD   = _STUBS_DIR / "hd.mkv"
_STUB_4K   = _STUBS_DIR / "4k.mkv"


# The stub payloads never change at runtime, but _get_stub_bytes() used to
# re-read them from disk on every single call — i.e. once per quality per
# episode. Adding an ended 8-season show meant re-reading the same 133KB
# (HD) / 352KB (4K) files a few hundred times, synchronously, on the event
# loop. Read once, keep in memory.
_STUB_BYTES_CACHE: dict[Quality, bytes] = {}


def _get_stub_bytes(quality: Quality) -> bytes:
    """Return the real stub MKV bytes for the given quality tier."""
    cached = _STUB_BYTES_CACHE.get(quality)
    if cached is not None:
        return cached
    data = _read_stub_bytes(quality)
    _STUB_BYTES_CACHE[quality] = data
    return data


def _read_stub_bytes(quality: Quality) -> bytes:
    stub_path = _STUB_4K if quality == Quality.UHD else _STUB_HD
    if stub_path.exists():
        return stub_path.read_bytes()
    # Fallback: try the other stub
    fallback = _STUB_HD if quality == Quality.UHD else _STUB_4K
    if fallback.exists():
        return fallback.read_bytes()
    # Last resort: minimal EBML header (original approach)
    logger.warning("Real stub files not found in %s — using minimal EBML header", _STUBS_DIR)
    ebml = bytes([
        0x1A,0x45,0xDF,0xA3, 0x9F,
        0x42,0x86,0x81,0x01, 0x42,0xF7,0x81,0x01,
        0x42,0xF2,0x81,0x04, 0x42,0xF3,0x81,0x08,
        0x42,0x82,0x88,
        0x6D,0x61,0x74,0x72,0x6F,0x73,0x6B,0x61,
        0x42,0x87,0x81,0x04, 0x42,0x85,0x81,0x02,
    ])
    segment = bytes([0x18,0x53,0x80,0x67,0x01,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF])
    return ebml + segment


def _stub_id(media_id: str, quality: Quality) -> str:
    return hashlib.sha256(f"{media_id}:{quality.value}".encode()).hexdigest()[:16]


class StubManager:
    def __init__(self) -> None:
        self._stubs: dict[str, Stub] = {}
        self._path_index: dict[str, str] = {}
        # Directories already mkdir'd this process. Every stub in a season
        # lands in the same folder, so without this a 200-episode add issues
        # 200 identical mkdir(parents=True) syscall chains.
        self._known_dirs: set[str] = set()
        # Callbacks fired once per genuinely-new stub — see
        # on_stub_created(). Used by prewarming so newly-added content is
        # resolved as it appears rather than only when a timer happens to
        # fire or someone has the web UI open.
        self._created_callbacks: list = []

    def on_stub_created(self, callback) -> None:
        """
        Register a callback invoked with the new Stub every time one is
        actually created. Not called when _create_one() returns an
        existing stub, so re-adding something already in the library
        doesn't re-fire it.

        Callbacks must be cheap and non-blocking: they run inline with
        stub creation, which happens in the middle of adds and library
        scans. Anything slow should queue work and return. Exceptions are
        caught and logged — a misbehaving listener must never stop a stub
        from being created.
        """
        self._created_callbacks.append(callback)

    def _fire_created(self, stub: Stub) -> None:
        for cb in self._created_callbacks:
            try:
                cb(stub)
            except Exception as exc:
                logger.warning("Stub-created callback failed for %s: %s", stub.stub_id, exc)

    def _build_path(self, item: MediaItem, quality: Quality) -> Path:
        folder_name = FOLDER_MAP[(item.media_type, quality)]
        base = _library_root() / folder_name

        if item.media_type == MediaType.MOVIE:
            return base / item.folder_name / f"{item.file_stem}.mkv"
        else:
            # Series: /library/Series/Show Title (Year)/Season 01/S01E01 - Episode Title.mkv
            return base / item.folder_name / item.season_folder / f"{item.file_stem}.mkv"

    async def create_stubs(self, item: MediaItem) -> list[Stub]:
        """
        Create HD stub always; 4K stub only if there are enough
        independent 4K candidates to be reasonably confident one will
        actually work. A single 4K source — as opposed to HD, which
        usually has many — tends to be a rare/uncached torrent that's
        more likely to be dead, slow, or unstable than a title with
        several 4K sources to fall back on. min_4k_candidates (default 2)
        governs the threshold; set to 1 to restore the old "any 4K source
        at all" behaviour.

        Also skips 4K entirely if 4K has already been confirmed
        unavailable for this exact item (see gateway/quality_unavailable)
        — every automatic caller of create_stubs() (normal adds, the
        background scan, auto-episode discovery, the pending-movies
        sweep) goes through this one function, so gating it here covers
        all of them without needing to special-case each one. The manual
        "Scan 4K" action bypasses this entirely by calling
        create_stub_for_quality() directly instead.
        """
        from gateway import settings as _settings
        from gateway import quality_unavailable as _qu

        min_4k = max(1, _settings.get("min_4k_candidates", 2) or 1)
        uhd_count = sum(1 for s in item.streams if s.is_4k)
        already_marked = _qu.is_marked(item.imdb_id, item.season, item.episode)

        qualities = [Quality.HD]
        if already_marked:
            logger.info("%s: 4K previously confirmed unavailable — skipping (manual Scan 4K to re-check)",
                       item.title)
        elif uhd_count >= min_4k:
            qualities.append(Quality.UHD)
        elif uhd_count > 0:
            logger.info(
                "%s: found %d 4K source(s), below the min_4k_candidates "
                "threshold of %d — skipping 4K stub", item.title, uhd_count, min_4k
            )

        created = []
        for q in qualities:
            # Pass the best stream for this quality so size is known immediately
            best = item.best_stream(q)
            stub = await self._create_one(item, q, best)
            created.append(stub)
        return created

    async def create_stubs_bulk(
        self, items: list[MediaItem], concurrency: int = 16
    ) -> list[Stub]:
        """
        create_stubs() for many items at once, with the filesystem work
        overlapped instead of strictly serialised.

        Stub creation is pure local I/O — mkdir, write a small .mkv, write
        a sidecar — with no AIOStreams involvement and therefore nothing
        for the rate gate to protect. Awaiting each episode's writes one
        after another was leaving the thread pool almost entirely idle
        while a big series was being stubbed out. This is only ever used
        by callers that already know availability for every item they
        pass (see main.py's _pack_first_fill); anything that still needs
        to query per episode keeps going through create_stubs() one at a
        time so the rate gate stays in charge.
        """
        if not items:
            return []

        sem = asyncio.Semaphore(max(1, concurrency))

        async def _one(it: MediaItem) -> list[Stub]:
            async with sem:
                try:
                    return await self.create_stubs(it)
                except Exception as exc:
                    logger.warning("Bulk stub creation failed for %s: %s", it.id, exc)
                    return []

        results = await asyncio.gather(*(_one(it) for it in items))
        return [stub for group in results for stub in group]

    async def create_stub_for_quality(self, item: MediaItem, quality: Quality, stream) -> Stub:
        """Create just ONE quality's stub, given an already-resolved stream —
        used by the manual "Scan HD" / "Scan 4K" actions, which target a
        single quality tier deliberately rather than create_stubs()'s
        always-HD-plus-4K-if-available behaviour. Idempotent like
        _create_one — a no-op if this exact stub already exists. This is
        a deliberate manual action, so it intentionally does NOT apply
        the min_4k_candidates threshold create_stubs() does — if you
        clicked "Scan 4K" you already know there's only whatever's
        available and want it anyway. For the same reason it clears any
        dead-stub suppression: this is a person explicitly asking."""
        try:
            from . import stub_history
            stub_history.clear_dead(_stub_id(item.id, quality))
        except Exception:
            pass
        return await self._create_one(item, quality, stream)

    async def create_stub_from_candidate(
        self, item: MediaItem, quality: Quality, url: str, headers: dict, size: Optional[int] = None
    ) -> Stub:
        """Create (or reuse) a stub for this item/quality and immediately
        point it at a specific, person-chosen stream — the "manual search"
        counterpart to create_stub_for_quality: instead of resolving via
        best_working_for_quality, this is used when an automatic scan
        found nothing (or the person just wants to hand-pick a source) and
        a candidate was chosen from the raw AIOStreams list themselves.
        Like select-stream on an existing stub, this does NOT probe the
        URL first — it's a deliberate manual choice, applied as given.
        """
        stub = await self._create_one(item, quality)
        # A deliberate human pick overrides any dead history: they've
        # chosen a specific stream, so drop the suppression entirely
        # rather than let the automatic backoff second-guess it.
        try:
            from . import stub_history
            stub_history.clear_dead(stub.stub_id)
        except Exception:
            pass
        await self.set_active(stub.stub_id, url, headers, size=size)
        return self._stubs[stub.stub_id]

    async def _create_one(self, item: MediaItem, quality: Quality, best_stream=None) -> Stub:
        sid = _stub_id(item.id, quality)
        if sid in self._stubs:
            return self._stubs[sid]

        path = self._build_path(item, quality)

        stub = Stub(
            stub_id         = sid,
            media_id        = item.id,
            title           = item.title,
            quality         = quality,
            abs_path        = str(path),
            imdb_id         = item.imdb_id,
            aiostreams_type = item.aiostreams_type,
            aiostreams_id   = item.aiostreams_id,
            # Path-derivation fields
            media_type      = item.media_type,
            show_title      = item.show_title,
            year            = item.year,
            season          = item.season,
            episode         = item.episode,
            # Store real file size immediately so getattr() never reports stub size
            stream_size     = best_stream.size if best_stream and best_stream.size else None,
        )
        # Sidecar for restart persistence
        poster = getattr(item, "_poster", "")
        stub._poster = poster

        # Inherit the original first-seen time if this media+quality has
        # been stubbed before — i.e. if this is a recreation after a dead
        # removal rather than a genuinely new add. Falls back to
        # created_at the first time, so a real add is unaffected.
        try:
            from . import stub_history
            label = (f"{item.show_title or item.title} "
                     f"S{item.season:02d}E{item.episode:02d}"
                     if item.season is not None and item.episode is not None
                     else item.title)
            stub.first_seen_at = stub_history.note_created(
                sid, stub.created_at, f"{label} ({quality.value})"
            )
            if stub.first_seen_at < stub.created_at - 60:
                logger.info(
                    "[%s] Re-created a previously-removed stub: %s "
                    "(first seen %.1f days ago — not treated as new content)",
                    sid, label, (stub.created_at - stub.first_seen_at) / 86400.0,
                )
        except Exception as exc:
            logger.warning("[%s] Could not read stub history: %s", sid, exc)
            stub.first_seen_at = stub.created_at

        sidecar = path.with_suffix(".aiogateway.json")
        sidecar_json = json.dumps({
            "stub_id":        sid,
            "media_id":       item.id,
            "title":          item.title,
            "imdb_id":        item.imdb_id,
            "quality":        quality.value,
            "media_type":     item.media_type.value,
            "aiostreams_type": item.aiostreams_type,
            "aiostreams_id":  item.aiostreams_id,
            "poster":         poster,
            "created_at":     stub.created_at,
            "first_seen_at":  stub.first_seen_at,
            # Path-derivation fields
            "show_title":     item.show_title,
            "year":           item.year,
            "season":         item.season,
            "episode":        item.episode,
            # Real file size — avoids stub-size getattr() on restart
            "stream_size":    stub.stream_size,
        }, indent=2)

        # One thread hop for all three filesystem operations instead of
        # three. Each await asyncio.to_thread() is a round-trip through the
        # executor and back onto the event loop; at 2 qualities x N episodes
        # that overhead was a real share of the wall-clock time for a large
        # series add, on top of the work itself.
        stub_bytes = _get_stub_bytes(quality)
        known_dirs = self._known_dirs

        def _write_stub_files() -> None:
            parent_key = str(path.parent)
            if parent_key not in known_dirs:
                path.parent.mkdir(parents=True, exist_ok=True)
                known_dirs.add(parent_key)
            path.write_bytes(stub_bytes)
            sidecar.write_text(sidecar_json)

        await asyncio.to_thread(_write_stub_files)

        # Registered only once the files are actually on disk — previously
        # the write happened first for the same reason, and keeping that
        # order means a failed write can never leave a stub in the index
        # with nothing backing it.
        self._stubs[sid] = stub
        self._path_index[str(path)] = sid

        # Record this title as "in the library" independent of stubs —
        # see gateway/library_items.py. Every stub-creation path (normal
        # adds, manual Scan HD/4K, background scan, auto-episode
        # discovery, migration) funnels through here, so this is the one
        # place that needs to know about it. Best-effort: a failure here
        # shouldn't stop the stub itself from being created.
        try:
            from . import library_items as _lib_items
            _lib_items.touch(
                item.imdb_id,
                item.show_title or item.title,
                item.media_type.value,
                item.year,
                poster,
            )
        except Exception as exc:
            logger.warning("Could not record library item for %s: %s", item.imdb_id, exc)

        logger.info("Created stub: %s → %s", sid, path)

        # Fired last, once everything above has succeeded, so listeners
        # only ever see a fully-built, persisted stub. This is the single
        # funnel every creation path goes through (normal adds, manual
        # Scan HD/4K, background scan, auto-episode discovery,
        # pending-movie sweep, migration), so one hook here covers all of
        # them.
        self._fire_created(stub)
        return stub

    # -- Lookups --------------------------------------------------------------

    def get(self, stub_id: str) -> Optional[Stub]:
        return self._stubs.get(stub_id)

    def by_path(self, path: str) -> Optional[Stub]:
        sid = self._path_index.get(path)
        return self._stubs.get(sid) if sid else None

    def all(self) -> list[Stub]:
        return list(self._stubs.values())

    def _build_sidecar_payload(self, stub: Stub) -> dict:
        return {
            "stub_id":         stub.stub_id,
            "media_id":        stub.media_id,
            "title":           stub.title,
            "imdb_id":         stub.imdb_id,
            "quality":         stub.quality.value,
            "media_type":      stub.media_type.value,
            "aiostreams_type": stub.aiostreams_type,
            "aiostreams_id":   stub.aiostreams_id,
            "poster":          getattr(stub, "_poster", ""),
            "created_at":      stub.created_at,
            "first_seen_at":   stub.first_seen_at,
            "show_title":      stub.show_title,
            "year":            stub.year,
            "season":          stub.season,
            "episode":         stub.episode,
            "stream_size":     stub.stream_size,
            # Resolve state — the actual fix: these were never persisted
            # before, so every restart reverted every ACTIVE stub back to
            # PLACEHOLDER regardless of reality.
            "state":           stub.state.value,
            "stream_url":      stub.stream_url,
            "stream_headers":  stub.stream_headers,
            "resolved_at":     stub.resolved_at,
            "ttl_expired_at":  stub.ttl_expired_at,
            "ever_resolved":   stub.ever_resolved,
            "last_resolved_at": stub.last_resolved_at,
            "error_count":     stub.error_count,
            "last_error_at":   stub.last_error_at,
        }

    def persist_sidecar_sync(self, stub: Stub) -> None:
        """
        Synchronous, blocking version of sidecar persistence — for callers
        already running in a plain (non-event-loop) worker thread, such as
        FUSE's _fetch_block retry loop, which detects expired CDN links
        (403/410) or bad responses and reverts the stub's state directly.
        That code can't safely bridge back into asyncio from inside its own
        worker thread, so it calls this instead of the async version. The
        write itself is a tiny JSON file — sub-millisecond, safe to block
        briefly on the calling thread.
        """
        try:
            path = Path(stub.abs_path)
            sidecar = path.with_suffix(".aiogateway.json")
            sidecar.write_text(json.dumps(self._build_sidecar_payload(stub), indent=2))
        except Exception as exc:
            logger.warning("[%s] Could not persist sidecar state: %s", stub.stub_id, exc)

    async def _persist_sidecar(self, stub: Stub) -> None:
        """
        Rewrite this stub's sidecar JSON with its FULL current state,
        including resolve state (state/stream_url/stream_headers/
        resolved_at) — not just the creation-time metadata the sidecar
        originally held.

        Without this, the sidecar was only ever written once at creation
        time (always PLACEHOLDER), so restore() on every container restart
        reconstructed every stub as freshly-unresolved regardless of
        whether it had actually been ACTIVE for weeks. Called from every
        state-changing method (set_active, set_error, set_resolving,
        revert_to_placeholder) so the on-disk record always reflects
        reality at the moment of any restart.
        """
        try:
            path = Path(stub.abs_path)
            sidecar = path.with_suffix(".aiogateway.json")
            await asyncio.to_thread(
                sidecar.write_text, json.dumps(self._build_sidecar_payload(stub), indent=2)
            )
        except Exception as exc:
            logger.warning("[%s] Could not persist sidecar state: %s", stub.stub_id, exc)

    # -- TTL expiry -------------------------------------------------------------

    async def revert_to_placeholder(self, sid: str, mark_expired: bool = False) -> None:
        """
        Revert a resolved stub back to PLACEHOLDER, dropping its stream URL,
        headers, and real file size so it goes back to being a virtual stub
        until next played. Used by the active-TTL sweep, and safe to call
        manually (e.g. a future "force re-resolve" UI action).

        `mark_expired` stamps ttl_expired_at, which tells prewarming to
        leave this stub alone until it's actually played again. The TTL
        sweep and the explicit expire commands set it; the manual
        "clear stream" actions don't, since those mean "get me a fresh
        link", not "stop keeping this warm".
        """
        if s := self._stubs.get(sid):
            if s.state != StubState.ACTIVE:
                return
            old_url = s.stream_url
            s.state          = StubState.PLACEHOLDER
            s.stream_url     = None
            s.stream_headers = {}
            # stream_size is deliberately KEPT. getattr reports it as the
            # file size, so clearing it made the size jump back to the 50GB
            # placeholder on expiry — a size change Plex treats as the file
            # having been modified. The last known real size stays until a
            # new resolve replaces it; it costs nothing to keep and is a
            # better estimate than 50GB regardless.
            if s.resolved_at:
                s.last_resolved_at = s.resolved_at
            s.resolved_at    = None
            if mark_expired:
                s.ttl_expired_at = time.time()
            if old_url:
                try:
                    from .fuse_fs import _block_cache
                    _block_cache.invalidate(old_url)
                except Exception:
                    pass
            # This rescan exists solely because the filename used to drop
            # its "- Ready" suffix on revert, leaving Plex's library entry
            # pointing at a path readdir() no longer listed. With
            # stable_stub_filenames the name doesn't change, and neither
            # does the reported size or mtime — there is nothing for Plex
            # to notice, and scanning anyway is the one remaining way an
            # expiry could nudge the item's state. Skip it.
            renames_on_revert = True
            try:
                from . import settings as _settings
                renames_on_revert = not (
                    _settings.get("stable_stub_filenames", True)
                    and getattr(s, "ever_resolved", False)
                )
            except Exception:
                pass
            if renames_on_revert:
                try:
                    from .fuse_fs import _fs_instance
                    from .plex_scan import scan_folder_async
                    if _fs_instance is not None:
                        folder = _fs_instance._resolved_folder(s)
                        scan_folder_async(folder)
                except Exception as exc:
                    logger.warning("Could not trigger Plex rescan after revert for %s: %s", sid, exc)
            await self._persist_sidecar(s)
            logger.info("[%s] reverted to stub (active TTL expired)", sid)

    async def sweep_expired(self, ttl_days: float) -> int:
        """
        Revert any ACTIVE stub whose resolved_at is older than ttl_days
        back to PLACEHOLDER. Returns the number reverted. ttl_days <= 0
        disables the sweep entirely (nothing is ever reverted).

        Scope is deliberately every stub this manager knows about: the
        only filters are state and age, never quality or media_type, so
        one TTL governs Movies, Movies4K, Series and Series4K alike. See
        sweep_expired_breakdown() for the same pass with a per-library
        tally, which is what the TTL loop actually calls.
        """
        result = await self.sweep_expired_breakdown(ttl_days)
        return result["total"]

    async def sweep_expired_breakdown(self, ttl_days: float) -> dict:
        """
        sweep_expired's actual implementation, returning a per-library
        tally as well as the total:

            {"total": 5, "by_folder": {"Movies": 2, "Series4K": 3}}

        The breakdown exists so the log line can show the sweep really is
        reaching all four libraries rather than, say, only ever expiring
        HD movies because that's all anyone had watched.
        """
        if ttl_days <= 0:
            return {"total": 0, "by_folder": {}}

        now    = time.time()
        cutoff = now - (ttl_days * 86400)
        by_folder: dict[str, int] = {}
        total = 0

        for s in list(self._stubs.values()):
            if s.state != StubState.ACTIVE:
                continue

            # An ACTIVE stub with no resolved_at can never satisfy an
            # age comparison, so it would stay active forever — the one
            # way a stub could quietly escape the TTL. It shouldn't
            # happen (set_active always stamps it), but a sidecar
            # hand-edited or written by an older build can produce it.
            # Stamp it now so it expires one full TTL from here rather
            # than never.
            if not s.resolved_at:
                s.resolved_at = now
                await self._persist_sidecar(s)
                logger.warning(
                    "[%s] ACTIVE with no resolved_at — stamping now so the TTL applies",
                    s.stub_id,
                )
                continue

            if s.resolved_at < cutoff:
                folder = FOLDER_MAP.get((s.media_type, s.quality), "?")
                # mark_expired=True: this is the TTL doing its job, so the
                # stub must not be silently re-warmed on the next prewarm
                # pass. It waits for a real play.
                await self.revert_to_placeholder(s.stub_id, mark_expired=True)
                by_folder[folder] = by_folder.get(folder, 0) + 1
                total += 1

        return {"total": total, "by_folder": by_folder}

    def active_breakdown(self) -> dict:
        """
        Current ACTIVE stub count per library folder — used by the TTL
        settings UI to show, at a glance, that the one TTL really is
        holding all four libraries and what it's currently governing.
        """
        out = {name: 0 for name in FOLDER_MAP.values()}
        for s in self._stubs.values():
            if s.state == StubState.ACTIVE:
                folder = FOLDER_MAP.get((s.media_type, s.quality))
                if folder:
                    out[folder] += 1
        return out

    # -- State ----------------------------------------------------------------

    async def set_resolving(self, sid: str) -> None:
        if s := self._stubs.get(sid):
            s.state = StubState.RESOLVING
            # Reset the event so the next read() waits fresh
            try:
                from .fuse_fs import _get_resolve_event
                _get_resolve_event(sid).clear()
            except Exception:
                pass
            await self._persist_sidecar(s)

    # Minimum plausible size for real movie/episode media — mirrors the
    # same guard in aiostreams_client._probe_stream(). Applied here too as
    # defense in depth: if a candidate somehow reached set_active() with an
    # implausibly small size, reject the resolution rather than activating
    # a stub that will only ever serve a near-empty file.
    _MIN_PLAUSIBLE_MEDIA_BYTES = 50 * 1024 * 1024   # 50MB

    async def set_active(self, sid: str, url: str, headers: dict, size: Optional[int] = None,
                         resolved_at: Optional[float] = None) -> None:
        """
        Mark a stub ACTIVE against a resolved stream.

        `resolved_at` overrides the timestamp the TTL is measured from.
        Only pack fast-tracking passes it: every episode pulled from one
        season pack shares a single cached source, so they should share a
        single lease on it and expire together on one sweep. Resolving a
        30-episode season takes long enough that per-episode timestamps
        would otherwise trickle the season out of ACTIVE over an hour,
        which is both untidy and the thing most likely to leave someone
        mid-binge waiting on a re-resolve. Everything else omits it and
        gets time.time() as before.
        """
        if s := self._stubs.get(sid):
            resolved_size = size

            if not resolved_size:
                # AIOStreams didn't return a size — try a HEAD request to get
                # Content-Length from the CDN so getattr() can report the
                # real size. Run via to_thread — this is a blocking
                # requests.head() call and set_active is now a coroutine
                # awaited from async call sites, so running it inline would
                # block the event loop for the duration of the HEAD request.
                resolved_size = await asyncio.to_thread(self._head_for_size, url, headers)

            if resolved_size and resolved_size < self._MIN_PLAUSIBLE_MEDIA_BYTES:
                logger.warning(
                    "[%s] rejecting resolution: reported size %d bytes (%.1f MB) "
                    "is implausibly small for real media — treating as a bad link",
                    sid, resolved_size, resolved_size / 1024 / 1024
                )
                await self.set_error(sid)
                return

            _prev_size = s.stream_size
            s.state, s.stream_url, s.stream_headers = StubState.ACTIVE, url, headers
            s.error_count   = 0   # successful resolution clears any prior failure streak
            s.last_error_at = None
            if resolved_size:
                s.stream_size = resolved_size
            s.resolved_at = resolved_at or time.time()
            s.ever_resolved = True
            # last_resolved_at is the mtime Plex sees, so it advances only
            # when the underlying media actually differs — judged by a
            # changed size. Re-resolving the same episode after a TTL
            # expiry usually lands on the same release, and bumping mtime
            # there would put a months-old title back in Recently Added
            # every time someone rewatched it.
            if s.last_resolved_at is None or (resolved_size and resolved_size != _prev_size):
                s.last_resolved_at = s.resolved_at
            # A fresh resolve clears any prior expiry marker — the stub is
            # live again, and if it expires later prewarm should re-evaluate
            # it from scratch rather than stay permanently excluded.
            s.ttl_expired_at = None
            # A working stream proves the sources aren't dead after all,
            # so reset the dead counter. first_seen_at is kept — it's
            # still true, and it's what stops a long-standing title that
            # briefly went dead from re-reading as new content.
            try:
                from . import stub_history
                stub_history.clear_dead(sid)
            except Exception:
                pass
            # Wake any FUSE read() that's waiting for this stub to resolve
            try:
                from .fuse_fs import signal_resolved
                signal_resolved(sid)
            except Exception:
                pass
            # Trigger a scoped Plex partial scan of just this stub's folder
            # so Plex picks up the renamed " - Ready" file quickly, instead
            # of waiting for the next periodic/full library scan.
            try:
                from .fuse_fs import _fs_instance
                from .plex_scan import scan_folder_async
                if _fs_instance is not None:
                    folder = _fs_instance._resolved_folder(s)
                    scan_folder_async(folder)
            except Exception as exc:
                logger.warning("Could not trigger Plex partial scan for %s: %s", sid, exc)
            await self._persist_sidecar(s)

    @staticmethod
    def _head_for_size(url: str, headers: dict) -> Optional[int]:
        """Blocking HEAD request to recover Content-Length. Run via to_thread."""
        r = None
        try:
            import requests as _req
            r = _req.head(url, headers=headers, timeout=5, allow_redirects=True)
            cl = r.headers.get("Content-Length") or r.headers.get("content-length")
            return int(cl) if cl else None
        except Exception:
            return None
        finally:
            if r is not None:
                r.close()

    async def set_error(self, sid: str) -> None:
        if s := self._stubs.get(sid):
            s.state         = StubState.ERROR
            s.error_count  += 1
            s.last_error_at = time.time()
            # Wake any waiting read() so it falls back to stub bytes immediately
            try:
                from .fuse_fs import signal_resolved
                signal_resolved(sid)
            except Exception:
                pass

            # A stub that's failed resolution this many times in a row is
            # treated as permanently dead rather than just temporarily
            # unavailable — leaving it in place would keep showing Plex a
            # "this exists in 4K" entry that can never actually play, which
            # is a worse false positive than just not having stubbed it.
            max_errors = _settings.get("dead_stub_max_errors", 0)
            if max_errors and s.error_count >= max_errors:
                logger.warning(
                    "[%s] %s failed resolution %d time(s) in a row — "
                    "removing as a dead stub",
                    sid, s.title, s.error_count
                )
                await self.remove_stub(sid, dead=True)
                return

            await self._persist_sidecar(s)

    async def remove_stub(self, sid: str, dead: bool = False) -> bool:
        """
        Permanently remove a stub: deletes its placeholder .mkv and sidecar
        .json from disk, drops it from the in-memory index, and triggers a
        scoped Plex rescan so the now-vanished file is cleaned out of Plex's
        library too (rather than lingering as a broken/missing item until
        the next periodic full scan).

        `dead=True` means "removed because every candidate stream was
        dead", and records that in gateway/stub_history so it survives the
        deletion. Without it, removal is amnesia: the auto-episode sweep
        re-stubs the episode minutes later, prewarm sees a stub with
        created_at=now and probes the same dead sources again, forever.
        Callers that remove a stub for any OTHER reason (a person deleting
        a title, a library cleanup) leave it False, so nothing is
        suppressed that the person might legitimately re-add.
        """
        s = self._stubs.pop(sid, None)
        if not s:
            return False
        self._path_index.pop(s.abs_path, None)
        path = Path(s.abs_path)
        sidecar = path.with_suffix(".aiogateway.json")
        for f in (path, sidecar):
            try:
                await asyncio.to_thread(f.unlink, missing_ok=True)
            except Exception as exc:
                logger.warning("[%s] Could not delete %s: %s", sid, f, exc)

        # Same scoped-rescan pattern used by set_active/revert_to_placeholder —
        # readdir() no longer lists this stub at all now that it's gone from
        # _stubs, so Plex's existing library entry needs a nudge to notice.
        try:
            from .fuse_fs import _fs_instance
            from .plex_scan import scan_folder_async
            if _fs_instance is not None:
                folder = _fs_instance._resolved_folder(s)
                scan_folder_async(folder)
        except Exception as exc:
            logger.warning("[%s] Could not trigger Plex rescan after removal: %s", sid, exc)

        if dead:
            try:
                from . import stub_history
                label = (f"{s.show_title or s.title} S{s.season:02d}E{s.episode:02d}"
                         if s.season is not None and s.episode is not None else s.title)
                count = stub_history.record_dead(sid, f"{label} ({s.quality.value})")
                if stub_history.permanently_dead(sid):
                    logger.info(
                        "[%s] Removed dead stub: %s — attempt %d, no further "
                        "automatic retries (still addable manually)",
                        sid, s.title, count,
                    )
                else:
                    nxt = stub_history.retry_at(sid)
                    logger.info(
                        "[%s] Removed dead stub: %s — attempt %d, suppressed for %.1fh",
                        sid, s.title, count,
                        ((nxt or time.time()) - time.time()) / 3600.0,
                    )
            except Exception as exc:
                logger.warning("[%s] Could not record dead stub: %s", sid, exc)
        else:
            logger.info("[%s] Removed stub: %s", sid, s.title)
        return True

    # Backoff schedule (seconds) by error_count, capped at the last value.
    _ERROR_COOLDOWNS = [30, 60, 300, 900, 3600]   # 30s, 1m, 5m, 15m, 1h

    def in_error_cooldown(self, sid: str) -> bool:
        """
        True if this stub recently failed resolution and is still within its
        backoff window — callers should skip re-probing AIOStreams/CDN links
        and just serve stub bytes instead. Prevents hammering a permanently
        dead title's sources on every single play attempt.
        """
        s = self._stubs.get(sid)
        if not s or s.state != StubState.ERROR or not s.last_error_at:
            return False
        idx = min(s.error_count - 1, len(self._ERROR_COOLDOWNS) - 1)
        cooldown = self._ERROR_COOLDOWNS[max(idx, 0)]
        return (time.time() - s.last_error_at) < cooldown

    # -- Backup / restore -------------------------------------------------------

    def export_all(self) -> list[dict]:
        """
        Serialize every known stub's metadata for backup. Deliberately does
        NOT include resolve state (stream_url/headers/stream_size) — a
        restored backup should come back as fresh stubs that re-resolve on
        next play, not with old (likely expired) CDN URLs baked in.
        """
        out = []
        for s in self._stubs.values():
            out.append({
                "stub_id":         s.stub_id,
                "media_id":        s.media_id,
                "title":           s.title,
                "quality":         s.quality.value,
                "imdb_id":         s.imdb_id,
                "aiostreams_type": s.aiostreams_type,
                "aiostreams_id":   s.aiostreams_id,
                "media_type":      s.media_type.value,
                "show_title":      s.show_title,
                "year":            s.year,
                "season":          s.season,
                "episode":         s.episode,
                "poster":          getattr(s, "_poster", ""),
                "created_at":      s.created_at,
                "first_seen_at":   s.first_seen_at,
            })
        return out

    async def import_all(self, items: list[dict], replace: bool = False) -> dict:
        """
        Restore stubs from a backup export. Each item becomes a fresh
        PLACEHOLDER stub (re-resolves on next play — no stale CDN URLs are
        imported). Also (re)writes the sidecar files to disk so they
        persist the same way newly-created stubs do.

        replace=True clears all current stubs first (full restore).
        replace=False merges, skipping any stub_id that already exists
        (safe "add missing" import).

        Returns {"imported": N, "skipped": N, "errors": [...]}.
        """
        if replace:
            self._stubs.clear()
            self._path_index.clear()

        imported, skipped, errors = 0, 0, []

        for data in items:
            try:
                sid = data["stub_id"]
                if not replace and sid in self._stubs:
                    skipped += 1
                    continue

                quality    = Quality(data["quality"])
                media_type = MediaType(data.get("media_type", "movie"))
                title = data.get("title", "")
                show_title = data.get("show_title", "")
                year = data.get("year")
                season = data.get("season")
                episode = data.get("episode")

                from .models import MediaItem
                item = MediaItem(
                    id=data["media_id"], imdb_id=data["imdb_id"], title=title,
                    year=year, media_type=media_type,
                    season=season, episode=episode,
                )
                if media_type == MediaType.SERIES:
                    item.show_title = show_title or title
                path = self._build_path(item, quality)

                await asyncio.to_thread(path.parent.mkdir, parents=True, exist_ok=True)
                if not path.exists():
                    await asyncio.to_thread(path.write_bytes, _get_stub_bytes(quality))

                stub = Stub(
                    stub_id         = sid,
                    media_id        = data["media_id"],
                    title           = title,
                    quality         = quality,
                    abs_path        = str(path),
                    imdb_id         = data["imdb_id"],
                    aiostreams_type = data["aiostreams_type"],
                    aiostreams_id   = data["aiostreams_id"],
                    created_at      = data.get("created_at", time.time()),
                    first_seen_at   = data.get("first_seen_at") or data.get("created_at"),
                    media_type      = media_type,
                    show_title      = show_title,
                    year            = year,
                    season          = season,
                    episode         = episode,
                )
                poster = data.get("poster", "")
                stub._poster = poster
                self._stubs[sid] = stub
                self._path_index[str(path)] = sid

                sidecar = path.with_suffix(".aiogateway.json")
                await asyncio.to_thread(sidecar.write_text, json.dumps({
                    "stub_id": sid, "media_id": data["media_id"], "title": title,
                    "imdb_id": data["imdb_id"], "quality": quality.value,
                    "media_type": media_type.value,
                    "aiostreams_type": data["aiostreams_type"],
                    "aiostreams_id": data["aiostreams_id"],
                    "poster": poster, "created_at": stub.created_at,
                    "first_seen_at": stub.first_seen_at,
                    "show_title": show_title, "year": year,
                    "season": season, "episode": episode,
                    "stream_size": None,
                }, indent=2))

                imported += 1
            except Exception as exc:
                errors.append(f"{data.get('stub_id', '?')}: {exc}")
                logger.warning("Import failed for stub %s: %s", data.get("stub_id"), exc)

        return {"imported": imported, "skipped": skipped, "errors": errors}

    # -- Restore from disk on restart -----------------------------------------

    async def restore(self) -> int:
        count = 0
        root = _library_root()
        if not root.exists():
            return 0
        for sidecar in root.rglob("*.aiogateway.json"):
            try:
                data = json.loads(sidecar.read_text())
                mkv = sidecar.with_suffix("").with_suffix(".mkv")
                if not mkv.exists():
                    continue
                quality = Quality(data["quality"])

                # Resolve state — these fields are only present in sidecars
                # written after the persistence fix (see _persist_sidecar).
                # Older sidecars from before that fix simply won't have
                # them, and fall back to PLACEHOLDER (the original
                # behaviour) via StubState's own default.
                saved_state = data.get("state")
                state = StubState(saved_state) if saved_state else StubState.PLACEHOLDER
                # A stub saved mid-RESOLVING (e.g. container killed during
                # an in-flight resolution) can never actually still be
                # resolving after a restart — nothing is running anymore.
                # Restart it as PLACEHOLDER so the next play attempt
                # re-triggers resolution cleanly, rather than getting stuck
                # waiting on a resolve event that will never fire.
                if state == StubState.RESOLVING:
                    state = StubState.PLACEHOLDER

                stub = Stub(
                    stub_id         = data["stub_id"],
                    media_id        = data["media_id"],
                    title           = data.get("title", ""),
                    quality         = quality,
                    abs_path        = str(mkv),
                    imdb_id         = data["imdb_id"],
                    aiostreams_type = data["aiostreams_type"],
                    aiostreams_id   = data["aiostreams_id"],
                    created_at      = data.get("created_at", time.time()),
                    first_seen_at   = data.get("first_seen_at") or data.get("created_at"),
                    # Path-derivation fields (may be absent in old sidecars)
                    media_type      = MediaType(data.get("media_type", "movie")),
                    show_title      = data.get("show_title", ""),
                    year            = data.get("year"),
                    season          = data.get("season"),
                    episode         = data.get("episode"),
                    stream_size     = data.get("stream_size"),
                    # Resolve state restored from the sidecar instead of
                    # always defaulting to PLACEHOLDER — this is the actual
                    # fix for "active stubs turn into placeholders on
                    # restart". If the CDN URL has since expired, the
                    # existing 403/410/416 handling in fuse_fs.py will
                    # detect that on next read and revert it cleanly, the
                    # same as it would for any other expired link.
                    state           = state,
                    stream_url      = data.get("stream_url") if state == StubState.ACTIVE else None,
                    stream_headers  = data.get("stream_headers") or {},
                    resolved_at     = data.get("resolved_at") if state == StubState.ACTIVE else None,
                    # Only meaningful while the stub is a placeholder; an
                    # ACTIVE stub by definition hasn't expired.
                    ttl_expired_at  = data.get("ttl_expired_at") if state != StubState.ACTIVE else None,
                    # Sticky across restarts: a stub restored as a
                    # placeholder that had resolved before must keep its
                    # " - Ready" filename, or the restart itself becomes a
                    # rename Plex reports as new content.
                    ever_resolved   = bool(data.get("ever_resolved")) or state == StubState.ACTIVE,
                    last_resolved_at = data.get("last_resolved_at") or data.get("resolved_at"),
                    error_count     = data.get("error_count", 0),
                    last_error_at   = data.get("last_error_at"),
                )
                stub._poster = data.get("poster", "")
                self._stubs[stub.stub_id] = stub
                self._path_index[stub.abs_path] = stub.stub_id
                count += 1

                # Backfill gateway/library_items for titles that already
                # existed before that module did — _create_one() only ever
                # touches it for genuinely new stubs, so anything restored
                # here from a pre-existing sidecar would otherwise have no
                # library_items record at all, making it vanish from the
                # Library page entirely the moment its last stub is deleted
                # instead of staying as a rescannable shell. Best-effort,
                # same as the _create_one call.
                try:
                    from . import library_items as _lib_items
                    _lib_items.touch(
                        stub.imdb_id,
                        stub.show_title or stub.title,
                        stub.media_type.value,
                        stub.year,
                        stub._poster,
                    )
                except Exception as exc:
                    logger.warning("Could not backfill library item for %s: %s", stub.imdb_id, exc)

            except Exception as exc:
                logger.warning("Could not restore sidecar %s: %s", sidecar, exc)
        return count
