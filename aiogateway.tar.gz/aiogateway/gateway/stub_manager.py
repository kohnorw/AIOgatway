"""
gateway/stub_manager.py — The library registry.

There are no placeholders. An entry is only created once it is BOUND to a
real file inside a torrent that is cached on TorBox and present in the
account (see TorBoxClient.bind_for_quality). Everything Plex can see is a
real, playable file with its real size, from the very first scan.

States:
  ACTIVE   bound and working                         → listed in Plex
  ERROR    was bound, its file stopped working       → still listed, the
           repair loop re-verifies or rebinds it (possibly to another
           cached torrent); removed if TorBox has nothing left for it
  UNBOUND  a record with no TorBox file yet — only from restoring a backup
           or upgrading from the old placeholder design → hidden from Plex,
           the repair loop binds it or drops it

Persistence: one JSON sidecar per entry under <mountpoint>_data. No media
bytes are ever written to disk.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

from .models import MediaItem, MediaType, Quality, Stub, StubState
from . import settings as _settings

logger = logging.getLogger("aiogateway.stubs")

SIDECAR_SUFFIX = ".aiogateway.json"


def _library_root() -> Path:
    override = os.environ.get("LIBRARY_DATA_ROOT")
    if override:
        return Path(override)
    mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    return Path(mountpoint.rstrip("/") + "_data")


FOLDER_MAP = {
    (MediaType.MOVIE,  Quality.HD):  "Movies",
    (MediaType.MOVIE,  Quality.UHD): "Movies4K",
    (MediaType.SERIES, Quality.HD):  "Series",
    (MediaType.SERIES, Quality.UHD): "Series4K",
}


def _stub_id(media_id: str, quality: Quality) -> str:
    return hashlib.sha256(f"{media_id}:{quality.value}".encode()).hexdigest()[:16]


def _safe_name(name: str) -> str:
    import re
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', '', name).strip('. ')


def virtual_path(stub: Stub) -> str:
    """Path of the entry inside the FUSE mount (what Plex sees)."""
    is_4k = stub.quality == Quality.UHD
    if stub.media_type == MediaType.SERIES:
        top = "Series4K" if is_4k else "Series"
        show = _safe_name(stub.show_title or stub.title)
        folder = f"{show} ({stub.year})" if stub.year else show
        season, ep = stub.season or 1, stub.episode or 1
        return f"/{top}/{folder}/Season {season:02d}/S{season:02d}E{ep:02d}.mkv"
    top = "Movies4K" if is_4k else "Movies"
    title = _safe_name(stub.title)
    folder = f"{title} ({stub.year})" if stub.year else title
    return f"/{top}/{folder}/{folder}.mkv"


def mount_folder(stub: Stub) -> str:
    mountpoint = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt").rstrip("/")
    return mountpoint + virtual_path(stub).rsplit("/", 1)[0]


def is_listed(stub: Stub) -> bool:
    """Only entries bound to a TorBox file are visible to Plex."""
    from .torbox_client import is_ref
    return stub.state in (StubState.ACTIVE, StubState.ERROR) and is_ref(stub.stream_url)


def item_for_stub(stub: Stub) -> MediaItem:
    if stub.media_type == MediaType.MOVIE:
        return MediaItem(id=stub.media_id, imdb_id=stub.imdb_id, title=stub.title,
                         year=stub.year, media_type=MediaType.MOVIE)
    return MediaItem(id=stub.media_id, imdb_id=stub.imdb_id, title=stub.title,
                     show_title=stub.show_title or stub.title, year=stub.year,
                     media_type=MediaType.SERIES, season=stub.season, episode=stub.episode)


class StubManager:
    def __init__(self) -> None:
        self._stubs: dict[str, Stub] = {}
        self._path_index: dict[str, str] = {}
        self.client = None                       # TorBoxClient, set by main at startup
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._repair_wakeup: Optional[asyncio.Event] = None

    def attach(self, client, loop: asyncio.AbstractEventLoop) -> None:
        self.client = client
        self._loop = loop
        self._repair_wakeup = asyncio.Event()

    def _sidecar_path(self, item: MediaItem, quality: Quality) -> Path:
        base = _library_root() / FOLDER_MAP[(item.media_type, quality)] / item.folder_name
        if item.media_type == MediaType.SERIES:
            base = base / item.season_folder
        return base / f"{item.file_stem}.mkv"   # identity path; only the sidecar next to it is written

    # -- Creation (bind first, then record) -----------------------------------

    async def create_stubs(self, item: MediaItem) -> list[Stub]:
        """
        Bind and record HD, plus 4K when there are at least min_4k_candidates
        4K sources (and spot check hasn't marked 4K unavailable). A quality
        whose cached torrents can't be bound right now is simply not added —
        the caller's normal retry paths (pending movies, auto-episodes,
        spot check) pick it up later.
        """
        from gateway import quality_unavailable as _qu

        min_4k = max(1, _settings.get("min_4k_candidates", 2) or 1)
        hd_count = sum(1 for s in item.streams if not s.is_4k)
        uhd_count = sum(1 for s in item.streams if s.is_4k)

        qualities = []
        if hd_count:
            qualities.append(Quality.HD)
        if _qu.is_marked(item.imdb_id, item.season, item.episode):
            logger.info("%s: 4K previously confirmed unavailable — skipping", item.title)
        elif uhd_count >= min_4k:
            qualities.append(Quality.UHD)
        elif uhd_count:
            logger.info("%s: %d 4K source(s), below min_4k_candidates=%d — skipping 4K",
                        item.title, uhd_count, min_4k)

        created = []
        for q in qualities:
            stub = await self.create_stub_for_quality(item, q, None)
            if stub:
                created.append(stub)
        return created

    async def create_stub_for_quality(self, item: MediaItem, quality: Quality, stream) -> Optional[Stub]:
        """Bind (unless `stream` is already bound) and record one quality.
        Returns None if nothing cached could be bound."""
        from .torbox_client import AllCandidatesDeadError, TorBoxUnavailableError, is_ref, parse_ref

        sid = _stub_id(item.id, quality)
        existing = self._stubs.get(sid)
        if existing and existing.state == StubState.ACTIVE and is_ref(existing.stream_url):
            return existing

        if not (stream and is_ref(stream.url) and parse_ref(stream.url)["file_id"] is not None and stream.size):
            try:
                stream = await self.client.bind_for_quality(item, quality)
            except AllCandidatesDeadError as exc:
                logger.info("%s (%s): no cached torrent could be bound (%s)", item.aiostreams_id, quality.value, exc)
                return None
            except TorBoxUnavailableError as exc:
                logger.warning("%s (%s): TorBox unavailable while binding — %s", item.aiostreams_id, quality.value, exc)
                return None
            if not stream:
                return None

        path = self._sidecar_path(item, quality)
        now = time.time()
        stub = existing or Stub(
            stub_id=sid, media_id=item.id, title=item.title, quality=quality,
            abs_path=str(path), imdb_id=item.imdb_id,
            aiostreams_type=item.aiostreams_type, aiostreams_id=item.aiostreams_id,
            media_type=item.media_type, show_title=item.show_title, year=item.year,
            season=item.season, episode=item.episode, created_at=now,
        )
        stub.state, stub.stream_url, stub.stream_headers = StubState.ACTIVE, stream.url, {}
        stub.stream_size, stub.resolved_at = stream.size, now
        stub.error_count, stub.last_error_at = 0, None
        stub._poster = getattr(item, "_poster", "") or getattr(stub, "_poster", "")

        self._stubs[sid] = stub
        self._path_index[str(path)] = sid
        await self._persist_sidecar(stub)
        self._clear_pending(stub)
        self._scan(stub)
        logger.info("Added %s (%s) → %s", item.aiostreams_id, quality.value, stream.filename)
        return stub

    # -- Lookups ----------------------------------------------------------------

    def get(self, stub_id: str) -> Optional[Stub]:
        return self._stubs.get(stub_id)

    def by_path(self, path: str) -> Optional[Stub]:
        sid = self._path_index.get(path)
        return self._stubs.get(sid) if sid else None

    def all(self) -> list[Stub]:
        return list(self._stubs.values())

    def listed(self) -> list[Stub]:
        return [s for s in self._stubs.values() if is_listed(s)]

    # -- Persistence ------------------------------------------------------------

    def _build_sidecar_payload(self, stub: Stub) -> dict:
        return {
            "stub_id": stub.stub_id, "media_id": stub.media_id, "title": stub.title,
            "imdb_id": stub.imdb_id, "quality": stub.quality.value,
            "media_type": stub.media_type.value, "aiostreams_type": stub.aiostreams_type,
            "aiostreams_id": stub.aiostreams_id, "poster": getattr(stub, "_poster", ""),
            "created_at": stub.created_at, "show_title": stub.show_title, "year": stub.year,
            "season": stub.season, "episode": stub.episode, "stream_size": stub.stream_size,
            "state": stub.state.value, "stream_url": stub.stream_url,
            "resolved_at": stub.resolved_at, "error_count": stub.error_count,
            "last_error_at": stub.last_error_at,
        }

    def persist_sidecar_sync(self, stub: Stub) -> None:
        try:
            sidecar = Path(stub.abs_path).with_suffix(SIDECAR_SUFFIX)
            sidecar.parent.mkdir(parents=True, exist_ok=True)
            sidecar.write_text(json.dumps(self._build_sidecar_payload(stub), indent=2))
        except Exception as exc:
            logger.warning("[%s] Could not persist sidecar: %s", stub.stub_id, exc)

    async def _persist_sidecar(self, stub: Stub) -> None:
        await asyncio.to_thread(self.persist_sidecar_sync, stub)

    @staticmethod
    def _clear_pending(stub: Stub) -> None:
        """A movie that's in the library isn't pending any more, however it
        got there (add, Search anyway, a picked release, manual scan, the
        pending sweep, repair)."""
        if stub.media_type != MediaType.MOVIE:
            return
        try:
            from . import pending_movies
            if pending_movies.remove(stub.imdb_id):
                logger.info("%s is in the library now — no longer pending", stub.title)
        except Exception as exc:
            logger.debug("Could not clear pending state for %s: %s", stub.imdb_id, exc)

    def _scan(self, stub: Stub) -> None:
        try:
            from .plex_scan import scan_folder_async
            scan_folder_async(mount_folder(stub))
        except Exception as exc:
            logger.debug("Plex scan trigger failed for %s: %s", stub.stub_id, exc)

    # -- State changes ----------------------------------------------------------

    async def set_active(self, sid: str, url: str, headers: dict, size: Optional[int] = None) -> None:
        """Point an entry at a (new) bound file — used by manual stream selection and repair."""
        from .torbox_client import is_ref, ref_size
        s = self._stubs.get(sid)
        if not s:
            return
        if not is_ref(url):
            raise ValueError("entries can only point at TorBox files")
        size = size or await asyncio.to_thread(ref_size, url)
        old = s.stream_url
        was_listed = is_listed(s)
        s.state, s.stream_url, s.stream_headers = StubState.ACTIVE, url, {}
        s.stream_size = size or s.stream_size
        s.resolved_at = time.time()
        s.error_count, s.last_error_at = 0, None
        if old and old != url:
            try:
                from .fuse_fs import _block_cache
                _block_cache.invalidate(old)
            except Exception:
                pass
        await self._persist_sidecar(s)
        self._clear_pending(s)
        if not was_listed or old != url:
            self._scan(s)

    def mark_broken_sync(self, stub: Stub, reason: str = "") -> None:
        """Called from FUSE threads when a bound file stops working even
        after in-place link repair. The entry stays listed; the repair loop
        is woken to re-verify or rebind it."""
        if stub.state != StubState.ERROR:
            logger.warning("[%s] %s stopped working (%s) — queued for repair", stub.stub_id[:8], stub.title, reason)
        stub.state = StubState.ERROR
        stub.error_count += 1
        stub.last_error_at = time.time()
        self.persist_sidecar_sync(stub)
        self.wake_repair()

    async def set_error(self, sid: str) -> None:
        if s := self._stubs.get(sid):
            await asyncio.to_thread(self.mark_broken_sync, s, "set_error")

    def wake_repair(self) -> None:
        if self._loop and self._repair_wakeup:
            try:
                self._loop.call_soon_threadsafe(self._repair_wakeup.set)
            except RuntimeError:
                pass

    async def wait_for_repair_wakeup(self, timeout: float) -> None:
        if not self._repair_wakeup:
            await asyncio.sleep(timeout)
            return
        try:
            await asyncio.wait_for(self._repair_wakeup.wait(), timeout)
        except asyncio.TimeoutError:
            pass
        self._repair_wakeup.clear()

    async def remove_stub(self, sid: str) -> bool:
        s = self._stubs.pop(sid, None)
        if not s:
            return False
        self._path_index.pop(s.abs_path, None)
        path = Path(s.abs_path)
        for f in (path.with_suffix(SIDECAR_SUFFIX), path):   # path: legacy placeholder .mkv, if any
            try:
                await asyncio.to_thread(f.unlink, missing_ok=True)
            except Exception as exc:
                logger.warning("[%s] Could not delete %s: %s", sid, f, exc)
        if s.stream_url:
            try:
                from .fuse_fs import _block_cache
                _block_cache.invalidate(s.stream_url)
            except Exception:
                pass
        self._scan(s)
        logger.info("[%s] Removed %s", sid, s.title)
        return True

    # -- Repair -----------------------------------------------------------------

    _ERROR_COOLDOWNS = [0, 60, 300, 900, 3600]

    def in_error_cooldown(self, sid: str) -> bool:
        s = self._stubs.get(sid)
        if not s or s.state == StubState.ACTIVE or not s.last_error_at:
            return False
        idx = min(max(s.error_count - 1, 0), len(self._ERROR_COOLDOWNS) - 1)
        return (time.time() - s.last_error_at) < self._ERROR_COOLDOWNS[idx]

    def needs_repair(self) -> list[Stub]:
        return [s for s in self._stubs.values()
                if s.state != StubState.ACTIVE and not self.in_error_cooldown(s.stub_id)]

    async def repair(self, sid: str) -> str:
        """
        ERROR: re-verify the current file (fresh link + probe); if it's
        really gone, rebind to another cached torrent. UNBOUND: bind.
        Nothing cached left → the entry is removed (the normal retry paths
        — pending movies, auto-episodes, spot check — will add it back when
        something shows up). TorBox unavailable → kept for the next cycle.
        Returns "ok" | "rebound" | "removed" | "retry".
        """
        from .torbox_client import AllCandidatesDeadError, TorBoxUnavailableError, is_ref, ref_hash
        s = self._stubs.get(sid)
        if not s or not self.client:
            return "retry"

        if s.state == StubState.ERROR and is_ref(s.stream_url):
            if await asyncio.to_thread(self.client.verify_ref_sync, s.stream_url):
                await self.set_active(sid, s.stream_url, {}, s.stream_size)
                logger.info("[%s] %s works again", sid[:8], s.title)
                return "ok"

        exclude = {ref_hash(s.stream_url)} if is_ref(s.stream_url) else None
        try:
            stream = await self.client.bind_for_quality(item_for_stub(s), s.quality, verify=True,
                                                        exclude_hashes=exclude)
        except AllCandidatesDeadError:
            stream = None
        except TorBoxUnavailableError as exc:
            s.error_count += 1
            s.last_error_at = time.time()
            if s.state == StubState.ACTIVE:
                s.state = StubState.ERROR
            await self._persist_sidecar(s)
            logger.info("[%s] repair postponed: %s", sid[:8], exc)
            return "retry"

        if not stream:
            await self.remove_stub(sid)
            return "removed"
        await self.set_active(sid, stream.url, {}, stream.size)
        logger.info("[%s] %s bound to %s", sid[:8], s.title, stream.filename)
        return "rebound"

    # -- Backup / restore ---------------------------------------------------------

    def export_all(self) -> list[dict]:
        """Library metadata for backup. Bindings aren't exported — a restore
        re-binds every entry against the TorBox account it's restored into."""
        return [{
            "stub_id": s.stub_id, "media_id": s.media_id, "title": s.title,
            "quality": s.quality.value, "imdb_id": s.imdb_id,
            "aiostreams_type": s.aiostreams_type, "aiostreams_id": s.aiostreams_id,
            "media_type": s.media_type.value, "show_title": s.show_title, "year": s.year,
            "season": s.season, "episode": s.episode, "poster": getattr(s, "_poster", ""),
            "created_at": s.created_at,
        } for s in self._stubs.values()]

    async def import_all(self, items: list[dict], replace: bool = False) -> dict:
        """Imported entries start UNBOUND (hidden) and the repair loop binds
        them to cached torrents, dropping any TorBox can't provide."""
        if replace:
            for sid in list(self._stubs):
                await self.remove_stub(sid)

        imported, skipped, errors = 0, 0, []
        for data in items:
            try:
                sid = data["stub_id"]
                if sid in self._stubs:
                    skipped += 1
                    continue
                quality = Quality(data["quality"])
                media_type = MediaType(data.get("media_type", "movie"))
                item = MediaItem(id=data["media_id"], imdb_id=data["imdb_id"], title=data.get("title", ""),
                                 year=data.get("year"), media_type=media_type,
                                 season=data.get("season"), episode=data.get("episode"))
                if media_type == MediaType.SERIES:
                    item.show_title = data.get("show_title") or item.title
                path = self._sidecar_path(item, quality)
                stub = Stub(
                    stub_id=sid, media_id=data["media_id"], title=item.title, quality=quality,
                    abs_path=str(path), imdb_id=data["imdb_id"],
                    aiostreams_type=data["aiostreams_type"], aiostreams_id=data["aiostreams_id"],
                    created_at=data.get("created_at", time.time()), media_type=media_type,
                    show_title=data.get("show_title", ""), year=item.year,
                    season=item.season, episode=item.episode, state=StubState.UNBOUND,
                )
                stub._poster = data.get("poster", "")
                self._stubs[sid] = stub
                self._path_index[str(path)] = sid
                await self._persist_sidecar(stub)
                imported += 1
            except Exception as exc:
                errors.append(f"{data.get('stub_id', '?')}: {exc}")
        self.wake_repair()
        return {"imported": imported, "skipped": skipped, "errors": errors}

    async def restore(self) -> int:
        """Load sidecars. Anything from the old placeholder design (no
        TorBox ref) comes back UNBOUND — hidden until the repair loop binds
        it. Legacy placeholder .mkv files are deleted."""
        from .torbox_client import is_ref
        root = _library_root()
        if not root.exists():
            return 0
        count = legacy = 0
        for sidecar in root.rglob("*" + SIDECAR_SUFFIX):
            try:
                data = json.loads(sidecar.read_text())
                abs_path = sidecar.with_suffix("").with_suffix(".mkv")
                if abs_path.exists():
                    abs_path.unlink()          # old placeholder bytes
                state = StubState.parse(data.get("state"))
                url = data.get("stream_url")
                if not is_ref(url):
                    url = None
                    state = StubState.UNBOUND
                if state == StubState.UNBOUND and data.get("state") != StubState.UNBOUND.value:
                    legacy += 1
                stub = Stub(
                    stub_id=data["stub_id"], media_id=data["media_id"], title=data.get("title", ""),
                    quality=Quality(data["quality"]), abs_path=str(abs_path), imdb_id=data["imdb_id"],
                    aiostreams_type=data["aiostreams_type"], aiostreams_id=data["aiostreams_id"],
                    created_at=data.get("created_at", time.time()),
                    media_type=MediaType(data.get("media_type", "movie")),
                    show_title=data.get("show_title", ""), year=data.get("year"),
                    season=data.get("season"), episode=data.get("episode"),
                    stream_size=data.get("stream_size") if url else None,
                    state=state, stream_url=url,
                    resolved_at=data.get("resolved_at") if url else None,
                    error_count=data.get("error_count", 0) if url else 0,
                    last_error_at=data.get("last_error_at") if url else None,
                )
                stub._poster = data.get("poster", "")
                self._stubs[stub.stub_id] = stub
                self._path_index[stub.abs_path] = stub.stub_id
                count += 1
            except Exception as exc:
                logger.warning("Could not restore %s: %s", sidecar, exc)
        if legacy:
            logger.info("%d entr%s from the placeholder era will be bound to cached torrents in the background",
                        legacy, "y" if legacy == 1 else "ies")
        return count
