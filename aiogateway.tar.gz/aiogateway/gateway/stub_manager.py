"""gateway/stub_manager.py — Creates and tracks placeholder .mkv files."""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

from .models import MediaItem, MediaType, Quality, Stub, StubState

logger = logging.getLogger("aiogateway.stubs")


def _library_root() -> Path:
    """
    Where stub files are physically written.

    When FUSE is in use, this is the real backing directory (separate
    from the FUSE mountpoint that Plex/Sonarr actually browse) so that
    FUSE is never mounted on top of the same directory it reads from.
    Falls back to LIBRARY_ROOT itself when FUSE is unavailable, since
    in that case stubs are served directly with no mount in the way.
    """
    mount_root = os.environ.get("LIBRARY_ROOT", "/library")
    real_root  = os.environ.get("LIBRARY_REAL_ROOT")
    if real_root:
        return Path(real_root)
    try:
        from .fuse_fs import FUSE_AVAILABLE
    except Exception:
        FUSE_AVAILABLE = False
    if FUSE_AVAILABLE:
        return Path(mount_root.rstrip("/") + "_real")
    return Path(mount_root)


FOLDER_MAP = {
    (MediaType.MOVIE,  Quality.HD):  "Movies",
    (MediaType.MOVIE,  Quality.UHD): "Movies4K",
    (MediaType.SERIES, Quality.HD):  "Series",
    (MediaType.SERIES, Quality.UHD): "Series4K",
}


# Real stub MKV files — valid Matroska files with proper duration/tracks
# so Plex accepts them without immediately stopping playback.
# Located in stubs/ directory next to this package.
_STUBS_DIR = Path(__file__).parent.parent / "stubs"
_STUB_HD   = _STUBS_DIR / "hd.mkv"
_STUB_4K   = _STUBS_DIR / "4k.mkv"


def _get_stub_bytes(quality: Quality) -> bytes:
    """Return the real stub MKV bytes for the given quality tier."""
    stub_path = _STUB_4K if quality == Quality.UHD else _STUB_HD
    if stub_path.exists():
        return stub_path.read_bytes()
    # Fallback: try the other stub
    fallback = _STUB_HD if quality == Quality.UHD else _STUB_4K
    if fallback.exists():
        return fallback.read_bytes()
    # Last resort: minimal EBML header (original approach)
    logger.warning("Real stub files not found in %s — using minimal EBML header", _STUBS_DIR)
    ebml = bytes([
        0x1A,0x45,0xDF,0xA3, 0x9F,
        0x42,0x86,0x81,0x01, 0x42,0xF7,0x81,0x01,
        0x42,0xF2,0x81,0x04, 0x42,0xF3,0x81,0x08,
        0x42,0x82,0x88,
        0x6D,0x61,0x74,0x72,0x6F,0x73,0x6B,0x61,
        0x42,0x87,0x81,0x04, 0x42,0x85,0x81,0x02,
    ])
    segment = bytes([0x18,0x53,0x80,0x67,0x01,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF])
    return ebml + segment


def _stub_id(media_id: str, quality: Quality) -> str:
    return hashlib.sha256(f"{media_id}:{quality.value}".encode()).hexdigest()[:16]


class StubManager:
    def __init__(self) -> None:
        self._stubs: dict[str, Stub] = {}
        self._path_index: dict[str, str] = {}

    def _build_path(self, item: MediaItem, quality: Quality) -> Path:
        folder_name = FOLDER_MAP[(item.media_type, quality)]
        base = _library_root() / folder_name

        if item.media_type == MediaType.MOVIE:
            return base / item.folder_name / f"{item.file_stem}.mkv"
        else:
            # Series: /library/Series/Show Title (Year)/Season 01/S01E01 - Episode Title.mkv
            return base / item.folder_name / item.season_folder / f"{item.file_stem}.mkv"

    async def create_stubs(self, item: MediaItem) -> list[Stub]:
        """Create HD stub always; 4K stub only if item.has_4k."""
        qualities = [Quality.HD]
        if item.has_4k:
            qualities.append(Quality.UHD)

        created = []
        for q in qualities:
            stub = await self._create_one(item, q)
            created.append(stub)
        return created

    async def _create_one(self, item: MediaItem, quality: Quality) -> Stub:
        sid = _stub_id(item.id, quality)
        if sid in self._stubs:
            return self._stubs[sid]

        path = self._build_path(item, quality)
        await asyncio.to_thread(path.parent.mkdir, parents=True, exist_ok=True)
        await asyncio.to_thread(path.write_bytes, _get_stub_bytes(quality))

        stub = Stub(
            stub_id         = sid,
            media_id        = item.id,
            title           = item.title,
            quality         = quality,
            abs_path        = str(path),
            imdb_id         = item.imdb_id,
            aiostreams_type = item.aiostreams_type,
            aiostreams_id   = item.aiostreams_id,
        )
        self._stubs[sid] = stub
        self._path_index[str(path)] = sid

        # Sidecar for restart persistence
        poster = getattr(item, "_poster", "")
        stub._poster = poster
        sidecar = path.with_suffix(".aiogateway.json")
        await asyncio.to_thread(sidecar.write_text, json.dumps({
            "stub_id": sid, "media_id": item.id, "title": item.title,
            "imdb_id": item.imdb_id, "quality": quality.value,
            "media_type": item.media_type.value,
            "aiostreams_type": item.aiostreams_type,
            "aiostreams_id": item.aiostreams_id,
            "poster": poster,
            "created_at": stub.created_at,
        }, indent=2))

        logger.info("Created stub: %s → %s", sid, path)
        return stub

    # -- Lookups --------------------------------------------------------------

    def get(self, stub_id: str) -> Optional[Stub]:
        return self._stubs.get(stub_id)

    def by_path(self, path: str) -> Optional[Stub]:
        sid = self._path_index.get(path)
        return self._stubs.get(sid) if sid else None

    def all(self) -> list[Stub]:
        return list(self._stubs.values())

    # -- State ----------------------------------------------------------------

    def set_resolving(self, sid: str) -> None:
        if s := self._stubs.get(sid): s.state = StubState.RESOLVING

    def set_active(self, sid: str, url: str, headers: dict) -> None:
        if s := self._stubs.get(sid):
            s.state, s.stream_url, s.stream_headers = StubState.ACTIVE, url, headers
            s.resolved_at = time.time()

    def set_error(self, sid: str) -> None:
        if s := self._stubs.get(sid): s.state = StubState.ERROR

    # -- Restore from disk on restart -----------------------------------------

    async def restore(self) -> int:
        count = 0
        root = _library_root()
        if not root.exists():
            return 0
        for sidecar in root.rglob("*.aiogateway.json"):
            try:
                data = json.loads(sidecar.read_text())
                mkv = sidecar.with_suffix("").with_suffix(".mkv")
                if not mkv.exists():
                    continue
                quality = Quality(data["quality"])
                stub = Stub(
                    stub_id         = data["stub_id"],
                    media_id        = data["media_id"],
                    title           = data.get("title", ""),
                    quality         = quality,
                    abs_path        = str(mkv),
                    imdb_id         = data["imdb_id"],
                    aiostreams_type = data["aiostreams_type"],
                    aiostreams_id   = data["aiostreams_id"],
                    created_at      = data.get("created_at", time.time()),
                )
                stub._poster = data.get("poster", "")
                self._stubs[stub.stub_id] = stub
                self._path_index[stub.abs_path] = stub.stub_id
                count += 1
            except Exception as exc:
                logger.warning("Could not restore sidecar %s: %s", sidecar, exc)
        return count
