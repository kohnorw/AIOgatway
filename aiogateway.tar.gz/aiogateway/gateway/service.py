"""
gateway/service.py
~~~~~~~~~~~~~~~~~~
The layer between the API and everything else: adding titles, activating
them on first play, and the sweeps that chase down what couldn't be had
straight away.

Adding never just fails
-----------------------
A request for something that isn't available yet is still a request. If
the search comes back empty, the title goes into the request trackers
(see gateway/requests.py) and a sweep keeps trying. The person is told
it's pending rather than told no, and doesn't have to remember to come
back and ask again.

Two ways a file gets created, and the difference matters:

  add_movie / add_series  — search, pick the best source, store the link.
    The file is real from the moment it appears, so Plex's scanner reads
    genuine media and gets codec, duration and audio tracks right first
    time.

  prepare_only=True (Migrate) — search only far enough to confirm a
    source exists, record the size, stop. The link is fetched on first
    play. A migration can cover thousands of titles, and holding a link
    for every one of them would open a lot of debrid sessions for files
    nobody has asked to watch yet.

Both produce the same thing in the library, and activation is identical
and permanent either way.
"""
from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timedelta, timezone
from typing import Optional

from . import aiostreams, cinemeta, fusefs, plex, requests as reqs, settings
from .aiostreams import AIOStreamsClient, AIOStreamsError
from .library import Library
from .models import Candidate, Entry, EntryState, MediaItem, MediaType, Quality
from .paths import mountpoint

logger = logging.getLogger("aiogateway.service")


def _parse_release(value) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value)[:10]).replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def movie_searchable_at(record: dict) -> Optional[datetime]:
    """When a film becomes worth searching for.

    Theatrical release plus the digital delay. Metadata only ever carries
    the theatrical date, and the gap before a digital copy exists is
    exactly the window in which the only findable copies are cam rips —
    so searching during it mostly turns up something nobody wants.
    """
    released = _parse_release(record.get("released") or record.get("releaseInfo"))
    if released is None:
        return None
    delay = float(settings.get("digital_release_delay_days", 21) or 0)
    return released + timedelta(days=delay)


class MediaService:
    def __init__(self, library: Library, client: AIOStreamsClient) -> None:
        self.library = library
        self.client = client

    # ── adding ──────────────────────────────────────────────────────
    async def add_movie(self, imdb_id: str, *, prepare_only: bool = False,
                        added_by: str = "") -> dict:
        record = await cinemeta.meta("movie", imdb_id)
        if not record:
            raise ValueError(f"No metadata for {imdb_id}")

        item = MediaItem(
            imdb_id=imdb_id,
            title=record.get("name") or imdb_id,
            media_type=MediaType.MOVIE,
            year=cinemeta.year_of(record),
            poster=record.get("poster", ""),
        )

        # Unreleased, or still inside the digital-delay window: don't
        # spend a search on it, just start tracking.
        searchable_at = movie_searchable_at(record)
        if searchable_at and searchable_at > datetime.now(timezone.utc):
            reqs.add_pending_movie(imdb_id, item.title, item.year, item.poster, added_by)
            return {
                "title": item.title, "year": item.year, "entries": [], "pending": True,
                "reason": f"Not out yet — first search on {searchable_at.date().isoformat()}",
            }

        created = []
        for quality in (Quality.HD, Quality.UHD):
            entry = await self._create(item, quality, prepare_only, added_by)
            if entry is not None:
                created.append({"entry_id": entry.entry_id,
                                "quality": quality.value,
                                "state": entry.state.value})

        if not created:
            reqs.add_pending_movie(imdb_id, item.title, item.year, item.poster, added_by)
            return {
                "title": item.title, "year": item.year, "entries": [], "pending": True,
                "reason": ("Nothing playable found yet. It'll be retried "
                           "automatically until something turns up."),
            }

        reqs.remove_pending_movie(imdb_id)
        self.library.save()
        return {"title": item.title, "year": item.year,
                "entries": created, "pending": False}

    async def add_series(self, imdb_id: str, seasons: Optional[list[int]] = None,
                         *, prepare_only: bool = False, added_by: str = "",
                         watch_for_new_seasons: bool = False) -> dict:
        record = await cinemeta.meta("series", imdb_id)
        if not record:
            raise ValueError(f"No metadata for {imdb_id}")

        show_title = record.get("name") or imdb_id
        year = cinemeta.year_of(record)
        poster = record.get("poster", "")
        episodes = cinemeta.episodes_of(record)

        if watch_for_new_seasons:
            reqs.enable_season_watch(imdb_id, show_title, poster, year, added_by)

        wanted = set(int(s) for s in seasons) if seasons else {e["season"] for e in episodes}
        if not wanted and not watch_for_new_seasons:
            raise ValueError(f"{show_title} has no seasons listed yet")

        added = waiting = 0
        upcoming: list[int] = []

        for season in sorted(wanted):
            in_season = [e for e in episodes if e["season"] == season]
            aired = [e for e in in_season if cinemeta.has_aired(e["released"])]

            if not aired:
                # Nothing in it has aired, so there is nothing to build a
                # file from. Without a wanted-season entry the request
                # would be lost: episode discovery only reaches into
                # seasons that already have files.
                reqs.add_wanted_season(imdb_id, season, show_title, poster, year, added_by)
                upcoming.append(season)
                continue

            for episode in aired:
                item = MediaItem(
                    imdb_id=imdb_id, title=show_title, media_type=MediaType.SERIES,
                    show_title=show_title, year=year, poster=poster,
                    season=episode["season"], episode=episode["episode"],
                    episode_title=episode["title"],
                )
                if self.library.by_media(item.media_id, Quality.HD) is not None:
                    continue

                entry = await self._create_episode(item, prepare_only, added_by)
                if entry is None:
                    waiting += 1
                    reqs.add_waiting_episode(imdb_id, episode["season"],
                                             episode["episode"], show_title, poster, year)
                else:
                    added += 1
                    reqs.clear_waiting_episode(imdb_id, episode["season"], episode["episode"])
                    reqs.remove_wanted_season(imdb_id, episode["season"])
                await aiostreams.yield_to_playback()

        reqs.save()
        self.library.save()

        if not added and not waiting and not upcoming and not watch_for_new_seasons:
            raise ValueError(f"Nothing to add for {show_title}")

        return {
            "title": show_title, "added": added, "waiting": waiting,
            "upcoming_seasons": upcoming,
            "watching": reqs.is_season_watched(imdb_id),
            "pending": added == 0,
        }

    async def _create_episode(self, item: MediaItem, prepare_only: bool, added_by: str):
        """HD decides whether the episode exists at all. 4K is attempted
        separately and allowed to fail, because plenty of episodes only
        exist in HD and that shouldn't block the add."""
        try:
            entry = await self._create(item, Quality.HD, prepare_only, added_by)
        except AIOStreamsError as exc:
            logger.warning("%s S%02dE%02d: %s", item.show_title,
                           item.season or 0, item.episode or 0, exc)
            return None
        if entry is None:
            return None
        try:
            await self._create(item, Quality.UHD, prepare_only, added_by)
        except AIOStreamsError:
            pass
        return entry

    async def _create(self, item: MediaItem, quality: Quality,
                      prepare_only: bool, added_by: str):
        try:
            candidates = await self.client.search(item, quality)
        except AIOStreamsError as exc:
            logger.warning("Search failed for %s [%s]: %s", item.title, quality.value, exc)
            return None

        if quality == Quality.UHD:
            minimum = max(1, int(settings.get("min_4k_sources", 4) or 1))
            if len(candidates) < minimum:
                return None
        if not candidates:
            return None

        best = candidates[0]
        if prepare_only:
            return self.library.upsert(item, quality, candidate=None,
                                       state=EntryState.READY,
                                       size_hint=best.size, added_by=added_by)
        return self.library.upsert(item, quality, candidate=best, added_by=added_by)

    # ── activation ──────────────────────────────────────────────────
    async def activate(self, entry_id: str) -> bool:
        entry = self.library.get(entry_id)
        if entry is None:
            return False

        already = entry.activated
        self.library.mark_activated(entry_id)

        if entry.url:
            if not already:
                self._after_activation(entry)
            return True

        # A read waiting on this entry wakes when the event is set, so the
        # link has to be attached before that happens.
        fusefs.begin_activation(entry_id)
        candidate = None
        try:
            try:
                async with aiostreams.play_priority():
                    candidate = await self._find_source(entry)
            except AIOStreamsError as exc:
                logger.warning("Could not activate %s: %s", entry.display_name, exc)

            if candidate is None:
                self.library.mark_missing(entry_id)
                logger.warning("No source available for %s", entry.display_name)
                return False

            self.library.attach_source(entry_id, candidate)
        finally:
            # Always released, on every path. A waiting read must not hang
            # for its full timeout when the fetch has already failed.
            fusefs.finish_activation(entry_id)

        self.library.save()
        self._after_activation(entry)
        return True

    async def _find_source(self, entry) -> Optional[Candidate]:
        item = MediaItem(
            imdb_id=entry.imdb_id, title=entry.title, media_type=entry.media_type,
            show_title=entry.show_title, year=entry.year,
            season=entry.season, episode=entry.episode, poster=entry.poster,
        )
        return await self.client.best(item, entry.quality)

    def _after_activation(self, entry) -> None:
        try:
            plex.refresh_path_async(fusefs.folder_for(entry, mountpoint()))
        except Exception as exc:
            logger.debug("Post-activation Plex scan skipped: %s", exc)

    # ── manual stream selection ─────────────────────────────────────
    async def manual_search(self, imdb_id: str, kind: str,
                            season: Optional[int] = None,
                            episode: Optional[int] = None,
                            quality: Optional[Quality] = None) -> tuple:
        """Every stream available for one title, for the Library picker.

        Unlike the automatic paths this keeps uncached results and
        ignores the 4K source-count floor. Both of those exist to stop
        the *automatic* picker choosing something fragile; someone
        choosing by hand can see the cache state on each row and decide
        for themselves, and hiding the options would defeat the point of
        opening the list.
        """
        media_type = MediaType.SERIES if kind == "series" else MediaType.MOVIE
        record = await cinemeta.meta(kind, imdb_id)
        title = (record or {}).get("name") or imdb_id
        year = cinemeta.year_of(record or {})
        poster = (record or {}).get("poster", "")

        item = MediaItem(
            imdb_id=imdb_id, title=title, media_type=media_type,
            show_title=title if media_type == MediaType.SERIES else "",
            year=year, poster=poster, season=season, episode=episode,
        )
        async with aiostreams.play_priority():
            candidates = await self.client.search(item, quality, enforce_cached=False)
        return item, candidates

    def apply_manual_choice(self, item: MediaItem, quality: Quality,
                            candidate: Candidate, added_by: str = "") -> "Entry":
        """Point the entry for this media + quality at a chosen stream,
        creating it if it doesn't exist yet.

        Creating on demand matters: picking a 4K release for a film that
        only ever got an HD file is one of the main reasons to open this
        picker, and there is no entry to update in that case.
        """
        entry = self.library.by_media(item.media_id, quality)
        if entry is None:
            entry = self.library.upsert(item, quality, candidate=candidate,
                                        added_by=added_by or "manual")
            self.library.attach_source(entry.entry_id, candidate, pinned=True)
        else:
            self.library.attach_source(entry.entry_id, candidate, pinned=True)

        # A file already being watched keeps its activation; only the
        # stream behind it changed.
        fusefs.invalidate(entry)
        self.library.save()
        updated = self.library.get(entry.entry_id)
        logger.info("Manual pick for %s [%s]: %s",
                    updated.display_name, quality.value, candidate.filename)
        return updated


    async def sweep_pending_movies(self, force: bool = False) -> dict:
        """Retry films that weren't findable when they were asked for.

        `force` bypasses the enabled setting, for the Check now button —
        a deliberate one-off is a different thing from the recurring
        behaviour the setting governs.
        """
        reqs.load()
        if not force and not settings.get("pending_movies_enabled", True):
            return {"skipped": "disabled"}

        retry_days = float(settings.get("pending_movies_retry_days", 30) or 0)
        now = time.time()
        checked = resolved = waiting = 0

        for record in reqs.list_pending_movies():
            imdb_id = record["imdb_id"]

            if retry_days and (now - record.get("first_missed_at", now)) > retry_days * 86400:
                # Given up on automatically. Still listed and still
                # searchable by hand — this only stops the polling.
                waiting += 1
                continue

            if self.library.for_imdb(imdb_id):
                reqs.remove_pending_movie(imdb_id)
                continue

            meta = await cinemeta.meta("movie", imdb_id)
            searchable_at = movie_searchable_at(meta) if meta else None
            if searchable_at and searchable_at > datetime.now(timezone.utc):
                waiting += 1
                continue

            await aiostreams.yield_to_playback()
            checked += 1
            record["attempts"] = record.get("attempts", 0) + 1
            record["last_attempt_at"] = now

            item = MediaItem(
                imdb_id=imdb_id, title=record.get("title") or imdb_id,
                media_type=MediaType.MOVIE, year=record.get("year"),
                poster=record.get("poster", ""),
            )
            found = False
            for quality in (Quality.HD, Quality.UHD):
                try:
                    entry = await self._create(item, quality, False,
                                               record.get("requested_by", ""))
                except AIOStreamsError as exc:
                    record["last_reason"] = str(exc)
                    entry = None
                if entry is not None:
                    found = True

            if found:
                resolved += 1
                reqs.remove_pending_movie(imdb_id)
                logger.info("Pending film now available: %s", item.title)
            else:
                record["last_reason"] = record.get("last_reason") or "Nothing cached yet"

        reqs.save()
        if resolved:
            self.library.save()
        return {"checked": checked, "resolved": resolved, "waiting": waiting,
                "pending": len(reqs.list_pending_movies())}

    # ── episode discovery ───────────────────────────────────────────
    async def discover_episodes(self, force: bool = False) -> dict:
        """Find episodes that have aired since the last pass.

        Scope is deliberately narrow. A season is eligible when it
        already has files, or is registered as wanted, or is the very
        next season after one that's fully caught up. That last case is
        the natural rollover: a show moving into a new season shouldn't
        need someone to click Request again. What it will never do is
        reach into a season nobody asked for just because it's listed.
        """
        reqs.load()
        if not force and not settings.get("auto_episodes_enabled", True):
            return {"skipped": "disabled"}

        retry_days = float(settings.get("auto_episodes_retry_days", 7) or 0)
        lookahead = max(1, int(settings.get("episode_lookahead", 3) or 3))

        show_ids = sorted(self.library.series_ids() | reqs.tracked_series_ids())
        if not show_ids:
            return {"shows": 0, "added": 0, **reqs.summary()}

        shows_checked = added = 0
        new_seasons: list[str] = []

        for imdb_id in show_ids:
            await aiostreams.yield_to_playback()
            try:
                record = await cinemeta.meta("series", imdb_id)
            except Exception as exc:
                logger.warning("Metadata for %s failed: %s", imdb_id, exc)
                continue
            if not record:
                continue

            shows_checked += 1
            episodes = cinemeta.episodes_of(record)
            entries = self.library.for_imdb(imdb_id)
            watch = reqs.season_watch_record(imdb_id)

            # Prefer what's already in the library — it matches the folder
            # names Plex is using. A show whose only interaction was
            # "watch for new seasons" has no files, so the watch record is
            # the only place these came from.
            show_title = (
                next((e.show_title or e.title for e in entries if e.show_title), None)
                or (watch or {}).get("title")
                or record.get("name") or imdb_id
            )
            poster = (next((e.poster for e in entries if e.poster), None)
                      or (watch or {}).get("poster") or record.get("poster", ""))
            year = (next((e.year for e in entries if e.year), None)
                    or (watch or {}).get("year") or cinemeta.year_of(record))

            have = {(e.season, e.episode) for e in entries
                    if e.season is not None and e.episode is not None}
            with_files = {e.season for e in entries if e.season}
            wanted = reqs.wanted_seasons_for(imdb_id)
            requested = with_files | wanted

            by_season: dict[int, list] = {}
            for episode in episodes:
                by_season.setdefault(episode["season"], []).append(episode)

            # Season watch: keep exactly one speculative season registered
            # beyond whatever metadata currently lists, re-checked every
            # sweep rather than once.
            #
            # The target is deliberately measured against what metadata
            # knows, not against what's already tracked. Measuring against
            # tracked seasons compounds: the speculative season we just
            # registered becomes the new highest tracked, so the next
            # sweep registers the one after it, and a long-running install
            # accumulates a wanted entry for every season number it ever
            # counted up to. Anchoring to metadata means the registration
            # only moves forward when a real new season is announced.
            if watch is not None and by_season:
                next_season = max(by_season) + 1
                if next_season not in requested:
                    if reqs.add_wanted_season(imdb_id, next_season, show_title,
                                              poster, year, watch.get("requested_by", "")):
                        new_seasons.append(f"{show_title} S{next_season:02d}")
                    reqs.note_registered_season(imdb_id, next_season)
                    requested = requested | {next_season}
                    wanted = wanted | {next_season}

            def fully_caught_up(season: int) -> bool:
                aired = [e for e in by_season.get(season, [])
                         if cinemeta.has_aired(e["released"])]
                if not aired:
                    return False
                return all((season, e["episode"]) in have for e in aired)

            eligible = set(requested)
            for season in with_files:
                if (season + 1) not in requested and fully_caught_up(season):
                    eligible.add(season + 1)

            highest_have: dict[int, int] = {}
            for season, number in have:
                highest_have[season] = max(highest_have.get(season, 0), number)

            for episode in episodes:
                season, number = episode["season"], episode["episode"]
                if season not in eligible or (season, number) in have:
                    continue
                if not cinemeta.has_aired(episode["released"]):
                    continue
                # Catch up gradually rather than firing a whole backlog of
                # searches in a single pass.
                if number > highest_have.get(season, 0) + lookahead:
                    continue

                pending = reqs.waiting_episode(imdb_id, season, number)
                if pending and reqs.gave_up_on_episode(pending, retry_days):
                    continue

                await aiostreams.yield_to_playback()
                item = MediaItem(
                    imdb_id=imdb_id, title=show_title, media_type=MediaType.SERIES,
                    show_title=show_title, year=year, poster=poster,
                    season=season, episode=number, episode_title=episode["title"],
                )
                entry = await self._create_episode(item, False, "auto")

                if entry is None:
                    reqs.add_waiting_episode(imdb_id, season, number,
                                             show_title, poster, year)
                else:
                    added += 1
                    highest_have[season] = max(highest_have.get(season, 0), number)
                    have.add((season, number))
                    reqs.clear_waiting_episode(imdb_id, season, number)
                    if season in wanted:
                        # It has a real file now, which is the normal
                        # definition of requested everywhere else, so the
                        # wanted-season entry has done its job.
                        reqs.remove_wanted_season(imdb_id, season)
                        wanted.discard(season)
                        logger.info("%s S%02d started airing — wanted mark cleared",
                                    show_title, season)
                    logger.info("New episode: %s S%02dE%02d", show_title, season, number)
                await asyncio.sleep(0)

        reqs.save()
        if added:
            self.library.save()
        return {"shows": shows_checked, "added": added,
                "new_seasons": new_seasons, **reqs.summary()}


async def request_sweep_loop(service: MediaService) -> None:
    """Both sweeps share one schedule. They chase the same kind of gap
    and draw on the same AIOStreams budget, so separate timers would only
    mean two things racing each other for it."""
    while True:
        minutes = float(settings.get("auto_episodes_interval_minutes", 30) or 30)
        try:
            await asyncio.sleep(max(60.0, minutes * 60))

            if settings.get("auto_episodes_enabled", True):
                result = await service.discover_episodes()
                if result.get("added"):
                    logger.info("Episode check added %d", result["added"])
                for label in result.get("new_seasons") or []:
                    logger.info("Now watching for %s", label)

            if settings.get("pending_movies_enabled", True):
                result = await service.sweep_pending_movies()
                if result.get("resolved"):
                    logger.info("%d pending film(s) became available", result["resolved"])
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.error("Request sweep failed: %s", exc)
