"""
gateway/resolver.py
~~~~~~~~~~~~~~~~~~~
The one place stream links are found, refreshed and repaired.

Links are found at the PLACEHOLDER SWITCH — the moment a stub goes from
placeholder to active because someone actually played it — never when a
title is requested/added. A request only creates placeholders; whatever
links AIOStreams returned while checking availability are thrown away, so
the link used for playback is always minutes old rather than days old.

Three operations, all serialised per stub by one asyncio.Lock so a webhook,
a FUSE read and a prefetch thread can never resolve the same stub twice at
once:

  activate(sid)  Placeholder switch. Fresh AIOStreams search, candidates
                 ordered (cached first; for series: series pack → season
                 pack → episode), each live-probed, first working one wins.

  refresh(sid)   An ACTIVE link older than link_refresh_hours (24h) gets a
                 new one on its next playback. Only a link to the SAME file
                 is swapped in, because Plex already has the old file open
                 and different bytes at the same offsets would corrupt the
                 playback. If no same-file link exists the current one is
                 kept as long as it still works, and if it doesn't, refresh
                 falls through to repair.

  repair(sid)    A link that just failed a real read. Same-file links are
                 preferred so playback continues seamlessly; failing that,
                 any working link is taken (the current playback can't
                 survive the switch, but the next one works). Called from
                 FUSE worker threads via repair_blocking(), which bridges
                 into the event loop and waits for the result.
"""
from __future__ import annotations

import asyncio
import logging
import threading
import time
from typing import TYPE_CHECKING, Callable, Optional

from .models import AIOStream, MediaItem, MediaType, StubState

if TYPE_CHECKING:
    from .aiostreams_client import AIOStreamsClient
    from .stub_manager import StubManager

logger = logging.getLogger("aiogateway.resolver")

# Outcomes reported to FUSE readers.
SAME_FILE = "same_file"   # new link, same bytes — keep reading
NEW_FILE  = "new_file"    # new link, different release — current playback can't continue
FAILED    = "failed"      # nothing working found
PENDING   = "pending"     # still working on it (caller timed out waiting)

_REPAIR_FAIL_COOLDOWN_S  = 60      # after a failed repair, don't re-search on every read
_REFRESH_RETRY_S         = 1800    # refresh found no same-file link → try again in 30 min
_RATE_LIMIT_BACKOFF      = (1, 2, 4)
# A placeholder switch that hasn't found a stream by now is abandoned (stub →
# ERROR, retried on the next play) rather than leaving the stub RESOLVING —
# and every read of it waiting — indefinitely.
_SWITCH_TIMEOUT_S        = 120


def _settings():
    from . import settings as _s
    return _s


def link_refresh_seconds() -> float:
    try:
        hours = float(_settings().get("link_refresh_hours", 24) or 0)
    except Exception:
        hours = 24.0
    return max(0.0, hours) * 3600.0


def _same_size(a: Optional[int], b: Optional[int]) -> bool:
    return bool(a and b and abs(a - b) <= 64 * 1024)


class LinkResolver:
    def __init__(
        self,
        stubs: "StubManager",
        client: "AIOStreamsClient",
        on_busy_start: Optional[Callable[[], None]] = None,
        on_busy_end: Optional[Callable[[], None]] = None,
    ) -> None:
        self.stubs  = stubs
        self.client = client
        self._busy_start = on_busy_start or (lambda: None)
        self._busy_end   = on_busy_end or (lambda: None)
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._locks: dict[str, asyncio.Lock] = {}
        self._repair_failed_at: dict[str, float] = {}
        self._refresh_attempt_at: dict[str, float] = {}
        self._refresh_scheduled: set[str] = set()
        self._bg: set[asyncio.Task] = set()
        self._sched_lock = threading.Lock()

    # ── lifecycle ────────────────────────────────────────────────────────

    def bind_loop(self, loop: Optional[asyncio.AbstractEventLoop] = None) -> None:
        self._loop = loop or asyncio.get_running_loop()

    def _lock(self, sid: str) -> asyncio.Lock:
        lk = self._locks.get(sid)
        if lk is None:
            lk = self._locks[sid] = asyncio.Lock()
        return lk

    def _spawn(self, coro) -> asyncio.Task:
        t = asyncio.ensure_future(coro)
        self._bg.add(t)
        t.add_done_callback(self._bg.discard)
        return t

    # ── helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _item_for(stub) -> MediaItem:
        media_type = MediaType.MOVIE if stub.aiostreams_type == "movie" else MediaType.SERIES
        season, episode = stub.season, stub.episode
        parts = (stub.aiostreams_id or "").split(":")
        if media_type == MediaType.SERIES and len(parts) >= 3:
            try:
                season, episode = int(parts[1]), int(parts[2])
            except ValueError:
                pass
        return MediaItem(
            id=stub.media_id, imdb_id=stub.imdb_id, title=stub.title,
            show_title=stub.show_title or "", year=stub.year, media_type=media_type,
            season=season if media_type == MediaType.SERIES else None,
            episode=episode if media_type == MediaType.SERIES else None,
        )

    @staticmethod
    def _label(stub) -> str:
        if stub.season is not None and stub.episode is not None:
            return f"{stub.show_title or stub.title} S{stub.season:02d}E{stub.episode:02d} ({stub.quality.value})"
        return f"{stub.title} ({stub.quality.value})"

    def link_is_stale(self, stub) -> bool:
        """ACTIVE, and the link was found longer ago than link_refresh_hours."""
        if stub is None or stub.state != StubState.ACTIVE or not stub.stream_url:
            return False
        limit = link_refresh_seconds()
        if limit <= 0:
            return False
        return bool(stub.resolved_at) and (time.time() - stub.resolved_at) >= limit

    @staticmethod
    def _search_rounds() -> int:
        try:
            return max(1, int(_settings().get("resolve_search_rounds", 3) or 1))
        except Exception:
            return 3

    async def _find(self, stub, **kw) -> tuple[Optional[AIOStream], Optional[int]]:
        """client.find_working with a short retry on AIOStreams 429s.
        Placeholder switches and repairs re-search (resolve_search_rounds)
        when every candidate fails; same-file refreshes don't."""
        from .aiostreams_client import play_priority
        item = self._item_for(stub)
        if not kw.get("require_same_file"):
            kw.setdefault("search_rounds", self._search_rounds())
        play_priority.set(True)          # this task's searches go first in the AIOStreams queue
        last: Optional[Exception] = None
        for attempt in range(len(_RATE_LIMIT_BACKOFF) + 1):
            try:
                return await self.client.find_working(item, stub.quality, fresh=True, **kw)
            except Exception as exc:
                last = exc
                if not ("429" in str(exc) or "Too Many Requests" in str(exc)):
                    raise
                if attempt < len(_RATE_LIMIT_BACKOFF):
                    wait = _RATE_LIMIT_BACKOFF[attempt]
                    logger.warning("[%s] AIOStreams rate limited — retrying in %ds", stub.stub_id[:8], wait)
                    await asyncio.sleep(wait)
        raise last  # type: ignore[misc]

    async def _commit(self, stub, stream: AIOStream, size: Optional[int], *, rescan: bool) -> bool:
        return await self.stubs.set_active(
            stub.stub_id, stream.url, stream.request_headers or {},
            size=size or stream.size,
            file_id=stream.file_identity, filename=stream.filename,
            rescan=rescan,
        )

    # ── placeholder switch ───────────────────────────────────────────────

    async def activate(self, sid: str, reason: str = "play") -> dict:
        """Placeholder → ACTIVE with a freshly found, probed link."""
        from .aiostreams_client import AllCandidatesDeadError

        async with self._lock(sid):
            stub = self.stubs.get(sid)
            if stub is None:
                return {"action": "error", "stub_id": sid, "error": "unknown stub"}
            if stub.state == StubState.ACTIVE and stub.stream_url:
                return {"action": "already_active", "stub_id": sid}

            label = self._label(stub)
            logger.info("[%s] Placeholder switch (%s): %s", sid[:8], reason, label)
            await self.stubs.set_resolving(sid)
            self._busy_start()
            try:
                stream, size = await asyncio.wait_for(self._find(stub), timeout=_SWITCH_TIMEOUT_S)
            except asyncio.TimeoutError:
                logger.error("[%s] %s: no answer within %ds — switch abandoned, will retry on next play",
                             sid[:8], label, _SWITCH_TIMEOUT_S)
                await self.stubs.set_error(sid)
                return {"action": "error", "stub_id": sid, "error": "timed out finding a stream"}
            except AllCandidatesDeadError as exc:
                logger.warning("[%s] %s: all %d candidate(s) dead", sid[:8], label, exc.count)
                if await self._drop_unavailable_4k(stub):
                    return {"action": "removed", "stub_id": sid, "error": "no working 4K source"}
                await self.stubs.set_error(sid)
                return {"action": "error", "stub_id": sid, "error": str(exc)}
            except Exception as exc:
                logger.error("[%s] %s: resolve failed: %s", sid[:8], label, exc)
                await self.stubs.set_error(sid)
                return {"action": "error", "stub_id": sid, "error": str(exc)}
            finally:
                self._busy_end()

            if not stream or not stream.url:
                logger.warning("[%s] %s: no stream available", sid[:8], label)
                if await self._drop_unavailable_4k(stub):
                    return {"action": "removed", "stub_id": sid, "error": "no 4K source"}
                await self.stubs.set_error(sid)
                return {"action": "error", "stub_id": sid, "error": "no stream available"}

            if not await self._commit(stub, stream, size, rescan=True):
                return {"action": "error", "stub_id": sid, "error": "link rejected"}
            self._repair_failed_at.pop(sid, None)
            self._refresh_attempt_at.pop(sid, None)
            kind, num = stream.pack_type
            logger.info("[%s] %s → ACTIVE (%s)", sid[:8], label,
                        "file" if stub.media_type == MediaType.MOVIE
                        else (f"{kind} S{num:02d}" if kind == "season" and num else kind))
            return {"action": "resolved", "stub_id": sid, "quality": stub.quality.value,
                    "pack": kind if stub.media_type == MediaType.SERIES else None}

    async def _drop_unavailable_4k(self, stub) -> bool:
        """
        Requests create placeholders without asking AIOStreams anything, so
        a 4K placeholder is a guess until its first play. When that play
        finds no working 4K source, remove the placeholder and mark 4K
        unavailable for the item, so it leaves the 4K library and isn't
        recreated (a manual "Scan 4K" clears the mark). HD placeholders keep
        the normal error/backoff handling.
        """
        from .models import Quality
        if stub.quality != Quality.UHD:
            return False
        try:
            from . import quality_unavailable as _qu
            _qu.mark(stub.imdb_id, stub.show_title or stub.title, stub.season, stub.episode,
                     getattr(stub, "_poster", "") or "")
        except Exception as exc:
            logger.warning("[%s] Could not mark 4K unavailable: %s", stub.stub_id[:8], exc)
        await self.stubs.remove_stub(stub.stub_id)
        logger.info("[%s] %s: no 4K source — 4K placeholder removed", stub.stub_id[:8], self._label(stub))
        return True

    # ── 24-hour refresh ──────────────────────────────────────────────────

    async def refresh(self, sid: str, reason: str = "stale", force: bool = False) -> dict:
        """New link for an ACTIVE stub whose link is past link_refresh_hours."""
        from .aiostreams_client import AllCandidatesDeadError, probe_stream

        async with self._lock(sid):
            stub = self.stubs.get(sid)
            if stub is None or stub.state != StubState.ACTIVE or not stub.stream_url:
                return {"action": "skipped", "stub_id": sid, "reason": "not active"}
            if not force and not self.link_is_stale(stub):
                return {"action": "skipped", "stub_id": sid, "reason": "link is fresh"}

            label = self._label(stub)
            old_url, old_id, old_size = stub.stream_url, stub.stream_file_id, stub.stream_size
            age_h = (time.time() - (stub.resolved_at or time.time())) / 3600.0
            logger.info("[%s] Refreshing %.1fh-old link (%s): %s", sid[:8], age_h, reason, label)
            self._refresh_attempt_at[sid] = time.time()

            self._busy_start()
            try:
                try:
                    stream, size = await self._find(
                        stub, prefer_file_id=old_id, prefer_size=old_size,
                        require_same_file=True, max_probes=4,
                    )
                except AllCandidatesDeadError:
                    stream, size = None, None
                except Exception as exc:
                    logger.warning("[%s] Refresh search failed: %s", sid[:8], exc)
                    stream, size = None, None

                if stream is not None:
                    if await self._commit(stub, stream, size, rescan=False):
                        self._refresh_attempt_at.pop(sid, None)
                        logger.info("[%s] %s: refreshed to a new link for the same file", sid[:8], label)
                        return {"action": "refreshed", "stub_id": sid}

                # No same-file link. Keep the current one if it still works —
                # swapping a different release in under an open playback is
                # worse than an old-but-working link. Retried on a later play.
                probe = await probe_stream(AIOStream(
                    url=old_url, filename=stub.stream_filename, size=old_size, service=None,
                    cached=None, parsed_file=None, request_headers=dict(stub.stream_headers or {}),
                ))
            finally:
                self._busy_end()

            if probe.ok:
                logger.info("[%s] %s: no same-file link available; current link still works — kept",
                            sid[:8], label)
                return {"action": "kept", "stub_id": sid}

        # Current link is dead too: that's a repair (lock released first —
        # repair takes it itself).
        logger.warning("[%s] %s: old link is dead and no same-file link exists — repairing", sid[:8], label)
        outcome = await self.repair(sid, old_url, old_id, old_size)
        return {"action": f"repaired:{outcome}", "stub_id": sid}

    def _refresh_due(self, sid: str) -> bool:
        last = self._refresh_attempt_at.get(sid)
        return not last or (time.time() - last) >= _REFRESH_RETRY_S

    def schedule_refresh(self, sid: str, reason: str = "stale") -> None:
        """Non-blocking, thread-safe: queue a refresh if one is due."""
        if not self._refresh_due(sid):
            return
        with self._sched_lock:
            if sid in self._refresh_scheduled:
                return
            self._refresh_scheduled.add(sid)

        async def _run():
            try:
                await self.refresh(sid, reason)
            except Exception as exc:
                logger.warning("[%s] Background refresh failed: %s", sid[:8], exc)
            finally:
                with self._sched_lock:
                    self._refresh_scheduled.discard(sid)

        loop = self._loop
        if loop is None or loop.is_closed():
            with self._sched_lock:
                self._refresh_scheduled.discard(sid)
            return
        try:
            running = asyncio.get_running_loop()
        except RuntimeError:
            running = None
        if running is loop:
            self._spawn(_run())
        else:
            loop.call_soon_threadsafe(lambda: self._spawn(_run()))

    # ── real-time repair ─────────────────────────────────────────────────

    async def repair(self, sid: str, failed_url: str,
                     failed_file_id: Optional[str] = None,
                     failed_size: Optional[int] = None) -> str:
        """Replace a link that just failed a read. Returns SAME_FILE / NEW_FILE / FAILED."""
        from .aiostreams_client import AllCandidatesDeadError

        async with self._lock(sid):
            stub = self.stubs.get(sid)
            if stub is None:
                return FAILED

            # Someone else (another reader, a refresh) already replaced it.
            if stub.state == StubState.ACTIVE and stub.stream_url and stub.stream_url != failed_url:
                same = (failed_file_id and stub.stream_file_id == failed_file_id) or \
                       _same_size(stub.stream_size, failed_size)
                return SAME_FILE if same else NEW_FILE

            last_fail = self._repair_failed_at.get(sid)
            if last_fail and (time.time() - last_fail) < _REPAIR_FAIL_COOLDOWN_S:
                return FAILED

            label = self._label(stub)
            logger.warning("[%s] Link broke during read — repairing: %s", sid[:8], label)
            # Readers arriving now should wait for this, not hit the dead link.
            stub.repairing = True
            stub.stream_url = None
            try:
                await self.stubs.set_resolving(sid)

                self._busy_start()
                try:
                    try:
                        # Mid-playback: at most one re-search, so a broken
                        # stream isn't left hanging for long.
                        stream, size = await self._find(
                            stub, prefer_file_id=failed_file_id, prefer_size=failed_size,
                            demote_urls={failed_url}, max_probes=8,
                            search_rounds=min(2, self._search_rounds()),
                        )
                    except AllCandidatesDeadError:
                        stream, size = None, None
                    except Exception as exc:
                        logger.warning("[%s] Repair search failed: %s", sid[:8], exc)
                        stream, size = None, None
                finally:
                    self._busy_end()

                if stream is None:
                    self._repair_failed_at[sid] = time.time()
                    logger.error("[%s] %s: no working replacement link — stub marked ERROR", sid[:8], label)
                    await self.stubs.set_error(sid)
                    return FAILED

                same = bool(failed_file_id and stream.file_identity == failed_file_id) or \
                       _same_size(size or stream.size, failed_size)
                if not await self._commit(stub, stream, size, rescan=not same):
                    self._repair_failed_at[sid] = time.time()
                    return FAILED
            finally:
                stub.repairing = False
                try:
                    from .fuse_fs import signal_resolved
                    signal_resolved(sid)
                except Exception:
                    pass
            self._repair_failed_at.pop(sid, None)
            logger.info("[%s] %s: repaired — %s", sid[:8], label,
                        "same file, playback continues" if same else
                        "different release; Plex will pick it up on the next play")
            return SAME_FILE if same else NEW_FILE

    def repair_blocking(self, sid: str, failed_url: str,
                        failed_file_id: Optional[str], failed_size: Optional[int],
                        timeout: float) -> str:
        """Called from FUSE worker threads. Runs repair() on the event loop
        and waits up to `timeout` seconds for the outcome."""
        loop = self._loop
        if loop is None or loop.is_closed():
            return FAILED
        try:
            if asyncio.get_running_loop() is loop:
                # Never block the loop on itself.
                self._spawn(self.repair(sid, failed_url, failed_file_id, failed_size))
                return PENDING
        except RuntimeError:
            pass
        fut = asyncio.run_coroutine_threadsafe(
            self.repair(sid, failed_url, failed_file_id, failed_size), loop
        )
        try:
            return fut.result(timeout=timeout)
        except Exception as exc:
            if not fut.done():
                return PENDING   # keeps running; the next read sees the result
            logger.warning("[%s] Repair raised: %s", sid[:8], exc)
            return FAILED

    def schedule_repair(self, sid: str, failed_url: str,
                        failed_file_id: Optional[str], failed_size: Optional[int]) -> None:
        """Fire-and-forget repair, for prefetch threads that mustn't block."""
        loop = self._loop
        if loop is None or loop.is_closed():
            return
        loop.call_soon_threadsafe(
            lambda: self._spawn(self.repair(sid, failed_url, failed_file_id, failed_size))
        )

    # ── play entry point ─────────────────────────────────────────────────

    async def on_play(self, sid: str) -> dict:
        """
        What a real play means for a stub:
          placeholder / error / resolving → placeholder switch (awaited)
          active, link older than 24h     → refresh in the background
          active, fresh link              → nothing to do
        The switch runs as its own task, shielded, so a webhook request
        being cut off mid-resolve can't cancel it.
        """
        stub = self.stubs.get(sid)
        if stub is None:
            return {"action": "error", "stub_id": sid, "error": "unknown stub"}
        if stub.state == StubState.ACTIVE and stub.stream_url:
            if self.link_is_stale(stub):
                self.schedule_refresh(sid, "play after 24h")
                return {"action": "refreshing", "stub_id": sid}
            return {"action": "already_active", "stub_id": sid}
        task = self._spawn(self.activate(sid, "play"))
        return await asyncio.shield(task)


_instance: Optional[LinkResolver] = None


def set_instance(r: LinkResolver) -> None:
    global _instance
    _instance = r


def get_instance() -> Optional[LinkResolver]:
    return _instance
