"""
gateway/probe_cache.py
~~~~~~~~~~~~~~~~~~~~~~
Persistent head/tail block cache — the Plex side of the API saver.

Plex's scanner, "Analyze", intro/credit detection and thumbnail passes read
the START and END of a media file (container headers, cues/seek index,
duration) over and over — warpbox calls this the ffprobe avalanche. Without
a cache each of those passes means CDN traffic, and once a CDN URL has
expired, a fresh requestdl API call per file. It also looks like "access" to
TorBox, which resets inactivity timers (the retention trap).

Blocks that fall inside the first `probe_cache_head_mb` or the last
`probe_cache_tail_mb` of a file are written to disk the first time they're
fetched and served from disk forever after. Keys are the stable torbox://
ref, so they survive CDN URL rotation. Real playback of the middle of the
file is unaffected.
"""
from __future__ import annotations

import hashlib
import logging
import os
import threading
from pathlib import Path
from typing import Optional

from . import torbox_guard as guard

log = logging.getLogger("aiogateway.probecache")
_lock = threading.Lock()


def _enabled() -> bool:
    return bool(guard._setting("probe_cache_enabled", True))


def _root() -> Path:
    return guard.data_dir() / "probe_cache"


def _path(ref: str, block_idx: int) -> Path:
    digest = hashlib.sha1(ref.encode()).hexdigest()
    return _root() / digest[:2] / digest / f"{block_idx}.blk"


def wants(block_idx: int, block_size: int, file_size: Optional[int]) -> bool:
    if not _enabled():
        return False
    head = float(guard._setting("probe_cache_head_mb", 16)) * 1024 * 1024
    tail = float(guard._setting("probe_cache_tail_mb", 16)) * 1024 * 1024
    start = block_idx * block_size
    if start < head:
        return True
    if file_size and start + block_size > file_size - tail:
        return True
    return False


def get(ref: str, block_idx: int) -> Optional[bytes]:
    if not _enabled():
        return None
    p = _path(ref, block_idx)
    try:
        data = p.read_bytes()
    except FileNotFoundError:
        return None
    except OSError as exc:
        log.debug("probe cache read failed %s: %s", p, exc)
        return None
    try:
        os.utime(p, None)   # LRU by mtime
    except OSError:
        pass
    guard.stats.inc("probe_cache_hits")
    return data


def put(ref: str, block_idx: int, data: bytes):
    if not _enabled() or not data:
        return
    p = _path(ref, block_idx)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        tmp.write_bytes(data)
        tmp.replace(p)
        guard.stats.inc("probe_cache_writes")
    except OSError as exc:
        log.debug("probe cache write failed %s: %s", p, exc)


def drop(ref: str):
    digest = hashlib.sha1(ref.encode()).hexdigest()
    d = _root() / digest[:2] / digest
    if d.exists():
        for f in d.iterdir():
            try:
                f.unlink()
            except OSError:
                pass
        try:
            d.rmdir()
        except OSError:
            pass


def _files():
    root = _root()
    if not root.exists():
        return []
    out = []
    for p in root.rglob("*.blk"):
        try:
            st = p.stat()
            out.append((st.st_mtime, st.st_size, p))
        except OSError:
            pass
    return out


def usage() -> dict:
    files = _files()
    return {"files": len(files), "mb": round(sum(f[1] for f in files) / 1024 / 1024, 1),
            "max_mb": guard._setting("probe_cache_max_mb", 4096)}


def evict():
    """Trim to probe_cache_max_mb, oldest-access first."""
    with _lock:
        limit = float(guard._setting("probe_cache_max_mb", 4096)) * 1024 * 1024
        files = _files()
        total = sum(f[1] for f in files)
        if total <= limit:
            return
        files.sort()
        removed = 0
        for _, size, p in files:
            if total <= limit * 0.9:
                break
            try:
                p.unlink()
                total -= size
                removed += 1
            except OSError:
                pass
        log.info("Probe cache evicted %d block(s)", removed)
