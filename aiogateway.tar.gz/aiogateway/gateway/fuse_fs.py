"""
gateway/fuse_fs.py
~~~~~~~~~~~~~~~~~~
Virtual FUSE filesystem for AIOGateway.

Presents a read-only directory tree at FUSE_MOUNTPOINT:

  <mountpoint>/
    Movies/   <Title (Year)>/<Title (Year)>.mkv
    Movies4K/ <Title (Year)>/<Title (Year)>.mkv
    Series/   <Show (Year)>/Season NN/SXXEYY.mkv
    Series4K/ <Show (Year)>/Season NN/SXXEYY.mkv

No physical files are ever written to disk. The directory tree is built
entirely from StubManager's in-memory stub registry.

read() behaviour:
  - Stub PLACEHOLDER/RESOLVING/ERROR  → serves the appropriate static
    stub .mkv bytes (hd.mkv or 4k.mkv from the stubs/ directory)
  - Stub ACTIVE (stream_url resolved)  → streams from CDN via HTTP range
    requests with an in-memory LRU block cache

This is the same architecture as alldebrid-web's AllDebridFS — a fully
virtual filesystem backed by a metadata registry, not by real files.
"""
from __future__ import annotations

import errno
import hashlib
import logging
import os
import stat
import threading
import time
from collections import OrderedDict
from pathlib import Path
from typing import TYPE_CHECKING, Optional

import requests

if TYPE_CHECKING:
    from .stub_manager import StubManager

log = logging.getLogger("aiogateway.fuse")

def _safe_name(name: str) -> str:
    """Strip characters that break Plex / filesystem paths."""
    import re
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', '', name).strip('. ')

# ── Try to import fusepy ───────────────────────────────────────────────────────
try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — FUSE mount unavailable")

# ── Tuning ────────────────────────────────────────────────────────────────────
_RA_MB        = int(os.environ.get("FUSE_BLOCK_MB",      "8"))
_CACHE_N      = int(os.environ.get("FUSE_CACHE_BLOCKS", "64"))
BLOCK_SIZE    = _RA_MB * 1024 * 1024

READ_TIMEOUT      = int(os.environ.get("FUSE_READ_TIMEOUT", "15"))
READ_MAX_ATTEMPTS = 5
READ_BACKOFF_BASE = 0.5
READ_BACKOFF_CAP  = 4.0

ATTR_TIMEOUT  = float(os.environ.get("FUSE_ATTR_TIMEOUT",  "30"))
ENTRY_TIMEOUT = float(os.environ.get("FUSE_ENTRY_TIMEOUT", "30"))

_PREFETCH_AHEAD = int(os.environ.get("FUSE_PREFETCH_AHEAD", "4"))

# ── Stub bytes source (same stubs/ dir already in the project) ────────────────
_STUBS_DIR = Path(__file__).parent.parent / "stubs"
_STUB_HD   = _STUBS_DIR / "hd.mkv"
_STUB_4K   = _STUBS_DIR / "4k.mkv"

def _stub_bytes(quality_value: str) -> bytes:
    """Return static stub MKV bytes for the given quality ('hd' or '4k')."""
    path = _STUB_4K if quality_value == "4k" else _STUB_HD
    if path.exists():
        return path.read_bytes()
    fallback = _STUB_HD if quality_value == "4k" else _STUB_4K
    if fallback.exists():
        return fallback.read_bytes()
    # Last-resort: minimal EBML header
    ebml = bytes([
        0x1A,0x45,0xDF,0xA3,0x9F,
        0x42,0x86,0x81,0x01,0x42,0xF7,0x81,0x01,
        0x42,0xF2,0x81,0x04,0x42,0xF3,0x81,0x08,
        0x42,0x82,0x88,
        0x6D,0x61,0x74,0x72,0x6F,0x73,0x6B,0x61,
        0x42,0x87,0x81,0x04,0x42,0x85,0x81,0x02,
    ])
    segment = bytes([0x18,0x53,0x80,0x67,0x01,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF])
    return ebml + segment

# Pre-load stub bytes once at import time
_STUB_BYTES_HD: bytes = b""
_STUB_BYTES_4K: bytes = b""

def _ensure_stub_bytes():
    global _STUB_BYTES_HD, _STUB_BYTES_4K
    if not _STUB_BYTES_HD:
        _STUB_BYTES_HD = _stub_bytes("hd")
    if not _STUB_BYTES_4K:
        _STUB_BYTES_4K = _stub_bytes("4k")

# ── Folder constants ──────────────────────────────────────────────────────────
_TOP_DIRS = {"Movies", "Movies4K", "Series", "Series4K"}

# ── LRU in-memory block cache ─────────────────────────────────────────────────
class _BlockCache:
    def __init__(self, max_blocks: int):
        self._max   = max_blocks
        self._lock  = threading.Lock()
        self._store: OrderedDict = OrderedDict()

    def get(self, key) -> Optional[bytes]:
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        return None

    def put(self, key, data: bytes):
        with self._lock:
            self._store[key] = data
            self._store.move_to_end(key)
            while len(self._store) > self._max:
                self._store.popitem(last=False)

    def invalidate(self, url: str):
        with self._lock:
            for k in [k for k in self._store if k[0] == url]:
                del self._store[k]

_block_cache = _BlockCache(_CACHE_N)


# ── Virtual filesystem ────────────────────────────────────────────────────────
class AIOGatewayFS(Operations):
    """
    Virtual read-only FUSE filesystem backed by StubManager.

    Directory structure:
      /Movies/<Title (Year)>/<Title (Year)>.mkv
      /Movies4K/...
      /Series/<Show (Year)>/Season NN/SXXEYY.mkv
      /Series4K/...

    read() intercepts file access:
      - unresolved stub  → static stub MKV bytes
      - resolved stub    → HTTP range request from stream_url (CDN)
    """

    def __init__(self, stubs: "StubManager"):
        self._stubs = stubs
        self._now   = time.time()
        self._lock  = threading.Lock()

    # ── Path parsing ──────────────────────────────────────────────────────────

    def _stub_for_path(self, path: str):
        """
        Resolve a FUSE path to a Stub, or None.

        Expected path forms:
          /Movies/<folder>/<file>.mkv          (movie)
          /Series/<folder>/Season NN/<ep>.mkv  (series)
          /Movies4K/...  /Series4K/...
        """
        for stub in self._stubs.all():
            if self._stub_path(stub) == path:
                return stub
        return None

    def _stub_path(self, stub) -> str:
        """
        Derive the virtual FUSE path for a stub from its own fields.
        No dependency on abs_path or any real-root prefix.

        Movies:  /Movies/Title (Year)/Title (Year).mkv
        Movies4K:/Movies4K/Title (Year)/Title (Year).mkv
        Series:  /Series/Show (Year)/Season NN/SXXEYY.mkv
        Series4K:/Series4K/Show (Year)/Season NN/SXXEYY.mkv
        """
        from .models import MediaType, Quality

        is_4k    = stub.quality == Quality.UHD
        is_series = stub.media_type == MediaType.SERIES

        if is_series:
            top = "Series4K" if is_4k else "Series"
            show = stub.show_title or stub.title
            show = _safe_name(show)
            folder = f"{show} ({stub.year})" if stub.year else show
            season = stub.season or 1
            ep     = stub.episode or 1
            filename = f"S{season:02d}E{ep:02d}.mkv"
            return f"/{top}/{folder}/Season {season:02d}/{filename}"
        else:
            top = "Movies4K" if is_4k else "Movies"
            title = _safe_name(stub.title)
            folder = f"{title} ({stub.year})" if stub.year else title
            filename = f"{folder}.mkv"
            return f"/{top}/{folder}/{filename}"

    def _dir_stubs(self, top_dir: str):
        """Return all stubs whose virtual path starts with /<top_dir>/."""
        prefix = f"/{top_dir}/"
        return [s for s in self._stubs.all() if self._stub_path(s).startswith(prefix)]

    def _dir_contents(self, path: str):
        """
        Return the set of immediate child names under the virtual directory `path`.
        Used by readdir().
        """
        prefix = path.rstrip("/") + "/"
        children = set()
        for stub in self._stubs.all():
            sp = self._stub_path(stub)
            if sp.startswith(prefix):
                rest = sp[len(prefix):]
                # immediate child = everything up to the next /
                child = rest.split("/")[0]
                if child:
                    children.add(child)
        return children

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        try:
            return self._getattr_safe(path)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning("getattr(%s): %s", path, e)
            raise FuseOSError(errno.ENOENT)

    def _getattr_safe(self, path):
        now  = self._now
        base = {
            "st_uid": os.getuid(), "st_gid": os.getgid(),
            "st_atime": now, "st_mtime": now, "st_ctime": now,
            "st_nlink": 2,
        }

        # Root
        if path == "/":
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        # Top-level category dirs
        name = path.lstrip("/")
        if name in _TOP_DIRS:
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        # Is it a known stub file?
        stub = self._stub_for_path(path)
        if stub is not None:
            from .models import Quality, StubState
            _ensure_stub_bytes()
            if stub.state == StubState.ACTIVE and stub.stream_url:
                # Resolved — report actual stub file size (Plex will get CDN bytes on read)
                file_size = len(_STUB_BYTES_4K if stub.quality == Quality.UHD else _STUB_BYTES_HD)
            else:
                data = _STUB_BYTES_4K if stub.quality == Quality.UHD else _STUB_BYTES_HD
                file_size = len(data)
            return {**base,
                    "st_mode": stat.S_IFREG | 0o444,
                    "st_nlink": 1,
                    "st_size": file_size,
                    "st_mtime": stub.created_at,
                    "st_ctime": stub.created_at}

        # Is it a virtual directory (parent of one or more stub paths)?
        if self._dir_contents(path):
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        raise FuseOSError(errno.ENOENT)

    def readdir(self, path, fh):
        try:
            return self._readdir_safe(path)
        except Exception as e:
            log.error("readdir(%s): %s", path, e)
            return [".", ".."]

    def _readdir_safe(self, path):
        entries = [".", ".."]

        if path == "/":
            # Always show the four category dirs, even if empty
            return entries + list(_TOP_DIRS)

        name = path.lstrip("/")
        if name in _TOP_DIRS:
            # List show/movie folder names under this category
            entries += sorted(self._dir_contents(path))
            return entries

        # Intermediate or leaf directory — list immediate children
        children = self._dir_contents(path)
        entries += sorted(children)
        return entries

    def open(self, path, flags):
        stub = self._stub_for_path(path)
        if stub is None:
            raise FuseOSError(errno.ENOENT)
        return 0

    def release(self, path, fh):
        return 0

    def read(self, path, size, offset, fh):
        try:
            return self._read_safe(path, size, offset)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning("read(%s): %s", path, e, exc_info=True)
            raise FuseOSError(errno.EIO)

    def _read_safe(self, path, size, offset):
        from .models import Quality, StubState
        _ensure_stub_bytes()

        stub = self._stub_for_path(path)
        if stub is None:
            raise FuseOSError(errno.ENOENT)

        # If unresolved, wait for the webhook to call set_active().
        # Plex's read() and the webhook fire almost simultaneously — we give
        # the webhook up to FUSE_RESOLVE_TIMEOUT seconds to win the race
        # before falling back to stub bytes.
        if stub.state != StubState.ACTIVE or not stub.stream_url:
            if stub.state in (StubState.PLACEHOLDER, StubState.RESOLVING):
                ev = _get_resolve_event(stub.stub_id)
                log.info("[%s] read() waiting for resolution (up to %.0fs)…",
                         stub.stub_id[:8], RESOLVE_WAIT_TIMEOUT)
                ev.wait(timeout=RESOLVE_WAIT_TIMEOUT)

            # Check again after waiting
            if stub.state != StubState.ACTIVE or not stub.stream_url:
                log.info("[%s] serving stub bytes (not yet resolved)", stub.stub_id[:8])
                data = _STUB_BYTES_4K if stub.quality == Quality.UHD else _STUB_BYTES_HD
                return data[offset:offset + size]

        # Resolved — stream from CDN
        cdn_url = stub.stream_url
        headers = dict(stub.stream_headers or {})

        block_idx = offset // BLOCK_SIZE
        cached = _block_cache.get((cdn_url, block_idx))

        if cached is None:
            cached = self._fetch_block(cdn_url, block_idx, headers, stub)
            if cached is None:
                log.warning("FUSE read failed for %s block %d", path, block_idx)
                data = _STUB_BYTES_4K if stub.quality == Quality.UHD else _STUB_BYTES_HD
                return data[offset:offset + size]

        block_start  = block_idx * BLOCK_SIZE
        slice_offset = offset - block_start
        chunk = cached[slice_offset:slice_offset + size]

        # Prefetch next blocks
        if _PREFETCH_AHEAD > 0:
            for a in range(1, _PREFETCH_AHEAD + 1):
                nb = block_idx + a
                self._prefetch_block(cdn_url, nb, headers, stub)

        # Cross-block reads
        remaining = size - len(chunk)
        nb = block_idx + 1
        while remaining > 0:
            nc = _block_cache.get((cdn_url, nb))
            if nc is None:
                nc = self._fetch_block(cdn_url, nb, headers, stub)
                if nc is None:
                    break
            chunk    += nc[:remaining]
            remaining -= len(nc[:remaining])
            nb        += 1

        return chunk

    def _fetch_block(self, cdn_url: str, block_idx: int, headers: dict, stub) -> Optional[bytes]:
        start = block_idx * BLOCK_SIZE
        end   = start + BLOCK_SIZE - 1
        req_headers = {**headers, "Range": f"bytes={start}-{end}"}

        for attempt in range(READ_MAX_ATTEMPTS):
            try:
                r = requests.get(cdn_url, headers=req_headers,
                                 timeout=READ_TIMEOUT, stream=True)
                if r.status_code in (200, 206):
                    data = r.content
                    _block_cache.put((cdn_url, block_idx), data)
                    return data
                if r.status_code in (403, 410):
                    log.warning("[%s] CDN URL expired (%d) — marking for re-resolve",
                                stub.stub_id[:8], r.status_code)
                    # Signal the stub needs re-resolution on next playback
                    from .models import StubState
                    stub.state      = StubState.PLACEHOLDER
                    stub.stream_url = None
                    _block_cache.invalidate(cdn_url)
                    return None
                log.warning("[%s] CDN returned %d for block %d",
                            stub.stub_id[:8], r.status_code, block_idx)
            except requests.RequestException as e:
                log.warning("[%s] fetch block %d attempt %d: %s",
                            stub.stub_id[:8], block_idx, attempt, e)
            if attempt < READ_MAX_ATTEMPTS - 1:
                time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))
        return None

    def _prefetch_block(self, cdn_url: str, block_idx: int, headers: dict, stub):
        key = (cdn_url, block_idx)
        if _block_cache.get(key) is not None:
            return
        def _do():
            self._fetch_block(cdn_url, block_idx, headers, stub)
        t = threading.Thread(target=_do, daemon=True, name=f"fuse-prefetch-{block_idx}")
        t.start()

    # Read-only filesystem — reject all write operations
    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)


# ── Per-stub resolution events ────────────────────────────────────────────────
# When read() fires on a PLACEHOLDER stub it waits on this event rather than
# immediately serving stub bytes. set_active() signals the event so read()
# picks up the real CDN URL. Keyed by stub_id.
_resolve_events: dict[str, threading.Event] = {}
_resolve_events_lock = threading.Lock()

RESOLVE_WAIT_TIMEOUT = float(os.environ.get("FUSE_RESOLVE_TIMEOUT", "10"))

def _get_resolve_event(stub_id: str) -> threading.Event:
    with _resolve_events_lock:
        if stub_id not in _resolve_events:
            _resolve_events[stub_id] = threading.Event()
        return _resolve_events[stub_id]

def signal_resolved(stub_id: str):
    """Called by set_active() to wake any read() waiting on this stub."""
    with _resolve_events_lock:
        ev = _resolve_events.get(stub_id)
    if ev:
        ev.set()
_fs_instance: Optional[AIOGatewayFS] = None
_mount_thread: Optional[threading.Thread] = None


def mount(stubs: "StubManager", mountpoint: str) -> bool:
    """
    Mount the virtual AIOGateway filesystem at `mountpoint`.

    `mountpoint` should be the same absolute path on both host and container
    (e.g. /docker/aiogateway/mnt) so that :shared propagation works correctly.
    No backing directory is needed — the filesystem is entirely virtual.
    """
    global _fs_instance, _mount_thread

    if not FUSE_AVAILABLE:
        log.error("Cannot mount: fusepy / libfuse not available")
        return False

    os.makedirs(mountpoint, exist_ok=True)
    _fs_instance = AIOGatewayFS(stubs)

    log.info("Mounting virtual AIOGateway FS at %s (block=%dMB, cache=%d blocks)",
             mountpoint, _RA_MB, _CACHE_N)

    def _run():
        try:
            FUSE(
                _fs_instance, mountpoint,
                nothreads=False,
                foreground=True,
                allow_other=True,
                attr_timeout=ATTR_TIMEOUT,
                entry_timeout=ENTRY_TIMEOUT,
            )
        except Exception as exc:
            log.error("FUSE mount exited: %s", exc)

    _mount_thread = threading.Thread(target=_run, daemon=True, name="fuse-mount")
    _mount_thread.start()
    time.sleep(1.0)
    if not _mount_thread.is_alive():
        log.error("FUSE thread died — check /dev/fuse and cap_add: SYS_ADMIN")
        return False
    log.info("Virtual FUSE filesystem mounted at %s", mountpoint)
    return True


def unmount(mountpoint: str):
    """Unmount the FUSE filesystem. Safe to call multiple times."""
    import subprocess
    def _try(cmd):
        try:
            return subprocess.run(cmd, timeout=5, capture_output=True).returncode == 0
        except Exception:
            return False
    ok = (
        _try(["fusermount", "-u",  mountpoint]) or
        _try(["fusermount", "-uz", mountpoint]) or
        _try(["umount", mountpoint]) or
        _try(["umount", "-l", mountpoint])
    )
    if ok:
        log.info("Unmounted %s", mountpoint)
    else:
        log.warning("Could not unmount %s", mountpoint)


def invalidate_stub(stub_id: str):
    """Call after a stub's stream_url changes so cached CDN blocks are dropped."""
    if _fs_instance is None:
        return
    # Find the stub and invalidate its CDN URL blocks
    stub = _fs_instance._stubs.get(stub_id)
    if stub and stub.stream_url:
        _block_cache.invalidate(stub.stream_url)
