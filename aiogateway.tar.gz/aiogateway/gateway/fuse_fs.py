"""
gateway/fuse_fs.py
~~~~~~~~~~~~~~~~~~
Virtual FUSE filesystem for AIOGateway.

Presents a read-only directory tree at FUSE_MOUNTPOINT:

  <mountpoint>/
    Movies/   <Title (Year)>/<Title (Year)>.mkv
    Movies4K/ <Title (Year)>/<Title (Year)>.mkv
    Series/   <Show (Year)>/Season NN/SXXEYY.mkv
    Series4K/ <Show (Year)>/Season NN/SXXEYY.mkv

No physical files are ever written to disk. The directory tree is built
entirely from StubManager's in-memory stub registry.

read() behaviour:
  - Stub PLACEHOLDER/RESOLVING/ERROR  → serves the appropriate static
    stub .mkv bytes (hd.mkv or 4k.mkv from the stubs/ directory)
  - Stub ACTIVE (stream_url resolved)  → streams from CDN via HTTP range
    requests with an in-memory LRU block cache

This is the same architecture as alldebrid-web's AllDebridFS — a fully
virtual filesystem backed by a metadata registry, not by real files.
"""
from __future__ import annotations

import errno
import hashlib
import logging
import os
import stat
import threading
import time
from collections import OrderedDict
from pathlib import Path
from typing import TYPE_CHECKING, Optional

import requests

if TYPE_CHECKING:
    from .stub_manager import StubManager
    from .aiostreams_client import AIOStreamsClient

log = logging.getLogger("aiogateway.fuse")

def _safe_name(name: str) -> str:
    """Strip characters that break Plex / filesystem paths."""
    import re
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', '', name).strip('. ')

# ── Try to import fusepy ───────────────────────────────────────────────────────
try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — FUSE mount unavailable")

# ── Tuning ────────────────────────────────────────────────────────────────────
_RA_MB        = int(os.environ.get("FUSE_BLOCK_MB",      "8"))
_CACHE_N      = int(os.environ.get("FUSE_CACHE_BLOCKS", "64"))
BLOCK_SIZE    = _RA_MB * 1024 * 1024

READ_TIMEOUT      = int(os.environ.get("FUSE_READ_TIMEOUT", "15"))
READ_MAX_ATTEMPTS = 5
READ_BACKOFF_BASE = 0.5
READ_BACKOFF_CAP  = 4.0

ATTR_TIMEOUT  = float(os.environ.get("FUSE_ATTR_TIMEOUT",  "30"))
ENTRY_TIMEOUT = float(os.environ.get("FUSE_ENTRY_TIMEOUT", "30"))

_PREFETCH_AHEAD = int(os.environ.get("FUSE_PREFETCH_AHEAD", "4"))

# ── Stub bytes source (same stubs/ dir already in the project) ────────────────
_STUBS_DIR = Path(__file__).parent.parent / "stubs"
_STUB_HD   = _STUBS_DIR / "hd.mkv"
_STUB_4K   = _STUBS_DIR / "4k.mkv"

def _stub_bytes(quality_value: str) -> bytes:
    """Return static stub MKV bytes for the given quality ('hd' or '4k')."""
    path = _STUB_4K if quality_value == "4k" else _STUB_HD
    if path.exists():
        return path.read_bytes()
    fallback = _STUB_HD if quality_value == "4k" else _STUB_4K
    if fallback.exists():
        return fallback.read_bytes()
    # Last-resort: minimal EBML header
    ebml = bytes([
        0x1A,0x45,0xDF,0xA3,0x9F,
        0x42,0x86,0x81,0x01,0x42,0xF7,0x81,0x01,
        0x42,0xF2,0x81,0x04,0x42,0xF3,0x81,0x08,
        0x42,0x82,0x88,
        0x6D,0x61,0x74,0x72,0x6F,0x73,0x6B,0x61,
        0x42,0x87,0x81,0x04,0x42,0x85,0x81,0x02,
    ])
    segment = bytes([0x18,0x53,0x80,0x67,0x01,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF])
    return ebml + segment

# Pre-load stub bytes once at import time
_STUB_BYTES_HD: bytes = b""
_STUB_BYTES_4K: bytes = b""

def _ensure_stub_bytes():
    global _STUB_BYTES_HD, _STUB_BYTES_4K
    if not _STUB_BYTES_HD:
        _STUB_BYTES_HD = _stub_bytes("hd")
    if not _STUB_BYTES_4K:
        _STUB_BYTES_4K = _stub_bytes("4k")

# ── Folder constants ──────────────────────────────────────────────────────────
_TOP_DIRS = {"Movies", "Movies4K", "Series", "Series4K"}

# ── LRU in-memory block cache ─────────────────────────────────────────────────
class _BlockCache:
    def __init__(self, max_blocks: int):
        self._max   = max_blocks
        self._lock  = threading.Lock()
        self._store: OrderedDict = OrderedDict()

    def get(self, key) -> Optional[bytes]:
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        return None

    def put(self, key, data: bytes):
        with self._lock:
            self._store[key] = data
            self._store.move_to_end(key)
            while len(self._store) > self._max:
                self._store.popitem(last=False)

    def invalidate(self, url: str):
        with self._lock:
            for k in [k for k in self._store if k[0] == url]:
                del self._store[k]

# ── Shared HTTP session with bounded connection pool ───────────────────────────
# A fresh requests.get() per block opens a brand new TCP+TLS connection every
# time with no pooling and no cap — under prefetch/seek load this exhausts the
# process's open file descriptor limit very quickly (each socket is an FD).
# A single shared Session with a bounded pool reuses connections and caps how
# many can be open at once.
#
# CRITICAL: pool_maxsize alone does NOT cap connections — by default urllib3
# just stops *reusing* pooled connections once the pool is full and silently
# opens new ones outside the pool instead (with a "Connection pool is full,
# discarding connection" warning). block=True makes it actually wait for a
# free slot instead, which is the real enforcement mechanism.
_POOL_CONNECTIONS = int(os.environ.get("FUSE_POOL_CONNECTIONS", "10"))
_POOL_MAXSIZE     = int(os.environ.get("FUSE_POOL_MAXSIZE", "20"))

_http_session = requests.Session()
_http_adapter = requests.adapters.HTTPAdapter(
    pool_connections=_POOL_CONNECTIONS,
    pool_maxsize=_POOL_MAXSIZE,
    max_retries=0,   # we do our own retry/backoff loop
    pool_block=True, # actually enforce pool_maxsize instead of overflowing it
)
_http_session.mount("https://", _http_adapter)
_http_session.mount("http://", _http_adapter)

# Caps how many blocks can be in-flight (fetching or prefetching) at once,
# independent of the connection pool, so a burst of seeks/prefetches can't
# spawn unbounded concurrent threads each holding a connection.
_inflight_sem = threading.Semaphore(int(os.environ.get("FUSE_MAX_INFLIGHT", "12")))


# Dedup: prevents multiple prefetch threads from fetching the same block
# concurrently (e.g. if read() and the prefetch loop both target it).
_inflight_prefetch: set = set()
_inflight_prefetch_lock = threading.Lock()

# Circuit breaker: when we detect FD exhaustion (EMFILE), pause ALL new
# prefetch requests for a cooldown window. Reads still happen (Plex needs
# them to keep playing) but speculative prefetching — which is what turns a
# normal single connection error into a multiplying storm — stops until FDs
# recover. This is what actually breaks the "Too many open files" cascade:
# without it, every failed prefetch retry just spawns more failed attempts.
_prefetch_paused_until: float = 0.0
_prefetch_pause_lock = threading.Lock()

def _pause_prefetch(seconds: float):
    global _prefetch_paused_until
    with _prefetch_pause_lock:
        _prefetch_paused_until = max(_prefetch_paused_until, time.time() + seconds)

def _prefetch_is_paused() -> bool:
    with _prefetch_pause_lock:
        return time.time() < _prefetch_paused_until


_block_cache = _BlockCache(_CACHE_N)


# ── Virtual filesystem ────────────────────────────────────────────────────────
class AIOGatewayFS(Operations):
    """
    Virtual read-only FUSE filesystem backed by StubManager.

    Resolution (real AIOStreams query + CDN probing) is NEVER triggered by
    open() or read() — only by the Plex webhook (media.play/media.resume,
    see webhook/handler.py). This was a hard lesson: both open()-triggered
    and read-pattern-heuristic-triggered resolution were tried and both
    converted stubs to real files without anyone pressing play, because
    Plex's library scanner legitimately calls open() + multiple reads on a
    newly added file during first-time deep analysis (codec/duration
    fingerprinting, thumbnail generation) — a pattern indistinguishable at
    the FUSE layer from genuine playback starting. The webhook is the one
    truly unambiguous "the user pressed play" signal, so it's the only
    thing allowed to start resolution. read() just waits if a webhook-
    triggered resolution happens to already be in progress, and otherwise
    always serves stub bytes immediately, regardless of how many times or
    how quickly it's called.
    """

    def __init__(self, stubs: "StubManager", client: "AIOStreamsClient"):
        self._stubs  = stubs
        self._client = client
        self._now    = time.time()
        self._lock   = threading.Lock()

        # ── Path index cache ──────────────────────────────────────────────
        # getattr()/readdir() used to do a full O(N) scan over every stub
        # (formatting + regex-sanitizing a path string for each one) on
        # EVERY call. FUSE calls readdir() once per folder listing and then
        # getattr() once per entry in that folder, so listing a folder with
        # M items cost O(M*N) full-library scans — with a large library
        # this is what made Plex's directory listing hang.
        #
        # Fix: cache a path->stub / dir->children index, and only rebuild
        # it (the expensive part, with string formatting/regex) when the
        # library has actually changed. Change-detection itself uses a
        # cheap fingerprint (plain attribute reads, no formatting) so it's
        # safe to check on every single FUSE call.
        self._index_lock        = threading.Lock()
        self._index_fingerprint = None
        self._path_to_stub: dict = {}
        self._dir_children: dict = {}

    def _index_fingerprint_now(self):
        # Cheap: just attribute reads, no string building. Changes iff a
        # stub is added/removed, or its resolved-state (which is the only
        # thing that alters its virtual path) changes.
        return tuple(
            (s.stub_id, s.state.value, s.stream_url is not None)
            for s in self._stubs.all()
        )

    def _ensure_index(self):
        fp = self._index_fingerprint_now()
        if fp == self._index_fingerprint:
            return
        with self._index_lock:
            fp = self._index_fingerprint_now()
            if fp == self._index_fingerprint:
                return  # another thread already rebuilt it
            path_to_stub: dict = {}
            dir_children: dict = {}

            def _register_dirs(full_path: str):
                parts = full_path.strip("/").split("/")
                for i in range(1, len(parts)):
                    parent = "/" + "/".join(parts[:i])
                    dir_children.setdefault(parent, set()).add(parts[i])

            for stub in self._stubs.all():
                for resolved in (True, False):
                    p = self._build_path_for_state(stub, resolved=resolved)
                    path_to_stub[p] = stub
                    _register_dirs(p)

            self._path_to_stub    = path_to_stub
            self._dir_children    = dir_children
            self._index_fingerprint = fp

    # ── Path parsing ──────────────────────────────────────────────────────────

    def _stub_for_path(self, path: str):
        """
        Resolve a FUSE path to a Stub, or None.

        Expected path forms:
          /Movies/<folder>/<file>.mkv          (movie)
          /Series/<folder>/Season NN/<ep>.mkv  (series)
          /Movies4K/...  /Series4K/...

        Once a stub resolves, _stub_path() starts returning a new filename
        (with a " - Ready" suffix). A Plex session that already opened the
        OLD path needs that path to keep resolving to the same stub for the
        lifetime of its open file handle — otherwise read() on the old path
        would 404. So this matches both the resolved and unresolved variants
        of each stub's path, regardless of its current actual state.
        """
        self._ensure_index()
        return self._path_to_stub.get(path)

    def _build_path_for_state(self, stub, resolved: bool) -> str:
        from .models import MediaType, Quality

        is_4k     = stub.quality == Quality.UHD
        is_series = stub.media_type == MediaType.SERIES
        suffix    = " - Ready" if resolved else ""

        if is_series:
            top = "Series4K" if is_4k else "Series"
            show = stub.show_title or stub.title
            show = _safe_name(show)
            folder = f"{show} ({stub.year})" if stub.year else show
            season = stub.season or 1
            ep     = stub.episode or 1
            filename = f"S{season:02d}E{ep:02d}{suffix}.mkv"
            return f"/{top}/{folder}/Season {season:02d}/{filename}"
        else:
            top = "Movies4K" if is_4k else "Movies"
            title = _safe_name(stub.title)
            folder = f"{title} ({stub.year})" if stub.year else title
            filename = f"{folder}{suffix}.mkv"
            return f"/{top}/{folder}/{filename}"

    def _stub_path(self, stub) -> str:
        """
        Derive the virtual FUSE path for a stub from its own fields.

        Once a stub resolves (ACTIVE + stream_url), its filename gains a
        ' - Ready' suffix. This forces Plex to see a brand new file on its
        next library scan, rather than relying on it noticing an existing
        file's size/mtime changed mid-session (which Plex does not reliably
        pick up while a session has the old file open).

        Movies:  /Movies/Title (Year)/Title (Year).mkv
                 /Movies/Title (Year)/Title (Year) - Ready.mkv   (resolved)
        Series:  /Series/Show (Year)/Season NN/SXXEYY.mkv
                 /Series/Show (Year)/Season NN/SXXEYY - Ready.mkv (resolved)
        """
        from .models import StubState
        resolved = stub.state == StubState.ACTIVE and bool(stub.stream_url)
        return self._build_path_for_state(stub, resolved=resolved)

    def _resolved_folder(self, stub) -> str:
        """
        Real filesystem path (mountpoint + virtual dir) of the folder
        containing this stub's resolved file. Used to trigger a scoped
        Plex partial scan right after resolution.
        """
        virtual_path = self._build_path_for_state(stub, resolved=True)
        virtual_dir  = "/".join(virtual_path.split("/")[:-1])
        mountpoint   = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt").rstrip("/")
        return f"{mountpoint}{virtual_dir}"

    def _dir_stubs(self, top_dir: str):
        """Return all stubs whose virtual path starts with /<top_dir>/."""
        prefix = f"/{top_dir}/"
        return [s for s in self._stubs.all() if self._stub_path(s).startswith(prefix)]

    def _dir_contents(self, path: str):
        """
        Return the set of immediate child names under the virtual directory `path`.
        Used by readdir().
        """
        self._ensure_index()
        return self._dir_children.get(path.rstrip("/") or "/", set())

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        try:
            return self._getattr_safe(path)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning("getattr(%s): %s", path, e)
            raise FuseOSError(errno.ENOENT)

    def _getattr_safe(self, path):
        now  = self._now
        base = {
            "st_uid": os.getuid(), "st_gid": os.getgid(),
            "st_atime": now, "st_mtime": now, "st_ctime": now,
            "st_nlink": 2,
        }

        # Root
        if path == "/":
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        # Top-level category dirs
        name = path.lstrip("/")
        if name in _TOP_DIRS:
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        # Is it a known stub file?
        stub = self._stub_for_path(path)
        if stub is not None:
            from .models import Quality, StubState
            _ensure_stub_bytes()

            if stub.stream_size:
                # Real size known (set at add time or on resolution) —
                # always report it so Plex never thinks this is a short file
                file_size = stub.stream_size
            else:
                # Size not yet known — report a large placeholder so Plex
                # doesn't cap reads at stub length. 50GB covers any movie.
                file_size = 50 * 1024 * 1024 * 1024

            mtime = stub.resolved_at if stub.resolved_at else stub.created_at
            return {**base,
                    "st_mode": stat.S_IFREG | 0o444,
                    "st_nlink": 1,
                    "st_size": file_size,
                    "st_mtime": mtime,
                    "st_ctime": mtime}

        # Is it a virtual directory (parent of one or more stub paths)?
        if self._dir_contents(path):
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        raise FuseOSError(errno.ENOENT)

    def readdir(self, path, fh):
        try:
            return self._readdir_safe(path)
        except Exception as e:
            log.error("readdir(%s): %s", path, e)
            return [".", ".."]

    def _readdir_safe(self, path):
        entries = [".", ".."]

        if path == "/":
            # Always show the four category dirs, even if empty
            return entries + list(_TOP_DIRS)

        name = path.lstrip("/")
        if name in _TOP_DIRS:
            # List show/movie folder names under this category
            entries += sorted(self._dir_contents(path))
            return entries

        # Intermediate or leaf directory — list immediate children
        children = self._dir_contents(path)
        entries += sorted(children)
        return entries

    def open(self, path, flags):
        stub = self._stub_for_path(path)
        if stub is None:
            raise FuseOSError(errno.ENOENT)
        # Deliberately does NOT trigger resolution. Resolution only ever
        # happens via the Plex webhook — see the class docstring above for
        # why open()/read()-triggered resolution was tried and abandoned.
        return 0

    def release(self, path, fh):
        return 0

    def read(self, path, size, offset, fh):
        try:
            return self._read_safe(path, size, offset)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning("read(%s): %s", path, e, exc_info=True)
            raise FuseOSError(errno.EIO)

    def _read_safe(self, path, size, offset):
        from .models import StubState
        _ensure_stub_bytes()

        stub = self._stub_for_path(path)
        if stub is None:
            raise FuseOSError(errno.ENOENT)

        # read() NEVER triggers resolution. There is no read-pattern heuristic
        # that reliably distinguishes "Plex is playing this" from "Plex's
        # scanner is doing first-time deep analysis of a newly added file" —
        # the latter can legitimately issue several reads in quick succession
        # (fingerprinting codecs, duration, generating thumbnails), which is
        # indistinguishable at the FUSE layer from a real play starting. That
        # ambiguity is exactly what caused new stubs to resolve into real
        # files seconds after being added, with no one pressing play.
        #
        # Resolution is ONLY triggered by the Plex webhook (media.play /
        # media.resume — see webhook/handler.py), which is the one truly
        # unambiguous signal that a user actually pressed play. If a
        # resolution is already in progress (because the webhook just fired),
        # read() waits for it; otherwise it serves stub bytes immediately.
        if stub.state != StubState.ACTIVE or not stub.stream_url:
            if stub.state == StubState.RESOLVING:
                ev = _get_resolve_event(stub.stub_id)
                log.info("[%s] read() waiting for resolution (up to %.0fs)…",
                         stub.stub_id[:8], RESOLVE_WAIT_TIMEOUT)
                ev.wait(timeout=RESOLVE_WAIT_TIMEOUT)

            # Check again after waiting (or immediately, if we didn't wait)
            if stub.state != StubState.ACTIVE or not stub.stream_url:
                return self._serve_stub(stub, offset, size)

        # Resolved — stream from CDN
        cdn_url = stub.stream_url
        headers = dict(stub.stream_headers or {})

        # If we now know the real size and this read starts past it, this is
        # a genuine EOF — return empty bytes, not stub/zero padding, so Plex
        # (and the kernel) correctly treats it as end of file.
        if stub.stream_size and offset >= stub.stream_size:
            return b""

        block_idx = offset // BLOCK_SIZE
        cached = _block_cache.get((cdn_url, block_idx))

        if cached is None:
            cached = self._fetch_block(cdn_url, block_idx, headers, stub)
            if cached is None:
                # Re-check size — _fetch_block may have just corrected it via
                # a 416's Content-Range. If this read is now past EOF, return
                # empty bytes (real EOF) instead of stub/zero padding.
                if stub.stream_size and offset >= stub.stream_size:
                    return b""
                log.warning("FUSE read failed for %s block %d", path, block_idx)
                return self._serve_stub(stub, offset, size)

        block_start  = block_idx * BLOCK_SIZE
        slice_offset = offset - block_start
        chunk = cached[slice_offset:slice_offset + size]

        # Prefetch next blocks (but not past known EOF)
        if _PREFETCH_AHEAD > 0:
            for a in range(1, _PREFETCH_AHEAD + 1):
                nb = block_idx + a
                if stub.stream_size and nb * BLOCK_SIZE >= stub.stream_size:
                    break
                self._prefetch_block(cdn_url, nb, headers, stub)

        # Cross-block reads
        remaining = size - len(chunk)
        nb = block_idx + 1
        while remaining > 0:
            if stub.stream_size and nb * BLOCK_SIZE >= stub.stream_size:
                break   # real EOF — stop, don't pad
            nc = _block_cache.get((cdn_url, nb))
            if nc is None:
                nc = self._fetch_block(cdn_url, nb, headers, stub)
                if nc is None:
                    break
            chunk    += nc[:remaining]
            remaining -= len(nc[:remaining])
            nb        += 1

        return chunk

    def _serve_stub(self, stub, offset: int, size: int) -> bytes:
        """
        Serve bytes from the static stub MKV, zero-padded if the read goes
        past the stub's own length. This matches alldebrid-web's behaviour:
        Plex thinks the file is full-movie-sized (from getattr) and keeps
        reading — we serve the real stub MKV header bytes first, then zeros,
        so Plex doesn't stop or error out while waiting for resolution.
        """
        from .models import Quality
        data = _STUB_BYTES_4K if stub.quality == Quality.UHD else _STUB_BYTES_HD
        if offset >= len(data):
            # Past end of stub — return zeros
            return b"\x00" * size
        chunk = data[offset:offset + size]
        if len(chunk) < size:
            # Pad remainder with zeros
            chunk = chunk + b"\x00" * (size - len(chunk))
        return chunk

    def _parse_content_range_size(self, content_range: str) -> Optional[int]:
        """
        Parse the total size out of a Content-Range header, e.g.
        'bytes */13458973081' → 13458973081
        """
        if not content_range or "/" not in content_range:
            return None
        try:
            total = content_range.rsplit("/", 1)[1].strip()
            if total == "*":
                return None
            return int(total)
        except (ValueError, IndexError):
            return None

    def _fetch_block(self, cdn_url: str, block_idx: int, headers: dict, stub) -> Optional[bytes]:
        start = block_idx * BLOCK_SIZE
        end   = start + BLOCK_SIZE - 1
        req_headers = {**headers, "Range": f"bytes={start}-{end}"}

        # Bound total concurrent in-flight requests (reads + prefetches) so a
        # burst of seeks can't open unbounded sockets even with a pooled session.
        acquired = _inflight_sem.acquire(timeout=READ_TIMEOUT + 2)
        if not acquired:
            log.warning("[%s] block %d: too many in-flight requests, skipping",
                        stub.stub_id[:8], block_idx)
            return None

        try:
            for attempt in range(READ_MAX_ATTEMPTS):
                r = None
                try:
                    r = _http_session.get(cdn_url, headers=req_headers,
                                          timeout=READ_TIMEOUT, stream=True)
                    if r.status_code in (200, 206):
                        data = r.content
                        # Some debrid/CDN backends return 200 OK with a JSON
                        # or HTML error body instead of a proper 4xx status
                        # when a request is malformed (e.g. expired/invalid
                        # token embedded in the URL). Without validation,
                        # that error page gets cached and served to Plex as
                        # if it were real video bytes — which is exactly
                        # what produced "Invalid request sent to the debrid
                        # provider" appearing as playback content instead of
                        # a clean failure. Reject anything that doesn't look
                        # like real binary media data.
                        content_type = (r.headers.get("Content-Type") or "").lower()
                        looks_like_error_body = (
                            "json" in content_type or
                            "text/html" in content_type or
                            "text/plain" in content_type
                        )
                        # A real range response should be close to a full
                        # block (or the tail of the file). A response far
                        # smaller than the block we asked for — especially
                        # one that's suspiciously tiny — is far more likely
                        # to be an error message than legitimate video data,
                        # unless this is genuinely the last block of the file.
                        is_near_eof = bool(
                            stub.stream_size and
                            start + len(data) >= stub.stream_size - 1
                        )
                        suspiciously_small = len(data) < 4096 and not is_near_eof

                        if looks_like_error_body or suspiciously_small:
                            snippet = data[:300]
                            try:
                                snippet_text = snippet.decode("utf-8", errors="replace")
                            except Exception:
                                snippet_text = repr(snippet)
                            log.warning(
                                "[%s] block %d: rejected non-media response "
                                "(content-type=%r, size=%d) — body: %s",
                                stub.stub_id[:8], block_idx, content_type,
                                len(data), snippet_text[:300]
                            )
                            # Treat like an expired/bad link: force re-resolve
                            # on next play rather than caching/serving this.
                            from .models import StubState
                            stub.state      = StubState.PLACEHOLDER
                            stub.stream_url = None
                            _block_cache.invalidate(cdn_url)
                            self._stubs.persist_sidecar_sync(stub)
                            return None

                        _block_cache.put((cdn_url, block_idx), data)
                        return data
                    if r.status_code == 416:
                        # Requested range past end of file — deterministic EOF,
                        # not a transient error. Don't retry.
                        real_size = self._parse_content_range_size(r.headers.get("Content-Range", ""))
                        if real_size and real_size != stub.stream_size:
                            log.info("[%s] correcting reported size %s → %s after 416",
                                     stub.stub_id[:8], stub.stream_size, real_size)
                            stub.stream_size = real_size
                        return None
                    if r.status_code in (403, 410):
                        log.warning("[%s] CDN URL expired (%d) — marking for re-resolve",
                                    stub.stub_id[:8], r.status_code)
                        from .models import StubState
                        stub.state      = StubState.PLACEHOLDER
                        stub.stream_url = None
                        _block_cache.invalidate(cdn_url)
                        self._stubs.persist_sidecar_sync(stub)
                        return None
                    log.warning("[%s] CDN returned %d for block %d",
                                stub.stub_id[:8], r.status_code, block_idx)
                except requests.RequestException as e:
                    # "Too many open files" (EMFILE) needs different handling
                    # than a normal network blip: retrying immediately just
                    # makes it worse since FDs are already exhausted. Back off
                    # harder and skip prefetch entirely until pressure clears.
                    is_emfile = "Too many open files" in str(e) or "[Errno 24]" in str(e)
                    if is_emfile:
                        log.warning("[%s] block %d attempt %d: FD exhaustion (EMFILE) — "
                                   "backing off and pausing prefetch",
                                   stub.stub_id[:8], block_idx, attempt)
                        _pause_prefetch(seconds=5)
                        time.sleep(2.0)   # longer pause than normal backoff
                    else:
                        log.warning("[%s] fetch block %d attempt %d: %s",
                                    stub.stub_id[:8], block_idx, attempt, e)
                finally:
                    # Always release the connection back to the pool, on every
                    # path (success, error status, or exception). This is the
                    # leak that caused "Too many open files" — a streamed
                    # response left unclosed holds its socket open.
                    if r is not None:
                        r.close()
                if attempt < READ_MAX_ATTEMPTS - 1:
                    time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))
            return None
        finally:
            _inflight_sem.release()

    def _prefetch_block(self, cdn_url: str, block_idx: int, headers: dict, stub):
        if _prefetch_is_paused():
            return   # FD exhaustion circuit breaker active — skip speculative fetches
        key = (cdn_url, block_idx)
        if _block_cache.get(key) is not None:
            return
        with _inflight_prefetch_lock:
            if key in _inflight_prefetch:
                return   # already being fetched by another thread
            _inflight_prefetch.add(key)

        def _do():
            try:
                self._fetch_block(cdn_url, block_idx, headers, stub)
            finally:
                with _inflight_prefetch_lock:
                    _inflight_prefetch.discard(key)

        t = threading.Thread(target=_do, daemon=True, name=f"fuse-prefetch-{block_idx}")
        t.start()

    # Read-only filesystem — reject all write operations
    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)


# ── Per-stub resolution events ────────────────────────────────────────────────
# When read() fires on a PLACEHOLDER stub it waits on this event rather than
# immediately serving stub bytes. set_active() signals the event so read()
# picks up the real CDN URL. Keyed by stub_id.
_resolve_events: dict[str, threading.Event] = {}
_resolve_events_lock = threading.Lock()

RESOLVE_WAIT_TIMEOUT = float(os.environ.get("FUSE_RESOLVE_TIMEOUT", "15"))

def _get_resolve_event(stub_id: str) -> threading.Event:
    with _resolve_events_lock:
        if stub_id not in _resolve_events:
            _resolve_events[stub_id] = threading.Event()
        return _resolve_events[stub_id]

def signal_resolved(stub_id: str):
    """Called by set_active() to wake any read() waiting on this stub."""
    with _resolve_events_lock:
        ev = _resolve_events.get(stub_id)
    if ev:
        ev.set()
_fs_instance: Optional[AIOGatewayFS] = None
_mount_thread: Optional[threading.Thread] = None


def mount(stubs: "StubManager", client: "AIOStreamsClient", mountpoint: str) -> bool:
    """
    Mount the virtual AIOGateway filesystem at `mountpoint`.
    """
    global _fs_instance, _mount_thread

    if not FUSE_AVAILABLE:
        log.error("Cannot mount: fusepy / libfuse not available")
        return False

    os.makedirs(mountpoint, exist_ok=True)
    _fs_instance = AIOGatewayFS(stubs, client)

    log.info("Mounting virtual AIOGateway FS at %s (block=%dMB, cache=%d blocks)",
             mountpoint, _RA_MB, _CACHE_N)

    def _run():
        try:
            FUSE(
                _fs_instance, mountpoint,
                nothreads=False,
                foreground=True,
                allow_other=True,
                attr_timeout=ATTR_TIMEOUT,
                entry_timeout=ENTRY_TIMEOUT,
            )
        except Exception as exc:
            log.error("FUSE mount exited: %s", exc)

    _mount_thread = threading.Thread(target=_run, daemon=True, name="fuse-mount")
    _mount_thread.start()
    time.sleep(1.0)
    if not _mount_thread.is_alive():
        log.error("FUSE thread died — check /dev/fuse and cap_add: SYS_ADMIN")
        return False
    log.info("Virtual FUSE filesystem mounted at %s", mountpoint)
    return True


def unmount(mountpoint: str):
    """Unmount the FUSE filesystem. Safe to call multiple times."""
    import subprocess
    def _try(cmd):
        try:
            return subprocess.run(cmd, timeout=5, capture_output=True).returncode == 0
        except Exception:
            return False
    ok = (
        _try(["fusermount", "-u",  mountpoint]) or
        _try(["fusermount", "-uz", mountpoint]) or
        _try(["umount", mountpoint]) or
        _try(["umount", "-l", mountpoint])
    )
    if ok:
        log.info("Unmounted %s", mountpoint)
    else:
        log.warning("Could not unmount %s", mountpoint)


def invalidate_stub(stub_id: str):
    """Call after a stub's stream_url changes so cached CDN blocks are dropped."""
    if _fs_instance is None:
        return
    # Find the stub and invalidate its CDN URL blocks
    stub = _fs_instance._stubs.get(stub_id)
    if stub and stub.stream_url:
        _block_cache.invalidate(stub.stream_url)
