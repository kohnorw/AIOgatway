"""
gateway/fuse_fs.py
~~~~~~~~~~~~~~~~~~
Passthrough FUSE filesystem for AIOGateway.

Mounts at LIBRARY_ROOT but is backed by its own separate real directory
(LIBRARY_ROOT + "_real" by default, override with LIBRARY_REAL_ROOT).
All filesystem operations (mkdir, stat, readdir, write, etc.) pass
through to that real backing directory.

The ONLY thing we override is read() — when a stub has a resolved
stream URL we serve bytes from the CDN instead of the stub file bytes.
This means:
  - The stub manager can still write .mkv and .json files normally
    (it writes directly to the real backing directory)
  - Plex scans directories normally through the FUSE mountpoint
  - When Plex reads a stub file we transparently serve the real stream
  - Seeking works via HTTP range requests with an LRU block cache

Using a separate backing folder (instead of mounting FUSE on top of
itself) avoids the fragile "mount over a non-empty directory that is
also your own backing store" pattern — the mountpoint and the real
files are simply two different directories.
"""
from __future__ import annotations

import errno
import logging
import os
import stat
import threading
import time
from collections import OrderedDict
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from gateway.stub_manager import StubManager

log = logging.getLogger("aiogateway.fuse")

# ── Tuning ────────────────────────────────────────────────────────────────────
BLOCK_MB       = int(os.environ.get("FUSE_BLOCK_MB",      "8"))
CACHE_BLOCKS   = int(os.environ.get("FUSE_CACHE_BLOCKS",  "64"))
READ_TIMEOUT   = int(os.environ.get("FUSE_READ_TIMEOUT",  "15"))
PREFETCH_AHEAD = int(os.environ.get("FUSE_PREFETCH_AHEAD", "4"))
BLOCK_SIZE     = BLOCK_MB * 1024 * 1024
ATTR_TIMEOUT   = 30.0
ENTRY_TIMEOUT  = 30.0

try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except (ImportError, OSError):
    FUSE_AVAILABLE = False
    log.warning("fusepy / libfuse not available — FUSE disabled")
    class FuseOSError(OSError): pass
    class Operations: pass


# ── LRU block cache ───────────────────────────────────────────────────────────

class BlockCache:
    def __init__(self, max_blocks: int):
        self._max   = max_blocks
        self._store: OrderedDict = OrderedDict()
        self._lock  = threading.Lock()

    def get(self, key) -> Optional[bytes]:
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        return None

    def put(self, key, data: bytes):
        with self._lock:
            self._store[key] = data
            self._store.move_to_end(key)
            while len(self._store) > self._max:
                self._store.popitem(last=False)


_cache = BlockCache(CACHE_BLOCKS)


# ── Passthrough + stream-intercept FUSE ───────────────────────────────────────

class AIOGatewayFS(Operations):
    """
    Full passthrough filesystem — all ops delegate to the real filesystem.
    Only read() is intercepted to serve CDN bytes for resolved stubs.
    """

    def __init__(self, stubs: "StubManager", real_root: str):
        self._stubs    = stubs
        self._root     = real_root.rstrip("/")
        self._fh_map: dict[int, int] = {}   # fuse fh → real os fd
        self._fh_lock  = threading.Lock()
        self._fetching: set = set()
        self._fetch_lock = threading.Lock()

    def _real(self, path: str) -> str:
        """Convert FUSE virtual path to real filesystem path."""
        return self._root + path

    # ── Metadata ops — pure passthrough ──────────────────────────────────────

    def getattr(self, path, fh=None):
        real = self._real(path)
        try:
            st = os.lstat(real)
        except OSError as e:
            raise FuseOSError(e.errno)

        # If this is a resolved stub, report a large file size so Plex
        # knows it's a real full-length video (not a tiny placeholder)
        if path.endswith(".mkv"):
            stub = self._stubs.by_path(real)
            if stub and stub.stream_url:
                from gateway.models import StubState
                if stub.state == StubState.ACTIVE:
                    # 50 GB — larger than any real file, Plex won't care
                    size = 50 * 1024 * 1024 * 1024
                    result = dict((key, getattr(st, key)) for key in (
                        'st_atime','st_ctime','st_gid','st_mode',
                        'st_mtime','st_nlink','st_size','st_uid'
                    ))
                    result['st_size'] = size
                    return result

        return dict((key, getattr(st, key)) for key in (
            'st_atime','st_ctime','st_gid','st_mode',
            'st_mtime','st_nlink','st_size','st_uid'
        ))

    def readdir(self, path, fh):
        real = self._real(path)
        yield '.'
        yield '..'
        try:
            for entry in os.scandir(real):
                yield entry.name
        except OSError:
            pass

    def readlink(self, path):
        return os.readlink(self._real(path))

    def statfs(self, path):
        real = self._real(path)
        stv = os.statvfs(real)
        return dict((key, getattr(stv, key)) for key in (
            'f_bavail','f_bfree','f_blocks','f_bsize',
            'f_favail','f_ffree','f_files','f_flag',
            'f_frsize','f_namemax'
        ))

    # ── File ops — passthrough write, intercept read ──────────────────────────

    def open(self, path, flags):
        real = self._real(path)
        try:
            fd = os.open(real, flags)
        except OSError as e:
            raise FuseOSError(e.errno)
        with self._fh_lock:
            # Use fd itself as the fuse file handle
            self._fh_map[fd] = fd
        return fd

    def create(self, path, mode, fi=None):
        real = self._real(path)
        try:
            fd = os.open(real, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode)
        except OSError as e:
            raise FuseOSError(e.errno)
        with self._fh_lock:
            self._fh_map[fd] = fd
        return fd

    def read(self, path, size, offset, fh):
        """
        Intercept read for resolved stubs → serve CDN bytes.
        All other reads → delegate to real filesystem.
        """
        real = self._real(path)

        if path.endswith(".mkv"):
            stub = self._stubs.by_path(real)
            if stub and stub.stream_url:
                from gateway.models import StubState
                if stub.state == StubState.ACTIVE:
                    try:
                        return self._read_cdn(
                            stub.stream_url,
                            stub.stream_headers or {},
                            size, offset
                        )
                    except Exception as exc:
                        log.warning("CDN read failed for %s: %s", path, exc)
                        # Fall through to real file

        # Real file read
        try:
            with self._fh_lock:
                fd = self._fh_map.get(fh, fh)
            os.lseek(fd, offset, os.SEEK_SET)
            return os.read(fd, size)
        except OSError as e:
            raise FuseOSError(e.errno)

    def write(self, path, data, offset, fh):
        with self._fh_lock:
            fd = self._fh_map.get(fh, fh)
        try:
            os.lseek(fd, offset, os.SEEK_SET)
            return os.write(fd, data)
        except OSError as e:
            raise FuseOSError(e.errno)

    def truncate(self, path, length, fh=None):
        real = self._real(path)
        try:
            with open(real, 'r+b') as f:
                f.truncate(length)
        except OSError as e:
            raise FuseOSError(e.errno)

    def flush(self, path, fh):
        try:
            with self._fh_lock:
                fd = self._fh_map.get(fh, fh)
            os.fsync(fd)
        except OSError:
            pass
        return 0

    def release(self, path, fh):
        with self._fh_lock:
            fd = self._fh_map.pop(fh, fh)
        try:
            os.close(fd)
        except OSError:
            pass
        return 0

    def fsync(self, path, fdatasync, fh):
        return self.flush(path, fh)

    # ── Directory ops — passthrough ───────────────────────────────────────────

    def mkdir(self, path, mode):
        try:
            os.mkdir(self._real(path), mode)
        except OSError as e:
            raise FuseOSError(e.errno)

    def rmdir(self, path):
        try:
            os.rmdir(self._real(path))
        except OSError as e:
            raise FuseOSError(e.errno)

    def unlink(self, path):
        try:
            os.unlink(self._real(path))
        except OSError as e:
            raise FuseOSError(e.errno)

    def rename(self, old, new):
        try:
            os.rename(self._real(old), self._real(new))
        except OSError as e:
            raise FuseOSError(e.errno)

    def chmod(self, path, mode):
        try:
            os.chmod(self._real(path), mode)
        except OSError as e:
            raise FuseOSError(e.errno)

    def chown(self, path, uid, gid):
        try:
            os.chown(self._real(path), uid, gid)
        except OSError as e:
            raise FuseOSError(e.errno)

    def utimens(self, path, times=None):
        try:
            os.utime(self._real(path), times)
        except OSError as e:
            raise FuseOSError(e.errno)

    def symlink(self, target, source):
        try:
            os.symlink(target, self._real(source))
        except OSError as e:
            raise FuseOSError(e.errno)

    def link(self, target, source):
        try:
            os.link(self._real(target), self._real(source))
        except OSError as e:
            raise FuseOSError(e.errno)

    # ── CDN block read ────────────────────────────────────────────────────────

    def _read_cdn(self, url: str, headers: dict, size: int, offset: int) -> bytes:
        block_idx   = offset // BLOCK_SIZE
        block_start = block_idx * BLOCK_SIZE
        key         = (url, block_idx)

        data = _cache.get(key)
        if data is None:
            data = self._fetch_block(url, headers, block_idx)
            if data is None:
                raise FuseOSError(errno.EIO)

        chunk     = data[offset - block_start : offset - block_start + size]
        remaining = size - len(chunk)
        next_blk  = block_idx + 1

        while remaining > 0:
            nd = _cache.get((url, next_blk)) or self._fetch_block(url, headers, next_blk)
            if not nd:
                break
            chunk    += nd[:remaining]
            remaining -= len(nd[:remaining])
            next_blk  += 1

        for a in range(1, PREFETCH_AHEAD + 1):
            self._prefetch(url, headers, block_idx + a)

        return chunk

    def _fetch_block(self, url: str, headers: dict, block_idx: int) -> Optional[bytes]:
        import urllib.request
        key   = (url, block_idx)
        start = block_idx * BLOCK_SIZE
        end   = start + BLOCK_SIZE - 1
        h     = dict(headers or {})
        h["Range"] = f"bytes={start}-{end}"

        for attempt in range(3):
            try:
                req = urllib.request.Request(url, headers=h)
                with urllib.request.urlopen(req, timeout=READ_TIMEOUT) as resp:
                    data = resp.read()
                _cache.put(key, data)
                return data
            except Exception as exc:
                log.debug("Block %d fetch attempt %d: %s", block_idx, attempt + 1, exc)
                if attempt < 2:
                    time.sleep(0.5 * (attempt + 1))
        return None

    def _prefetch(self, url: str, headers: dict, block_idx: int):
        key = (url, block_idx)
        if _cache.get(key) is not None:
            return
        with self._fetch_lock:
            if key in self._fetching:
                return
            self._fetching.add(key)

        def _do():
            try:
                self._fetch_block(url, headers, block_idx)
            finally:
                with self._fetch_lock:
                    self._fetching.discard(key)

        threading.Thread(target=_do, daemon=True).start()


# ── Mount / unmount ───────────────────────────────────────────────────────────

_fs_instance: Optional[AIOGatewayFS] = None
_mount_thread: Optional[threading.Thread] = None


def mount(stubs: "StubManager", mountpoint: str, real_root: Optional[str] = None) -> bool:
    """
    Mount a passthrough FUSE filesystem at `mountpoint`, backed by the
    separate real directory `real_root`.

    Writes pass through to `real_root`; reads of resolved stubs are
    intercepted and served from CDN. `mountpoint` and `real_root` must
    be different directories — FUSE is never mounted on top of its own
    backing store.
    """
    global _fs_instance, _mount_thread

    if not FUSE_AVAILABLE:
        log.error("Cannot mount: fusepy / libfuse not available")
        return False

    if real_root is None:
        real_root = os.environ.get("LIBRARY_REAL_ROOT", mountpoint.rstrip("/") + "_real")

    mountpoint = mountpoint.rstrip("/")
    real_root  = real_root.rstrip("/")

    if os.path.abspath(real_root) == os.path.abspath(mountpoint):
        log.error("real_root must differ from mountpoint (got %s == %s)", real_root, mountpoint)
        return False

    os.makedirs(mountpoint, exist_ok=True)
    os.makedirs(real_root, exist_ok=True)
    _fs_instance = AIOGatewayFS(stubs, real_root)

    log.info("Mounting passthrough FUSE at %s (backed by %s, block=%dMB, cache=%d blocks)",
             mountpoint, real_root, BLOCK_MB, CACHE_BLOCKS)

    def _run():
        try:
            FUSE(
                _fs_instance, mountpoint,
                nothreads=False,
                foreground=True,
                allow_other=True,
                attr_timeout=ATTR_TIMEOUT,
                entry_timeout=ENTRY_TIMEOUT,
            )
        except Exception as exc:
            log.error("FUSE mount exited: %s", exc)

    _mount_thread = threading.Thread(target=_run, daemon=True, name="fuse-mount")
    _mount_thread.start()
    time.sleep(1.0)
    if not _mount_thread.is_alive():
        log.error("FUSE thread died — check /dev/fuse and cap_add: SYS_ADMIN")
        return False
    log.info("FUSE passthrough mounted at %s", mountpoint)
    return True


def unmount(mountpoint: str):
    """Unmount FUSE. Safe to call multiple times."""
    import subprocess

    def _is_mounted():
        try:
            with open("/proc/mounts") as f:
                return any(mountpoint in line for line in f)
        except Exception:
            return True

    if not _is_mounted():
        log.info("FUSE already unmounted: %s", mountpoint)
        return

    for cmd in (
        ["fusermount", "-u",  mountpoint],
        ["fusermount", "-uz", mountpoint],
        ["umount",     mountpoint],
        ["umount",     "-l",  mountpoint],
    ):
        try:
            r = subprocess.run(cmd, timeout=5, capture_output=True)
            if r.returncode == 0:
                log.info("Unmounted %s", mountpoint)
                return
        except Exception:
            pass
    log.warning("Could not unmount %s", mountpoint)
