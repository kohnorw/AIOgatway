"""
gateway/fuse_fs.py
~~~~~~~~~~~~~~~~~~
FUSE virtual filesystem for AIOGateway.

Mounts at LIBRARY_ROOT and exposes the same directory structure as the
stub files, but intercepts every read() and serves bytes from the
resolved AIOStreams CDN URL instead — with block-level LRU caching
and read-ahead prefetch (same approach as alldebrid-web).

Directory structure:
  /library/
    Movies/Title (Year)/Title (Year).mkv
    Movies4K/Title (Year)/Title (Year).mkv
    Series/Show (Year)/Season 01/S01E01.mkv
    Series4K/Show (Year)/Season 01/S01E01.mkv

How it works:
  1. getattr / readdir answer from the StubManager registry
  2. read() checks if the stub has a resolved stream URL
     - Not resolved → serve stub MKV bytes (placeholder content)
     - Resolved → fetch the requested byte range from the CDN URL,
       cache it in an LRU block cache, serve it to Plex
  3. Plex gets the real stream bytes, plays smoothly with seeking
"""
from __future__ import annotations

import errno
import logging
import os
import stat
import threading
import time
from collections import OrderedDict
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from gateway.stub_manager import StubManager

log = logging.getLogger("aiogateway.fuse")

# ── Tuning ────────────────────────────────────────────────────────────────────
BLOCK_MB      = int(os.environ.get("FUSE_BLOCK_MB",    "8"))
CACHE_BLOCKS  = int(os.environ.get("FUSE_CACHE_BLOCKS","64"))
READ_TIMEOUT  = int(os.environ.get("FUSE_READ_TIMEOUT","15"))
PREFETCH_AHEAD = int(os.environ.get("FUSE_PREFETCH_AHEAD", "4"))  # blocks to prefetch
BLOCK_SIZE    = BLOCK_MB * 1024 * 1024
ATTR_TIMEOUT  = 30.0
ENTRY_TIMEOUT = 30.0

# ── Stub file sizes reported to Plex ─────────────────────────────────────────
# When not yet resolved, we report the stub file size so Plex adds the item.
# Use a large fake size so Plex doesn't think it's too small to be real video.
FAKE_MOVIE_SIZE  = 8  * 1024 * 1024 * 1024   # 8 GB
FAKE_SERIES_SIZE = 2  * 1024 * 1024 * 1024   # 2 GB

try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except (ImportError, OSError):
    FUSE_AVAILABLE = False
    log.warning("fusepy / libfuse not available — FUSE mount disabled")

    # Provide stub classes so imports don't break
    class FuseOSError(OSError): pass
    class Operations: pass

# ── LRU block cache ───────────────────────────────────────────────────────────

class BlockCache:
    def __init__(self, max_blocks: int):
        self._max   = max_blocks
        self._store: OrderedDict = OrderedDict()
        self._lock  = threading.Lock()

    def get(self, key) -> Optional[bytes]:
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        return None

    def put(self, key, data: bytes):
        with self._lock:
            self._store[key] = data
            self._store.move_to_end(key)
            while len(self._store) > self._max:
                self._store.popitem(last=False)

    @property
    def size(self):
        with self._lock:
            return len(self._store)


_cache = BlockCache(CACHE_BLOCKS)

# ── FUSE filesystem ───────────────────────────────────────────────────────────

class AIOGatewayFS(Operations):
    """
    Read-only FUSE filesystem that serves stub file metadata from
    StubManager and real video bytes from resolved CDN URLs.
    """

    def __init__(self, stubs: "StubManager", stub_hd: bytes, stub_4k: bytes):
        self._stubs    = stubs
        self._stub_hd  = stub_hd   # bytes of stubs/hd.mkv
        self._stub_4k  = stub_4k   # bytes of stubs/4k.mkv
        self._now      = time.time()
        self._fh       = 0
        self._fh_lock  = threading.Lock()
        self._fetching: set = set()
        self._fetch_lock = threading.Lock()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _stub_by_path(self, path: str):
        """Find a Stub by FUSE path (e.g. /Series/Friends (1994)/Season 01/S01E01.mkv)"""
        # Normalise: strip leading slash, make absolute using library root
        library_root = os.environ.get("LIBRARY_ROOT", "/library")
        abs_path = os.path.join(library_root, path.lstrip("/"))
        return self._stubs.by_path(abs_path)

    def _stub_bytes(self, stub) -> bytes:
        """Return placeholder bytes for an unresolved stub."""
        from gateway.models import Quality
        return self._stub_4k if stub and stub.quality == Quality.UHD else self._stub_hd

    def _base_stat(self):
        return {
            "st_uid":   os.getuid(),
            "st_gid":   os.getgid(),
            "st_atime": self._now,
            "st_mtime": self._now,
            "st_ctime": self._now,
        }

    def _is_dir_path(self, path: str) -> bool:
        """True if path looks like a directory in our virtual tree."""
        parts = [p for p in path.split("/") if p]
        if not parts:
            return True  # root
        # Top-level folders
        if len(parts) == 1 and parts[0] in ("Movies","Movies4K","Series","Series4K"):
            return True
        # Title folder or Season folder — no .mkv extension
        if not parts[-1].endswith(".mkv"):
            return True
        return False

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        base = self._base_stat()

        # Root or known directory structure
        if self._is_dir_path(path):
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_nlink": 2, "st_size": 0}

        # File — look up in stub registry
        stub = self._stub_by_path(path)
        if stub is None:
            raise FuseOSError(errno.ENOENT)

        from gateway.models import StubState, Quality
        if stub.stream_url and stub.state == StubState.ACTIVE:
            # Report a large size so Plex knows it's a real movie/episode
            size = FAKE_SERIES_SIZE if "Series" in path else FAKE_MOVIE_SIZE
        else:
            # Report stub file size — enough for Plex to accept it
            size = len(self._stub_bytes(stub))

        return {**base, "st_mode": stat.S_IFREG | 0o444, "st_nlink": 1, "st_size": size}

    def readdir(self, path, fh):
        yield "."
        yield ".."

        parts = [p for p in path.split("/") if p]
        library_root = os.environ.get("LIBRARY_ROOT", "/library")

        # Root: yield top-level library folders
        if not parts:
            for d in ("Movies", "Movies4K", "Series", "Series4K"):
                yield d
            return

        # Yield real filesystem entries under the library root
        real_path = os.path.join(library_root, *parts)
        try:
            for entry in os.scandir(real_path):
                yield entry.name
        except (PermissionError, FileNotFoundError):
            pass

    def open(self, path, flags):
        stub = self._stub_by_path(path)
        if stub is None:
            raise FuseOSError(errno.ENOENT)
        with self._fh_lock:
            self._fh += 1
            return self._fh

    def read(self, path, size, offset, fh):
        stub = self._stub_by_path(path)
        if stub is None:
            raise FuseOSError(errno.ENOENT)

        from gateway.models import StubState

        # Not yet resolved — serve stub placeholder bytes
        if not stub.stream_url or stub.state != StubState.ACTIVE:
            data = self._stub_bytes(stub)
            return data[offset:offset + size]

        # Resolved — serve from CDN via block cache
        try:
            return self._read_cdn(stub.stream_url, stub.stream_headers or {}, size, offset)
        except Exception as exc:
            log.warning("FUSE read error for %s: %s", path, exc)
            # Fall back to stub bytes on CDN error
            data = self._stub_bytes(stub)
            chunk = data[offset:offset + size]
            return chunk + b"\x00" * max(0, size - len(chunk))

    def _read_cdn(self, url: str, headers: dict, size: int, offset: int) -> bytes:
        """Fetch the requested byte range from CDN, using LRU block cache."""
        import urllib.request

        block_idx  = offset // BLOCK_SIZE
        block_key  = (url, block_idx)
        block_start = block_idx * BLOCK_SIZE

        # Check cache
        cached = _cache.get(block_key)
        if cached is None:
            cached = self._fetch_block(url, headers, block_idx)
            if cached is None:
                raise FuseOSError(errno.EIO)

        # Slice the block to the requested offset/size
        slice_start = offset - block_start
        chunk = cached[slice_start:slice_start + size]

        # Cross-block read
        next_block = block_idx + 1
        remaining  = size - len(chunk)
        while remaining > 0:
            nb_key  = (url, next_block)
            nb_data = _cache.get(nb_key) or self._fetch_block(url, headers, next_block)
            if not nb_data:
                break
            chunk    += nb_data[:remaining]
            remaining -= len(nb_data[:remaining])
            next_block += 1

        # Prefetch next N blocks in background
        for a in range(1, PREFETCH_AHEAD + 1):
            self._prefetch(url, headers, block_idx + a)

        return chunk

    def _fetch_block(self, url: str, req_headers: dict, block_idx: int) -> Optional[bytes]:
        """HTTP range request for one block. Cached on success."""
        import urllib.request, socket

        key   = (url, block_idx)
        start = block_idx * BLOCK_SIZE
        end   = start + BLOCK_SIZE - 1

        h = dict(req_headers) if req_headers else {}
        h["Range"] = f"bytes={start}-{end}"

        for attempt in range(3):
            try:
                req  = urllib.request.Request(url, headers=h)
                with urllib.request.urlopen(req, timeout=READ_TIMEOUT) as resp:
                    data = resp.read()
                _cache.put(key, data)
                return data
            except Exception as exc:
                log.debug("Block fetch attempt %d failed: %s", attempt + 1, exc)
                if attempt < 2:
                    time.sleep(0.5 * (attempt + 1))
        return None

    def _prefetch(self, url: str, headers: dict, block_idx: int):
        key = (url, block_idx)
        if _cache.get(key) is not None:
            return
        with self._fetch_lock:
            if key in self._fetching:
                return
            self._fetching.add(key)

        def _do():
            try:
                self._fetch_block(url, headers, block_idx)
            finally:
                with self._fetch_lock:
                    self._fetching.discard(key)

        threading.Thread(target=_do, daemon=True).start()

    # Read-only filesystem
    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)


# ── Mount / unmount ───────────────────────────────────────────────────────────

_fs_instance: Optional[AIOGatewayFS] = None
_mount_thread: Optional[threading.Thread] = None


def mount(stubs: "StubManager", mountpoint: str) -> bool:
    """
    Mount the FUSE filesystem at mountpoint in a background thread.
    Returns True if started, False if FUSE is unavailable.
    """
    global _fs_instance, _mount_thread

    if not FUSE_AVAILABLE:
        log.error("Cannot mount: fusepy / libfuse not available")
        return False

    # Load real stub bytes
    base = Path(__file__).parent.parent / "stubs"
    stub_hd  = (base / "hd.mkv").read_bytes()  if (base / "hd.mkv").exists()  else b""
    stub_4k  = (base / "4k.mkv").read_bytes()  if (base / "4k.mkv").exists()  else stub_hd

    os.makedirs(mountpoint, exist_ok=True)
    _fs_instance = AIOGatewayFS(stubs, stub_hd, stub_4k)

    log.info("Mounting AIOGateway FS at %s (block=%dMB, cache=%d blocks)",
             mountpoint, BLOCK_MB, CACHE_BLOCKS)

    def _run():
        try:
            FUSE(
                _fs_instance, mountpoint,
                nothreads=False,
                foreground=False,   # run in background thread
                allow_other=True,
                nonempty=True,
                ro=True,
                attr_timeout=ATTR_TIMEOUT,
                entry_timeout=ENTRY_TIMEOUT,
            )
        except Exception as exc:
            log.error("FUSE mount error: %s", exc)

    _mount_thread = threading.Thread(target=_run, daemon=True, name="fuse-mount")
    _mount_thread.start()
    time.sleep(0.5)   # give FUSE a moment to initialise
    log.info("FUSE mount started")
    return True


def unmount(mountpoint: str):
    """Unmount the FUSE filesystem."""
    import subprocess
    for cmd in (["fusermount", "-u", mountpoint],
                ["fusermount", "-uz", mountpoint],
                ["umount", mountpoint]):
        try:
            r = subprocess.run(cmd, timeout=5, capture_output=True)
            if r.returncode == 0:
                log.info("Unmounted %s", mountpoint)
                return
        except Exception:
            pass
    log.warning("Could not unmount %s", mountpoint)
