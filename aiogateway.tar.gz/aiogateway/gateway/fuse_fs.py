"""
gateway/fuse_fs.py
~~~~~~~~~~~~~~~~~~
Virtual read-only FUSE filesystem for AIOGateway.

  <mountpoint>/
    Movies/   <Title (Year)>/<Title (Year)>.mkv
    Movies4K/ <Title (Year)>/<Title (Year)>.mkv
    Series/   <Show (Year)>/Season NN/SXXEYY.mkv
    Series4K/ <Show (Year)>/Season NN/SXXEYY.mkv

Every file listed here is a real file inside a torrent cached on TorBox —
there are no placeholder files. The tree is built from StubManager's bound
entries; nothing is written to disk except the probe cache.

read(): the entry's stable torbox:// ref is turned into a CDN URL through
the TorBox cache, byte ranges are fetched into an in-memory LRU block cache,
head/tail blocks are persisted to the probe cache, and expired links are
repaired in place. If a file really stops working, read() returns EIO (never
fake bytes) and the entry is queued for repair.
"""
from __future__ import annotations

import errno
import logging
import os
import stat
import threading
import time
from collections import OrderedDict
from typing import TYPE_CHECKING, Optional

import requests

if TYPE_CHECKING:
    from .stub_manager import StubManager
    from .torbox_client import TorBoxClient

log = logging.getLogger("aiogateway.fuse")

def _safe_name(name: str) -> str:
    """Strip characters that break Plex / filesystem paths."""
    import re
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', '', name).strip('. ')

# ── Try to import fusepy ───────────────────────────────────────────────────────
try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — FUSE mount unavailable")

# ── Tuning ────────────────────────────────────────────────────────────────────
_RA_MB        = int(os.environ.get("FUSE_BLOCK_MB",      "8"))
_CACHE_N      = int(os.environ.get("FUSE_CACHE_BLOCKS", "64"))
BLOCK_SIZE    = _RA_MB * 1024 * 1024

READ_TIMEOUT      = int(os.environ.get("FUSE_READ_TIMEOUT", "15"))
READ_MAX_ATTEMPTS = 5
READ_BACKOFF_BASE = 0.5
READ_BACKOFF_CAP  = 4.0

ATTR_TIMEOUT  = float(os.environ.get("FUSE_ATTR_TIMEOUT",  "30"))
ENTRY_TIMEOUT = float(os.environ.get("FUSE_ENTRY_TIMEOUT", "30"))

_PREFETCH_AHEAD = int(os.environ.get("FUSE_PREFETCH_AHEAD", "4"))

# ── Folder constants ──────────────────────────────────────────────────────────
_TOP_DIRS = {"Movies", "Movies4K", "Series", "Series4K"}

# ── LRU in-memory block cache ─────────────────────────────────────────────────
class _BlockCache:
    def __init__(self, max_blocks: int):
        self._max   = max_blocks
        self._lock  = threading.Lock()
        self._store: OrderedDict = OrderedDict()

    def get(self, key) -> Optional[bytes]:
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        return None

    def put(self, key, data: bytes):
        with self._lock:
            self._store[key] = data
            self._store.move_to_end(key)
            while len(self._store) > self._max:
                self._store.popitem(last=False)

    def invalidate(self, url: str):
        with self._lock:
            for k in [k for k in self._store if k[0] == url]:
                del self._store[k]

# ── Shared HTTP session with bounded connection pool ───────────────────────────
# A fresh requests.get() per block opens a brand new TCP+TLS connection every
# time with no pooling and no cap — under prefetch/seek load this exhausts the
# process's open file descriptor limit very quickly (each socket is an FD).
# A single shared Session with a bounded pool reuses connections and caps how
# many can be open at once.
#
# CRITICAL: pool_maxsize alone does NOT cap connections — by default urllib3
# just stops *reusing* pooled connections once the pool is full and silently
# opens new ones outside the pool instead (with a "Connection pool is full,
# discarding connection" warning). block=True makes it actually wait for a
# free slot instead, which is the real enforcement mechanism.
_POOL_CONNECTIONS = int(os.environ.get("FUSE_POOL_CONNECTIONS", "10"))
_POOL_MAXSIZE     = int(os.environ.get("FUSE_POOL_MAXSIZE", "20"))

_http_session = requests.Session()
_http_adapter = requests.adapters.HTTPAdapter(
    pool_connections=_POOL_CONNECTIONS,
    pool_maxsize=_POOL_MAXSIZE,
    max_retries=0,   # we do our own retry/backoff loop
    pool_block=True, # actually enforce pool_maxsize instead of overflowing it
)
_http_session.mount("https://", _http_adapter)
_http_session.mount("http://", _http_adapter)

# Caps how many blocks can be in-flight (fetching or prefetching) at once,
# independent of the connection pool, so a burst of seeks/prefetches can't
# spawn unbounded concurrent threads each holding a connection.
_inflight_sem = threading.Semaphore(int(os.environ.get("FUSE_MAX_INFLIGHT", "12")))


# Dedup: prevents multiple prefetch threads from fetching the same block
# concurrently (e.g. if read() and the prefetch loop both target it).
_inflight_prefetch: set = set()
_inflight_prefetch_lock = threading.Lock()

# Circuit breaker: when we detect FD exhaustion (EMFILE), pause ALL new
# prefetch requests for a cooldown window. Reads still happen (Plex needs
# them to keep playing) but speculative prefetching — which is what turns a
# normal single connection error into a multiplying storm — stops until FDs
# recover. This is what actually breaks the "Too many open files" cascade:
# without it, every failed prefetch retry just spawns more failed attempts.
_prefetch_paused_until: float = 0.0
_prefetch_pause_lock = threading.Lock()

def _pause_prefetch(seconds: float):
    global _prefetch_paused_until
    with _prefetch_pause_lock:
        _prefetch_paused_until = max(_prefetch_paused_until, time.time() + seconds)

def _prefetch_is_paused() -> bool:
    with _prefetch_pause_lock:
        return time.time() < _prefetch_paused_until


_block_cache = _BlockCache(_CACHE_N)


# ── Virtual filesystem ────────────────────────────────────────────────────────
class AIOGatewayFS(Operations):
    """Read-only view over StubManager's bound entries."""

    def __init__(self, stubs: "StubManager", client: "TorBoxClient"):
        self._stubs  = stubs
        self._client = client
        self._now    = time.time()
        self._lock   = threading.Lock()

    # ── Path parsing ──────────────────────────────────────────────────────────

    def _stub_path(self, stub) -> str:
        from .stub_manager import virtual_path
        return virtual_path(stub)

    def _stub_for_path(self, path: str):
        for stub in self._stubs.listed():
            if self._stub_path(stub) == path:
                return stub
        return None

    def _dir_contents(self, path: str):
        prefix = path.rstrip("/") + "/"
        children = set()
        for stub in self._stubs.listed():
            sp = self._stub_path(stub)
            if sp.startswith(prefix):
                child = sp[len(prefix):].split("/")[0]
                if child:
                    children.add(child)
        return children

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        try:
            return self._getattr_safe(path)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning("getattr(%s): %s", path, e)
            raise FuseOSError(errno.ENOENT)

    def _getattr_safe(self, path):
        now  = self._now
        base = {
            "st_uid": os.getuid(), "st_gid": os.getgid(),
            "st_atime": now, "st_mtime": now, "st_ctime": now,
            "st_nlink": 2,
        }

        # Root
        if path == "/":
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        # Top-level category dirs
        name = path.lstrip("/")
        if name in _TOP_DIRS:
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        # Is it a known stub file?
        stub = self._stub_for_path(path)
        if stub is not None:
            mtime = stub.resolved_at or stub.created_at
            return {**base,
                    "st_mode": stat.S_IFREG | 0o444,
                    "st_nlink": 1,
                    "st_size": stub.stream_size or 0,
                    "st_mtime": mtime,
                    "st_ctime": mtime}

        # Is it a virtual directory (parent of one or more stub paths)?
        if self._dir_contents(path):
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        raise FuseOSError(errno.ENOENT)

    def readdir(self, path, fh):
        try:
            return self._readdir_safe(path)
        except Exception as e:
            log.error("readdir(%s): %s", path, e)
            return [".", ".."]

    def _readdir_safe(self, path):
        entries = [".", ".."]

        if path == "/":
            # Always show the four category dirs, even if empty
            return entries + list(_TOP_DIRS)

        name = path.lstrip("/")
        if name in _TOP_DIRS:
            # List show/movie folder names under this category
            entries += sorted(self._dir_contents(path))
            return entries

        # Intermediate or leaf directory — list immediate children
        children = self._dir_contents(path)
        entries += sorted(children)
        return entries

    def open(self, path, flags):
        stub = self._stub_for_path(path)
        if stub is None:
            raise FuseOSError(errno.ENOENT)
        return 0

    def release(self, path, fh):
        return 0

    def read(self, path, size, offset, fh):
        try:
            return self._read_safe(path, size, offset)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning("read(%s): %s", path, e, exc_info=True)
            raise FuseOSError(errno.EIO)

    def _read_safe(self, path, size, offset):
        stub = self._stub_for_path(path)
        if stub is None or not stub.stream_url:
            raise FuseOSError(errno.ENOENT)
        cdn_url = stub.stream_url
        headers = dict(stub.stream_headers or {})

        # If we now know the real size and this read starts past it, this is
        # a genuine EOF — return empty bytes, not stub/zero padding, so Plex
        # (and the kernel) correctly treats it as end of file.
        if stub.stream_size and offset >= stub.stream_size:
            return b""

        block_idx = offset // BLOCK_SIZE
        cached = _block_cache.get((cdn_url, block_idx))

        if cached is None:
            cached = self._fetch_block(cdn_url, block_idx, headers, stub)
            if cached is None:
                # Re-check size — _fetch_block may have just corrected it via
                # a 416's Content-Range. If this read is now past EOF, return
                # empty bytes (real EOF) instead of stub/zero padding.
                if stub.stream_size and offset >= stub.stream_size:
                    return b""
                log.warning("FUSE read failed for %s block %d", path, block_idx)
                raise FuseOSError(errno.EIO)

        block_start  = block_idx * BLOCK_SIZE
        slice_offset = offset - block_start
        chunk = cached[slice_offset:slice_offset + size]

        # Prefetch next blocks (but not past known EOF)
        if _PREFETCH_AHEAD > 0:
            for a in range(1, _PREFETCH_AHEAD + 1):
                nb = block_idx + a
                if stub.stream_size and nb * BLOCK_SIZE >= stub.stream_size:
                    break
                self._prefetch_block(cdn_url, nb, headers, stub)

        # Cross-block reads
        remaining = size - len(chunk)
        nb = block_idx + 1
        while remaining > 0:
            if stub.stream_size and nb * BLOCK_SIZE >= stub.stream_size:
                break   # real EOF — stop, don't pad
            nc = _block_cache.get((cdn_url, nb))
            if nc is None:
                nc = self._fetch_block(cdn_url, nb, headers, stub)
                if nc is None:
                    break
            chunk    += nc[:remaining]
            remaining -= len(nc[:remaining])
            nb        += 1

        return chunk

    def _parse_content_range_size(self, content_range: str) -> Optional[int]:
        """
        Parse the total size out of a Content-Range header, e.g.
        'bytes */13458973081' → 13458973081
        """
        if not content_range or "/" not in content_range:
            return None
        try:
            total = content_range.rsplit("/", 1)[1].strip()
            if total == "*":
                return None
            return int(total)
        except (ValueError, IndexError):
            return None

    # ── TorBox ref → real CDN URL (with hang/poll) ────────────────────────
    def _real_url(self, stream_url: str, stub, force_refresh: bool = False) -> Optional[str]:
        """
        Plain URLs pass straight through. torbox:// refs go through the
        TorBox cache (0 API calls when warm). If TorBox is rate limiting or
        briefly down, this HOLDS the read and polls — warpbox's hang/poll
        mode — instead of failing, so Plex sees a slow disk rather than a
        broken file. Gives up after torbox_hang_max_seconds.
        """
        from .torbox_client import is_ref, cdn_url_for_ref, link_errors, is_retryable
        from .torbox_guard import HIGH, _setting
        # Both providers' failures, handled the same way.
        LinkError = link_errors()
        if not is_ref(stream_url):
            return stream_url
        deadline = time.monotonic() + float(_setting("torbox_hang_max_seconds", 120))
        poll = 5.0
        while True:
            try:
                return cdn_url_for_ref(stream_url, HIGH, force_refresh=force_refresh)
            except LinkError as exc:
                if not is_retryable(exc):
                    log.warning("[%s] debrid link unavailable: %s", stub.stub_id[:8], exc)
                    self._mark_bad_link(stub, str(exc))
                    return None
                if time.monotonic() + poll > deadline:
                    log.warning("[%s] debrid service still unavailable after hang window: %s",
                                stub.stub_id[:8], exc)
                    return None
                log.info("[%s] debrid service busy (%s) — holding read, polling in %.0fs",
                         stub.stub_id[:8], exc, poll)
                time.sleep(poll)
                poll = min(poll * 2, 30.0)
                force_refresh = False
            except Exception as exc:
                log.warning("[%s] could not resolve debrid ref: %s", stub.stub_id[:8], exc)
                return None

    def _mark_bad_link(self, stub, reason: str):
        # Keep the entry and its ref (Plex keeps the item); the repair loop
        # re-verifies the file or rebinds it to another cached torrent.
        self._stubs.mark_broken_sync(stub, reason)

    def _fetch_block(self, cdn_url: str, block_idx: int, headers: dict, stub) -> Optional[bytes]:
        """
        cdn_url is the stub's stream_url — for TorBox that's the stable ref,
        which is also the block-cache key (so cached blocks survive CDN URL
        rotation).
        """
        from . import probe_cache
        from .torbox_client import is_ref, invalidate_ref
        from .torbox_guard import _setting

        ref_mode = is_ref(cdn_url)
        persist  = ref_mode and probe_cache.wants(block_idx, BLOCK_SIZE, stub.stream_size)
        if persist:
            disk = probe_cache.get(cdn_url, block_idx)
            if disk is not None:
                _block_cache.put((cdn_url, block_idx), disk)
                return disk

        start = block_idx * BLOCK_SIZE
        end   = start + BLOCK_SIZE - 1
        req_headers = {**headers, "Range": f"bytes={start}-{end}"}

        acquired = _inflight_sem.acquire(timeout=READ_TIMEOUT + 2)
        if not acquired:
            log.warning("[%s] block %d: too many in-flight requests, skipping",
                        stub.stub_id[:8], block_idx)
            return None

        try:
            real_url = self._real_url(cdn_url, stub)
            if not real_url:
                return None
            repairs_left = int(_setting("torbox_cdn_repair_retries", 2)) if ref_mode else 0

            attempt = 0
            while attempt < READ_MAX_ATTEMPTS:
                r = None
                try:
                    r = _http_session.get(real_url, headers=req_headers,
                                          timeout=READ_TIMEOUT, stream=True)
                    if r.status_code in (200, 206):
                        data = r.content
                        content_type = (r.headers.get("Content-Type") or "").lower()
                        looks_like_error_body = (
                            "json" in content_type or "text/html" in content_type or
                            "text/plain" in content_type
                        )
                        is_near_eof = bool(stub.stream_size and start + len(data) >= stub.stream_size - 1)
                        suspiciously_small = len(data) < 4096 and not is_near_eof

                        if looks_like_error_body or suspiciously_small:
                            snippet = data[:300].decode("utf-8", errors="replace")
                            log.warning("[%s] block %d: rejected non-media response "
                                        "(content-type=%r, size=%d) — body: %s",
                                        stub.stub_id[:8], block_idx, content_type, len(data), snippet)
                            if repairs_left > 0:
                                # TorBox's CDN sometimes answers a rate limit or
                                # expired token with a 200 + error body. Get a
                                # fresh URL instead of giving up on the stub.
                                repairs_left -= 1
                                invalidate_ref(cdn_url)
                                real_url = self._real_url(cdn_url, stub, force_refresh=True)
                                if not real_url:
                                    return None
                                continue
                            self._mark_bad_link(stub, "CDN returned a non-media body")
                            return None

                        _block_cache.put((cdn_url, block_idx), data)
                        if persist:
                            probe_cache.put(cdn_url, block_idx, data)
                        return data

                    if r.status_code == 416:
                        real_size = self._parse_content_range_size(r.headers.get("Content-Range", ""))
                        if real_size and real_size != stub.stream_size:
                            log.info("[%s] correcting reported size %s → %s after 416",
                                     stub.stub_id[:8], stub.stream_size, real_size)
                            stub.stream_size = real_size
                        return None

                    if r.status_code in (401, 403, 404, 410):
                        if repairs_left > 0:
                            # Expired CDN link: repair it in place (1 API call
                            # at most) — the stub stays ACTIVE, playback just
                            # continues. No webhook, no re-search.
                            repairs_left -= 1
                            log.info("[%s] CDN link expired (%d) — refreshing in place",
                                     stub.stub_id[:8], r.status_code)
                            invalidate_ref(cdn_url)
                            real_url = self._real_url(cdn_url, stub, force_refresh=True)
                            if not real_url:
                                return None
                            continue
                        log.warning("[%s] CDN URL dead (%d) after repair attempts",
                                    stub.stub_id[:8], r.status_code)
                        self._mark_bad_link(stub, f"CDN {r.status_code}")
                        return None

                    if r.status_code == 429 and ref_mode:
                        wait = float(_setting("torbox_429_backoff_seconds", 30))
                        log.warning("[%s] CDN rate limited — holding read %.0fs", stub.stub_id[:8], wait)
                        time.sleep(wait)
                        attempt += 1
                        continue

                    log.warning("[%s] CDN returned %d for block %d",
                                stub.stub_id[:8], r.status_code, block_idx)
                except requests.RequestException as e:
                    is_emfile = "Too many open files" in str(e) or "[Errno 24]" in str(e)
                    if is_emfile:
                        log.warning("[%s] block %d attempt %d: FD exhaustion (EMFILE) — "
                                    "backing off and pausing prefetch", stub.stub_id[:8], block_idx, attempt)
                        _pause_prefetch(seconds=5)
                        time.sleep(2.0)
                    else:
                        log.warning("[%s] fetch block %d attempt %d: %s",
                                    stub.stub_id[:8], block_idx, attempt, e)
                finally:
                    if r is not None:
                        r.close()
                attempt += 1
                if attempt < READ_MAX_ATTEMPTS:
                    time.sleep(min(READ_BACKOFF_BASE * attempt, READ_BACKOFF_CAP))
            return None
        finally:
            _inflight_sem.release()

    def _prefetch_block(self, cdn_url: str, block_idx: int, headers: dict, stub):
        if _prefetch_is_paused():
            return   # FD exhaustion circuit breaker active — skip speculative fetches
        key = (cdn_url, block_idx)
        if _block_cache.get(key) is not None:
            return
        with _inflight_prefetch_lock:
            if key in _inflight_prefetch:
                return   # already being fetched by another thread
            _inflight_prefetch.add(key)

        def _do():
            try:
                self._fetch_block(cdn_url, block_idx, headers, stub)
            finally:
                with _inflight_prefetch_lock:
                    _inflight_prefetch.discard(key)

        t = threading.Thread(target=_do, daemon=True, name=f"fuse-prefetch-{block_idx}")
        t.start()

    # Read-only filesystem — reject all write operations
    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)


_fs_instance: Optional[AIOGatewayFS] = None
_mount_thread: Optional[threading.Thread] = None


def mount(stubs: "StubManager", client: "TorBoxClient", mountpoint: str) -> bool:
    """
    Mount the virtual AIOGateway filesystem at `mountpoint`.
    """
    global _fs_instance, _mount_thread

    if not FUSE_AVAILABLE:
        log.error("Cannot mount: fusepy / libfuse not available")
        return False

    os.makedirs(mountpoint, exist_ok=True)
    _fs_instance = AIOGatewayFS(stubs, client)

    log.info("Mounting virtual AIOGateway FS at %s (block=%dMB, cache=%d blocks)",
             mountpoint, _RA_MB, _CACHE_N)

    def _run():
        try:
            FUSE(
                _fs_instance, mountpoint,
                nothreads=False,
                foreground=True,
                allow_other=True,
                attr_timeout=ATTR_TIMEOUT,
                entry_timeout=ENTRY_TIMEOUT,
            )
        except Exception as exc:
            log.error("FUSE mount exited: %s", exc)

    _mount_thread = threading.Thread(target=_run, daemon=True, name="fuse-mount")
    _mount_thread.start()
    time.sleep(1.0)
    if not _mount_thread.is_alive():
        log.error("FUSE thread died — check /dev/fuse and cap_add: SYS_ADMIN")
        return False
    log.info("Virtual FUSE filesystem mounted at %s", mountpoint)
    return True


def unmount(mountpoint: str):
    """Unmount the FUSE filesystem. Safe to call multiple times."""
    import subprocess
    def _try(cmd):
        try:
            return subprocess.run(cmd, timeout=5, capture_output=True).returncode == 0
        except Exception:
            return False
    ok = (
        _try(["fusermount", "-u",  mountpoint]) or
        _try(["fusermount", "-uz", mountpoint]) or
        _try(["umount", mountpoint]) or
        _try(["umount", "-l", mountpoint])
    )
    if ok:
        log.info("Unmounted %s", mountpoint)
    else:
        log.warning("Could not unmount %s", mountpoint)


def invalidate_stub(stub_id: str):
    """Call after a stub's stream_url changes so cached CDN blocks are dropped."""
    if _fs_instance is None:
        return
    # Find the stub and invalidate its CDN URL blocks
    stub = _fs_instance._stubs.get(stub_id)
    if stub and stub.stream_url:
        _block_cache.invalidate(stub.stream_url)
