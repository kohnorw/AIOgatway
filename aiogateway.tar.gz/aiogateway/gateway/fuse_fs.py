"""
gateway/fuse_fs.py
~~~~~~~~~~~~~~~~~~
Virtual FUSE filesystem for AIOGateway.

Presents a read-only directory tree at FUSE_MOUNTPOINT:

  <mountpoint>/
    Movies/   <Title (Year)>/<Title (Year)>.mkv
    Movies4K/ <Title (Year)>/<Title (Year)>.mkv
    Series/   <Show (Year)>/Season NN/SXXEYY.mkv
    Series4K/ <Show (Year)>/Season NN/SXXEYY.mkv

No physical files are ever written to disk. The directory tree is built
entirely from StubManager's in-memory stub registry.

read() behaviour:
  - Stub PLACEHOLDER/RESOLVING/ERROR  → serves the appropriate static
    stub .mkv bytes (hd.mkv or 4k.mkv from the stubs/ directory), unless
    this file handle has already been reading the real file — then EIO,
    never placeholder bytes spliced into real media
  - Stub ACTIVE (stream_url resolved)  → streams from CDN via HTTP range
    requests with an in-memory LRU block cache
  - A link that breaks mid-read (403/404/410, an error page served as 200,
    a CDN that stops honouring Range, or repeated network failure) is
    repaired in real time via gateway/resolver.py and the read retried on
    the new link — seamlessly when the new link serves the same file
  - A link older than link_refresh_hours triggers a background same-file
    refresh on read

This is the same architecture as alldebrid-web's AllDebridFS — a fully
virtual filesystem backed by a metadata registry, not by real files.
"""
from __future__ import annotations

import errno
import logging
import os
import stat
import threading
import time
from collections import OrderedDict
from pathlib import Path
from typing import TYPE_CHECKING, Optional

import requests
import urllib3

if TYPE_CHECKING:
    from .stub_manager import StubManager
    from .aiostreams_client import AIOStreamsClient

log = logging.getLogger("aiogateway.fuse")

def _safe_name(name: str) -> str:
    """Strip characters that break Plex / filesystem paths."""
    import re
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', '', name).strip('. ')

# ── Try to import fusepy ───────────────────────────────────────────────────────
try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except (ImportError, OSError) as _fuse_exc:
    # fusepy raises OSError ("Unable to find libfuse"), not ImportError,
    # when the package is installed but libfuse isn't — that used to crash
    # the whole app at import instead of just disabling the mount.
    FUSE_AVAILABLE = False
    log.warning("FUSE unavailable (%s) — mount disabled", _fuse_exc)

    class FuseOSError(OSError):          # minimal stand-ins so the module imports
        def __init__(self, errno_):
            super().__init__(errno_, os.strerror(errno_))

    class Operations:                    # noqa: D401
        pass

    FUSE = None

# ── Tuning ────────────────────────────────────────────────────────────────────
_RA_MB        = int(os.environ.get("FUSE_BLOCK_MB",      "8"))
_CACHE_N      = int(os.environ.get("FUSE_CACHE_BLOCKS", "32"))
BLOCK_SIZE    = _RA_MB * 1024 * 1024

READ_TIMEOUT      = int(os.environ.get("FUSE_READ_TIMEOUT", "15"))
# Attempts per block before the link is declared broken and repaired. Kept
# low on purpose: every extra attempt is up to READ_TIMEOUT more seconds of
# a frozen player before the real fix (a new link) even starts.
READ_MAX_ATTEMPTS = max(1, int(os.environ.get("FUSE_READ_ATTEMPTS", "3")))
READ_BACKOFF_BASE = 0.5
READ_BACKOFF_CAP  = 2.0

# How long a read() blocks waiting for a broken link to be replaced. Long
# enough for one AIOStreams search plus a couple of probe rounds.
REPAIR_WAIT_TIMEOUT = float(os.environ.get("FUSE_REPAIR_TIMEOUT", "45"))

# Fetch outcomes
_OK, _EOF, _DEAD, _FAIL = "ok", "eof", "dead", "fail"

ATTR_TIMEOUT  = float(os.environ.get("FUSE_ATTR_TIMEOUT",  "30"))
ENTRY_TIMEOUT = float(os.environ.get("FUSE_ENTRY_TIMEOUT", "30"))

_PREFETCH_AHEAD = int(os.environ.get("FUSE_PREFETCH_AHEAD", "2"))
_INDEX_CHECK_S  = float(os.environ.get("FUSE_INDEX_CHECK_SECONDS", "1.0"))

# ── Stub bytes source (same stubs/ dir already in the project) ────────────────
_STUBS_DIR = Path(__file__).parent.parent / "stubs"
_STUB_HD   = _STUBS_DIR / "hd.mkv"
_STUB_4K   = _STUBS_DIR / "4k.mkv"

def _stub_bytes(quality_value: str) -> bytes:
    """Return static stub MKV bytes for the given quality ('hd' or '4k')."""
    path = _STUB_4K if quality_value == "4k" else _STUB_HD
    if path.exists():
        return path.read_bytes()
    fallback = _STUB_HD if quality_value == "4k" else _STUB_4K
    if fallback.exists():
        return fallback.read_bytes()
    # Last-resort: minimal EBML header
    ebml = bytes([
        0x1A,0x45,0xDF,0xA3,0x9F,
        0x42,0x86,0x81,0x01,0x42,0xF7,0x81,0x01,
        0x42,0xF2,0x81,0x04,0x42,0xF3,0x81,0x08,
        0x42,0x82,0x88,
        0x6D,0x61,0x74,0x72,0x6F,0x73,0x6B,0x61,
        0x42,0x87,0x81,0x04,0x42,0x85,0x81,0x02,
    ])
    segment = bytes([0x18,0x53,0x80,0x67,0x01,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF])
    return ebml + segment

# Pre-load stub bytes once at import time
_STUB_BYTES_HD: bytes = b""
_STUB_BYTES_4K: bytes = b""

def _ensure_stub_bytes():
    global _STUB_BYTES_HD, _STUB_BYTES_4K
    if not _STUB_BYTES_HD:
        _STUB_BYTES_HD = _stub_bytes("hd")
    if not _STUB_BYTES_4K:
        _STUB_BYTES_4K = _stub_bytes("4k")

# ── Folder constants ──────────────────────────────────────────────────────────
_TOP_DIRS = {"Movies", "Movies4K", "Series", "Series4K"}

# ── LRU in-memory block cache ─────────────────────────────────────────────────
class _BlockCache:
    def __init__(self, max_blocks: int):
        self._max   = max_blocks
        self._lock  = threading.Lock()
        self._store: OrderedDict = OrderedDict()

    def get(self, key) -> Optional[bytes]:
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        return None

    def put(self, key, data: bytes):
        with self._lock:
            self._store[key] = data
            self._store.move_to_end(key)
            while len(self._store) > self._max:
                self._store.popitem(last=False)

    def invalidate(self, url: str):
        with self._lock:
            for k in [k for k in self._store if k[0] == url]:
                del self._store[k]

# ── Shared HTTP session with bounded connection pool ───────────────────────────
# A fresh requests.get() per block opens a brand new TCP+TLS connection every
# time with no pooling and no cap — under prefetch/seek load this exhausts the
# process's open file descriptor limit very quickly (each socket is an FD).
# A single shared Session with a bounded pool reuses connections and caps how
# many can be open at once.
#
# CRITICAL: pool_maxsize alone does NOT cap connections — by default urllib3
# just stops *reusing* pooled connections once the pool is full and silently
# opens new ones outside the pool instead (with a "Connection pool is full,
# discarding connection" warning). block=True makes it actually wait for a
# free slot instead, which is the real enforcement mechanism.
_POOL_CONNECTIONS = int(os.environ.get("FUSE_POOL_CONNECTIONS", "10"))
_POOL_MAXSIZE     = int(os.environ.get("FUSE_POOL_MAXSIZE", "20"))

_http_session = requests.Session()
# Debrid CDNs (and Cloudflare in front of them) commonly answer python
# client user-agents with 403. Present as a normal media player.
STREAM_USER_AGENT = os.environ.get(
    "STREAM_USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0 Safari/537.36",
)
_http_session.headers["User-Agent"] = STREAM_USER_AGENT
_http_adapter = requests.adapters.HTTPAdapter(
    pool_connections=_POOL_CONNECTIONS,
    pool_maxsize=_POOL_MAXSIZE,
    max_retries=0,   # we do our own retry/backoff loop
    pool_block=True, # actually enforce pool_maxsize instead of overflowing it
)
_http_session.mount("https://", _http_adapter)
_http_session.mount("http://", _http_adapter)

# Caps how many blocks can be in-flight (fetching or prefetching) at once,
# independent of the connection pool, so a burst of seeks/prefetches can't
# spawn unbounded concurrent threads each holding a connection.
_inflight_sem = threading.Semaphore(int(os.environ.get("FUSE_MAX_INFLIGHT", "6")))


# Dedup: prevents multiple prefetch threads from fetching the same block
# concurrently (e.g. if read() and the prefetch loop both target it).
_inflight_prefetch: set = set()
_inflight_prefetch_lock = threading.Lock()
# (cdn_url, block_idx) -> Event, for ANY fetch in progress (read or prefetch)
_inflight_fetch: dict = {}

# Circuit breaker: when we detect FD exhaustion (EMFILE), pause ALL new
# prefetch requests for a cooldown window. Reads still happen (Plex needs
# them to keep playing) but speculative prefetching — which is what turns a
# normal single connection error into a multiplying storm — stops until FDs
# recover. This is what actually breaks the "Too many open files" cascade:
# without it, every failed prefetch retry just spawns more failed attempts.
_prefetch_paused_until: float = 0.0
_prefetch_pause_lock = threading.Lock()

def _pause_prefetch(seconds: float):
    global _prefetch_paused_until
    with _prefetch_pause_lock:
        _prefetch_paused_until = max(_prefetch_paused_until, time.time() + seconds)

def _prefetch_is_paused() -> bool:
    with _prefetch_pause_lock:
        return time.time() < _prefetch_paused_until


_block_cache = _BlockCache(_CACHE_N)


# ── Virtual filesystem ────────────────────────────────────────────────────────
class AIOGatewayFS(Operations):
    """
    Virtual read-only FUSE filesystem backed by StubManager.

    Resolution (real AIOStreams query + CDN probing) is NEVER triggered by
    open() or read() — only by the Plex webhook (media.play/media.resume,
    see webhook/handler.py). This was a hard lesson: both open()-triggered
    and read-pattern-heuristic-triggered resolution were tried and both
    converted stubs to real files without anyone pressing play, because
    Plex's library scanner legitimately calls open() + multiple reads on a
    newly added file during first-time deep analysis (codec/duration
    fingerprinting, thumbnail generation) — a pattern indistinguishable at
    the FUSE layer from genuine playback starting. The webhook is the one
    truly unambiguous "the user pressed play" signal, so it's the only
    thing allowed to start resolution. read() just waits if a webhook-
    triggered resolution happens to already be in progress, and otherwise
    always serves stub bytes immediately, regardless of how many times or
    how quickly it's called.
    """

    def __init__(self, stubs: "StubManager", client: "AIOStreamsClient"):
        self._stubs  = stubs
        self._client = client
        self._now    = time.time()
        self._lock   = threading.Lock()

        # ── Path index cache ──────────────────────────────────────────────
        # getattr()/readdir() used to do a full O(N) scan over every stub
        # (formatting + regex-sanitizing a path string for each one) on
        # EVERY call. FUSE calls readdir() once per folder listing and then
        # getattr() once per entry in that folder, so listing a folder with
        # M items cost O(M*N) full-library scans — with a large library
        # this is what made Plex's directory listing hang.
        #
        # Fix: cache a path->stub / dir->children index, and only rebuild
        # it (the expensive part, with string formatting/regex) when the
        # library has actually changed. Change-detection itself uses a
        # cheap fingerprint (plain attribute reads, no formatting) so it's
        # safe to check on every single FUSE call.
        self._index_lock        = threading.Lock()
        self._index_fingerprint = None
        self._index_checked_at  = 0.0
        self._path_to_stub: dict = {}
        self._dir_children: dict = {}

        # Per open file handle: has this handle been served real media
        # bytes yet? Once it has, it is a real playback (or analysis) of the
        # real file, and must never be handed placeholder bytes or a
        # different release's bytes at the same offsets — it gets EIO
        # instead, which Plex surfaces as a clean playback error.
        self._fh_lock = threading.Lock()
        self._fh_next = 1
        self._fh_streamed: dict[int, bool] = {}
        # Handles that have been served placeholder bytes: they keep getting
        # them, even if the stub switches meanwhile.
        self._fh_placeholder: set[int] = set()

    def _index_fingerprint_now(self):
        # Cheap: just attribute reads, no string building. Changes iff a
        # stub is added/removed, or its resolved-state (which is the only
        # thing that alters its virtual path) changes.
        return tuple(
            (s.stub_id, s.state.value, s.stream_url is not None, getattr(s, "named_ready", False))
            for s in self._stubs.all()
        )

    def _ensure_index(self):
        # Every getattr()/read() used to rebuild a tuple of every stub in
        # the library just to check for changes — during playback that's
        # hundreds of full-library allocations per second, which is both
        # CPU burn (now capped at 2 cores) and heap churn that fragments
        # memory. Check at most every _INDEX_CHECK_S instead.
        now = time.monotonic()
        count = len(getattr(self._stubs, "_stubs", ()))   # O(1): added/removed stubs show up at once
        if (self._index_fingerprint is not None and now - self._index_checked_at < _INDEX_CHECK_S
                and count == getattr(self, "_index_count", -1)):
            return
        self._index_count = count
        self._index_checked_at = now
        fp = self._index_fingerprint_now()
        if fp == self._index_fingerprint:
            return
        with self._index_lock:
            fp = self._index_fingerprint_now()
            if fp == self._index_fingerprint:
                return  # another thread already rebuilt it
            path_to_stub: dict = {}
            dir_children: dict = {}

            def _register_dirs(full_path: str):
                parts = full_path.strip("/").split("/")
                for i in range(1, len(parts)):
                    parent = "/" + "/".join(parts[:i])
                    dir_children.setdefault(parent, set()).add(parts[i])

            for stub in self._stubs.all():
                # path_to_stub maps BOTH filename variants, so a Plex
                # session holding an open handle on the pre-resolve name
                # keeps working after the rename.
                #
                # dir_children, though, must only carry the ONE name this
                # stub currently presents. Registering both meant readdir
                # listed every stub twice — "S01E01.mkv" and
                # "S01E01 - Ready.mkv" side by side, permanently, in every
                # season folder. Plex merges those into a single item with
                # two versions, so it doesn't look obviously broken, but it
                # doubles every scan and gives Plex a second file whose
                # state it can report as changed.
                current = self._stub_path(stub)
                for resolved in (True, False):
                    p = self._build_path_for_state(stub, resolved=resolved)
                    path_to_stub[p] = stub
                _register_dirs(current)

            self._path_to_stub    = path_to_stub
            self._dir_children    = dir_children
            self._index_fingerprint = fp

    # ── Path parsing ──────────────────────────────────────────────────────────

    def _stub_for_path(self, path: str):
        """
        Resolve a FUSE path to a Stub, or None.

        Expected path forms:
          /Movies/<folder>/<file>.mkv          (movie)
          /Series/<folder>/Season NN/<ep>.mkv  (series)
          /Movies4K/...  /Series4K/...

        Once a stub resolves, _stub_path() starts returning a new filename
        (with a " - Ready" suffix). A Plex session that already opened the
        OLD path needs that path to keep resolving to the same stub for the
        lifetime of its open file handle — otherwise read() on the old path
        would 404. So this matches both the resolved and unresolved variants
        of each stub's path, regardless of its current actual state.
        """
        self._ensure_index()
        return self._path_to_stub.get(path)

    def _build_path_for_state(self, stub, resolved: bool) -> str:
        from .models import MediaType, Quality

        is_4k     = stub.quality == Quality.UHD
        is_series = stub.media_type == MediaType.SERIES
        suffix    = " - Ready" if resolved else ""

        if is_series:
            top = "Series4K" if is_4k else "Series"
            show = stub.show_title or stub.title
            show = _safe_name(show)
            folder = f"{show} ({stub.year})" if stub.year else show
            season = stub.season or 1
            ep     = stub.episode or 1
            filename = f"S{season:02d}E{ep:02d}{suffix}.mkv"
            return f"/{top}/{folder}/Season {season:02d}/{filename}"
        else:
            top = "Movies4K" if is_4k else "Movies"
            title = _safe_name(stub.title)
            folder = f"{title} ({stub.year})" if stub.year else title
            filename = f"{folder}{suffix}.mkv"
            return f"/{top}/{folder}/{filename}"

    def _stub_path(self, stub) -> str:
        """
        Derive the virtual FUSE path for a stub from its own fields.

        The ' - Ready' suffix appears the first time a stub resolves, which
        forces Plex to see a new file and re-analyse content that has just
        changed from a small placeholder into real media. Plex does not
        reliably notice an existing file's size/mtime changing mid-session,
        so that first rename earns its keep.

        It is sticky. Once a stub has resolved, it keeps the suffix for
        good — including after the TTL reverts it to a placeholder. The
        name previously tracked *current* state, so expiry renamed the file
        back and Plex read the vanished "- Ready" path plus the reappearing
        bare one as newly added content, every single TTL cycle. Nothing
        about the media changes when a lease expires, so nothing about the
        filename should either. One rename per stub, ever.

        Set stable_stub_filenames=false to go back to state-tracking names.

        Movies:  /Movies/Title (Year)/Title (Year).mkv
                 /Movies/Title (Year)/Title (Year) - Ready.mkv   (has resolved)
        Series:  /Series/Show (Year)/Season NN/SXXEYY.mkv
                 /Series/Show (Year)/Season NN/SXXEYY - Ready.mkv (has resolved)
        """
        # The name no longer changes when a stub switches (see
        # Stub.named_ready); only stubs renamed by older builds keep the
        # " - Ready" suffix, permanently.
        return self._build_path_for_state(stub, resolved=bool(getattr(stub, "named_ready", False)))

    def _resolved_folder(self, stub) -> str:
        """
        Real filesystem path (mountpoint + virtual dir) of the folder
        containing this stub's resolved file. Used to trigger a scoped
        Plex partial scan right after resolution.
        """
        virtual_path = self._build_path_for_state(stub, resolved=True)
        virtual_dir  = "/".join(virtual_path.split("/")[:-1])
        mountpoint   = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt").rstrip("/")
        return f"{mountpoint}{virtual_dir}"

    def _dir_stubs(self, top_dir: str):
        """Return all stubs whose virtual path starts with /<top_dir>/."""
        prefix = f"/{top_dir}/"
        return [s for s in self._stubs.all() if self._stub_path(s).startswith(prefix)]

    def _dir_contents(self, path: str):
        """
        Return the set of immediate child names under the virtual directory `path`.
        Used by readdir().
        """
        self._ensure_index()
        return self._dir_children.get(path.rstrip("/") or "/", set())

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        try:
            return self._getattr_safe(path)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning("getattr(%s): %s", path, e)
            raise FuseOSError(errno.ENOENT)

    def _getattr_safe(self, path):
        now  = self._now
        base = {
            "st_uid": os.getuid(), "st_gid": os.getgid(),
            "st_atime": now, "st_mtime": now, "st_ctime": now,
            "st_nlink": 2,
        }

        # Root
        if path == "/":
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        # Top-level category dirs
        name = path.lstrip("/")
        if name in _TOP_DIRS:
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        # Is it a known stub file?
        stub = self._stub_for_path(path)
        if stub is not None:
            _ensure_stub_bytes()

            if stub.stream_size:
                # Real size known (set at add time or on resolution) —
                # always report it so Plex never thinks this is a short file
                file_size = stub.stream_size
            else:
                # Size not yet known — report a large placeholder so Plex
                # doesn't cap reads at stub length. 50GB covers any movie.
                file_size = 50 * 1024 * 1024 * 1024

            # mtime must not move backwards when a stub expires. It used to
            # fall back to created_at the moment revert cleared resolved_at,
            # and a file whose mtime changes is a file Plex re-adds. Hold
            # the last resolve time instead.
            mtime = (getattr(stub, "last_resolved_at", None)
                     or stub.resolved_at
                     or stub.created_at)
            return {**base,
                    "st_mode": stat.S_IFREG | 0o444,
                    "st_nlink": 1,
                    "st_size": file_size,
                    "st_mtime": mtime,
                    "st_ctime": mtime}

        # Is it a virtual directory (parent of one or more stub paths)?
        if self._dir_contents(path):
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        raise FuseOSError(errno.ENOENT)

    def readdir(self, path, fh):
        try:
            return self._readdir_safe(path)
        except Exception as e:
            log.error("readdir(%s): %s", path, e)
            return [".", ".."]

    def _readdir_safe(self, path):
        entries = [".", ".."]

        if path == "/":
            # Always show the four category dirs, even if empty
            return entries + list(_TOP_DIRS)

        name = path.lstrip("/")
        if name in _TOP_DIRS:
            # List show/movie folder names under this category
            entries += sorted(self._dir_contents(path))
            return entries

        # Intermediate or leaf directory — list immediate children
        children = self._dir_contents(path)
        entries += sorted(children)
        return entries

    def open(self, path, flags):
        stub = self._stub_for_path(path)
        if stub is None:
            raise FuseOSError(errno.ENOENT)
        # Deliberately does NOT trigger resolution. Resolution only ever
        # happens via the Plex webhook — see the class docstring above for
        # why open()/read()-triggered resolution was tried and abandoned.
        with self._fh_lock:
            fh = self._fh_next
            self._fh_next += 1
            self._fh_streamed[fh] = False
        return fh

    def release(self, path, fh):
        with self._fh_lock:
            self._fh_streamed.pop(fh, None)
            self._fh_placeholder.discard(fh)
        return 0

    def _mark_streamed(self, fh) -> None:
        if fh:
            with self._fh_lock:
                if fh in self._fh_streamed:
                    self._fh_streamed[fh] = True

    def _has_streamed(self, fh) -> bool:
        with self._fh_lock:
            return bool(self._fh_streamed.get(fh))

    def _mark_placeholder(self, fh) -> None:
        if fh:
            with self._fh_lock:
                if fh in self._fh_streamed:
                    self._fh_placeholder.add(fh)

    def _is_placeholder_handle(self, fh) -> bool:
        with self._fh_lock:
            return fh in self._fh_placeholder

    def _plex_paths(self, stub) -> set[str]:
        mnt = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt").rstrip("/")
        return {mnt + self._build_path_for_state(stub, resolved=r) for r in (True, False)}

    def _switch_for_playback(self, stub, fh) -> bool:
        """
        Decide, on a placeholder's read, whether this read is a real
        playback — and if so do the placeholder switch right here, so the
        player gets the real content on this same press of play.

        Returns True when the stub is now ACTIVE and this handle should
        stream it; False to serve placeholder bytes.

        * A handle already serving placeholder bytes keeps doing so (mixing
          placeholder and real bytes in one stream is garbage).
        * A switch already running (webhook got there first) → wait for it.
        * Otherwise ask Plex whether it has a session on this file. The
          scanner, analyzer and thumbnailer never show up as sessions, so
          they get placeholder bytes and cost no AIOStreams search. A
          playback's first read can arrive a moment before Plex lists the
          session, so it waits up to FUSE_PLAY_DETECT_SECONDS for it.
        """
        from .models import StubState
        if self._is_placeholder_handle(fh):
            return False

        if stub.state == StubState.RESOLVING:
            timeout = REPAIR_WAIT_TIMEOUT if stub.repairing else RESOLVE_WAIT_TIMEOUT
            log.info("[%s] read() waiting for %s (up to %.0fs)…", stub.stub_id[:8],
                     "link repair" if stub.repairing else "placeholder switch", timeout)
            _get_resolve_event(stub.stub_id).wait(timeout=timeout)
            return stub.state == StubState.ACTIVE and bool(stub.stream_url)

        if self._has_streamed(fh) or PLAY_DETECT_S <= 0:
            return False
        try:
            from . import plex_sessions
        except Exception:
            return False
        rating_key = plex_sessions.wait_for_any(self._plex_paths(stub), PLAY_DETECT_S)
        if rating_key is None:
            return False

        resolver = _resolver()
        if resolver is None:
            return False
        log.info("[%s] Plex is playing this placeholder — switching now", stub.stub_id[:8])
        resolver.activate_blocking(stub.stub_id, RESOLVE_WAIT_TIMEOUT)
        return stub.state == StubState.ACTIVE and bool(stub.stream_url)

    def read(self, path, size, offset, fh):
        try:
            return self._read_safe(path, size, offset, fh)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning("read(%s): %s", path, e, exc_info=True)
            raise FuseOSError(errno.EIO)

    def _read_safe(self, path, size, offset, fh=None):
        from .models import StubState
        _ensure_stub_bytes()

        stub = self._stub_for_path(path)
        if stub is None:
            raise FuseOSError(errno.ENOENT)

        if stub.state != StubState.ACTIVE or not stub.stream_url:
            if not self._switch_for_playback(stub, fh):
                if self._has_streamed(fh):
                    # This handle was reading the real file. Placeholder
                    # bytes at this offset would be garbage to the decoder.
                    raise FuseOSError(errno.EIO)
                self._mark_placeholder(fh)
                return self._serve_stub(stub, offset, size)

        # Fresh links on every playback after link_refresh_hours: kick off a
        # background same-file refresh; this read carries on with the
        # current link meanwhile.
        resolver = _resolver()
        if resolver is not None and resolver.link_is_stale(stub):
            resolver.schedule_refresh(stub.stub_id, "read after 24h")

        if stub.stream_size and offset >= stub.stream_size:
            return b""

        block_idx = offset // BLOCK_SIZE
        first = self._get_block(stub, block_idx, fh)
        if first is None:
            return b""      # genuine EOF (416)

        slice_offset = offset - block_idx * BLOCK_SIZE
        chunk = first[slice_offset:slice_offset + size]

        cdn_url = stub.stream_url
        if _PREFETCH_AHEAD > 0 and cdn_url:
            headers = dict(stub.stream_headers or {})
            for a in range(1, _PREFETCH_AHEAD + 1):
                nb = block_idx + a
                if stub.stream_size and nb * BLOCK_SIZE >= stub.stream_size:
                    break
                self._prefetch_block(cdn_url, nb, headers, stub)

        remaining = size - len(chunk)
        nb = block_idx + 1
        while remaining > 0:
            if stub.stream_size and nb * BLOCK_SIZE >= stub.stream_size:
                break   # real EOF — stop, don't pad
            nc = self._get_block(stub, nb, fh)
            if nc is None:
                break
            part = nc[:remaining]
            chunk += part
            remaining -= len(part)
            if len(nc) < BLOCK_SIZE:
                break   # short block = end of file
            nb += 1

        return chunk

    def _get_block(self, stub, block_idx: int, fh) -> Optional[bytes]:
        """
        One block of the stub's current link, repairing the link in real
        time if it's broken. Returns None only at a genuine EOF; raises EIO
        when the read can't be satisfied coherently.
        """
        from .models import StubState
        for _ in range(3):
            url = stub.stream_url
            if not url:
                # Another thread is replacing the link right now.
                if stub.state == StubState.RESOLVING:
                    _get_resolve_event(stub.stub_id).wait(timeout=REPAIR_WAIT_TIMEOUT)
                    if stub.stream_url:
                        continue
                raise FuseOSError(errno.EIO)

            data = _block_cache.get((url, block_idx))
            if data is not None:
                self._mark_streamed(fh)
                return data

            status, data = self._fetch_block(url, block_idx, dict(stub.stream_headers or {}), stub)
            if status == _OK:
                self._mark_streamed(fh)
                return data
            if status == _EOF:
                return None

            # Broken link (expired/denied/error body/unreachable).
            if stub.stream_url and stub.stream_url != url:
                continue        # already replaced by another reader — retry on the new link

            outcome = self._repair(stub, url)
            if outcome == "same_file":
                continue
            if outcome == "new_file" and not self._has_streamed(fh):
                continue        # playback hadn't started on the old bytes — safe to switch
            log.warning("[%s] read at block %d can't continue (repair: %s)",
                        stub.stub_id[:8], block_idx, outcome)
            raise FuseOSError(errno.EIO)
        raise FuseOSError(errno.EIO)

    def _repair(self, stub, failed_url: str) -> str:
        resolver = _resolver()
        if resolver is None:
            return "failed"
        return resolver.repair_blocking(
            stub.stub_id, failed_url, stub.stream_file_id, stub.stream_size, REPAIR_WAIT_TIMEOUT
        )

    def _serve_stub(self, stub, offset: int, size: int) -> bytes:
        """
        Serve bytes from the static stub MKV, zero-padded if the read goes
        past the stub's own length. This matches alldebrid-web's behaviour:
        Plex thinks the file is full-movie-sized (from getattr) and keeps
        reading — we serve the real stub MKV header bytes first, then zeros,
        so Plex doesn't stop or error out while waiting for resolution.
        """
        from .models import Quality
        data = _STUB_BYTES_4K if stub.quality == Quality.UHD else _STUB_BYTES_HD
        if offset >= len(data):
            # Past end of stub — return zeros
            return b"\x00" * size
        chunk = data[offset:offset + size]
        if len(chunk) < size:
            # Pad remainder with zeros
            chunk = chunk + b"\x00" * (size - len(chunk))
        return chunk

    def _parse_content_range_size(self, content_range: str) -> Optional[int]:
        """
        Parse the total size out of a Content-Range header, e.g.
        'bytes */13458973081' → 13458973081
        """
        if not content_range or "/" not in content_range:
            return None
        try:
            total = content_range.rsplit("/", 1)[1].strip()
            if total == "*":
                return None
            return int(total)
        except (ValueError, IndexError):
            return None

    def _fetch_block(self, cdn_url: str, block_idx: int, headers: dict, stub) -> tuple[str, Optional[bytes]]:
        """
        De-duplicated block fetch → (status, data). If another thread (a
        prefetch, or a parallel read() from Plex/the kernel's readahead) is
        already downloading this block, wait for it and share its result
        instead of downloading the same 8 MB again.
        """
        key = (cdn_url, block_idx)
        with _inflight_prefetch_lock:
            entry = _inflight_fetch.get(key)
            owner = entry is None
            if owner:
                entry = (threading.Event(), [_FAIL, None])
                _inflight_fetch[key] = entry
        ev, holder = entry
        if not owner:
            ev.wait(timeout=READ_TIMEOUT * READ_MAX_ATTEMPTS + 5)
            cached = _block_cache.get(key)
            if cached is not None:
                return _OK, cached
            if not ev.is_set():
                return _FAIL, None
            if holder[0] == _OK and holder[1] is None:
                return _FAIL, None
            return holder[0], holder[1]
        try:
            status, data = self._fetch_block_uncached(cdn_url, block_idx, headers, stub)
            holder[0], holder[1] = status, data
            return status, data
        finally:
            with _inflight_prefetch_lock:
                _inflight_fetch.pop(key, None)
            ev.set()

    def _fetch_block_uncached(self, cdn_url: str, block_idx: int, headers: dict, stub) -> tuple[str, Optional[bytes]]:
        start = block_idx * BLOCK_SIZE
        end   = start + BLOCK_SIZE - 1
        req_headers = {**headers, "Range": f"bytes={start}-{end}"}

        # Bound total concurrent in-flight requests (reads + prefetches) so a
        # burst of seeks can't open unbounded sockets even with a pooled session.
        acquired = _inflight_sem.acquire(timeout=READ_TIMEOUT + 2)
        if not acquired:
            log.warning("[%s] block %d: too many in-flight requests, skipping",
                        stub.stub_id[:8], block_idx)
            return _FAIL, None

        try:
            for attempt in range(READ_MAX_ATTEMPTS):
                r = None
                try:
                    r = _http_session.get(cdn_url, headers=req_headers,
                                          timeout=READ_TIMEOUT, stream=True)
                    if r.status_code == 200 and start > 0:
                        # Server ignored Range and is sending the whole file
                        # from byte 0. Never read that body (multi-GB → OOM,
                        # and it's the wrong bytes for block N). A link that
                        # can't seek is unusable — repair it.
                        log.warning("[%s] block %d: CDN ignored Range (200 for offset %d)",
                                    stub.stub_id[:8], block_idx, start)
                        return _DEAD, None
                    if r.status_code in (200, 206):
                        data = r.raw.read(BLOCK_SIZE, decode_content=True) or b""
                        # Debrid backends sometimes answer an expired or
                        # invalid link with 200 + a JSON/HTML error body.
                        # Caching that would hand Plex an error message as
                        # video data.
                        content_type = (r.headers.get("Content-Type") or "").lower()
                        looks_like_error_body = (
                            "json" in content_type or
                            "text/html" in content_type or
                            "text/plain" in content_type
                        )
                        is_near_eof = bool(
                            stub.stream_size and
                            start + len(data) >= stub.stream_size - 1
                        )
                        suspiciously_small = len(data) < 4096 and not is_near_eof
                        if looks_like_error_body or suspiciously_small:
                            snippet = data[:300].decode("utf-8", errors="replace")
                            log.warning(
                                "[%s] block %d: rejected non-media response "
                                "(content-type=%r, size=%d) — body: %s",
                                stub.stub_id[:8], block_idx, content_type, len(data), snippet,
                            )
                            return _DEAD, None
                        _block_cache.put((cdn_url, block_idx), data)
                        return _OK, data
                    if r.status_code == 416:
                        # Past end of file — deterministic EOF, not an error.
                        real_size = self._parse_content_range_size(r.headers.get("Content-Range", ""))
                        if real_size and real_size != stub.stream_size:
                            log.info("[%s] correcting reported size %s → %s after 416",
                                     stub.stub_id[:8], stub.stream_size, real_size)
                            stub.stream_size = real_size
                        return _EOF, None
                    if r.status_code in (401, 403, 404, 410, 451):
                        log.warning("[%s] CDN link rejected (%d) at block %d",
                                    stub.stub_id[:8], r.status_code, block_idx)
                        return _DEAD, None
                    log.warning("[%s] CDN returned %d for block %d (attempt %d/%d)",
                                stub.stub_id[:8], r.status_code, block_idx,
                                attempt + 1, READ_MAX_ATTEMPTS)
                except (requests.RequestException, urllib3.exceptions.HTTPError, OSError) as e:
                    is_emfile = "Too many open files" in str(e) or "[Errno 24]" in str(e)
                    if is_emfile:
                        log.warning("[%s] block %d attempt %d: FD exhaustion (EMFILE) — "
                                    "backing off and pausing prefetch",
                                    stub.stub_id[:8], block_idx, attempt + 1)
                        _pause_prefetch(seconds=5)
                        time.sleep(2.0)
                    else:
                        log.warning("[%s] fetch block %d attempt %d/%d: %s",
                                    stub.stub_id[:8], block_idx, attempt + 1, READ_MAX_ATTEMPTS, e)
                finally:
                    if r is not None:
                        r.close()
                if attempt < READ_MAX_ATTEMPTS - 1:
                    time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))
            return _FAIL, None
        finally:
            _inflight_sem.release()

    def _prefetch_block(self, cdn_url: str, block_idx: int, headers: dict, stub):
        if _prefetch_is_paused():
            return   # FD exhaustion circuit breaker active — skip speculative fetches
        key = (cdn_url, block_idx)
        if _block_cache.get(key) is not None:
            return
        with _inflight_prefetch_lock:
            if key in _inflight_prefetch or key in _inflight_fetch:
                return   # already being fetched by another thread
            _inflight_prefetch.add(key)

        def _do():
            try:
                status, _ = self._fetch_block(cdn_url, block_idx, headers, stub)
                if status in (_DEAD, _FAIL) and stub.stream_url == cdn_url:
                    # Start the repair now so it's (nearly) done by the time
                    # the player reaches this block. Non-blocking.
                    resolver = _resolver()
                    if resolver is not None:
                        resolver.schedule_repair(stub.stub_id, cdn_url,
                                                 stub.stream_file_id, stub.stream_size)
            finally:
                with _inflight_prefetch_lock:
                    _inflight_prefetch.discard(key)

        t = threading.Thread(target=_do, daemon=True, name=f"fuse-prefetch-{block_idx}")
        t.start()

    # Read-only filesystem — reject all write operations
    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)


# ── Per-stub resolution events ────────────────────────────────────────────────
# When read() fires on a PLACEHOLDER stub it waits on this event rather than
# immediately serving stub bytes. set_active() signals the event so read()
# picks up the real CDN URL. Keyed by stub_id.
_resolve_events: dict[str, threading.Event] = {}
_resolve_events_lock = threading.Lock()

# How long a playback read waits for its placeholder switch. Long enough
# for a search, a couple of link tests and one re-search; the player shows
# its buffering spinner meanwhile instead of the placeholder clip.
RESOLVE_WAIT_TIMEOUT = float(os.environ.get("FUSE_RESOLVE_TIMEOUT", "40"))

# How long a placeholder's first read waits for Plex to list the playback
# session before deciding "not a playback" (scanner etc.). 0 disables
# read-time switching (webhook only).
PLAY_DETECT_S = float(os.environ.get("FUSE_PLAY_DETECT_SECONDS", "4"))

def _get_resolve_event(stub_id: str) -> threading.Event:
    with _resolve_events_lock:
        if stub_id not in _resolve_events:
            _resolve_events[stub_id] = threading.Event()
        return _resolve_events[stub_id]

def signal_resolved(stub_id: str):
    """Called by set_active() to wake any read() waiting on this stub."""
    with _resolve_events_lock:
        ev = _resolve_events.get(stub_id)
    if ev:
        ev.set()
def _resolver():
    try:
        from .resolver import get_instance
        return get_instance()
    except Exception:
        return None


_fs_instance: Optional[AIOGatewayFS] = None
_mount_thread: Optional[threading.Thread] = None


def mount(stubs: "StubManager", client: "AIOStreamsClient", mountpoint: str) -> bool:
    """
    Mount the virtual AIOGateway filesystem at `mountpoint`.
    """
    global _fs_instance, _mount_thread

    if not FUSE_AVAILABLE:
        log.error("Cannot mount: fusepy / libfuse not available")
        return False

    os.makedirs(mountpoint, exist_ok=True)
    _fs_instance = AIOGatewayFS(stubs, client)

    log.info("Mounting virtual AIOGateway FS at %s (block=%dMB, cache=%d blocks)",
             mountpoint, _RA_MB, _CACHE_N)

    def _run():
        try:
            FUSE(
                _fs_instance, mountpoint,
                nothreads=False,
                foreground=True,
                allow_other=True,
                attr_timeout=ATTR_TIMEOUT,
                entry_timeout=ENTRY_TIMEOUT,
            )
        except Exception as exc:
            log.error("FUSE mount exited: %s", exc)

    _mount_thread = threading.Thread(target=_run, daemon=True, name="fuse-mount")
    _mount_thread.start()
    time.sleep(1.0)
    if not _mount_thread.is_alive():
        log.error("FUSE thread died — check /dev/fuse and cap_add: SYS_ADMIN")
        return False
    log.info("Virtual FUSE filesystem mounted at %s", mountpoint)
    return True


def unmount(mountpoint: str):
    """Unmount the FUSE filesystem. Safe to call multiple times."""
    import subprocess
    def _try(cmd):
        try:
            return subprocess.run(cmd, timeout=5, capture_output=True).returncode == 0
        except Exception:
            return False
    ok = (
        _try(["fusermount", "-u",  mountpoint]) or
        _try(["fusermount", "-uz", mountpoint]) or
        _try(["umount", mountpoint]) or
        _try(["umount", "-l", mountpoint])
    )
    if ok:
        log.info("Unmounted %s", mountpoint)
    else:
        log.warning("Could not unmount %s", mountpoint)


def invalidate_stub(stub_id: str):
    """Call after a stub's stream_url changes so cached CDN blocks are dropped."""
    if _fs_instance is None:
        return
    # Find the stub and invalidate its CDN URL blocks
    stub = _fs_instance._stubs.get(stub_id)
    if stub and stub.stream_url:
        _block_cache.invalidate(stub.stream_url)
