"""
gateway/config.py
~~~~~~~~~~~~~~~~~
Connection details and credentials, entered in the GUI and stored
encrypted (see gateway/crypto.py).

Kept separate from gateway/settings.py on purpose: this file holds
secrets and is never returned to the browser in plaintext, while settings
holds preferences that are safe to round-trip through the UI.
"""
from __future__ import annotations

import json
import logging
import os
import threading
from typing import Any

from . import crypto
from .paths import config_file

logger = logging.getLogger("aiogateway.config")

# Fields written to disk as ciphertext and never sent to the browser.
# The URL fields are in here alongside the keys because a private
# AIOStreams or Plex address is itself worth not leaking.
SECRET_FIELDS = {
    "aiostreams_url",
    "aiostreams_uuid",
    "aiostreams_password",
    "plex_url",
    "plex_token",
    "radarr_url",
    "radarr_api_key",
    "sonarr_url",
    "sonarr_api_key",
}

_DEFAULTS: dict[str, Any] = {
    # ── AIOStreams ──────────────────────────────────────────────────
    "aiostreams_url": "",
    "aiostreams_uuid": "",
    "aiostreams_password": "",

    # ── Plex ────────────────────────────────────────────────────────
    "plex_url": "",
    "plex_token": "",

    # ── Radarr / Sonarr (Migrate tab) ───────────────────────────────
    "radarr_url": "",
    "radarr_api_key": "",
    "sonarr_url": "",
    "sonarr_api_key": "",

    # ── Setup state ─────────────────────────────────────────────────
    # Flipped once the first-start wizard has been completed. Until
    # then the UI shows the wizard instead of the app.
    "setup_complete": False,
}

_lock = threading.RLock()
_cache: dict[str, Any] = {}
_loaded = False


def _add_debrid_defaults() -> None:
    """Each supported debrid service gets an api_key slot, an enabled
    flag, and its own rate limits. Registered here rather than hardcoded
    so adding a service to gateway/debrid/ is a one-file change."""
    from .debrid import SERVICES
    for svc in SERVICES.values():
        _DEFAULTS[f"debrid_{svc.key}_api_key"] = ""
        _DEFAULTS[f"debrid_{svc.key}_enabled"] = False
        _DEFAULTS[f"debrid_{svc.key}_rpm"] = svc.default_rpm
        _DEFAULTS[f"debrid_{svc.key}_concurrency"] = svc.default_concurrency
        _DEFAULTS[f"debrid_{svc.key}_spacing_ms"] = svc.default_spacing_ms
        SECRET_FIELDS.add(f"debrid_{svc.key}_api_key")


def load() -> dict[str, Any]:
    global _loaded
    with _lock:
        if _loaded:
            return dict(_cache)
        _add_debrid_defaults()
        data = dict(_DEFAULTS)
        path = config_file()
        if path.exists():
            try:
                data.update(json.loads(path.read_text()))
            except Exception as exc:
                logger.error("config.json unreadable (%s) — using defaults", exc)
        _cache.clear()
        _cache.update(data)
        _loaded = True
        return dict(_cache)


def _persist() -> None:
    path = config_file()
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(_cache, indent=2))
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def get(key: str, default: Any = None) -> Any:
    """Raw stored value — still ciphertext for secret fields. Callers
    that need a usable value should use `secret()`."""
    load()
    with _lock:
        return _cache.get(key, _DEFAULTS.get(key, default))


def secret(key: str) -> str:
    """Decrypted value of a secret field, ready to use in a request."""
    return crypto.decrypt(get(key, ""))


def set_many(updates: dict[str, Any]) -> None:
    """Write a batch of values, encrypting anything in SECRET_FIELDS.

    A secret whose incoming value is the masked placeholder is skipped,
    so a form that round-trips '••••abcd' back to the server doesn't
    overwrite the real key with dots.
    """
    load()
    with _lock:
        for key, value in updates.items():
            if key not in _DEFAULTS:
                continue
            if key in SECRET_FIELDS:
                if isinstance(value, str) and value.startswith("•"):
                    continue
                _cache[key] = crypto.encrypt((value or "").strip())
            else:
                _cache[key] = value
        _persist()


def is_configured() -> bool:
    """True once both required connections are filled in. The wizard
    tests each one before it lets the user submit, so reaching this state
    means both were reachable at least once."""
    return bool(
        secret("aiostreams_url")
        and secret("aiostreams_uuid")
        and secret("plex_url")
        and secret("plex_token")
    )


def public_view() -> dict[str, Any]:
    """What the Config UI is allowed to see: every non-secret value
    verbatim, and every secret reduced to a mask plus a `_set` flag."""
    load()
    out: dict[str, Any] = {}
    with _lock:
        for key in _DEFAULTS:
            if key in SECRET_FIELDS:
                plain = crypto.decrypt(_cache.get(key, ""))
                out[key] = crypto.mask(plain)
                out[f"{key}_set"] = bool(plain)
            else:
                out[key] = _cache.get(key)
    return out


def aiostreams() -> tuple[str, str, str]:
    return (
        secret("aiostreams_url").rstrip("/"),
        secret("aiostreams_uuid"),
        secret("aiostreams_password"),
    )


def plex() -> tuple[str, str]:
    return secret("plex_url").rstrip("/"), secret("plex_token")


def debrid_key(service_key: str) -> str:
    return secret(f"debrid_{service_key}_api_key")


def debrid_enabled(service_key: str) -> bool:
    return bool(get(f"debrid_{service_key}_enabled")) and bool(debrid_key(service_key))


def debrid_limits(service_key: str) -> dict[str, float]:
    from .debrid import SERVICES
    svc = SERVICES[service_key]
    return {
        "rpm": float(get(f"debrid_{service_key}_rpm") or svc.default_rpm),
        "concurrency": int(get(f"debrid_{service_key}_concurrency") or svc.default_concurrency),
        "spacing_ms": float(get(f"debrid_{service_key}_spacing_ms") or svc.default_spacing_ms),
    }
