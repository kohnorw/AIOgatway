"""
gateway/quality_unavailable.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Tracks items — a movie, or a specific episode — where a scan has
already confirmed 4K genuinely isn't available: either AIOStreams
returned zero 4K-flagged candidates at all, or every 4K candidate that
did show up turned out to be dead. Once marked, every automatic path
that would otherwise try 4K skips it entirely for that exact item —
create_stubs()'s normal has_4k auto-detection,
auto-episode discovery, the pending-movies retry sweep — so a title
that's simply never going to have 4K doesn't get re-attempted forever.

The only way to check again is the manual "Scan 4K" button, which
explicitly bypasses this (see main.py's scan_movie_quality/
scan_season_quality) — and clears the mark automatically if it succeeds,
since a working 4K stream is proof the "unavailable" mark was outdated.

Same persistence pattern as pending_movies.py — a flat JSON file, loaded
once and kept in memory, written back on every change.
"""
from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger("aiogateway.qualityunavailable")

# key -> {key, imdb_id, season, episode, title, poster, marked_at}
_marked: dict[str, dict] = {}
_loaded = False


def key_for(imdb_id: str, season: Optional[int] = None, episode: Optional[int] = None) -> str:
    """Movies: just the imdb_id. Episodes: imdb_id:season:episode — 4K
    availability is checked per-episode, not per-show, since it commonly
    varies episode to episode within the same series."""
    if season is not None and episode is not None:
        return f"{imdb_id}:{season}:{episode}"
    return imdb_id


def _state_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_quality_unavailable.json"


def _load() -> None:
    global _marked, _loaded
    if _loaded:
        return
    path = _state_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text())
            _marked = {item["key"]: item for item in raw}
            logger.info("Loaded %d 4K-unavailable mark(s) from %s", len(_marked), path)
    except Exception as exc:
        logger.warning("Could not load quality-unavailable marks from %s: %s", path, exc)
        _marked = {}
    _loaded = True


def _persist() -> None:
    path = _state_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(list(_marked.values()), indent=2))
    except Exception as exc:
        logger.warning("Could not persist quality-unavailable marks to %s: %s", path, exc)


def mark(imdb_id: str, title: str, season: Optional[int] = None,
         episode: Optional[int] = None, poster: str = "") -> None:
    key = key_for(imdb_id, season, episode)
    _load()
    _marked[key] = {
        "key": key, "imdb_id": imdb_id, "season": season, "episode": episode,
        "title": title, "poster": poster, "marked_at": time.time(),
    }
    _persist()
    logger.info("Marked 4K unavailable: %s (%s)", title, key)


def unmark(imdb_id: str, season: Optional[int] = None, episode: Optional[int] = None) -> bool:
    key = key_for(imdb_id, season, episode)
    _load()
    if key in _marked:
        del _marked[key]
        _persist()
        logger.info("Cleared 4K-unavailable mark: %s", key)
        return True
    return False


def is_marked(imdb_id: str, season: Optional[int] = None, episode: Optional[int] = None) -> bool:
    _load()
    return key_for(imdb_id, season, episode) in _marked


def list_all() -> list[dict]:
    _load()
    return list(_marked.values())
