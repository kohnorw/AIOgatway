"""
gateway/fourk_retry.py
~~~~~~~~~~~~~~~~~~~~~~
When a title (a movie, or one specific episode) gets its HD stub but no
4K stub because no 4K release was found, it is queued here. A background
loop (main.py's _fourk_retry_loop) re-checks every queued item once an
hour. If 4K turns up, the 4K stub is created and the item leaves the
queue. If 24 hours pass with nothing, the item is dropped and marked in
quality_unavailable, so the normal automatic paths stop trying (the
manual "Scan 4K" button, and the Keep Cached repair pass, still work).
"""
from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger("aiogateway.fourkretry")

RETRY_INTERVAL_SECONDS = 3600        # every hour
RETRY_WINDOW_SECONDS   = 24 * 3600   # for 24 hours

# key -> {key, imdb_id, season, episode, title, show_title, year, poster,
#         media_type, first_seen, last_attempt, attempts}
_items: dict[str, dict] = {}
_loaded = False


def key_for(imdb_id: str, season: Optional[int] = None, episode: Optional[int] = None) -> str:
    if season is not None and episode is not None:
        return f"{imdb_id}:{season}:{episode}"
    return imdb_id


def _state_path() -> Path:
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_4k_retry.json"


def _load() -> None:
    global _items, _loaded
    if _loaded:
        return
    path = _state_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text())
            _items = {item["key"]: item for item in raw if item.get("key")}
            logger.info("Loaded %d pending 4K retr(y/ies) from %s", len(_items), path)
    except Exception as exc:
        logger.warning("Could not load 4K retry queue from %s: %s", path, exc)
        _items = {}
    _loaded = True


def _persist() -> None:
    path = _state_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(list(_items.values()), indent=2))
        tmp.replace(path)
    except Exception as exc:
        logger.warning("Could not persist 4K retry queue to %s: %s", path, exc)


def enqueue(imdb_id: str, title: str, media_type: str, *, season: Optional[int] = None,
            episode: Optional[int] = None, show_title: str = "", year: Optional[int] = None,
            poster: str = "") -> bool:
    """Queue an item for hourly 4K re-checks. No-op (returns False) if it
    is already queued — the 24h window runs from the FIRST miss."""
    _load()
    key = key_for(imdb_id, season, episode)
    if key in _items:
        return False
    now = time.time()
    _items[key] = {
        "key": key, "imdb_id": imdb_id, "season": season, "episode": episode,
        "title": title, "show_title": show_title or title, "year": year,
        "poster": poster or "", "media_type": media_type,
        "first_seen": now, "last_attempt": now, "attempts": 0,
    }
    _persist()
    logger.info("4K not found for %s — will re-check hourly for 24h", key)
    return True


def discard(imdb_id: str, season: Optional[int] = None, episode: Optional[int] = None) -> bool:
    _load()
    key = key_for(imdb_id, season, episode)
    if key in _items:
        del _items[key]
        _persist()
        return True
    return False


def discard_title(imdb_id: str) -> int:
    """Drop every queued entry for a title (movie or all its episodes)."""
    _load()
    keys = [k for k, v in _items.items() if v.get("imdb_id") == imdb_id]
    for k in keys:
        del _items[k]
    if keys:
        _persist()
    return len(keys)


def record_attempt(key: str) -> None:
    _load()
    e = _items.get(key)
    if e:
        e["last_attempt"] = time.time()
        e["attempts"] = int(e.get("attempts") or 0) + 1
        _persist()


def due(now: Optional[float] = None) -> tuple[list[dict], list[dict]]:
    """Return (to_retry, expired). to_retry: still inside the 24h window
    and at least an hour since the last attempt. expired: window over."""
    _load()
    now = now or time.time()
    to_retry, expired = [], []
    for e in _items.values():
        if now - e.get("first_seen", now) >= RETRY_WINDOW_SECONDS:
            expired.append(e)
        elif now - e.get("last_attempt", 0) >= RETRY_INTERVAL_SECONDS:
            to_retry.append(e)
    return to_retry, expired


def list_all() -> list[dict]:
    _load()
    return list(_items.values())
