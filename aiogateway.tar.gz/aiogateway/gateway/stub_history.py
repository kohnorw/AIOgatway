"""
gateway/stub_history.py
~~~~~~~~~~~~~~~~~~~~~~~
A small persistent ledger of facts about a stub that must OUTLIVE the
stub object itself.

Why this exists
---------------
Everything the app knew about a stub used to live on the Stub instance
and its sidecar .json. remove_stub() deletes both. That was fine while
removal meant "gone for good", but it isn't: the auto-episode sweep
re-discovers any aired episode of a requested season that has no stub,
and re-creates it. The rebuilt Stub is a brand-new object with
created_at=now and error_count=0.

That produced a loop with no exit:

    prewarm probes episode → all candidates dead → remove_stub()
      → auto-episode sweep sees a missing aired episode → re-stubs it
      → new-stub callback fires → prewarm sees created_at=now, calls it
        "newly added", probes the same dead candidates → remove_stub()
      → ...

Each of the three things that should have stopped it was stored on the
object being deleted: _prewarm_last_attempt is explicitly cleared on the
dead path, in_error_cooldown reads error_count off the stub, and
auto_episodes' _pending timer is cleared whenever stubbing SUCCEEDS —
which it does, since it's the later probe that fails, not the stubbing.

So this file keeps the two facts that need to survive deletion, keyed by
stub_id (deterministic: sha256(media_id:quality), so a rebuilt stub maps
to the same record):

  first_seen_at — when this media+quality was FIRST stubbed, ever.
                  created_at means "when this object was built" and
                  resets on every recreation, which is what made a 2003
                  episode read as new content. Prewarm eligibility uses
                  this instead.

  dead_count /  — how many times resolution has been attempted and found
  last_dead_at    every candidate dead. Drives an escalating backoff and
                  eventually a permanent stop, so a title with no working
                  sources is tried a few times and then left alone.

Deliberately NOT a blocklist: a manual add, a manual search, or a real
play all clear the record (see forget()), because those are a person
saying "I want this, try again". This only governs automatic behaviour.
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger("aiogateway.stubhistory")

# stub_id -> {stub_id, label, first_seen_at, dead_count, last_dead_at}
_records: dict[str, dict] = {}
_loaded = False
_lock = threading.Lock()

# Escalating backoff after a dead-removal, by dead_count. After the last
# entry is reached (see _MAX_DEAD_ATTEMPTS) automatic retries stop
# entirely rather than continuing on the longest interval — a title whose
# every candidate has been dead five separate times over three weeks is
# not going to be fixed by a sixth automatic attempt.
_DEAD_BACKOFF_S = [
    6 * 3600,        # 6 hours
    24 * 3600,       # 1 day
    3 * 86400,       # 3 days
    7 * 86400,       # 1 week
    21 * 86400,      # 3 weeks
]
_MAX_DEAD_ATTEMPTS = len(_DEAD_BACKOFF_S)

# Records for stubs that are alive and healthy still cost a little disk
# and load time; prune ones that are neither dead-marked nor referenced
# by a live stub after this long.
_STALE_RECORD_S = 180 * 86400


def _state_path() -> Path:
    # Same convention as pending_movies/wanted_seasons — alongside the
    # other app state, next to the FUSE mountpoint.
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_stub_history.json"


def _load() -> None:
    global _records, _loaded
    if _loaded:
        return
    path = _state_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text())
            _records = {r["stub_id"]: r for r in raw if r.get("stub_id")}
            dead = sum(1 for r in _records.values() if r.get("dead_count"))
            logger.info("Loaded %d stub history record(s) (%d dead-marked) from %s",
                        len(_records), dead, path)
    except Exception as exc:
        logger.warning("Could not load stub history from %s: %s", path, exc)
        _records = {}
    _loaded = True


def _persist() -> None:
    path = _state_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(list(_records.values()), indent=2))
        tmp.replace(path)          # atomic — never leave a half-written ledger
    except Exception as exc:
        logger.warning("Could not persist stub history to %s: %s", path, exc)


def _rec(stub_id: str) -> dict:
    r = _records.get(stub_id)
    if r is None:
        r = {"stub_id": stub_id, "label": "", "first_seen_at": None,
             "dead_count": 0, "last_dead_at": None}
        _records[stub_id] = r
    return r


# ── first_seen_at ──────────────────────────────────────────────────────────

def note_created(stub_id: str, created_at: float, label: str = "") -> float:
    """
    Record that a stub exists, and return the timestamp at which this
    media+quality was FIRST seen — which is the existing recorded value
    if there is one, otherwise `created_at`.

    Called from _create_one, so a stub rebuilt after a dead-removal
    inherits its original first-seen time instead of looking brand new.
    """
    _load()
    with _lock:
        r = _rec(stub_id)
        if label:
            r["label"] = label
        if r["first_seen_at"] is None:
            r["first_seen_at"] = created_at
            _persist()
        return r["first_seen_at"]


def first_seen(stub_id: str) -> Optional[float]:
    """Recorded first-seen timestamp, or None if never recorded."""
    _load()
    return (_records.get(stub_id) or {}).get("first_seen_at")


# ── dead tracking ──────────────────────────────────────────────────────────

def record_dead(stub_id: str, label: str = "") -> int:
    """
    Note that every candidate for this stub was dead and it's being
    removed. Returns the new attempt count.
    """
    _load()
    with _lock:
        r = _rec(stub_id)
        if label:
            r["label"] = label
        r["dead_count"]  = int(r.get("dead_count") or 0) + 1
        r["last_dead_at"] = time.time()
        _persist()
        return r["dead_count"]


def dead_state(stub_id: str) -> tuple[int, Optional[float]]:
    """(dead_count, last_dead_at) for this stub — (0, None) if unknown."""
    _load()
    r = _records.get(stub_id) or {}
    return int(r.get("dead_count") or 0), r.get("last_dead_at")


def suppressed(stub_id: str) -> bool:
    """
    True if automatic machinery should leave this alone right now: either
    it's inside the backoff window after a dead-removal, or it has hit
    _MAX_DEAD_ATTEMPTS and automatic retries have stopped for good.

    Consulted by BOTH sides of the old loop — prewarm before probing, and
    auto-episode discovery before re-stubbing — because suppressing only
    one of them just moves where the churn happens.
    """
    count, last = dead_state(stub_id)
    if count <= 0 or last is None:
        return False
    if count >= _MAX_DEAD_ATTEMPTS:
        return True
    return (time.time() - last) < _DEAD_BACKOFF_S[count - 1]


def retry_at(stub_id: str) -> Optional[float]:
    """When this stub next becomes retryable, or None if it never does
    automatically (or isn't suppressed at all). For UI/logging."""
    count, last = dead_state(stub_id)
    if count <= 0 or last is None:
        return None
    if count >= _MAX_DEAD_ATTEMPTS:
        return None
    return last + _DEAD_BACKOFF_S[count - 1]


def permanently_dead(stub_id: str) -> bool:
    """Hit the attempt ceiling — no further automatic retries, ever."""
    count, _ = dead_state(stub_id)
    return count >= _MAX_DEAD_ATTEMPTS


def clear_dead(stub_id: str) -> None:
    """
    A working stream was found — reset the dead counter but KEEP
    first_seen_at, which is still true and still wanted.
    """
    _load()
    with _lock:
        r = _records.get(stub_id)
        if not r or not r.get("dead_count"):
            return
        r["dead_count"]   = 0
        r["last_dead_at"] = None
        _persist()


def forget(stub_id: str) -> None:
    """
    Drop the whole record. For deliberate human actions — a manual
    re-add, a manual stream pick — where the person is explicitly asking
    for a fresh start, including a reset of first_seen_at.
    """
    _load()
    with _lock:
        if _records.pop(stub_id, None) is not None:
            _persist()


# ── maintenance / introspection ────────────────────────────────────────────

def all_dead() -> list[dict]:
    """Every dead-marked record, newest first — backs the UI listing."""
    _load()
    out = [dict(r) for r in _records.values() if r.get("dead_count")]
    out.sort(key=lambda r: r.get("last_dead_at") or 0, reverse=True)
    for r in out:
        r["permanently_dead"] = r["dead_count"] >= _MAX_DEAD_ATTEMPTS
        r["retry_at"] = retry_at(r["stub_id"])
    return out


def clear_all_dead() -> int:
    """Reset every dead marker — the "try everything again" escape hatch."""
    _load()
    with _lock:
        n = 0
        for r in _records.values():
            if r.get("dead_count"):
                r["dead_count"]   = 0
                r["last_dead_at"] = None
                n += 1
        if n:
            _persist()
        return n


def prune(live_stub_ids: set[str]) -> int:
    """
    Drop records that are neither dead-marked nor backing a live stub and
    haven't been touched in _STALE_RECORD_S. Called at startup.
    """
    _load()
    now = time.time()
    with _lock:
        drop = [
            sid for sid, r in _records.items()
            if not r.get("dead_count")
            and sid not in live_stub_ids
            and (r.get("first_seen_at") or now) < now - _STALE_RECORD_S
        ]
        for sid in drop:
            _records.pop(sid, None)
        if drop:
            _persist()
        return len(drop)
