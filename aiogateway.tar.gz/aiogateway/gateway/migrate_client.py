"""
gateway/migrate_client.py
~~~~~~~~~~~~~~~~~~~~~~~~~~
Talks to a Radarr or Sonarr instance's REST API (v3) to list what the user
already has there, so it can be migrated into aiogateway's own AIOStreams-
backed stubs. This module only ever reads from Radarr/Sonarr — it never
writes anything back to them.

Radarr: GET {url}/api/v3/movie   → every movie, hasFile tells us whether
        Radarr actually has the file (not just monitored/wanted).
Sonarr: GET {url}/api/v3/series  → every series, with a `seasons[]` array;
        each season's statistics.episodeFileCount tells us whether Sonarr
        actually has files for that season.

Both APIs are authenticated with an `X-Api-Key` header.
"""
from __future__ import annotations

import logging
from typing import Optional

import aiohttp

logger = logging.getLogger("aiogateway.migrate")

_TIMEOUT = aiohttp.ClientTimeout(total=20)


class MigrateAPIError(Exception):
    pass


def _headers(api_key: str) -> dict:
    return {"X-Api-Key": api_key, "Accept": "application/json"}


def _poster(images: list) -> str:
    for img in images or []:
        if img.get("coverType") == "poster":
            # remoteUrl is a full externally-reachable URL (TMDB/fanart CDN
            # in Radarr's case); `url` is only a path on the *arr instance
            # itself, which our frontend can't reach directly, so it's not
            # used as a fallback here.
            if img.get("remoteUrl"):
                return img["remoteUrl"]
    return ""


async def test_connection(base_url: str, api_key: str, service: str) -> dict:
    """Hits /api/v3/system/status. Raises MigrateAPIError with a readable
    message on any failure (bad URL, bad key, unreachable host, etc.)."""
    url = f"{base_url.rstrip('/')}/api/v3/system/status"
    try:
        async with aiohttp.ClientSession(timeout=_TIMEOUT) as session:
            async with session.get(url, headers=_headers(api_key)) as resp:
                if resp.status == 401:
                    raise MigrateAPIError("Rejected — check the API key")
                if resp.status != 200:
                    raise MigrateAPIError(f"{service.title()} returned HTTP {resp.status}")
                data = await resp.json(content_type=None)
                return {
                    "ok": True,
                    "version": data.get("version", "unknown"),
                    "instance_name": data.get("instanceName", service.title()),
                }
    except aiohttp.ClientConnectorError as exc:
        raise MigrateAPIError(f"Could not reach {base_url} — {exc}")
    except MigrateAPIError:
        raise
    except Exception as exc:
        raise MigrateAPIError(str(exc))


async def fetch_radarr_movies(base_url: str, api_key: str) -> list[dict]:
    """Every Radarr movie that actually has a downloaded file, normalized to
    the shape the migration UI/endpoints expect."""
    url = f"{base_url.rstrip('/')}/api/v3/movie"
    try:
        async with aiohttp.ClientSession(timeout=_TIMEOUT) as session:
            async with session.get(url, headers=_headers(api_key)) as resp:
                if resp.status == 401:
                    raise MigrateAPIError("Rejected — check the API key")
                if resp.status != 200:
                    raise MigrateAPIError(f"Radarr returned HTTP {resp.status}")
                movies = await resp.json(content_type=None)
    except aiohttp.ClientConnectorError as exc:
        raise MigrateAPIError(f"Could not reach {base_url} — {exc}")
    except MigrateAPIError:
        raise
    except Exception as exc:
        raise MigrateAPIError(str(exc))

    out = []
    for m in movies:
        if not m.get("hasFile"):
            continue
        imdb_id = m.get("imdbId")
        if not imdb_id:
            # Nothing we can key a stub on — skip rather than guess.
            continue
        out.append({
            "imdb_id": imdb_id,
            "title":   m.get("title") or "Untitled",
            "year":    m.get("year"),
            "poster":  _poster(m.get("images")),
        })
    out.sort(key=lambda x: x["title"].lower())
    return out


async def fetch_sonarr_series(base_url: str, api_key: str) -> list[dict]:
    """Every Sonarr series that has an imdbId, with only the seasons Sonarr
    actually has episode files for (not just monitored/wanted seasons)."""
    url = f"{base_url.rstrip('/')}/api/v3/series"
    try:
        async with aiohttp.ClientSession(timeout=_TIMEOUT) as session:
            async with session.get(url, headers=_headers(api_key)) as resp:
                if resp.status == 401:
                    raise MigrateAPIError("Rejected — check the API key")
                if resp.status != 200:
                    raise MigrateAPIError(f"Sonarr returned HTTP {resp.status}")
                series_list = await resp.json(content_type=None)
    except aiohttp.ClientConnectorError as exc:
        raise MigrateAPIError(f"Could not reach {base_url} — {exc}")
    except MigrateAPIError:
        raise
    except Exception as exc:
        raise MigrateAPIError(str(exc))

    out = []
    for s in series_list:
        imdb_id = s.get("imdbId")
        if not imdb_id:
            continue
        seasons_with_files = []
        for season in s.get("seasons") or []:
            stats = season.get("statistics") or {}
            if (stats.get("episodeFileCount") or 0) > 0:
                seasons_with_files.append({
                    "season_number": season.get("seasonNumber"),
                    "episode_file_count": stats.get("episodeFileCount"),
                })
        if not seasons_with_files:
            continue
        # Season 0 is Sonarr's convention for specials — skip it, matching
        # how the rest of aiogateway treats season 0 (see /api/series/*
        # episode listing, which drops sn == 0 for the same reason).
        seasons_with_files = [s2 for s2 in seasons_with_files if s2["season_number"] != 0]
        if not seasons_with_files:
            continue
        seasons_with_files.sort(key=lambda x: x["season_number"])
        out.append({
            "imdb_id": imdb_id,
            "title":   s.get("title") or "Untitled",
            "year":    s.get("year"),
            "poster":  _poster(s.get("images")),
            "seasons": seasons_with_files,
        })
    out.sort(key=lambda x: x["title"].lower())
    return out
