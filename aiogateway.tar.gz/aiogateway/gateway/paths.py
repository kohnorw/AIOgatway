"""
gateway/paths.py
~~~~~~~~~~~~~~~~
Every on-disk location in one place.

Only two environment variables exist in the whole application, both with
working defaults, because the runbook asks for a compose file that can be
pasted without editing. Everything else is configured in the GUI.
"""
from __future__ import annotations

import os
from pathlib import Path

_DEFAULT_DATA = "/docker/aiogateway"


def data_dir() -> Path:
    """Persistent state: config, library, users, sessions, encryption key."""
    p = Path(os.environ.get("AIOGW_DATA", _DEFAULT_DATA))
    p.mkdir(parents=True, exist_ok=True)
    return p


def mountpoint() -> str:
    """Where the virtual filesystem is mounted. Plex points here."""
    mp = os.environ.get("AIOGW_MOUNTPOINT") or str(data_dir() / "mnt")
    return mp.rstrip("/")


def config_file() -> Path:
    return data_dir() / "config.json"


def settings_file() -> Path:
    return data_dir() / "settings.json"


def library_file() -> Path:
    return data_dir() / "library.json"


def users_file() -> Path:
    return data_dir() / "users.json"


def sessions_file() -> Path:
    return data_dir() / "sessions.json"


def client_id_file() -> Path:
    return data_dir() / "plex_client_id.json"


def meta_cache_file() -> Path:
    return data_dir() / "meta_cache.json"
