"""
gateway/aiostreams_client.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Connects to the real AIOStreams /api/v1/search endpoint.

Environment variables (read at call time):
  AIOSTREAMS_URL       — e.g. http://192.168.1.x:3000
  AIOSTREAMS_UUID      — your user UUID from AIOStreams Settings page
  AIOSTREAMS_PASSWORD  — your password from AIOStreams Settings page

If AIOSTREAMS_UUID is empty the client returns stub data for testing.
"""
from __future__ import annotations

import asyncio
import base64
import logging
import os
from typing import AsyncIterator

import aiohttp
from aiostream import operator, pipe, stream as astream

from .models import AIOStream, MediaItem, Quality

logger = logging.getLogger("aiogateway.aiostreams")


def _cfg():
    return (
        os.environ.get("AIOSTREAMS_URL",      "http://localhost:3001"),
        os.environ.get("AIOSTREAMS_UUID",     ""),
        os.environ.get("AIOSTREAMS_PASSWORD", ""),
    )


def _auth_headers(uuid: str, password: str) -> dict:
    token = base64.b64encode(f"{uuid}:{password}".encode()).decode()
    return {"Authorization": f"Basic {token}"}


# ---------------------------------------------------------------------------
# Stub data — used when AIOSTREAMS_UUID is not set
# ---------------------------------------------------------------------------

def _stub_results(item: MediaItem) -> list[dict]:
    base = f"http://fake-cdn.local/streams/{item.imdb_id}"
    return [
        {
            "url": f"{base}/hd.mkv",
            "filename": f"{item.title}.1080p.BluRay.x265.mkv",
            "size": 8_500_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "1080p", "quality": "BluRay", "encode": "HEVC", "hdr": []},
        },
        {
            "url": f"{base}/4k.mkv",
            "filename": f"{item.title}.2160p.BluRay.DV.HDR10.mkv",
            "size": 42_000_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "2160p", "quality": "BluRay", "encode": "HEVC", "hdr": ["DV", "HDR10"]},
        },
    ]


# ---------------------------------------------------------------------------
# aiostream operators
# ---------------------------------------------------------------------------

@operator
async def _fetch_raw(
    session: aiohttp.ClientSession,
    item: MediaItem,
    url: str,
    uuid: str,
    password: str,
) -> AsyncIterator[dict]:
    """Yield raw SearchApiResult dicts that have a direct stream URL."""

    if not uuid:
        logger.warning("AIOSTREAMS_UUID not set — using stub data")
        await asyncio.sleep(0.05)
        for r in _stub_results(item):
            yield r
        return

    endpoint = f"{url}/api/v1/search"
    params   = {"type": item.aiostreams_type, "id": item.aiostreams_id}
    headers  = _auth_headers(uuid, password)

    logger.info("AIOStreams query: %s %s", endpoint, params)

    try:
        async with session.get(
            endpoint, params=params, headers=headers,
            timeout=aiohttp.ClientTimeout(total=30)
        ) as resp:
            if resp.status == 401:
                raise RuntimeError(
                    "AIOStreams: invalid credentials (401). "
                    "Check AIOSTREAMS_UUID and AIOSTREAMS_PASSWORD in docker-compose.yml."
                )
            if resp.status == 404:
                raise RuntimeError(
                    "AIOStreams: /api/v1/search not found (404). "
                    "Check AIOSTREAMS_URL — should be http://host:3000 (not 3001)."
                )
            resp.raise_for_status()
            data = await resp.json()
    except aiohttp.ClientConnectorError as exc:
        raise RuntimeError(
            f"Cannot connect to AIOStreams at {url}. "
            "Check AIOSTREAMS_URL and that AIOStreams is running."
        ) from exc

    if not data.get("success"):
        err = (data.get("error") or {}).get("message", "unknown error")
        raise RuntimeError(f"AIOStreams returned error: {err}")

    results = (data.get("data") or {}).get("results", [])
    errors  = (data.get("data") or {}).get("errors", [])
    total   = len(results)
    logger.info("AIOStreams returned %d total results", total)

    if errors:
        for e in errors:
            logger.warning("AIOStreams addon error — %s: %s", e.get("title",""), e.get("description",""))

    # Diagnose empty results so the user knows exactly why
    if total == 0:
        # Build a helpful message for the 404 response the UI will show
        err_titles = [e.get("title","") for e in errors]
        if errors:
            msg = (
                f"AIOStreams returned 0 results. Addon errors: "
                + "; ".join(e.get("description", e.get("title","")) for e in errors[:3])
                + ". Make sure your debrid service is configured in AIOStreams."
            )
        else:
            msg = (
                "AIOStreams returned 0 results with no errors. "
                "This usually means: (1) no addons are installed in AIOStreams, "
                "(2) no debrid service is configured, or "
                "(3) this title has no streams available from your configured addons. "
                f"Check the AIOStreams config page at {url}/stremio/configure"
            )
        raise RuntimeError(msg)

    yielded = 0
    for r in results:
        if r.get("url"):    # only results with a direct HTTP URL
            yield r
            yielded += 1

    logger.info("Yielded %d results with direct URLs (out of %d total)", yielded, total)

    # If results exist but none have a url, give a specific diagnosis
    if yielded == 0 and total > 0:
        sample = results[0]
        has_infoHash = any(r.get("infoHash") for r in results[:5])
        raise RuntimeError(
            f"AIOStreams returned {total} result(s) but none have a direct stream URL. "
            + ("Results appear to be raw torrents (infoHash present) — "
               "configure a debrid service (Real-Debrid, AllDebrid, etc.) in AIOStreams "
               "so torrents are resolved to direct HTTP URLs." if has_infoHash else
               "Check your debrid service configuration in AIOStreams.")
        )


@operator
async def _parse(raw: dict) -> AsyncIterator[AIOStream]:
    yield AIOStream.from_api(raw)


# ---------------------------------------------------------------------------
# Public client
# ---------------------------------------------------------------------------

class AIOStreamsClient:
    """Async client for AIOStreams /api/v1/search."""

    def __init__(self) -> None:
        self._session: aiohttp.ClientSession | None = None

    async def open(self) -> None:
        self._session = aiohttp.ClientSession()

    async def close(self) -> None:
        if self._session:
            await self._session.close()
            self._session = None

    def stream_results(self, item: MediaItem):
        assert self._session
        aio_url, uuid, password = _cfg()
        raw = _fetch_raw(self._session, item, aio_url, uuid, password)
        return raw | pipe.flatmap(lambda d: _parse(d))

    def stream_4k(self, item: MediaItem):
        return self.stream_results(item) | pipe.filter(lambda s: s.is_4k)

    def stream_hd(self, item: MediaItem):
        return self.stream_results(item) | pipe.filter(lambda s: not s.is_4k)

    async def resolve_all(self, item: MediaItem) -> list[AIOStream]:
        return await astream.list(self.stream_results(item))

    async def best_for_quality(self, item: MediaItem, quality: Quality) -> AIOStream | None:
        src = self.stream_4k(item) if quality == Quality.UHD else self.stream_hd(item)
        all_s = await astream.list(src)
        cached = [s for s in all_s if s.cached]
        return (cached or all_s or [None])[0]

    async def connection_test(self) -> dict:
        """Test connectivity and return a diagnostic dict."""
        aio_url, uuid, password = _cfg()
        result = {
            "url": aio_url,
            "uuid_set": bool(uuid),
            "ok": False,
            "error": None,
            "status_code": None,
            "diagnosis": None,
        }
        if not uuid:
            result["error"] = "AIOSTREAMS_UUID not set — running in stub mode"
            result["diagnosis"] = "stub"
            return result
        try:
            async with self._session.get(
                f"{aio_url}/api/v1/search",
                params={"type": "movie", "id": "tt0068646"},   # The Godfather — widely indexed
                headers=_auth_headers(uuid, password),
                timeout=aiohttp.ClientTimeout(total=8),
            ) as resp:
                result["status_code"] = resp.status
                if resp.status == 401:
                    result["error"] = "Invalid credentials (401)"
                    result["diagnosis"] = "bad_auth"
                elif resp.status == 200:
                    data = await resp.json()
                    results = (data.get("data") or {}).get("results", [])
                    errors  = (data.get("data") or {}).get("errors", [])
                    with_url = [r for r in results if r.get("url")]
                    result["ok"] = True
                    result["total_results"] = len(results)
                    result["direct_urls"] = len(with_url)
                    result["addon_errors"] = len(errors)
                    if len(results) == 0:
                        result["diagnosis"] = "no_addons"
                        result["error"] = (
                            f"Connected but 0 results returned. "
                            f"No addons or debrid configured in AIOStreams. "
                            f"Visit {aio_url}/stremio/configure"
                        )
                        result["ok"] = False
                    elif len(with_url) == 0:
                        result["diagnosis"] = "no_debrid"
                        result["error"] = (
                            f"Connected, {len(results)} results, but none have a direct URL. "
                            "Add a debrid service (Real-Debrid etc.) in AIOStreams."
                        )
                        result["ok"] = False
                    else:
                        result["diagnosis"] = "ok"
                else:
                    result["error"] = f"HTTP {resp.status}"
        except Exception as exc:
            result["error"] = str(exc)
            result["diagnosis"] = "unreachable"
        return result
