"""
gateway/aiostreams_client.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Connects to the real AIOStreams /api/v1/search endpoint.

Auth: Basic auth  →  Authorization: Basic base64(uuid:password)
      OR x-aiostreams-user-data header with base64-encoded UserData JSON

Environment variables (read at call time, not import time):
  AIOSTREAMS_URL       — e.g. http://192.168.1.x:3001
  AIOSTREAMS_UUID      — your user UUID from AIOStreams Settings
  AIOSTREAMS_PASSWORD  — your password from AIOStreams Settings

If AIOSTREAMS_UUID is empty the client returns stub data so you can
test the rest of the system without a live AIOStreams instance.
"""
from __future__ import annotations

import asyncio
import base64
import logging
import os
from typing import AsyncIterator

import aiohttp
from aiostream import operator, pipe, stream as astream

from .models import AIOStream, MediaItem, Quality

logger = logging.getLogger("aiogateway.aiostreams")

CHUNK = 256 * 1024


def _cfg():
    return (
        os.environ.get("AIOSTREAMS_URL",      "http://localhost:3001"),
        os.environ.get("AIOSTREAMS_UUID",     ""),
        os.environ.get("AIOSTREAMS_PASSWORD", ""),
    )


def _auth_headers(uuid: str, password: str) -> dict:
    token = base64.b64encode(f"{uuid}:{password}".encode()).decode()
    return {"Authorization": f"Basic {token}"}


# ---------------------------------------------------------------------------
# Stub data — used when AIOSTREAMS_UUID is not set
# ---------------------------------------------------------------------------

def _stub_results(item: MediaItem) -> list[dict]:
    base = f"http://fake-cdn.local/streams/{item.imdb_id}"
    results = [
        {
            "url": f"{base}/hd.mkv",
            "filename": f"{item.title}.1080p.BluRay.x265.mkv",
            "size": 8_500_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "1080p", "quality": "BluRay", "encode": "HEVC", "hdr": []},
        },
        {
            "url": f"{base}/4k.mkv",
            "filename": f"{item.title}.2160p.BluRay.DV.HDR10.mkv",
            "size": 42_000_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "2160p", "quality": "BluRay", "encode": "HEVC", "hdr": ["DV", "HDR10"]},
        },
    ]
    return results


# ---------------------------------------------------------------------------
# aiostream operators
# ---------------------------------------------------------------------------

@operator
async def _fetch_raw(
    session: aiohttp.ClientSession,
    item: MediaItem,
    url: str,
    uuid: str,
    password: str,
) -> AsyncIterator[dict]:
    """Yield raw SearchApiResult dicts that have a direct stream URL."""

    if not uuid:
        logger.warning("AIOSTREAMS_UUID not set — using stub data")
        await asyncio.sleep(0.05)
        for r in _stub_results(item):
            yield r
        return

    endpoint = f"{url}/api/v1/search"
    params   = {"type": item.aiostreams_type, "id": item.aiostreams_id}
    headers  = _auth_headers(uuid, password)

    logger.info("AIOStreams query: %s %s", endpoint, params)

    try:
        async with session.get(
            endpoint, params=params, headers=headers, timeout=aiohttp.ClientTimeout(total=30)
        ) as resp:
            if resp.status == 401:
                raise RuntimeError("AIOStreams: invalid credentials (401). Check AIOSTREAMS_UUID and AIOSTREAMS_PASSWORD.")
            if resp.status == 404:
                raise RuntimeError("AIOStreams: /api/v1/search not found (404). Check AIOSTREAMS_URL.")
            resp.raise_for_status()
            data = await resp.json()
    except aiohttp.ClientConnectorError as exc:
        raise RuntimeError(
            f"Cannot connect to AIOStreams at {url}. "
            "Check AIOSTREAMS_URL and that AIOStreams is running."
        ) from exc

    if not data.get("success"):
        err = (data.get("error") or {}).get("message", "unknown error")
        raise RuntimeError(f"AIOStreams returned error: {err}")

    results = (data.get("data") or {}).get("results", [])
    logger.info("AIOStreams returned %d total results", len(results))

    yielded = 0
    for r in results:
        if r.get("url"):    # only results with a direct HTTP URL
            yield r
            yielded += 1

    logger.info("Yielded %d results with direct URLs", yielded)


@operator
async def _parse(raw: dict) -> AsyncIterator[AIOStream]:
    yield AIOStream.from_api(raw)


# ---------------------------------------------------------------------------
# Public client
# ---------------------------------------------------------------------------

class AIOStreamsClient:
    """Async client for AIOStreams /api/v1/search."""

    def __init__(self) -> None:
        self._session: aiohttp.ClientSession | None = None

    async def open(self) -> None:
        self._session = aiohttp.ClientSession()

    async def close(self) -> None:
        if self._session:
            await self._session.close()
            self._session = None

    # -- streaming API --------------------------------------------------------

    def stream_results(self, item: MediaItem):
        assert self._session
        aio_url, uuid, password = _cfg()
        raw = _fetch_raw(self._session, item, aio_url, uuid, password)
        return raw | pipe.flatmap(lambda d: _parse(d))

    def stream_4k(self, item: MediaItem):
        return self.stream_results(item) | pipe.filter(lambda s: s.is_4k)

    def stream_hd(self, item: MediaItem):
        return self.stream_results(item) | pipe.filter(lambda s: not s.is_4k)

    # -- materialise ----------------------------------------------------------

    async def resolve_all(self, item: MediaItem) -> list[AIOStream]:
        return await astream.list(self.stream_results(item))

    async def best_for_quality(self, item: MediaItem, quality: Quality) -> AIOStream | None:
        src = self.stream_4k(item) if quality == Quality.UHD else self.stream_hd(item)
        all_s = await astream.list(src)
        cached = [s for s in all_s if s.cached]
        return (cached or all_s or [None])[0]

    async def connection_test(self) -> dict:
        """Test connectivity to AIOStreams. Returns status dict."""
        aio_url, uuid, password = _cfg()
        result = {"url": aio_url, "uuid_set": bool(uuid), "ok": False, "error": None}
        try:
            async with self._session.get(
                f"{aio_url}/api/v1/search",
                params={"type": "movie", "id": "tt0000001"},
                headers=_auth_headers(uuid, password) if uuid else {},
                timeout=aiohttp.ClientTimeout(total=5),
            ) as resp:
                result["status_code"] = resp.status
                result["ok"] = resp.status in (200, 404)  # 404 = no results, still connected
        except Exception as exc:
            result["error"] = str(exc)
        return result
