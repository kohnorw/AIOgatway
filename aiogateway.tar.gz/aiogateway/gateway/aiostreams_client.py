"""
gateway/aiostreams_client.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Client for the real AIOStreams REST API.

Endpoint: GET /api/v1/search?type={movie|series}&id={imdb_id}
Auth:     Basic auth  →  Authorization: Basic base64(uuid:password)

Docs: https://docs.aiostreams.viren070.me/apis/search/

The `url` field in each SearchApiResult is the direct HTTP stream URL
that we proxy to Plex. We filter to only results that have a url
(i.e. debrid-resolved, not raw torrents).
"""
from __future__ import annotations

import asyncio
import base64
import os
from typing import AsyncIterator

import aiohttp
from aiostream import operator, pipe, stream

from .models import AIOStream, MediaItem, Quality

# ---------------------------------------------------------------------------
# Config — set via environment or docker-compose
# ---------------------------------------------------------------------------
AIOSTREAMS_URL      = os.getenv("AIOSTREAMS_URL",      "http://localhost:3000")
AIOSTREAMS_UUID     = os.getenv("AIOSTREAMS_UUID",     "")
AIOSTREAMS_PASSWORD = os.getenv("AIOSTREAMS_PASSWORD", "")

def _basic_auth_header() -> dict:
    if AIOSTREAMS_UUID and AIOSTREAMS_PASSWORD:
        token = base64.b64encode(
            f"{AIOSTREAMS_UUID}:{AIOSTREAMS_PASSWORD}".encode()
        ).decode()
        return {"Authorization": f"Basic {token}"}
    return {}


# ---------------------------------------------------------------------------
# Stub data (used when AIOSTREAMS_UUID is not configured)
# ---------------------------------------------------------------------------

def _stub_results(item: MediaItem) -> list[dict]:
    base = f"http://fake-cdn.local/streams/{item.imdb_id}"
    return [
        {
            "url": f"{base}/hd.mkv",
            "filename": f"{item.title}.1080p.BluRay.mkv",
            "size": 8_500_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "1080p", "quality": "BluRay", "encode": "HEVC", "hdr": []},
        },
        {
            "url": f"{base}/4k.mkv",
            "filename": f"{item.title}.2160p.BluRay.DV.mkv",
            "size": 42_000_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "2160p", "quality": "BluRay", "encode": "HEVC", "hdr": ["DV", "HDR10"]},
        },
    ]


# ---------------------------------------------------------------------------
# aiostream operators
# ---------------------------------------------------------------------------

@operator
async def _fetch_raw_results(
    session: aiohttp.ClientSession,
    item: MediaItem,
) -> AsyncIterator[dict]:
    """
    Yield raw SearchApiResult dicts from AIOStreams.
    Only yields results that have a direct url (debrid-resolved).
    """
    if not AIOSTREAMS_UUID:
        await asyncio.sleep(0.05)
        for r in _stub_results(item):
            yield r
        return

    url = f"{AIOSTREAMS_URL}/api/v1/search"
    params = {"type": item.aiostreams_type, "id": item.aiostreams_id}
    headers = _basic_auth_header()

    async with session.get(url, params=params, headers=headers) as resp:
        resp.raise_for_status()
        data = await resp.json()

    if not data.get("success"):
        raise RuntimeError(
            f"AIOStreams error: {data.get('error', {}).get('message', 'unknown')}"
        )

    for result in data.get("data", {}).get("results", []):
        if result.get("url"):   # only yield if we have a direct stream URL
            yield result


@operator
async def _parse_result(raw: dict) -> AsyncIterator[AIOStream]:
    yield AIOStream.from_api_result(raw)


# ---------------------------------------------------------------------------
# Public client
# ---------------------------------------------------------------------------

class AIOStreamsClient:
    """
    Async client for the AIOStreams /api/v1/search REST API.
    All collection methods return aiostream Streams for pipeline composition.
    """

    def __init__(self) -> None:
        self._session: aiohttp.ClientSession | None = None

    async def __aenter__(self) -> "AIOStreamsClient":
        self._session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, *_: object) -> None:
        if self._session:
            await self._session.close()

    # -- aiostream pipeline API -------------------------------------------

    def stream_results(self, item: MediaItem):
        """
        Stream all AIOStream results for a MediaItem.
        Each item has already been filtered to results with a direct url.

        Returns: Stream[AIOStream]
        """
        assert self._session, "Use inside async with AIOStreamsClient()"
        raw = _fetch_raw_results(self._session, item)
        return raw | pipe.flatmap(lambda d: _parse_result(d))

    def stream_4k(self, item: MediaItem):
        """Stream only 4K results."""
        return self.stream_results(item) | pipe.filter(lambda s: s.is_4k)

    def stream_hd(self, item: MediaItem):
        """Stream only HD (non-4K) results."""
        return self.stream_results(item) | pipe.filter(lambda s: not s.is_4k)

    # -- Convenience materialisation methods ------------------------------

    async def resolve_all(self, item: MediaItem) -> list[AIOStream]:
        """Fetch all streams for an item into a list."""
        assert self._session
        return await stream.list(self.stream_results(item))

    async def best_for_quality(
        self, item: MediaItem, quality: Quality
    ) -> AIOStream | None:
        """
        Return the best (cached-preferred) stream for a given quality.
        Re-queries AIOStreams fresh — used at Plex play time.
        """
        assert self._session
        src = self.stream_4k(item) if quality == Quality.UHD else self.stream_hd(item)
        # prefer cached
        all_streams = await stream.list(src)
        cached = [s for s in all_streams if s.cached]
        return (cached or all_streams or [None])[0]
