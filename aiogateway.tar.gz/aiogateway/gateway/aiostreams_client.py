"""
gateway/aiostreams_client.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Connects to the real AIOStreams /api/v1/search endpoint.

Environment variables (read at call time):
  AIOSTREAMS_URL       — e.g. http://192.168.1.x:3000
  AIOSTREAMS_UUID      — your user UUID from AIOStreams Settings page
  AIOSTREAMS_PASSWORD  — your password from AIOStreams Settings page

If AIOSTREAMS_UUID is empty the client returns stub data for testing.
"""
from __future__ import annotations

import asyncio
import base64
import logging
import os
from typing import AsyncIterator, Optional

import aiohttp
from aiostream import operator, pipe, stream as astream

from .models import AIOStream, MediaItem, Quality

logger = logging.getLogger("aiogateway.aiostreams")


def _cfg():
    return (
        os.environ.get("AIOSTREAMS_URL",      "http://localhost:3001"),
        os.environ.get("AIOSTREAMS_UUID",     ""),
        os.environ.get("AIOSTREAMS_PASSWORD", ""),
    )


def _auth_headers(uuid: str, password: str) -> dict:
    token = base64.b64encode(f"{uuid}:{password}".encode()).decode()
    return {"Authorization": f"Basic {token}"}


_PROBE_TIMEOUT = float(os.environ.get("AIOSTREAMS_PROBE_TIMEOUT", "6"))

# ---------------------------------------------------------------------------
# Global rate gate for AIOStreams /api/v1/search queries
# ---------------------------------------------------------------------------
# Every code path that talks to AIOStreams — webhook play-triggered resolves,
# background episode scans (one independent task per tracked show), the
# auto-episode discovery sweep, and bulk migration — all funnel through
# _fetch_raw() below. Each of those call sites already has its own local
# concurrency limit (a semaphore here, a "1s between episodes" there,
# migration's worker pool), but none of them coordinate with each other —
# so e.g. migrating a dozen shows at once spins up a dozen independent
# background scan tasks that all start querying AIOStreams simultaneously,
# on top of migration's own concurrent requests. The result, seen in
# practice: nearly every single query gets rate limited (429), even though
# each individual caller was already pacing itself.
#
# This gate fixes that at the root by capping the ACTUAL outbound request
# rate to AIOStreams app-wide, no matter how many independent tasks are
# trying to query at once — a semaphore alone isn't enough since it only
# limits how many requests are in flight, not how fast new ones are
# launched. Both knobs are env-configurable in case a given AIOStreams/
# debrid setup can tolerate more (or needs less).
_AIOSTREAMS_MAX_CONCURRENT   = int(os.environ.get("AIOSTREAMS_MAX_CONCURRENT", "2"))
_AIOSTREAMS_MIN_INTERVAL_MS  = float(os.environ.get("AIOSTREAMS_MIN_INTERVAL_MS", "500"))


class _RateGate:
    """Caps both how many requests can be in flight at once (a normal
    semaphore) and how fast new ones can be launched (a minimum spacing
    between successive requests) — the two together are what actually
    bound sustained request rate, not just momentary concurrency."""

    def __init__(self, max_concurrent: int, min_interval_ms: float):
        self._sem = asyncio.Semaphore(max(1, max_concurrent))
        self._min_interval = max(0.0, min_interval_ms) / 1000.0
        self._lock = asyncio.Lock()
        self._last_started_at = 0.0

    async def __aenter__(self):
        await self._sem.acquire()
        async with self._lock:
            now = asyncio.get_event_loop().time()
            wait = self._min_interval - (now - self._last_started_at)
            if wait > 0:
                await asyncio.sleep(wait)
            self._last_started_at = asyncio.get_event_loop().time()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self._sem.release()
        return False


_aiostreams_gate = _RateGate(_AIOSTREAMS_MAX_CONCURRENT, _AIOSTREAMS_MIN_INTERVAL_MS)

# A candidate's TOTAL reported size (from Content-Range on the probe
# response, or Content-Length as a fallback) must be at least this large to
# be accepted as real movie/episode video. This catches debrid backends that
# return a 200/206 "success" for a broken/expired link backed by a tiny
# placeholder, error page, or partial/corrupted file — which otherwise pass
# the probe's status-code check while being unmistakably not real content.
# 50MB is comfortably below even a short, heavily compressed TV episode.
_MIN_PLAUSIBLE_MEDIA_BYTES = int(os.environ.get("AIOSTREAMS_MIN_MEDIA_BYTES", str(50 * 1024 * 1024)))


def _parse_total_size(resp) -> Optional[int]:
    """Extract the TOTAL file size from a ranged response, preferring
    Content-Range's total (works even for a 1-byte probe request) and
    falling back to Content-Length (only correct for a non-ranged response)."""
    cr = resp.headers.get("Content-Range", "")
    if cr and "/" in cr:
        try:
            total = cr.rsplit("/", 1)[1].strip()
            if total != "*":
                return int(total)
        except (ValueError, IndexError):
            pass
    cl = resp.headers.get("Content-Length")
    if cl:
        try:
            return int(cl)
        except ValueError:
            pass
    return None


def _filter_by_size(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Hard-filter candidates by min/max_size_gb from settings. Unlike
    preference ranking, these are exclusions, not just a sort order —
    "too small to be the real thing" and "too large for available
    bandwidth/storage" are genuine deal-breakers. A candidate with an
    unknown size is never excluded (size filters only apply when we
    actually know the size — better to let an unknown-size candidate
    through than wrongly drop something real).
    """
    try:
        from gateway import settings as _settings
        min_gb = _settings.get("min_size_gb", 0) or 0
        max_gb = _settings.get("max_size_gb", 0) or 0
    except Exception:
        min_gb = max_gb = 0

    if not min_gb and not max_gb:
        return streams

    min_bytes = min_gb * 1024 * 1024 * 1024 if min_gb else 0
    max_bytes = max_gb * 1024 * 1024 * 1024 if max_gb else None

    out = []
    for s in streams:
        if not s.size:
            out.append(s)   # unknown size — don't exclude
            continue
        if min_bytes and s.size < min_bytes:
            continue
        if max_bytes and s.size > max_bytes:
            continue
        out.append(s)
    return out


def _rank_by_preferences(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Stable-sort candidates so ones matching configured preferences
    (preferred_language, preferred_audio, require_subtitles) come first.
    This is ranking, not filtering — nothing is excluded, so if nothing
    matches the preference, the original AIOStreams ordering for the
    non-matching tail is preserved (AIOStreams' own sort/SEL config still
    has the final say among non-preferred candidates).
    """
    try:
        from gateway import settings as _settings
        pref_lang     = (_settings.get("preferred_language", "") or "").lower()
        pref_audio    = [a.lower() for a in (_settings.get("preferred_audio", []) or [])]
        require_subs  = bool(_settings.get("require_subtitles", False))
    except Exception:
        pref_lang, pref_audio, require_subs = "", [], False

    if not pref_lang and not pref_audio and not require_subs:
        return streams

    def score(s: AIOStream) -> tuple:
        languages = [l.lower() for l in (s.parsed_file.languages or [])] if s.parsed_file else []
        audio_tags = [a.lower() for a in (s.parsed_file.audio_tags or [])] if s.parsed_file else []

        lang_match  = 1 if pref_lang and pref_lang in languages else 0
        audio_match = sum(1 for a in pref_audio if any(a in tag for tag in audio_tags))
        subs_match  = 1 if (require_subs and s.subtitles) else 0

        # Higher is better; Python's sort is stable so ties keep original order.
        return (lang_match, audio_match, subs_match)

    return sorted(streams, key=score, reverse=True)


async def _probe_stream(candidate: AIOStream) -> bool:
    """
    Validate a candidate stream actually works before committing to it.
    Issues a tiny ranged GET (1 byte) rather than HEAD, because many debrid
    CDNs don't implement HEAD correctly but do honour Range on GET — a HEAD
    that 200s/405s isn't reliable evidence the link is really alive.

    Beyond the status code, also checks the TOTAL file size reported via
    Content-Range/Content-Length against _MIN_PLAUSIBLE_MEDIA_BYTES. A
    "successful" 200/206 backed by a tiny (sub-MB) file is exactly the
    failure mode that was slipping through: the debrid backend returns a
    real-looking response for a broken/expired link, the probe's status
    check alone passes it, and the genuinely tiny file gets accepted as if
    it were real media — only surfacing later as an ~8-second, sub-1MB
    "movie" in Plex.
    """
    if not candidate.url:
        return False
    try:
        timeout = aiohttp.ClientTimeout(total=_PROBE_TIMEOUT)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            headers = {**(candidate.request_headers or {}), "Range": "bytes=0-0"}
            async with session.get(candidate.url, headers=headers) as resp:
                # Drain a tiny bit so the connection closes cleanly
                await resp.content.read(1)
                if resp.status not in (200, 206):
                    return False
                total_size = _parse_total_size(resp)
                if total_size is not None and total_size < _MIN_PLAUSIBLE_MEDIA_BYTES:
                    logger.warning(
                        "Candidate rejected: reported size %d bytes (%.1f MB) is "
                        "implausibly small for real media — %s…",
                        total_size, total_size / 1024 / 1024, candidate.url[:60]
                    )
                    return False
                # If the candidate's own metadata claims a size, cross-check
                # it against what the probe actually saw — a mismatch is
                # also a sign of a broken/substituted link.
                if candidate.size and total_size and abs(candidate.size - total_size) > candidate.size * 0.1:
                    logger.warning(
                        "Candidate rejected: AIOStreams claimed %d bytes but "
                        "probe found %d bytes — %s…",
                        candidate.size, total_size, candidate.url[:60]
                    )
                    return False
                return True
    except Exception as exc:
        logger.debug("Probe failed for %s…: %s", candidate.url[:60], exc)
        return False


# ---------------------------------------------------------------------------
# Stub data — used when AIOSTREAMS_UUID is not set
# ---------------------------------------------------------------------------

def _stub_results(item: MediaItem) -> list[dict]:
    base = f"http://fake-cdn.local/streams/{item.imdb_id}"
    return [
        {
            "url": f"{base}/hd.mkv",
            "filename": f"{item.title}.1080p.BluRay.x265.mkv",
            "size": 8_500_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "1080p", "quality": "BluRay", "encode": "HEVC", "hdr": []},
        },
        {
            "url": f"{base}/4k.mkv",
            "filename": f"{item.title}.2160p.BluRay.DV.HDR10.mkv",
            "size": 42_000_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "2160p", "quality": "BluRay", "encode": "HEVC", "hdr": ["DV", "HDR10"]},
        },
    ]


# ---------------------------------------------------------------------------
# aiostream operators
# ---------------------------------------------------------------------------

@operator
async def _fetch_raw(
    session: aiohttp.ClientSession,
    item: MediaItem,
    url: str,
    uuid: str,
    password: str,
) -> AsyncIterator[dict]:
    """Yield raw SearchApiResult dicts that have a direct stream URL."""

    if not uuid:
        logger.warning("AIOSTREAMS_UUID not set — using stub data")
        await asyncio.sleep(0.05)
        for r in _stub_results(item):
            yield r
        return

    endpoint = f"{url}/api/v1/search"
    params   = {"type": item.aiostreams_type, "id": item.aiostreams_id}
    headers  = _auth_headers(uuid, password)

    logger.info("AIOStreams query: %s %s", endpoint, params)

    try:
        async with _aiostreams_gate:
            async with session.get(
                endpoint, params=params, headers=headers,
                timeout=aiohttp.ClientTimeout(total=30)
            ) as resp:
                if resp.status == 401:
                    raise RuntimeError(
                        "AIOStreams: invalid credentials (401). "
                        "Check AIOSTREAMS_UUID and AIOSTREAMS_PASSWORD in docker-compose.yml."
                    )
                if resp.status == 404:
                    raise RuntimeError(
                        "AIOStreams: /api/v1/search not found (404). "
                        "Check AIOSTREAMS_URL — should be http://host:3000 (not 3001)."
                    )
                resp.raise_for_status()
                data = await resp.json()
    except aiohttp.ClientConnectorError as exc:
        raise RuntimeError(
            f"Cannot connect to AIOStreams at {url}. "
            "Check AIOSTREAMS_URL and that AIOStreams is running."
        ) from exc

    if not data.get("success"):
        err = (data.get("error") or {}).get("message", "unknown error")
        raise RuntimeError(f"AIOStreams returned error: {err}")

    results = (data.get("data") or {}).get("results", [])
    errors  = (data.get("data") or {}).get("errors", [])
    total   = len(results)
    logger.info("AIOStreams returned %d total results", total)

    if errors:
        for e in errors:
            logger.warning("AIOStreams addon error — %s: %s", e.get("title",""), e.get("description",""))

    # 0 results = episode not available — yield nothing, caller handles it
    if total == 0:
        if errors:
            for e in errors:
                logger.debug("Addon error: %s — %s", e.get("title",""), e.get("description",""))
        return

    yielded = 0
    for r in results:
        if r.get("url"):    # only results with a direct HTTP URL
            yield r
            yielded += 1

    logger.info("Yielded %d results with direct URLs (out of %d total)", yielded, total)

    # Results present but no direct url — log for debugging, yield nothing
    if yielded == 0 and total > 0:
        for i, r in enumerate(results[:2]):
            logger.warning(
                "Result[%d] has no direct url — keys: %s | externalUrl=%r",
                i, list(r.keys()), r.get("externalUrl")
            )


@operator
async def _parse(raw: dict) -> AsyncIterator[AIOStream]:
    yield AIOStream.from_api(raw)


# ---------------------------------------------------------------------------
# Public client
# ---------------------------------------------------------------------------

class AIOStreamsClient:
    """Async client for AIOStreams /api/v1/search."""

    def __init__(self) -> None:
        self._session: aiohttp.ClientSession | None = None

    async def open(self) -> None:
        self._session = aiohttp.ClientSession()

    async def close(self) -> None:
        if self._session:
            await self._session.close()
            self._session = None

    def stream_results(self, item: MediaItem):
        assert self._session
        aio_url, uuid, password = _cfg()
        raw = _fetch_raw(self._session, item, aio_url, uuid, password)
        return raw | pipe.flatmap(lambda d: _parse(d))

    def stream_4k(self, item: MediaItem):
        return self.stream_results(item) | pipe.filter(lambda s: s.is_4k)

    def stream_hd(self, item: MediaItem):
        return self.stream_results(item) | pipe.filter(lambda s: not s.is_4k)

    async def resolve_all(self, item: MediaItem) -> list[AIOStream]:
        return await astream.list(self.stream_results(item))

    async def best_for_quality(self, item: MediaItem, quality: Quality) -> AIOStream | None:
        src = self.stream_4k(item) if quality == Quality.UHD else self.stream_hd(item)
        all_s = await astream.list(src)
        cached = [s for s in all_s if s.cached]
        return (cached or all_s or [None])[0]

    async def best_working_for_quality(
        self, item: MediaItem, quality: Quality, max_candidates: int = 5
    ) -> AIOStream | None:
        """
        Like best_for_quality(), but probes each candidate with a real HTTP
        request before committing to it, falling through to the next one if
        a link is dead (404/410/connection refused/timeout/etc). This is the
        fix for "bad links" — a single dead link no longer breaks playback
        for an entire title when other valid sources exist.

        Before probing, candidates are filtered by hard size bounds and
        ranked by stream preferences (language, audio, subtitles) from
        settings — see _apply_stream_preferences(). Tries up to
        `max_candidates` of the resulting ranked list.
        """
        src = self.stream_4k(item) if quality == Quality.UHD else self.stream_hd(item)
        all_s = await astream.list(src)
        if not all_s:
            return None

        all_s = _filter_by_size(all_s)
        if not all_s:
            logger.warning("All candidates for %s (%s) excluded by size bounds",
                           item.title, quality.value)
            return None

        all_s = _rank_by_preferences(all_s)

        cached     = [s for s in all_s if s.cached]
        uncached   = [s for s in all_s if not s.cached]
        candidates = (cached + uncached)[:max_candidates]

        for i, candidate in enumerate(candidates):
            if not candidate.url:
                continue
            ok = await _probe_stream(candidate)
            if ok:
                if i > 0:
                    logger.info("Skipped %d dead candidate(s) before finding a working stream", i)
                return candidate
            logger.warning("Candidate %d/%d dead: %s…",
                           i + 1, len(candidates), candidate.url[:60])

        logger.warning("All %d candidate(s) for %s (%s) were dead",
                       len(candidates), item.title, quality.value)
        return None

    async def connection_test(self) -> dict:
        """Test connectivity and return a diagnostic dict."""
        aio_url, uuid, password = _cfg()
        result = {
            "url": aio_url,
            "uuid_set": bool(uuid),
            "ok": False,
            "error": None,
            "status_code": None,
            "diagnosis": None,
        }
        if not uuid:
            result["error"] = "AIOSTREAMS_UUID not set — running in stub mode"
            result["diagnosis"] = "stub"
            return result
        try:
            async with self._session.get(
                f"{aio_url}/api/v1/search",
                params={"type": "movie", "id": "tt0068646"},   # The Godfather — widely indexed
                headers=_auth_headers(uuid, password),
                timeout=aiohttp.ClientTimeout(total=8),
            ) as resp:
                result["status_code"] = resp.status
                if resp.status == 401:
                    result["error"] = "Invalid credentials (401)"
                    result["diagnosis"] = "bad_auth"
                elif resp.status == 200:
                    data = await resp.json()
                    results = (data.get("data") or {}).get("results", [])
                    errors  = (data.get("data") or {}).get("errors", [])
                    with_url = [r for r in results if r.get("url")]
                    result["ok"] = True
                    result["total_results"] = len(results)
                    result["direct_urls"] = len(with_url)
                    result["addon_errors"] = len(errors)
                    if len(results) == 0:
                        result["diagnosis"] = "no_addons"
                        result["error"] = (
                            f"Connected but 0 results returned. "
                            f"No addons or debrid configured in AIOStreams. "
                            f"Visit {aio_url}/stremio/configure"
                        )
                        result["ok"] = False
                    elif len(with_url) == 0:
                        result["diagnosis"] = "no_debrid"
                        result["error"] = (
                            f"Connected, {len(results)} results, but none have a direct URL. "
                            "Add a debrid service (Real-Debrid etc.) in AIOStreams."
                        )
                        result["ok"] = False
                    else:
                        result["diagnosis"] = "ok"
                else:
                    result["error"] = f"HTTP {resp.status}"
        except Exception as exc:
            result["error"] = str(exc)
            result["diagnosis"] = "unreachable"
        return result
