"""
gateway/aiostreams_client.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Connects to the real AIOStreams /api/v1/search endpoint.

Environment variables (read at call time):
  AIOSTREAMS_URL       — e.g. http://192.168.1.x:3000
  AIOSTREAMS_UUID      — your user UUID from AIOStreams Settings page
  AIOSTREAMS_PASSWORD  — your password from AIOStreams Settings page

If AIOSTREAMS_UUID is empty the client returns stub data for testing.
"""
from __future__ import annotations

import asyncio
import base64
import logging
import os
import re
import time
from typing import AsyncIterator, Optional

import aiohttp
from aiostream import operator, pipe, stream as astream

from .models import AIOStream, MediaItem, MediaType, Quality


class AllCandidatesDeadError(Exception):
    """
    Raised by best_working_for_quality specifically when at least one
    candidate existed and every single one failed its live probe — a much
    stronger signal than the plain "no candidates at all" case (which just
    returns None, since that could easily mean nothing's been cached yet
    and might show up later). Callers that want to treat "exhaustively
    tried and all dead" differently from "genuinely nothing found" catch
    this specifically instead of just checking for a None return.
    """
    def __init__(self, count: int):
        self.count = count
        super().__init__(f"All {count} candidate(s) were dead")

logger = logging.getLogger("aiogateway.aiostreams")


def _cfg():
    """
    (url, uuid, password) actually in effect.

    Read through gateway.settings.connection(), which resolves the
    settings-first / env-fallback precedence — so these are editable
    from Config → Connections without a container restart, while an
    install that only ever set the env vars keeps working unchanged.
    """
    try:
        from gateway import settings as _settings
        return (
            _settings.connection("aiostreams_url", "http://localhost:3001"),
            _settings.connection("aiostreams_uuid", ""),
            _settings.connection("aiostreams_password", ""),
        )
    except Exception:
        # Settings unavailable (very early startup) — fall back to the
        # raw env vars rather than failing the query outright.
        return (
            os.environ.get("AIOSTREAMS_URL",      "http://localhost:3001"),
            os.environ.get("AIOSTREAMS_UUID",     ""),
            os.environ.get("AIOSTREAMS_PASSWORD", ""),
        )


def _auth_headers(uuid: str, password: str) -> dict:
    token = base64.b64encode(f"{uuid}:{password}".encode()).decode()
    return {"Authorization": f"Basic {token}"}


_PROBE_TIMEOUT = float(os.environ.get("AIOSTREAMS_PROBE_TIMEOUT", "6"))

# ---------------------------------------------------------------------------
# Global rate gate for AIOStreams /api/v1/search queries
# ---------------------------------------------------------------------------
# Every code path that talks to AIOStreams — webhook play-triggered resolves,
# background episode scans (one independent task per tracked show), the
# auto-episode discovery sweep, and bulk migration — all funnel through
# _fetch_raw() below. Each of those call sites already has its own local
# concurrency limit (a semaphore here, a "1s between episodes" there,
# migration's worker pool), but none of them coordinate with each other —
# so e.g. migrating a dozen shows at once spins up a dozen independent
# background scan tasks that all start querying AIOStreams simultaneously,
# on top of migration's own concurrent requests. The result, seen in
# practice: nearly every single query gets rate limited (429), even though
# each individual caller was already pacing itself.
#
# This gate fixes that at the root by capping the ACTUAL outbound request
# rate to AIOStreams app-wide, no matter how many independent tasks are
# trying to query at once — a semaphore alone isn't enough since it only
# limits how many requests are in flight, not how fast new ones are
# launched.
#
# Worth knowing: AIOStreams itself fans a single query out to every addon
# you have configured (Comet, MediaFusion, etc.) in parallel — so even a
# modest top-level request rate from us can still translate into a much
# higher burst of requests hitting those addons, which is outside our
# control. The only lever we have is how often WE query AIOStreams, so
# when 429s/502s are still frequent, slowing this down further (fewer,
# more spaced-out top-level queries) is the only knob that actually helps.
#
# Concurrency is fixed at process start (from settings, defaulting to
# fully serialized — only 1 request in flight at a time app-wide).
# min_interval is re-read from settings on every single request, so it
# can be tuned live from the Config UI without a container restart.
_AIOSTREAMS_MAX_CONCURRENT = int(os.environ.get("AIOSTREAMS_MAX_CONCURRENT", "0")) or None  # None = read from settings


def _live_min_interval_ms() -> float:
    try:
        from gateway import settings as _settings
        return float(_settings.get("aiostreams_min_interval_ms", 1500))
    except Exception:
        return 1500.0


def _configured_max_concurrent() -> int:
    if _AIOSTREAMS_MAX_CONCURRENT is not None:
        return _AIOSTREAMS_MAX_CONCURRENT   # explicit env override wins
    try:
        from gateway import settings as _settings
        return int(_settings.get("aiostreams_max_concurrent", 1))
    except Exception:
        return 1


class _RateGate:
    """Caps both how many requests can be in flight at once (a normal
    semaphore, sized once at first use) and how fast new ones can be
    launched (a minimum spacing between successive dispatches, re-read
    live on every acquire) — the two together are what actually bound
    sustained request rate, not just momentary concurrency."""

    def __init__(self):
        self._sem: Optional[asyncio.Semaphore] = None
        self._lock = asyncio.Lock()
        self._last_started_at = 0.0

    def _semaphore(self) -> asyncio.Semaphore:
        if self._sem is None:
            self._sem = asyncio.Semaphore(max(1, _configured_max_concurrent()))
        return self._sem

    async def __aenter__(self):
        await self._semaphore().acquire()
        async with self._lock:
            min_interval = max(0.0, _live_min_interval_ms()) / 1000.0
            now = asyncio.get_event_loop().time()
            wait = min_interval - (now - self._last_started_at)
            if wait > 0:
                await asyncio.sleep(wait)
            self._last_started_at = asyncio.get_event_loop().time()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self._semaphore().release()
        return False


_aiostreams_gate = _RateGate()

# A candidate's TOTAL reported size (from Content-Range on the probe
# response, or Content-Length as a fallback) must be at least this large to
# be accepted as real movie/episode video. This catches debrid backends that
# return a 200/206 "success" for a broken/expired link backed by a tiny
# placeholder, error page, or partial/corrupted file — which otherwise pass
# the probe's status-code check while being unmistakably not real content.
# 50MB is comfortably below even a short, heavily compressed TV episode.
_MIN_PLAUSIBLE_MEDIA_BYTES = int(os.environ.get("AIOSTREAMS_MIN_MEDIA_BYTES", str(50 * 1024 * 1024)))


def _parse_total_size(resp) -> Optional[int]:
    """Extract the TOTAL file size from a ranged response, preferring
    Content-Range's total (works even for a 1-byte probe request) and
    falling back to Content-Length (only correct for a non-ranged response)."""
    cr = resp.headers.get("Content-Range", "")
    if cr and "/" in cr:
        try:
            total = cr.rsplit("/", 1)[1].strip()
            if total != "*":
                return int(total)
        except (ValueError, IndexError):
            pass
    cl = resp.headers.get("Content-Length")
    if cl:
        try:
            return int(cl)
        except ValueError:
            pass
    return None


def _filter_by_size(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Hard-filter candidates by min/max_size_gb from settings. Unlike
    preference ranking, these are exclusions, not just a sort order —
    "too small to be the real thing" and "too large for available
    bandwidth/storage" are genuine deal-breakers. A candidate with an
    unknown size is never excluded (size filters only apply when we
    actually know the size — better to let an unknown-size candidate
    through than wrongly drop something real).
    """
    try:
        from gateway import settings as _settings
        min_gb = _settings.get("min_size_gb", 0) or 0
        max_gb = _settings.get("max_size_gb", 0) or 0
    except Exception:
        min_gb = max_gb = 0

    if not min_gb and not max_gb:
        return streams

    min_bytes = min_gb * 1024 * 1024 * 1024 if min_gb else 0
    max_bytes = max_gb * 1024 * 1024 * 1024 if max_gb else None

    out = []
    for s in streams:
        if not s.size:
            out.append(s)   # unknown size — don't exclude
            continue
        if min_bytes and s.size < min_bytes:
            continue
        if max_bytes and s.size > max_bytes:
            continue
        out.append(s)
    return out


_EXCLUDE_WORD_RE_CACHE: dict = {}


def _exclude_word_pattern(word: str):
    pat = _EXCLUDE_WORD_RE_CACHE.get(word)
    if pat is None:
        # Match as a distinct token (surrounded by non-alphanumeric chars or
        # string edges) so e.g. excluding "cam" doesn't also reject a real
        # release whose title happens to contain "camera" or "campfire".
        pat = re.compile(rf'(?<![a-z0-9]){re.escape(word)}(?![a-z0-9])')
        _EXCLUDE_WORD_RE_CACHE[word] = pat
    return pat


def _filter_by_usenet_allowed(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Hard-filter out usenet-sourced candidates (AIOStreams' "type": "usenet" —
    its built-in NNTP engine, Easynews, NzbDAV/AltMount, Stremio NNTP,
    TorBox's usenet side, etc.) unless allow_usenet is enabled in settings.

    This is purely a gate on our side — if the user hasn't set up usenet
    in AIOStreams at all, AIOStreams never returns usenet-typed results in
    the first place and this is a no-op either way. When usenet IS
    configured there and allow_usenet is on (the default), usenet
    candidates are treated exactly like any other stream from here on:
    same size/exclude-word filters, same preference ranking, same live
    probe before being committed to.
    """
    try:
        from gateway import settings as _settings
        allow_usenet = bool(_settings.get("allow_usenet", True))
    except Exception:
        allow_usenet = True

    if allow_usenet:
        return streams

    return [s for s in streams if not s.is_usenet]


async def _commit_choice(chosen: Optional[AIOStream]) -> bool:
    """
    Tell AllDebrid which candidate won, sweep the rest off the account,
    and — in own-links mode — replace the candidate's URL with a freshly
    minted one.

    Every selection path funnels through here so there's exactly one
    place that decides what "the pick" means.

    Returns False only in the one case that genuinely invalidates the
    candidate: own-links mode deleted the account's copies and then
    failed to mint a replacement, leaving `chosen.url` pointing at a
    link that no longer resolves. Callers must treat that as a failed
    resolve rather than handing a dead URL to a stub.

    Every other failure returns True. Losing a cleanup pass leaves
    clutter on the account, which is a tidiness problem — turning a
    successful resolve into a failed one over it would be the worse
    outcome.
    """
    if chosen is None:
        return True
    try:
        from gateway import alldebrid as _ad
        if not _ad.is_enabled() or not _ad.is_alldebrid(chosen.service):
            # Non-AllDebrid picks still sweep the account, since an
            # AllDebrid candidate from the same search may well have
            # been uploaded during verification.
            if _ad.is_enabled():
                await _ad.keep_only(None)
            return True

        result = await _ad.keep_only(
            chosen.info_hash, filename=chosen.filename, file_idx=chosen.file_idx
        )

        if "link" not in result:
            return True            # pin mode — AIOStreams' URL still stands

        link = result.get("link")
        if not link or not link.get("url"):
            return False

        chosen.url = link["url"]
        # A minted link is served straight from AllDebrid's CDN, so
        # whatever headers AIOStreams wanted for its own proxied URL no
        # longer apply and would at best be ignored.
        chosen.request_headers = {}
        if link.get("size"):
            chosen.size = link["size"]
        return True
    except Exception as exc:
        logger.warning("AllDebrid keep-only sweep failed: %s", exc)
        return True


async def _verify_alldebrid(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Resolve the real cache status of AllDebrid-served candidates by
    adding them to the account, and drop the ones that come back
    not-ready.

    AllDebrid has no instant-availability endpoint any more, so the only
    way to know whether a release is cached is to upload it and read the
    `ready` flag off the response — which is exactly what
    gateway.alldebrid.verify does. A ready torrent is already complete
    on AllDebrid's servers, i.e. cached; a not-ready one has to be
    downloaded first, so streaming it now would either stall or fail.

    Three states come back and all three are handled distinctly:

      ready       → s.cached is set to True. This also upgrades
                    candidates AIOStreams reported as uncached or didn't
                    report on at all, which is the common case for
                    AllDebrid and the reason plenty of genuinely cached
                    releases used to rank below worse ones.
      not ready   → s.cached is set to False, and the candidate is
                    dropped when alldebrid_drop_uncached is on (default).
      no answer   → left exactly as AIOStreams reported it. An API
                    failure or a rejected hash must not masquerade as
                    "uncached", or an AllDebrid outage would empty every
                    search result in the app.

    Candidates with no infoHash (usenet, direct HTTP, library results)
    are untouched — there's nothing to look up, and they're not
    AllDebrid's to answer for anyway.

    Only the first alldebrid_max_checks unverified candidates are
    checked. The list arrives already ranked, so the cap falls on the
    tail nobody was going to pick; anything past it keeps whatever
    status AIOStreams gave it and is never dropped on that basis.
    """
    try:
        from gateway import alldebrid as _ad
        from gateway import settings as _settings
    except Exception:
        return streams

    if not streams or not _ad.is_enabled():
        return streams

    # Only candidates AllDebrid serves, that have a hash to ask about,
    # and whose status isn't already a definite True from AIOStreams.
    pending = [
        s for s in streams
        if _ad.is_alldebrid(s.service) and s.info_hash and s.cached is not True
    ]
    # Every AllDebrid candidate this search surfaced becomes eligible
    # for cleanup later, whether or not it gets probed here — AIOStreams
    # adds them to the account itself when it builds their stream URLs,
    # so the ones we skip still need sweeping.
    try:
        _ad.note_candidates(s.info_hash for s in streams
                            if _ad.is_alldebrid(s.service) and s.info_hash)
    except Exception:
        pass

    if not pending:
        return streams

    try:
        limit = int(_settings.get("alldebrid_max_checks", 20))
    except (TypeError, ValueError):
        limit = 20
    checked = pending[:max(1, limit)]

    try:
        verdicts = await _ad.verify({s.info_hash for s in checked})
    except Exception as exc:
        logger.warning("AllDebrid verification failed, leaving cache status as "
                       "reported: %s", exc)
        return streams

    if not verdicts:
        return streams

    for s in checked:
        ready = verdicts.get(s.info_hash)
        if ready is None:
            continue          # no answer — leave as-is
        s.cached = bool(ready)

    if not bool(_settings.get("alldebrid_drop_uncached", True)):
        return streams

    kept, dropped = [], 0
    for s in streams:
        if (_ad.is_alldebrid(s.service) and s.info_hash
                and verdicts.get(s.info_hash) is False):
            dropped += 1
            continue
        kept.append(s)

    if dropped:
        logger.info("Dropped %d uncached AllDebrid candidate(s); %d left",
                    dropped, len(kept))
    return kept


async def _verify_torbox(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Resolve the real cache status of TorBox candidates, and drop the ones
    TorBox says aren't cached.

    The TorBox mirror of _verify_alldebrid, but far simpler because
    TorBox kept its instant-availability endpoint: this is one read-only
    query for up to ~80 hashes. Nothing is added to the account, so
    there's no cleanup, no pinning and no sweep.

    Same three-state discipline as AllDebrid:
      reported cached     → cached = True
      reported not cached → cached = False, dropped when
                            torbox_drop_uncached is on (default)
      no answer at all    → left exactly as AIOStreams reported it, so a
                            TorBox outage can't look like "nothing is
                            cached"
    """
    try:
        from gateway import torbox as _tb
        from gateway import settings as _settings
    except Exception:
        return streams

    if not streams or not _tb.is_enabled():
        return streams

    pending = [
        s for s in streams
        if _tb.is_torbox(s.service) and s.info_hash and s.cached is not True
    ]
    if not pending:
        return streams

    try:
        limit = int(_settings.get("torbox_max_checks", 100))
    except (TypeError, ValueError):
        limit = 100
    checked = pending[:max(1, limit)]

    try:
        verdicts = await _tb.verify({s.info_hash for s in checked})
    except Exception as exc:
        logger.warning("TorBox verification failed, leaving cache status as "
                       "reported: %s", exc)
        return streams

    if not verdicts:
        return streams

    for s in checked:
        cached = verdicts.get(s.info_hash)
        if cached is None:
            continue
        s.cached = bool(cached)

    if not bool(_settings.get("torbox_drop_uncached", True)):
        return streams

    kept, dropped = [], 0
    for s in streams:
        if (_tb.is_torbox(s.service) and s.info_hash
                and verdicts.get(s.info_hash) is False):
            dropped += 1
            continue
        kept.append(s)

    if dropped:
        logger.info("Dropped %d uncached TorBox candidate(s); %d left",
                    dropped, len(kept))
    return kept


def _filter_by_cached(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Hard-exclude anything whose cache status isn't a definite True, for
    every service — the global "cached only" mode.

    Off by default and deliberately so. `cached` is three-state and a
    missing value means the addon didn't report, not that the release is
    uncached, so this drops unknowns too and can empty results entirely
    on a setup whose addons are quiet about caching. The AllDebrid check
    above is the targeted version, dropping only what it verified.
    """
    try:
        from gateway import settings as _settings
        if not bool(_settings.get("only_cached_streams", False)):
            return streams
    except Exception:
        return streams

    out = [s for s in streams if s.cached is True]
    if len(out) != len(streams):
        logger.info("Cached-only mode: kept %d of %d candidate(s)",
                    len(out), len(streams))
    return out


def _diversify(ranked: list[AIOStream], limit: int) -> list[AIOStream]:
    """
    Take the top `limit` candidates while making sure no single debrid
    service monopolises the slice.

    Cached candidates sort ahead of uncached ones, which was harmless
    while nobody knew much about cache status. It stopped being harmless
    once AllDebrid results started being actively verified: they now come
    back with cached=True far more often than services that simply don't
    report it, so they filled the entire slice and every other service —
    TorBox especially — was cut off before it could be probed. From the
    outside that looks like only AllDebrid existing.

    So the slice is filled round-robin across services in rank order:
    best AllDebrid, best TorBox, second-best AllDebrid, and so on. Within
    a service the original ranking is untouched, and if only one service
    returned anything it behaves exactly as before.
    """
    if limit <= 0 or len(ranked) <= limit:
        return ranked[:limit] if limit > 0 else []

    buckets: dict = {}
    for s in ranked:
        buckets.setdefault((s.service or "none").lower(), []).append(s)

    if len(buckets) < 2:
        return ranked[:limit]

    out: list[AIOStream] = []
    order = list(buckets)
    while len(out) < limit:
        progressed = False
        for key in order:
            if buckets[key]:
                out.append(buckets[key].pop(0))
                progressed = True
                if len(out) >= limit:
                    break
        if not progressed:
            break

    logger.info("Candidate slice diversified across %d service(s): %s",
                len(buckets), _by_service(out))
    return out


def _by_service(streams: list[AIOStream]) -> dict:
    """Count candidates per service, for drop diagnostics."""
    out: dict = {}
    for s in streams:
        key = (s.service or "none").lower()
        out[key] = out.get(key, 0) + 1
    return out


def _log_service_drop(stage: str, before: list[AIOStream], after: list[AIOStream]) -> None:
    """
    Log when a filter removes a whole service's worth of candidates.

    Filters are per-candidate, but their effect can be per-service — a
    strict cached-only rule silently erases every service whose addon
    doesn't report cache status, leaving only the ones that do. From the
    outside that looks like "only service X shows up", with nothing in
    the logs connecting it to a filter. This names the stage and the
    service so that's diagnosable instead of mysterious.
    """
    if len(after) == len(before):
        return
    b, a = _by_service(before), _by_service(after)
    for svc, n in b.items():
        left = a.get(svc, 0)
        if left == 0 and n:
            logger.warning("%s removed ALL %d %s candidate(s) — if you expected "
                           "%s results, this filter is why", stage, n, svc, svc)
        elif left < n:
            logger.info("%s: %s %d -> %d", stage, svc, n, left)


async def _apply_cache_filters(streams: list[AIOStream]) -> list[AIOStream]:
    """AllDebrid verification then the global cached-only gate, in that
    order — verification has to run first, since it's what turns an
    unreported AllDebrid candidate into a known-cached one that the
    cached-only gate should keep rather than discard."""
    before = streams
    streams = await _verify_alldebrid(streams)
    _log_service_drop("AllDebrid verification", before, streams)

    # TorBox next, and BEFORE the cached-only gate — that ordering is the
    # whole point. Verification is what turns an unreported TorBox
    # candidate into a known-cached one the gate should keep, rather than
    # an unknown one it discards.
    before = streams
    streams = await _verify_torbox(streams)
    _log_service_drop("TorBox verification", before, streams)

    before = streams
    streams = _filter_by_cached(streams)
    _log_service_drop("Cached-only mode", before, streams)
    return streams


def _filter_by_exclude_words(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Hard-filter candidates whose filename or parsed quality/resolution tag
    matches a configured exclude word — e.g. "CAM", "TS", "TELESYNC" — so
    cam-rips, telesyncs, and other low-quality pre-release captures never
    get picked or counted as an available stream, even if they're the only
    thing that shows up yet (which is common right around a movie's
    release, when a real encode hasn't hit debrid caches).
    """
    try:
        from gateway import settings as _settings
        words = [w.strip().lower() for w in (_settings.get("exclude_words", []) or []) if w.strip()]
    except Exception:
        words = []

    if not words:
        return streams

    out = []
    for s in streams:
        haystack = " ".join([
            s.filename or "",
            (s.parsed_file.quality or "") if s.parsed_file else "",
            (s.parsed_file.resolution or "") if s.parsed_file else "",
            (s.parsed_file.encode or "") if s.parsed_file else "",
        ]).lower()
        if any(_exclude_word_pattern(w).search(haystack) for w in words):
            continue
        out.append(s)
    return out


def _pack_signature(s: "AIOStream") -> Optional[str]:
    """
    A stable identity for the release a stream came from, used to
    recognise "this is the same pack that already worked".

    Keyed on the filename rather than the infoHash, even though
    AIOStreams does expose infoHash (an earlier version of this comment
    claimed it didn't — that was wrong, and it's parsed onto
    AIOStream.info_hash now). The filename is still the better key here:
    it's populated for usenet and direct-HTTP results too, which have no
    infohash at all, and the question this cache answers — "is this the
    same release that just worked?" — is about the release, not the
    torrent. Lowercased and stripped of the path, since some addons
    return a full path inside the archive and others just the file.

    Returns None for anything that isn't a season/series pack — a
    single-episode file says nothing about its neighbours, which is the
    entire premise of this cache.
    """
    if not s.filename:
        return None
    kind, _ = s.pack_type
    if kind not in ("season", "series"):
        return None
    name = s.filename.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    return name.strip().lower() or None


# (imdb_id, quality, season|"series") -> {"sig": str, "at": float}
#
# Which pack last produced a WORKING stream for this show. Populated on a
# successful probe, read to reorder candidates before probing the next
# episode.
#
# This does not skip queries or reuse URLs — the per-episode URL is
# computed by AIOStreams and is the one thing that must not be guessed.
# It only reorders: a pack that just served a working stream for E05 is
# the best first guess for E06, so probe it first instead of working down
# a list where the first few candidates are frequently dead.
#
# The cost this removes is real and dominant. A dead candidate costs a
# full HTTP probe (~2s); the query itself is ~1.8s. An episode that
# probes 4 dead candidates before a live one spends ~9s of its ~11s
# probing. Landing on the known-good pack first turns that into one
# probe.
#
# In-memory and small by design: a wrong guess costs one extra probe and
# self-corrects, so there's nothing worth persisting across restarts.
_known_good_packs: dict[tuple, dict] = {}
_KNOWN_GOOD_PACK_TTL_S = 6 * 3600   # a debrid link's useful life, roughly


def _pack_cache_keys(item: "MediaItem", quality: "Quality") -> list[tuple]:
    """
    Keys to consult for this episode, most specific first: the season's
    own pack, then any series pack covering the whole show.
    """
    if item.media_type != MediaType.SERIES or item.season is None:
        return []
    return [
        (item.imdb_id, quality.value, item.season),
        (item.imdb_id, quality.value, "series"),
    ]


def _remember_working_pack(item: "MediaItem", quality: "Quality", s: "AIOStream") -> None:
    """Record that this pack produced a working stream."""
    sig = _pack_signature(s)
    if not sig or item.media_type != MediaType.SERIES or item.season is None:
        return
    kind, pack_season = s.pack_type
    scope = "series" if kind == "series" else (pack_season or item.season)
    _known_good_packs[(item.imdb_id, quality.value, scope)] = {
        "sig": sig, "at": time.time(),
    }


def _hoist_known_good_pack(
    streams: list["AIOStream"], item: "MediaItem", quality: "Quality"
) -> list["AIOStream"]:
    """
    Move candidates from an already-proven pack to the front, preserving
    the existing order otherwise. Ranking only — nothing is filtered, so
    if the remembered pack isn't among this episode's results the list is
    unchanged and probing proceeds exactly as before.
    """
    now = time.time()
    for key in _pack_cache_keys(item, quality):
        entry = _known_good_packs.get(key)
        if not entry:
            continue
        if now - entry["at"] > _KNOWN_GOOD_PACK_TTL_S:
            _known_good_packs.pop(key, None)      # stale — links likely expired
            continue
        sig = entry["sig"]
        matching = [s for s in streams if _pack_signature(s) == sig]
        if not matching:
            continue
        rest = [s for s in streams if _pack_signature(s) != sig]
        logger.info(
            "Trying known-good pack first for %s S%02dE%02d (%s)",
            item.imdb_id, item.season, item.episode or 0, quality.value,
        )
        return matching + rest
    return streams


def _forget_pack_if_matches(
    item: "MediaItem", quality: "Quality", failed: "AIOStream"
) -> None:
    """Drop a remembered pack when one of its links probes dead."""
    sig = _pack_signature(failed)
    if not sig:
        return
    for key in _pack_cache_keys(item, quality):
        entry = _known_good_packs.get(key)
        if entry and entry["sig"] == sig:
            _known_good_packs.pop(key, None)
            logger.info("Forgetting known-good pack for %s (%s) — its link probed dead",
                        item.imdb_id, quality.value)


def _rank_by_preferences(streams: list[AIOStream], media_type: Optional["MediaType"] = None) -> list[AIOStream]:
    """
    Stable-sort candidates so ones matching configured preferences
    (preferred_language, preferred_audio, require_subtitles,
    prefer_season_packs) come first. This is ranking, not filtering —
    nothing is excluded, so if nothing matches the preference, the
    original AIOStreams ordering for the non-matching tail is preserved
    (AIOStreams' own sort/SEL config still has the final say among
    non-preferred candidates).

    prefer_season_packs ranks up candidates detected as a season or
    series pack (see detect_pack_type) over individual-episode files.
    Packs tend to be more heavily seeded/cached — the same underlying
    reliability concern as min_4k_candidates — so all else equal, a pack
    is a better bet than a lone episode file.

    This is a TV-only concept, so `media_type` gates it explicitly:
    pack_match is only ever scored when media_type == SERIES. Movie
    release names routinely contain incidental "s" + digits substrings
    that detect_pack_type's regex can't tell apart from a real season
    marker — a resolution/format tag like "DS4K" reads as "S4", a
    stereoscopic "S3D" reads as "S3", etc. Without this gate, a movie
    whose filename happens to collide with the pattern would get
    boosted to the top of its own search results ahead of otherwise
    equal or better candidates, for a reason that has nothing to do with
    it actually being a pack — because for a movie, it never is one.
    """
    try:
        from gateway import settings as _settings
        pref_lang     = (_settings.get("preferred_language", "") or "").lower()
        pref_audio    = [a.lower() for a in (_settings.get("preferred_audio", []) or [])]
        require_subs  = bool(_settings.get("require_subtitles", False))
        prefer_packs  = bool(_settings.get("prefer_season_packs", True)) and media_type == MediaType.SERIES
    except Exception:
        pref_lang, pref_audio, require_subs, prefer_packs = "", [], False, False

    if not pref_lang and not pref_audio and not require_subs and not prefer_packs:
        return streams

    def score(s: AIOStream) -> tuple:
        languages = [l.lower() for l in (s.parsed_file.languages or [])] if s.parsed_file else []
        audio_tags = [a.lower() for a in (s.parsed_file.audio_tags or [])] if s.parsed_file else []

        lang_match  = 1 if pref_lang and pref_lang in languages else 0
        pack_kind, _season_num = s.pack_type
        pack_match  = 1 if (prefer_packs and pack_kind in ("season", "series")) else 0
        audio_match = sum(1 for a in pref_audio if any(a in tag for tag in audio_tags))
        subs_match  = 1 if (require_subs and s.subtitles) else 0

        # Higher is better; Python's sort is stable so ties keep original order.
        return (lang_match, pack_match, audio_match, subs_match)

    return sorted(streams, key=score, reverse=True)


async def _probe_stream(candidate: AIOStream) -> bool:
    """
    Validate a candidate stream actually works before committing to it.
    Issues a tiny ranged GET (1 byte) rather than HEAD, because many debrid
    CDNs don't implement HEAD correctly but do honour Range on GET — a HEAD
    that 200s/405s isn't reliable evidence the link is really alive.

    Beyond the status code, also checks the TOTAL file size reported via
    Content-Range/Content-Length against _MIN_PLAUSIBLE_MEDIA_BYTES. A
    "successful" 200/206 backed by a tiny (sub-MB) file is exactly the
    failure mode that was slipping through: the debrid backend returns a
    real-looking response for a broken/expired link, the probe's status
    check alone passes it, and the genuinely tiny file gets accepted as if
    it were real media — only surfacing later as an ~8-second, sub-1MB
    "movie" in Plex.
    """
    if not candidate.url:
        return False
    try:
        timeout = aiohttp.ClientTimeout(total=_PROBE_TIMEOUT)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            headers = {**(candidate.request_headers or {}), "Range": "bytes=0-0"}
            async with session.get(candidate.url, headers=headers) as resp:
                # Drain a tiny bit so the connection closes cleanly
                await resp.content.read(1)
                if resp.status not in (200, 206):
                    return False
                total_size = _parse_total_size(resp)
                if total_size is not None and total_size < _MIN_PLAUSIBLE_MEDIA_BYTES:
                    logger.warning(
                        "Candidate rejected: reported size %d bytes (%.1f MB) is "
                        "implausibly small for real media — %s…",
                        total_size, total_size / 1024 / 1024, candidate.url[:60]
                    )
                    return False
                # If the candidate's own metadata claims a size, cross-check
                # it against what the probe actually saw — a mismatch is
                # also a sign of a broken/substituted link.
                if candidate.size and total_size and abs(candidate.size - total_size) > candidate.size * 0.1:
                    logger.warning(
                        "Candidate rejected: AIOStreams claimed %d bytes but "
                        "probe found %d bytes — %s…",
                        candidate.size, total_size, candidate.url[:60]
                    )
                    return False
                return True
    except Exception as exc:
        logger.debug("Probe failed for %s…: %s", candidate.url[:60], exc)
        return False


# ---------------------------------------------------------------------------
# Stub data — used when AIOSTREAMS_UUID is not set
# ---------------------------------------------------------------------------

def _stub_results(item: MediaItem) -> list[dict]:
    base = f"http://fake-cdn.local/streams/{item.imdb_id}"
    return [
        {
            "url": f"{base}/hd.mkv",
            "filename": f"{item.title}.1080p.BluRay.x265.mkv",
            "size": 8_500_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "1080p", "quality": "BluRay", "encode": "HEVC", "hdr": []},
        },
        {
            "url": f"{base}/4k.mkv",
            "filename": f"{item.title}.2160p.BluRay.DV.HDR10.mkv",
            "size": 42_000_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "2160p", "quality": "BluRay", "encode": "HEVC", "hdr": ["DV", "HDR10"]},
        },
    ]


# ---------------------------------------------------------------------------
# aiostream operators
# ---------------------------------------------------------------------------

@operator
async def _fetch_raw(
    session: aiohttp.ClientSession,
    item: MediaItem,
    url: str,
    uuid: str,
    password: str,
) -> AsyncIterator[dict]:
    """Yield raw SearchApiResult dicts that have a direct stream URL."""

    if not uuid:
        logger.warning("AIOSTREAMS_UUID not set — using stub data")
        await asyncio.sleep(0.05)
        for r in _stub_results(item):
            yield r
        return

    endpoint = f"{url}/api/v1/search"
    params   = {"type": item.aiostreams_type, "id": item.aiostreams_id}
    headers  = _auth_headers(uuid, password)

    try:
        async with _aiostreams_gate:
            # Logged here, not before the gate — this is the moment the
            # request actually gets sent, which is what makes the log
            # timestamps a meaningful way to see the real dispatch rate
            # rather than just when each caller started waiting its turn.
            logger.info("AIOStreams query: %s %s", endpoint, params)
            async with session.get(
                endpoint, params=params, headers=headers,
                timeout=aiohttp.ClientTimeout(total=60)
            ) as resp:
                if resp.status == 401:
                    raise RuntimeError(
                        "AIOStreams: invalid credentials (401). "
                        "Check AIOSTREAMS_UUID and AIOSTREAMS_PASSWORD in docker-compose.yml."
                    )
                if resp.status == 404:
                    raise RuntimeError(
                        "AIOStreams: /api/v1/search not found (404). "
                        "Check AIOSTREAMS_URL — should be http://host:3000 (not 3001)."
                    )
                resp.raise_for_status()
                data = await resp.json()
    except aiohttp.ClientConnectorError as exc:
        raise RuntimeError(
            f"Cannot connect to AIOStreams at {url}. "
            "Check AIOSTREAMS_URL and that AIOStreams is running."
        ) from exc
    except asyncio.TimeoutError as exc:
        # Previously uncaught here, and no caller logged it server-side
        # either — a slow/complex query (many addons, a title with heavy
        # fan-out) would silently show up only as a generic error to
        # whatever called this, with no way to tell "AIOStreams timed out"
        # apart from any other failure without digging through code.
        logger.warning("AIOStreams request timed out after 60s for %s", params)
        raise RuntimeError(
            f"AIOStreams did not respond within 60s for {item.title} — "
            "it may be slow for this particular title (a lot of addon "
            "fan-out) or temporarily overloaded."
        ) from exc

    if not data.get("success"):
        err = (data.get("error") or {}).get("message", "unknown error")
        raise RuntimeError(f"AIOStreams returned error: {err}")

    results = (data.get("data") or {}).get("results", [])
    errors  = (data.get("data") or {}).get("errors", [])
    total   = len(results)
    logger.info("AIOStreams returned %d total results", total)

    if errors:
        for e in errors:
            logger.warning("AIOStreams addon error — %s: %s", e.get("title",""), e.get("description",""))

    # 0 results = episode not available — yield nothing, caller handles it
    if total == 0:
        if errors:
            for e in errors:
                logger.debug("Addon error: %s — %s", e.get("title",""), e.get("description",""))
        return

    yielded = 0
    for r in results:
        if r.get("url"):    # only results with a direct HTTP URL
            yield r
            yielded += 1

    logger.info("Yielded %d results with direct URLs (out of %d total)", yielded, total)

    # Service breakdown of what AIOStreams actually returned, BEFORE any
    # filtering happens here. This is the line that distinguishes "a
    # filter in aiogateway removed your TorBox results" from "AIOStreams
    # never sent any" — the latter is usually its deduplicator, which
    # matches duplicates by infohash and in "Single Result" mode keeps
    # only the copy from your highest-priority service. TorBox and
    # AllDebrid serve the same torrents, so whichever service ranks
    # lower disappears entirely and it looks like aiogateway dropped it.
    breakdown: dict = {}
    for r in results:
        key = (r.get("service") or "none").lower()
        breakdown[key] = breakdown.get(key, 0) + 1
    logger.info("AIOStreams results by service: %s", breakdown or "{}")
    if len(breakdown) == 1 and "none" not in breakdown:
        logger.info(
            "Only one service (%s) in these results. If you expected more, "
            "check AIOStreams → Deduplicator: 'Single Result' keeps just the "
            "highest-priority service's copy of each release.",
            next(iter(breakdown))
        )

    # Results present but no direct url — log for debugging, yield nothing
    if yielded == 0 and total > 0:
        for i, r in enumerate(results[:2]):
            logger.warning(
                "Result[%d] has no direct url — keys: %s | externalUrl=%r",
                i, list(r.keys()), r.get("externalUrl")
            )


@operator
async def _parse(raw: dict) -> AsyncIterator[AIOStream]:
    yield AIOStream.from_api(raw)


# ---------------------------------------------------------------------------
# Public client
# ---------------------------------------------------------------------------

class AIOStreamsClient:
    """Async client for AIOStreams /api/v1/search."""

    def __init__(self) -> None:
        self._session: aiohttp.ClientSession | None = None

    async def open(self) -> None:
        self._session = aiohttp.ClientSession()

    async def close(self) -> None:
        if self._session:
            await self._session.close()
            self._session = None

    def stream_results(self, item: MediaItem):
        assert self._session
        aio_url, uuid, password = _cfg()
        raw = _fetch_raw(self._session, item, aio_url, uuid, password)
        return raw | pipe.flatmap(lambda d: _parse(d))

    def stream_4k(self, item: MediaItem):
        return self.stream_results(item) | pipe.filter(lambda s: s.is_4k)

    def stream_hd(self, item: MediaItem):
        return self.stream_results(item) | pipe.filter(lambda s: not s.is_4k)

    async def resolve_all(self, item: MediaItem) -> list[AIOStream]:
        all_s = await astream.list(self.stream_results(item))
        all_s = _filter_by_usenet_allowed(all_s)
        all_s = _filter_by_exclude_words(all_s)
        # Ranking was previously applied only in best_working_for_quality,
        # i.e. only on the play-time resolve path. Every discovery path
        # (adds, background scans, the auto-episode sweep) goes through
        # resolve_all instead, so prefer_season_packs had no effect on
        # whether a pack was ever noticed — pack detection came down to
        # AIOStreams' own sort order putting one first by luck. Ranking
        # here makes discovery and playback agree on what the best
        # candidate is, and is what lets pack-first filling reliably see
        # a pack when one exists.
        #
        # Ranking also has to happen BEFORE the cache check, so the
        # AllDebrid verification budget (alldebrid_max_checks) is spent
        # on the candidates most likely to actually be picked rather
        # than on whatever order the addons happened to return.
        all_s = _rank_by_preferences(all_s, item.media_type)
        return await _apply_cache_filters(all_s)

    async def best_for_quality(self, item: MediaItem, quality: Quality) -> AIOStream | None:
        src = self.stream_4k(item) if quality == Quality.UHD else self.stream_hd(item)
        all_s = await astream.list(src)
        all_s = _filter_by_usenet_allowed(all_s)
        all_s = _filter_by_exclude_words(all_s)
        all_s = await _apply_cache_filters(all_s)
        cached = [s for s in all_s if s.cached]
        chosen = (cached or all_s or [None])[0]
        if not await _commit_choice(chosen):
            return None
        return chosen

    async def best_working_for_quality(
        self, item: MediaItem, quality: Quality, max_candidates: int = 5
    ) -> AIOStream | None:
        """
        Like best_for_quality(), but probes each candidate with a real HTTP
        request before committing to it, falling through to the next one if
        a link is dead (404/410/connection refused/timeout/etc). This is the
        fix for "bad links" — a single dead link no longer breaks playback
        for an entire title when other valid sources exist.

        Before probing, candidates are filtered by hard size bounds and
        excluded words, then ranked by stream preferences (language, audio,
        subtitles) from settings — see _filter_by_size, _filter_by_exclude_
        words, and _rank_by_preferences. Tries up to `max_candidates` of the
        resulting ranked list.
        """
        src = self.stream_4k(item) if quality == Quality.UHD else self.stream_hd(item)
        all_s = await astream.list(src)
        if not all_s:
            return None

        all_s = _filter_by_size(all_s)
        if not all_s:
            logger.warning("All candidates for %s (%s) excluded by size bounds",
                           item.title, quality.value)
            return None

        all_s = _filter_by_exclude_words(all_s)
        if not all_s:
            logger.warning("All candidates for %s (%s) excluded by exclude words",
                           item.title, quality.value)
            return None

        all_s = _filter_by_usenet_allowed(all_s)
        if not all_s:
            logger.warning("All candidates for %s (%s) excluded — usenet results disabled",
                           item.title, quality.value)
            return None

        all_s = _rank_by_preferences(all_s, item.media_type)

        # After ranking, so verification is spent on the front of the
        # list, and before the candidate slice, so a dropped uncached
        # AllDebrid result frees its slot for a real one instead of
        # wasting one of the max_candidates probes on something that was
        # never going to stream.
        all_s = await _apply_cache_filters(all_s)
        if not all_s:
            logger.warning("All candidates for %s (%s) excluded — none are cached",
                           item.title, quality.value)
            return None

        cached     = [s for s in all_s if s.cached]
        uncached   = [s for s in all_s if not s.cached]
        candidates = _diversify(cached + uncached, max_candidates)

        # Applied last, so it outranks the preference sort: a pack that
        # has actually served a working stream for this show is stronger
        # evidence than any heuristic about what should work. Reorders
        # only within the already-filtered, already-ranked candidate list.
        candidates = _hoist_known_good_pack(candidates, item, quality)

        for i, candidate in enumerate(candidates):
            if not candidate.url:
                continue
            ok = await _probe_stream(candidate)
            if ok:
                if i > 0:
                    logger.info("Skipped %d dead candidate(s) before finding a working stream", i)
                _remember_working_pack(item, quality, candidate)
                if not await _commit_choice(candidate):
                    # Own-links mode couldn't mint a replacement link, so
                    # this candidate's URL is now dead. Treat it exactly
                    # like a dead probe and carry on down the list — the
                    # next one gets its own attempt.
                    logger.warning("Candidate %d/%d passed its probe but no "
                                   "AllDebrid link could be minted", i + 1, len(candidates))
                    continue
                return candidate
            logger.warning("Candidate %d/%d dead: %s…",
                           i + 1, len(candidates), candidate.url[:60])
            # A candidate we'd verified as ready that then probes dead
            # means the memoised verdict is stale (torrent expired off
            # the account, link revoked). Drop it so the next search
            # re-asks AllDebrid instead of confidently reusing the wrong
            # answer for the rest of the TTL.
            if candidate.info_hash:
                try:
                    from gateway import alldebrid as _ad
                    from gateway import torbox as _tb
                    if _ad.is_alldebrid(candidate.service):
                        _ad.forget(candidate.info_hash)
                    elif _tb.is_torbox(candidate.service):
                        _tb.forget(candidate.info_hash)
                except Exception:
                    pass
            # If the pack we hoisted is itself dead, drop it now. Leaving
            # it cached would put a known-bad candidate first for every
            # remaining episode of the season — turning the optimisation
            # into a guaranteed extra probe each time.
            _forget_pack_if_matches(item, quality, candidate)

        logger.warning("All %d candidate(s) for %s (%s) were dead",
                       len(candidates), item.title, quality.value)
        raise AllCandidatesDeadError(len(candidates))

    async def search_for_stream(self, item: MediaItem, quality: Quality) -> AIOStream | None:
        """
        Play-time resolution for the stub actually being played: run one
        AIOStreams search, apply the same size/exclude-words/usenet
        filters and preference ranking as best_working_for_quality, and
        return the single top-ranked result directly.

        Deliberately does NOT probe the result with a real HTTP request
        and does NOT fall through to a second or third candidate if it
        turns out to be dead — this is a search for "the" stream, not a
        pick from a candidate list. A dead link surfaces as a normal
        resolve failure (the webhook handler's existing set_error path),
        the same as any other resolve error, rather than being silently
        retried against another source.

        best_working_for_quality is kept as-is and still used everywhere
        else (pack fast-tracking, pre-warming, manual scans) — those are
        speculative resolves for stubs nobody actually pressed play on
        yet, where probing and falling back to a live candidate remains
        the right behaviour.
        """
        src = self.stream_4k(item) if quality == Quality.UHD else self.stream_hd(item)
        all_s = await astream.list(src)
        if not all_s:
            return None

        all_s = _filter_by_size(all_s)
        if not all_s:
            logger.warning("All results for %s (%s) excluded by size bounds",
                           item.title, quality.value)
            return None

        all_s = _filter_by_exclude_words(all_s)
        if not all_s:
            logger.warning("All results for %s (%s) excluded by exclude words",
                           item.title, quality.value)
            return None

        all_s = _filter_by_usenet_allowed(all_s)
        if not all_s:
            logger.warning("All results for %s (%s) excluded — usenet results disabled",
                           item.title, quality.value)
            return None

        all_s = _rank_by_preferences(all_s, item.media_type)
        all_s = await _apply_cache_filters(all_s)
        if not all_s:
            logger.warning("All results for %s (%s) excluded — none are cached",
                           item.title, quality.value)
            return None

        cached   = [s for s in all_s if s.cached]
        uncached = [s for s in all_s if not s.cached]
        ranked   = cached + uncached

        # A pack already proven to work for this show is still stronger
        # evidence than the preference ranking alone, even without a
        # fresh probe — reorders within the already-filtered list only.
        ranked = _hoist_known_good_pack(ranked, item, quality)

        chosen = next((s for s in ranked if s.url), None)
        if not await _commit_choice(chosen):
            return None
        return chosen

    async def connection_test(self) -> dict:
        """Test connectivity and return a diagnostic dict."""
        aio_url, uuid, password = _cfg()
        result = {
            "url": aio_url,
            "uuid_set": bool(uuid),
            "ok": False,
            "error": None,
            "status_code": None,
            "diagnosis": None,
        }
        if not uuid:
            result["error"] = "AIOSTREAMS_UUID not set — running in stub mode"
            result["diagnosis"] = "stub"
            return result
        try:
            async with self._session.get(
                f"{aio_url}/api/v1/search",
                params={"type": "movie", "id": "tt0068646"},   # The Godfather — widely indexed
                headers=_auth_headers(uuid, password),
                timeout=aiohttp.ClientTimeout(total=8),
            ) as resp:
                result["status_code"] = resp.status
                if resp.status == 401:
                    result["error"] = "Invalid credentials (401)"
                    result["diagnosis"] = "bad_auth"
                elif resp.status == 200:
                    data = await resp.json()
                    results = (data.get("data") or {}).get("results", [])
                    errors  = (data.get("data") or {}).get("errors", [])
                    with_url = [r for r in results if r.get("url")]
                    result["ok"] = True
                    result["total_results"] = len(results)
                    result["direct_urls"] = len(with_url)
                    result["addon_errors"] = len(errors)
                    if len(results) == 0:
                        result["diagnosis"] = "no_addons"
                        result["error"] = (
                            f"Connected but 0 results returned. "
                            f"No addons or debrid configured in AIOStreams. "
                            f"Visit {aio_url}/stremio/configure"
                        )
                        result["ok"] = False
                    elif len(with_url) == 0:
                        result["diagnosis"] = "no_debrid"
                        result["error"] = (
                            f"Connected, {len(results)} results, but none have a direct URL. "
                            "Add a debrid service (Real-Debrid etc.) in AIOStreams."
                        )
                        result["ok"] = False
                    else:
                        result["diagnosis"] = "ok"
                else:
                    result["error"] = f"HTTP {resp.status}"
        except Exception as exc:
            result["error"] = str(exc)
            result["diagnosis"] = "unreachable"
        return result
