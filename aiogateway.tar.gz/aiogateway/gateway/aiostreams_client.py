"""
gateway/aiostreams_client.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Connects to the real AIOStreams /api/v1/search endpoint.

Environment variables (read at call time):
  AIOSTREAMS_URL       — e.g. http://192.168.1.x:3000
  AIOSTREAMS_UUID      — your user UUID from AIOStreams Settings page
  AIOSTREAMS_PASSWORD  — your password from AIOStreams Settings page

If AIOSTREAMS_UUID is empty the client returns stub data for testing.
"""
from __future__ import annotations

import asyncio
import base64
import logging
import os
import re
import time
from typing import AsyncIterator, Optional

import aiohttp
from aiostream import operator, pipe, stream as astream

from .models import AIOStream, MediaItem, MediaType, Quality


class AllCandidatesDeadError(Exception):
    """
    Raised by best_working_for_quality specifically when at least one
    candidate existed and every single one failed its live probe — a much
    stronger signal than the plain "no candidates at all" case (which just
    returns None, since that could easily mean nothing's been cached yet
    and might show up later). Callers that want to treat "exhaustively
    tried and all dead" differently from "genuinely nothing found" catch
    this specifically instead of just checking for a None return.
    """
    def __init__(self, count: int):
        self.count = count
        super().__init__(f"All {count} candidate(s) were dead")

logger = logging.getLogger("aiogateway.aiostreams")


def _cfg():
    return (
        os.environ.get("AIOSTREAMS_URL",      "http://localhost:3001"),
        os.environ.get("AIOSTREAMS_UUID",     ""),
        os.environ.get("AIOSTREAMS_PASSWORD", ""),
    )


def _auth_headers(uuid: str, password: str) -> dict:
    token = base64.b64encode(f"{uuid}:{password}".encode()).decode()
    return {"Authorization": f"Basic {token}"}


_PROBE_TIMEOUT = float(os.environ.get("AIOSTREAMS_PROBE_TIMEOUT", "6"))

# ---------------------------------------------------------------------------
# Global rate gate for AIOStreams /api/v1/search queries
# ---------------------------------------------------------------------------
# Every code path that talks to AIOStreams — webhook play-triggered resolves,
# background episode scans (one independent task per tracked show), the
# auto-episode discovery sweep, and bulk migration — all funnel through
# _fetch_raw() below. Each of those call sites already has its own local
# concurrency limit (a semaphore here, a "1s between episodes" there,
# migration's worker pool), but none of them coordinate with each other —
# so e.g. migrating a dozen shows at once spins up a dozen independent
# background scan tasks that all start querying AIOStreams simultaneously,
# on top of migration's own concurrent requests. The result, seen in
# practice: nearly every single query gets rate limited (429), even though
# each individual caller was already pacing itself.
#
# This gate fixes that at the root by capping the ACTUAL outbound request
# rate to AIOStreams app-wide, no matter how many independent tasks are
# trying to query at once — a semaphore alone isn't enough since it only
# limits how many requests are in flight, not how fast new ones are
# launched.
#
# Worth knowing: AIOStreams itself fans a single query out to every addon
# you have configured (Comet, MediaFusion, etc.) in parallel — so even a
# modest top-level request rate from us can still translate into a much
# higher burst of requests hitting those addons, which is outside our
# control. The only lever we have is how often WE query AIOStreams, so
# when 429s/502s are still frequent, slowing this down further (fewer,
# more spaced-out top-level queries) is the only knob that actually helps.
#
# Concurrency is fixed at process start (from settings, defaulting to
# fully serialized — only 1 request in flight at a time app-wide).
# min_interval is re-read from settings on every single request, so it
# can be tuned live from the Config UI without a container restart.
_AIOSTREAMS_MAX_CONCURRENT = int(os.environ.get("AIOSTREAMS_MAX_CONCURRENT", "0")) or None  # None = read from settings


def _live_min_interval_ms() -> float:
    try:
        from gateway import settings as _settings
        return float(_settings.get("aiostreams_min_interval_ms", 1500))
    except Exception:
        return 1500.0


def _configured_max_concurrent() -> int:
    if _AIOSTREAMS_MAX_CONCURRENT is not None:
        return _AIOSTREAMS_MAX_CONCURRENT   # explicit env override wins
    try:
        from gateway import settings as _settings
        return int(_settings.get("aiostreams_max_concurrent", 1))
    except Exception:
        return 1


class _RateGate:
    """Caps both how many requests can be in flight at once (a normal
    semaphore, sized once at first use) and how fast new ones can be
    launched (a minimum spacing between successive dispatches, re-read
    live on every acquire) — the two together are what actually bound
    sustained request rate, not just momentary concurrency."""

    def __init__(self):
        self._sem: Optional[asyncio.Semaphore] = None
        self._lock = asyncio.Lock()
        self._last_started_at = 0.0

    def _semaphore(self) -> asyncio.Semaphore:
        if self._sem is None:
            self._sem = asyncio.Semaphore(max(1, _configured_max_concurrent()))
        return self._sem

    async def __aenter__(self):
        await self._semaphore().acquire()
        async with self._lock:
            min_interval = max(0.0, _live_min_interval_ms()) / 1000.0
            now = asyncio.get_event_loop().time()
            wait = min_interval - (now - self._last_started_at)
            if wait > 0:
                await asyncio.sleep(wait)
            self._last_started_at = asyncio.get_event_loop().time()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self._semaphore().release()
        return False


_aiostreams_gate = _RateGate()

# A candidate's TOTAL reported size (from Content-Range on the probe
# response, or Content-Length as a fallback) must be at least this large to
# be accepted as real movie/episode video. This catches debrid backends that
# return a 200/206 "success" for a broken/expired link backed by a tiny
# placeholder, error page, or partial/corrupted file — which otherwise pass
# the probe's status-code check while being unmistakably not real content.
# 50MB is comfortably below even a short, heavily compressed TV episode.
_MIN_PLAUSIBLE_MEDIA_BYTES = int(os.environ.get("AIOSTREAMS_MIN_MEDIA_BYTES", str(50 * 1024 * 1024)))


def _parse_total_size(resp) -> Optional[int]:
    """Extract the TOTAL file size from a ranged response, preferring
    Content-Range's total (works even for a 1-byte probe request) and
    falling back to Content-Length (only correct for a non-ranged response)."""
    cr = resp.headers.get("Content-Range", "")
    if cr and "/" in cr:
        try:
            total = cr.rsplit("/", 1)[1].strip()
            if total != "*":
                return int(total)
        except (ValueError, IndexError):
            pass
    cl = resp.headers.get("Content-Length")
    if cl:
        try:
            return int(cl)
        except ValueError:
            pass
    return None


def _filter_by_size(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Hard-filter candidates by min/max_size_gb from settings. Unlike
    preference ranking, these are exclusions, not just a sort order —
    "too small to be the real thing" and "too large for available
    bandwidth/storage" are genuine deal-breakers. A candidate with an
    unknown size is never excluded (size filters only apply when we
    actually know the size — better to let an unknown-size candidate
    through than wrongly drop something real).
    """
    try:
        from gateway import settings as _settings
        min_gb = _settings.get("min_size_gb", 0) or 0
        max_gb = _settings.get("max_size_gb", 0) or 0
    except Exception:
        min_gb = max_gb = 0

    if not min_gb and not max_gb:
        return streams

    min_bytes = min_gb * 1024 * 1024 * 1024 if min_gb else 0
    max_bytes = max_gb * 1024 * 1024 * 1024 if max_gb else None

    out = []
    for s in streams:
        if not s.size:
            out.append(s)   # unknown size — don't exclude
            continue
        if min_bytes and s.size < min_bytes:
            continue
        if max_bytes and s.size > max_bytes:
            continue
        out.append(s)
    return out


_EXCLUDE_WORD_RE_CACHE: dict = {}


def _exclude_word_pattern(word: str):
    pat = _EXCLUDE_WORD_RE_CACHE.get(word)
    if pat is None:
        # Match as a distinct token (surrounded by non-alphanumeric chars or
        # string edges) so e.g. excluding "cam" doesn't also reject a real
        # release whose title happens to contain "camera" or "campfire".
        pat = re.compile(rf'(?<![a-z0-9]){re.escape(word)}(?![a-z0-9])')
        _EXCLUDE_WORD_RE_CACHE[word] = pat
    return pat


def _filter_by_usenet_allowed(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Hard-filter out usenet-sourced candidates (AIOStreams' "type": "usenet" —
    its built-in NNTP engine, Easynews, NzbDAV/AltMount, Stremio NNTP,
    TorBox's usenet side, etc.) unless allow_usenet is enabled in settings.

    This is purely a gate on our side — if the user hasn't set up usenet
    in AIOStreams at all, AIOStreams never returns usenet-typed results in
    the first place and this is a no-op either way. When usenet IS
    configured there and allow_usenet is on (the default), usenet
    candidates are treated exactly like any other stream from here on:
    same size/exclude-word filters, same preference ranking, same live
    probe before being committed to.
    """
    try:
        from gateway import settings as _settings
        allow_usenet = bool(_settings.get("allow_usenet", True))
    except Exception:
        allow_usenet = True

    if allow_usenet:
        return streams

    return [s for s in streams if not s.is_usenet]


def _filter_by_exclude_words(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Hard-filter candidates whose filename or parsed quality/resolution tag
    matches a configured exclude word — e.g. "CAM", "TS", "TELESYNC" — so
    cam-rips, telesyncs, and other low-quality pre-release captures never
    get picked or counted as an available stream, even if they're the only
    thing that shows up yet (which is common right around a movie's
    release, when a real encode hasn't hit debrid caches).
    """
    try:
        from gateway import settings as _settings
        words = [w.strip().lower() for w in (_settings.get("exclude_words", []) or []) if w.strip()]
    except Exception:
        words = []

    if not words:
        return streams

    out = []
    for s in streams:
        haystack = " ".join([
            s.filename or "",
            (s.parsed_file.quality or "") if s.parsed_file else "",
            (s.parsed_file.resolution or "") if s.parsed_file else "",
            (s.parsed_file.encode or "") if s.parsed_file else "",
        ]).lower()
        if any(_exclude_word_pattern(w).search(haystack) for w in words):
            continue
        out.append(s)
    return out


def _pack_signature(s: "AIOStream") -> Optional[str]:
    """
    A stable identity for the release a stream came from, used to
    recognise "this is the same pack that already worked".

    The filename is the only field every addon reliably populates (url is
    per-episode and differs within one pack; infoHash isn't exposed on the
    search result), so it's what we key on. Lowercased and stripped of the
    path, since some addons return a full path inside the archive and
    others just the file.

    Returns None for anything that isn't a season/series pack — a
    single-episode file says nothing about its neighbours, which is the
    entire premise of this cache.
    """
    if not s.filename:
        return None
    kind, _ = s.pack_type
    if kind not in ("season", "series"):
        return None
    name = s.filename.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    return name.strip().lower() or None


# (imdb_id, quality, season|"series") -> {"sig": str, "at": float}
#
# Which pack last produced a WORKING stream for this show. Populated on a
# successful probe, read to reorder candidates before probing the next
# episode.
#
# This does not skip queries or reuse URLs — the per-episode URL is
# computed by AIOStreams and is the one thing that must not be guessed.
# It only reorders: a pack that just served a working stream for E05 is
# the best first guess for E06, so probe it first instead of working down
# a list where the first few candidates are frequently dead.
#
# The cost this removes is real and dominant. A dead candidate costs a
# full HTTP probe (~2s); the query itself is ~1.8s. An episode that
# probes 4 dead candidates before a live one spends ~9s of its ~11s
# probing. Landing on the known-good pack first turns that into one
# probe.
#
# In-memory and small by design: a wrong guess costs one extra probe and
# self-corrects, so there's nothing worth persisting across restarts.
_known_good_packs: dict[tuple, dict] = {}
_KNOWN_GOOD_PACK_TTL_S = 6 * 3600   # a debrid link's useful life, roughly


def _pack_cache_keys(item: "MediaItem", quality: "Quality") -> list[tuple]:
    """
    Keys to consult for this episode, most specific first: the season's
    own pack, then any series pack covering the whole show.
    """
    if item.media_type != MediaType.SERIES or item.season is None:
        return []
    return [
        (item.imdb_id, quality.value, item.season),
        (item.imdb_id, quality.value, "series"),
    ]


def _remember_working_pack(item: "MediaItem", quality: "Quality", s: "AIOStream") -> None:
    """Record that this pack produced a working stream."""
    sig = _pack_signature(s)
    if not sig or item.media_type != MediaType.SERIES or item.season is None:
        return
    kind, pack_season = s.pack_type
    scope = "series" if kind == "series" else (pack_season or item.season)
    _known_good_packs[(item.imdb_id, quality.value, scope)] = {
        "sig": sig, "at": time.time(),
    }


def _hoist_known_good_pack(
    streams: list["AIOStream"], item: "MediaItem", quality: "Quality"
) -> list["AIOStream"]:
    """
    Move candidates from an already-proven pack to the front, preserving
    the existing order otherwise. Ranking only — nothing is filtered, so
    if the remembered pack isn't among this episode's results the list is
    unchanged and probing proceeds exactly as before.
    """
    now = time.time()
    for key in _pack_cache_keys(item, quality):
        entry = _known_good_packs.get(key)
        if not entry:
            continue
        if now - entry["at"] > _KNOWN_GOOD_PACK_TTL_S:
            _known_good_packs.pop(key, None)      # stale — links likely expired
            continue
        sig = entry["sig"]
        matching = [s for s in streams if _pack_signature(s) == sig]
        if not matching:
            continue
        rest = [s for s in streams if _pack_signature(s) != sig]
        logger.info(
            "Trying known-good pack first for %s S%02dE%02d (%s)",
            item.imdb_id, item.season, item.episode or 0, quality.value,
        )
        return matching + rest
    return streams


def _forget_pack_if_matches(
    item: "MediaItem", quality: "Quality", failed: "AIOStream"
) -> None:
    """Drop a remembered pack when one of its links probes dead."""
    sig = _pack_signature(failed)
    if not sig:
        return
    for key in _pack_cache_keys(item, quality):
        entry = _known_good_packs.get(key)
        if entry and entry["sig"] == sig:
            _known_good_packs.pop(key, None)
            logger.info("Forgetting known-good pack for %s (%s) — its link probed dead",
                        item.imdb_id, quality.value)


def _rank_by_preferences(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Stable-sort candidates so ones matching configured preferences
    (preferred_language, preferred_audio, require_subtitles,
    prefer_season_packs) come first. This is ranking, not filtering —
    nothing is excluded, so if nothing matches the preference, the
    original AIOStreams ordering for the non-matching tail is preserved
    (AIOStreams' own sort/SEL config still has the final say among
    non-preferred candidates).

    prefer_season_packs ranks up candidates detected as a season or
    series pack (see detect_pack_type) over individual-episode files.
    Packs tend to be more heavily seeded/cached — the same underlying
    reliability concern as min_4k_candidates — so all else equal, a pack
    is a better bet than a lone episode file. This only affects episode
    queries; movie filenames never match the pack patterns, so it's a
    no-op for movies.
    """
    try:
        from gateway import settings as _settings
        pref_lang     = (_settings.get("preferred_language", "") or "").lower()
        pref_audio    = [a.lower() for a in (_settings.get("preferred_audio", []) or [])]
        require_subs  = bool(_settings.get("require_subtitles", False))
        prefer_packs  = bool(_settings.get("prefer_season_packs", True))
    except Exception:
        pref_lang, pref_audio, require_subs, prefer_packs = "", [], False, True

    if not pref_lang and not pref_audio and not require_subs and not prefer_packs:
        return streams

    def score(s: AIOStream) -> tuple:
        languages = [l.lower() for l in (s.parsed_file.languages or [])] if s.parsed_file else []
        audio_tags = [a.lower() for a in (s.parsed_file.audio_tags or [])] if s.parsed_file else []

        lang_match  = 1 if pref_lang and pref_lang in languages else 0
        pack_kind, _season_num = s.pack_type
        pack_match  = 1 if (prefer_packs and pack_kind in ("season", "series")) else 0
        audio_match = sum(1 for a in pref_audio if any(a in tag for tag in audio_tags))
        subs_match  = 1 if (require_subs and s.subtitles) else 0

        # Higher is better; Python's sort is stable so ties keep original order.
        return (lang_match, pack_match, audio_match, subs_match)

    return sorted(streams, key=score, reverse=True)


async def _probe_stream(candidate: AIOStream) -> bool:
    """
    Validate a candidate stream actually works before committing to it.
    Issues a tiny ranged GET (1 byte) rather than HEAD, because many debrid
    CDNs don't implement HEAD correctly but do honour Range on GET — a HEAD
    that 200s/405s isn't reliable evidence the link is really alive.

    Beyond the status code, also checks the TOTAL file size reported via
    Content-Range/Content-Length against _MIN_PLAUSIBLE_MEDIA_BYTES. A
    "successful" 200/206 backed by a tiny (sub-MB) file is exactly the
    failure mode that was slipping through: the debrid backend returns a
    real-looking response for a broken/expired link, the probe's status
    check alone passes it, and the genuinely tiny file gets accepted as if
    it were real media — only surfacing later as an ~8-second, sub-1MB
    "movie" in Plex.
    """
    if not candidate.url:
        return False
    try:
        timeout = aiohttp.ClientTimeout(total=_PROBE_TIMEOUT)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            headers = {**(candidate.request_headers or {}), "Range": "bytes=0-0"}
            async with session.get(candidate.url, headers=headers) as resp:
                # Drain a tiny bit so the connection closes cleanly
                await resp.content.read(1)
                if resp.status not in (200, 206):
                    return False
                total_size = _parse_total_size(resp)
                if total_size is not None and total_size < _MIN_PLAUSIBLE_MEDIA_BYTES:
                    logger.warning(
                        "Candidate rejected: reported size %d bytes (%.1f MB) is "
                        "implausibly small for real media — %s…",
                        total_size, total_size / 1024 / 1024, candidate.url[:60]
                    )
                    return False
                # If the candidate's own metadata claims a size, cross-check
                # it against what the probe actually saw — a mismatch is
                # also a sign of a broken/substituted link.
                if candidate.size and total_size and abs(candidate.size - total_size) > candidate.size * 0.1:
                    logger.warning(
                        "Candidate rejected: AIOStreams claimed %d bytes but "
                        "probe found %d bytes — %s…",
                        candidate.size, total_size, candidate.url[:60]
                    )
                    return False
                return True
    except Exception as exc:
        logger.debug("Probe failed for %s…: %s", candidate.url[:60], exc)
        return False


# ---------------------------------------------------------------------------
# Stub data — used when AIOSTREAMS_UUID is not set
# ---------------------------------------------------------------------------

def _stub_results(item: MediaItem) -> list[dict]:
    base = f"http://fake-cdn.local/streams/{item.imdb_id}"
    return [
        {
            "url": f"{base}/hd.mkv",
            "filename": f"{item.title}.1080p.BluRay.x265.mkv",
            "size": 8_500_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "1080p", "quality": "BluRay", "encode": "HEVC", "hdr": []},
        },
        {
            "url": f"{base}/4k.mkv",
            "filename": f"{item.title}.2160p.BluRay.DV.HDR10.mkv",
            "size": 42_000_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "2160p", "quality": "BluRay", "encode": "HEVC", "hdr": ["DV", "HDR10"]},
        },
    ]


# ---------------------------------------------------------------------------
# aiostream operators
# ---------------------------------------------------------------------------

@operator
async def _fetch_raw(
    session: aiohttp.ClientSession,
    item: MediaItem,
    url: str,
    uuid: str,
    password: str,
) -> AsyncIterator[dict]:
    """Yield raw SearchApiResult dicts that have a direct stream URL."""

    if not uuid:
        logger.warning("AIOSTREAMS_UUID not set — using stub data")
        await asyncio.sleep(0.05)
        for r in _stub_results(item):
            yield r
        return

    endpoint = f"{url}/api/v1/search"
    params   = {"type": item.aiostreams_type, "id": item.aiostreams_id}
    headers  = _auth_headers(uuid, password)

    try:
        async with _aiostreams_gate:
            # Logged here, not before the gate — this is the moment the
            # request actually gets sent, which is what makes the log
            # timestamps a meaningful way to see the real dispatch rate
            # rather than just when each caller started waiting its turn.
            logger.info("AIOStreams query: %s %s", endpoint, params)
            async with session.get(
                endpoint, params=params, headers=headers,
                timeout=aiohttp.ClientTimeout(total=60)
            ) as resp:
                if resp.status == 401:
                    raise RuntimeError(
                        "AIOStreams: invalid credentials (401). "
                        "Check AIOSTREAMS_UUID and AIOSTREAMS_PASSWORD in docker-compose.yml."
                    )
                if resp.status == 404:
                    raise RuntimeError(
                        "AIOStreams: /api/v1/search not found (404). "
                        "Check AIOSTREAMS_URL — should be http://host:3000 (not 3001)."
                    )
                resp.raise_for_status()
                data = await resp.json()
    except aiohttp.ClientConnectorError as exc:
        raise RuntimeError(
            f"Cannot connect to AIOStreams at {url}. "
            "Check AIOSTREAMS_URL and that AIOStreams is running."
        ) from exc
    except asyncio.TimeoutError as exc:
        # Previously uncaught here, and no caller logged it server-side
        # either — a slow/complex query (many addons, a title with heavy
        # fan-out) would silently show up only as a generic error to
        # whatever called this, with no way to tell "AIOStreams timed out"
        # apart from any other failure without digging through code.
        logger.warning("AIOStreams request timed out after 60s for %s", params)
        raise RuntimeError(
            f"AIOStreams did not respond within 60s for {item.title} — "
            "it may be slow for this particular title (a lot of addon "
            "fan-out) or temporarily overloaded."
        ) from exc

    if not data.get("success"):
        err = (data.get("error") or {}).get("message", "unknown error")
        raise RuntimeError(f"AIOStreams returned error: {err}")

    results = (data.get("data") or {}).get("results", [])
    errors  = (data.get("data") or {}).get("errors", [])
    total   = len(results)
    logger.info("AIOStreams returned %d total results", total)

    if errors:
        for e in errors:
            logger.warning("AIOStreams addon error — %s: %s", e.get("title",""), e.get("description",""))

    # 0 results = episode not available — yield nothing, caller handles it
    if total == 0:
        if errors:
            for e in errors:
                logger.debug("Addon error: %s — %s", e.get("title",""), e.get("description",""))
        return

    yielded = 0
    for r in results:
        if r.get("url"):    # only results with a direct HTTP URL
            yield r
            yielded += 1

    logger.info("Yielded %d results with direct URLs (out of %d total)", yielded, total)

    # Results present but no direct url — log for debugging, yield nothing
    if yielded == 0 and total > 0:
        for i, r in enumerate(results[:2]):
            logger.warning(
                "Result[%d] has no direct url — keys: %s | externalUrl=%r",
                i, list(r.keys()), r.get("externalUrl")
            )


@operator
async def _parse(raw: dict) -> AsyncIterator[AIOStream]:
    yield AIOStream.from_api(raw)


# ---------------------------------------------------------------------------
# Public client
# ---------------------------------------------------------------------------

class AIOStreamsClient:
    """Async client for AIOStreams /api/v1/search."""

    def __init__(self) -> None:
        self._session: aiohttp.ClientSession | None = None

    async def open(self) -> None:
        self._session = aiohttp.ClientSession()

    async def close(self) -> None:
        if self._session:
            await self._session.close()
            self._session = None

    def stream_results(self, item: MediaItem):
        assert self._session
        aio_url, uuid, password = _cfg()
        raw = _fetch_raw(self._session, item, aio_url, uuid, password)
        return raw | pipe.flatmap(lambda d: _parse(d))

    def stream_4k(self, item: MediaItem):
        return self.stream_results(item) | pipe.filter(lambda s: s.is_4k)

    def stream_hd(self, item: MediaItem):
        return self.stream_results(item) | pipe.filter(lambda s: not s.is_4k)

    async def resolve_all(self, item: MediaItem) -> list[AIOStream]:
        all_s = await astream.list(self.stream_results(item))
        all_s = _filter_by_usenet_allowed(all_s)
        all_s = _filter_by_exclude_words(all_s)
        # Ranking was previously applied only in best_working_for_quality,
        # i.e. only on the play-time resolve path. Every discovery path
        # (adds, background scans, the auto-episode sweep) goes through
        # resolve_all instead, so prefer_season_packs had no effect on
        # whether a pack was ever noticed — pack detection came down to
        # AIOStreams' own sort order putting one first by luck. Ranking
        # here makes discovery and playback agree on what the best
        # candidate is, and is what lets pack-first filling reliably see
        # a pack when one exists.
        return _rank_by_preferences(all_s)

    async def best_for_quality(self, item: MediaItem, quality: Quality) -> AIOStream | None:
        src = self.stream_4k(item) if quality == Quality.UHD else self.stream_hd(item)
        all_s = await astream.list(src)
        all_s = _filter_by_usenet_allowed(all_s)
        all_s = _filter_by_exclude_words(all_s)
        cached = [s for s in all_s if s.cached]
        return (cached or all_s or [None])[0]

    async def best_working_for_quality(
        self, item: MediaItem, quality: Quality, max_candidates: int = 5
    ) -> AIOStream | None:
        """
        Like best_for_quality(), but probes each candidate with a real HTTP
        request before committing to it, falling through to the next one if
        a link is dead (404/410/connection refused/timeout/etc). This is the
        fix for "bad links" — a single dead link no longer breaks playback
        for an entire title when other valid sources exist.

        Before probing, candidates are filtered by hard size bounds and
        excluded words, then ranked by stream preferences (language, audio,
        subtitles) from settings — see _filter_by_size, _filter_by_exclude_
        words, and _rank_by_preferences. Tries up to `max_candidates` of the
        resulting ranked list.
        """
        src = self.stream_4k(item) if quality == Quality.UHD else self.stream_hd(item)
        all_s = await astream.list(src)
        if not all_s:
            return None

        all_s = _filter_by_size(all_s)
        if not all_s:
            logger.warning("All candidates for %s (%s) excluded by size bounds",
                           item.title, quality.value)
            return None

        all_s = _filter_by_exclude_words(all_s)
        if not all_s:
            logger.warning("All candidates for %s (%s) excluded by exclude words",
                           item.title, quality.value)
            return None

        all_s = _filter_by_usenet_allowed(all_s)
        if not all_s:
            logger.warning("All candidates for %s (%s) excluded — usenet results disabled",
                           item.title, quality.value)
            return None

        all_s = _rank_by_preferences(all_s)

        cached     = [s for s in all_s if s.cached]
        uncached   = [s for s in all_s if not s.cached]
        candidates = (cached + uncached)[:max_candidates]

        # Applied last, so it outranks the preference sort: a pack that
        # has actually served a working stream for this show is stronger
        # evidence than any heuristic about what should work. Reorders
        # only within the already-filtered, already-ranked candidate list.
        candidates = _hoist_known_good_pack(candidates, item, quality)

        for i, candidate in enumerate(candidates):
            if not candidate.url:
                continue
            ok = await _probe_stream(candidate)
            if ok:
                if i > 0:
                    logger.info("Skipped %d dead candidate(s) before finding a working stream", i)
                _remember_working_pack(item, quality, candidate)
                return candidate
            logger.warning("Candidate %d/%d dead: %s…",
                           i + 1, len(candidates), candidate.url[:60])
            # If the pack we hoisted is itself dead, drop it now. Leaving
            # it cached would put a known-bad candidate first for every
            # remaining episode of the season — turning the optimisation
            # into a guaranteed extra probe each time.
            _forget_pack_if_matches(item, quality, candidate)

        logger.warning("All %d candidate(s) for %s (%s) were dead",
                       len(candidates), item.title, quality.value)
        raise AllCandidatesDeadError(len(candidates))

    async def connection_test(self) -> dict:
        """Test connectivity and return a diagnostic dict."""
        aio_url, uuid, password = _cfg()
        result = {
            "url": aio_url,
            "uuid_set": bool(uuid),
            "ok": False,
            "error": None,
            "status_code": None,
            "diagnosis": None,
        }
        if not uuid:
            result["error"] = "AIOSTREAMS_UUID not set — running in stub mode"
            result["diagnosis"] = "stub"
            return result
        try:
            async with self._session.get(
                f"{aio_url}/api/v1/search",
                params={"type": "movie", "id": "tt0068646"},   # The Godfather — widely indexed
                headers=_auth_headers(uuid, password),
                timeout=aiohttp.ClientTimeout(total=8),
            ) as resp:
                result["status_code"] = resp.status
                if resp.status == 401:
                    result["error"] = "Invalid credentials (401)"
                    result["diagnosis"] = "bad_auth"
                elif resp.status == 200:
                    data = await resp.json()
                    results = (data.get("data") or {}).get("results", [])
                    errors  = (data.get("data") or {}).get("errors", [])
                    with_url = [r for r in results if r.get("url")]
                    result["ok"] = True
                    result["total_results"] = len(results)
                    result["direct_urls"] = len(with_url)
                    result["addon_errors"] = len(errors)
                    if len(results) == 0:
                        result["diagnosis"] = "no_addons"
                        result["error"] = (
                            f"Connected but 0 results returned. "
                            f"No addons or debrid configured in AIOStreams. "
                            f"Visit {aio_url}/stremio/configure"
                        )
                        result["ok"] = False
                    elif len(with_url) == 0:
                        result["diagnosis"] = "no_debrid"
                        result["error"] = (
                            f"Connected, {len(results)} results, but none have a direct URL. "
                            "Add a debrid service (Real-Debrid etc.) in AIOStreams."
                        )
                        result["ok"] = False
                    else:
                        result["diagnosis"] = "ok"
                else:
                    result["error"] = f"HTTP {resp.status}"
        except Exception as exc:
            result["error"] = str(exc)
            result["diagnosis"] = "unreachable"
        return result
