"""
gateway/aiostreams_client.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Connects to the real AIOStreams /api/v1/search endpoint.

Environment variables (read at call time):
  AIOSTREAMS_URL       — e.g. http://192.168.1.x:3000
  AIOSTREAMS_UUID      — your user UUID from AIOStreams Settings page
  AIOSTREAMS_PASSWORD  — your password from AIOStreams Settings page

If AIOSTREAMS_UUID is empty the client returns stub data for testing.
"""
from __future__ import annotations

import asyncio
import base64
import logging
import os
import re
import time
from typing import AsyncIterator, Optional

import aiohttp
from aiostream import operator, pipe, stream as astream

from .models import AIOStream, MediaItem, MediaType, Quality


class AllCandidatesDeadError(Exception):
    """
    Raised by best_working_for_quality specifically when at least one
    candidate existed and every single one failed its live probe — a much
    stronger signal than the plain "no candidates at all" case (which just
    returns None, since that could easily mean nothing's been cached yet
    and might show up later). Callers that want to treat "exhaustively
    tried and all dead" differently from "genuinely nothing found" catch
    this specifically instead of just checking for a None return.
    """
    def __init__(self, count: int):
        self.count = count
        super().__init__(f"All {count} candidate(s) were dead")

logger = logging.getLogger("aiogateway.aiostreams")


def _cfg():
    return (
        os.environ.get("AIOSTREAMS_URL",      "http://localhost:3001"),
        os.environ.get("AIOSTREAMS_UUID",     ""),
        os.environ.get("AIOSTREAMS_PASSWORD", ""),
    )


def _auth_headers(uuid: str, password: str) -> dict:
    token = base64.b64encode(f"{uuid}:{password}".encode()).decode()
    return {"Authorization": f"Basic {token}"}


_PROBE_TIMEOUT = float(os.environ.get("AIOSTREAMS_PROBE_TIMEOUT", "6"))
# Candidates probed at once. 1 = one at a time (default; see _probe_in_order).
_PROBE_PARALLEL = max(1, int(os.environ.get("AIOSTREAMS_PROBE_PARALLEL", "1")))
# Waits before each re-search when a whole search's candidates all failed.
_RESEARCH_DELAYS = (5, 15, 30)

# ---------------------------------------------------------------------------
# Global rate gate for AIOStreams /api/v1/search queries
# ---------------------------------------------------------------------------
# Every code path that talks to AIOStreams — webhook play-triggered resolves,
# background episode scans (one independent task per tracked show), the
# auto-episode discovery sweep, and bulk migration — all funnel through
# _fetch_raw() below. Each of those call sites already has its own local
# concurrency limit (a semaphore here, a "1s between episodes" there,
# migration's worker pool), but none of them coordinate with each other —
# so e.g. migrating a dozen shows at once spins up a dozen independent
# background scan tasks that all start querying AIOStreams simultaneously,
# on top of migration's own concurrent requests. The result, seen in
# practice: nearly every single query gets rate limited (429), even though
# each individual caller was already pacing itself.
#
# This gate fixes that at the root by capping the ACTUAL outbound request
# rate to AIOStreams app-wide, no matter how many independent tasks are
# trying to query at once — a semaphore alone isn't enough since it only
# limits how many requests are in flight, not how fast new ones are
# launched.
#
# Worth knowing: AIOStreams itself fans a single query out to every addon
# you have configured (Comet, MediaFusion, etc.) in parallel — so even a
# modest top-level request rate from us can still translate into a much
# higher burst of requests hitting those addons, which is outside our
# control. The only lever we have is how often WE query AIOStreams, so
# when 429s/502s are still frequent, slowing this down further (fewer,
# more spaced-out top-level queries) is the only knob that actually helps.
#
# Concurrency is fixed at process start (from settings, defaulting to
# fully serialized — only 1 request in flight at a time app-wide).
# min_interval is re-read from settings on every single request, so it
# can be tuned live from the Config UI without a container restart.
_AIOSTREAMS_MAX_CONCURRENT = int(os.environ.get("AIOSTREAMS_MAX_CONCURRENT", "0")) or None  # None = read from settings


def _live_min_interval_ms() -> float:
    try:
        from gateway import settings as _settings
        return float(_settings.get("aiostreams_min_interval_ms", 3000))
    except Exception:
        return 3000.0


def _configured_max_concurrent() -> int:
    if _AIOSTREAMS_MAX_CONCURRENT is not None:
        return _AIOSTREAMS_MAX_CONCURRENT   # explicit env override wins
    try:
        from gateway import settings as _settings
        return int(_settings.get("aiostreams_max_concurrent", 1))
    except Exception:
        return 1


import contextvars

# Set by gateway/resolver.py around playback searches (placeholder switch,
# repair, refresh). Those jump ahead of queued background searches.
play_priority: contextvars.ContextVar[bool] = contextvars.ContextVar("aiogw_play_priority", default=False)


class _RateGate:
    """
    Caps how many AIOStreams requests are in flight (max_concurrent, sized
    once at first use) and how fast new ones start (min_interval_ms,
    re-read live), with two properties the old version lacked:

    * Cancellation-safe. The old __aenter__ took the semaphore and THEN
      slept out the spacing interval; a task cancelled during that sleep
      (e.g. a series' background 4K check, cancelled when the next season
      was added) never reached __aexit__, so the only slot leaked and every
      later search — including playback — waited forever. Every exit path
      here gives the slot back.

    * Playback first. A search made under play_priority goes ahead of any
      queued background search instead of waiting behind, say, ten
      seasons of 4K checks.
    """

    def __init__(self):
        self._cond: Optional[asyncio.Condition] = None
        self._limit: Optional[int] = None
        self._in_flight = 0
        self._high_waiting = 0
        self._spacing_lock: Optional[asyncio.Lock] = None
        self._last_started_at = 0.0

    def _setup(self) -> None:
        if self._cond is None:
            self._cond = asyncio.Condition()
            self._spacing_lock = asyncio.Lock()
            self._limit = max(1, _configured_max_concurrent())

    async def __aenter__(self):
        self._setup()
        high = play_priority.get()
        cond = self._cond
        async with cond:
            if high:
                self._high_waiting += 1
            try:
                await cond.wait_for(
                    lambda: self._in_flight < self._limit and (high or self._high_waiting == 0)
                )
                self._in_flight += 1
            finally:
                if high:
                    self._high_waiting -= 1
                    cond.notify_all()
        try:
            async with self._spacing_lock:
                min_interval = max(0.0, _live_min_interval_ms()) / 1000.0
                loop = asyncio.get_running_loop()
                wait = min_interval - (loop.time() - self._last_started_at)
                if wait > 0:
                    await asyncio.sleep(wait)
                self._last_started_at = loop.time()
        except BaseException:
            await self._release()
            raise
        return self

    async def _release(self) -> None:
        async with self._cond:
            self._in_flight = max(0, self._in_flight - 1)
            self._cond.notify_all()

    async def __aexit__(self, exc_type, exc, tb):
        await asyncio.shield(self._release())
        return False


_aiostreams_gate = _RateGate()

# A candidate's TOTAL reported size (from Content-Range on the probe
# response, or Content-Length as a fallback) must be at least this large to
# be accepted as real movie/episode video. This catches debrid backends that
# return a 200/206 "success" for a broken/expired link backed by a tiny
# placeholder, error page, or partial/corrupted file — which otherwise pass
# the probe's status-code check while being unmistakably not real content.
# 50MB is comfortably below even a short, heavily compressed TV episode.
_MIN_PLAUSIBLE_MEDIA_BYTES = int(os.environ.get("AIOSTREAMS_MIN_MEDIA_BYTES", str(50 * 1024 * 1024)))


def _parse_total_size(resp) -> Optional[int]:
    """Extract the TOTAL file size from a ranged response, preferring
    Content-Range's total (works even for a 1-byte probe request) and
    falling back to Content-Length (only correct for a non-ranged response)."""
    cr = resp.headers.get("Content-Range", "")
    if cr and "/" in cr:
        try:
            total = cr.rsplit("/", 1)[1].strip()
            if total != "*":
                return int(total)
        except (ValueError, IndexError):
            pass
    cl = resp.headers.get("Content-Length")
    if cl:
        try:
            return int(cl)
        except ValueError:
            pass
    return None


def _filter_by_size(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Hard-filter candidates by min/max_size_gb from settings. Unlike
    preference ranking, these are exclusions, not just a sort order —
    "too small to be the real thing" and "too large for available
    bandwidth/storage" are genuine deal-breakers. A candidate with an
    unknown size is never excluded (size filters only apply when we
    actually know the size — better to let an unknown-size candidate
    through than wrongly drop something real).
    """
    try:
        from gateway import settings as _settings
        min_gb = _settings.get("min_size_gb", 0) or 0
        max_gb = _settings.get("max_size_gb", 0) or 0
    except Exception:
        min_gb = max_gb = 0

    if not min_gb and not max_gb:
        return streams

    min_bytes = min_gb * 1024 * 1024 * 1024 if min_gb else 0
    max_bytes = max_gb * 1024 * 1024 * 1024 if max_gb else None

    out = []
    for s in streams:
        if not s.size:
            out.append(s)   # unknown size — don't exclude
            continue
        if min_bytes and s.size < min_bytes:
            continue
        if max_bytes and s.size > max_bytes:
            continue
        out.append(s)
    return out


_EXCLUDE_WORD_RE_CACHE: dict = {}


def _exclude_word_pattern(word: str):
    pat = _EXCLUDE_WORD_RE_CACHE.get(word)
    if pat is None:
        # Match as a distinct token (surrounded by non-alphanumeric chars or
        # string edges) so e.g. excluding "cam" doesn't also reject a real
        # release whose title happens to contain "camera" or "campfire".
        pat = re.compile(rf'(?<![a-z0-9]){re.escape(word)}(?![a-z0-9])')
        _EXCLUDE_WORD_RE_CACHE[word] = pat
    return pat


def _filter_by_usenet_allowed(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Hard-filter out usenet-sourced candidates (AIOStreams' "type": "usenet" —
    its built-in NNTP engine, Easynews, NzbDAV/AltMount, Stremio NNTP,
    TorBox's usenet side, etc.) unless allow_usenet is enabled in settings.

    This is purely a gate on our side — if the user hasn't set up usenet
    in AIOStreams at all, AIOStreams never returns usenet-typed results in
    the first place and this is a no-op either way. When usenet IS
    configured there and allow_usenet is on (the default), usenet
    candidates are treated exactly like any other stream from here on:
    same size/exclude-word filters, same preference ranking, same live
    probe before being committed to.
    """
    try:
        from gateway import settings as _settings
        allow_usenet = bool(_settings.get("allow_usenet", True))
    except Exception:
        allow_usenet = True

    if allow_usenet:
        return streams

    return [s for s in streams if not s.is_usenet]


def _filter_by_exclude_words(streams: list[AIOStream]) -> list[AIOStream]:
    """
    Hard-filter candidates whose filename or parsed quality/resolution tag
    matches a configured exclude word — e.g. "CAM", "TS", "TELESYNC" — so
    cam-rips, telesyncs, and other low-quality pre-release captures never
    get picked or counted as an available stream, even if they're the only
    thing that shows up yet (which is common right around a movie's
    release, when a real encode hasn't hit debrid caches).
    """
    try:
        from gateway import settings as _settings
        words = [w.strip().lower() for w in (_settings.get("exclude_words", []) or []) if w.strip()]
    except Exception:
        words = []

    if not words:
        return streams

    out = []
    for s in streams:
        haystack = " ".join([
            s.filename or "",
            (s.parsed_file.quality or "") if s.parsed_file else "",
            (s.parsed_file.resolution or "") if s.parsed_file else "",
            (s.parsed_file.encode or "") if s.parsed_file else "",
        ]).lower()
        if any(_exclude_word_pattern(w).search(haystack) for w in words):
            continue
        out.append(s)
    return out


def _pack_signature(s: "AIOStream") -> Optional[str]:
    """
    A stable identity for the release (pack) a stream came from, used to
    recognise "this is the same pack that already worked".

    infoHash identifies the torrent exactly and is shared by every episode
    file in it, so it's preferred. folderName is the next best thing (same
    for every file in one pack). The old code keyed on `filename`, which is
    the per-episode file name and therefore different for every episode of
    the same pack — so a remembered pack could never match the next
    episode and the hoist never fired.

    Returns None for anything that isn't a season/series pack — a
    single-episode file says nothing about its neighbours.
    """
    kind, _ = s.pack_type
    if kind not in ("season", "series"):
        return None
    if s.info_hash:
        return "ih:" + s.info_hash.strip().lower()
    if s.folder_name:
        return "fn:" + s.folder_name.strip().lower()
    if not s.filename:
        return None
    name = s.filename.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    return ("f:" + name.strip().lower()) if name.strip() else None


# (imdb_id, quality, season|"series") -> {"sig": str, "at": float}
#
# Which pack last produced a WORKING stream for this show. Populated on a
# successful probe, read to reorder candidates before probing the next
# episode.
#
# This does not skip queries or reuse URLs — the per-episode URL is
# computed by AIOStreams and is the one thing that must not be guessed.
# It only reorders: a pack that just served a working stream for E05 is
# the best first guess for E06, so probe it first instead of working down
# a list where the first few candidates are frequently dead.
#
# The cost this removes is real and dominant. A dead candidate costs a
# full HTTP probe (~2s); the query itself is ~1.8s. An episode that
# probes 4 dead candidates before a live one spends ~9s of its ~11s
# probing. Landing on the known-good pack first turns that into one
# probe.
#
# In-memory and small by design: a wrong guess costs one extra probe and
# self-corrects, so there's nothing worth persisting across restarts.
_known_good_packs: dict[tuple, dict] = {}
_KNOWN_GOOD_PACK_TTL_S = 6 * 3600   # a debrid link's useful life, roughly


def _pack_cache_keys(item: "MediaItem", quality: "Quality") -> list[tuple]:
    """
    Keys to consult for this episode, most specific first: the season's
    own pack, then any series pack covering the whole show.
    """
    if item.media_type != MediaType.SERIES or item.season is None:
        return []
    return [
        (item.imdb_id, quality.value, item.season),
        (item.imdb_id, quality.value, "series"),
    ]


def _remember_working_pack(item: "MediaItem", quality: "Quality", s: "AIOStream") -> None:
    """Record that this pack produced a working stream."""
    sig = _pack_signature(s)
    if not sig or item.media_type != MediaType.SERIES or item.season is None:
        return
    kind, pack_season = s.pack_type
    scope = "series" if kind == "series" else (pack_season or item.season)
    _known_good_packs[(item.imdb_id, quality.value, scope)] = {
        "sig": sig, "at": time.time(),
    }


def _hoist_known_good_pack(
    streams: list["AIOStream"], item: "MediaItem", quality: "Quality"
) -> list["AIOStream"]:
    """
    Move candidates from an already-proven pack to the front, preserving
    the existing order otherwise. Ranking only — nothing is filtered, so
    if the remembered pack isn't among this episode's results the list is
    unchanged and probing proceeds exactly as before.
    """
    now = time.time()
    for key in _pack_cache_keys(item, quality):
        entry = _known_good_packs.get(key)
        if not entry:
            continue
        if now - entry["at"] > _KNOWN_GOOD_PACK_TTL_S:
            _known_good_packs.pop(key, None)      # stale — links likely expired
            continue
        sig = entry["sig"]
        matching = [s for s in streams if _pack_signature(s) == sig]
        if not matching:
            continue
        rest = [s for s in streams if _pack_signature(s) != sig]
        logger.info(
            "Trying known-good pack first for %s S%02dE%02d (%s)",
            item.imdb_id, item.season, item.episode or 0, quality.value,
        )
        return matching + rest
    return streams


def _forget_pack_if_matches(
    item: "MediaItem", quality: "Quality", failed: "AIOStream"
) -> None:
    """Drop a remembered pack when one of its links probes dead."""
    sig = _pack_signature(failed)
    if not sig:
        return
    for key in _pack_cache_keys(item, quality):
        entry = _known_good_packs.get(key)
        if entry and entry["sig"] == sig:
            _known_good_packs.pop(key, None)
            logger.info("Forgetting known-good pack for %s (%s) — its link probed dead",
                        item.imdb_id, quality.value)


def _rank_by_preferences(streams: list[AIOStream], media_type: Optional["MediaType"] = None) -> list[AIOStream]:
    """
    Stable-sort candidates so ones matching configured preferences
    (preferred_language, preferred_audio, require_subtitles,
    prefer_season_packs) come first. This is ranking, not filtering —
    nothing is excluded, so if nothing matches the preference, the
    original AIOStreams ordering for the non-matching tail is preserved
    (AIOStreams' own sort/SEL config still has the final say among
    non-preferred candidates).

    prefer_season_packs ranks up candidates detected as a season or
    series pack (see detect_pack_type) over individual-episode files.
    Packs tend to be more heavily seeded/cached — the same underlying
    reliability concern as min_4k_candidates — so all else equal, a pack
    is a better bet than a lone episode file.

    This is a TV-only concept, so `media_type` gates it explicitly:
    pack_match is only ever scored when media_type == SERIES. Movie
    release names routinely contain incidental "s" + digits substrings
    that detect_pack_type's regex can't tell apart from a real season
    marker — a resolution/format tag like "DS4K" reads as "S4", a
    stereoscopic "S3D" reads as "S3", etc. Without this gate, a movie
    whose filename happens to collide with the pattern would get
    boosted to the top of its own search results ahead of otherwise
    equal or better candidates, for a reason that has nothing to do with
    it actually being a pack — because for a movie, it never is one.
    """
    try:
        from gateway import settings as _settings
        pref_lang     = (_settings.get("preferred_language", "") or "").lower()
        pref_audio    = [a.lower() for a in (_settings.get("preferred_audio", []) or [])]
        require_subs  = bool(_settings.get("require_subtitles", False))
        prefer_packs  = bool(_settings.get("prefer_season_packs", True)) and media_type == MediaType.SERIES
    except Exception:
        pref_lang, pref_audio, require_subs, prefer_packs = "", [], False, False

    if not pref_lang and not pref_audio and not require_subs and not prefer_packs:
        return streams

    def score(s: AIOStream) -> tuple:
        languages = [l.lower() for l in (s.parsed_file.languages or [])] if s.parsed_file else []
        audio_tags = [a.lower() for a in (s.parsed_file.audio_tags or [])] if s.parsed_file else []

        lang_match  = 1 if pref_lang and pref_lang in languages else 0
        # Series pack > season pack > single episode (see AIOStream.pack_tier).
        pack_match  = (2 - s.pack_tier(None)) if prefer_packs else 0
        audio_match = sum(1 for a in pref_audio if any(a in tag for tag in audio_tags))
        subs_match  = 1 if (require_subs and s.subtitles) else 0

        # Higher is better; Python's sort is stable so ties keep original order.
        return (lang_match, pack_match, audio_match, subs_match)

    return sorted(streams, key=score, reverse=True)


class ProbeResult:
    """Outcome of one live probe: whether the link serves real media, and
    the total size it reported (None if the server didn't say)."""
    __slots__ = ("ok", "size", "reason")

    def __init__(self, ok: bool, size: Optional[int] = None, reason: str = ""):
        self.ok, self.size, self.reason = ok, size, reason

    def __bool__(self) -> bool:
        return self.ok


_NON_MEDIA_TYPES = ("json", "text/html", "text/plain")


async def probe_stream(candidate: AIOStream) -> ProbeResult:
    """
    Validate a candidate link actually serves media before committing to
    it. Issues a tiny ranged GET (bytes=0-0) rather than HEAD, because many
    debrid CDNs don't implement HEAD correctly but do honour Range on GET.

    Rejects: non-2xx, a JSON/HTML/plain-text body (debrid error pages that
    come back as 200), a total size under _MIN_PLAUSIBLE_MEDIA_BYTES (the
    "downloading…" placeholder video uncached debrid links serve, or an
    expired link backed by a tiny file), and a size that disagrees with
    what AIOStreams claimed by more than 10%.
    """
    if not candidate.url:
        return ProbeResult(False, reason="no url")
    try:
        timeout = aiohttp.ClientTimeout(total=_PROBE_TIMEOUT)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            headers = {**(candidate.request_headers or {}), "Range": "bytes=0-0"}
            async with session.get(candidate.url, headers=headers) as resp:
                if resp.status not in (200, 206):
                    # Say WHO refused: AIOStreams' playback route itself
                    # never answers 403 (it 307-redirects to the debrid
                    # CDN), so the final host tells AIOStreams problems
                    # apart from debrid/CDN ones.
                    try:
                        body = (await resp.content.read(160)).decode("utf-8", "replace")
                    except Exception:
                        body = ""
                    body = " ".join(body.split())[:120]
                    host = resp.url.host or "?"
                    hops = len(resp.history)
                    return ProbeResult(False, reason=(
                        f"HTTP {resp.status} from {host}"
                        + (f" after {hops} redirect(s)" if hops else "")
                        + (f": {body}" if body else "")
                    ))
                await resp.content.read(1)
                ctype = (resp.headers.get("Content-Type") or "").lower()
                if any(t in ctype for t in _NON_MEDIA_TYPES):
                    return ProbeResult(False, reason=f"non-media content-type {ctype!r}")
                total_size = _parse_total_size(resp)
                if total_size is not None and total_size < _MIN_PLAUSIBLE_MEDIA_BYTES:
                    return ProbeResult(False, total_size,
                                       f"implausibly small ({total_size / 1024 / 1024:.1f} MB)")
                if candidate.size and total_size and abs(candidate.size - total_size) > candidate.size * 0.1:
                    return ProbeResult(False, total_size,
                                       f"size mismatch (claimed {candidate.size}, got {total_size})")
                return ProbeResult(True, total_size or candidate.size)
    except Exception as exc:
        return ProbeResult(False, reason=f"{type(exc).__name__}: {exc}"[:120])


async def _probe_stream(candidate: AIOStream) -> bool:
    """Back-compat boolean wrapper around probe_stream()."""
    return (await probe_stream(candidate)).ok


def _cache_rank(s: AIOStream) -> int:
    # True (cached) → 0, unknown → 1, explicitly uncached → 2. An uncached
    # debrid link can't play now — hitting it just queues a download and
    # serves a "downloading" clip — so those are only tried after every
    # source that can actually play immediately.
    if s.cached is True:
        return 0
    if s.cached is None:
        return 1
    return 2


def _same_size(a: Optional[int], b: Optional[int]) -> bool:
    return bool(a and b and abs(a - b) <= 64 * 1024)


def order_for_resolution(
    streams: list[AIOStream],
    item: MediaItem,
    quality: Quality,
    prefer_file_id: Optional[str] = None,
    prefer_size: Optional[int] = None,
    demote_urls: Optional[set] = None,
) -> list[AIOStream]:
    """
    The single ordering every resolve path uses (placeholder switch,
    24-hour refresh, real-time repair, look-ahead, manual scans).

    1. Same file as the stub already serves (prefer_file_id / prefer_size)
       — only set for refresh/repair, where swapping to different bytes
       under an open playback would corrupt it.
    2. Playable-now first: cached → unknown → uncached.
    3. Series only: series pack → season pack (this season) → episode.
       A pack that has already produced a working link for this show is
       hoisted to the front of its tier.
    4. Configured preferences (language, audio, subtitles), then
       AIOStreams' own order — the sort is stable throughout.

    Links in demote_urls (the one that just failed) go last rather than
    being dropped: AIOStreams playback URLs are often stable proxy URLs
    that re-unrestrict on each request, so a fresh probe of the "same"
    URL can legitimately succeed.
    """
    demote_urls = demote_urls or set()
    ranked = _rank_by_preferences(streams, item.media_type)
    ranked = _hoist_known_good_pack(ranked, item, quality)
    position = {id(s): i for i, s in enumerate(ranked)}
    is_series = item.media_type == MediaType.SERIES

    def key(s: AIOStream) -> tuple:
        same = 0
        if prefer_file_id and s.file_identity == prefer_file_id:
            same = -2
        elif prefer_size and _same_size(s.size, prefer_size):
            same = -1
        tier = s.pack_tier(item.season) if is_series else 0
        return (
            1 if s.url in demote_urls else 0,
            same,
            _cache_rank(s),
            tier,
            position[id(s)],
        )

    return sorted([s for s in ranked if s.url], key=key)


def _apply_hard_filters(all_s: list[AIOStream], item: MediaItem, quality: Quality) -> list[AIOStream]:
    """Size bounds, exclude words, usenet gate — logged when they empty the list."""
    for fn, why in (
        (_filter_by_size, "size bounds"),
        (_filter_by_exclude_words, "exclude words"),
        (_filter_by_usenet_allowed, "usenet results disabled"),
    ):
        before = len(all_s)
        all_s = fn(all_s)
        if before and not all_s:
            logger.warning("All candidates for %s (%s) excluded by %s", item.title, quality.value, why)
            return []
    return all_s


# ---------------------------------------------------------------------------
# Stub data — used when AIOSTREAMS_UUID is not set
# ---------------------------------------------------------------------------

def _stub_results(item: MediaItem) -> list[dict]:
    base = f"http://fake-cdn.local/streams/{item.imdb_id}"
    return [
        {
            "url": f"{base}/hd.mkv",
            "filename": f"{item.title}.1080p.BluRay.x265.mkv",
            "size": 8_500_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "1080p", "quality": "BluRay", "encode": "HEVC", "hdr": []},
        },
        {
            "url": f"{base}/4k.mkv",
            "filename": f"{item.title}.2160p.BluRay.DV.HDR10.mkv",
            "size": 42_000_000_000,
            "service": "realdebrid",
            "cached": True,
            "addon": "torrentio",
            "requestHeaders": {},
            "responseHeaders": {},
            "parsedFile": {"resolution": "2160p", "quality": "BluRay", "encode": "HEVC", "hdr": ["DV", "HDR10"]},
        },
    ]


# ---------------------------------------------------------------------------
# Search result cache + in-flight de-duplication
# ---------------------------------------------------------------------------
# The rate gate above only spaces requests out; it never avoids one. In
# practice the same (type, id) is queried over and over in a short window:
# stream_hd() and stream_4k() each ran their own identical search for the
# same title, discovery → prewarm → play resolved the same item back to
# back, and concurrent background tasks asked for the same show at once.
# Each of those was a full AIOStreams fan-out to every configured addon.
#
# Now every search is cached per (type, id) for AIOSTREAMS_CACHE_SECONDS,
# and concurrent callers for the same key share one in-flight request
# instead of each queuing their own. Empty results are cached too (for a
# shorter time) since "nothing yet" is the commonest answer during
# background sweeps. Errors are never cached.
#
# Freshness where it matters: play-time resolves pass fresh=True (skips
# the cache read but still refreshes it), and a probe that finds every
# candidate dead invalidates the entry so the next attempt re-queries.
_CACHE_TTL_S       = float(os.environ.get("AIOSTREAMS_CACHE_SECONDS", "900"))
_CACHE_EMPTY_TTL_S = float(os.environ.get("AIOSTREAMS_CACHE_EMPTY_SECONDS", "600"))
_CACHE_MAX_ENTRIES = int(os.environ.get("AIOSTREAMS_CACHE_MAX_ENTRIES", "500"))

_search_cache: dict[tuple, tuple[float, list]] = {}   # key -> (expires_at, results)
_inflight: dict[tuple, asyncio.Future] = {}


def _cache_key(item: MediaItem) -> tuple:
    return (item.aiostreams_type, item.aiostreams_id)


def invalidate_search_cache(item: MediaItem) -> None:
    _search_cache.pop(_cache_key(item), None)


def _cache_put(key: tuple, results: list) -> None:
    ttl = _CACHE_TTL_S if results else _CACHE_EMPTY_TTL_S
    if ttl <= 0:
        return
    if len(_search_cache) >= _CACHE_MAX_ENTRIES:
        now = time.time()
        for k in [k for k, (exp, _) in _search_cache.items() if exp <= now]:
            _search_cache.pop(k, None)
        while len(_search_cache) >= _CACHE_MAX_ENTRIES:
            _search_cache.pop(next(iter(_search_cache)))   # oldest insert
    _search_cache[key] = (time.time() + ttl, results)


async def _search(
    session: aiohttp.ClientSession, item: MediaItem,
    url: str, uuid: str, password: str, fresh: bool = False,
) -> list[dict]:
    key = _cache_key(item)
    if not fresh:
        hit = _search_cache.get(key)
        if hit and hit[0] > time.time():
            logger.debug("AIOStreams cache hit: %s", key)
            return hit[1]
    fut = _inflight.get(key)
    if fut is not None:
        logger.debug("AIOStreams joining in-flight query: %s", key)
        return await asyncio.shield(fut)

    fut = asyncio.get_event_loop().create_future()
    _inflight[key] = fut
    try:
        results = await _search_uncached(session, item, url, uuid, password)
        _cache_put(key, results)
        fut.set_result(results)
        return results
    except BaseException as exc:
        fut.set_exception(exc)
        fut.exception()   # mark retrieved so an unawaited future doesn't warn
        raise
    finally:
        _inflight.pop(key, None)


# ---------------------------------------------------------------------------
# aiostream operators
# ---------------------------------------------------------------------------

@operator
async def _fetch_raw(
    session: aiohttp.ClientSession,
    item: MediaItem,
    url: str,
    uuid: str,
    password: str,
    fresh: bool = False,
) -> AsyncIterator[dict]:
    """Yield raw SearchApiResult dicts that have a direct stream URL."""
    if not uuid:
        logger.warning("AIOSTREAMS_UUID not set — using stub data")
        await asyncio.sleep(0.05)
        for r in _stub_results(item):
            yield r
        return
    for r in await _search(session, item, url, uuid, password, fresh):
        yield r


async def _search_uncached(
    session: aiohttp.ClientSession,
    item: MediaItem,
    url: str,
    uuid: str,
    password: str,
) -> list[dict]:
    """One real AIOStreams query; returns results that have a direct URL."""

    endpoint = f"{url}/api/v1/search"
    params   = {"type": item.aiostreams_type, "id": item.aiostreams_id}
    headers  = _auth_headers(uuid, password)

    try:
        async with _aiostreams_gate:
            # Logged here, not before the gate — this is the moment the
            # request actually gets sent, which is what makes the log
            # timestamps a meaningful way to see the real dispatch rate
            # rather than just when each caller started waiting its turn.
            logger.info("AIOStreams query: %s %s", endpoint, params)
            async with session.get(
                endpoint, params=params, headers=headers,
                timeout=aiohttp.ClientTimeout(total=60)
            ) as resp:
                if resp.status == 401:
                    raise RuntimeError(
                        "AIOStreams: invalid credentials (401). "
                        "Check AIOSTREAMS_UUID and AIOSTREAMS_PASSWORD in docker-compose.yml."
                    )
                if resp.status == 404:
                    raise RuntimeError(
                        "AIOStreams: /api/v1/search not found (404). "
                        "Check AIOSTREAMS_URL — should be http://host:3000 (not 3001)."
                    )
                resp.raise_for_status()
                data = await resp.json()
    except aiohttp.ClientConnectorError as exc:
        raise RuntimeError(
            f"Cannot connect to AIOStreams at {url}. "
            "Check AIOSTREAMS_URL and that AIOStreams is running."
        ) from exc
    except asyncio.TimeoutError as exc:
        # Previously uncaught here, and no caller logged it server-side
        # either — a slow/complex query (many addons, a title with heavy
        # fan-out) would silently show up only as a generic error to
        # whatever called this, with no way to tell "AIOStreams timed out"
        # apart from any other failure without digging through code.
        logger.warning("AIOStreams request timed out after 60s for %s", params)
        raise RuntimeError(
            f"AIOStreams did not respond within 60s for {item.title} — "
            "it may be slow for this particular title (a lot of addon "
            "fan-out) or temporarily overloaded."
        ) from exc

    if not data.get("success"):
        err = (data.get("error") or {}).get("message", "unknown error")
        raise RuntimeError(f"AIOStreams returned error: {err}")

    results = (data.get("data") or {}).get("results", [])
    errors  = (data.get("data") or {}).get("errors", [])
    total   = len(results)
    logger.info("AIOStreams returned %d total results", total)

    if errors:
        for e in errors:
            logger.warning("AIOStreams addon error — %s: %s", e.get("title",""), e.get("description",""))

    # 0 results = episode not available — return nothing, caller handles it
    if total == 0:
        return []

    out = [r for r in results if r.get("url")]   # only results with a direct HTTP URL
    yielded = len(out)

    logger.info("Yielded %d results with direct URLs (out of %d total)", yielded, total)

    # Results present but no direct url — log for debugging, yield nothing
    if yielded == 0 and total > 0:
        for i, r in enumerate(results[:2]):
            logger.warning(
                "Result[%d] has no direct url — keys: %s | externalUrl=%r",
                i, list(r.keys()), r.get("externalUrl")
            )
    return out


@operator
async def _parse(raw: dict) -> AsyncIterator[AIOStream]:
    yield AIOStream.from_api(raw)


# ---------------------------------------------------------------------------
# Public client
# ---------------------------------------------------------------------------

class AIOStreamsClient:
    """Async client for AIOStreams /api/v1/search."""

    def __init__(self) -> None:
        self._session: aiohttp.ClientSession | None = None

    async def open(self) -> None:
        self._session = aiohttp.ClientSession()

    async def close(self) -> None:
        if self._session:
            await self._session.close()
            self._session = None

    def stream_results(self, item: MediaItem, fresh: bool = False):
        assert self._session
        aio_url, uuid, password = _cfg()
        raw = _fetch_raw(self._session, item, aio_url, uuid, password, fresh)
        return raw | pipe.flatmap(lambda d: _parse(d))

    def stream_4k(self, item: MediaItem, fresh: bool = False):
        return self.stream_results(item, fresh) | pipe.filter(lambda s: s.is_4k)

    def stream_hd(self, item: MediaItem, fresh: bool = False):
        return self.stream_results(item, fresh) | pipe.filter(lambda s: not s.is_4k)

    async def resolve_all(self, item: MediaItem) -> list[AIOStream]:
        all_s = await astream.list(self.stream_results(item))
        all_s = _filter_by_usenet_allowed(all_s)
        all_s = _filter_by_exclude_words(all_s)
        # Ranking was previously applied only in best_working_for_quality,
        # i.e. only on the play-time resolve path. Every discovery path
        # (adds, background scans, the auto-episode sweep) goes through
        # resolve_all instead, so prefer_season_packs had no effect on
        # whether a pack was ever noticed — pack detection came down to
        # AIOStreams' own sort order putting one first by luck. Ranking
        # here makes discovery and playback agree on what the best
        # candidate is, and is what lets pack-first filling reliably see
        # a pack when one exists.
        return _rank_by_preferences(all_s, item.media_type)

    async def best_for_quality(self, item: MediaItem, quality: Quality) -> AIOStream | None:
        src = self.stream_4k(item) if quality == Quality.UHD else self.stream_hd(item)
        all_s = await astream.list(src)
        all_s = _filter_by_usenet_allowed(all_s)
        all_s = _filter_by_exclude_words(all_s)
        cached = [s for s in all_s if s.cached]
        return (cached or all_s or [None])[0]

    async def find_working(
        self,
        item: MediaItem,
        quality: Quality,
        *,
        fresh: bool = True,
        max_probes: int = 12,
        prefer_file_id: Optional[str] = None,
        prefer_size: Optional[int] = None,
        demote_urls: Optional[set] = None,
        require_same_file: bool = False,
        search_rounds: int = 1,
    ) -> tuple[Optional[AIOStream], Optional[int]]:
        """
        Search AIOStreams, order candidates (see order_for_resolution) and
        live-probe them until one works. Returns (stream, probed_size).

        search_rounds > 1: when every candidate of a search fails, wait a
        little and run a NEW fresh search, up to that many searches in
        total. Debrid links are generated per request, and a burst of
        refusals (rate limits, a CDN node, a torrent still being cached)
        is often gone seconds later. Each new round probes links it hasn't
        tried yet first, then retries the ones that failed.

        Returns (None, None) when no search found anything usable — that
        can just mean nothing is cached yet. Raises AllCandidatesDeadError
        when candidates existed and every probe in every round failed.

        require_same_file restricts probing to candidates that serve the
        same bytes as prefer_file_id/prefer_size — used by the 24-hour
        refresh, which must never swap a different release in under a
        playback that's already running.
        """
        rounds = max(1, int(search_rounds or 1))
        tried_urls: set = set()
        total_probed = 0
        saw_candidates = False

        for rnd in range(rounds):
            if rnd:
                delay = _RESEARCH_DELAYS[min(rnd - 1, len(_RESEARCH_DELAYS) - 1)]
                logger.info("%s (%s): no working link — new search in %ds (search %d/%d)",
                            item.title, quality.value, delay, rnd + 1, rounds)
                await asyncio.sleep(delay)
                invalidate_search_cache(item)

            use_fresh = fresh or rnd > 0
            src = (self.stream_4k(item, fresh=use_fresh) if quality == Quality.UHD
                   else self.stream_hd(item, fresh=use_fresh))
            all_s = await astream.list(src)
            all_s = _apply_hard_filters(all_s, item, quality) if all_s else []
            if not all_s:
                continue

            ordered = order_for_resolution(all_s, item, quality, prefer_file_id, prefer_size, demote_urls)
            if require_same_file:
                ordered = [
                    s for s in ordered
                    if (prefer_file_id and s.file_identity == prefer_file_id)
                    or (prefer_size and _same_size(s.size, prefer_size))
                ]
            if not ordered:
                continue
            saw_candidates = True

            # Links not tried in an earlier round first (stable: keeps the
            # pack-first ranking inside each group).
            ordered = sorted(ordered, key=lambda c: c.url in tried_urls)
            candidates = ordered[:max(1, max_probes)]

            found = await self._probe_in_order(item, quality, candidates)
            total_probed += len(candidates)
            tried_urls.update(c.url for c in candidates)
            if found is not None:
                return found

        if not saw_candidates:
            return None, None
        logger.warning("All %d probe(s) across %d search(es) for %s (%s) failed",
                       total_probed, rounds, item.title, quality.value)
        invalidate_search_cache(item)
        raise AllCandidatesDeadError(total_probed)

    async def _probe_in_order(
        self, item: MediaItem, quality: Quality, candidates: list[AIOStream]
    ) -> Optional[tuple[AIOStream, Optional[int]]]:
        """
        Probe in ranking order; first working candidate wins. Batches of
        _PROBE_PARALLEL (default 1 — one at a time, since every probe of
        an AIOStreams playback URL makes it unrestrict a link at the debrid
        service, and a burst of those is exactly what services rate-limit).
        A batch never spans two tiers, so it stays strictly
        series pack → season pack → episode.
        """
        is_series = item.media_type == MediaType.SERIES

        def _tier(c: AIOStream) -> tuple:
            return (_cache_rank(c), c.pack_tier(item.season) if is_series else 0)

        groups: list[list[AIOStream]] = []
        for c in candidates:
            if groups and len(groups[-1]) < _PROBE_PARALLEL and _tier(groups[-1][0]) == _tier(c):
                groups[-1].append(c)
            else:
                groups.append([c])

        tried = 0
        for group in groups:
            results = await asyncio.gather(*(probe_stream(c) for c in group))
            for c, r in zip(group, results):
                tried += 1
                if r.ok:
                    if tried > 1:
                        logger.info("%s (%s): skipped %d dead candidate(s)",
                                    item.title, quality.value, tried - 1)
                    kind, num = c.pack_type
                    logger.info(
                        "%s (%s): using %s%s — %s",
                        item.title, quality.value,
                        kind if item.media_type == MediaType.SERIES else "file",
                        f" S{num:02d}" if kind == "season" and num else "",
                        (c.folder_name or c.filename or c.url or "")[:90],
                    )
                    _remember_working_pack(item, quality, c)
                    return c, r.size
                logger.warning("%s (%s): candidate %d/%d dead (%s): %s",
                               item.title, quality.value, tried, len(candidates),
                               r.reason, (c.filename or c.url or "")[:70])
                _forget_pack_if_matches(item, quality, c)
        return None

    async def best_working_for_quality(
        self, item: MediaItem, quality: Quality, max_candidates: int = 8
    ) -> AIOStream | None:
        """Probe-and-fall-through pick for a quality tier, using the same
        ordering as play-time resolution. Kept for the manual scan paths;
        raises AllCandidatesDeadError like before."""
        stream, _size = await self.find_working(item, quality, fresh=False, max_probes=max_candidates)
        return stream

    async def search_for_stream(self, item: MediaItem, quality: Quality) -> AIOStream | None:
        """
        Play-time resolution. This used to return the top search result
        WITHOUT probing it and with no fallback, so a single dead top
        result put the stub ACTIVE on a dead link — the switch "succeeded",
        Plex rescanned, and the next play failed. It now uses the same
        probe-and-fall-through as everything else, against a fresh search.
        """
        stream, _size = await self.find_working(item, quality, fresh=True)
        return stream

    async def connection_test(self) -> dict:
        """Test connectivity and return a diagnostic dict."""
        aio_url, uuid, password = _cfg()
        result = {
            "url": aio_url,
            "uuid_set": bool(uuid),
            "ok": False,
            "error": None,
            "status_code": None,
            "diagnosis": None,
        }
        if not uuid:
            result["error"] = "AIOSTREAMS_UUID not set — running in stub mode"
            result["diagnosis"] = "stub"
            return result
        try:
            async with self._session.get(
                f"{aio_url}/api/v1/search",
                params={"type": "movie", "id": "tt0068646"},   # The Godfather — widely indexed
                headers=_auth_headers(uuid, password),
                timeout=aiohttp.ClientTimeout(total=8),
            ) as resp:
                result["status_code"] = resp.status
                if resp.status == 401:
                    result["error"] = "Invalid credentials (401)"
                    result["diagnosis"] = "bad_auth"
                elif resp.status == 200:
                    data = await resp.json()
                    results = (data.get("data") or {}).get("results", [])
                    errors  = (data.get("data") or {}).get("errors", [])
                    with_url = [r for r in results if r.get("url")]
                    result["ok"] = True
                    result["total_results"] = len(results)
                    result["direct_urls"] = len(with_url)
                    result["addon_errors"] = len(errors)
                    if len(results) == 0:
                        result["diagnosis"] = "no_addons"
                        result["error"] = (
                            f"Connected but 0 results returned. "
                            f"No addons or debrid configured in AIOStreams. "
                            f"Visit {aio_url}/stremio/configure"
                        )
                        result["ok"] = False
                    elif len(with_url) == 0:
                        result["diagnosis"] = "no_debrid"
                        result["error"] = (
                            f"Connected, {len(results)} results, but none have a direct URL. "
                            "Add a debrid service (Real-Debrid etc.) in AIOStreams."
                        )
                        result["ok"] = False
                    else:
                        result["diagnosis"] = "ok"
                else:
                    result["error"] = f"HTTP {resp.status}"
        except Exception as exc:
            result["error"] = str(exc)
            result["diagnosis"] = "unreachable"
        return result
