"""
gateway/backup.py
~~~~~~~~~~~~~~~~~
Download everything needed to rebuild this install, and put it back.

A backup carries settings, the library — every title, quality and
season, plus which ones had been activated — and everything still on
order in the request system. It deliberately does not carry credentials
or stream links.

Credentials are left out because a backup is a file people move around:
into cloud storage, onto a USB stick, attached to a forum post asking
why something isn't working. A backup that quietly contains a working
debrid key is a credential leak waiting for someone to be helpful with
it. Re-entering four fields after a restore is a small price.

Links are left out because they expire anyway. A restored library comes
back with its files in place and fetches fresh links on first play, which
is the same path a new file takes.
"""
from __future__ import annotations

import logging
import time
from typing import Any

from . import config, requests as reqs, settings
from .library import Library

logger = logging.getLogger("aiogateway.backup")

BACKUP_VERSION = 2


def create(library: Library) -> dict[str, Any]:
    return {
        "version": BACKUP_VERSION,
        "created_at": time.time(),
        "settings": settings.all_settings(),
        "library": library.export(),
        "requests": reqs.export(),
        "note": (
            "Connection details and API keys are not included. Re-enter them "
            "in Connections and Streams after restoring."
        ),
    }


def restore(library: Library, payload: dict, replace: bool = False) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("That file isn't an AIOGateway backup")

    # Older releases wrote `format_version`; this one writes `version`.
    # Both are accepted so a backup taken before the rewrite still
    # restores — that file is often the only remaining record of a
    # library, and refusing it would strand people mid-upgrade.
    version = payload.get("version", payload.get("format_version"))
    if version not in (1, 2):
        raise ValueError(
            "Unrecognised backup file. Expected one written by AIOGateway."
        )

    restored_settings = 0
    if isinstance(payload.get("settings"), dict):
        # Only keys this version still recognises. An older backup carries
        # settings for features that no longer exist (stub TTLs, prewarm),
        # and those are dropped rather than reintroduced as dead config.
        known = {k: v for k, v in payload["settings"].items()
                 if k in settings.DEFAULTS}
        settings.update(known)
        restored_settings = len(known)

    rows = payload.get("library") or payload.get("stubs") or []
    if not isinstance(rows, list):
        raise ValueError("The backup's library section is malformed")

    result = library.import_entries(rows, replace=replace)

    # Restored alongside the library on purpose: a backup that brought
    # back the files but forgot what was still on order would silently
    # drop every outstanding request, and nobody would notice until the
    # episode they were waiting for never appeared.
    restored_requests = 0
    if isinstance(payload.get("requests"), dict):
        restored_requests = reqs.import_all(payload["requests"], replace=replace)

    connections = _restore_connections(payload)

    logger.info("Restored %d entries (%d skipped), %d settings, %d request(s), %d connection field(s)",
                result["added"], result["skipped"], restored_settings,
                restored_requests, len(connections))
    return {
        "added": result["added"],
        "skipped": result["skipped"],
        "settings": restored_settings,
        "requests": restored_requests,
        "connections": connections,
        "legacy": "format_version" in payload and "version" not in payload,
        "replaced": replace,
    }


def _restore_connections(payload: dict) -> list[str]:
    """Pull credentials out of a pre-rewrite backup.

    Backups written by the old version embedded the AIOStreams and Plex
    credentials in plaintext, because it read them from environment
    variables and had no way to put them back into a running container.
    Since they are already sitting in the file, restoring them is the one
    thing that makes an upgrade from an old backup actually finish —
    otherwise the library comes back but the install still can't reach
    anything and the wizard has to be redone by hand.

    Only fields that aren't configured yet are filled in. Restoring an
    old backup onto a working install should never silently repoint it at
    whatever server it used to talk to.

    Current backups contain no credentials at all, so this does nothing
    for them.
    """
    block = payload.get("connection")
    if not isinstance(block, dict):
        return []

    mapping = {
        "aiostreams_url": "aiostreams_url",
        "aiostreams_uuid": "aiostreams_uuid",
        "aiostreams_password": "aiostreams_password",
        "plex_url": "plex_url",
        "plex_token": "plex_token",
    }
    updates = {}
    for source, target in mapping.items():
        value = (block.get(source) or "").strip()
        if value and not config.secret(target):
            updates[target] = value

    if not updates:
        return []

    # set_many encrypts on the way in, so these stop being plaintext the
    # moment they land.
    config.set_many(updates)
    if config.is_configured() and not config.get("setup_complete"):
        config.set_many({"setup_complete": True})
    logger.info("Imported %d connection field(s) from a pre-rewrite backup", len(updates))
    return sorted(updates)
