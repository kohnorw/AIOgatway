"""
gateway/plex_sessions.py
~~~~~~~~~~~~~~~~~~~~~~~~
"Is Plex playing this file right now?" — answered from Plex's own
/status/sessions, which lists the file path of every active playback.

This is what lets a FUSE read tell a real playback apart from Plex's
scanner, analyzer or thumbnailer (all of which read files exactly like a
player does, but never appear as a session). With it, the placeholder
switch happens on the very read that starts playback, so pressing play
streams the real content straight away instead of first showing the
45-second placeholder clip and needing a second press.

Called from FUSE worker threads, so it is synchronous (requests) with a
short shared cache: a burst of reads costs one Plex call.
"""
from __future__ import annotations

import logging
import os
import threading
import time
from typing import Optional

import requests

log = logging.getLogger("aiogateway.plexsessions")

_CACHE_S      = 0.5     # how long one /status/sessions answer is reused
_ERROR_HOLD_S = 10.0    # after a failure, don't hammer Plex
_TIMEOUT_S    = 2.0

_lock = threading.Lock()
_cached_at = 0.0
_cached: dict[str, str] = {}      # file path → ratingKey
_error_until = 0.0


def configured() -> bool:
    url = os.environ.get("PLEX_URL", "")
    tok = os.environ.get("PLEX_TOKEN", "")
    return bool(url and tok and "your-plex" not in url and "your-plex" not in tok)


def _fetch() -> dict[str, str]:
    url = os.environ.get("PLEX_URL", "").rstrip("/")
    tok = os.environ.get("PLEX_TOKEN", "")
    r = requests.get(f"{url}/status/sessions", params={"X-Plex-Token": tok},
                     headers={"Accept": "application/json"}, timeout=_TIMEOUT_S)
    r.raise_for_status()
    out: dict[str, str] = {}
    for md in (r.json().get("MediaContainer") or {}).get("Metadata") or []:
        rk = str(md.get("ratingKey") or "")
        for media in md.get("Media") or []:
            for part in media.get("Part") or []:
                f = part.get("file")
                if f:
                    out[f] = rk
    return out


def playing_files(max_age: float = _CACHE_S) -> dict[str, str]:
    """File paths Plex is currently playing → ratingKey. Empty on any error."""
    global _cached_at, _cached, _error_until
    if not configured():
        return {}
    now = time.monotonic()
    with _lock:
        if now < _error_until:
            return {}
        if now - _cached_at <= max_age:
            return dict(_cached)
        try:
            _cached = _fetch()
            _cached_at = time.monotonic()
        except Exception as exc:
            log.warning("Could not read Plex sessions: %s", exc)
            _error_until = now + _ERROR_HOLD_S
            _cached = {}
        return dict(_cached)


def wait_for_any(paths: set[str], timeout: float) -> Optional[str]:
    """
    Poll until Plex reports a session on one of `paths` (returns its
    ratingKey) or `timeout` passes (returns None). A playback's first read
    can land a moment before Plex lists the session, hence the short wait.
    """
    if not configured():
        return None
    deadline = time.monotonic() + max(0.0, timeout)
    while True:
        files = playing_files()
        for p in paths:
            if p in files:
                return files[p] or ""
        if time.monotonic() >= deadline:
            return None
        time.sleep(0.25)
