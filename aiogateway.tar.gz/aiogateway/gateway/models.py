"""
gateway/models.py
~~~~~~~~~~~~~~~~~
Data models grounded in the real AIOStreams SearchApiResult schema.

Key fields from AIOStreams API:
  url           — direct HTTP stream URL  (this is what we proxy to Plex)
  parsedFile    — contains resolution, quality, encode, HDR tags
  size          — bytes
  filename      — release filename
  service       — debrid service id
  cached        — whether it's cached on the debrid service
  requestHeaders / responseHeaders — headers needed for the stream request
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class MediaType(str, Enum):
    MOVIE  = "movie"
    SERIES = "series"


class Quality(str, Enum):
    HD  = "hd"    # 1080p and below
    UHD = "4k"    # 2160p / UHD


class StubState(str, Enum):
    PLACEHOLDER = "placeholder"  # .mkv on disk, waiting for play
    RESOLVING   = "resolving"    # Plex webhook fired, fetching URL
    ACTIVE      = "active"       # proxy is live-streaming
    ERROR       = "error"


@dataclass
class ParsedFile:
    """Mirrors AIOStreams parsedFile object."""
    resolution: Optional[str] = None   # "2160p", "1080p", "720p", ...
    quality: Optional[str] = None      # "BluRay", "WEB-DL", ...
    encode: Optional[str] = None       # "HEVC", "AVC", "AV1"
    hdr: Optional[list[str]] = None    # ["HDR10", "DV"]


@dataclass
class AIOStream:
    """
    A single result from the AIOStreams /api/v1/search endpoint.
    Only the fields we actually use are mapped here.
    """
    url: Optional[str]                  # direct HTTP stream URL — may be None for torrents
    filename: Optional[str]
    size: Optional[int]                 # bytes
    service: Optional[str]             # debrid service id e.g. "realdebrid"
    cached: Optional[bool]
    parsed_file: Optional[ParsedFile]
    request_headers: dict = field(default_factory=dict)
    response_headers: dict = field(default_factory=dict)
    addon: Optional[str] = None

    @property
    def is_4k(self) -> bool:
        if not self.parsed_file:
            return False
        res = (self.parsed_file.resolution or "").lower()
        return res in ("2160p", "4k", "uhd")

    @property
    def quality(self) -> Quality:
        return Quality.UHD if self.is_4k else Quality.HD

    @classmethod
    def from_api_result(cls, raw: dict) -> "AIOStream":
        pf_raw = raw.get("parsedFile") or {}
        parsed = ParsedFile(
            resolution=pf_raw.get("resolution"),
            quality=pf_raw.get("quality"),
            encode=pf_raw.get("encode"),
            hdr=pf_raw.get("hdr"),
        ) if pf_raw else None
        return cls(
            url=raw.get("url"),
            filename=raw.get("filename"),
            size=raw.get("size"),
            service=raw.get("service"),
            cached=raw.get("cached"),
            parsed_file=parsed,
            request_headers=raw.get("requestHeaders") or {},
            response_headers=raw.get("responseHeaders") or {},
            addon=raw.get("addon"),
        )


@dataclass
class MediaItem:
    """A piece of media the user selected in the web UI."""
    id: str                         # our internal ID
    imdb_id: str                    # e.g. "tt1375666"  — used for AIOStreams query
    title: str
    year: Optional[int]
    media_type: MediaType

    # Series only
    season: Optional[int] = None
    episode: Optional[int] = None

    # Populated after AIOStreams query
    streams: list[AIOStream] = field(default_factory=list)

    @property
    def has_4k(self) -> bool:
        return any(s.is_4k for s in self.streams)

    @property
    def aiostreams_type(self) -> str:
        return "movie" if self.media_type == MediaType.MOVIE else "series"

    @property
    def aiostreams_id(self) -> str:
        """ID string for AIOStreams API. Series include season:episode."""
        if self.media_type == MediaType.SERIES and self.season and self.episode:
            return f"{self.imdb_id}:{self.season}:{self.episode}"
        return self.imdb_id

    @property
    def folder_name(self) -> str:
        if self.media_type == MediaType.MOVIE:
            return f"{self.title} ({self.year})" if self.year else self.title
        return self.title

    @property
    def file_stem(self) -> str:
        if self.media_type == MediaType.SERIES:
            return f"S{self.season:02d}E{self.episode:02d}"
        return self.folder_name

    def best_stream(self, quality: Quality) -> Optional[AIOStream]:
        """Return best (cached-preferred) stream for a given quality."""
        candidates = [s for s in self.streams if s.quality == quality and s.url]
        # prefer cached debrid results
        cached = [s for s in candidates if s.cached]
        return (cached or candidates or [None])[0]


@dataclass
class Stub:
    """
    A placeholder .mkv file on disk that Plex indexes.
    When Plex plays it, the proxy intercepts and streams from AIOStreams.
    """
    stub_id: str
    media_id: str
    quality: Quality
    abs_path: str                       # full path of the .mkv file
    imdb_id: str
    aiostreams_type: str
    aiostreams_id: str                  # ID for re-querying AIOStreams at play time
    state: StubState = StubState.PLACEHOLDER
    stream_url: Optional[str] = None
    stream_headers: dict = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    resolved_at: Optional[float] = None

    def __repr__(self) -> str:
        return (
            f"<Stub {self.stub_id!r} {self.quality.value} "
            f"state={self.state.value} path={self.abs_path!r}>"
        )
