"""gateway/models.py — Core data models."""
from __future__ import annotations
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class MediaType(str, Enum):
    MOVIE  = "movie"
    SERIES = "series"


class Quality(str, Enum):
    HD  = "hd"
    UHD = "4k"


class StubState(str, Enum):
    PLACEHOLDER = "placeholder"
    RESOLVING   = "resolving"
    ACTIVE      = "active"
    ERROR       = "error"


# Characters not allowed in Windows/Plex folder/file names
_ILLEGAL = re.compile(r'[<>:"/\\|?*\x00-\x1f]')

def _safe(name: str) -> str:
    """Strip characters that break Plex / filesystem paths."""
    return _ILLEGAL.sub('', name).strip('. ')


@dataclass
class ParsedFile:
    resolution:     Optional[str] = None
    quality:        Optional[str] = None
    encode:         Optional[str] = None
    hdr:            Optional[list] = None
    languages:      Optional[list] = None   # e.g. ["English", "French"]
    audio_tags:     Optional[list] = None   # e.g. ["Atmos", "TrueHD"]
    audio_channels: Optional[list] = None   # e.g. ["7.1", "5.1"]


# ---------------------------------------------------------------------------
# Season / series pack detection helpers
# ---------------------------------------------------------------------------

_SEASON_PACK_RE = re.compile(
    r'(?i)(?:'
    # "S01" or "Season 1" NOT followed by E (episode) — negative lookahead
    r's(?:eason[\s._-]?)?(\d{1,2})(?![eE\d])(?:[\s._-]?(?:complete|pack|full|bluray|web|hdtv))?'
    r'|'
    # "Complete Season 1" or "Complete S01"
    r'complete[\s._-]?s(?:eason[\s._-]?)?(\d{1,2})(?![eE\d])'
    r')',
    re.IGNORECASE,
)

_SERIES_PACK_RE = re.compile(
    r'(?i)(?:complete[\s._-]?series|full[\s._-]?series|all[\s._-]?seasons)',
    re.IGNORECASE,
)

_EPISODE_RE = re.compile(r'(?i)s(\d{1,2})e(\d{1,2})', re.IGNORECASE)


def detect_pack_type(filename: str) -> tuple[str, Optional[int]]:
    """
    Given a release filename, return (pack_type, season_number):
      ('episode', None)   — individual episode file
      ('season',  N)      — season pack for season N
      ('series',  None)   — full series pack
    """
    if not filename:
        return ('episode', None)

    if _SERIES_PACK_RE.search(filename):
        return ('series', None)

    m = _SEASON_PACK_RE.search(filename)
    if m:
        s = m.group(1) or m.group(2)
        return ('season', int(s))

    return ('episode', None)


@dataclass
class AIOStream:
    url:              Optional[str]
    filename:         Optional[str]
    size:             Optional[int]
    service:          Optional[str]
    cached:           Optional[bool]
    parsed_file:      Optional[ParsedFile]
    request_headers:  dict = field(default_factory=dict)
    response_headers: dict = field(default_factory=dict)
    addon:            Optional[str] = None
    subtitles:        list = field(default_factory=list)   # list of language strings/codes, if AIOStreams reports any

    @property
    def is_4k(self) -> bool:
        if not self.parsed_file:
            return False
        return (self.parsed_file.resolution or "").lower() in ("2160p", "4k", "uhd")

    @property
    def quality(self) -> Quality:
        return Quality.UHD if self.is_4k else Quality.HD

    @property
    def pack_type(self) -> tuple[str, Optional[int]]:
        return detect_pack_type(self.filename or "")

    @classmethod
    def from_api(cls, raw: dict) -> "AIOStream":
        pf = raw.get("parsedFile") or {}
        return cls(
            url              = raw.get("url"),
            filename         = raw.get("filename"),
            size             = raw.get("size"),
            service          = raw.get("service"),
            cached           = raw.get("cached"),
            parsed_file      = ParsedFile(
                resolution     = pf.get("resolution"),
                quality        = pf.get("quality"),
                encode         = pf.get("encode"),
                hdr            = pf.get("hdr"),
                languages      = pf.get("languages"),
                audio_tags     = pf.get("audioTags"),
                audio_channels = pf.get("audioChannels"),
            ) if pf else None,
            subtitles        = raw.get("subtitles") or [],
            request_headers  = raw.get("requestHeaders") or {},
            response_headers = raw.get("responseHeaders") or {},
            addon            = raw.get("addon"),
        )


@dataclass
class MediaItem:
    id:            str
    imdb_id:       str
    title:         str          # For series episodes: "Friends - The One Where..."
    show_title:    str = ""     # For series: "Friends" (always just the show name)
    year:          Optional[int] = None
    media_type:    MediaType = MediaType.MOVIE
    season:        Optional[int] = None
    episode:       Optional[int] = None
    episode_title: str = ""     # e.g. "The One Where Monica Gets a Roommate"
    streams:       list[AIOStream] = field(default_factory=list)

    def __post_init__(self):
        if self.media_type == MediaType.SERIES and not self.show_title:
            self.show_title = self.title

    @property
    def has_4k(self) -> bool:
        return any(s.is_4k for s in self.streams)

    @property
    def has_season_pack(self) -> bool:
        return any(s.pack_type[0] == 'season' for s in self.streams)

    @property
    def has_series_pack(self) -> bool:
        return any(s.pack_type[0] == 'series' for s in self.streams)

    @property
    def aiostreams_type(self) -> str:
        return "movie" if self.media_type == MediaType.MOVIE else "series"

    # Override for pack queries (e.g. season pack = "imdb_id:season")
    _query_id: Optional[str] = field(default=None, repr=False)

    @property
    def aiostreams_id(self) -> str:
        if self._query_id is not None:
            return self._query_id
        if self.media_type == MediaType.SERIES and self.season and self.episode:
            return f"{self.imdb_id}:{self.season}:{self.episode}"
        return self.imdb_id

    @property
    def folder_name(self) -> str:
        """Top-level folder: 'Show Title (Year)' or 'Movie Title (Year)'."""
        if self.media_type == MediaType.MOVIE:
            name = _safe(self.title)
            return f"{name} ({self.year})" if self.year else name
        # For series, always use show_title (never the episode title)
        name = _safe(self.show_title or self.title)
        return f"{name} ({self.year})" if self.year else name

    @property
    def season_folder(self) -> str:
        """e.g. 'Season 01'"""
        n = self.season or 1
        return f"Season {n:02d}"

    @property
    def file_stem(self) -> str:
        """
        Plex-compatible filename stem:
          Movies:  'Movie Title (Year)'
          Series:  'S01E01'  (Plex matches episode metadata by season/episode number)
        """
        if self.media_type == MediaType.SERIES:
            s = self.season or 1
            e = self.episode or 1
            return f"S{s:02d}E{e:02d}"
        return _safe(self.folder_name)

    def best_stream(self, quality: Quality) -> Optional[AIOStream]:
        candidates = [s for s in self.streams if s.quality == quality and s.url]
        cached = [s for s in candidates if s.cached]
        return (cached or candidates or [None])[0]


@dataclass
class Stub:
    stub_id:          str
    media_id:         str
    title:            str
    quality:          Quality
    abs_path:         str
    imdb_id:          str
    aiostreams_type:  str   # "movie" | "series"
    aiostreams_id:    str
    state:            StubState = StubState.PLACEHOLDER
    stream_url:       Optional[str] = None
    stream_headers:   dict = field(default_factory=dict)
    stream_size:      Optional[int] = None   # real file size in bytes once resolved
    created_at:       float = field(default_factory=time.time)
    resolved_at:      Optional[float] = None

    # Path-derivation fields — needed by the virtual FUSE filesystem to
    # reconstruct the correct directory/file path without relying on abs_path.
    media_type:       MediaType = MediaType.MOVIE
    show_title:       str = ""           # series only: just the show name
    year:             Optional[int] = None
    season:           Optional[int] = None
    episode:          Optional[int] = None

    # Failure tracking — avoids hammering AIOStreams/CDN probes on every
    # open() for a title with no working sources at all.
    error_count:      int = 0
    last_error_at:    Optional[float] = None
