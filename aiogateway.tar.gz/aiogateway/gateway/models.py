"""
gateway/models.py
~~~~~~~~~~~~~~~~~
Data model.

The central object is `Entry`: one title at one quality, which is exactly
one file in the mounted filesystem. There is no placeholder/real
distinction. An entry is a file from the moment it is created; playing it
the first time activates it, and it stays activated.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class MediaType(str, Enum):
    MOVIE = "movie"
    SERIES = "series"


class Quality(str, Enum):
    HD = "hd"
    UHD = "4k"


class EntryState(str, Enum):
    # A source was found. The file is in the library and playable.
    READY = "ready"
    # Someone played it. Activated permanently from here on.
    ACTIVE = "active"
    # No working source right now. Repair keeps trying.
    MISSING = "missing"


_ILLEGAL = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def safe_name(name: str) -> str:
    """Strip characters Plex and the filesystem can't carry."""
    return _ILLEGAL.sub("", name or "").strip(". ") or "Untitled"


# ── Info hash extraction ────────────────────────────────────────────────
_BTIH = re.compile(r"btih:([0-9a-fA-F]{40})", re.I)
_HEX40 = re.compile(r"(?<![0-9a-fA-F])([0-9a-fA-F]{40})(?![0-9a-fA-F])")


def extract_info_hash(raw: dict) -> Optional[str]:
    """Best-effort info hash for an AIOStreams result.

    AIOStreams doesn't promise one on every result — how much torrent
    metadata survives depends on the addon behind it — so this checks the
    structured fields first, then falls back to scraping a btih out of
    anything URL-shaped. Returns None for sources that genuinely have no
    torrent identity, which is usually usenet or a direct HTTP link.
    """
    if not isinstance(raw, dict):
        return None

    torrent = raw.get("torrent") if isinstance(raw.get("torrent"), dict) else {}
    hints = raw.get("behaviorHints") if isinstance(raw.get("behaviorHints"), dict) else {}
    for container, field_name in (
        (raw, "infoHash"), (raw, "info_hash"),
        (torrent, "infoHash"), (torrent, "hash"),
        (hints, "bingeGroup"),
    ):
        value = container.get(field_name)
        if isinstance(value, str):
            match = _HEX40.search(value)
            if match:
                return match.group(1).lower()

    sources = torrent.get("sources") or raw.get("sources") or []
    candidates = [raw.get("url"), raw.get("externalUrl"), raw.get("magnetUrl")]
    candidates += [s for s in sources if isinstance(s, str)]
    for value in candidates:
        if isinstance(value, str):
            match = _BTIH.search(value)
            if match:
                return match.group(1).lower()
    return None


# ── Pack detection ──────────────────────────────────────────────────────
_EPISODE = re.compile(r"(?i)s(\d{1,2})[\s._-]?e(\d{1,3})")
_SERIES_PACK = re.compile(
    r"(?i)complete[\s._-]?series|full[\s._-]?series|all[\s._-]?seasons"
    r"|series[\s._-]?pack|box[\s._-]?set|\bcollection\b"
)
_SEASON_RANGE = re.compile(
    r"(?i)s(?:easons?[\s._-]?)?(\d{1,2})[\s._-]?(?:-|~|to)[\s._-]?(?:s(?:easons?)?[\s._-]?)?(\d{1,2})\b"
)
_SEASON_PACK = re.compile(r"(?i)s(?:eason[\s._-]?)?(\d{1,2})(?![eE\d])")
_BARE_COMPLETE = re.compile(r"(?i)\bcomplete\b")


def detect_pack(filename: str) -> tuple[str, Optional[int]]:
    """('episode', None) | ('season', N) | ('series', None).

    An explicit SxxEyy marker wins outright and is checked first, because
    an episode's own title can innocently contain "Complete" or "Season"
    and would otherwise trip the pack patterns below it.
    """
    if not filename:
        return ("episode", None)
    if _EPISODE.search(filename):
        return ("episode", None)
    if _SERIES_PACK.search(filename) or _SEASON_RANGE.search(filename):
        return ("series", None)
    match = _SEASON_PACK.search(filename)
    if match:
        return ("season", int(match.group(1)))
    if _BARE_COMPLETE.search(filename):
        return ("series", None)
    return ("episode", None)


@dataclass
class ParsedFile:
    resolution: Optional[str] = None
    quality: Optional[str] = None
    encode: Optional[str] = None
    hdr: list = field(default_factory=list)
    languages: list = field(default_factory=list)
    audio_tags: list = field(default_factory=list)
    audio_channels: list = field(default_factory=list)


@dataclass
class Candidate:
    """One stream AIOStreams offered."""
    url: Optional[str] = None
    filename: Optional[str] = None
    size: Optional[int] = None
    service: Optional[str] = None
    addon: Optional[str] = None
    cached: Optional[bool] = None
    stream_type: Optional[str] = None
    info_hash: Optional[str] = None
    headers: dict = field(default_factory=dict)
    subtitles: list = field(default_factory=list)
    parsed: Optional[ParsedFile] = None
    # Set when a debrid provider was actually asked. None means no
    # verdict and `cached` is the addon's own claim.
    cached_verified: Optional[bool] = None

    @property
    def is_usenet(self) -> bool:
        return (self.stream_type or "").lower() == "usenet"

    @property
    def is_4k(self) -> bool:
        if not self.parsed:
            return False
        return (self.parsed.resolution or "").lower() in ("2160p", "4k", "uhd")

    @property
    def quality(self) -> Quality:
        return Quality.UHD if self.is_4k else Quality.HD

    @property
    def pack(self) -> tuple[str, Optional[int]]:
        return detect_pack(self.filename or "")

    @property
    def is_cached(self) -> bool:
        """Verified state wins; otherwise the addon's claim."""
        if self.cached_verified is not None:
            return self.cached_verified
        return bool(self.cached)

    @classmethod
    def from_api(cls, raw: dict) -> "Candidate":
        parsed_raw = raw.get("parsedFile") or {}
        return cls(
            url=raw.get("url"),
            filename=raw.get("filename"),
            size=raw.get("size"),
            service=raw.get("service"),
            addon=raw.get("addon"),
            cached=raw.get("cached"),
            stream_type=raw.get("type"),
            info_hash=extract_info_hash(raw),
            headers=raw.get("requestHeaders") or {},
            subtitles=raw.get("subtitles") or [],
            parsed=ParsedFile(
                resolution=parsed_raw.get("resolution"),
                quality=parsed_raw.get("quality"),
                encode=parsed_raw.get("encode"),
                hdr=parsed_raw.get("hdr") or [],
                languages=parsed_raw.get("languages") or [],
                audio_tags=parsed_raw.get("audioTags") or [],
                audio_channels=parsed_raw.get("audioChannels") or [],
            ) if parsed_raw else None,
        )

    def to_dict(self) -> dict:
        return {
            "url": self.url, "filename": self.filename, "size": self.size,
            "service": self.service, "addon": self.addon, "cached": self.cached,
            "stream_type": self.stream_type, "info_hash": self.info_hash,
            "headers": self.headers, "cached_verified": self.cached_verified,
            "resolution": self.parsed.resolution if self.parsed else None,
        }


@dataclass
class MediaItem:
    """A thing to search for."""
    imdb_id: str
    title: str
    media_type: MediaType = MediaType.MOVIE
    show_title: str = ""
    year: Optional[int] = None
    season: Optional[int] = None
    episode: Optional[int] = None
    episode_title: str = ""
    poster: str = ""

    def __post_init__(self):
        if self.media_type == MediaType.SERIES and not self.show_title:
            self.show_title = self.title

    @property
    def media_id(self) -> str:
        if self.media_type == MediaType.SERIES:
            return f"{self.imdb_id}:{self.season or 1}:{self.episode or 1}"
        return self.imdb_id

    @property
    def search_type(self) -> str:
        return "movie" if self.media_type == MediaType.MOVIE else "series"

    @property
    def search_id(self) -> str:
        if self.media_type == MediaType.SERIES and self.season and self.episode:
            return f"{self.imdb_id}:{self.season}:{self.episode}"
        return self.imdb_id

    @property
    def folder(self) -> str:
        name = safe_name(self.show_title or self.title
                         if self.media_type == MediaType.SERIES else self.title)
        return f"{name} ({self.year})" if self.year else name


@dataclass
class Entry:
    """One file in the library."""
    entry_id: str
    media_id: str
    imdb_id: str
    title: str
    quality: Quality
    media_type: MediaType = MediaType.MOVIE
    show_title: str = ""
    year: Optional[int] = None
    season: Optional[int] = None
    episode: Optional[int] = None
    poster: str = ""

    state: EntryState = EntryState.READY

    # Current source. `url` may be empty on an entry created by Migrate,
    # which only verified that a source exists and leaves fetching the
    # link to the first play.
    url: Optional[str] = None
    headers: dict = field(default_factory=dict)
    size: Optional[int] = None
    source_filename: Optional[str] = None
    source_service: Optional[str] = None
    info_hash: Optional[str] = None

    created_at: float = field(default_factory=time.time)
    # Set once, on first play. Never cleared — this is what "activated
    # forever" means, and repair reads it to decide what to protect first.
    activated_at: Optional[float] = None
    last_repair_at: Optional[float] = None
    last_played_at: Optional[float] = None
    repair_failures: int = 0
    added_by: str = ""
    # Set when someone chose this stream by hand in the Library tab.
    # Repair then tries to re-acquire this exact release before falling
    # back to picking a new best — otherwise the next expiry would
    # quietly undo a deliberate choice.
    pinned: bool = False

    @property
    def activated(self) -> bool:
        return self.activated_at is not None

    @property
    def top_folder(self) -> str:
        if self.media_type == MediaType.SERIES:
            return "Series4K" if self.quality == Quality.UHD else "Series"
        return "Movies4K" if self.quality == Quality.UHD else "Movies"

    @property
    def title_folder(self) -> str:
        base = self.show_title or self.title if self.media_type == MediaType.SERIES else self.title
        name = safe_name(base)
        return f"{name} ({self.year})" if self.year else name

    @property
    def virtual_path(self) -> str:
        """Where this entry appears under the mountpoint.

        The name never changes over an entry's life. An earlier design
        renamed files on state changes to make Plex re-read them, which
        worked once and then made every later state change look to Plex
        like content being removed and re-added. Activation triggers an
        explicit Plex refresh instead, which is the same outcome without
        disturbing the library.
        """
        if self.media_type == MediaType.SERIES:
            season = self.season or 1
            episode = self.episode or 1
            return (f"/{self.top_folder}/{self.title_folder}"
                    f"/Season {season:02d}/S{season:02d}E{episode:02d}.mkv")
        return f"/{self.top_folder}/{self.title_folder}/{self.title_folder}.mkv"

    @property
    def display_name(self) -> str:
        if self.media_type == MediaType.SERIES:
            return f"{self.show_title or self.title} S{self.season or 1:02d}E{self.episode or 1:02d}"
        return self.title

    def to_dict(self) -> dict:
        return {
            "entry_id": self.entry_id, "media_id": self.media_id,
            "imdb_id": self.imdb_id, "title": self.title,
            "quality": self.quality.value, "media_type": self.media_type.value,
            "show_title": self.show_title, "year": self.year,
            "season": self.season, "episode": self.episode, "poster": self.poster,
            "state": self.state.value, "url": self.url, "headers": self.headers,
            "size": self.size, "source_filename": self.source_filename,
            "source_service": self.source_service, "info_hash": self.info_hash,
            "created_at": self.created_at, "activated_at": self.activated_at,
            "last_repair_at": self.last_repair_at, "last_played_at": self.last_played_at,
            "repair_failures": self.repair_failures, "added_by": self.added_by,
            "pinned": self.pinned,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Entry":
        return cls(
            entry_id=data["entry_id"], media_id=data["media_id"],
            imdb_id=data["imdb_id"], title=data["title"],
            quality=Quality(data.get("quality", "hd")),
            media_type=MediaType(data.get("media_type", "movie")),
            show_title=data.get("show_title", ""), year=data.get("year"),
            season=data.get("season"), episode=data.get("episode"),
            poster=data.get("poster", ""),
            state=EntryState(data.get("state", "ready")),
            url=data.get("url"), headers=data.get("headers") or {},
            size=data.get("size"), source_filename=data.get("source_filename"),
            source_service=data.get("source_service"), info_hash=data.get("info_hash"),
            created_at=data.get("created_at", time.time()),
            activated_at=data.get("activated_at"),
            last_repair_at=data.get("last_repair_at"),
            last_played_at=data.get("last_played_at"),
            repair_failures=data.get("repair_failures", 0),
            added_by=data.get("added_by", ""),
            pinned=data.get("pinned", False),
        )
