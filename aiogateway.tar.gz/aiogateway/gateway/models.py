"""gateway/models.py — Core data models."""
from __future__ import annotations
import hashlib
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class MediaType(str, Enum):
    MOVIE  = "movie"
    SERIES = "series"


class Quality(str, Enum):
    HD  = "hd"
    UHD = "4k"


class StubState(str, Enum):
    PLACEHOLDER = "placeholder"
    RESOLVING   = "resolving"
    ACTIVE      = "active"
    ERROR       = "error"


@dataclass
class ParsedFile:
    resolution: Optional[str] = None
    quality:    Optional[str] = None
    encode:     Optional[str] = None
    hdr:        Optional[list] = None


@dataclass
class AIOStream:
    url:              Optional[str]
    filename:         Optional[str]
    size:             Optional[int]
    service:          Optional[str]
    cached:           Optional[bool]
    parsed_file:      Optional[ParsedFile]
    request_headers:  dict = field(default_factory=dict)
    response_headers: dict = field(default_factory=dict)
    addon:            Optional[str] = None

    @property
    def is_4k(self) -> bool:
        if not self.parsed_file:
            return False
        return (self.parsed_file.resolution or "").lower() in ("2160p", "4k", "uhd")

    @property
    def quality(self) -> Quality:
        return Quality.UHD if self.is_4k else Quality.HD

    @classmethod
    def from_api(cls, raw: dict) -> "AIOStream":
        pf = raw.get("parsedFile") or {}
        return cls(
            url              = raw.get("url"),
            filename         = raw.get("filename"),
            size             = raw.get("size"),
            service          = raw.get("service"),
            cached           = raw.get("cached"),
            parsed_file      = ParsedFile(**{k: pf.get(k) for k in ("resolution","quality","encode","hdr")}) if pf else None,
            request_headers  = raw.get("requestHeaders") or {},
            response_headers = raw.get("responseHeaders") or {},
            addon            = raw.get("addon"),
        )


@dataclass
class MediaItem:
    id:         str
    imdb_id:    str
    title:      str
    year:       Optional[int]
    media_type: MediaType
    season:     Optional[int] = None
    episode:    Optional[int] = None
    streams:    list[AIOStream] = field(default_factory=list)

    @property
    def has_4k(self) -> bool:
        return any(s.is_4k for s in self.streams)

    @property
    def aiostreams_type(self) -> str:
        return "movie" if self.media_type == MediaType.MOVIE else "series"

    @property
    def aiostreams_id(self) -> str:
        if self.media_type == MediaType.SERIES and self.season and self.episode:
            return f"{self.imdb_id}:{self.season}:{self.episode}"
        return self.imdb_id

    @property
    def folder_name(self) -> str:
        if self.media_type == MediaType.MOVIE:
            return f"{self.title} ({self.year})" if self.year else self.title
        return self.title

    @property
    def file_stem(self) -> str:
        if self.media_type == MediaType.SERIES and self.season and self.episode:
            return f"S{self.season:02d}E{self.episode:02d}"
        return self.folder_name

    def best_stream(self, quality: Quality) -> Optional[AIOStream]:
        candidates = [s for s in self.streams if s.quality == quality and s.url]
        cached = [s for s in candidates if s.cached]
        return (cached or candidates or [None])[0]


@dataclass
class Stub:
    stub_id:          str
    media_id:         str
    title:            str
    quality:          Quality
    abs_path:         str
    imdb_id:          str
    aiostreams_type:  str
    aiostreams_id:    str
    state:            StubState = StubState.PLACEHOLDER
    stream_url:       Optional[str] = None
    stream_headers:   dict = field(default_factory=dict)
    created_at:       float = field(default_factory=time.time)
    resolved_at:      Optional[float] = None
