"""gateway/models.py — Core data models."""
from __future__ import annotations
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class MediaType(str, Enum):
    MOVIE  = "movie"
    SERIES = "series"


class Quality(str, Enum):
    HD  = "hd"
    UHD = "4k"


class StubState(str, Enum):
    PLACEHOLDER = "placeholder"
    RESOLVING   = "resolving"
    ACTIVE      = "active"
    ERROR       = "error"


# Characters not allowed in Windows/Plex folder/file names
_ILLEGAL = re.compile(r'[<>:"/\\|?*\x00-\x1f]')

def _safe(name: str) -> str:
    """Strip characters that break Plex / filesystem paths."""
    return _ILLEGAL.sub('', name).strip('. ')


@dataclass
class ParsedFile:
    resolution:     Optional[str] = None
    quality:        Optional[str] = None
    encode:         Optional[str] = None
    hdr:            Optional[list] = None
    languages:      Optional[list] = None   # e.g. ["English", "French"]
    audio_tags:     Optional[list] = None   # e.g. ["Atmos", "TrueHD"]
    audio_channels: Optional[list] = None   # e.g. ["7.1", "5.1"]
    # Season/episode structure as parsed by AIOStreams itself. The folder*
    # variants describe the torrent/NZB folder the file lives in — the only
    # place a pack is visible, because the file inside a season pack is
    # named like any single episode ("Show.S02E05.mkv").
    seasons:         Optional[list] = None
    episodes:        Optional[list] = None
    folder_seasons:  Optional[list] = None
    folder_episodes: Optional[list] = None
    season_pack:     Optional[bool] = None


# ---------------------------------------------------------------------------
# Season / series pack detection helpers
# ---------------------------------------------------------------------------

# Every pattern below is anchored with (?<![a-z0-9]) so the "s" has to
# start a token. Without it, audio/format tags inside ordinary release
# names were read as season markers: "DTS5.1" → season 5, "DDP5.1.Atmos"
# was safe only by luck, "DS4K" → season 4. On a series that meant a
# single-episode release could be ranked as a "pack".
_TOKEN = r'(?<![a-z0-9])'

_SEASON_PACK_RE = re.compile(
    r'(?i)(?:'
    # "S01" or "Season 1" NOT followed by E (episode) — negative lookahead
    + _TOKEN + r's(?:eason[\s._-]?)?(\d{1,2})(?![eE\d])(?:[\s._-]?(?:complete|pack|full|bluray|web|hdtv))?'
    r'|'
    # "Complete Season 1" or "Complete S01"
    + _TOKEN + r'complete[\s._-]?s(?:eason[\s._-]?)?(\d{1,2})(?![eE\d])'
    r')',
    re.IGNORECASE,
)

# Explicit phrases: "Complete Series", "Full Series", "All Seasons",
# "Series Pack", "Box Set", "Collection".
_SERIES_PACK_RE = re.compile(
    r'(?i)(?:complete[\s._-]?series|full[\s._-]?series|all[\s._-]?seasons|'
    r'series[\s._-]?pack|box[\s._-]?set|\bcollection\b)',
    re.IGNORECASE,
)

# A season RANGE — "S01-S05", "S1-S8", "Season 1-5", "Seasons 1-5" — spans
# more than one season, so it's a series-level pack even without any of the
# explicit phrases above. Checked before _SEASON_PACK_RE so a range's first
# number (e.g. the "01" in "S01-S05") doesn't get misread as a single-season
# pack — _SEASON_PACK_RE alone would otherwise happily match just that part.
_SEASON_RANGE_RE = re.compile(
    r'(?i)' + _TOKEN + r's(?:easons?[\s._-]?)?(\d{1,2})[\s._-]?(?:-|~|to)[\s._-]?(?:s(?:easons?)?[\s._-]?)?(\d{1,2})\b',
    re.IGNORECASE,
)

_EPISODE_RE = re.compile(r'(?i)' + _TOKEN + r's(\d{1,2})[\s._-]?e(\d{1,3})', re.IGNORECASE)

# A bare "COMPLETE" with no adjacent season number at all — e.g.
# "Show.Name.COMPLETE.1080p.BluRay.x265-GROUP" — is a common tag for a
# full-series dump. Only reached as a fallback after season-range and
# single-season patterns have already been ruled out, so this doesn't
# collide with e.g. "Show.S03.Complete.1080p" (which _SEASON_PACK_RE
# already correctly classifies as season 3 before this check runs).
_BARE_COMPLETE_RE = re.compile(r'(?i)\bcomplete\b', re.IGNORECASE)


def _season_list(v) -> list[int]:
    out = []
    for x in (v or []):
        try:
            out.append(int(x))
        except (TypeError, ValueError):
            continue
    return sorted(set(out))


def classify_pack(
    filename: Optional[str],
    folder_name: Optional[str] = None,
    parsed: Optional["ParsedFile"] = None,
) -> tuple[str, Optional[int]]:
    """
    Classify one AIOStreams result as ('series', None), ('season', N) or
    ('episode', None), using every signal AIOStreams provides, most
    reliable first:

      1. parsedFile.folderSeasons / folderEpisodes — AIOStreams' own parse
         of the torrent folder name.
      2. folderName — the raw torrent/NZB folder, run through the same
         regexes as a filename.
      3. parsedFile.seasonPack + seasons — set when the release itself is
         a season pack.
      4. filename — the old (and previously only) signal.

    The old code used only (4). For a pack, `filename` is the episode file
    *inside* the pack ("Show.S02E05.1080p.mkv"), and an SxxEyy marker wins
    outright, so nearly every real season/series pack was classified as a
    single episode. Pack-first ranking, pack fast-tracking and pack fill
    were all effectively dead code as a result.
    """
    fs = _season_list(parsed.folder_seasons) if parsed else []
    if fs:
        if len(fs) > 1:
            return ('series', None)
        fe = _season_list(parsed.folder_episodes) if parsed else []
        if len(fe) == 1:
            return ('episode', None)          # a folder holding one episode
        return ('season', fs[0])

    if folder_name:
        kind, num = detect_pack_type(folder_name)
        if kind != 'episode':
            return kind, num

    if parsed and parsed.season_pack:
        ss = _season_list(parsed.seasons)
        if len(ss) > 1:
            return ('series', None)
        if len(ss) == 1:
            return ('season', ss[0])

    return detect_pack_type(filename or "")


def detect_pack_type(filename: str) -> tuple[str, Optional[int]]:
    """
    Given a release filename, return (pack_type, season_number):
      ('episode', None)   — individual episode file
      ('season',  N)      — season pack for season N
      ('series',  None)   — full series pack
    """
    if not filename:
        return ('episode', None)

    # An explicit SxxEyy marker is checked first and wins outright — it's
    # an unambiguous single-episode signal, which matters because an
    # episode's own title can innocently contain words like "Complete" or
    # "Season" (e.g. "S03E12.The.Complete.Story...") that would otherwise
    # trip the series-pack checks below.
    if _EPISODE_RE.search(filename):
        return ('episode', None)

    if _SERIES_PACK_RE.search(filename) or _SEASON_RANGE_RE.search(filename):
        return ('series', None)

    m = _SEASON_PACK_RE.search(filename)
    if m:
        s = m.group(1) or m.group(2)
        return ('season', int(s))

    if _BARE_COMPLETE_RE.search(filename):
        return ('series', None)

    return ('episode', None)


@dataclass
class AIOStream:
    url:              Optional[str]
    filename:         Optional[str]
    size:             Optional[int]
    service:          Optional[str]
    cached:           Optional[bool]
    parsed_file:      Optional[ParsedFile]
    request_headers:  dict = field(default_factory=dict)
    response_headers: dict = field(default_factory=dict)
    addon:            Optional[str] = None
    subtitles:        list = field(default_factory=list)   # list of language strings/codes, if AIOStreams reports any
    stream_type:      Optional[str] = None   # AIOStreams "type": debrid | usenet | p2p | http | live | external | youtube
    folder_name:      Optional[str] = None   # torrent/NZB folder — where packs are visible
    folder_size:      Optional[int] = None   # whole-pack size; `size` is this file only
    info_hash:        Optional[str] = None
    file_idx:         Optional[int] = None

    @property
    def is_usenet(self) -> bool:
        return (self.stream_type or "").lower() == "usenet"

    @property
    def is_4k(self) -> bool:
        if not self.parsed_file:
            return False
        return (self.parsed_file.resolution or "").lower() in ("2160p", "4k", "uhd")

    @property
    def quality(self) -> Quality:
        return Quality.UHD if self.is_4k else Quality.HD

    @property
    def pack_type(self) -> tuple[str, Optional[int]]:
        return classify_pack(self.filename, self.folder_name, self.parsed_file)

    def pack_tier(self, season: Optional[int]) -> int:
        """
        Resolution order for a series episode: 0 = series pack, 1 = season
        pack for `season`, 2 = single episode (or a pack that claims some
        other season, which means the parse is wrong and it earns no
        preference).
        """
        kind, num = self.pack_type
        if kind == 'series':
            return 0
        if kind == 'season' and (season is None or num == season):
            return 1
        return 2

    @property
    def file_identity(self) -> Optional[str]:
        """Stable identity of the underlying FILE (not the link), used to
        tell whether a replacement link still serves the same bytes."""
        if self.info_hash:
            return f"{self.info_hash.lower()}:{self.file_idx if self.file_idx is not None else ''}"
        if self.filename and self.size:
            return f"{self.filename.rsplit('/', 1)[-1].lower()}:{self.size}"
        return None

    @classmethod
    def from_api(cls, raw: dict) -> "AIOStream":
        pf = raw.get("parsedFile") or {}
        return cls(
            url              = raw.get("url"),
            filename         = raw.get("filename"),
            size             = raw.get("size"),
            service          = raw.get("service"),
            cached           = raw.get("cached"),
            parsed_file      = ParsedFile(
                resolution     = pf.get("resolution"),
                quality        = pf.get("quality"),
                encode         = pf.get("encode"),
                hdr            = pf.get("hdr"),
                languages      = pf.get("languages"),
                audio_tags     = pf.get("audioTags"),
                audio_channels = pf.get("audioChannels"),
                seasons         = pf.get("seasons"),
                episodes        = pf.get("episodes"),
                folder_seasons  = pf.get("folderSeasons"),
                folder_episodes = pf.get("folderEpisodes"),
                season_pack     = pf.get("seasonPack"),
            ) if pf else None,
            subtitles        = raw.get("subtitles") or [],
            request_headers  = raw.get("requestHeaders") or {},
            response_headers = raw.get("responseHeaders") or {},
            addon            = raw.get("addon"),
            stream_type      = raw.get("type"),
            folder_name      = raw.get("folderName"),
            folder_size      = raw.get("folderSize"),
            info_hash        = raw.get("infoHash"),
            file_idx         = raw.get("fileIdx"),
        )


@dataclass
class MediaItem:
    id:            str
    imdb_id:       str
    title:         str          # For series episodes: "Friends - The One Where..."
    show_title:    str = ""     # For series: "Friends" (always just the show name)
    year:          Optional[int] = None
    media_type:    MediaType = MediaType.MOVIE
    season:        Optional[int] = None
    episode:       Optional[int] = None
    episode_title: str = ""     # e.g. "The One Where Monica Gets a Roommate"
    streams:       list[AIOStream] = field(default_factory=list)

    def __post_init__(self):
        if self.media_type == MediaType.SERIES and not self.show_title:
            self.show_title = self.title

    @property
    def has_4k(self) -> bool:
        return any(s.is_4k for s in self.streams)

    @property
    def has_season_pack(self) -> bool:
        return any(s.pack_type[0] == 'season' for s in self.streams)

    @property
    def has_series_pack(self) -> bool:
        return any(s.pack_type[0] == 'series' for s in self.streams)

    @property
    def aiostreams_type(self) -> str:
        return "movie" if self.media_type == MediaType.MOVIE else "series"

    # Override for pack queries (e.g. season pack = "imdb_id:season")
    _query_id: Optional[str] = field(default=None, repr=False)

    @property
    def aiostreams_id(self) -> str:
        if self._query_id is not None:
            return self._query_id
        if self.media_type == MediaType.SERIES and self.season and self.episode:
            return f"{self.imdb_id}:{self.season}:{self.episode}"
        return self.imdb_id

    @property
    def folder_name(self) -> str:
        """Top-level folder: 'Show Title (Year)' or 'Movie Title (Year)'."""
        if self.media_type == MediaType.MOVIE:
            name = _safe(self.title)
            return f"{name} ({self.year})" if self.year else name
        # For series, always use show_title (never the episode title)
        name = _safe(self.show_title or self.title)
        return f"{name} ({self.year})" if self.year else name

    @property
    def season_folder(self) -> str:
        """e.g. 'Season 01'"""
        n = self.season or 1
        return f"Season {n:02d}"

    @property
    def file_stem(self) -> str:
        """
        Plex-compatible filename stem:
          Movies:  'Movie Title (Year)'
          Series:  'S01E01'  (Plex matches episode metadata by season/episode number)
        """
        if self.media_type == MediaType.SERIES:
            s = self.season or 1
            e = self.episode or 1
            return f"S{s:02d}E{e:02d}"
        return _safe(self.folder_name)

    def best_stream(self, quality: Quality) -> Optional[AIOStream]:
        candidates = [s for s in self.streams if s.quality == quality and s.url]
        cached = [s for s in candidates if s.cached]
        return (cached or candidates or [None])[0]


@dataclass
class Stub:
    stub_id:          str
    media_id:         str
    title:            str
    quality:          Quality
    abs_path:         str
    imdb_id:          str
    aiostreams_type:  str   # "movie" | "series"
    aiostreams_id:    str
    state:            StubState = StubState.PLACEHOLDER
    stream_url:       Optional[str] = None
    stream_headers:   dict = field(default_factory=dict)
    stream_size:      Optional[int] = None   # real file size in bytes once resolved
    created_at:       float = field(default_factory=time.time)
    resolved_at:      Optional[float] = None

    # When this media+quality was FIRST stubbed, ever — as opposed to
    # created_at, which is when this particular Stub object was built.
    #
    # They differ because stubs get destroyed and rebuilt: remove_stub()
    # deletes a dead stub outright, and the auto-episode sweep then
    # re-discovers that episode as "aired, requested season, no stub" and
    # re-creates it. The rebuilt object has created_at=now, so anything
    # judging newness by created_at concluded a decades-old episode was
    # brand-new content and prewarmed it — which removed it again, and
    # round it went.
    #
    # Populated from gateway/stub_history.py, which persists it outside
    # the stub's own sidecar precisely so it survives that deletion.
    # Prewarm eligibility reads this; created_at is left alone for
    # display and for the bulk-import burst detection, where "when did
    # this object appear" is genuinely the right question.
    first_seen_at:    Optional[float] = None

    # When this stub was reverted to PLACEHOLDER by TTL expiry (or by an
    # explicit expire command), as opposed to never having been resolved
    # at all. Cleared by set_active().
    #
    # This exists because expiry and prewarming were working against each
    # other: the TTL sweep reverted a stub, then the next prewarm backstop
    # pass saw a plain placeholder, judged it eligible on exactly the same
    # created_at/release-date grounds it did the first time, and resolved
    # it straight back. Nothing distinguished "never resolved" from "we
    # already resolved this and its lease ran out", so recently-added
    # content cycled expire → prewarm → expire forever and its debrid
    # links were effectively never released. Prewarm now skips these and
    # waits for an actual play.
    ttl_expired_at:   Optional[float] = None

    # True once this stub has been resolved at least once, ever. Sticky —
    # never cleared, including by TTL expiry.
    #
    # The virtual filename gains a " - Ready" suffix when a stub resolves,
    # which is what makes Plex re-analyse a file whose content has just
    # changed from a 133KB placeholder to real media. That rename is
    # genuinely needed the first time. It is NOT needed on the way back:
    # when the TTL expires a stub, nothing about the media changed, only
    # the lease on the link — but the filename flipped back anyway, so
    # Plex saw the "- Ready" file disappear and a bare one appear, and
    # dutifully reported it as newly added. Keying the suffix on
    # ever_resolved instead of current state means the name changes at
    # most once in a stub's life.
    ever_resolved:    bool = False

    # Whether the virtual filename carries the " - Ready" suffix. Only
    # stubs that were renamed by older builds keep it (so Plex doesn't see
    # them renamed a second time). New switches no longer rename: a rename
    # makes Plex drop the item being played and re-add it as a new one,
    # which is what made the first press of play never play the content.
    named_ready:      bool = False

    # resolved_at from the last time this stub was ACTIVE, kept after a
    # revert clears resolved_at. Used only for the reported mtime, so the
    # timestamp Plex sees doesn't jump backwards to created_at when a
    # stub expires — another change Plex reads as "this file was
    # modified, re-add it".
    last_resolved_at: Optional[float] = None

    # Path-derivation fields — needed by the virtual FUSE filesystem to
    # reconstruct the correct directory/file path without relying on abs_path.
    media_type:       MediaType = MediaType.MOVIE
    show_title:       str = ""           # series only: just the show name
    year:             Optional[int] = None
    season:           Optional[int] = None
    episode:          Optional[int] = None

    # Failure tracking — avoids hammering AIOStreams/CDN probes on every
    # open() for a title with no working sources at all.
    error_count:      int = 0
    last_error_at:    Optional[float] = None

    # Identity of the file the current link serves (see
    # AIOStream.file_identity). Lets a link refresh or a mid-playback
    # repair tell "same bytes, new link" — safe to swap under an open
    # playback — from "different release" — not safe.
    stream_file_id:   Optional[str] = None
    stream_filename:  Optional[str] = None

    # Transient (never persisted): True while a broken ACTIVE link is being
    # replaced. FUSE reads that land in that window wait for the repair
    # instead of being handed placeholder bytes in the middle of a real
    # file, which is what used to turn a dead link into garbled playback.
    repairing:        bool = False
