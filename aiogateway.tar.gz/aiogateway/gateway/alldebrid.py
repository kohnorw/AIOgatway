"""
gateway/alldebrid.py
~~~~~~~~~~~~~~~~~~~~
Cache verification against an AllDebrid account.

Why this exists
---------------
AIOStreams reports a per-result `cached` flag, but it's three-state:
True, False, or missing entirely when the addon didn't say. For
AllDebrid specifically, "missing" is the common case, because AllDebrid
retired the instant-availability endpoint that addons used to call —
there is no longer any read-only way to ask "is this hash already on
your servers?".

What replaced it is a write: upload the magnet. AllDebrid's
`magnet/upload` response carries a `ready` flag per magnet, which is
true when the torrent is already complete on their side and false when
it has to be downloaded first. Uploading an already-complete torrent is
free and instantaneous — it just appears in the account's list, linked
to the existing copy. So "add it and see if it says ready" is now the
cache check, and that's exactly what this module does.

Uploading one that ISN'T complete starts a download, which is why
alldebrid_delete_uncached exists: off (the default) the torrent is left
in place to finish, so a miss today becomes a hit later; on, it's
removed again immediately and nothing is warmed.

Everything is keyed by infoHash and memoised, because a single season
scan asks about the same handful of packs over and over.

API shape (v4):
  POST /v4/magnet/upload   magnets[]=<hash or magnet>   → data.magnets[]
       each: {magnet, hash, name, size, id, ready}  (or {error} per magnet)
  GET  /v4/magnet/status?id=<id>                        → data.magnets
       {status: "Ready", statusCode: 4, ...}
  GET  /v4/magnet/delete?id=<id>

Auth is sent both as a Bearer header (v4.1+) and an apikey query
parameter (classic v4), since both are accepted and which one an
instance wants isn't worth probing for.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Iterable, Optional

import aiohttp

logger = logging.getLogger("aiogateway.alldebrid")

API_BASE = "https://api.alldebrid.com/v4"
AGENT = "aiogateway"

# AllDebrid allows many magnets per upload call. Keep batches modest so a
# single failed request doesn't lose a whole search's worth of answers,
# and so the request body stays small.
_BATCH_SIZE = 20

_REQUEST_TIMEOUT = 20

# statusCode 4 == "Ready". Anything below is in progress, anything above
# is an error/expired state. Only 4 counts as cached.
_STATUS_READY = 4

# infoHash (lowercase) -> {"ready": bool, "at": float, "id": int | None}
_cache: dict[str, dict] = {}
_cache_lock = asyncio.Lock()

# One upload at a time app-wide. AllDebrid's limits are generous, but
# every call here is triggered by a search that's already rate-gated
# against AIOStreams, so there's nothing to gain from parallelism and a
# lot to lose from tripping an account-level limit mid-library-scan.
_gate = asyncio.Semaphore(1)


def _settings():
    from gateway import settings as _s
    return _s


def api_key() -> str:
    """The AllDebrid API key in effect (settings first, then env)."""
    return _settings().connection("alldebrid_api_key", "")


def is_enabled() -> bool:
    """Whether verification should run at all: switched on AND has a key."""
    s = _settings()
    return bool(s.get("alldebrid_enabled", True)) and bool(api_key())


def is_alldebrid(service: Optional[str]) -> bool:
    """
    Whether a result's `service` field names AllDebrid.

    AIOStreams reports the service id, which is "alldebrid", but addons
    have historically also used "ad" and "all-debrid", so match loosely
    rather than on one exact string.
    """
    s = (service or "").strip().lower().replace("-", "").replace("_", "")
    return s in ("alldebrid", "ad")


def _cache_ttl_seconds() -> float:
    try:
        return float(_settings().get("alldebrid_cache_ttl_minutes", 360)) * 60.0
    except (TypeError, ValueError):
        return 360 * 60.0


def _cached_answer(info_hash: str) -> Optional[bool]:
    entry = _cache.get(info_hash)
    if not entry:
        return None
    ttl = _cache_ttl_seconds()
    if ttl and time.time() - entry["at"] > ttl:
        _cache.pop(info_hash, None)
        return None
    return entry["ready"]


def _remember(info_hash: str, ready: bool, magnet_id: Optional[int] = None) -> None:
    _cache[info_hash] = {"ready": bool(ready), "at": time.time(), "id": magnet_id}


def forget(info_hash: str) -> None:
    """Drop a memoised answer — e.g. after a supposedly-ready link probed dead."""
    _cache.pop((info_hash or "").lower(), None)


def clear_cache() -> int:
    n = len(_cache)
    _cache.clear()
    return n


def _auth(params: dict) -> tuple[dict, dict]:
    key = api_key()
    return (
        {"Authorization": f"Bearer {key}", "Accept": "application/json"},
        {"agent": AGENT, "apikey": key, **params},
    )


async def _request(
    session: aiohttp.ClientSession, method: str, path: str,
    params: Optional[dict] = None, data: Optional[list] = None,
) -> Optional[dict]:
    """
    One AllDebrid call. Returns the `data` object on success, None on any
    failure — every caller treats a failure as "couldn't determine", not
    as "not cached", so a transient AllDebrid outage degrades to leaving
    cache status unchanged rather than silently emptying search results.
    """
    headers, query = _auth(params or {})
    try:
        async with session.request(
            method, f"{API_BASE}{path}",
            params=query, data=data, headers=headers,
            timeout=aiohttp.ClientTimeout(total=_REQUEST_TIMEOUT),
        ) as resp:
            if resp.status == 401 or resp.status == 403:
                logger.warning("AllDebrid rejected the API key (HTTP %d) — "
                               "check it in Config → Connections", resp.status)
                return None
            if resp.status != 200:
                logger.warning("AllDebrid %s returned HTTP %d", path, resp.status)
                return None
            payload = await resp.json(content_type=None)
    except asyncio.TimeoutError:
        logger.warning("AllDebrid %s timed out after %ds", path, _REQUEST_TIMEOUT)
        return None
    except Exception as exc:
        logger.warning("AllDebrid %s failed: %s", path, exc)
        return None

    if not isinstance(payload, dict):
        return None
    if payload.get("status") != "success":
        err = (payload.get("error") or {})
        logger.warning("AllDebrid %s error: %s (%s)",
                       path, err.get("message", "unknown"), err.get("code", ""))
        return None
    return payload.get("data") or {}


async def _delete(session: aiohttp.ClientSession, magnet_id: int) -> None:
    await _request(session, "GET", "/magnet/delete", params={"id": str(magnet_id)})


async def _upload_batch(
    session: aiohttp.ClientSession, hashes: list[str]
) -> dict[str, bool]:
    """
    Upload one batch of infoHashes and read back each one's ready flag.

    AllDebrid accepts a bare hash wherever it accepts a magnet URI, so
    the hash is sent as-is — no tracker list needed, and no risk of a
    malformed magnet being rejected for a reason unrelated to caching.
    """
    form = [("magnets[]", h) for h in hashes]
    data = await _request(session, "POST", "/magnet/upload", data=form)
    if data is None:
        return {}

    out: dict[str, bool] = {}
    delete_uncached = bool(_settings().get("alldebrid_delete_uncached", False))

    for m in (data.get("magnets") or []):
        if not isinstance(m, dict):
            continue
        # A per-magnet error (bad hash, account limit) is not an answer
        # about cache state, so leave that hash unrecorded rather than
        # recording it as uncached.
        if m.get("error"):
            err = m.get("error") or {}
            logger.debug("AllDebrid could not add %s: %s",
                         m.get("magnet", "?"), err.get("message", err))
            continue

        h = (m.get("hash") or "").lower()
        if not h:
            continue
        ready = bool(m.get("ready"))
        magnet_id = m.get("id")
        out[h] = ready
        _remember(h, ready, magnet_id if isinstance(magnet_id, int) else None)

        if not ready and delete_uncached and isinstance(magnet_id, int):
            await _delete(session, magnet_id)

    return out


async def verify(hashes: Iterable[str]) -> dict[str, bool]:
    """
    Resolve ready/not-ready for a set of infoHashes, using memoised
    answers where available and uploading the rest in batches.

    Returns a hash → ready map containing only the hashes an answer could
    actually be obtained for. A hash absent from the result means
    "unknown" (API failure, rejected magnet), which callers must treat
    differently from False.
    """
    wanted = {(h or "").lower() for h in hashes if h}
    wanted.discard("")
    if not wanted or not is_enabled():
        return {}

    result: dict[str, bool] = {}
    todo: list[str] = []
    for h in wanted:
        known = _cached_answer(h)
        if known is None:
            todo.append(h)
        else:
            result[h] = known

    if not todo:
        return result

    async with _gate:
        # Re-check the memo inside the gate: while queued behind another
        # search, the hashes this one wants may well have just been
        # answered by that one.
        still: list[str] = []
        for h in todo:
            known = _cached_answer(h)
            if known is None:
                still.append(h)
            else:
                result[h] = known
        if not still:
            return result

        logger.info("AllDebrid: verifying %d hash(es)", len(still))
        async with aiohttp.ClientSession() as session:
            for i in range(0, len(still), _BATCH_SIZE):
                batch = still[i:i + _BATCH_SIZE]
                result.update(await _upload_batch(session, batch))

    ready_n = sum(1 for v in result.values() if v)
    logger.info("AllDebrid: %d/%d verified cached", ready_n, len(result))
    return result


async def status(magnet_id: int) -> Optional[dict]:
    """Raw magnet/status for one uploaded magnet. Used by the UI test."""
    if not is_enabled():
        return None
    async with aiohttp.ClientSession() as session:
        data = await _request(session, "GET", "/magnet/status",
                              params={"id": str(magnet_id)})
    if not data:
        return None
    m = data.get("magnets")
    if isinstance(m, list):
        m = m[0] if m else None
    return m if isinstance(m, dict) else None


def is_ready_status(magnet: dict) -> bool:
    """Whether a magnet/status record represents a completed torrent."""
    if not isinstance(magnet, dict):
        return False
    code = magnet.get("statusCode")
    if isinstance(code, int):
        return code == _STATUS_READY
    return str(magnet.get("status", "")).strip().lower() == "ready"


async def connection_test() -> dict:
    """
    Diagnostic for Config → Connections. Checks the key against
    /user, which is the cheapest endpoint that proves both that the key
    is valid and that the account is premium (a free account can't serve
    debrid links at all, so that's worth surfacing explicitly rather
    than leaving it to fail later as mysterious dead candidates).
    """
    result = {
        "ok": False, "configured": bool(api_key()), "enabled": is_enabled(),
        "error": None, "username": None, "premium": None, "expires": None,
    }
    if not api_key():
        result["error"] = "No AllDebrid API key set"
        return result

    async with aiohttp.ClientSession() as session:
        data = await _request(session, "GET", "/user")

    if data is None:
        result["error"] = ("Could not reach AllDebrid, or the API key was "
                           "rejected. See the container logs for the exact error.")
        return result

    user = data.get("user") or {}
    result["username"] = user.get("username")
    result["premium"] = bool(user.get("isPremium"))
    exp = user.get("premiumUntil")
    if isinstance(exp, (int, float)) and exp:
        result["expires"] = time.strftime("%Y-%m-%d", time.gmtime(exp))
    if not result["premium"]:
        result["error"] = ("Key works, but this account isn't premium — "
                           "AllDebrid won't serve stream links from it.")
        return result
    result["ok"] = True
    return result
