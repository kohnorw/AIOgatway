"""
gateway/alldebrid.py
~~~~~~~~~~~~~~~~~~~~
Cache verification against an AllDebrid account.

Why this exists
---------------
AIOStreams reports a per-result `cached` flag, but it's three-state:
True, False, or missing entirely when the addon didn't say. For
AllDebrid specifically, "missing" is the common case, because AllDebrid
retired the instant-availability endpoint that addons used to call —
there is no longer any read-only way to ask "is this hash already on
your servers?".

What replaced it is a write: upload the magnet. AllDebrid's
`magnet/upload` response carries a `ready` flag per magnet, which is
true when the torrent is already complete on their side and false when
it has to be downloaded first. Uploading an already-complete torrent is
free and instantaneous — it just appears in the account's list, linked
to the existing copy. So "add it and see if it says ready" is now the
cache check, and that's exactly what this module does.

Uploading one that ISN'T complete starts a download, which is why
alldebrid_delete_uncached exists: off (the default) the torrent is left
in place to finish, so a miss today becomes a hit later; on, it's
removed again immediately and nothing is warmed.

Everything is keyed by infoHash and memoised, because a single season
scan asks about the same handful of packs over and over.

API shape (v4):
  POST /v4/magnet/upload   magnets[]=<hash or magnet>   → data.magnets[]
       each: {magnet, hash, name, size, id, ready}  (or {error} per magnet)
  GET  /v4/magnet/status?id=<id>                        → data.magnets
       {status: "Ready", statusCode: 4, ...}
  GET  /v4/magnet/delete?id=<id>

Auth is sent both as a Bearer header (v4.1+) and an apikey query
parameter (classic v4), since both are accepted and which one an
instance wants isn't worth probing for.
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
import urllib.parse
from typing import Iterable, Optional

import aiohttp

logger = logging.getLogger("aiogateway.alldebrid")

API_BASE = "https://api.alldebrid.com/v4"

# magnet/status lives on v4.1, NOT v4, and the difference is not cosmetic:
# the v4.1 account-wide listing returns a `hash` for each magnet, which is
# what makes it possible to tell which entries are ours. The v4 response
# has no hash field at all, so matching on one there silently matches
# nothing — which is exactly why cleanup appeared to run and delete
# nothing.
STATUS_URL = "https://api.alldebrid.com/v4.1/magnet/status"

# AllDebrid marks `agent` as required on EVERY v4 endpoint —
# AUTH_MISSING_AGENT is a real error code, and calls fail without it even
# with a perfectly valid key.
AGENT = os.environ.get("ALLDEBRID_AGENT", "aiogateway")

# AllDebrid allows many magnets per upload call. Keep batches modest so a
# single failed request doesn't lose a whole search's worth of answers,
# and so the request body stays small.
_BATCH_SIZE = 20

_REQUEST_TIMEOUT = 20

# statusCode 4 == "Ready". Anything below is in progress, anything above
# is an error/expired state. Only 4 counts as cached.
_STATUS_READY = 4

# infoHash (lowercase) -> {"ready": bool, "at": float, "id": int | None}
_cache: dict[str, dict] = {}
_cache_lock = asyncio.Lock()

# One upload at a time app-wide. AllDebrid's limits are generous, but
# every call here is triggered by a search that's already rate-gated
# against AIOStreams, so there's nothing to gain from parallelism and a
# lot to lose from tripping an account-level limit mid-library-scan.
_gate = asyncio.Semaphore(1)


def _settings():
    from gateway import settings as _s
    return _s


def api_key() -> str:
    """The AllDebrid API key in effect (settings first, then env)."""
    return _settings().connection("alldebrid_api_key", "")


def is_enabled() -> bool:
    """Whether verification should run at all: switched on AND has a key."""
    s = _settings()
    return bool(s.get("alldebrid_enabled", True)) and bool(api_key())


def is_alldebrid(service: Optional[str]) -> bool:
    """
    Whether a result's `service` field names AllDebrid.

    AIOStreams reports the service id, which is "alldebrid", but addons
    have historically also used "ad" and "all-debrid", so match loosely
    rather than on one exact string.
    """
    s = (service or "").strip().lower().replace("-", "").replace("_", "")
    return s in ("alldebrid", "ad")


def _cache_ttl_seconds() -> float:
    try:
        return float(_settings().get("alldebrid_cache_ttl_minutes", 360)) * 60.0
    except (TypeError, ValueError):
        return 360 * 60.0


def _cached_answer(info_hash: str) -> Optional[bool]:
    entry = _cache.get(info_hash)
    if not entry:
        return None
    ttl = _cache_ttl_seconds()
    if ttl and time.time() - entry["at"] > ttl:
        _cache.pop(info_hash, None)
        return None
    return entry["ready"]


def _remember(info_hash: str, ready: bool, magnet_id: Optional[int] = None) -> None:
    _cache[info_hash] = {"ready": bool(ready), "at": time.time(), "id": magnet_id}


def forget(info_hash: str) -> None:
    """Drop a memoised answer — e.g. after a supposedly-ready link probed dead."""
    _cache.pop((info_hash or "").lower(), None)


def clear_cache() -> int:
    n = len(_cache)
    _cache.clear()
    return n


def _headers() -> dict:
    return {"Authorization": f"Bearer {api_key()}", "Accept": "application/json"}


def _unwrap(payload, label: str):
    """Validate AllDebrid's envelope and return its `data` object.

    None means "no answer" — a transport failure, a rejected key, or an
    API-level error. Every caller treats that as unknown rather than as a
    negative result, so an AllDebrid outage can never masquerade as
    "nothing is cached" or "nothing needs deleting".
    """
    if not isinstance(payload, dict):
        return None
    if payload.get("status") == "error" or payload.get("data") is None:
        err = payload.get("error") or {}
        logger.warning("AllDebrid %s error %s: %s", label,
                       err.get("code", "UNKNOWN"), err.get("message", "unknown"))
        return None
    data = payload.get("data")
    return data if isinstance(data, dict) else {}


async def _call(
    session: aiohttp.ClientSession, method: str, url: str,
    params: Optional[dict] = None, pairs: Optional[list] = None,
) -> Optional[dict]:
    """
    One AllDebrid call.

    `agent` is attached to every request — in the query string for GET,
    in the form body for POST — because AllDebrid requires it on all v4
    endpoints regardless of method. Auth is the Bearer header.

    POST bodies are form-urlencoded, and repeated keys (magnets[], id[])
    are sent as a list of pairs rather than a dict so multiple values
    survive encoding.
    """
    label = url.rsplit("/", 2)[-2] + "/" + url.rsplit("/", 1)[-1]
    try:
        if method == "GET":
            query = {"agent": AGENT, **(params or {})}
            ctx = session.get(url, params=query, headers=_headers(),
                              timeout=aiohttp.ClientTimeout(total=_REQUEST_TIMEOUT))
        else:
            body = [("agent", AGENT)] + list(pairs or [])
            ctx = session.post(
                url,
                data=urllib.parse.urlencode(body),
                headers={**_headers(),
                         "Content-Type": "application/x-www-form-urlencoded"},
                timeout=aiohttp.ClientTimeout(total=_REQUEST_TIMEOUT),
            )
        async with ctx as resp:
            payload = await resp.json(content_type=None)
            if resp.status >= 400:
                logger.warning("AllDebrid %s -> HTTP %d: %s", label, resp.status,
                               str(payload)[:200])
                return _unwrap(payload, label)
    except asyncio.TimeoutError:
        logger.warning("AllDebrid %s timed out after %ds", label, _REQUEST_TIMEOUT)
        return None
    except Exception as exc:
        logger.warning("AllDebrid %s failed: %s", label, exc)
        return None

    return _unwrap(payload, label)


async def _request(
    session: aiohttp.ClientSession, method: str, path: str,
    params: Optional[dict] = None, data: Optional[list] = None,
) -> Optional[dict]:
    """Compatibility shim over _call, resolving a path to its real URL.

    magnet/status is the one endpoint that is NOT under the v4 base — it
    moved to v4.1, and only the v4.1 response carries the per-magnet
    hash this code needs.
    """
    url = STATUS_URL if path == "/magnet/status" else f"{API_BASE}{path}"
    return await _call(session, method, url, params=params, pairs=data)


async def _delete(session: aiohttp.ClientSession, magnet_id: int) -> None:
    """
    Remove one magnet from the account.

    POST, not GET. AllDebrid's current API takes the id in the request
    BODY for the magnet endpoints — sending it as a query string on a
    GET is accepted at the HTTP level but arrives with no id attached,
    so the call reports success and deletes nothing. That silent no-op
    is exactly how this looked from the outside: cleanup logging
    deletions that never happened.
    """
    await _request(session, "POST", "/magnet/delete",
                   data=[("id", str(magnet_id))])


async def _upload_batch(
    session: aiohttp.ClientSession, hashes: list[str]
) -> dict[str, bool]:
    """
    Upload one batch of infoHashes and read back each one's ready flag.

    AllDebrid accepts a bare hash wherever it accepts a magnet URI, so
    the hash is sent as-is — no tracker list needed, and no risk of a
    malformed magnet being rejected for a reason unrelated to caching.

    Every hash that lands is recorded in _seen, which is what later
    makes it eligible for cleanup. Uploading is the only way to check,
    so the account inevitably accumulates entries here; cleanup() is
    what takes them back off again.
    """
    # A bare hash is accepted, but a full magnet URI is what AllDebrid's
    # own clients send and is less likely to be rejected by a stricter
    # parser, so build one.
    form = [("magnets[]", f"magnet:?xt=urn:btih:{h}") for h in hashes]
    data = await _request(session, "POST", "/magnet/upload", data=form)
    if data is None:
        return {}

    out: dict[str, bool] = {}

    for m in (data.get("magnets") or []):
        if not isinstance(m, dict):
            continue
        # A per-magnet error (bad hash, account limit) is not an answer
        # about cache state, so leave that hash unrecorded rather than
        # recording it as uncached.
        if m.get("error"):
            err = m.get("error") or {}
            logger.debug("AllDebrid could not add %s: %s",
                         m.get("magnet", "?"), err.get("message", err))
            continue

        h = (m.get("hash") or "").lower()
        if not h:
            continue
        ready = bool(m.get("ready"))
        magnet_id = m.get("id")
        out[h] = ready
        _remember(h, ready, magnet_id if isinstance(magnet_id, int) else None)
        _note_seen(h, magnet_id if isinstance(magnet_id, int) else None)

    return out


# ---------------------------------------------------------------------------
# Account hygiene: keep the pick, delete the rest
# ---------------------------------------------------------------------------
# Checking cache status requires uploading, so every search leaves
# entries behind on the account — most of them releases that were never
# going to be used. Two structures keep that from piling up:
#
#   _seen    every AllDebrid hash a search has surfaced here. This is the
#            ONLY set cleanup will ever delete from, which is what stops
#            it touching torrents added by hand, or anything predating
#            this feature. In-memory: forgetting one just means it stops
#            being a cleanup candidate, which is the safe direction.
#
#   _pinned  hashes that became a stub's actual stream. Persisted, since
#            a stub outlives a restart by a long way and an unpinned pick
#            would be deleted while still playable.

# hash -> first seen at. Persisted, because it's the ONLY set cleanup
# will delete from: if a restart lost it, everything uploaded before that
# restart would be permanently unrecognisable as ours and could never be
# swept. Losing it fails safe (nothing gets deleted) but leaves clutter
# forever, which is exactly the case worth avoiding on a big migration.
_seen: dict[str, dict] = {}       # hash -> {"at": float, "id": int | None}
_seen_loaded = False
_seen_dirty = False

# Drop hashes nothing has referenced in this long. A release that hasn't
# appeared in a search for weeks has already been swept or was never
# uploaded, so keeping it only grows the file.
_SEEN_TTL_S = 30 * 86400

# hash -> pinned at (persisted)
_pinned: dict[str, float] = {}
_pins_loaded = False


def _seen_path():
    from pathlib import Path
    import os
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_alldebrid_seen.json"


def _load_seen() -> None:
    global _seen_loaded
    if _seen_loaded:
        return
    _seen_loaded = True
    path = _seen_path()
    try:
        if path.exists():
            import json
            data = json.loads(path.read_text())
            if isinstance(data, dict):
                now = time.time()
                for k, v in data.items():
                    # Older files stored a bare timestamp; newer ones a
                    # {"at", "id"} record. Read both so an upgrade
                    # doesn't silently drop the cleanup backlog.
                    if isinstance(v, dict):
                        at, magnet_id = float(v.get("at", 0)), v.get("id")
                    else:
                        at, magnet_id = float(v), None
                    if now - at < _SEEN_TTL_S:
                        _seen[str(k).lower()] = {"at": at, "id": magnet_id}
            logger.info("Loaded %d AllDebrid cleanup candidate(s) from %s",
                        len(_seen), path)
    except Exception as exc:
        logger.warning("Could not load AllDebrid seen-list from %s: %s", path, exc)


def _save_seen() -> None:
    global _seen_dirty
    if not _seen_dirty:
        return
    path = _seen_path()
    try:
        import json
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(_seen, indent=2))
        _seen_dirty = False
    except Exception as exc:
        logger.warning("Could not persist AllDebrid seen-list to %s: %s", path, exc)


def _note_seen(info_hash: str, magnet_id: Optional[int] = None) -> None:
    """
    Record a hash as ours, along with the account's magnet id for it
    when we know one.

    The id is the important half. /magnet/status reports no hash for its
    entries, so an id recorded at upload time is the only link between a
    hash and the thing to delete — without it, cleanup has to re-upload
    just to rediscover the id.
    """
    global _seen_dirty
    _load_seen()
    entry = _seen.get(info_hash)
    if entry is None:
        _seen[info_hash] = {"at": time.time(), "id": magnet_id}
        _seen_dirty = True
    elif magnet_id is not None and entry.get("id") != magnet_id:
        entry["id"] = magnet_id
        _seen_dirty = True


def _forget_seen(info_hash: str) -> None:
    """Stop tracking a hash — it's been deleted, so there's nothing left
    to clean up and keeping it would mean re-uploading it on the next
    sweep just to delete it again."""
    global _seen_dirty
    if _seen.pop(info_hash, None) is not None:
        _seen_dirty = True


def _pins_path():
    from pathlib import Path
    import os
    root = os.environ.get("FUSE_MOUNTPOINT", "/docker/aiogateway/mnt")
    base = Path(root).parent if Path(root).parent != Path("/") else Path("/docker/aiogateway")
    return base / "aiogateway_alldebrid_pins.json"


def _load_pins() -> None:
    global _pins_loaded
    if _pins_loaded:
        return
    _pins_loaded = True
    path = _pins_path()
    try:
        if path.exists():
            import json
            data = json.loads(path.read_text())
            if isinstance(data, dict):
                _pinned.update({str(k).lower(): float(v) for k, v in data.items()})
            logger.info("Loaded %d AllDebrid pin(s) from %s", len(_pinned), path)
    except Exception as exc:
        logger.warning("Could not load AllDebrid pins from %s: %s", path, exc)


def _save_pins() -> None:
    path = _pins_path()
    try:
        import json
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(_pinned, indent=2))
    except Exception as exc:
        logger.warning("Could not persist AllDebrid pins to %s: %s", path, exc)


def _pin_ttl_seconds() -> float:
    try:
        return float(_settings().get("alldebrid_pin_days", 45)) * 86400.0
    except (TypeError, ValueError):
        return 45 * 86400.0


def _prune_pins() -> None:
    ttl = _pin_ttl_seconds()
    if ttl <= 0:
        return
    now = time.time()
    stale = [h for h, at in _pinned.items() if now - at > ttl]
    for h in stale:
        _pinned.pop(h, None)
    if stale:
        logger.info("Expired %d stale AllDebrid pin(s)", len(stale))
        _save_pins()


def pin(info_hash: Optional[str]) -> None:
    """
    Protect a release from cleanup: this is the one aiogateway picked.

    Called wherever a candidate is actually committed to — an automatic
    resolve, a play-time search, a manual pick in the UI. Re-pinning an
    already-pinned hash refreshes its timestamp, so a release that keeps
    being chosen keeps being kept.
    """
    h = (info_hash or "").lower()
    if not h:
        return
    _load_pins()
    first = h not in _pinned
    _pinned[h] = time.time()
    _save_pins()
    if first:
        logger.info("AllDebrid: pinned %s — kept on the account as a picked stream", h[:12])


def unpin(info_hash: Optional[str]) -> None:
    """Release a pin, making the hash eligible for cleanup again."""
    h = (info_hash or "").lower()
    if not h:
        return
    _load_pins()
    if _pinned.pop(h, None) is not None:
        _save_pins()


def is_pinned(info_hash: Optional[str]) -> bool:
    _load_pins()
    _prune_pins()
    return (info_hash or "").lower() in _pinned


# ---------------------------------------------------------------------------
# Minting our own links
# ---------------------------------------------------------------------------
# With alldebrid_own_links on, the picked release gets deleted along with
# everything else and then re-added on its own — which means AIOStreams'
# URL is dead and aiogateway has to produce a replacement: re-upload,
# read the torrent's file list, choose the right file, unlock it.
#
# Choosing the right file is the load-bearing step. For a single-file
# movie torrent it's trivial. For a season pack it decides which episode
# plays, so a wrong answer is a silently wrong video rather than an
# error.

_VIDEO_EXTS = (".mkv", ".mp4", ".avi", ".m4v", ".ts", ".mov", ".wmv", ".mpg", ".mpeg")

# How long to wait for a re-added torrent to expose its file list. A
# release that was ready a moment ago is ready again instantly, so this
# is a guard against a slow response, not a download wait.
_LINKS_POLL_ATTEMPTS = 6
_LINKS_POLL_DELAY = 1.0


def _basename(name: str) -> str:
    return (name or "").rsplit("/", 1)[-1].rsplit("\\", 1)[-1].strip().lower()


def _is_video(name: str) -> bool:
    return _basename(name).endswith(_VIDEO_EXTS)


def choose_file(links: list, filename: Optional[str], file_idx: Optional[int]) -> Optional[dict]:
    """
    Pick the right file out of a torrent's link list, most trustworthy
    signal first.

    1. fileIdx, when AIOStreams reported one and it's in range. This is
       the torrent's own file index and is the only unambiguous answer.
    2. An exact basename match against the candidate's filename. Reliable
       when present; AIOStreams reports the specific file it matched, not
       the torrent name, for pack results.
    3. The largest video file. Correct for single-file movie torrents and
       a coin toss inside a pack — which is why it's last, and why it's
       logged loudly when reached.

    Returns the chosen link dict, or None if the list holds no usable
    file at all.
    """
    usable = [l for l in links if isinstance(l, dict) and l.get("link")]
    if not usable:
        return None

    if isinstance(file_idx, int) and 0 <= file_idx < len(usable):
        return usable[file_idx]

    if filename:
        want = _basename(filename)
        for l in usable:
            if _basename(l.get("filename", "")) == want:
                return l

    videos = [l for l in usable if _is_video(l.get("filename", ""))] or usable
    best = max(videos, key=lambda l: l.get("size") or 0)
    if len(videos) > 1:
        logger.warning(
            "AllDebrid: no fileIdx and no filename match among %d files — "
            "falling back to the largest (%s). If this is a season pack the "
            "wrong episode may play.",
            len(videos), _basename(best.get("filename", "?")),
        )
    return best


def _flatten_files(nodes, prefix: str = "") -> list[dict]:
    """
    Flatten AllDebrid's nested file tree into a flat list of
    {"link", "filename", "size"}.

    The tree uses single-letter keys: n = name, s = size, l = link,
    e = entries (a subfolder's children). A node with `e` is a
    directory and carries no link of its own; only leaves have `l`.

    Flattened in depth-first order, which matters because that's the
    order the torrent's own file index counts in — it's what makes
    fileIdx meaningful against this list. Paths are preserved in the
    filename so a pack's episode names survive nesting.
    """
    out: list[dict] = []
    if not isinstance(nodes, list):
        return out
    for node in nodes:
        if not isinstance(node, dict):
            continue
        name = node.get("n") or ""
        path = f"{prefix}/{name}" if prefix else name
        children = node.get("e")
        if isinstance(children, list) and children:
            out.extend(_flatten_files(children, path))
            continue
        link = node.get("l")
        if link:
            out.append({"link": link, "filename": path, "size": node.get("s")})
    return out


async def _await_links(session: aiohttp.ClientSession, magnet_id: int) -> list:
    """
    Fetch the torrent's file list, waiting briefly if it isn't ready.

    Files come from /magnet/files, NOT /magnet/status. AllDebrid split
    these apart: status now reports only lifecycle state
    (id/filename/size/status/statusCode/counters) and carries no link
    array at all, so the previous version of this looked for a `links`
    key that is never present and concluded every torrent had no files.

    /magnet/files takes ids as repeated id[] body fields and returns
    data.magnets[].files as a nested tree — see _flatten_files.
    """
    for attempt in range(_LINKS_POLL_ATTEMPTS):
        data = await _request(session, "GET", "/magnet/files",
                              params={"id[]": str(magnet_id)})
        magnets = (data or {}).get("magnets")
        if isinstance(magnets, dict):
            magnets = [magnets]
        entry = magnets[0] if isinstance(magnets, list) and magnets else None

        if isinstance(entry, dict) and not entry.get("error"):
            links = _flatten_files(entry.get("files"))
            if links:
                return links

        # No files yet. Check lifecycle state before waiting again —
        # a torrent that isn't going to become ready never will, and
        # polling it to the end of the attempts just delays the failure.
        status_data = await _request(session, "GET", "/magnet/status",
                                     params={"id[]": str(magnet_id)})
        m = (status_data or {}).get("magnets")
        if isinstance(m, list):
            m = m[0] if m else None
        if isinstance(m, dict) and not is_ready_status(m):
            logger.warning("AllDebrid magnet %s is not ready (%s) — cannot "
                           "unlock a link from it", magnet_id, m.get("status"))
            return []

        if attempt < _LINKS_POLL_ATTEMPTS - 1:
            await asyncio.sleep(_LINKS_POLL_DELAY)
    return []


async def resolve_link(
    info_hash: str, filename: Optional[str] = None, file_idx: Optional[int] = None
) -> Optional[dict]:
    """
    Re-add a release to the account and unlock a fresh direct link to the
    right file inside it.

    Returns {"url", "filename", "size"} or None. None is a real failure
    the caller has to handle — with own-links on there's no AIOStreams URL
    to fall back to, because deleting the release is what invalidated it.
    """
    h = (info_hash or "").lower()
    if not h or not is_enabled():
        return None

    async with _gate:
        async with aiohttp.ClientSession() as session:
            up = await _request(session, "POST", "/magnet/upload",
                                data=[("magnets[]", f"magnet:?xt=urn:btih:{h}")])
            magnets = (up or {}).get("magnets") or []
            entry = magnets[0] if magnets and isinstance(magnets[0], dict) else None
            if not entry or entry.get("error"):
                logger.warning("AllDebrid: could not re-add %s to unlock a link", h[:12])
                return None

            magnet_id = entry.get("id")
            if not isinstance(magnet_id, int):
                return None
            _note_seen(h, magnet_id)
            _remember(h, bool(entry.get("ready", True)), magnet_id)

            links = await _await_links(session, magnet_id)
            if not links:
                logger.warning("AllDebrid: %s exposed no files to unlock", h[:12])
                return None

            chosen = choose_file(links, filename, file_idx)
            if not chosen:
                return None

            # GET — unlock takes the link as a query parameter. (Only
            # upload and delete are POST; the read endpoints are all GET.)
            unlocked = await _request(session, "GET", "/link/unlock",
                                      params={"link": chosen.get("link")})
            direct = (unlocked or {}).get("link")
            if not direct:
                logger.warning("AllDebrid: unlock failed for %s", h[:12])
                return None

            logger.info("AllDebrid: minted a direct link for %s (%s)",
                        h[:12], _basename(chosen.get("filename", "?")))
            return {
                "url": direct,
                "filename": chosen.get("filename"),
                "size": (unlocked or {}).get("filesize") or chosen.get("size"),
            }


async def keep_only(
    info_hash: Optional[str],
    filename: Optional[str] = None,
    file_idx: Optional[int] = None,
) -> dict:
    """
    Settle the account down to just the release that was picked, by
    whichever of the two routes is configured.

    PIN MODE (alldebrid_own_links off, the default)
      Pin the pick, then delete everything else. The pick is never
      removed, so AIOStreams' stream URL — generated from that very copy
      — stays valid and nothing needs regenerating. Ordering matters:
      pinning has to happen before the sweep, or the winner goes with
      the rest.

    OWN-LINKS MODE (alldebrid_own_links on)
      Delete everything INCLUDING the pick, then re-add only the pick
      and unlock a fresh link to the right file inside it. This is the
      strict "account holds nothing but the selected stream" behaviour,
      and it's why link minting is mandatory here: the delete is what
      invalidates AIOStreams' URL, so a replacement has to be produced
      or the stub has no working stream.

    Returns the sweep counters, plus "link" in own-links mode: the
    freshly minted stream dict, or None if minting failed. A None there
    is not cosmetic — the caller must treat it as a failed resolve.
    """
    empty = {"deleted": 0, "kept": 0, "skipped": 0, "error": None}
    if not is_enabled():
        return empty

    own_links = bool(_settings().get("alldebrid_own_links", False))
    h = (info_hash or "").lower()

    if not own_links:
        pin(info_hash)
        return await cleanup(force=True)

    # Own-links mode. Unpin first so the sweep takes the pick too — a
    # leftover pin from a previous run (or from before this mode was
    # switched on) would otherwise silently exempt it and leave the
    # account holding two copies of the same release.
    if h:
        unpin(h)
    result = await cleanup(force=True)

    if not h:
        result["link"] = None
        return result

    link = await resolve_link(h, filename, file_idx)
    if link:
        # Pin the re-added copy so the NEXT search's sweep leaves it
        # alone. Without this the account would be emptied again on the
        # following resolve, taking this stub's live stream with it.
        pin(h)
    else:
        logger.error(
            "AllDebrid: deleted the account's copies but could not mint a "
            "replacement link for %s — this resolve will fail. Turn off "
            "'Manage AllDebrid links directly' if this keeps happening.", h[:12]
        )
    result["link"] = link
    return result


def note_candidates(hashes: Iterable[str]) -> None:
    """
    Mark hashes as "surfaced by an aiogateway search", making them
    eligible for cleanup later.

    Upload already does this for anything it checked, but candidates can
    reach a stub without ever being probed — the per-search check cap,
    or a result AIOStreams already reported as definitely cached. Those
    still end up on the account (AIOStreams adds them itself to build a
    stream URL), so they have to be cleanup-eligible too, or they'd
    accumulate untouched.
    """
    for h in hashes:
        h = (h or "").lower()
        if h:
            _note_seen(h)


def _grace_seconds() -> float:
    try:
        return float(_settings().get("alldebrid_grace_minutes", 10)) * 60.0
    except (TypeError, ValueError):
        return 600.0


async def cleanup(session: Optional[aiohttp.ClientSession] = None,
                  force: bool = False) -> dict:
    """
    Delete every AllDebrid entry this app put there that isn't the
    release it actually picked.

    Works from magnet IDS, not hashes, and that detail is load-bearing:
    /magnet/status does NOT return a hash for each entry (its
    MagnetStatusItem is id/filename/size/status/statusCode/counters and
    nothing else). An earlier version of this matched the listing on a
    `hash` field that is never present, so every entry fell through as
    "not ours" and nothing was ever deleted.

    So the id recorded when we uploaded a hash is the link between the
    two, and it's persisted alongside the seen-list for exactly that
    reason. For a hash seen in a search but never uploaded by us —
    AIOStreams adds releases itself when building stream URLs — the id
    is recovered by re-uploading, which returns the existing entry
    rather than creating a second one.

    The account listing is still fetched, but only to confirm an id is
    really present before issuing a delete, so a stale recorded id can't
    turn into a delete of whatever id got reused since.

    Anything on the account that aiogateway never saw in a search is
    left strictly alone — that's the guard against deleting a torrent
    someone added themselves.

    Safe to run often: deleting a cached torrent doesn't evict it from
    AllDebrid's shared cache, it only removes your link to it, so a
    re-add later returns ready immediately.
    """
    result = {"deleted": 0, "kept": 0, "skipped": 0, "held": 0, "error": None}
    if not is_enabled() or not bool(_settings().get("alldebrid_cleanup", True)):
        return result
    _load_seen()
    if not _seen:
        return result

    _load_pins()
    _prune_pins()

    # Candidates younger than the grace window belong to a search whose
    # results may still be on screen and clickable, so they're held back
    # unless this sweep follows an actual pick (force), at which point
    # the losers are known to be unused.
    now = time.time()
    grace = 0.0 if force else _grace_seconds()
    targets, held = {}, 0
    for h, meta in _seen.items():
        if h in _pinned:
            continue
        if grace and now - float(meta.get("at", 0)) < grace:
            held += 1
            continue
        targets[h] = meta

    result["kept"] = sum(1 for h in _seen if h in _pinned)
    result["held"] = held
    if not targets:
        return result

    own_session = session is None
    session = session or aiohttp.ClientSession()
    try:
        data = await _request(session, "GET", "/magnet/status")
        if data is None:
            result["error"] = "Could not list AllDebrid magnets"
            return result

        magnets = data.get("magnets")
        if isinstance(magnets, dict):
            magnets = [magnets]
        if not isinstance(magnets, list):
            return result

        # v4.1's listing carries a real info-hash per magnet, so the
        # account can be matched against our seen-list directly. That's
        # the primary path, and it also catches releases AIOStreams added
        # itself — we never uploaded those, so we hold no id for them,
        # but we did see their hash in the search results.
        by_hash: dict[str, int] = {}
        present_ids = set()
        hashless = 0
        for m in magnets:
            if not isinstance(m, dict):
                continue
            magnet_id = m.get("id")
            if not isinstance(magnet_id, int):
                continue
            present_ids.add(magnet_id)
            h = (m.get("hash") or "").strip().lower()
            if h:
                by_hash[h] = magnet_id
            else:
                # A magnet added from a raw .torrent with a degenerate
                # info-hash can come back without one. It can still be
                # matched by id if we uploaded it ourselves.
                hashless += 1

        if hashless:
            logger.debug("AllDebrid: %d account entr(ies) reported no hash — "
                         "those can only be matched by recorded id", hashless)

        for h, meta in list(targets.items()):
            magnet_id = by_hash.get(h)

            if magnet_id is None:
                # Not matched by hash. Fall back to an id we recorded at
                # upload time, but only if that id is still on the
                # account — a stale one could have been reused since.
                recorded = meta.get("id")
                if isinstance(recorded, int) and recorded in present_ids:
                    magnet_id = recorded
                else:
                    # Not on the account at all. Nothing to delete, and
                    # nothing to keep tracking.
                    _forget_seen(h)
                    continue

            await _delete(session, magnet_id)
            result["deleted"] += 1
            _forget_seen(h)
            entry = _cache.get(h)
            if entry:
                entry["id"] = None

        result["skipped"] = max(0, len(present_ids) - result["deleted"] - result["kept"])

    finally:
        if own_session:
            await session.close()

    _save_seen()

    if result["deleted"] or result["kept"] or result["held"]:
        logger.info("AllDebrid cleanup: deleted %d, kept %d pinned, held %d in "
                    "grace, left %d untouched",
                    result["deleted"], result["kept"], result["held"],
                    result["skipped"])
    return result


async def sweep_loop(interval_minutes: float = 5.0) -> None:
    """
    Periodic backstop for the discovery paths.

    Adds, background episode scans, pack filling and the manual
    candidate lists all upload candidates while checking them, but none
    of them COMMIT to one — stubs are created as placeholders and the
    real stream is resolved later, at play time. So nothing on those
    paths ever triggers the post-selection sweep, and without this their
    uploads would sit on the account until some unrelated playback
    happened to clean up after them. On a library migration that's
    hundreds of entries waiting on an event that may not come for hours.
    """
    await asyncio.sleep(30)          # let startup settle first
    while True:
        try:
            if is_enabled() and bool(_settings().get("alldebrid_cleanup", True)):
                await cleanup()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning("AllDebrid periodic sweep failed: %s", exc)
        await asyncio.sleep(max(60.0, interval_minutes * 60.0))


async def verify(hashes: Iterable[str]) -> dict[str, bool]:
    """
    Resolve ready/not-ready for a set of infoHashes, using memoised
    answers where available and uploading the rest in batches.

    Returns a hash → ready map containing only the hashes an answer could
    actually be obtained for. A hash absent from the result means
    "unknown" (API failure, rejected magnet), which callers must treat
    differently from False.
    """
    wanted = {(h or "").lower() for h in hashes if h}
    wanted.discard("")
    if not wanted or not is_enabled():
        return {}

    result: dict[str, bool] = {}
    todo: list[str] = []
    for h in wanted:
        known = _cached_answer(h)
        if known is None:
            todo.append(h)
        else:
            result[h] = known

    if not todo:
        return result

    async with _gate:
        # Re-check the memo inside the gate: while queued behind another
        # search, the hashes this one wants may well have just been
        # answered by that one.
        still: list[str] = []
        for h in todo:
            known = _cached_answer(h)
            if known is None:
                still.append(h)
            else:
                result[h] = known
        if not still:
            return result

        logger.info("AllDebrid: verifying %d hash(es)", len(still))
        async with aiohttp.ClientSession() as session:
            for i in range(0, len(still), _BATCH_SIZE):
                batch = still[i:i + _BATCH_SIZE]
                result.update(await _upload_batch(session, batch))

    ready_n = sum(1 for v in result.values() if v)
    logger.info("AllDebrid: %d/%d verified cached", ready_n, len(result))
    return result


async def status(magnet_id: int) -> Optional[dict]:
    """Raw magnet/status for one uploaded magnet. Used by the UI test."""
    if not is_enabled():
        return None
    async with aiohttp.ClientSession() as session:
        data = await _request(session, "GET", "/magnet/status",
                              params={"id[]": str(magnet_id)})
    if not data:
        return None
    m = data.get("magnets")
    if isinstance(m, list):
        m = m[0] if m else None
    return m if isinstance(m, dict) else None


def is_ready_status(magnet: dict) -> bool:
    """Whether a magnet/status record represents a completed torrent."""
    if not isinstance(magnet, dict):
        return False
    code = magnet.get("statusCode")
    if isinstance(code, int):
        return code == _STATUS_READY
    return str(magnet.get("status", "")).strip().lower() == "ready"


async def connection_test() -> dict:
    """
    Diagnostic for Config → Connections. Checks the key against
    /user, which is the cheapest endpoint that proves both that the key
    is valid and that the account is premium (a free account can't serve
    debrid links at all, so that's worth surfacing explicitly rather
    than leaving it to fail later as mysterious dead candidates).
    """
    result = {
        "ok": False, "configured": bool(api_key()), "enabled": is_enabled(),
        "error": None, "username": None, "premium": None, "expires": None,
    }
    if not api_key():
        result["error"] = "No AllDebrid API key set"
        return result

    async with aiohttp.ClientSession() as session:
        data = await _request(session, "GET", "/user")

    if data is None:
        result["error"] = ("Could not reach AllDebrid, or the API key was "
                           "rejected. See the container logs for the exact error.")
        return result

    user = data.get("user") or {}
    result["username"] = user.get("username")
    result["premium"] = bool(user.get("isPremium"))
    exp = user.get("premiumUntil")
    if isinstance(exp, (int, float)) and exp:
        result["expires"] = time.strftime("%Y-%m-%d", time.gmtime(exp))
    if not result["premium"]:
        result["error"] = ("Key works, but this account isn't premium — "
                           "AllDebrid won't serve stream links from it.")
        return result
    result["ok"] = True
    return result
