"""
gateway/ad_cache.py
~~~~~~~~~~~~~~~~~~~
Real AllDebrid cache verification — an asyncio port of the cache-check
used in alldebrid-web (app.py: check_cache_ad).

Why this exists
---------------
AIOStreams reports a per-result `cached` flag, but it only reflects what
each individual addon claims, and for AllDebrid that claim is frequently
wrong or simply missing: AllDebrid deprecated real-time "instant
availability" lookups (magnet/instant no longer reflects true cache
state), so addons that still call it report stale or made-up values, and
many report nothing at all.

The only method that reflects AllDebrid's real cache state today is the
one alldebrid-web settled on:

    upload the magnet -> read `ready` from the upload response ->
    delete anything we uploaded purely to probe

`ready` in the upload response is accurate immediately. The delete step
is what keeps this non-destructive: a probe never leaves anything behind
in the user's AllDebrid account. It runs as a background task, so it
never delays the verdict the caller is waiting on.

Cost is 1 upload call per batch of up to _CHUNK hashes, plus 1 delete per
probed magnet. Results are memoised in-process for _CC_TTL seconds so
repeated searches for the same hashes don't re-hit the upstream API.

Because that cost is paid before any stream can be returned, a single
call probes at most _MAX_PROBE hashes (10 by default), taken from the
front of the candidate list. The goal is to find a cached file quickly,
not to produce a complete cache census of the search results — anything
past the cap is left unverified and falls back to the addon's flag.

Entirely optional: with no ALLDEBRID_API_KEY set, is_enabled() is False
and every caller falls back to AIOStreams' own `cached` flag.
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
import urllib.parse
from typing import Iterable, Optional

import aiohttp

logger = logging.getLogger("aiogateway.ad_cache")

AD_BASE   = "https://api.alldebrid.com/v4"
AD_UPLOAD = f"{AD_BASE}/magnet/upload"
AD_DELETE = f"{AD_BASE}/magnet/delete"

# AllDebrid requires an `agent` parameter on every v4 endpoint.
AD_AGENT = os.environ.get("ALLDEBRID_AGENT", "aiogateway")

# How many hashes go into one upload call. AllDebrid accepts multiple
# magnets[] per request; 10 keeps payloads well clear of any limit and
# keeps each probe round-trip short.
_CHUNK = int(os.environ.get("AD_CACHE_CHUNK", "10"))

# Hard cap on how many hashes a single check_cached() call will actually
# probe. A search can easily return 100+ candidates with info hashes, and
# probing all of them means N/_CHUNK sequential uploads plus one delete
# per magnet — every one of those delete calls is rate-gated, so a big
# search turns into tens of seconds of waiting before a single stream can
# be handed back.
#
# We don't need a verdict on every candidate; we need a cached one fast.
# The list arrives best-first, so the first _MAX_PROBE entries are the
# ones worth spending calls on. Anything past the cap is simply left
# unverified and falls back to the addon's own `cached` flag — the same
# path used when no key is configured at all, so nothing is dropped for
# lack of a verdict.
#
# Set AD_CACHE_MAX_PROBE=0 to restore "probe everything".
_MAX_PROBE = int(os.environ.get("AD_CACHE_MAX_PROBE", "10"))

# Stop probing further chunks as soon as a chunk has produced at least one
# confirmed-cached hash. Only has an effect when _MAX_PROBE allows more
# than one chunk (or is unlimited); with the defaults the cap alone means
# exactly one upload call per search.
_STOP_ON_HIT = os.environ.get("AD_CACHE_STOP_ON_HIT", "true").lower() not in ("0", "false", "no")

# How long a hash's cache verdict is trusted before being re-probed.
_CC_TTL = float(os.environ.get("AD_CACHE_TTL", "300"))

# Whether probe magnets are deleted after their `ready` state is read.
#
# On by default — otherwise every search quietly fills the account's
# magnet list with things nobody asked for. The one caveat, and the
# reason this is a switch at all: if a magnet is ALREADY in the account,
# AllDebrid's upload returns that existing entry's id, and deleting it
# removes the user's real item rather than a probe. alldebrid-web could
# avoid that because its TransferManager knew every hash the user had
# added on purpose; aiogateway has no such list, since it plays through
# AIOStreams and doesn't manage an AllDebrid library of its own. Set
# this to false if you also use the same AllDebrid account to keep
# torrents around by hand.
_DELETE_PROBES = os.environ.get("AD_CACHE_DELETE_PROBES", "true").lower() not in ("0", "false", "no")

# Sliding-window rate limit + minimum spacing between request starts —
# same two-part shape as alldebrid-web, for the same reason: AllDebrid's
# front-end enforces a short-window burst limit independently of the
# per-minute total, so concurrent callers have to be spaced out, not just
# counted.
_AD_RATE_LIMIT  = int(os.environ.get("AD_RATE_LIMIT", "250"))
_AD_RATE_WINDOW = 60.0
_AD_MIN_SPACING = float(os.environ.get("AD_MIN_SPACING_MS", "240")) / 1000.0


def api_key() -> str:
    return os.environ.get("ALLDEBRID_API_KEY", "").strip()


def is_enabled() -> bool:
    """True when a key is configured AND verification is switched on."""
    if not api_key():
        return False
    try:
        from gateway import settings as _settings
        return bool(_settings.get("verify_cache_with_alldebrid", True))
    except Exception:
        return True


# ---------------------------------------------------------------------------
# Rate gate
# ---------------------------------------------------------------------------

class _AdRateGate:
    """Caps outbound AllDebrid request rate app-wide: a per-minute sliding
    window plus a floor on the gap between consecutive request starts."""

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._timestamps: list[float] = []
        self._last_at = 0.0

    async def acquire(self) -> None:
        while True:
            async with self._lock:
                now    = time.monotonic()
                cutoff = now - _AD_RATE_WINDOW
                while self._timestamps and self._timestamps[0] < cutoff:
                    self._timestamps.pop(0)

                since_last = now - self._last_at
                under_cap  = len(self._timestamps) < _AD_RATE_LIMIT
                spaced_out = since_last >= _AD_MIN_SPACING

                if under_cap and spaced_out:
                    self._timestamps.append(now)
                    self._last_at = now
                    return

                wait_for_cap   = (self._timestamps[0] - cutoff) + 0.01 if not under_cap else 0.0
                wait_for_space = (_AD_MIN_SPACING - since_last) if not spaced_out else 0.0
                wait = max(wait_for_cap, wait_for_space, 0.01)
            await asyncio.sleep(wait)


_gate = _AdRateGate()


# ---------------------------------------------------------------------------
# Low-level AllDebrid calls
# ---------------------------------------------------------------------------

def _headers(key: str) -> dict:
    return {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/x-www-form-urlencoded",
    }


def make_magnet(hash_: str, name: str = "") -> str:
    n = urllib.parse.quote(name or "", safe="")
    h = hash_.lower()
    return f"magnet:?xt=urn:btih:{h}&dn={n}" if n else f"magnet:?xt=urn:btih:{h}"


async def _upload_batch(session: aiohttp.ClientSession, key: str, magnets: list[str]) -> dict:
    await _gate.acquire()
    pairs = [("agent", AD_AGENT)] + [("magnets[]", m) for m in magnets]
    try:
        async with session.post(
            AD_UPLOAD,
            headers=_headers(key),
            data=urllib.parse.urlencode(pairs),
            timeout=aiohttp.ClientTimeout(total=20),
        ) as resp:
            if resp.status >= 400:
                body = (await resp.text())[:200]
                logger.warning("[cache-check] upload -> HTTP %s: %s", resp.status, body)
                return {}
            return await resp.json(content_type=None)
    except Exception as exc:
        logger.warning("[cache-check] upload failed: %s", exc)
        return {}


async def _delete(session: aiohttp.ClientSession, key: str, mid) -> None:
    """Remove a magnet we uploaded purely to probe cache state."""
    if not key or not mid:
        return
    await _gate.acquire()
    try:
        async with session.post(
            AD_DELETE,
            headers=_headers(key),
            data=urllib.parse.urlencode({"agent": AD_AGENT, "id": mid}),
            timeout=aiohttp.ClientTimeout(total=15),
        ) as resp:
            if resp.status >= 400:
                logger.warning("[cache-check] delete %s -> HTTP %s: %s",
                               mid, resp.status, (await resp.text())[:200])
    except Exception as exc:
        logger.warning("[cache-check] delete %s: %s", mid, exc)


# ---------------------------------------------------------------------------
# Background probe cleanup
# ---------------------------------------------------------------------------
#
# Deleting the probe magnets is bookkeeping — the `ready` verdict is known
# the moment the upload returns, and nothing downstream needs the account
# to be tidy before a stream can be handed back. But each delete goes
# through the rate gate's minimum spacing, so awaiting ten of them adds
# ~2.4s to every search for no benefit to the caller.
#
# So cleanup is handed to a background task and check_cached returns as
# soon as it has verdicts. Two details make that safe:
#
#   * The deletes use a session owned by this module, never the caller's.
#     A caller-provided session (or one check_cached opened for itself) is
#     typically closed the moment the call returns, which would cancel the
#     in-flight deletes and leave the probes sitting in the account.
#   * Tasks are held in a set until they finish. asyncio only keeps weak
#     references to running tasks, so a fire-and-forget task with no
#     strong reference anywhere can be garbage-collected mid-flight.
#
# shutdown() drains whatever is still pending and closes the session.

_bg_session: Optional[aiohttp.ClientSession] = None
_bg_tasks: set[asyncio.Task] = set()
_bg_lock = asyncio.Lock()


async def _get_bg_session() -> aiohttp.ClientSession:
    global _bg_session
    async with _bg_lock:
        if _bg_session is None or _bg_session.closed:
            _bg_session = aiohttp.ClientSession()
        return _bg_session


async def _cleanup_probes(key: str, ids: list) -> None:
    """Delete probe magnets in the background, off the caller's path."""
    try:
        session = await _get_bg_session()
        results = await asyncio.gather(
            *(_delete(session, key, mid) for mid in ids),
            return_exceptions=True,
        )
        failed = sum(1 for r in results if isinstance(r, Exception))
        if failed:
            logger.warning("[cache-check] background cleanup: %d/%d delete(s) failed",
                           failed, len(ids))
        else:
            logger.debug("[cache-check] background cleanup: removed %d probe magnet(s)",
                         len(ids))
    except asyncio.CancelledError:
        # Shutdown mid-cleanup. Say so plainly — the leftovers are in the
        # user's AllDebrid account and only a log line explains them.
        logger.warning("[cache-check] cleanup cancelled — %d probe magnet(s) "
                       "may remain in the account", len(ids))
        raise
    except Exception as exc:
        logger.warning("[cache-check] background cleanup failed: %s", exc)


def _schedule_cleanup(key: str, ids: list) -> None:
    if not ids:
        return
    try:
        task = asyncio.create_task(_cleanup_probes(key, list(ids)))
    except RuntimeError:
        # No running loop (shouldn't happen from an async caller) — fall
        # back to leaving them, rather than raising into the search path.
        logger.warning("[cache-check] no event loop for cleanup; %d probe "
                       "magnet(s) left in place", len(ids))
        return
    _bg_tasks.add(task)
    task.add_done_callback(_bg_tasks.discard)


async def shutdown(timeout: float = 10.0) -> None:
    """Finish outstanding probe cleanup and close the background session.

    Called from the app's lifespan teardown. Pending deletes get a bounded
    grace period: probe magnets left behind are a cosmetic annoyance, not
    worth hanging a shutdown on a slow or unreachable AllDebrid.
    """
    global _bg_session
    pending = [t for t in _bg_tasks if not t.done()]
    if pending:
        logger.info("[cache-check] waiting on %d background cleanup task(s)", len(pending))
        done, still_running = await asyncio.wait(pending, timeout=timeout)
        for t in still_running:
            t.cancel()
        if still_running:
            await asyncio.gather(*still_running, return_exceptions=True)
    async with _bg_lock:
        if _bg_session is not None and not _bg_session.closed:
            await _bg_session.close()
        _bg_session = None


# ---------------------------------------------------------------------------
# Result memo
# ---------------------------------------------------------------------------

_results: dict[str, tuple[bool, float]] = {}
_results_lock = asyncio.Lock()


async def _memo_read(hashes: list[str]) -> tuple[dict[str, bool], list[str]]:
    now = time.time()
    async with _results_lock:
        fresh = {h: _results[h][0] for h in hashes
                 if h in _results and now < _results[h][1]}
    stale = [h for h in hashes if h not in fresh]
    return fresh, stale


async def _memo_write(hashes: Iterable[str], ready_map: dict[str, bool]) -> None:
    exp = time.time() + _CC_TTL
    async with _results_lock:
        for h in hashes:
            _results[h] = (ready_map.get(h, False), exp)


def forget(hash_: str) -> None:
    """Drop a memoised verdict — e.g. after a link from it turned out dead."""
    _results.pop(hash_.lower(), None)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def check_cached(
    items: list[tuple[str, str]],
    session: Optional[aiohttp.ClientSession] = None,
) -> dict[str, bool]:
    """Return {info_hash: bool} — True means AllDebrid really has it cached.

    `items` is a list of (info_hash, display_name) pairs, best candidate
    first; the name is only used to build a nicer magnet dn and may be
    empty.

    The returned dict is NOT guaranteed to cover every hash passed in. At
    most _MAX_PROBE unmemoised hashes are probed per call, and probing
    stops early once a cached one is found, so a hash that was never
    asked about is simply absent. Callers must treat "absent" as "no
    verdict" and fall back to whatever the addon claimed — never as
    uncached.

    Hashes whose verdict is still fresh in the memo are answered without
    any network call.

    A per-magnet error is reported False — same as alldebrid-web — and
    logged. A whole batch that failed (upload error, rate limit,
    top-level API error) is left absent instead, so a transient upstream
    failure falls back to the addon's flag rather than making every hash
    in that batch look uncached; it's logged loudly either way.
    """
    key = api_key()
    if not items or not key:
        return {}

    hashes = []
    name_by_hash: dict[str, str] = {}
    for h, name in items:
        if not h:
            continue
        h = h.lower()
        if h not in name_by_hash:
            hashes.append(h)
        name_by_hash[h] = name or name_by_hash.get(h, "")

    if not hashes:
        return {}

    fresh, stale = await _memo_read(hashes)
    if not stale:
        return fresh

    # Spend the probe budget on the front of the list only. Memo hits
    # above don't count against it — they cost nothing.
    if _MAX_PROBE > 0 and len(stale) > _MAX_PROBE:
        logger.info("[cache-check] %d unverified hash(es); probing the first %d",
                    len(stale), _MAX_PROBE)
        stale = stale[:_MAX_PROBE]

    own_session = session is None
    if own_session:
        session = aiohttp.ClientSession()

    ready_map: dict[str, bool] = {}
    to_delete: list = []   # AllDebrid magnet ids to clean up afterwards
    probed: list[str] = []  # hashes we actually got as far as asking about

    try:
        for i in range(0, len(stale), _CHUNK):
            chunk   = stale[i:i + _CHUNK]
            magnets = [make_magnet(h, name_by_hash.get(h, "")) for h in chunk]

            resp = await _upload_batch(session, key, magnets)
            if not resp:
                continue

            # A failed call can come back as a TOP-LEVEL error (bad apikey,
            # rate limited) with no "data" key at all. Silently reading
            # data.magnets there would make the whole chunk look uncached.
            if resp.get("status") == "error":
                err = resp.get("error", {}) or {}
                logger.warning("[cache-check] AllDebrid error %s: %s",
                               err.get("code"), err.get("message"))
                continue

            entries = (resp.get("data") or {}).get("magnets", []) or []
            if not entries:
                logger.warning(
                    "[cache-check] upload succeeded but returned 0 magnets "
                    "for %d requested hash(es) — raw: %s",
                    len(chunk), str(resp)[:300],
                )
                continue

            # Past this point the chunk got a real answer, so its verdicts
            # are worth memoising. Chunks that bailed out above did not —
            # a transient upload failure must not cache a False verdict
            # that then drops those candidates for the next _CC_TTL.
            probed.extend(chunk)

            n_errors = 0
            for idx, m in enumerate(entries):
                # AllDebrid normally echoes the hash back; fall back to
                # the request's positional order if it's ever missing so
                # results aren't dropped silently.
                h = (m.get("hash") or "").lower()
                if not h and idx < len(chunk):
                    h = chunk[idx]
                if not h:
                    logger.warning("[cache-check] magnet item has no hash and no "
                                   "positional fallback: %s", m)
                    continue

                if m.get("error"):
                    err = m["error"] or {}
                    logger.warning("[cache-check] %s: %s %s",
                                   h[:8], err.get("code"), err.get("message"))
                    ready_map[h] = False
                    n_errors += 1
                    continue

                ready_map[h] = bool(m.get("ready", False))
                mid = m.get("id")
                if mid and _DELETE_PROBES:
                    to_delete.append(mid)

            n_ready = sum(1 for m in entries if not m.get("error") and m.get("ready"))
            logger.info("[cache-check] batch of %d: %d ready, %d errored, %d not-ready",
                        len(chunk), n_ready, n_errors,
                        len(entries) - n_ready - n_errors)

            # One confirmed-cached candidate is enough to play. Everything
            # still unprobed keeps its addon flag and stays in the running,
            # so stopping here costs nothing but the calls it saves.
            if _STOP_ON_HIT and n_ready and i + _CHUNK < len(stale):
                logger.info("[cache-check] cached hit found — skipping %d remaining hash(es)",
                            len(stale) - (i + len(chunk)))
                break

        # Hand cleanup off and return — the verdicts are already known,
        # and each delete costs a rate-gated round-trip the caller has no
        # reason to wait for. Scheduled before the finally block closes
        # our session because the cleanup task uses its own.
        _schedule_cleanup(key, to_delete)
    finally:
        if own_session:
            await session.close()

    # Only hashes that were actually asked about get a verdict. A hash we
    # skipped — over the cap, or after an early exit — must not be
    # memoised or reported as False: callers treat False as "AllDebrid
    # says no" and drop it, whereas a missing key means "no verdict" and
    # falls back to the addon's own flag. Conflating the two would quietly
    # discard every candidate past the cap.
    await _memo_write(probed, ready_map)
    return {**fresh, **{h: ready_map.get(h, False) for h in probed}}
