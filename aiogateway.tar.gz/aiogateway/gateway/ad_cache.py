"""
gateway/ad_cache.py
~~~~~~~~~~~~~~~~~~~
Real AllDebrid cache verification — an asyncio port of the cache-check
used in alldebrid-web (app.py: check_cache_ad).

Why this exists
---------------
AIOStreams reports a per-result `cached` flag, but it only reflects what
each individual addon claims, and for AllDebrid that claim is frequently
wrong or simply missing: AllDebrid deprecated real-time "instant
availability" lookups (magnet/instant no longer reflects true cache
state), so addons that still call it report stale or made-up values, and
many report nothing at all.

The only method that reflects AllDebrid's real cache state today is the
one alldebrid-web settled on:

    upload the magnet -> read `ready` from the upload response ->
    delete anything we uploaded purely to probe

`ready` in the upload response is accurate immediately. The delete step
is what keeps this non-destructive: a probe never leaves anything behind
in the user's AllDebrid account.

Cost is 1 upload call per batch of up to 20 hashes, plus 1 delete per
probed magnet. Results are memoised in-process for _CC_TTL seconds so
repeated searches for the same hashes don't re-hit the upstream API.

Entirely optional: with no ALLDEBRID_API_KEY set, is_enabled() is False
and every caller falls back to AIOStreams' own `cached` flag.
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
import urllib.parse
from typing import Iterable, Optional

import aiohttp

logger = logging.getLogger("aiogateway.ad_cache")

AD_BASE   = "https://api.alldebrid.com/v4"
AD_UPLOAD = f"{AD_BASE}/magnet/upload"
AD_DELETE = f"{AD_BASE}/magnet/delete"

# AllDebrid requires an `agent` parameter on every v4 endpoint.
AD_AGENT = os.environ.get("ALLDEBRID_AGENT", "aiogateway")

# How many hashes go into one upload call. AllDebrid accepts multiple
# magnets[] per request; 20 keeps payloads well clear of any limit.
_CHUNK = int(os.environ.get("AD_CACHE_CHUNK", "20"))

# How long a hash's cache verdict is trusted before being re-probed.
_CC_TTL = float(os.environ.get("AD_CACHE_TTL", "300"))

# Whether probe magnets are deleted after their `ready` state is read.
#
# On by default — otherwise every search quietly fills the account's
# magnet list with things nobody asked for. The one caveat, and the
# reason this is a switch at all: if a magnet is ALREADY in the account,
# AllDebrid's upload returns that existing entry's id, and deleting it
# removes the user's real item rather than a probe. alldebrid-web could
# avoid that because its TransferManager knew every hash the user had
# added on purpose; aiogateway has no such list, since it plays through
# AIOStreams and doesn't manage an AllDebrid library of its own. Set
# this to false if you also use the same AllDebrid account to keep
# torrents around by hand.
_DELETE_PROBES = os.environ.get("AD_CACHE_DELETE_PROBES", "true").lower() not in ("0", "false", "no")

# Sliding-window rate limit + minimum spacing between request starts —
# same two-part shape as alldebrid-web, for the same reason: AllDebrid's
# front-end enforces a short-window burst limit independently of the
# per-minute total, so concurrent callers have to be spaced out, not just
# counted.
_AD_RATE_LIMIT  = int(os.environ.get("AD_RATE_LIMIT", "250"))
_AD_RATE_WINDOW = 60.0
_AD_MIN_SPACING = float(os.environ.get("AD_MIN_SPACING_MS", "240")) / 1000.0


def api_key() -> str:
    return os.environ.get("ALLDEBRID_API_KEY", "").strip()


def is_enabled() -> bool:
    """True when a key is configured AND verification is switched on."""
    if not api_key():
        return False
    try:
        from gateway import settings as _settings
        return bool(_settings.get("verify_cache_with_alldebrid", True))
    except Exception:
        return True


# ---------------------------------------------------------------------------
# Rate gate
# ---------------------------------------------------------------------------

class _AdRateGate:
    """Caps outbound AllDebrid request rate app-wide: a per-minute sliding
    window plus a floor on the gap between consecutive request starts."""

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._timestamps: list[float] = []
        self._last_at = 0.0

    async def acquire(self) -> None:
        while True:
            async with self._lock:
                now    = time.monotonic()
                cutoff = now - _AD_RATE_WINDOW
                while self._timestamps and self._timestamps[0] < cutoff:
                    self._timestamps.pop(0)

                since_last = now - self._last_at
                under_cap  = len(self._timestamps) < _AD_RATE_LIMIT
                spaced_out = since_last >= _AD_MIN_SPACING

                if under_cap and spaced_out:
                    self._timestamps.append(now)
                    self._last_at = now
                    return

                wait_for_cap   = (self._timestamps[0] - cutoff) + 0.01 if not under_cap else 0.0
                wait_for_space = (_AD_MIN_SPACING - since_last) if not spaced_out else 0.0
                wait = max(wait_for_cap, wait_for_space, 0.01)
            await asyncio.sleep(wait)


_gate = _AdRateGate()


# ---------------------------------------------------------------------------
# Low-level AllDebrid calls
# ---------------------------------------------------------------------------

def _headers(key: str) -> dict:
    return {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/x-www-form-urlencoded",
    }


def make_magnet(hash_: str, name: str = "") -> str:
    n = urllib.parse.quote(name or "", safe="")
    h = hash_.lower()
    return f"magnet:?xt=urn:btih:{h}&dn={n}" if n else f"magnet:?xt=urn:btih:{h}"


async def _upload_batch(session: aiohttp.ClientSession, key: str, magnets: list[str]) -> dict:
    await _gate.acquire()
    pairs = [("agent", AD_AGENT)] + [("magnets[]", m) for m in magnets]
    try:
        async with session.post(
            AD_UPLOAD,
            headers=_headers(key),
            data=urllib.parse.urlencode(pairs),
            timeout=aiohttp.ClientTimeout(total=20),
        ) as resp:
            if resp.status >= 400:
                body = (await resp.text())[:200]
                logger.warning("[cache-check] upload -> HTTP %s: %s", resp.status, body)
                return {}
            return await resp.json(content_type=None)
    except Exception as exc:
        logger.warning("[cache-check] upload failed: %s", exc)
        return {}


async def _delete(session: aiohttp.ClientSession, key: str, mid) -> None:
    """Remove a magnet we uploaded purely to probe cache state."""
    if not key or not mid:
        return
    await _gate.acquire()
    try:
        async with session.post(
            AD_DELETE,
            headers=_headers(key),
            data=urllib.parse.urlencode({"agent": AD_AGENT, "id": mid}),
            timeout=aiohttp.ClientTimeout(total=15),
        ) as resp:
            if resp.status >= 400:
                logger.warning("[cache-check] delete %s -> HTTP %s: %s",
                               mid, resp.status, (await resp.text())[:200])
    except Exception as exc:
        logger.warning("[cache-check] delete %s: %s", mid, exc)


# ---------------------------------------------------------------------------
# Result memo
# ---------------------------------------------------------------------------

_results: dict[str, tuple[bool, float]] = {}
_results_lock = asyncio.Lock()


async def _memo_read(hashes: list[str]) -> tuple[dict[str, bool], list[str]]:
    now = time.time()
    async with _results_lock:
        fresh = {h: _results[h][0] for h in hashes
                 if h in _results and now < _results[h][1]}
    stale = [h for h in hashes if h not in fresh]
    return fresh, stale


async def _memo_write(hashes: Iterable[str], ready_map: dict[str, bool]) -> None:
    exp = time.time() + _CC_TTL
    async with _results_lock:
        for h in hashes:
            _results[h] = (ready_map.get(h, False), exp)


def forget(hash_: str) -> None:
    """Drop a memoised verdict — e.g. after a link from it turned out dead."""
    _results.pop(hash_.lower(), None)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def check_cached(
    items: list[tuple[str, str]],
    session: Optional[aiohttp.ClientSession] = None,
) -> dict[str, bool]:
    """Return {info_hash: bool} — True means AllDebrid really has it cached.

    `items` is a list of (info_hash, display_name) pairs; the name is only
    used to build a nicer magnet dn and may be empty.

    Hashes whose verdict is still fresh in the memo are answered without
    any network call. Anything that couldn't be determined (upload error,
    rate limit, API error) is reported False — same as alldebrid-web —
    but is logged loudly rather than silently looking uncached, since a
    top-level API error would otherwise make every hash in the batch
    look not-cached with no indication anything went wrong.
    """
    key = api_key()
    if not items or not key:
        return {}

    hashes = []
    name_by_hash: dict[str, str] = {}
    for h, name in items:
        if not h:
            continue
        h = h.lower()
        if h not in name_by_hash:
            hashes.append(h)
        name_by_hash[h] = name or name_by_hash.get(h, "")

    if not hashes:
        return {}

    fresh, stale = await _memo_read(hashes)
    if not stale:
        return fresh

    own_session = session is None
    if own_session:
        session = aiohttp.ClientSession()

    ready_map: dict[str, bool] = {}
    to_delete: list = []   # AllDebrid magnet ids to clean up afterwards

    try:
        for i in range(0, len(stale), _CHUNK):
            chunk   = stale[i:i + _CHUNK]
            magnets = [make_magnet(h, name_by_hash.get(h, "")) for h in chunk]

            resp = await _upload_batch(session, key, magnets)
            if not resp:
                continue

            # A failed call can come back as a TOP-LEVEL error (bad apikey,
            # rate limited) with no "data" key at all. Silently reading
            # data.magnets there would make the whole chunk look uncached.
            if resp.get("status") == "error":
                err = resp.get("error", {}) or {}
                logger.warning("[cache-check] AllDebrid error %s: %s",
                               err.get("code"), err.get("message"))
                continue

            entries = (resp.get("data") or {}).get("magnets", []) or []
            if not entries:
                logger.warning(
                    "[cache-check] upload succeeded but returned 0 magnets "
                    "for %d requested hash(es) — raw: %s",
                    len(chunk), str(resp)[:300],
                )
                continue

            n_errors = 0
            for idx, m in enumerate(entries):
                # AllDebrid normally echoes the hash back; fall back to
                # the request's positional order if it's ever missing so
                # results aren't dropped silently.
                h = (m.get("hash") or "").lower()
                if not h and idx < len(chunk):
                    h = chunk[idx]
                if not h:
                    logger.warning("[cache-check] magnet item has no hash and no "
                                   "positional fallback: %s", m)
                    continue

                if m.get("error"):
                    err = m["error"] or {}
                    logger.warning("[cache-check] %s: %s %s",
                                   h[:8], err.get("code"), err.get("message"))
                    ready_map[h] = False
                    n_errors += 1
                    continue

                ready_map[h] = bool(m.get("ready", False))
                mid = m.get("id")
                if mid and _DELETE_PROBES:
                    to_delete.append(mid)

            n_ready = sum(1 for m in entries if not m.get("error") and m.get("ready"))
            logger.info("[cache-check] batch of %d: %d ready, %d errored, %d not-ready",
                        len(chunk), n_ready, n_errors,
                        len(entries) - n_ready - n_errors)

        # Clean up everything uploaded purely to probe. Done before the
        # function returns (rather than fire-and-forget) so nothing is
        # left behind if the session we opened is about to close.
        if to_delete:
            await asyncio.gather(
                *(_delete(session, key, mid) for mid in to_delete),
                return_exceptions=True,
            )
    finally:
        if own_session:
            await session.close()

    await _memo_write(stale, ready_map)
    return {**fresh, **{h: ready_map.get(h, False) for h in stale}}
