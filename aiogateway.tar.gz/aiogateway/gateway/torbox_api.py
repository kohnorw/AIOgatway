"""
gateway/torbox_api.py
~~~~~~~~~~~~~~~~~~~~~
Thin, synchronous TorBox API client. Every outbound call waits on the
shared limiters in torbox_guard, so no combination of playback, scans,
sweeps and migration can burst past TorBox's rate limit.

Endpoints used:
  search-api.torbox.app  GET /torrents/imdb:{id}[?season=&episode=]&check_cache=true
  api.torbox.app         POST /v1/api/torrents/createtorrent
                         GET  /v1/api/torrents/mylist            (paged / ?id=)
                         GET  /v1/api/torrents/requestdl
                         GET  /v1/api/user/me

Sync (requests) on purpose: FUSE read threads need to repair expired CDN
URLs inline, and async callers just use asyncio.to_thread.
"""
from __future__ import annotations

import logging
import os
import re
import threading
import time
from typing import Any, Optional

import requests

from . import torbox_guard as guard

log = logging.getLogger("aiogateway.torbox.api")

API_BASE    = os.environ.get("TORBOX_API_BASE", "https://api.torbox.app").rstrip("/")
SEARCH_BASE = os.environ.get("TORBOX_SEARCH_BASE", "https://search-api.torbox.app").rstrip("/")
_UA = "AIOGateway-TorBox/1.0"


def api_key() -> str:
    """The key entered in Config → Connections wins; TORBOX_API_KEY in the
    environment is the fallback."""
    return key_source()[0]


def key_source() -> tuple[str, str]:
    """(key, source) where source is "config", "env" or "" (not set)."""
    try:
        from gateway import settings as _settings
        k = (_settings.get("torbox_api_key", "") or "").strip()
        if k:
            return k, "config"
    except Exception:
        pass
    k = os.environ.get("TORBOX_API_KEY", "").strip()
    return (k, "env") if k else ("", "")


class TorBoxError(Exception):
    def __init__(self, message: str, status: int = 0, code: str = ""):
        super().__init__(message)
        self.status = status
        self.code = code

    @property
    def retryable(self) -> bool:
        return self.status == 429 or self.status >= 500 or self.status == 0

    @property
    def rate_limited(self) -> bool:
        return self.status == 429


_session_lock = threading.Lock()
_session: Optional[requests.Session] = None


def _http() -> requests.Session:
    global _session
    with _session_lock:
        if _session is None:
            s = requests.Session()
            adapter = requests.adapters.HTTPAdapter(pool_connections=8, pool_maxsize=16)
            s.mount("https://", adapter)
            s.mount("http://", adapter)
            s.headers["User-Agent"] = _UA
            _session = s
        return _session


def _call(method: str, url: str, *, limiter: guard.RateLimiter, priority: int,
          params: Optional[dict] = None, data: Optional[dict] = None,
          files: Optional[dict] = None, auth_header: bool = True,
          timeout: float = 60, retries: int = 2, key: Optional[str] = None) -> Any:
    """One logical API call: limiter → request → envelope decode, with a
    small number of retries for transient failures (each retry also waits on
    the limiter, so retries can't break the budget either)."""
    key = key or api_key()
    if not key:
        raise TorBoxError("No TorBox API key set (Config → Connections)", status=401, code="NO_KEY")

    headers = {"Authorization": f"Bearer {key}"} if auth_header else {}
    last: Optional[TorBoxError] = None

    for attempt in range(retries + 1):
        limiter.acquire(priority)
        guard.stats.api_call()
        guard.stats.inc(f"api_calls_{limiter.name}")
        try:
            r = _http().request(method, url, params=params, data=data, files=files,
                                headers=headers, timeout=timeout)
        except requests.RequestException as exc:
            last = TorBoxError(f"network error: {exc}", status=0)
        else:
            body: Any = None
            try:
                body = r.json()
            except ValueError:
                pass

            if r.status_code == 429:
                guard.stats.inc("http_429")
                backoff = float(guard._setting("torbox_429_backoff_seconds", 30))
                limiter.pause(backoff)
                last = TorBoxError("TorBox rate limited (429)", status=429)
            elif r.status_code >= 400 or (isinstance(body, dict) and body.get("success") is False):
                detail = ""
                code = ""
                if isinstance(body, dict):
                    detail = str(body.get("detail") or body.get("error") or "")
                    code = str(body.get("error") or "")
                if not detail:
                    detail = (r.text or "")[:200]
                status = r.status_code if r.status_code >= 400 else 400
                err = TorBoxError(f"TorBox {status}: {detail}", status=status, code=code)
                if not err.retryable:
                    raise err
                last = err
            elif body is None:
                # 200 with an HTML/garbage body is TorBox's "disguised" error.
                last = TorBoxError("TorBox returned a non-JSON response", status=502)
            else:
                return body

        if attempt < retries:
            sleep = min(2 ** attempt, 8)
            log.debug("TorBox call %s failed (%s) — retry %d in %ds", url, last, attempt + 1, sleep)
            time.sleep(sleep)

    guard.stats.inc("api_errors")
    raise last or TorBoxError("TorBox call failed")


# ─────────────────────────────────────────────────────────────────────────────
# Search API
# ─────────────────────────────────────────────────────────────────────────────

def search_torrents(imdb_id: str, season: Optional[int] = None, episode: Optional[int] = None,
                    priority: int = guard.LOW) -> list[dict]:
    params: dict = {"check_cache": "true", "metadata": "false"}
    if season is not None:
        params["season"] = season
        params["episode"] = episode if episode is not None else 0
    url = f"{SEARCH_BASE}/torrents/imdb:{imdb_id}"
    try:
        body = _call("GET", url, limiter=guard.search_limiter, priority=priority,
                     params=params, timeout=45)
    except TorBoxError as exc:
        # The search API answers 404 / "Could not find metadata" for titles
        # it simply has nothing for — that's an empty result, not an error.
        if exc.status == 404 or "metadata" in str(exc).lower():
            return []
        raise
    data = body.get("data") if isinstance(body, dict) else None
    torrents = (data or {}).get("torrents") if isinstance(data, dict) else None
    return list(torrents or [])


_BTIH = re.compile(r"btih:([a-fA-F0-9]{40}|[A-Z2-7]{32})", re.I)


def hash_of(result: dict) -> Optional[str]:
    h = result.get("hash") or result.get("info_hash")
    if not h and result.get("magnet"):
        m = _BTIH.search(result["magnet"])
        h = m.group(1) if m else None
    return h.lower() if h and len(h) == 40 else (h.lower() if h else None)


# ─────────────────────────────────────────────────────────────────────────────
# Main API
# ─────────────────────────────────────────────────────────────────────────────

def user_me(priority: int = guard.HIGH, key: Optional[str] = None) -> dict:
    """Account details. `key` lets a new key be validated before it's saved."""
    body = _call("GET", f"{API_BASE}/v1/api/user/me", limiter=guard.api_limiter,
                 priority=priority, timeout=15, retries=0, key=key)
    return body.get("data") or {}


def create_torrent(magnet: str, only_cached: bool = True, priority: int = guard.LOW) -> dict:
    """Adds a torrent to the account. With only_cached (always, in this
    app), TorBox refuses instead of queueing a download."""
    guard.create_limiter.acquire(priority)
    form = {
        "magnet": magnet,
        "seed": "3",                  # don't seed
        "allow_zip": "false",
        "add_only_if_cached": "true" if only_cached else "false",
    }
    body = _call("POST", f"{API_BASE}/v1/api/torrents/createtorrent", limiter=guard.api_limiter,
                 priority=priority, files={k: (None, v) for k, v in form.items()},
                 timeout=60, retries=1)
    guard.stats.inc("torrents_added")
    return body.get("data") or {}


def torrent_info(torrent_id: int, priority: int = guard.LOW) -> Optional[dict]:
    body = _call("GET", f"{API_BASE}/v1/api/torrents/mylist", limiter=guard.api_limiter,
                 priority=priority, params={"id": torrent_id, "bypass_cache": "true"}, timeout=60)
    data = body.get("data")
    if isinstance(data, list):
        return data[0] if data else None
    return data or None


def list_all_torrents(page_size: int = 1000, priority: int = guard.LOW) -> list[dict]:
    """Paginated full mylist — TorBox caps a single response, so page with
    offset until a short page (same approach as warpbox)."""
    out: list[dict] = []
    offset = 0
    while True:
        body = _call("GET", f"{API_BASE}/v1/api/torrents/mylist", limiter=guard.api_limiter,
                     priority=priority, timeout=120,
                     params={"offset": offset, "limit": page_size, "bypass_cache": "false"})
        page = body.get("data") or []
        out.extend(page)
        if len(page) < page_size:
            return out
        offset += len(page)


def request_download_url(torrent_id: int, file_id: int, priority: int = guard.HIGH) -> str:
    # requestdl authenticates via the token query param, not the header.
    body = _call("GET", f"{API_BASE}/v1/api/torrents/requestdl", limiter=guard.api_limiter,
                 priority=priority, auth_header=False, timeout=30,
                 params={"token": api_key(), "torrent_id": torrent_id,
                         "file_id": file_id, "redirect": "false"})
    url = body.get("data")
    if not isinstance(url, str) or not url.startswith("http"):
        raise TorBoxError("requestdl returned no URL", status=502)
    guard.stats.inc("requestdl_calls")
    return url
