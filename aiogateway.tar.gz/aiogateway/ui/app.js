'use strict';

/* AIOGateway UI
 *
 * Three states the page can be in, decided once on load:
 *   wizard  — no connections configured yet
 *   login   — configured, nobody signed in
 *   app     — signed in
 */

const state = {
  user: null,
  page: 'home',
  searchKind: 'all',
  searchTimer: null,
  hero: [],
  heroIndex: 0,
  heroTimer: null,
  library: { page: 1, filter: '', kind: 'all', state: 'all', requestCount: 0 },
  detail: { imdbId: null, page: 1, season: null, quality: 'all' },
  streams: { token: null, rows: [], filter: 'all', ctx: null },
  calendar: {
    entries: [], view: 'month', filter: 'all', loaded: false,
    month: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
    selected: new Date().toISOString().slice(0, 10),
  },
  users: { page: 1, filter: '', timer: null },
  modal: null,
  seasons: new Set(),
  migItems: [],
  migJob: null,
  migTimer: null,
  repairTimer: null,
  inLibrary: new Set(),
};

/* ── helpers ─────────────────────────────────────────────────── */
const $ = (id) => document.getElementById(id);
const el = (sel, root = document) => root.querySelector(sel);
const els = (sel, root = document) => Array.from(root.querySelectorAll(sel));

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    credentials: 'same-origin',
    headers: options.body ? { 'Content-Type': 'application/json' } : {},
    ...options,
  });
  if (response.status === 401) {
    showLogin();
    throw new Error('Sign in to continue');
  }
  const text = await response.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = null; }
  if (!response.ok) {
    throw new Error((data && data.detail) || `Request failed (${response.status})`);
  }
  return data;
}

function toast(message, kind = 'in', ms = 3800) {
  const existing = el('.toast');
  if (existing) existing.remove();
  const node = document.createElement('div');
  node.className = `toast ${kind}`;
  node.textContent = message;
  document.body.appendChild(node);
  setTimeout(() => node.remove(), ms);
}

function setResult(id, message, kind) {
  const node = $(id);
  if (!node) return;
  node.textContent = message || '';
  node.className = `tresult${kind ? ' ' + kind : ''}`;
}

function flashSaved(id) {
  const node = $(id);
  if (!node) return;
  node.style.display = 'inline';
  setTimeout(() => { node.style.display = 'none'; }, 2200);
}

function bytes(value) {
  if (!value) return '—';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let n = value, i = 0;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i += 1; }
  return `${n.toFixed(n >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}

function when(timestamp) {
  if (!timestamp) return 'never';
  const diff = Date.now() / 1000 - timestamp;
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

function csvToList(value) {
  return String(value || '').split(',').map((s) => s.trim()).filter(Boolean);
}

/* ── boot ────────────────────────────────────────────────────── */
async function boot() {
  let setup;
  try {
    setup = await fetch('/api/setup/status').then((r) => r.json());
  } catch {
    document.body.innerHTML =
      '<div class="login"><div class="login-inner">' +
      '<div class="login-logo">AIOGateway</div>' +
      '<div class="hint">The server isn\'t responding. Check the container is running.</div>' +
      '</div></div>';
    return;
  }

  if (!setup.setup_complete) {
    showWizard(setup);
    return;
  }

  try {
    const me = await fetch('/api/auth/me', { credentials: 'same-origin' }).then((r) => r.json());
    if (me.authenticated) {
      startApp(me.user);
      return;
    }
  } catch { /* fall through to the sign-in screen */ }
  showLogin();
}

/* ── wizard ──────────────────────────────────────────────────── */
function showWizard(setup) {
  $('wizard').style.display = 'flex';
  if (setup.aiostreams_set) markStep('stepAio', 'aioPill');
  if (setup.plex_set) markStep('stepPlex', 'plexPill');
}

function markStep(stepId, pillId) {
  $(stepId).classList.add('done');
  const pill = $(pillId);
  pill.className = 'pill ok';
  pill.textContent = 'Saved';
}

function aioForm() {
  return {
    url: $('wizAioUrl').value.trim(),
    uuid: $('wizAioUuid').value.trim(),
    password: $('wizAioPass').value,
  };
}

async function wizTestAio() {
  setResult('wizAioResult', 'Testing…');
  try {
    const result = await api('/api/setup/aiostreams/test',
      { method: 'POST', body: JSON.stringify(aioForm()) });
    const services = result.services && result.services.length
      ? ` Services seen: ${result.services.join(', ')}.`
      : '';
    setResult('wizAioResult',
      `Connected. ${result.results} result(s) for the test search.${services}`, 'ok');
  } catch (error) {
    setResult('wizAioResult', error.message, 'er');
  }
}

async function wizSaveAio() {
  setResult('wizAioResult', 'Saving…');
  try {
    await api('/api/setup/aiostreams', { method: 'POST', body: JSON.stringify(aioForm()) });
    setResult('wizAioResult', 'Saved and encrypted.', 'ok');
    markStep('stepAio', 'aioPill');
    await maybeFinishWizard();
  } catch (error) {
    setResult('wizAioResult', error.message, 'er');
  }
}

function plexForm() {
  return { url: $('wizPlexUrl').value.trim(), token: $('wizPlexToken').value };
}

async function wizTestPlex() {
  setResult('wizPlexResult', 'Testing…');
  try {
    const result = await api('/api/setup/plex/test',
      { method: 'POST', body: JSON.stringify(plexForm()) });
    setResult('wizPlexResult', `Connected to ${result.server}.`, 'ok');
  } catch (error) {
    setResult('wizPlexResult', error.message, 'er');
  }
}

async function wizSavePlex() {
  setResult('wizPlexResult', 'Saving…');
  try {
    await api('/api/setup/plex', { method: 'POST', body: JSON.stringify(plexForm()) });
    setResult('wizPlexResult', 'Saved and encrypted.', 'ok');
    markStep('stepPlex', 'plexPill');
    await maybeFinishWizard();
  } catch (error) {
    setResult('wizPlexResult', error.message, 'er');
  }
}

async function wizRestore(event) {
  const file = event.target.files[0];
  if (!file) return;
  setResult('wizRestoreResult', 'Restoring…');
  try {
    const payload = JSON.parse(await file.text());
    const r = await api('/api/setup/restore',
      { method: 'POST', body: JSON.stringify({ payload }) });

    const bits = [`${r.added} file${r.added === 1 ? '' : 's'}`];
    if (r.settings) bits.push(`${r.settings} setting${r.settings === 1 ? '' : 's'}`);
    if (r.requests) bits.push(`${r.requests} request${r.requests === 1 ? '' : 's'}`);
    if ((r.connections || []).length) bits.push('connection details');
    let message = `Restored ${bits.join(', ')}.`;

    if (r.legacy && (r.connections || []).length) {
      // Old backups stored these in the clear. They're encrypted now that
      // they're here, but the file on disk still isn't.
      message += ' That backup held your URLs and keys as plain text — ' +
                 "they're encrypted here now, but delete the file when you're done.";
    }
    setResult('wizRestoreResult', message, 'ok');

    if (r.setup_complete) {
      markStep('stepAio', 'aioPill');
      markStep('stepPlex', 'plexPill');
      setTimeout(maybeFinishWizard, 1200);
    } else {
      setResult('wizRestoreResult',
        message + ' Fill in whatever is still missing above.', 'ok');
    }
  } catch (error) {
    setResult('wizRestoreResult', error.message, 'er');
  } finally {
    event.target.value = '';
  }
}

async function maybeFinishWizard() {
  const setup = await fetch('/api/setup/status').then((r) => r.json());
  if (!setup.setup_complete) return;
  toast('Setup complete — sign in with Plex', 'ok');
  setTimeout(() => { $('wizard').style.display = 'none'; showLogin(); }, 900);
}

/* ── login ───────────────────────────────────────────────────── */
function showLogin() {
  $('wizard').style.display = 'none';
  $('nav').style.display = 'none';
  els('.page').forEach((p) => { p.style.display = 'none'; });
  $('loginScreen').style.display = 'flex';
}

async function startLogin() {
  const button = $('loginBtn');
  button.disabled = true;
  setResult('loginStatus', 'Opening Plex…');
  try {
    const pin = await api('/api/auth/plex/start', { method: 'POST' });
    const popup = window.open(pin.auth_url, 'plex-login', 'width=620,height=760');
    if (!popup) {
      setResult('loginStatus',
        'Your browser blocked the sign-in window. Allow pop-ups and try again.', 'er');
      button.disabled = false;
      return;
    }
    setResult('loginStatus', 'Waiting for you to approve the sign-in…');
    pollLogin(pin.pin_id, button, Date.now() + 180000);
  } catch (error) {
    setResult('loginStatus', error.message, 'er');
    button.disabled = false;
  }
}

async function pollLogin(pinId, button, deadline) {
  if (Date.now() > deadline) {
    setResult('loginStatus', 'That sign-in timed out. Try again.', 'er');
    button.disabled = false;
    return;
  }
  try {
    const result = await api(`/api/auth/plex/poll/${pinId}`);
    if (result.pending) {
      setTimeout(() => pollLogin(pinId, button, deadline), 1800);
      return;
    }
    setResult('loginStatus', '');
    button.disabled = false;
    $('loginScreen').style.display = 'none';
    startApp(result.user);
  } catch (error) {
    setResult('loginStatus', error.message, 'er');
    button.disabled = false;
  }
}

async function logout() {
  await api('/api/auth/logout', { method: 'POST' }).catch(() => {});
  location.reload();
}

/* ── app shell ───────────────────────────────────────────────── */
function startApp(user) {
  state.user = user;
  $('loginScreen').style.display = 'none';
  $('wizard').style.display = 'none';
  $('nav').style.display = 'flex';

  const admin = user.role === 'admin';
  $('navLibrary').style.display = admin ? '' : 'none';
  $('navConfig').style.display = admin ? '' : 'none';

  const badge = $('userBadge');
  badge.style.display = 'flex';
  if (user.thumb) {
    $('userThumb').src = user.thumb;
    $('userThumb').style.display = 'block';
  } else {
    $('userInitial').textContent = (user.username || '?')[0].toUpperCase();
    $('userInitial').style.display = 'flex';
  }
  $('userMenuName').textContent = user.username;
  $('userMenuRole').textContent = user.role;

  nav('home');
  loadHome();
  refreshInLibrary();
}

function nav(page) {
  if ((page === 'config' || page === 'library') && state.user?.role !== 'admin') return;
  state.page = page;
  els('.ni').forEach((b) => b.classList.toggle('on', b.dataset.page === page));
  els('.page').forEach((p) => { p.style.display = 'none'; });
  const target = $('p' + page.charAt(0).toUpperCase() + page.slice(1));
  if (target) target.style.display = 'block';
  window.scrollTo(0, 0);

  if (page === 'calendar') loadCalendar(false);
  if (page === 'library') loadLibrary();
  if (page === 'config') loadConfig();

  // The hero rotation is only worth running while it's on screen.
  if (page === 'home') startHeroRotation(); else stopHeroRotation();
  if (page !== 'config') stopRepairPolling();
}

function toggleUserMenu(event) {
  event.stopPropagation();
  const menu = $('userMenu');
  if (menu.style.display === 'block') { menu.style.display = 'none'; return; }
  const rect = $('userBadge').getBoundingClientRect();
  menu.style.display = 'block';
  menu.style.top = `${rect.bottom + 10}px`;
  menu.style.right = `${Math.max(12, window.innerWidth - rect.right)}px`;
}

document.addEventListener('click', () => { $('userMenu').style.display = 'none'; });
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    closeStreams(); closeModal(); $('userMenu').style.display = 'none';
  }
});

/* ── home ────────────────────────────────────────────────────── */
async function loadHome() {
  skeletons('rowMovies');
  skeletons('rowSeries');
  const [movies, series] = await Promise.all([
    api('/api/catalog/movie').catch(() => ({ metas: [] })),
    api('/api/catalog/series').catch(() => ({ metas: [] })),
  ]);
  renderRow('rowMovies', movies.metas, 'movie');
  renderRow('rowSeries', series.metas, 'series');

  state.hero = (movies.metas || []).filter((m) => m.background).slice(0, 5);
  if (state.hero.length) {
    renderHeroDots();
    setHero(0);
    startHeroRotation();
  }
}

function skeletons(id, count = 8) {
  $(id).innerHTML = Array.from({ length: count }, () =>
    '<div class="card"><div class="skel" style="width:138px;height:207px"></div></div>').join('');
}

function renderRow(id, metas, kind) {
  const node = $(id);
  if (!metas || !metas.length) {
    node.innerHTML = '<div class="hint">Nothing to show right now.</div>';
    return;
  }
  node.innerHTML = metas.slice(0, 20).map((m) => cardHtml(m, kind)).join('');
}

function cardHtml(meta, kind) {
  const type = meta.type || kind;
  const inLib = state.inLibrary.has(meta.imdb_id || meta.id);
  const rating = meta.imdbRating ? `<span class="crating">${escapeHtml(meta.imdbRating)}</span>` : '';
  return `
    <button class="card${inLib ? ' inlib' : ''}" onclick="openModal('${escapeHtml(meta.id)}','${type}')">
      <div class="cposter">
        ${meta.poster ? `<img src="${escapeHtml(meta.poster)}" alt="" loading="lazy"/>` : ''}
        ${rating}<span class="ccheck">✓</span>
      </div>
      <div class="cname">${escapeHtml(meta.name || '')}</div>
      <div class="cyear">${escapeHtml(meta.releaseInfo || meta.year || '')}</div>
    </button>`;
}

function renderHeroDots() {
  $('heroDots').innerHTML = state.hero.map((_, i) =>
    `<button class="hero-dot${i === 0 ? ' on' : ''}" onclick="setHero(${i})" aria-label="Slide ${i + 1}"></button>`
  ).join('');
}

function setHero(index) {
  const meta = state.hero[index];
  if (!meta) return;
  state.heroIndex = index;
  $('heroBg').style.backgroundImage = `url('${meta.background}')`;
  $('heroTitle').textContent = meta.name || '';
  $('heroDesc').textContent = meta.description || '';
  $('heroMeta').innerHTML = [
    meta.releaseInfo ? escapeHtml(meta.releaseInfo) : '',
    meta.imdbRating ? `<span class="hero-rating">${escapeHtml(meta.imdbRating)}</span>` : '',
    meta.runtime ? escapeHtml(meta.runtime) : '',
  ].filter(Boolean).join(' ');
  els('.hero-dot').forEach((d, i) => d.classList.toggle('on', i === index));
}

function startHeroRotation() {
  stopHeroRotation();
  if (state.hero.length < 2) return;
  state.heroTimer = setInterval(() => {
    setHero((state.heroIndex + 1) % state.hero.length);
  }, 8000);
}

function stopHeroRotation() {
  if (state.heroTimer) { clearInterval(state.heroTimer); state.heroTimer = null; }
}

function heroOpen() {
  const meta = state.hero[state.heroIndex];
  if (meta) openModal(meta.id, meta.type || 'movie');
}

/* ── search ──────────────────────────────────────────────────── */
function setSearchKind(kind) {
  state.searchKind = kind;
  els('.srch-tab').forEach((b) => b.classList.toggle('on', b.dataset.kind === kind));
  doSearch($('srchInput').value);
}

function onSearchInput(value) {
  clearTimeout(state.searchTimer);
  state.searchTimer = setTimeout(() => doSearch(value), 320);
}

async function doSearch(query) {
  const trimmed = (query || '').trim();
  if (trimmed.length < 2) {
    $('srchStatus').textContent = '';
    $('srchGrid').innerHTML =
      '<div class="empty"><div class="empty-title">Search for something to add</div>' +
      '<div class="empty-sub">Same catalogue AIOStreams searches against</div></div>';
    return;
  }
  $('srchStatus').textContent = 'Searching…';
  try {
    const result = await api(
      `/api/search?q=${encodeURIComponent(trimmed)}&kind=${state.searchKind}`);
    const metas = result.metas || [];
    $('srchStatus').textContent = metas.length
      ? `${metas.length} result${metas.length === 1 ? '' : 's'}`
      : '';
    $('srchGrid').innerHTML = metas.length
      ? metas.map((m) => cardHtml(m, m.type)).join('')
      : '<div class="empty"><div class="empty-title">Nothing found</div>' +
        '<div class="empty-sub">Try a shorter or differently spelled title</div></div>';
  } catch (error) {
    $('srchStatus').textContent = error.message;
    $('srchGrid').innerHTML = '';
  }
}

/* ── detail modal ────────────────────────────────────────────── */
async function openModal(imdbId, kind) {
  state.seasons = new Set();
  $('modal').classList.add('open');
  $('modalTitle').textContent = 'Loading…';
  $('modalMeta').textContent = '';
  $('modalOverview').textContent = '';
  $('modalSeasons').style.display = 'none';
  $('modalPending').style.display = 'none';
  $('modalWatch').checked = false;
  $('modalAdd').style.display = '';
  $('modalAdd').disabled = true;

  try {
    const result = await api(`/api/meta/${kind}/${imdbId}`);
    state.modal = { ...result, imdbId, kind };
    const meta = result.meta;

    $('modalHero').style.backgroundImage = meta.background ? `url('${meta.background}')` : '';
    $('modalTitle').textContent = meta.name || imdbId;
    $('modalMeta').textContent = [
      meta.releaseInfo || meta.year, meta.runtime,
      meta.imdbRating ? `★ ${meta.imdbRating}` : '',
      (meta.genres || []).slice(0, 3).join(', '),
    ].filter(Boolean).join(' · ');
    $('modalOverview').textContent = meta.description || '';

    const button = $('modalAdd');
    button.disabled = state.user?.role !== 'admin';

    if (kind === 'series') {
      renderSeasonPicker(result.seasons || [], result.wanted_seasons || []);
      $('modalWatch').checked = !!result.watching;
      button.textContent = 'Add selected seasons';
      if ((result.wanted_seasons || []).length) {
        showPending('Waiting on season ' + result.wanted_seasons.join(', ') +
                    ' — they\'ll be added as soon as they start airing.');
      }
    } else if (result.pending) {
      showPending("Already requested. It isn't available yet, so it's being " +
                  'retried automatically until it is.');
      button.textContent = 'Requested';
      button.disabled = true;
    } else {
      button.textContent = result.in_library ? 'Already in your library' : 'Add to Plex';
      button.disabled = button.disabled || result.in_library;
    }
  } catch (error) {
    $('modalTitle').textContent = 'Could not load that title';
    $('modalOverview').textContent = error.message;
  }
}

function showPending(message) {
  const node = $('modalPending');
  node.textContent = message;
  node.style.display = 'block';
}

function renderSeasonPicker(seasons, wanted) {
  // Always shown for a series, even with no seasons listed — that's the
  // case where someone wants to register interest in a show that has
  // been renewed but not yet scheduled, and hiding the picker would
  // hide the only control that does it.
  $('modalSeasons').style.display = 'block';
  const wantedSet = new Set(wanted || []);
  $('seasonPicker').innerHTML = seasons.length
    ? seasons.map((s) => {
        const complete = s.total > 0 && s.have >= s.total;
        const upcoming = wantedSet.has(s.season) || s.total === 0;
        const label = upcoming
          ? 'Not aired yet — already requested'
          : `${s.have} of ${s.total} episodes`;
        return `<button class="season-btn${complete ? ' have' : ''}${upcoming ? ' upcoming' : ''}"
          data-season="${s.season}" onclick="toggleSeason(${s.season})"
          title="${escapeHtml(label)}">Season ${s.season}</button>`;
      }).join('')
    : '<span class="hint" style="margin:0">No seasons listed yet.</span>';
}

function toggleSeason(number) {
  if (state.seasons.has(number)) state.seasons.delete(number);
  else state.seasons.add(number);
  els('.season-btn').forEach((b) => {
    b.classList.toggle('on', state.seasons.has(Number(b.dataset.season)));
  });
}

function closeModal() {
  $('modal').classList.remove('open');
}

async function modalAdd() {
  if (!state.modal) return;
  const { imdbId, kind } = state.modal;
  const button = $('modalAdd');
  const original = button.textContent;
  button.disabled = true;
  button.textContent = 'Searching…';

  const body = { imdb_id: imdbId, kind };
  if (kind === 'series') {
    body.watch_for_new_seasons = $('modalWatch').checked;
    if (!state.seasons.size && !body.watch_for_new_seasons) {
      toast('Pick a season, or turn on new-season tracking', 'er');
      button.disabled = false;
      button.textContent = original;
      return;
    }
    if (state.seasons.size) body.seasons = Array.from(state.seasons);
  }

  try {
    const result = await api('/api/add', { method: 'POST', body: JSON.stringify(body) });
    if (kind === 'series') {
      const bits = [];
      if (result.added) bits.push(`${result.added} episode${result.added === 1 ? '' : 's'}`);
      if (result.waiting) bits.push(`${result.waiting} waiting on a source`);
      if ((result.upcoming_seasons || []).length) {
        bits.push(`season ${result.upcoming_seasons.join(', ')} not aired yet`);
      }
      if (result.watching) bits.push('tracking new seasons');
      toast(`${result.title} — ${bits.join(', ') || 'nothing new'}`,
            result.added ? 'ok' : 'in', 5200);
    } else if (result.pending) {
      // Not a failure. It's on order, and the sweep will keep trying.
      toast(`${result.title} requested — ${result.reason}`, 'in', 6000);
      button.textContent = 'Requested';
      setTimeout(closeModal, 1400);
      return;
    } else {
      toast(`Added ${result.title} — ${result.entries.length} file` +
            `${result.entries.length === 1 ? '' : 's'}`, 'ok');
    }
    button.textContent = 'Added';
    state.inLibrary.add(imdbId);
    setTimeout(closeModal, 900);
  } catch (error) {
    toast(error.message, 'er', 6000);
    button.disabled = false;
    button.textContent = original;
  }
}

async function refreshInLibrary() {
  if (state.user?.role !== 'admin') return;
  try {
    const result = await api('/api/library?page_size=200');
    state.inLibrary = new Set((result.items || []).map((i) => i.imdb_id));
  } catch { /* a stale in-library marker is cosmetic */ }
}

/* ── calendar ────────────────────────────────────────────────── */
async function loadCalendar(refresh) {
  const cal = state.calendar;
  if (!refresh && cal.loaded) { renderCalendar(); return; }
  $('calGrid').innerHTML = '<div class="hint">Loading…</div>';
  try {
    // The window is wide enough to cover a month either side of the one
    // being viewed, so paging through months doesn't refetch each time.
    const r = await api(`/api/calendar?days_back=60&days_ahead=120${refresh ? '&refresh=true' : ''}`);
    cal.entries = r.entries || [];
    cal.loaded = true;
    renderCalStale(r);
    renderCalMissing(r.unavailable || []);
    renderCalendar();
  } catch (error) {
    $('calGrid').innerHTML = `<div class="hint">${escapeHtml(error.message)}</div>`;
  }
}

function renderCalStale(payload) {
  const node = $('calStale');
  const age = payload.oldest_meta_age;
  // Only worth saying when it's old enough to actually mislead. A
  // calendar built from week-old metadata shows week-old dates however
  // recently the page loaded, and nothing else on screen says so.
  if (!age || age < 86400) { node.style.display = 'none'; return; }
  node.style.display = 'block';
  node.textContent = `Some of these dates come from metadata last checked ${when(
    Date.now() / 1000 - age)}. Use "Check for changes" to refetch.`;
}

function renderCalMissing(rows) {
  const node = $('calMissing');
  if (!rows.length) { node.style.display = 'none'; return; }
  node.style.display = 'block';
  const names = rows.slice(0, 4).map((r) => escapeHtml(r.title || r.imdb_id)).join(', ');
  node.innerHTML = `Couldn't load ${rows.length} title${rows.length === 1 ? '' : 's'} ` +
    `(${names}${rows.length > 4 ? ', …' : ''}), so anything of theirs is missing below.`;
}

function calFiltered() {
  const { entries, filter } = state.calendar;
  if (filter === 'episodes') return entries.filter((e) => e.kind === 'episode');
  if (filter === 'movies') return entries.filter((e) => e.kind === 'movie');
  if (filter === 'missing') return entries.filter((e) => !e.in_library);
  if (filter === 'requested') return entries.filter((e) => e.requested);
  return entries;
}

function setCalFilter(value) {
  state.calendar.filter = state.calendar.filter === value ? 'all' : value;
  renderCalendar();
}

function toggleCalView() {
  const cal = state.calendar;
  cal.view = cal.view === 'month' ? 'list' : 'month';
  $('calViewBtn').textContent = cal.view === 'month' ? 'List view' : 'Month view';
  renderCalendar();
}

function calShiftMonth(delta) {
  const cal = state.calendar;
  cal.month = new Date(cal.month.getFullYear(), cal.month.getMonth() + delta, 1);
  renderCalendar();
}

function renderCalendar() {
  const cal = state.calendar;
  const rows = calFiltered();

  const counts = {
    all: cal.entries.length,
    episodes: cal.entries.filter((e) => e.kind === 'episode').length,
    movies: cal.entries.filter((e) => e.kind === 'movie').length,
    missing: cal.entries.filter((e) => !e.in_library).length,
    requested: cal.entries.filter((e) => e.requested).length,
  };
  $('calChips').innerHTML = [
    ['all', `Everything (${counts.all})`],
    ['episodes', `Episodes (${counts.episodes})`],
    ['movies', `Films (${counts.movies})`],
    ['missing', `Not here yet (${counts.missing})`],
    ['requested', `On order (${counts.requested})`],
  ].filter(([key]) => key === 'all' || counts[key])
   .map(([key, label]) => `<button class="fchip${cal.filter === key ? ' on' : ''}"
      onclick="setCalFilter('${key}')">${escapeHtml(label)}</button>`).join('');

  $('calMonth').style.display = cal.view === 'month' ? 'block' : 'none';
  $('calList').style.display = cal.view === 'list' ? 'block' : 'none';
  if (cal.view === 'month') renderCalMonth(rows); else renderCalList(rows);
}

function renderCalMonth(rows) {
  const cal = state.calendar;
  const year = cal.month.getFullYear();
  const month = cal.month.getMonth();
  $('calMonthLabel').textContent = cal.month.toLocaleDateString(undefined,
    { month: 'long', year: 'numeric' });

  // Start the week on Monday, which is how most of the world reads a
  // schedule, and label the columns from real dates so they follow the
  // browser's locale rather than being hardcoded English.
  const weekdays = [];
  for (let i = 0; i < 7; i += 1) {
    const day = new Date(2024, 0, 1 + i);   // 1 Jan 2024 was a Monday
    weekdays.push(day.toLocaleDateString(undefined, { weekday: 'short' }));
  }
  $('calWeekdays').innerHTML = weekdays
    .map((d) => `<div class="cal-weekday">${escapeHtml(d)}</div>`).join('');

  const byDate = {};
  rows.forEach((e) => { (byDate[e.date] ||= []).push(e); });

  const first = new Date(year, month, 1);
  const offset = (first.getDay() + 6) % 7;      // Monday = 0
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const today = new Date().toISOString().slice(0, 10);

  const cells = [];
  for (let i = 0; i < offset; i += 1) cells.push('<div class="cal-cell blank"></div>');

  for (let day = 1; day <= daysInMonth; day += 1) {
    const key = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const items = byDate[key] || [];
    const shown = items.slice(0, 2).map((e) => {
      const label = e.kind === 'movie'
        ? e.title
        : `${e.title} ${String(e.season).padStart(2, '0')}x${String(e.episode).padStart(2, '0')}`;
      const cls = e.in_library ? 'inlib' : e.kind === 'movie' ? 'movie' : '';
      return `<span class="cal-pill ${cls}">${escapeHtml(label)}</span>`;
    }).join('');
    const more = items.length > 2
      ? `<span class="cal-cellmore">+${items.length - 2} more</span>` : '';
    cells.push(`
      <button class="cal-cell${cal.selected === key ? ' selected' : ''}${items.length ? ' has-items' : ''}"
              onclick="calSelectDay('${key}')"
              aria-label="${day}, ${items.length} item${items.length === 1 ? '' : 's'}">
        <span class="cal-cellnum${key === today ? ' today' : ''}">${day}</span>
        ${shown}${more}
      </button>`);
  }

  $('calGrid').innerHTML = cells.join('');
  renderCalDetail(byDate);
}

function calSelectDay(key) {
  state.calendar.selected = key;
  renderCalendar();
}

function renderCalDetail(byDate) {
  const key = state.calendar.selected;
  const items = (byDate || {})[key] || [];
  $('calDetail').innerHTML = `
    <div class="cal-detail">
      <div class="cal-detail-date">${escapeHtml(formatDate(key))}</div>
      ${items.length
        ? items.map(calEntryHtml).join('')
        : '<div class="hint" style="margin:0">Nothing scheduled.</div>'}
    </div>`;
}

function renderCalList(rows) {
  if (!rows.length) {
    $('calList').innerHTML =
      '<div class="empty"><div class="empty-title">Nothing scheduled</div>' +
      '<div class="empty-sub">Add a film or series and its dates appear here</div></div>';
    return;
  }
  const byDate = {};
  rows.forEach((e) => { (byDate[e.date] ||= []).push(e); });
  const today = new Date().toISOString().slice(0, 10);

  $('calList').innerHTML = Object.keys(byDate).sort().map((date) => `
    <div class="cal-day">
      <div class="cal-day-label${date === today ? ' today' : ''}">
        ${date === today ? 'Today' : escapeHtml(formatDate(date))}
      </div>
      ${byDate[date].map(calEntryHtml).join('')}
    </div>`).join('');
}

function formatDate(iso) {
  return new Date(iso + 'T00:00:00').toLocaleDateString(undefined,
    { weekday: 'long', day: 'numeric', month: 'long' });
}

function calEntryHtml(entry) {
  const sub = entry.kind === 'movie'
    ? `Film${entry.year ? ' · ' + entry.year : ''}`
    : `S${String(entry.season).padStart(2, '0')}E${String(entry.episode).padStart(2, '0')}` +
      `${entry.episode_title ? ' · ' + escapeHtml(entry.episode_title) : ''}`;

  const status = entry.in_library
    ? '<span class="pill ok">In library</span>'
    : entry.requested
      ? '<span class="pill info">On order</span>'
      : entry.future
        ? '<span class="pill warn">Upcoming</span>'
        : '<span class="pill warn">Not added</span>';

  // Say which date this is. For a film it's the cinema date, and a
  // digital copy can be weeks behind it — showing the two identically
  // would imply a precision that isn't there.
  const dateNote = entry.date_type === 'cinema release'
    ? '<span class="cal-badge">cinema date</span>' : '';

  const action = entry.in_library ? '' :
    `<button class="btn bg2" onclick="event.stopPropagation();calAdd('${escapeHtml(entry.imdb_id)}','${entry.kind}',${entry.season || 'null'})">
       ${entry.kind === 'movie' ? 'Add' : 'Add season'}
     </button>`;

  return `
    <div class="cal-entry${entry.in_library ? ' inlib' : ''}${entry.future ? ' future' : ''}"
         onclick="openModal('${escapeHtml(entry.imdb_id)}','${entry.kind === 'movie' ? 'movie' : 'series'}')"
         style="cursor:pointer">
      ${entry.poster
        ? `<img class="cal-poster" src="${escapeHtml(entry.poster)}" alt="" loading="lazy"/>`
        : '<div class="cal-poster"></div>'}
      <div class="grow">
        <div style="font-size:14px;font-weight:700">${escapeHtml(entry.title)}</div>
        <div style="font-size:12px;color:var(--mut)">${sub}</div>
      </div>
      ${dateNote}${status}${action}
    </div>`;
}

async function calAdd(imdbId, kind, season) {
  if (state.user?.role !== 'admin') { toast('Only an admin can add titles', 'er'); return; }
  const body = { imdb_id: imdbId, kind: kind === 'movie' ? 'movie' : 'series' };
  if (kind !== 'movie' && season) body.seasons = [season];
  try {
    const r = await api('/api/add', { method: 'POST', body: JSON.stringify(body) });
    toast(r.pending ? `${r.title} requested — ${r.reason || 'waiting on a source'}`
                    : `Added ${r.title}`, r.pending ? 'in' : 'ok', 5000);
    loadCalendar(false);
    refreshInLibrary();
  } catch (error) {
    toast(error.message, 'er', 5000);
  }
}

/* ── requests ────────────────────────────────────────────────── */
function renderRequests(r) {
  $('sweepBtn').style.display = canEditRequests() ? '' : 'none';
  if (!r) {
    $('reqBody').innerHTML = '<div class="hint">Could not load requests.</div>';
    return;
  }
  const total = r.summary.pending_movies + r.summary.waiting_episodes +
                r.summary.wanted_seasons + r.summary.season_watch;
  if (!total) {
    $('reqBody').innerHTML =
      '<div class="empty"><div class="empty-title">Nothing outstanding</div>' +
      "<div class=\"empty-sub\">Anything that can't be found yet shows up here</div></div>";
    return;
  }
  $('reqBody').innerHTML = [
    reqSection('Films not out yet', r.pending_movies, pendingMovieHtml,
               'Retried automatically until a copy turns up.'),
    reqSection('Seasons not started', r.wanted_seasons, wantedSeasonHtml,
               'Registered before anything aired. Added as soon as the first episode does.'),
    reqSection('Episodes waiting on a source', r.waiting_episodes, waitingEpisodeHtml,
               'Aired already, but nothing has been uploaded yet.'),
    reqSection('Shows tracked for new seasons', r.season_watch, watchedShowHtml,
               'Each new season is registered on its own, indefinitely.'),
  ].filter(Boolean).join('');
}

function reqSection(title, rows, render, blurb) {
  if (!rows || !rows.length) return '';
  return `
    <section style="margin-bottom:28px">
      <div class="cal-day-label">${escapeHtml(title)} (${rows.length})</div>
      <div class="hint" style="margin:-4px 0 12px;font-size:12px">${escapeHtml(blurb)}</div>
      ${rows.map(render).join('')}
    </section>`;
}

// Viewing requests is open to everyone — someone who asked for
// something should be able to see where it got to — but changing them
// isn't. Hide the controls rather than letting them fail with a 403.
const canEditRequests = () => state.user?.role === 'admin';

function reqCancelBtn(path, label) {
  if (!canEditRequests()) return '';
  return `<button class="btn bdanger" onclick="cancelRequest('${path}')">${label}</button>`;
}

function reqPoster(poster) {
  return poster
    ? `<img class="cal-poster" src="${escapeHtml(poster)}" alt="" loading="lazy"/>`
    : '<div class="cal-poster"></div>';
}

function pendingMovieHtml(row) {
  const attempts = row.attempts
    ? `${row.attempts} attempt${row.attempts === 1 ? '' : 's'}, last ${when(row.last_attempt_at)}`
    : 'not tried yet';
  return `
    <div class="cal-entry">
      ${reqPoster(row.poster)}
      <div class="grow">
        <div style="font-size:14px;font-weight:700">
          ${escapeHtml(row.title)}${row.year ? ' (' + row.year + ')' : ''}
        </div>
        <div style="font-size:12px;color:var(--mut)">
          ${escapeHtml(row.last_reason || 'Waiting for a source')} · ${escapeHtml(attempts)}
        </div>
      </div>
      ${reqCancelBtn('/api/requests/movie/' + escapeHtml(row.imdb_id), 'Cancel')}
    </div>`;
}

function wantedSeasonHtml(row) {
  return `
    <div class="cal-entry future">
      ${reqPoster(row.poster)}
      <div class="grow">
        <div style="font-size:14px;font-weight:700">${escapeHtml(row.title || row.imdb_id)}</div>
        <div style="font-size:12px;color:var(--mut)">
          Season ${row.season} · requested ${when(row.requested_at)}
        </div>
      </div>
      ${reqCancelBtn('/api/requests/season/' + escapeHtml(row.imdb_id) + '/' + row.season, 'Cancel')}
    </div>`;
}

function waitingEpisodeHtml(row) {
  const code = `S${String(row.season).padStart(2, '0')}E${String(row.episode).padStart(2, '0')}`;
  return `
    <div class="cal-entry">
      ${reqPoster(row.poster)}
      <div class="grow">
        <div style="font-size:14px;font-weight:700">${escapeHtml(row.title || row.imdb_id)}</div>
        <div style="font-size:12px;color:var(--mut)">
          ${code} · waiting since ${when(row.first_missed_at)} · ${row.attempts} check${row.attempts === 1 ? '' : 's'}
        </div>
      </div>
      ${reqCancelBtn('/api/requests/episode/' + escapeHtml(row.imdb_id) + '/' +
                     row.season + '/' + row.episode, 'Stop')}
    </div>`;
}

function watchedShowHtml(row) {
  const have = row.seasons && row.seasons.length
    ? `has season ${row.seasons.join(', ')}`
    : 'nothing in the library yet';
  const next = row.last_registered_season
    ? ` · watching for season ${row.last_registered_season}`
    : '';
  return `
    <div class="cal-entry inlib">
      ${reqPoster(row.poster)}
      <div class="grow">
        <div style="font-size:14px;font-weight:700">${escapeHtml(row.title || row.imdb_id)}</div>
        <div style="font-size:12px;color:var(--mut)">${escapeHtml(have)}${escapeHtml(next)}</div>
      </div>
      ${reqCancelBtn('/api/requests/watch/' + escapeHtml(row.imdb_id), 'Stop tracking')}
    </div>`;
}

async function cancelRequest(path) {
  try {
    await api(path, { method: 'DELETE' });
    toast('Request cancelled', 'ok');
    loadLibrary();
  } catch (error) {
    toast(error.message, 'er');
  }
}

async function sweepRequests() {
  const button = $('sweepBtn');
  button.disabled = true;
  button.textContent = 'Checking…';
  try {
    const r = await api('/api/requests/sweep', { method: 'POST' });
    const added = (r.episodes && r.episodes.added) || 0;
    const films = (r.movies && r.movies.resolved) || 0;
    toast(added || films
      ? `Found ${added} episode(s) and ${films} film(s)`
      : 'Nothing new yet', added || films ? 'ok' : 'in');
    loadLibrary();
  } catch (error) {
    toast(error.message, 'er');
  } finally {
    button.disabled = false;
    button.textContent = 'Check now';
  }
}

/* ── library ─────────────────────────────────────────────────── */
function onLibFilter(value) {
  state.library.filter = value;
  state.library.page = 1;
  clearTimeout(state.searchTimer);
  state.searchTimer = setTimeout(loadLibrary, 300);
}

function setLibFilter(key, value) {
  state.library[key] = value;
  state.library.page = 1;
  loadLibrary();
}

async function loadLibrary() {
  const { page, filter, kind } = state.library;
  const stateFilter = state.library.state;
  const onRequests = kind === 'requests';

  $('libRequests').style.display = onRequests ? 'block' : 'none';
  $('libMain').style.display = onRequests ? 'none' : 'block';

  try {
    // Counts for both panes come back together, so the chip showing how
    // many things are outstanding is correct whichever pane is open.
    const [result, requests] = await Promise.all([
      api(`/api/library?page=${page}&q=${encodeURIComponent(filter)}` +
          `&kind=${onRequests ? 'all' : kind}&state_filter=${stateFilter}`),
      api('/api/requests').catch(() => null),
    ]);

    if (requests) {
      const s = requests.summary;
      state.library.requestCount =
        s.pending_movies + s.waiting_episodes + s.wanted_seasons;
    }
    renderLibChips(result.counts);

    if (onRequests) {
      renderRequests(requests);
      return;
    }
    renderLibGrid(result.items);
    renderPager('libPager', result.page, result.pages, (p) => {
      state.library.page = p; loadLibrary();
    });
  } catch (error) {
    $('libGrid').innerHTML = `<div class="hint">${escapeHtml(error.message)}</div>`;
  }
}

function renderLibChips(counts) {
  const chips = [
    ['kind', 'all', `Everything (${counts.total})`],
    ['kind', 'movies', `Films (${counts.movies})`],
    ['kind', 'series', `Series (${counts.episodes})`],
    ['state', 'activated', `Played (${counts.activated})`],
    ['state', 'missing', `Needs repair (${counts.missing})`],
    ['kind', 'requests', `On order (${state.library.requestCount})`],
  ];
  $('libChips').innerHTML = chips.map(([key, value, label]) => {
    const active = state.library[key] === value;
    const next = active && key === 'state' ? 'all' : value;
    return `<button class="fchip${active ? ' on' : ''}"
      onclick="setLibFilter('${key}','${next}')">${escapeHtml(label)}</button>`;
  }).join('');
}

function renderLibGrid(items) {
  if (!items.length) {
    $('libGrid').innerHTML =
      '<div class="empty"><div class="empty-title">Nothing here yet</div>' +
      '<div class="empty-sub">Add something from Search and it appears in Plex</div></div>';
    return;
  }
  $('libGrid').innerHTML = `<div class="grid">${items.map(libCardHtml).join('')}</div>`;
}

function libCardHtml(item) {
  const detail = item.media_type === 'series'
    ? `${item.files} file${item.files === 1 ? '' : 's'} · ${item.seasons.length} season${item.seasons.length === 1 ? '' : 's'}`
    : item.qualities.join(' + ').toUpperCase();
  const badge = item.missing
    ? `<span class="pill er">${item.missing} to repair</span>`
    : item.activated
      ? `<span class="pill ok">${item.activated} played</span>`
      : '<span class="pill warn">Not played</span>';
  return `
    <button class="card" onclick="openLibraryDetail('${escapeHtml(item.imdb_id)}')">
      <div class="cposter">
        ${item.poster ? `<img src="${escapeHtml(item.poster)}" alt="" loading="lazy"/>` : ''}
      </div>
      <div class="cname">${escapeHtml(item.title)}</div>
      <div class="cyear">${escapeHtml(detail)}</div>
      <div style="margin-top:5px">${badge}</div>
    </button>`;
}

async function openLibraryDetail(imdbId, keepPage) {
  if (!keepPage) state.detail = { imdbId, page: 1, season: null, quality: 'all' };
  state.detail.imdbId = imdbId;

  $('modal').classList.add('open');
  $('modalAdd').style.display = 'none';
  $('modalSeasons').style.display = 'none';
  $('modalPending').style.display = 'none';
  if (!keepPage) {
    $('modalTitle').textContent = 'Loading…';
    $('modalMeta').textContent = '';
    $('modalOverview').innerHTML = '';
  }

  const d = state.detail;
  const params = new URLSearchParams({ page: d.page, quality: d.quality });
  if (d.season !== null) params.set('season', d.season);

  try {
    const r = await api(`/api/library/${imdbId}?${params}`);
    $('modalHero').style.backgroundImage = r.poster ? `url('${r.poster}')` : '';
    $('modalTitle').textContent = r.title;
    $('modalMeta').textContent =
      `${r.total} file${r.total === 1 ? '' : 's'} shown of ${r.counts.all}`;

    const chips = [['quality', 'all', `All (${r.counts.all})`]];
    if (r.counts.hd) chips.push(['quality', 'hd', `HD (${r.counts.hd})`]);
    if (r.counts['4k']) chips.push(['quality', '4k', `4K (${r.counts['4k']})`]);
    (r.seasons || []).forEach((n) => chips.push(['season', n, `Season ${n}`]));

    const chipHtml = chips.map(([key, value, label]) => {
      const active = key === 'season'
        ? d.season === value
        : d[key] === value;
      // Clicking an active season chip clears it, so there's always a
      // way back to every season without hunting for an "all" chip.
      const next = key === 'season' && active ? 'null' : JSON.stringify(value);
      return `<button class="fchip${active ? ' on' : ''}"
        onclick="setDetailFilter('${key}',${next})">${escapeHtml(label)}</button>`;
    }).join('');

    $('modalOverview').innerHTML = `
      <div class="filter-chips">${chipHtml}</div>
      <div>${r.entries.map(entryRowHtml).join('') ||
             '<div class="hint" style="margin:0">Nothing matches that filter.</div>'}</div>
      <div class="pager" id="detailPager"></div>
      <div class="actions" style="margin-top:16px">
        <button class="btn bg2" onclick="openStreams('${escapeHtml(imdbId)}','${r.media_type}',null,null)">
          Find other versions
        </button>
        <button class="btn bdanger" onclick="removeTitle('${escapeHtml(imdbId)}')">
          Remove this title
        </button>
      </div>`;

    renderPager('detailPager', r.page, r.pages, (pageNumber) => {
      state.detail.page = pageNumber;
      openLibraryDetail(imdbId, true);
    });
  } catch (error) {
    $('modalTitle').textContent = 'Could not load that title';
    $('modalOverview').textContent = error.message;
  }
}

function setDetailFilter(key, value) {
  state.detail[key] = value;
  state.detail.page = 1;
  openLibraryDetail(state.detail.imdbId, true);
}

function entryRowHtml(entry) {
  const badge = entry.state === 'missing'
    ? '<span class="pill er">Needs repair</span>'
    : entry.activated
      ? '<span class="pill ok">Played</span>'
      : '<span class="pill warn">Ready</span>';
  const pin = entry.pinned ? '<span class="pill info">Chosen by hand</span>' : '';
  const kind = entry.season ? 'series' : 'movie';

  return `
    <div class="rowitem">
      <div class="grow">
        <div style="font-size:13px;font-weight:700">
          ${escapeHtml(entry.name)} · ${entry.quality.toUpperCase()}
        </div>
        <div style="font-size:11px;color:var(--mut);overflow-wrap:anywhere">
          ${entry.source ? escapeHtml(entry.source) : 'No stream yet'}
        </div>
        <div style="font-size:11px;color:var(--mut)">
          ${bytes(entry.size)}${entry.service ? ' · ' + escapeHtml(entry.service) : ''}
          · repaired ${when(entry.last_repair_at)}
        </div>
      </div>
      ${badge}${pin}
      <button class="btn bg2"
        onclick="openStreams('${escapeHtml(state.detail.imdbId)}','${kind}',${entry.season || 'null'},${entry.episode || 'null'})">
        Change stream
      </button>
      <button class="btn bg2" onclick="repairEntry('${entry.entry_id}',this)">Repair</button>
    </div>`;
}

/* ── stream picker ───────────────────────────────────────────── */
async function openStreams(imdbId, kind, season, episode) {
  state.streams = { token: null, rows: [], filter: 'all',
                    ctx: { imdbId, kind, season, episode } };
  $('streamModal').classList.add('open');
  $('streamTitle').textContent = 'Finding versions…';
  $('streamMeta').textContent = '';
  $('streamChips').innerHTML = '';
  $('streamCurrent').innerHTML = '';
  $('streamList').innerHTML = '<div class="hint">Searching AIOStreams…</div>';

  // A movie has no season, but an episode picker needs one. If the
  // caller didn't give us one for a series, ask for the first episode
  // the library holds rather than failing.
  if (kind === 'series' && (season === null || episode === null)) {
    try {
      const lib = await api(`/api/library/${imdbId}?page_size=1`);
      const first = lib.entries[0];
      if (first && first.season) { season = first.season; episode = first.episode; }
    } catch { /* handled by the error below */ }
    if (season === null || episode === null) {
      $('streamList').innerHTML =
        '<div class="hint">Open a specific episode to change its stream.</div>';
      return;
    }
    state.streams.ctx = { imdbId, kind, season, episode };
  }

  const params = new URLSearchParams({ imdb_id: imdbId, kind, quality: 'all' });
  if (season !== null) params.set('season', season);
  if (episode !== null) params.set('episode', episode);

  try {
    const r = await api(`/api/streams?${params}`);
    state.streams.token = r.token;
    state.streams.rows = r.streams;
    state.streams.current = r.current || {};

    const label = r.kind === 'series'
      ? `${r.title} S${String(r.season).padStart(2, '0')}E${String(r.episode).padStart(2, '0')}`
      : r.title;
    $('streamTitle').textContent = label;
    $('streamMeta').textContent =
      `${r.counts.all} version${r.counts.all === 1 ? '' : 's'} · ` +
      `${r.counts.hd} HD · ${r.counts['4k']} 4K`;

    $('streamChips').innerHTML = [
      ['all', `All (${r.counts.all})`],
      ['hd', `HD (${r.counts.hd})`],
      ['4k', `4K (${r.counts['4k']})`],
    ].map(([key, text]) => `<button class="fchip${state.streams.filter === key ? ' on' : ''}"
        onclick="setStreamFilter('${key}')">${escapeHtml(text)}</button>`).join('');

    renderCurrentStreams();
    renderStreamList();
  } catch (error) {
    $('streamTitle').textContent = 'Could not search';
    $('streamList').innerHTML = `<div class="hint">${escapeHtml(error.message)}</div>`;
  }
}

function renderCurrentStreams() {
  const current = state.streams.current || {};
  const rows = Object.keys(current).map((q) => {
    const c = current[q];
    return `<div class="hint" style="margin:0 0 6px">
      <strong>${q.toUpperCase()} in use:</strong>
      ${escapeHtml(c.filename || 'no stream yet')}
      ${c.pinned ? ' (chosen by hand)' : ''}
    </div>`;
  }).join('');
  $('streamCurrent').innerHTML = rows
    ? `<div style="margin-bottom:14px">${rows}</div>` : '';
}

function setStreamFilter(value) {
  state.streams.filter = value;
  els('#streamChips .fchip').forEach((b) => {
    b.classList.toggle('on', b.getAttribute('onclick').includes(`'${value}'`));
  });
  renderStreamList();
}

function renderStreamList() {
  const { rows, filter } = state.streams;
  const shown = filter === 'all' ? rows
    : rows.filter((r) => (filter === '4k' ? r.is_4k : !r.is_4k));

  if (!shown.length) {
    $('streamList').innerHTML =
      `<div class="empty"><div class="empty-title">No ${filter === 'all' ? '' : filter.toUpperCase() + ' '}versions found</div>` +
      '<div class="empty-sub">Nothing your addons can reach right now</div></div>';
    return;
  }
  $('streamList').innerHTML = shown.map(streamRowHtml).join('');
}

function streamRowHtml(row) {
  // Three cache states, not two. A confirmed no and "nobody could tell
  // us" are different things and picking between them is the whole
  // reason someone opens this list.
  const cache = row.cached_verified === true
    ? '<span class="strm-tag cached">Cached</span>'
    : row.cached_verified === false
      ? '<span class="strm-tag uncached">Not cached</span>'
      : row.cached
        ? '<span class="strm-tag unknown">Reported cached</span>'
        : '<span class="strm-tag unknown">Cache unknown</span>';

  const tags = [
    row.resolution
      ? `<span class="strm-tag ${row.is_4k ? 'uhd' : 'res'}">${escapeHtml(row.resolution)}</span>`
      : '',
    row.quality ? `<span class="strm-tag">${escapeHtml(row.quality)}</span>` : '',
    ...(row.hdr || []).map((h) => `<span class="strm-tag">${escapeHtml(h)}</span>`),
    ...(row.audio || []).slice(0, 2).map((a) => `<span class="strm-tag">${escapeHtml(a)}</span>`),
    row.usenet ? '<span class="strm-tag">Usenet</span>' : '',
    cache,
  ].filter(Boolean).join('');

  return `
    <button class="strm${row.current ? ' current' : ''}" onclick="pickStream(${row.index},this)">
      <div class="grow">
        <div class="strm-name">${escapeHtml(row.filename)}</div>
        <div class="strm-sub">
          ${bytes(row.size)}${row.service ? ' · ' + escapeHtml(row.service) : ''}
          ${row.addon ? ' · ' + escapeHtml(row.addon) : ''}
          ${row.current ? ' · in use now' : ''}
        </div>
        <div class="strm-tags">${tags}</div>
      </div>
      <span class="pill ${row.current ? 'ok' : 'info'}">${row.current ? 'In use' : 'Use this'}</span>
    </button>`;
}

async function pickStream(index, button) {
  const original = button.innerHTML;
  button.disabled = true;
  try {
    const r = await api('/api/streams/select', {
      method: 'POST',
      body: JSON.stringify({ token: state.streams.token, index }),
    });
    toast(`Now using this ${r.quality.toUpperCase()} version`, 'ok');
    closeStreams();
    if (state.detail.imdbId) openLibraryDetail(state.detail.imdbId, true);
    refreshInLibrary();
  } catch (error) {
    toast(error.message, 'er', 6000);
    button.disabled = false;
    button.innerHTML = original;
  }
}

function closeStreams() {
  $('streamModal').classList.remove('open');
}

async function repairEntry(entryId, button) {
  button.disabled = true;
  button.textContent = 'Checking…';
  try {
    const result = await api(`/api/entry/${entryId}/repair`, { method: 'POST' });
    if (result.repaired) toast('New link fetched', 'ok');
    else if (result.still_good) toast('That link is still fine', 'ok');
    else if (result.removed) toast('No source found — the file was removed', 'er');
    else toast('No source available right now', 'er');
    button.textContent = 'Repair';
    button.disabled = false;
  } catch (error) {
    toast(error.message, 'er');
    button.textContent = 'Repair';
    button.disabled = false;
  }
}

async function removeTitle(imdbId) {
  if (!confirm('Remove this title and all of its files from the library?')) return;
  try {
    const result = await api(`/api/library/${imdbId}`, { method: 'DELETE' });
    toast(`Removed ${result.removed} file(s)`, 'ok');
    closeModal();
    loadLibrary();
    refreshInLibrary();
  } catch (error) {
    toast(error.message, 'er');
  }
}

function renderPager(id, page, pages, onGo) {
  const node = $(id);
  if (!node) return;
  if (pages <= 1) { node.innerHTML = ''; return; }

  // A window around the current page, so a hundred-page library doesn't
  // render a hundred buttons.
  const numbers = [];
  const from = Math.max(1, page - 2);
  const to = Math.min(pages, page + 2);
  if (from > 1) numbers.push(1);
  if (from > 2) numbers.push('…');
  for (let i = from; i <= to; i += 1) numbers.push(i);
  if (to < pages - 1) numbers.push('…');
  if (to < pages) numbers.push(pages);

  node.innerHTML = [
    `<button class="pagebtn" ${page <= 1 ? 'disabled' : ''} data-go="${page - 1}">‹</button>`,
    ...numbers.map((n) => n === '…'
      ? '<span style="color:var(--mut)">…</span>'
      : `<button class="pagebtn${n === page ? ' on' : ''}" data-go="${n}">${n}</button>`),
    `<button class="pagebtn" ${page >= pages ? 'disabled' : ''} data-go="${page + 1}">›</button>`,
  ].join('');

  els('[data-go]', node).forEach((button) => {
    button.onclick = () => onGo(Number(button.dataset.go));
  });
}

/* ── config ──────────────────────────────────────────────────── */
function switchCfgTab(name) {
  els('.cfgtab').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
  els('.cfgpanel').forEach((p) => p.classList.toggle('on', p.dataset.panel === name));
  if (name === 'users') loadUsers();
  if (name === 'migrate') loadMigrateSettings();
  if (name === 'repair') { loadRepair(); startRepairPolling(); } else stopRepairPolling();
  if (name === 'streams') loadDebrid();
}

async function loadConfig() {
  await Promise.all([loadConnections(), loadSettings()]);
}

async function loadConnections() {
  try {
    const result = await api('/api/config/connections');
    $('cfgAioUrl').value = result.aiostreams.url_set ? result.aiostreams.url : '';
    $('cfgAioUuid').value = result.aiostreams.uuid_set ? result.aiostreams.uuid : '';
    $('cfgPlexUrl').value = result.plex.url_set ? result.plex.url : '';
    $('webhookUrl').value = result.webhook_url;
    $('folderChips').innerHTML = result.library_folders.map((f) =>
      `<span class="chip"><span class="cv">${escapeHtml(f)}</span></span>`).join('');
    $('mountChips').innerHTML = `
      <span class="chip"><span class="cl">Mountpoint</span><span class="cv">${escapeHtml(result.mountpoint)}</span></span>`;
    loadPlexSections(result.library_folders);
  } catch (error) {
    toast(error.message, 'er');
  }
}

async function loadPlexSections(folders) {
  try {
    const result = await api('/api/config/plex/sections');
    const known = new Set();
    (result.sections || []).forEach((s) => (s.paths || []).forEach((p) => known.add(p)));
    const missing = folders.filter((f) => !known.has(f));
    $('sectionStatus').innerHTML = missing.length
      ? `Plex hasn't been pointed at ${missing.length} of these folders yet.`
      : 'All four folders are set up as Plex libraries.';
  } catch {
    $('sectionStatus').textContent = '';
  }
}

async function cfgTestAio() {
  setResult('cfgAioResult', 'Testing…');
  try {
    const result = await api('/api/setup/aiostreams/test', {
      method: 'POST',
      body: JSON.stringify({
        url: $('cfgAioUrl').value.trim(),
        uuid: $('cfgAioUuid').value.trim(),
        password: $('cfgAioPass').value,
      }),
    });
    setResult('cfgAioResult', `Connected. ${result.results} test result(s).`, 'ok');
  } catch (error) {
    setResult('cfgAioResult', error.message, 'er');
  }
}

async function cfgSaveAio() {
  try {
    await api('/api/setup/aiostreams', {
      method: 'POST',
      body: JSON.stringify({
        url: $('cfgAioUrl').value.trim(),
        uuid: $('cfgAioUuid').value.trim(),
        password: $('cfgAioPass').value,
      }),
    });
    $('cfgAioPass').value = '';
    setResult('cfgAioResult', 'Saved.', 'ok');
  } catch (error) {
    setResult('cfgAioResult', error.message, 'er');
  }
}

async function cfgTestPlex() {
  setResult('cfgPlexResult', 'Testing…');
  try {
    const result = await api('/api/setup/plex/test', {
      method: 'POST',
      body: JSON.stringify({
        url: $('cfgPlexUrl').value.trim(), token: $('cfgPlexToken').value,
      }),
    });
    setResult('cfgPlexResult', `Connected to ${result.server}.`, 'ok');
  } catch (error) {
    setResult('cfgPlexResult', error.message, 'er');
  }
}

async function cfgSavePlex() {
  try {
    await api('/api/setup/plex', {
      method: 'POST',
      body: JSON.stringify({
        url: $('cfgPlexUrl').value.trim(), token: $('cfgPlexToken').value,
      }),
    });
    $('cfgPlexToken').value = '';
    setResult('cfgPlexResult', 'Saved.', 'ok');
    loadConnections();
  } catch (error) {
    setResult('cfgPlexResult', error.message, 'er');
  }
}

/* settings */
let settingsCache = {};

async function loadSettings() {
  settingsCache = await api('/api/settings');
  const s = settingsCache;

  $('fuseBlock').value = s.fuse_block_mb;
  $('fuseCache').value = s.fuse_cache_blocks;
  $('fusePrefetch').value = s.fuse_prefetch_ahead;
  $('fuseTimeout').value = s.fuse_read_timeout;
  $('fuseInflight').value = s.fuse_max_inflight;
  $('fuseWait').value = s.fuse_activation_wait;

  $('prefLang').value = s.preferred_language || '';
  $('prefAudio').value = (s.preferred_audio || []).join(', ');
  $('excludeWords').value = (s.exclude_words || []).join(', ');
  $('minSize').value = s.min_size_gb;
  $('maxSize').value = s.max_size_gb;
  $('min4k').value = s.min_4k_sources;
  $('preferSubs').checked = !!s.prefer_subtitles;
  $('preferPacks').checked = !!s.prefer_packs;
  $('allowUsenet').checked = !!s.allow_usenet;
  $('cachedOnly').checked = !!s.cached_only;
  $('dropUnknown').checked = !!s.drop_unknown_cache;
  $('verifyDebrid').checked = !!s.verify_cache_with_debrid;

  $('adDelete').checked = !!s.alldebrid_delete_probes;
  $('adStopOnHit').checked = !!s.alldebrid_stop_on_hit;
  $('adChunk').value = s.alldebrid_probe_chunk;
  $('debridProbe').value = s.debrid_max_probe;

  $('autoEpEnabled').checked = !!s.auto_episodes_enabled;
  $('pendingEnabled').checked = !!s.pending_movies_enabled;
  $('sweepInterval').value = s.auto_episodes_interval_minutes;
  $('epRetryDays').value = s.auto_episodes_retry_days;
  $('mvRetryDays').value = s.pending_movies_retry_days;
  $('digitalDelay').value = s.digital_release_delay_days;
  $('epLookahead').value = s.episode_lookahead;

  $('aioConcurrent').value = s.aiostreams_max_concurrent;
  $('aioInterval').value = s.aiostreams_min_interval_ms;
}

async function saveSettings(patch, savedId) {
  try {
    settingsCache = await api('/api/settings', { method: 'POST', body: JSON.stringify(patch) });
    if (savedId) flashSaved(savedId);
  } catch (error) {
    toast(error.message, 'er');
  }
}

function saveFuse() {
  saveSettings({
    fuse_block_mb: Number($('fuseBlock').value),
    fuse_cache_blocks: Number($('fuseCache').value),
    fuse_prefetch_ahead: Number($('fusePrefetch').value),
    fuse_read_timeout: Number($('fuseTimeout').value),
    fuse_max_inflight: Number($('fuseInflight').value),
    fuse_activation_wait: Number($('fuseWait').value),
  }, 'fuseSaved');
}

function saveStreamPrefs() {
  saveSettings({
    preferred_language: $('prefLang').value.trim(),
    preferred_audio: csvToList($('prefAudio').value),
    exclude_words: csvToList($('excludeWords').value),
    min_size_gb: Number($('minSize').value),
    max_size_gb: Number($('maxSize').value),
    min_4k_sources: Number($('min4k').value),
    prefer_subtitles: $('preferSubs').checked,
    prefer_packs: $('preferPacks').checked,
    allow_usenet: $('allowUsenet').checked,
    cached_only: $('cachedOnly').checked,
    drop_unknown_cache: $('dropUnknown').checked,
  }, 'streamSaved');
}

function saveDebridBehaviour() {
  saveSettings({
    verify_cache_with_debrid: $('verifyDebrid').checked,
    alldebrid_delete_probes: $('adDelete').checked,
    alldebrid_stop_on_hit: $('adStopOnHit').checked,
    alldebrid_probe_chunk: Number($('adChunk').value),
    debrid_max_probe: Number($('debridProbe').value),
  }, 'adSaved');
}

function saveRequestSettings() {
  saveSettings({
    auto_episodes_enabled: $('autoEpEnabled').checked,
    pending_movies_enabled: $('pendingEnabled').checked,
    auto_episodes_interval_minutes: Number($('sweepInterval').value),
    auto_episodes_retry_days: Number($('epRetryDays').value),
    pending_movies_retry_days: Number($('mvRetryDays').value),
    digital_release_delay_days: Number($('digitalDelay').value),
    episode_lookahead: Number($('epLookahead').value),
  }, 'reqSaved');
}

function savePacing() {
  saveSettings({
    aiostreams_max_concurrent: Number($('aioConcurrent').value),
    aiostreams_min_interval_ms: Number($('aioInterval').value),
  }, 'pacingSaved');
}

/* debrid services */
async function loadDebrid() {
  try {
    const result = await api('/api/debrid');
    $('debridList').innerHTML = result.services.map(debridHtml).join('');
  } catch (error) {
    $('debridList').innerHTML = `<div class="hint">${escapeHtml(error.message)}</div>`;
  }
}

function debridHtml(svc) {
  const status = svc.key_set
    ? (svc.enabled ? '<span class="pill ok">On</span>' : '<span class="pill warn">Key saved, off</span>')
    : '<span class="pill warn">No key</span>';
  const cacheNote = svc.supports_cache_check
    ? ''
    : '<span class="pill info">No cache lookup</span>';
  return `
    <div class="svc${svc.key_set ? ' open' : ''}" id="svc-${svc.key}">
      <div class="svc-hd">
        <span class="svc-badge">${escapeHtml(svc.short)}</span>
        <span class="grow" style="font-weight:700;font-size:14px">${escapeHtml(svc.name)}</span>
        ${status}${cacheNote}
        <button class="btn bg2" onclick="document.getElementById('svc-${svc.key}').classList.toggle('open')">
          Settings
        </button>
      </div>
      <div class="svc-body">
        ${svc.note ? `<div class="hint" style="font-size:12px">${escapeHtml(svc.note)}</div>` : ''}
        <div class="grid2">
          <div class="field">
            <label class="flabel" for="key-${svc.key}">API key</label>
            <input type="password" id="key-${svc.key}"
                   placeholder="${svc.key_set ? 'Saved — leave blank to keep' : 'Paste your API key'}"
                   autocomplete="new-password"/>
          </div>
          <div class="field">
            <label class="check" style="margin-top:28px">
              <input type="checkbox" id="on-${svc.key}" ${svc.enabled ? 'checked' : ''}/>
              Use this service
            </label>
          </div>
        </div>
        <label class="flabel">Request limits</label>
        <div class="grid3">
          <div class="field">
            <label class="flabel" for="rpm-${svc.key}">Per minute</label>
            <input type="number" id="rpm-${svc.key}" value="${svc.rpm}" min="1"/>
          </div>
          <div class="field">
            <label class="flabel" for="con-${svc.key}">At once</label>
            <input type="number" id="con-${svc.key}" value="${svc.concurrency}" min="1"/>
          </div>
          <div class="field">
            <label class="flabel" for="gap-${svc.key}">Minimum gap (ms)</label>
            <input type="number" id="gap-${svc.key}" value="${svc.spacing_ms}" min="0" step="50"/>
          </div>
        </div>
        <div class="hint" style="font-size:12px">
          Defaults leave room for whatever else uses this account — your Stremio
          client and addons share the same limits.
        </div>
        <div class="tresult" id="res-${svc.key}"></div>
        <div class="actions">
          <button class="btn bg2" onclick="testDebrid('${svc.key}')">Test key</button>
          <button class="btn bp" onclick="saveDebrid('${svc.key}')">Save</button>
        </div>
      </div>
    </div>`;
}

function debridForm(key) {
  const apiKey = $(`key-${key}`).value;
  const body = {
    enabled: $(`on-${key}`).checked,
    rpm: Number($(`rpm-${key}`).value),
    concurrency: Number($(`con-${key}`).value),
    spacing_ms: Number($(`gap-${key}`).value),
  };
  if (apiKey) body.api_key = apiKey;
  return body;
}

async function testDebrid(key) {
  setResult(`res-${key}`, 'Testing…');
  try {
    const result = await api(`/api/debrid/${key}/test`, {
      method: 'POST', body: JSON.stringify({ api_key: $(`key-${key}`).value }),
    });
    const extra = result.note ? ` ${result.note}` : '';
    setResult(`res-${key}`, `Connected as ${result.account}.${extra}`, 'ok');
  } catch (error) {
    setResult(`res-${key}`, error.message, 'er');
  }
}

async function saveDebrid(key) {
  try {
    await api(`/api/debrid/${key}`, { method: 'POST', body: JSON.stringify(debridForm(key)) });
    $(`key-${key}`).value = '';
    setResult(`res-${key}`, 'Saved.', 'ok');
    loadDebrid();
  } catch (error) {
    setResult(`res-${key}`, error.message, 'er');
  }
}

/* users */
function onUserFilter(value) {
  state.users.filter = value;
  state.users.page = 1;
  clearTimeout(state.users.timer);
  state.users.timer = setTimeout(loadUsers, 300);
}

async function loadUsers() {
  try {
    const result = await api(
      `/api/users?page=${state.users.page}&q=${encodeURIComponent(state.users.filter)}`);
    $('usersList').innerHTML = result.users.length
      ? result.users.map((u) => userHtml(u, result.admin_count)).join('')
      : '<div class="hint">Nobody matches that.</div>';
    renderPager('usersPager', result.page, result.pages, (p) => {
      state.users.page = p; loadUsers();
    });
  } catch (error) {
    $('usersList').innerHTML = `<div class="hint">${escapeHtml(error.message)}</div>`;
  }
}

function userHtml(user, adminCount) {
  const isMe = state.user && state.user.plex_user_id === user.plex_user_id;
  const lastAdmin = user.role === 'admin' && adminCount <= 1;
  return `
    <div class="rowitem">
      ${user.thumb
        ? `<img class="avatar" src="${escapeHtml(user.thumb)}" alt=""/>`
        : `<span class="avatar-initial">${escapeHtml((user.username || '?')[0].toUpperCase())}</span>`}
      <div class="grow">
        <div style="font-size:14px;font-weight:700">
          ${escapeHtml(user.username)}${isMe ? ' <span class="pill info">You</span>' : ''}
        </div>
        <div style="font-size:12px;color:var(--mut)">
          ${escapeHtml(user.email || 'No email')} · last seen ${when(user.last_login_at)}
        </div>
      </div>
      <select onchange="changeRole('${escapeHtml(user.plex_user_id)}',this.value,this)"
              style="width:auto" ${lastAdmin ? 'disabled' : ''}>
        <option value="user" ${user.role === 'user' ? 'selected' : ''}>User</option>
        <option value="admin" ${user.role === 'admin' ? 'selected' : ''}>Admin</option>
      </select>
      <button class="btn bdanger" ${lastAdmin ? 'disabled' : ''}
              onclick="removeUser('${escapeHtml(user.plex_user_id)}','${escapeHtml(user.username)}')">
        Remove
      </button>
    </div>`;
}

async function changeRole(userId, role, select) {
  try {
    await api(`/api/users/${userId}/role`, { method: 'POST', body: JSON.stringify({ role }) });
    toast(`Role changed to ${role}`, 'ok');
    loadUsers();
  } catch (error) {
    toast(error.message, 'er');
    loadUsers();
  }
}

async function removeUser(userId, username) {
  if (!confirm(`Remove ${username}? They can sign in again if they still have Plex access.`)) return;
  try {
    await api(`/api/users/${userId}`, { method: 'DELETE' });
    toast(`Removed ${username}`, 'ok');
    loadUsers();
  } catch (error) {
    toast(error.message, 'er');
  }
}

/* migrate */
async function loadMigrateSettings() {
  try {
    const result = await api('/api/migrate/settings');
    onMigServiceChange(result);
  } catch { /* the fields just stay empty */ }
}

let migSettings = null;

function onMigServiceChange(settingsFromServer) {
  if (settingsFromServer) migSettings = settingsFromServer;
  if (!migSettings) return;
  const service = $('migSvc').value;
  const saved = migSettings[service] || {};
  $('migUrl').value = saved.url_set ? saved.url : '';
  $('migKey').value = '';
  $('migKey').placeholder = saved.key_set ? 'Saved — leave blank to keep' : 'API key';
  $('migPreview').style.display = 'none';
  setResult('migResult', '');
}

async function migTest() {
  setResult('migResult', 'Testing…');
  try {
    const result = await api('/api/migrate/test', {
      method: 'POST',
      body: JSON.stringify({
        service: $('migSvc').value,
        url: $('migUrl').value.trim(),
        api_key: $('migKey').value,
      }),
    });
    setResult('migResult', `Connected to ${result.name} ${result.version}. Saved.`, 'ok');
    $('migKey').value = '';
    loadMigrateSettings();
  } catch (error) {
    setResult('migResult', error.message, 'er');
  }
}

async function migLoad() {
  setResult('migResult', 'Reading the library…');
  try {
    const result = await api(`/api/migrate/library?service=${$('migSvc').value}`);
    state.migItems = result.items;
    setResult('migResult', '', '');
    $('migSummary').textContent =
      `${result.total} title${result.total === 1 ? '' : 's'}, ${result.new} not here yet`;
    $('migList').innerHTML = result.items.map(migItemHtml).join('');
    $('migPreview').style.display = 'block';
  } catch (error) {
    setResult('migResult', error.message, 'er');
  }
}

function migItemHtml(item) {
  const detail = item.seasons
    ? `${item.seasons.length} season${item.seasons.length === 1 ? '' : 's'}`
    : (item.year || '');
  return `
    <label class="rowitem" style="cursor:pointer">
      <input type="checkbox" class="migcheck" value="${escapeHtml(item.imdb_id)}"
             ${item.already_here ? '' : 'checked'} style="width:16px;height:16px;accent-color:var(--acc)"/>
      <div class="grow">
        <div style="font-size:13px;font-weight:700">${escapeHtml(item.title)}</div>
        <div style="font-size:11px;color:var(--mut)">${escapeHtml(String(detail))}</div>
      </div>
      ${item.already_here ? '<span class="pill ok">Already here</span>' : ''}
    </label>`;
}

function migSelectAll(checked) {
  els('.migcheck').forEach((box) => { box.checked = checked; });
}

async function migStart() {
  const ids = els('.migcheck').filter((b) => b.checked).map((b) => b.value);
  if (!ids.length) { toast('Nothing selected', 'er'); return; }
  try {
    const job = await api('/api/migrate/run', {
      method: 'POST',
      body: JSON.stringify({ service: $('migSvc').value, imdb_ids: ids, skip_existing: true }),
    });
    state.migJob = job.job_id;
    $('migPreview').style.display = 'none';
    $('migProgress').style.display = 'block';
    $('migCancelBtn').style.display = '';
    pollMigration();
  } catch (error) {
    setResult('migResult', error.message, 'er');
  }
}

function pollMigration() {
  clearTimeout(state.migTimer);
  if (!state.migJob) return;
  api(`/api/migrate/status/${state.migJob}`).then((job) => {
    const percent = job.total ? Math.round((job.done / job.total) * 100) : 0;
    $('migBar').style.width = `${percent}%`;
    $('migCount').textContent = `${job.done} / ${job.total}`;
    $('migCurrent').textContent = job.current || '';
    $('migState').textContent = job.running
      ? `${job.created} added`
      : `Finished — ${job.created} added, ${job.skipped} skipped`;
    if (job.running) {
      state.migTimer = setTimeout(pollMigration, 1200);
    } else {
      $('migCancelBtn').style.display = 'none';
      toast(`Migration finished — ${job.created} added`, 'ok');
      refreshInLibrary();
    }
  }).catch(() => { state.migTimer = setTimeout(pollMigration, 3000); });
}

async function migCancel() {
  if (!state.migJob) return;
  await api(`/api/migrate/cancel/${state.migJob}`, { method: 'POST' }).catch(() => {});
  toast('Stopping after the current title', 'in');
}

/* repair */
async function loadRepair() {
  try {
    const status = await api('/api/repair/status');
    $('repairEnabled').checked = status.enabled;
    $('repairMode').value = status.mode;
    $('repairInterval').value = status.interval_hours;
    renderRepairTimes(status.times);
    onRepairModeChange();
    const s = settingsCache;
    $('repairBatch').value = s.repair_batch_size ?? 40;
    $('repairMaxFail').value = s.repair_max_failures ?? 5;
    $('repairPause').checked = s.repair_pause_on_playback !== false;
    renderRepairStatus(status);
  } catch (error) {
    toast(error.message, 'er');
  }
}

function renderRepairTimes(times) {
  $('repairTimes').innerHTML = (times || ['04:00']).map((t, i) => `
    <div style="display:flex;gap:8px;align-items:center;margin-bottom:8px;max-width:320px">
      <input type="time" class="repair-time" value="${escapeHtml(t)}"/>
      <button class="btn bg2" onclick="removeRepairTime(${i})" ${times.length <= 1 ? 'disabled' : ''}>
        Remove
      </button>
    </div>`).join('');
}

function currentRepairTimes() {
  return els('.repair-time').map((input) => input.value).filter(Boolean);
}

function addRepairTime() {
  renderRepairTimes([...currentRepairTimes(), '04:00']);
}

function removeRepairTime(index) {
  const times = currentRepairTimes();
  times.splice(index, 1);
  renderRepairTimes(times.length ? times : ['04:00']);
}

function onRepairModeChange() {
  const interval = $('repairMode').value === 'interval';
  $('repairIntervalField').style.display = interval ? 'block' : 'none';
  $('repairTimesField').querySelector('.flabel').textContent =
    interval ? 'Start from' : 'Times';
}

async function saveRepair() {
  try {
    const status = await api('/api/repair/schedule', {
      method: 'POST',
      body: JSON.stringify({
        enabled: $('repairEnabled').checked,
        mode: $('repairMode').value,
        times: currentRepairTimes(),
        interval_hours: Number($('repairInterval').value),
        batch_size: Number($('repairBatch').value),
        pause_on_playback: $('repairPause').checked,
        max_failures: Number($('repairMaxFail').value),
      }),
    });
    flashSaved('repairSaved');
    renderRepairStatus(status);
  } catch (error) {
    toast(error.message, 'er');
  }
}

function renderRepairStatus(status) {
  const next = status.next_due
    ? new Date(status.next_due * 1000).toLocaleString()
    : 'not scheduled';
  const last = status.last;
  $('repairChips').innerHTML = `
    <span class="chip"><span class="cl">Next run</span><span class="cv">${escapeHtml(next)}</span></span>
    <span class="chip"><span class="cl">Queued urgently</span><span class="cv">${status.urgent_queued}</span></span>
    ${last ? `<span class="chip"><span class="cl">Last run</span><span class="cv">${escapeHtml(when(last.finished_at))}</span></span>` : ''}`;

  const running = status.current;
  $('repairCancelBtn').style.display = running ? '' : 'none';
  $('repairRunBtn').disabled = !!running;

  if (running) {
    const percent = running.total ? Math.round((running.checked / running.total) * 100) : 0;
    $('repairRun').innerHTML = `
      <div class="hint" style="margin-bottom:4px">${escapeHtml(running.current || 'Working…')}</div>
      <div class="bar"><div style="width:${percent}%"></div></div>
      <div style="font-size:12px;color:var(--mut)">
        ${running.checked} / ${running.total} · ${running.repaired} repaired · ${running.failed} unresolved
      </div>`;
  } else if (last) {
    $('repairRun').innerHTML = `
      <div class="hint" style="margin:0">
        Last run checked ${last.checked} file(s): ${last.still_good} already fine,
        ${last.repaired} repaired, ${last.failed} with no source, ${last.removed} removed.
      </div>`;
  } else {
    $('repairRun').innerHTML = '<div class="hint" style="margin:0">No repair has run yet.</div>';
  }
}

function startRepairPolling() {
  stopRepairPolling();
  state.repairTimer = setInterval(async () => {
    try { renderRepairStatus(await api('/api/repair/status')); } catch { /* transient */ }
  }, 2500);
}

function stopRepairPolling() {
  if (state.repairTimer) { clearInterval(state.repairTimer); state.repairTimer = null; }
}

async function runRepair() {
  try {
    await api('/api/repair/run', { method: 'POST' });
    toast('Repair started', 'ok');
    startRepairPolling();
  } catch (error) {
    toast(error.message, 'er');
  }
}

async function cancelRepair() {
  await api('/api/repair/cancel', { method: 'POST' }).catch(() => {});
  toast('Stopping after the current file', 'in');
}

/* backup */
async function downloadBackup() {
  try {
    const payload = await api('/api/backup');
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `aiogateway-backup-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast('Backup downloaded', 'ok');
  } catch (error) {
    toast(error.message, 'er');
  }
}

async function restoreBackup(event) {
  const file = event.target.files[0];
  if (!file) return;
  setResult('restoreResult', 'Restoring…');
  try {
    const payload = JSON.parse(await file.text());
    const result = await api('/api/restore', {
      method: 'POST',
      body: JSON.stringify({ payload, replace: $('restoreReplace').checked }),
    });
    const bits = [`${result.added} file(s)`, `${result.settings} setting(s)`];
    if (result.requests) bits.push(`${result.requests} request(s)`);
    if ((result.connections || []).length) {
      bits.push(`${result.connections.length} connection field(s) that weren't set`);
    }
    setResult('restoreResult',
      `Restored ${bits.join(', ')}; skipped ${result.skipped}. ` +
      'Links are fetched on first play.', 'ok');
    refreshInLibrary();
  } catch (error) {
    setResult('restoreResult', error.message, 'er');
  } finally {
    event.target.value = '';
  }
}

boot();
