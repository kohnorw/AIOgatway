# Run: python tests/test_requests.py <path-to-aiogateway>   (needs fastapi, aiohttp, aiostream, requests, httpx)
"""Requests create placeholders and run only the 4K existence check (one
search per movie; one per season, or one per show when a 4K series pack
shows up). No links are kept or probed. A 4K placeholder whose first play
finds no 4K source is removed and marked unavailable."""
import asyncio, json, os, sys, tempfile
from pathlib import Path

SRC = sys.argv[1]
TMP = Path(tempfile.mkdtemp())
os.environ.update({
    "AIOSTREAMS_URL": "http://127.0.0.1:18921", "AIOSTREAMS_UUID": "u", "AIOSTREAMS_PASSWORD": "p",
    "FUSE_MOUNTPOINT": str(TMP / "mnt"), "AIOSTREAMS_CACHE_SECONDS": "0",
    "PLEX_URL": "", "PLEX_TOKEN": "", "AIOGW_API_KEY": "k",
})
(TMP / "aiogateway_settings.json").write_text(json.dumps({
    "aiostreams_min_interval_ms": 0, "min_4k_candidates": 2,
    "_prewarm_backstop_migrated": True, "_prewarm_window_migrated": True}))
sys.path.insert(0, SRC); os.chdir(SRC)

from aiohttp import web
import httpx

SIZE = 90 * 1024 * 1024
queries = []
FOUR_K = {"tt500": "series", "tt800": "season"}   # shows with 4K: via series pack / per-season packs
NO_4K_NOW = set()
def _r(i, res, folder=None):
    return {"url": f"http://127.0.0.1:18922/f/{i}/{res}", "filename": f"x.{res}.mkv", "size": SIZE,
            "cached": True, "folderName": folder, "parsedFile": {"resolution": res}}
async def search(req):
    i = req.query["id"]; queries.append(i)
    show = i.split(":")[0]
    res = [_r(i, "1080p")]
    if show in FOUR_K and i not in NO_4K_NOW:
        folder = "Show.Complete.Series.2160p" if FOUR_K[show] == "series" else f"Show.S0{i.split(':')[1]}.2160p"
        res += [_r(i, "2160p", folder), _r(i + "b", "2160p", folder)]
    return web.json_response({"success": True, "data": {"results": res, "errors": []}})
async def cdn(req):
    return web.Response(status=206, body=b"\x1a" * 1, headers={"Content-Range": f"bytes 0-0/{SIZE}",
                                                               "Content-Type": "video/x-matroska"})

VIDEOS = [{"season": s, "number": e, "released": "2015-01-01T00:00:00Z"} for s in (1, 2, 3) for e in range(1, 11)]
class FakeResp:
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    async def json(self, content_type=None):
        return {"meta": {"name": "Show", "year": "2015-2018", "videos": VIDEOS}}
class FakeHttp:
    def get(self, *a, **k): return FakeResp()
    async def close(self): pass

fails = []
def check(n, c, d=""):
    print(("PASS " if c else "FAIL ") + n + (f" — {d}" if d and not c else "")); c or fails.append(n)

async def main():
    for app_, port, route, h in ((web.Application(), 18921, "/api/v1/search", search),
                                 (web.Application(), 18922, "/f/{p:.*}", cdn)):
        app_.router.add_get(route, h); rr = web.AppRunner(app_); await rr.setup()
        await web.TCPSite(rr, "127.0.0.1", port).start()

    import main as M
    from gateway.models import StubState, Quality
    from gateway import quality_unavailable as QU
    async with M.app.router.lifespan_context(M.app):
        M._http = FakeHttp()
        async def _cm(kind, imdb_id, refresh=False): return {}
        M._cinemeta_cached = _cm
        tr = httpx.ASGITransport(app=M.app)
        async with httpx.AsyncClient(transport=tr, base_url="http://t", headers={"X-API-Key": "k"}) as c:
            r = await c.post("/api/add", json={"imdb_id": "tt500", "title": "Show", "media_type": "series"})
            check("series request ok", r.status_code == 200, r.text)
            r2 = await c.post("/api/add", json={"imdb_id": "tt600", "title": "Film", "year": 2019, "media_type": "movie"})
            check("movie request ok", r2.status_code == 200, r2.text)
            r3 = await c.post("/api/add", json={"imdb_id": "tt800", "title": "Other", "media_type": "series"})
            check("second series request ok", r3.status_code == 200, r3.text)
            for t in list(M._bg_scans.values()):
                await t
        stubs = M._stubs.all()
        by = lambda imdb, q: [s for s in stubs if s.imdb_id == imdb and s.quality == q]
        check("series w/ 4K series pack: 30 HD + 30 4K", (len(by("tt500", Quality.HD)), len(by("tt500", Quality.UHD))) == (30, 30))
        check("series w/ season packs: 30 HD + 30 4K", (len(by("tt800", Quality.HD)), len(by("tt800", Quality.UHD))) == (30, 30))
        check("movie without 4K: HD only", (len(by("tt600", Quality.HD)), len(by("tt600", Quality.UHD))) == (1, 0))
        check("all placeholders, no links", all(s.state == StubState.PLACEHOLDER and not s.stream_url for s in stubs))
        check("searches: 1 (series pack) + 1 (movie) + 3 (one per season)",
              sorted(queries) == sorted(["tt500:1:1", "tt600", "tt800:1:1", "tt800:2:1", "tt800:3:1"]), queries)

        # first play of HD = exactly one more search
        n = len(queries)
        hd = by("tt600", Quality.HD)[0]
        r = await M._resolver.on_play(hd.stub_id)
        check("HD play switches placeholder", r["action"] == "resolved", r)
        check("one search for that play", len(queries) == n + 1, queries[n:])

        # 4K placeholder whose 4K has gone → removed + marked on first play
        u = next(s for s in by("tt800", Quality.UHD) if s.season == 2 and s.episode == 3)
        NO_4K_NOW.add("tt800:2:3")
        r = await M._resolver.on_play(u.stub_id)
        check("4K with no source → removed", r["action"] == "removed" and M._stubs.get(u.stub_id) is None, r)
        check("4K marked unavailable for that episode", QU.is_marked("tt800", 2, 3))

        # new episode in an existing 4K season: inherits, no search
        n = len(queries)
        await M._query_episode("tt800", "Other", 2015, "", {"season": 3, "number": 11}, None)
        check("sweep episode inherits season's 4K, no search",
              len(by_now := [s for s in M._stubs.all() if s.imdb_id == "tt800" and s.season == 3 and s.episode == 11]) == 2
              and len(queries) == n, (len(by_now), queries[n:]))

asyncio.run(main())
print(f"\n{len(fails)} failure(s)"); sys.exit(1 if fails else 0)
