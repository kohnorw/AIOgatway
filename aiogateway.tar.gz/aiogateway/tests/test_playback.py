# Run: python tests/test_playback.py <path-to-aiogateway>   (needs aiohttp, aiostream, requests)
"""
End-to-end "press play" behaviour against fakes of Plex, AIOStreams and a
debrid CDN:

  * the scanner reading a placeholder gets placeholder bytes, no search
  * pressing play (Plex lists a session on the file) switches the
    placeholder on that very read and returns REAL bytes — no 45-second
    placeholder clip, no second press, no rename
  * the CDN refuses python user-agents (common in the wild)
  * AIOStreams' playback URL 307-redirects to the CDN; the CDN link is
    pinned so blocks don't go back through AIOStreams
  * reliability simulation: 100 first-press plays with flaky links
"""
import asyncio, json, os, random, sys, tempfile, time
from pathlib import Path

SRC = sys.argv[1]
TMP = Path(tempfile.mkdtemp())
MNT = str(TMP / "mnt")
os.environ.update({
    "AIOSTREAMS_URL": "http://127.0.0.1:18951", "AIOSTREAMS_UUID": "u", "AIOSTREAMS_PASSWORD": "p",
    "FUSE_MOUNTPOINT": MNT, "FUSE_BLOCK_MB": "1", "FUSE_PREFETCH_AHEAD": "1",
    "FUSE_READ_TIMEOUT": "3", "FUSE_PLAY_DETECT_SECONDS": "1", "AIOSTREAMS_CACHE_SECONDS": "0",
    "AIOSTREAMS_CACHE_EMPTY_SECONDS": "0", "PLEX_URL": "http://127.0.0.1:18953", "PLEX_TOKEN": "t",
})
(TMP / "aiogateway_settings.json").write_text(json.dumps({
    "aiostreams_min_interval_ms": 3000, "_prewarm_backstop_migrated": True, "_prewarm_window_migrated": True}))
sys.path.insert(0, SRC)

from aiohttp import web
from gateway.models import MediaItem, MediaType, StubState, Quality
from gateway.stub_manager import StubManager
from gateway.aiostreams_client import AIOStreamsClient
import gateway.aiostreams_client as AC
from gateway import resolver as R, fuse_fs as F
from webhook.handler import PlexWebhookHandler
AC._RESEARCH_DELAYS = (0.3, 0.6)

SIZE = 70 * 1024 * 1024
PAT = bytes(range(251)) * (2 * 1024 * 1024 // 251 + 2)
def data(seed, a, n):
    out = bytearray()
    while n > 0:
        k = min(n, 1024 * 1024); o = (a + seed) % 251; out += PAT[o:o + k]; a += k; n -= k
    return bytes(out)

queries, playback_hits, sessions = [], [], {}
dead = set()
flaky = {"p_dead": 0.0, "p_all_dead_search": 0.0}
search_n = {"n": 0}

async def search(req):
    i = req.query["id"]; queries.append(i); search_n["n"] += 1
    n = search_n["n"]
    all_dead = random.random() < flaky["p_all_dead_search"]
    res = []
    for k in range(6):
        key = f"{i.replace(':', '_')}-s{n}-{k}"
        if all_dead or random.random() < flaky["p_dead"]:
            dead.add(key)
        res.append({"url": f"http://127.0.0.1:18951/api/v1/debrid/playback/{key}",
                    "filename": f"Show.{i}.{k}.1080p.mkv", "folderName": None, "size": SIZE,
                    "cached": True, "parsedFile": {"resolution": "1080p"}})
    return web.json_response({"success": True, "data": {"results": res, "errors": []}})

async def playback(req):
    key = req.match_info["k"]; playback_hits.append(key)
    raise web.HTTPTemporaryRedirect(f"http://127.0.0.1:18952/cdn/{key}")

async def cdn(req):
    key = req.match_info["k"]
    ua = req.headers.get("User-Agent", "").lower()
    if "python" in ua or "aiohttp" in ua:
        return web.Response(status=403, text="bot user-agent refused")
    if key in dead:
        return web.Response(status=403, text="link expired")
    a, b = req.headers.get("Range", "bytes=0-").split("=")[1].split("-")
    a = int(a); b = min(int(b) if b else SIZE - 1, SIZE - 1)
    if a >= SIZE:
        return web.Response(status=416, headers={"Content-Range": f"bytes */{SIZE}"})
    return web.Response(status=206, body=data(7, a, b - a + 1),
                        headers={"Content-Range": f"bytes {a}-{b}/{SIZE}", "Content-Type": "video/x-matroska"})

async def plex_sessions(req):
    md = [{"ratingKey": rk, "Media": [{"Part": [{"file": f}]}]} for f, rk in sessions.items()]
    return web.json_response({"MediaContainer": {"Metadata": md}})

fails = []
def check(n, c, d=""):
    print(("PASS " if c else "FAIL ") + n + (f" — {d}" if d and not c else "")); c or fails.append(n)

def rd(fs, path, off, n, fh):
    try:
        return fs.read(path, n, off, fh)
    except OSError as e:
        return e

async def main():
    random.seed(7)
    apps = [(18951, [("/api/v1/search", search), ("/api/v1/debrid/playback/{k}", playback)]),
            (18952, [("/cdn/{k}", cdn)]), (18953, [("/status/sessions", plex_sessions)])]
    for port, routes in apps:
        a = web.Application()
        for r_, h in routes: a.router.add_get(r_, h)
        rr = web.AppRunner(a); await rr.setup(); await web.TCPSite(rr, "127.0.0.1", port).start()

    stubs = StubManager(); client = AIOStreamsClient(); await client.open()
    res = R.LinkResolver(stubs, client); res.bind_loop(); R.set_instance(res)
    fs = F.AIOGatewayFS(stubs, client); F._fs_instance = fs
    wh = PlexWebhookHandler(stubs, client, resolver=res)

    async def ep_stub(e):
        it = MediaItem(id=f"tt9_s1e{e}", imdb_id="tt9", title="Show", show_title="Show", year=2020,
                       media_type=MediaType.SERIES, season=1, episode=e)
        return (await stubs.create_placeholders(it))[0]

    # ── scanner read: placeholder bytes, no search ──
    st = await ep_stub(1)
    path = fs._stub_path(st)
    fh = fs.open(path, 0)
    t0 = time.time(); b = await asyncio.to_thread(rd, fs, path, 0, 4096, fh); took = time.time() - t0
    check("scanner read gets placeholder bytes", isinstance(b, bytes) and b[:4] == b"\x1aE\xdf\xa3")
    check("scanner read made no AIOStreams search", queries == [], queries)
    check("scanner read delay bounded by play-detect window", took < 2.0, f"{took:.1f}s")
    # same handle keeps placeholder even if the stub switches later
    sessions[MNT + path] = "101"
    b2 = await asyncio.to_thread(rd, fs, path, 0, 4096, fh)
    check("placeholder handle stays placeholder", isinstance(b2, bytes) and b2[:4] == b"\x1aE\xdf\xa3")
    fs.release(path, fh); sessions.clear()

    # ── press play: first read switches and returns real content ──
    sessions[MNT + path] = "101"
    fh = fs.open(path, 0)
    t0 = time.time(); b = await asyncio.to_thread(rd, fs, path, 0, 65536, fh); took = time.time() - t0
    check("FIRST press of play returns the real file", b == data(7, 0, 65536), repr(b)[:60])
    print(f"     switch + first bytes took {took:.2f}s (AIOStreams spacing is 3s; playback skips it)")
    check("switch skipped the 3s queue spacing", took < 2.5, f"{took:.1f}s")
    check("stub ACTIVE", st.state == StubState.ACTIVE)
    check("filename unchanged (no Plex re-add)", fs._stub_path(st) == path, fs._stub_path(st))
    check("CDN link pinned (not the AIOStreams playback URL)", "/cdn/" in st.stream_url, st.stream_url)
    hits = len(playback_hits)
    b = await asyncio.to_thread(rd, fs, path, 30 * 1024 * 1024, 65536, fh)
    check("later blocks stream from CDN directly", b == data(7, 30 * 1024 * 1024, 65536) and len(playback_hits) == hits)
    out = await wh.handle(json.dumps({"event": "media.play", "Metadata": {"type": "episode",
                          "Media": [{"Part": [{"file": MNT + path}]}]}}))
    check("webhook arriving after = already_active, no 2nd search", out["action"] == "already_active" and len(queries) == 1, (out, queries))
    fs.release(path, fh); sessions.clear()

    # ── webhook first, read second (other ordering) ──
    st2 = await ep_stub(2); p2 = fs._stub_path(st2)
    task = asyncio.create_task(wh.handle(json.dumps({"event": "media.play", "Metadata": {"type": "episode",
                               "Media": [{"Part": [{"file": MNT + p2}]}]}})))
    await asyncio.sleep(0.05)
    fh = fs.open(p2, 0)
    b = await asyncio.to_thread(rd, fs, p2, 0, 4096, fh)
    await task
    check("webhook-first ordering also returns real bytes", b == data(7, 0, 4096))
    fs.release(p2, fh)

    # ── reliability simulation ──
    flaky.update(p_dead=0.45, p_all_dead_search=0.12)
    ok = 0; N = 100; slow = []
    for e in range(10, 10 + N):
        s = await ep_stub(e); p = fs._stub_path(s)
        sessions.clear(); sessions[MNT + p] = str(e)
        fh = fs.open(p, 0)
        t0 = time.time(); b = await asyncio.to_thread(rd, fs, p, 0, 8192, fh); slow.append(time.time() - t0)
        ok += (b == data(7, 0, 8192))
        fs.release(p, fh)
    slow.sort()
    print(f"     {ok}/{N} first-press plays got real content "
          f"(45% of links dead, 12% of searches entirely dead); median {slow[N//2]:.2f}s, worst {slow[-1]:.2f}s")
    check("≥98% of first presses play real content under flaky links", ok >= 98, f"{ok}/{N}")
    await client.close()

asyncio.run(main())
print(f"\n{len(fails)} failure(s)"); sys.exit(1 if fails else 0)
