# Run: python tests/test_requests.py <path-to-aiogateway>   (needs fastapi, aiohttp, aiostream, requests, httpx)
"""Requests create placeholders and run only the 4K existence check (one
search per movie; one per season, or one per show when a 4K series pack
shows up). No links are kept or probed. A 4K placeholder whose first play
finds no 4K source is removed and marked unavailable."""
import asyncio, json, os, sys, tempfile
from pathlib import Path

SRC = sys.argv[1]
TMP = Path(tempfile.mkdtemp())
os.environ.update({
    "AIOSTREAMS_URL": "http://127.0.0.1:18941", "AIOSTREAMS_UUID": "u", "AIOSTREAMS_PASSWORD": "p",
    "FUSE_MOUNTPOINT": str(TMP / "mnt"), "AIOSTREAMS_CACHE_SECONDS": "0",
    "PLEX_URL": "", "PLEX_TOKEN": "", "AIOGW_API_KEY": "k",
})
(TMP / "aiogateway_settings.json").write_text(json.dumps({
    "aiostreams_min_interval_ms": 3000, "min_4k_candidates": 2,
    "_prewarm_backstop_migrated": True, "_prewarm_window_migrated": True}))
sys.path.insert(0, SRC); os.chdir(SRC)

from aiohttp import web
import httpx

SIZE = 90 * 1024 * 1024
queries = []
FOUR_K = {"tt500": "series", "tt800": "season"}   # shows with 4K: via series pack / per-season packs
NO_4K_NOW = set()
def _r(i, res, folder=None):
    return {"url": f"http://127.0.0.1:18942/f/{i}/{res}", "filename": f"x.{res}.mkv", "size": SIZE,
            "cached": True, "folderName": folder, "parsedFile": {"resolution": res}}
async def search(req):
    i = req.query["id"]; queries.append(i)
    show = i.split(":")[0]
    res = [_r(i, "1080p")]
    if show in FOUR_K and i not in NO_4K_NOW:
        folder = "Show.Complete.Series.2160p" if FOUR_K[show] == "series" else f"Show.S0{i.split(':')[1]}.2160p"
        res += [_r(i, "2160p", folder), _r(i + "b", "2160p", folder)]
    return web.json_response({"success": True, "data": {"results": res, "errors": []}})
async def cdn(req):
    return web.Response(status=206, body=b"\x1a" * 1, headers={"Content-Range": f"bytes 0-0/{SIZE}",
                                                               "Content-Type": "video/x-matroska"})

VIDEOS = [{"season": s, "number": e, "released": "2015-01-01T00:00:00Z"} for s in (1, 2, 3) for e in range(1, 11)]
class FakeResp:
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    async def json(self, content_type=None):
        return {"meta": {"name": "Show", "year": "2015-2018", "videos": VIDEOS}}
class FakeHttp:
    def get(self, *a, **k): return FakeResp()
    async def close(self): pass

fails = []
def check(n, c, d=""):
    print(("PASS " if c else "FAIL ") + n + (f" — {d}" if d and not c else "")); c or fails.append(n)

async def main():
    for app_, port, route, h in ((web.Application(), 18941, "/api/v1/search", search),
                                 (web.Application(), 18942, "/f/{p:.*}", cdn)):
        app_.router.add_get(route, h); rr = web.AppRunner(app_); await rr.setup()
        await web.TCPSite(rr, "127.0.0.1", port).start()

    import main as M
    from gateway.models import StubState, Quality
    from gateway import quality_unavailable as QU
    async with M.app.router.lifespan_context(M.app):
        M._http = FakeHttp()
        async def _cm(kind, imdb_id, refresh=False): return {}
        M._cinemeta_cached = _cm
        import time as _t
        tr = httpx.ASGITransport(app=M.app)
        async with httpx.AsyncClient(transport=tr, base_url="http://t", headers={"X-API-Key": "k"}) as c:
            for sn in (1, 2, 3):                       # the UI adds one season per request
                r = await c.post("/api/add", json={"imdb_id": "tt800", "title": "Friends", "media_type": "series", "season": sn})
                check(f"season {sn} request ok", r.status_code == 200, r.text)
                await asyncio.sleep(1.0)               # lands mid-queue of the previous season's 4K check
        hd = next(s for s in M._stubs.all() if s.imdb_id == "tt800" and s.season == 1 and s.episode == 1 and s.quality == Quality.HD)
        t0 = _t.time()
        r = await asyncio.wait_for(M._resolver.on_play(hd.stub_id), 30)
        took = _t.time() - t0
        check("play switches while 4K checks are queued", r["action"] == "resolved", r)
        check("switch didn't wait behind background checks (<8s)", took < 8, f"{took:.1f}s")
        for t in list(M._bg_scans.values()):
            await asyncio.wait_for(t, 60)
        uhd = [s for s in M._stubs.all() if s.imdb_id == "tt800" and s.quality == Quality.UHD]
        check("all 3 seasons still got their 4K check", sorted({s.season for s in uhd}) == [1, 2, 3], sorted({s.season for s in uhd}))
        r2 = await asyncio.wait_for(M._resolver.on_play(
            next(s for s in M._stubs.all() if s.imdb_id == "tt800" and s.season == 2 and s.episode == 1 and s.quality == Quality.HD).stub_id), 30)
        check("queue still healthy afterwards", r2["action"] == "resolved", r2)

asyncio.run(main())
print(f"\n{len(fails)} failure(s)"); sys.exit(1 if fails else 0)
