# Run: python tests/test_flow.py <path-to-aiogateway>   (needs fastapi, aiohttp, aiostream, requests, httpx)
"""
End-to-end checks for the rebuilt link flow, against a fake AIOStreams and a
fake Range-capable CDN. FUSE ops are called directly (no kernel mount); reads
run in worker threads exactly like libfuse's, so the thread→loop repair
bridge is exercised for real.
"""
import asyncio, json, os, sys, tempfile, time, threading, errno
from pathlib import Path

SRC = sys.argv[1]
TMP = Path(tempfile.mkdtemp())
os.environ.update({
    "AIOSTREAMS_URL": "http://127.0.0.1:18901", "AIOSTREAMS_UUID": "u", "AIOSTREAMS_PASSWORD": "p",
    "FUSE_MOUNTPOINT": str(TMP / "mnt"), "FUSE_BLOCK_MB": "1", "FUSE_PREFETCH_AHEAD": "0",
    "FUSE_READ_TIMEOUT": "3", "FUSE_REPAIR_TIMEOUT": "20", "AIOSTREAMS_CACHE_SECONDS": "0",
    "AIOSTREAMS_CACHE_EMPTY_SECONDS": "0", "PLEX_URL": "", "PLEX_TOKEN": "",
})
(TMP / "aiogateway_settings.json").write_text(json.dumps({
    "aiostreams_min_interval_ms": 0, "min_4k_candidates": 1,
    "_prewarm_backstop_migrated": True, "_prewarm_window_migrated": True,
}))
sys.path.insert(0, SRC)

from aiohttp import web
from gateway.models import MediaItem, MediaType, Quality, StubState
from gateway.stub_manager import StubManager
from gateway.aiostreams_client import AIOStreamsClient
from gateway import resolver as R
from gateway import fuse_fs as F
from webhook.handler import PlexWebhookHandler

CDN = "http://127.0.0.1:18902"
SIZE = 120 * 1024 * 1024
PAT = bytes(range(251)) * (2 * 1024 * 1024 // 251 + 2)

def expect_bytes(seed, start, n):
    out = bytearray()
    while n > 0:
        k = min(n, 1024 * 1024)
        o = (start + seed) % 251
        out += PAT[o:o + k]
        start += k; n -= k
    return bytes(out)

# ── fake CDN ────────────────────────────────────────────────────────────────
files = {}       # path -> {"seed":int, "size":int, "dead":bool}
cdn_hits = []

async def cdn(request):
    path = request.match_info["p"]
    cdn_hits.append(path)
    f = files.get(path)
    if not f or f["dead"]:
        return web.Response(status=403, text="expired")
    rng = request.headers.get("Range", "bytes=0-")
    a, b = rng.split("=")[1].split("-")
    a = int(a); b = int(b) if b else f["size"] - 1
    if a >= f["size"]:
        return web.Response(status=416, headers={"Content-Range": f"bytes */{f['size']}"})
    b = min(b, f["size"] - 1)
    return web.Response(status=206, body=expect_bytes(f["seed"], a, b - a + 1),
                        headers={"Content-Range": f"bytes {a}-{b}/{f['size']}",
                                 "Content-Type": "video/x-matroska"})

# ── fake AIOStreams ────────────────────────────────────────────────────────
results = {}     # id -> list of result dicts
queries = []

async def search(request):
    i = request.query["id"]
    queries.append(i)
    return web.json_response({"success": True, "data": {"results": results.get(i, []), "errors": []}})

def res(path, *, folder=None, fname="x.mkv", res_="1080p", cached=True, ih=None, idx=None, size=SIZE, fseasons=None):
    return {"url": f"{CDN}/f/{path}", "filename": fname, "folderName": folder, "size": size,
            "cached": cached, "infoHash": ih, "fileIdx": idx, "type": "debrid",
            "parsedFile": {"resolution": res_, "folderSeasons": fseasons}}

def add_file(path, seed, size=SIZE):
    files[path] = {"seed": seed, "size": size, "dead": False}

failures = []
def check(name, cond, detail=""):
    print(("PASS " if cond else "FAIL ") + name + (f" — {detail}" if detail and not cond else ""))
    if not cond:
        failures.append(name)

def fuse_read(fs, path, offset, size, fh):
    try:
        return fs.read(path, size, offset, fh)
    except OSError as e:
        return e

async def main():
    app = web.Application(); app.router.add_get("/api/v1/search", search)
    cdnapp = web.Application(); cdnapp.router.add_get("/f/{p:.*}", cdn)
    r1 = web.AppRunner(app); await r1.setup(); await web.TCPSite(r1, "127.0.0.1", 18901).start()
    r2 = web.AppRunner(cdnapp); await r2.setup(); await web.TCPSite(r2, "127.0.0.1", 18902).start()

    stubs = StubManager(); client = AIOStreamsClient(); await client.open()
    res_ = R.LinkResolver(stubs, client); res_.bind_loop(); R.set_instance(res_)
    fs = F.AIOGatewayFS(stubs, client); F._fs_instance = fs
    th = lambda *a: asyncio.to_thread(fuse_read, fs, *a)

    # ── 1. series: request creates placeholders only, no links touched ──
    ep = "tt100:1:2"
    add_file("series_pack", 11); add_file("season_pack", 22); add_file("episode", 33)
    results[ep] = [
        res("episode", fname="Show.S01E02.1080p.mkv"),
        res("season_pack", fname="Show.S01E02.1080p.mkv", folder="Show.S01.1080p.WEB-DL", ih="AAA", idx=2),
        res("series_pack", fname="Show.S01E02.1080p.mkv", folder="Show.Complete.Series.1080p", ih="BBB", idx=7),
    ]
    item = MediaItem(id="tt100_s1e2", imdb_id="tt100", title="Show", show_title="Show", year=2020,
                     media_type=MediaType.SERIES, season=1, episode=2)
    item.streams = await client.resolve_all(item)
    created = await stubs.create_stubs(item)
    hd = next(s for s in created if s.quality == Quality.HD)
    check("request leaves placeholder", hd.state == StubState.PLACEHOLDER and not hd.stream_url)
    check("request never touches CDN", cdn_hits == [], cdn_hits)

    # pack detection via folderName
    kinds = [s.pack_type for s in item.streams]
    check("pack detection uses folderName", ("series", None) in kinds and ("season", 1) in kinds, kinds)

    # ── 2. placeholder read serves stub bytes, no resolution ──
    path = fs._stub_path(hd)
    fh = fs.open(path, 0)
    b = await th(path, 0, 64, fh)
    check("placeholder read = stub bytes", isinstance(b, bytes) and b[:4] == b"\x1aE\xdf\xa3")
    check("read does not trigger switch", hd.state == StubState.PLACEHOLDER)
    fs.release(path, fh)

    # ── 3. switch: series pack first; dead series pack → season pack ──
    files["series_pack"]["dead"] = True
    cdn_hits.clear()
    wh = PlexWebhookHandler(stubs, client, resolver=res_)
    payload = {"event": "media.play", "Metadata": {"type": "episode",
               "Media": [{"Part": [{"file": os.environ["FUSE_MOUNTPOINT"] + path}]}]}}
    out = await wh.handle(json.dumps(payload))
    check("webhook switched placeholder", out.get("action") == "resolved", out)
    check("dead series pack skipped → season pack used", hd.stream_url.endswith("/season_pack"), hd.stream_url)
    check("series pack was tried before season pack",
          cdn_hits.index("series_pack") < cdn_hits.index("season_pack"), cdn_hits)
    check("episode-only file not needed", "episode" not in cdn_hits, cdn_hits)
    check("file identity recorded", hd.stream_file_id == "aaa:2", hd.stream_file_id)

    # duplicate play events don't re-resolve
    n = len(queries)
    out2 = await wh.handle(json.dumps(payload))
    check("second play = already_active, no new search", out2.get("action") == "already_active" and len(queries) == n, out2)

    # ── 4. real-time repair, same file ──
    newpath = fs._stub_path(hd)
    check("ready filename after switch", newpath.endswith(" - Ready.mkv"), newpath)
    fh = fs.open(newpath, 0)
    off = 5 * 1024 * 1024 + 123
    b = await th(newpath, off, 4096, fh)
    check("active read returns real bytes", b == expect_bytes(22, off, 4096))
    # link expires; AIOStreams now hands out a new URL for the same torrent file
    files["season_pack"]["dead"] = True
    add_file("season_pack_v2", 22)
    results[ep] = [res("season_pack_v2", fname="Show.S01E02.1080p.mkv", folder="Show.S01.1080p.WEB-DL", ih="AAA", idx=2),
                   res("episode", fname="Show.S01E02.1080p.mkv")]
    off2 = 40 * 1024 * 1024 + 7
    t0 = time.time()
    b = await th(newpath, off2, 4096, fh)
    check("broken link repaired in real time, same bytes", b == expect_bytes(22, off2, 4096),
          repr(b)[:80])
    check("stub now on new link", hd.stream_url.endswith("/season_pack_v2") and hd.state == StubState.ACTIVE)
    print(f"     repair took {time.time()-t0:.2f}s")

    # ── 5. repair to a DIFFERENT release mid-playback → EIO, next play ok ──
    files["season_pack_v2"]["dead"] = True
    results[ep] = [res("episode", fname="Show.S01E02.720p.mkv", size=SIZE)]
    files["episode"]["size"] = SIZE - 5 * 1024 * 1024   # genuinely different file
    results[ep][0]["size"] = files["episode"]["size"]
    b = await th(newpath, 60 * 1024 * 1024, 4096, fh)
    check("different release mid-stream → EIO (no garbage)", isinstance(b, OSError) and b.errno == errno.EIO, b)
    check("stub moved to the new release for the next play", hd.stream_url.endswith("/episode"), hd.stream_url)
    fs.release(newpath, fh)
    fh2 = fs.open(newpath, 0)
    b = await th(newpath, 0, 4096, fh2)
    check("fresh playback reads new release", b == expect_bytes(33, 0, 4096))
    fs.release(newpath, fh2)

    # ── 6. 24h refresh on playback ──
    hd.resolved_at = time.time() - 25 * 3600
    old_url = hd.stream_url
    add_file("episode_v3", 33, files["episode"]["size"])
    results[ep] = [res("episode_v3", fname="Show.S01E02.720p.mkv", size=files["episode"]["size"])]
    fh3 = fs.open(newpath, 0)
    b = await th(newpath, 1024, 2048, fh3)
    check("stale link still serves while refreshing", b == expect_bytes(33, 1024, 2048))
    for _ in range(50):
        if hd.stream_url != old_url:
            break
        await asyncio.sleep(0.1)
    check("link older than 24h replaced on playback", hd.stream_url.endswith("/episode_v3"), hd.stream_url)
    check("refresh reset link age", time.time() - hd.resolved_at < 60)
    fs.release(newpath, fh3)

    # stale via webhook too
    hd.resolved_at = time.time() - 30 * 3600
    res_._refresh_attempt_at.clear()
    out3 = await wh.handle(json.dumps(payload))
    check("webhook on stale active → refreshing", out3.get("action") == "refreshing", out3)
    await asyncio.sleep(1.0)
    check("webhook refresh completed", time.time() - hd.resolved_at < 60)

    # ── 7. everything dead → EIO + ERROR, no placeholder bytes mid-stream ──
    for f in files.values():
        f["dead"] = True
    fh4 = fs.open(newpath, 0)
    files_ok = await th(newpath, 0, 10, fh4)   # first read fails → repair fails
    check("all dead → read errors cleanly", isinstance(files_ok, OSError), files_ok)
    for _ in range(300):                     # repair may outlive the read's wait (re-search)
        if hd.state != StubState.RESOLVING:
            break
        await asyncio.sleep(0.1)
    check("stub marked ERROR", hd.state == StubState.ERROR, hd.state)
    fs.release(newpath, fh4)

    # ── 8. movie: request = placeholder; switch via /proxy-less resolver ──
    add_file("movie_a", 44)
    results["tt200"] = [res("movie_a", fname="Film.2021.DTS5.1.1080p.mkv")]
    mv = MediaItem(id="tt200", imdb_id="tt200", title="Film", year=2021, media_type=MediaType.MOVIE)
    mv.streams = await client.resolve_all(mv)
    check("DTS5.1 movie not misread as a pack", mv.streams[0].pack_type == ("episode", None), mv.streams[0].pack_type)
    ms = (await stubs.create_stubs(mv))[0]
    r = await res_.activate(ms.stub_id)
    check("movie switch", r.get("action") == "resolved" and ms.stream_url.endswith("/movie_a"), r)

    # concurrent plays → one resolve
    await stubs.revert_to_placeholder(ms.stub_id)
    q0 = len(queries)
    outs = await asyncio.gather(*(res_.on_play(ms.stub_id) for _ in range(5)))
    check("5 concurrent plays → 1 AIOStreams search", len(queries) - q0 == 1, (len(queries) - q0, outs))

    await client.close(); await r1.cleanup(); await r2.cleanup()

asyncio.run(main())
print("\n%d failure(s)" % len(failures))
sys.exit(1 if failures else 0)
