# Run: python tests/test_gate.py <path-to-aiogateway>
"""The AIOStreams queue must survive cancelled searches, and playback
searches must go ahead of queued background ones."""
import asyncio, sys, os, tempfile, json
from pathlib import Path
T = Path(tempfile.mkdtemp()); os.environ["FUSE_MOUNTPOINT"] = str(T / "mnt")
(T / "aiogateway_settings.json").write_text(json.dumps({"aiostreams_min_interval_ms": 300}))
sys.path.insert(0, sys.argv[1])
import gateway.aiostreams_client as AC

fails = []
def check(n, c, d=""):
    print(("PASS " if c else "FAIL ") + n + (f" — {d}" if d and not c else "")); c or fails.append(n)

async def main():
    g = AC._aiostreams_gate
    async with g: pass
    # cancelled while sleeping the spacing interval (the old leak)
    t = asyncio.create_task(g.__aenter__()); await asyncio.sleep(0.1); t.cancel()
    try: await t
    except asyncio.CancelledError: pass
    # cancelled while queued
    async with g:
        t2 = asyncio.create_task(g.__aenter__()); await asyncio.sleep(0.05); t2.cancel()
        try: await t2
        except asyncio.CancelledError: pass
    try:
        await asyncio.wait_for(g.__aenter__(), 3); await g.__aexit__(None, None, None)
        check("queue survives cancelled searches", True)
    except asyncio.TimeoutError:
        check("queue survives cancelled searches", False)

    # priority: 5 background searches queued, then a playback search
    order = []
    async def bg(i):
        async with g:
            order.append(f"bg{i}"); await asyncio.sleep(0.05)
    async def play():
        AC.play_priority.set(True)
        async with g:
            order.append("play")
    async with g:                      # hold the slot while everyone queues up
        tasks = [asyncio.create_task(bg(i)) for i in range(5)]
        await asyncio.sleep(0.05)
        tasks.append(asyncio.create_task(play()))
        await asyncio.sleep(0.05)
    await asyncio.gather(*tasks)
    check("playback search jumps the queue", order[0] == "play", order)

asyncio.run(main())
print(f"\n{len(fails)} failure(s)"); sys.exit(1 if fails else 0)
