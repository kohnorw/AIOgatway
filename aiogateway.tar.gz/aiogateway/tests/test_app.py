# Run: python tests/test_flow.py <path-to-aiogateway>   (needs fastapi, aiohttp, aiostream, requests, httpx)
"""App-level smoke test: boot main.py's lifespan, hit /webhook/plex and
/proxy, restart-restore of a resolved stub, and concurrent readers with
prefetch on when a link dies."""
import asyncio, json, os, sys, tempfile, time, threading
from pathlib import Path

SRC = sys.argv[1]
TMP = Path(tempfile.mkdtemp())
os.environ.update({
    "AIOSTREAMS_URL": "http://127.0.0.1:18911", "AIOSTREAMS_UUID": "u", "AIOSTREAMS_PASSWORD": "p",
    "FUSE_MOUNTPOINT": str(TMP / "mnt"), "FUSE_BLOCK_MB": "1", "FUSE_PREFETCH_AHEAD": "2",
    "FUSE_READ_TIMEOUT": "3", "AIOSTREAMS_CACHE_SECONDS": "0", "PLEX_URL": "", "PLEX_TOKEN": "",
    "AIOGW_API_KEY": "k",
})
(TMP / "aiogateway_settings.json").write_text(json.dumps({
    "aiostreams_min_interval_ms": 0, "_prewarm_backstop_migrated": True, "_prewarm_window_migrated": True}))
sys.path.insert(0, SRC)
os.chdir(SRC)

from aiohttp import web
import httpx

SIZE = 80 * 1024 * 1024
PAT = bytes(range(251)) * (2 * 1024 * 1024 // 251 + 2)
def data(seed, a, n):
    out = bytearray()
    while n > 0:
        k = min(n, 1024 * 1024); o = (a + seed) % 251; out += PAT[o:o + k]; a += k; n -= k
    return bytes(out)

dead = set(); results = {}; hits = []
async def cdn(req):
    p = req.match_info["p"]; hits.append(p)
    if p in dead: return web.Response(status=410)
    a, b = req.headers.get("Range", "bytes=0-").split("=")[1].split("-")
    a = int(a); b = min(int(b) if b else SIZE - 1, SIZE - 1)
    if a >= SIZE: return web.Response(status=416, headers={"Content-Range": f"bytes */{SIZE}"})
    return web.Response(status=206, body=data(7, a, b - a + 1),
                        headers={"Content-Range": f"bytes {a}-{b}/{SIZE}", "Content-Type": "video/mp4"})
async def search(req):
    return web.json_response({"success": True, "data": {"results": results.get(req.query["id"], []), "errors": []}})
def r(p, ih="H1"):
    return {"url": f"http://127.0.0.1:18912/f/{p}", "filename": "Film.2020.1080p.mkv", "size": SIZE,
            "cached": True, "infoHash": ih, "fileIdx": 0, "parsedFile": {"resolution": "1080p"}}

fails = []
def check(n, c, d=""):
    print(("PASS " if c else "FAIL ") + n + (f" — {d}" if d and not c else "")); c or fails.append(n)

async def main():
    a1 = web.Application(); a1.router.add_get("/api/v1/search", search)
    a2 = web.Application(); a2.router.add_get("/f/{p:.*}", cdn)
    for app, port in ((a1, 18911), (a2, 18912)):
        rr = web.AppRunner(app); await rr.setup(); await web.TCPSite(rr, "127.0.0.1", port).start()

    import main as M
    from gateway.models import MediaItem, MediaType, StubState
    from gateway import fuse_fs as F, resolver as R
    async with M.app.router.lifespan_context(M.app):
        check("resolver installed", R.get_instance() is M._resolver and M._resolver is not None)
        results["tt300"] = [r("a")]
        it = MediaItem(id="tt300", imdb_id="tt300", title="Film", year=2020, media_type=MediaType.MOVIE)
        it.streams = await M._client.resolve_all(it)
        st = (await M._stubs.create_stubs(it))[0]
        check("no prewarm on request", st.state == StubState.PLACEHOLDER)
        await asyncio.sleep(0.2)

        tr = httpx.ASGITransport(app=M.app)
        async with httpx.AsyncClient(transport=tr, base_url="http://t") as c:
            # webhook via guid fallback (no FUSE mount here)
            pl = {"event": "media.play", "Metadata": {"type": "movie", "Guid": [{"id": "imdb://tt300"}]}}
            resp = await c.post("/webhook/plex", files={"payload": (None, json.dumps(pl))})
            check("webhook endpoint switches placeholder", resp.json().get("action") == "resolved", resp.text)

            # proxy with a dead link → repaired + served
            dead.add("a"); results["tt300"] = [r("a"), r("b")]
            resp = await c.get(f"/proxy/{st.stub_id}", headers={"Range": "bytes=100-199"})
            check("proxy repairs dead link", resp.status_code == 206 and resp.content == data(7, 100, 100),
                  (resp.status_code, resp.content[:40]))

        # concurrent FUSE readers with prefetch while the link dies
        fs = F.AIOGatewayFS(M._stubs, M._client)
        path = fs._stub_path(st)
        fhs = [fs.open(path, 0) for _ in range(4)]
        dead.add("b"); results["tt300"] = [r("c")]
        def rd(i):
            off = (10 + i * 7) * 1024 * 1024 + 11
            return fs.read(path, 65536, off, fhs[i]) == data(7, off, 65536)
        oks = await asyncio.gather(*(asyncio.to_thread(rd, i) for i in range(4)))
        check("4 concurrent readers all repaired onto same file", all(oks), oks)
        check("one link swap, on c", st.stream_url.endswith("/c"), st.stream_url)

        # restart persistence
        sc = Path(st.abs_path).with_suffix(".aiogateway.json")
        d = json.loads(sc.read_text())
        check("file identity persisted", d.get("stream_file_id") == "h1:0" and d["state"] == "active", d.get("stream_file_id"))

    from gateway.stub_manager import StubManager
    sm = StubManager(); n = await sm.restore()
    s2 = sm.get(st.stub_id)
    check("restore keeps active link + identity", s2 and s2.state == StubState.ACTIVE and s2.stream_file_id == "h1:0")

asyncio.run(main())
print(f"\n{len(fails)} failure(s)"); sys.exit(1 if fails else 0)
