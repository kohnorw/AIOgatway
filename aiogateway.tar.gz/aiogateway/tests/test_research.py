# Run: python tests/test_research.py <path-to-aiogateway>   (needs aiohttp, aiostream, requests)
"""When every candidate of a playback search fails (e.g. all 403), the
switch runs a NEW fresh search and uses the links from that."""
import asyncio, json, os, sys, tempfile
from pathlib import Path

SRC = sys.argv[1]
TMP = Path(tempfile.mkdtemp())
os.environ.update({
    "AIOSTREAMS_URL": "http://127.0.0.1:18931", "AIOSTREAMS_UUID": "u", "AIOSTREAMS_PASSWORD": "p",
    "FUSE_MOUNTPOINT": str(TMP / "mnt"), "AIOSTREAMS_CACHE_SECONDS": "900",
    "PLEX_URL": "", "PLEX_TOKEN": "",
})
(TMP / "aiogateway_settings.json").write_text(json.dumps({
    "aiostreams_min_interval_ms": 0, "_prewarm_backstop_migrated": True, "_prewarm_window_migrated": True}))
sys.path.insert(0, SRC)

from aiohttp import web
from gateway.models import MediaItem, MediaType, StubState, Quality
from gateway.stub_manager import StubManager
from gateway.aiostreams_client import AIOStreamsClient
import gateway.aiostreams_client as AC
from gateway import resolver as R
AC._RESEARCH_DELAYS = (0.2, 0.2)

SIZE = 90 * 1024 * 1024
queries, probes = [], []
round_ = {"n": 0}
async def search(req):
    queries.append(req.query["id"]); round_["n"] += 1
    gen = round_["n"]
    res = [{"url": f"http://127.0.0.1:18932/cdn/g{gen}-{k}", "filename": f"Show.S06E01.{k}.1080p.mkv",
            "size": SIZE, "cached": True, "parsedFile": {"resolution": "1080p"}} for k in range(6)]
    return web.json_response({"success": True, "data": {"results": res, "errors": []}})
async def cdn(req):
    p = req.match_info["p"]; probes.append(p)
    if p.startswith("g1-") or p.startswith("g2-"):     # first two searches: every link refused
        return web.Response(status=403, text="Forbidden: link not allowed")
    return web.Response(status=206, body=b"\x1a", headers={"Content-Range": f"bytes 0-0/{SIZE}",
                                                             "Content-Type": "video/x-matroska"})

fails = []
def check(n, c, d=""):
    print(("PASS " if c else "FAIL ") + n + (f" — {d}" if d and not c else "")); c or fails.append(n)

async def main():
    for port, route, h in ((18931, "/api/v1/search", search), (18932, "/cdn/{p}", cdn)):
        a = web.Application(); a.router.add_get(route, h); rr = web.AppRunner(a); await rr.setup()
        await web.TCPSite(rr, "127.0.0.1", port).start()
    stubs = StubManager(); client = AIOStreamsClient(); await client.open()
    res = R.LinkResolver(stubs, client); res.bind_loop()
    it = MediaItem(id="tt5875444_s6e1", imdb_id="tt5875444", title="Slow Horses", show_title="Slow Horses",
                   year=2022, media_type=MediaType.SERIES, season=6, episode=1)
    st = (await stubs.create_placeholders(it))[0]

    # warm the search cache the way a request's 4K check would
    await client.resolve_all(it)
    q0 = len(queries)

    r = await res.activate(st.stub_id)
    check("switch succeeds after re-searching", r["action"] == "resolved", r)
    check("used a link from the third (fresh) search", st.stream_url.endswith("/cdn/g3-0"), st.stream_url)
    check("play did 2 fresh searches after the cached one", len(queries) - q0 == 2, queries)
    check("probes went one at a time, in order", probes[:6] == [f"g2-{k}" for k in range(6)], probes[:8])

    reason = AC.ProbeResult  # diagnostic text check
    pr = await AC.probe_stream(AC.AIOStream(url="http://127.0.0.1:18932/cdn/g1-0", filename=None, size=None,
                                             service=None, cached=None, parsed_file=None))
    check("refusal names the host and body", "from 127.0.0.1" in pr.reason and "Forbidden" in pr.reason, pr.reason)

    # never works → after the configured rounds it gives up with an error
    round_["n"] = -100   # all generations negative → g-… never matches "g1-"/"g2-"? force refusals instead:
    async def always_403(req):
        return web.Response(status=403)
    st.state = StubState.PLACEHOLDER; st.stream_url = None
    probes.clear(); q1 = len(queries)
    round_["n"] = 0
    import gateway.aiostreams_client as _ac
    orig = _ac.probe_stream
    async def dead(c): return _ac.ProbeResult(False, reason="HTTP 403 from cdn")
    _ac.probe_stream = dead
    r = await res.activate(st.stub_id)
    _ac.probe_stream = orig
    check("gives up after 3 searches", r["action"] == "error" and len(queries) - q1 == 3, (r, len(queries) - q1))
    check("stub left in ERROR for retry on next play", st.state == StubState.ERROR)
    await client.close()

asyncio.run(main())
print(f"\n{len(fails)} failure(s)"); sys.exit(1 if fails else 0)
