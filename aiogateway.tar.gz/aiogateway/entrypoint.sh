#!/bin/sh
# Clear any FUSE mount left behind by a previous crash, then start the app.
set -e

DATA_DIR="${AIOGW_DATA:-/docker/aiogateway}"
MOUNTPOINT="${AIOGW_MOUNTPOINT:-$DATA_DIR/mnt}"

if grep -qs "$MOUNTPOINT" /proc/mounts; then
    echo "Stale FUSE mount at $MOUNTPOINT — unmounting"
    fusermount -uz "$MOUNTPOINT" 2>/dev/null || umount -l "$MOUNTPOINT" 2>/dev/null || true
    sleep 0.5
fi

mkdir -p "$MOUNTPOINT" "$DATA_DIR"

exec uvicorn main:app --host 0.0.0.0 --port "${AIOGW_PORT:-8001}"
