#!/bin/sh
# entrypoint.sh — clean up any stale FUSE mount from a previous crash, then start.

LIBRARY="${LIBRARY_ROOT:-/library}"
LIBRARY_REAL="${LIBRARY_REAL_ROOT:-${LIBRARY}_real}"

# If /library is already mounted (from a previous container crash), unmount it
# so FUSE can re-mount cleanly on startup.
if grep -qs "$LIBRARY" /proc/mounts; then
    echo "Stale FUSE mount detected at $LIBRARY — unmounting..."
    fusermount -uz "$LIBRARY" 2>/dev/null || umount -l "$LIBRARY" 2>/dev/null || true
    sleep 0.5
fi

# Make sure both the mountpoint and its real backing dir exist.
mkdir -p "$LIBRARY" "$LIBRARY_REAL"

exec uvicorn main:app --host 0.0.0.0 --port 8001
