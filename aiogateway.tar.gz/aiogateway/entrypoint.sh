#!/bin/sh
# Clear any FUSE mount left behind by a previous crash, then start.
set -e

DATA_DIR="${AIOGW_DATA:-/docker/aiogateway}"
MOUNTPOINT="${AIOGW_MOUNTPOINT:-$DATA_DIR/mnt}"

if grep -qs " $MOUNTPOINT " /proc/mounts; then
    echo "Stale FUSE mount at $MOUNTPOINT — clearing it"
    fusermount -u "$MOUNTPOINT" 2>/dev/null \
        || fusermount -uz "$MOUNTPOINT" 2>/dev/null \
        || umount -l "$MOUNTPOINT" 2>/dev/null \
        || true
    sleep 0.5
fi

mkdir -p "$MOUNTPOINT" "$DATA_DIR"

# exec so uvicorn becomes PID 1 and receives SIGTERM directly. Without
# it the signal stops at this shell, uvicorn never unwinds its lifespan,
# and the mount is still there when the container is killed.
exec uvicorn main:app \
    --host 0.0.0.0 \
    --port "${AIOGW_PORT:-8001}" \
    --timeout-graceful-shutdown 30
