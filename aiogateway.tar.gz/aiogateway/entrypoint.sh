#!/bin/sh
# entrypoint.sh — clean up any stale FUSE mount from a previous crash, then start.

MOUNTPOINT="${FUSE_MOUNTPOINT:-/docker/aiogateway/mnt}"

# Clean up any stale FUSE mount from a previous container crash
if grep -qs "$MOUNTPOINT" /proc/mounts; then
    echo "Stale FUSE mount detected at $MOUNTPOINT — unmounting..."
    fusermount -uz "$MOUNTPOINT" 2>/dev/null || umount -l "$MOUNTPOINT" 2>/dev/null || true
    sleep 0.5
fi

# Ensure the mountpoint directory exists
mkdir -p "$MOUNTPOINT"

exec uvicorn main:app --host 0.0.0.0 --port 8001
