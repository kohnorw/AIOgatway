"""
api/config_routes.py
~~~~~~~~~~~~~~~~~~~~
Everything behind the Config page. Admin only, throughout.

One tab per section of the runbook: Connections, Users, FUSE, Streams,
Migrate, Repair, Backup/Restore.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from api import state
from gateway import arr, auth, backup, config, debrid, plex, repair, settings
from gateway.aiostreams import AIOStreamsError
from gateway.arr import ArrError
from gateway.debrid.base import DebridError
from gateway.paths import mountpoint
from gateway.plex import PlexError

logger = logging.getLogger("aiogateway.api.config")
router = APIRouter(dependencies=[Depends(state.require_admin)])


# ── Connections ─────────────────────────────────────────────────────────
@router.get("/api/config/connections")
async def get_connections(request: Request):
    view = config.public_view()
    return {
        "aiostreams": {
            "url": view["aiostreams_url"],
            "url_set": view["aiostreams_url_set"],
            "uuid": view["aiostreams_uuid"],
            "uuid_set": view["aiostreams_uuid_set"],
            "password_set": view["aiostreams_password_set"],
        },
        "plex": {
            "url": view["plex_url"],
            "url_set": view["plex_url_set"],
            "token_set": view["plex_token_set"],
        },
        "webhook_url": f"{request.base_url}webhook/plex".replace("//webhook", "/webhook"),
        "mountpoint": mountpoint(),
        "library_folders": [f"{mountpoint()}/{name}" for name in
                            ("Movies", "Movies4K", "Series", "Series4K")],
    }


@router.get("/api/config/plex/sections")
async def plex_sections():
    """Shown next to the folder list so the user can see at a glance
    whether Plex has actually been pointed at the mount yet."""
    try:
        return {"sections": await plex.sections()}
    except Exception as exc:
        raise HTTPException(502, str(exc))


# ── Users ───────────────────────────────────────────────────────────────
@router.get("/api/users")
async def list_users(page: int = 1, page_size: Optional[int] = None, q: str = ""):
    return auth.list_users(page=page, page_size=page_size, query=q)


class RoleChange(BaseModel):
    role: str


@router.post("/api/users/{plex_user_id}/role")
async def change_role(plex_user_id: str, body: RoleChange):
    try:
        if not auth.set_role(plex_user_id, body.role):
            raise HTTPException(404, "No such account")
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"ok": True, "role": body.role}


@router.delete("/api/users/{plex_user_id}")
async def delete_user(plex_user_id: str):
    try:
        if not auth.delete_user(plex_user_id):
            raise HTTPException(404, "No such account")
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"ok": True}


# ── Settings (FUSE + Streams share this) ────────────────────────────────
@router.get("/api/settings")
async def get_settings():
    return settings.all_settings()


@router.post("/api/settings")
async def update_settings(patch: dict[str, Any]):
    unknown = [k for k in patch if k not in settings.DEFAULTS]
    if unknown:
        raise HTTPException(400, f"Unknown setting: {', '.join(unknown)}")
    return settings.update(patch)


# ── Streams: debrid services ────────────────────────────────────────────
@router.get("/api/debrid")
async def list_debrid():
    return {"services": debrid.catalogue()}


class DebridForm(BaseModel):
    api_key: Optional[str] = None
    enabled: Optional[bool] = None
    rpm: Optional[float] = None
    concurrency: Optional[int] = None
    spacing_ms: Optional[float] = None


@router.post("/api/debrid/{service_key}")
async def save_debrid(service_key: str, form: DebridForm):
    if service_key not in debrid.SERVICES:
        raise HTTPException(404, "No such service")
    updates: dict[str, Any] = {}
    if form.api_key is not None:
        updates[f"debrid_{service_key}_api_key"] = form.api_key
    if form.enabled is not None:
        updates[f"debrid_{service_key}_enabled"] = bool(form.enabled)
    if form.rpm is not None:
        updates[f"debrid_{service_key}_rpm"] = max(1, float(form.rpm))
    if form.concurrency is not None:
        updates[f"debrid_{service_key}_concurrency"] = max(1, int(form.concurrency))
    if form.spacing_ms is not None:
        updates[f"debrid_{service_key}_spacing_ms"] = max(0, float(form.spacing_ms))
    config.set_many(updates)
    return {"ok": True, "services": debrid.catalogue()}


@router.post("/api/debrid/{service_key}/test")
async def test_debrid(service_key: str, form: DebridForm):
    if service_key not in debrid.SERVICES:
        raise HTTPException(404, "No such service")
    api_key = form.api_key
    if not api_key or api_key.startswith("•"):
        api_key = config.debrid_key(service_key)
    if not api_key:
        raise HTTPException(400, "Enter an API key first")
    try:
        return await debrid.test_service(service_key, api_key)
    except DebridError as exc:
        raise HTTPException(400, str(exc))
    except Exception as exc:
        raise HTTPException(502, f"Could not reach {debrid.SERVICES[service_key].name}: {exc}")


# ── Connections: retest saved credentials ───────────────────────────────
@router.post("/api/config/test/aiostreams")
async def retest_aiostreams():
    try:
        return await state.need_client().test()
    except AIOStreamsError as exc:
        raise HTTPException(400, str(exc))


@router.post("/api/config/test/plex")
async def retest_plex():
    try:
        return await plex.test()
    except PlexError as exc:
        raise HTTPException(400, str(exc))


# ── Migrate ─────────────────────────────────────────────────────────────
class ArrForm(BaseModel):
    service: str
    url: str = ""
    api_key: str = ""


@router.get("/api/migrate/settings")
async def migrate_settings():
    view = config.public_view()
    return {
        "radarr": {"url": view["radarr_url"], "url_set": view["radarr_url_set"],
                   "key_set": view["radarr_api_key_set"]},
        "sonarr": {"url": view["sonarr_url"], "url_set": view["sonarr_url_set"],
                   "key_set": view["sonarr_api_key_set"]},
    }


@router.post("/api/migrate/test")
async def migrate_test(form: ArrForm):
    if form.service not in ("radarr", "sonarr"):
        raise HTTPException(400, "Choose Radarr or Sonarr")
    url = form.url.strip() or config.secret(f"{form.service}_url")
    api_key = form.api_key
    if not api_key or api_key.startswith("•"):
        api_key = config.secret(f"{form.service}_api_key")
    try:
        result = await arr.test(form.service, url, api_key)
    except ArrError as exc:
        raise HTTPException(400, str(exc))
    # Only saved once it has actually answered, so a bad URL never gets
    # stored as if it were working.
    config.set_many({f"{form.service}_url": url, f"{form.service}_api_key": api_key})
    return result


@router.get("/api/migrate/library")
async def migrate_library(service: str):
    if service not in ("radarr", "sonarr"):
        raise HTTPException(400, "Choose Radarr or Sonarr")
    library = state.need_library()
    try:
        items = await arr.library(service)
    except ArrError as exc:
        raise HTTPException(400, str(exc))

    existing = {e.imdb_id for e in library.all()}
    for item in items:
        item["already_here"] = item["imdb_id"] in existing
    return {
        "service": service,
        "items": items,
        "total": len(items),
        "new": sum(1 for i in items if not i["already_here"]),
    }


class MigrateRun(BaseModel):
    service: str
    imdb_ids: Optional[list[str]] = None
    skip_existing: bool = True


@router.post("/api/migrate/run")
async def migrate_run(body: MigrateRun):
    if body.service not in ("radarr", "sonarr"):
        raise HTTPException(400, "Choose Radarr or Sonarr")
    library = state.need_library()
    try:
        items = await arr.library(body.service)
    except ArrError as exc:
        raise HTTPException(400, str(exc))

    if body.imdb_ids is not None:
        wanted = set(body.imdb_ids)
        items = [i for i in items if i["imdb_id"] in wanted]
    if body.skip_existing:
        existing = {e.imdb_id for e in library.all()}
        items = [i for i in items if i["imdb_id"] not in existing]
    if not items:
        raise HTTPException(400, "Nothing selected that isn't already here")

    job = await arr.run_migration(body.service, items, state.need_media())
    return job.to_dict()


@router.get("/api/migrate/status/{job_id}")
async def migrate_status(job_id: str):
    job = arr.job(job_id)
    if job is None:
        raise HTTPException(404, "No such migration")
    return job.to_dict()


@router.post("/api/migrate/cancel/{job_id}")
async def migrate_cancel(job_id: str):
    if not arr.cancel(job_id):
        raise HTTPException(404, "That migration isn't running")
    return {"ok": True}


# ── Repair ──────────────────────────────────────────────────────────────
@router.get("/api/repair/status")
async def repair_status():
    return state.need_repairer().status()


class RepairSchedule(BaseModel):
    enabled: Optional[bool] = None
    mode: Optional[str] = None
    times: Optional[list[str]] = None
    interval_hours: Optional[float] = None
    batch_size: Optional[int] = None
    pause_on_playback: Optional[bool] = None
    max_failures: Optional[int] = None


@router.post("/api/repair/schedule")
async def repair_schedule(body: RepairSchedule):
    patch: dict[str, Any] = {}
    if body.enabled is not None:
        patch["repair_enabled"] = bool(body.enabled)
    if body.mode is not None:
        if body.mode not in ("daily", "interval"):
            raise HTTPException(400, "Mode must be daily or interval")
        patch["repair_mode"] = body.mode
    if body.times is not None:
        cleaned = []
        for value in body.times:
            parts = str(value).strip().split(":")
            try:
                hour, minute = int(parts[0]), int(parts[1])
                if not (0 <= hour < 24 and 0 <= minute < 60):
                    raise ValueError
            except Exception:
                raise HTTPException(400, f"'{value}' isn't a time like 04:00")
            cleaned.append(f"{hour:02d}:{minute:02d}")
        if not cleaned:
            raise HTTPException(400, "Set at least one time")
        patch["repair_times"] = sorted(set(cleaned))
    if body.interval_hours is not None:
        patch["repair_interval_hours"] = max(0.25, float(body.interval_hours))
    if body.batch_size is not None:
        patch["repair_batch_size"] = max(0, int(body.batch_size))
    if body.pause_on_playback is not None:
        patch["repair_pause_on_playback"] = bool(body.pause_on_playback)
    if body.max_failures is not None:
        patch["repair_max_failures"] = max(0, int(body.max_failures))

    settings.update(patch)
    repairer = state.need_repairer()
    due = repair.next_run_at()
    repairer.next_due = due.timestamp() if due else None
    return repairer.status()


@router.post("/api/repair/run")
async def repair_run():
    repairer = state.need_repairer()
    if repairer.current is not None:
        raise HTTPException(409, "A repair pass is already running")
    import asyncio
    asyncio.create_task(repairer.run_pass("manual"))
    return {"ok": True, "started": True}


@router.post("/api/repair/cancel")
async def repair_cancel():
    if not state.need_repairer().cancel():
        raise HTTPException(404, "Nothing is running")
    return {"ok": True}


# ── Backup / Restore ────────────────────────────────────────────────────
@router.get("/api/backup")
async def download_backup():
    payload = backup.create(state.need_library())
    return JSONResponse(
        payload,
        headers={"Content-Disposition": 'attachment; filename="aiogateway-backup.json"'},
    )


class RestoreBody(BaseModel):
    payload: dict
    replace: bool = False


@router.post("/api/restore")
async def restore_backup(body: RestoreBody):
    try:
        result = backup.restore(state.need_library(), body.payload,
                                replace=body.replace)
    except ValueError as exc:
        raise HTTPException(400, str(exc))

    # A backup carries no links, so everything it restored needs one.
    # Start straight away rather than waiting for the loop's next tick —
    # the person is sitting there watching the restore finish.
    import asyncio
    asyncio.create_task(state.need_media().acquire_missing_links(limit=0))
    result["acquiring"] = True
    return result


@router.post("/api/links/acquire")
async def acquire_links():
    """Fetch links for anything still missing one, now."""
    return await state.need_media().acquire_missing_links(limit=0)
