"""
api/setup_routes.py
~~~~~~~~~~~~~~~~~~~
The first-start wizard, and sign-in.

The wizard asks for two connections and gives each a Test button and a
Submit button. Test doesn't save; Submit does. Keeping those separate
means a typo is caught while the person is still looking at the field,
rather than being stored and rediscovered later as a mysteriously broken
library.

These routes are deliberately reachable without a session — there is no
account to sign into until Plex has been configured, since that's what
membership is checked against.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Request, Response
from pydantic import BaseModel

from api import state
from gateway import auth, backup, config, plex
from gateway.aiostreams import AIOStreamsError
from gateway.plex import PlexError

logger = logging.getLogger("aiogateway.api.setup")
router = APIRouter()


class AIOStreamsForm(BaseModel):
    url: str = ""
    uuid: str = ""
    password: str = ""


class PlexForm(BaseModel):
    url: str = ""
    token: str = ""


def _fallback(value: str, stored_key: str) -> str:
    """A masked field coming back from the UI means 'leave it alone', so
    fall back to what's already stored rather than testing against dots."""
    if not value or value.startswith("•"):
        return config.secret(stored_key)
    return value.strip()


@router.get("/api/setup/status")
async def setup_status():
    return {
        "setup_complete": bool(config.get("setup_complete")) and config.is_configured(),
        "aiostreams_set": bool(config.secret("aiostreams_url") and config.secret("aiostreams_uuid")),
        "plex_set": bool(config.secret("plex_url") and config.secret("plex_token")),
        "has_users": auth.admin_count() > 0,
    }


@router.post("/api/setup/aiostreams/test")
async def test_aiostreams(form: AIOStreamsForm):
    try:
        return await state.need_client().test(
            _fallback(form.url, "aiostreams_url"),
            _fallback(form.uuid, "aiostreams_uuid"),
            _fallback(form.password, "aiostreams_password"),
        )
    except AIOStreamsError as exc:
        raise HTTPException(400, str(exc))


@router.post("/api/setup/aiostreams")
async def save_aiostreams(form: AIOStreamsForm):
    url = _fallback(form.url, "aiostreams_url")
    uuid = _fallback(form.uuid, "aiostreams_uuid")
    password = _fallback(form.password, "aiostreams_password")
    if not url or not uuid:
        raise HTTPException(400, "The URL and UUID are both needed")

    config.set_many({
        "aiostreams_url": url,
        "aiostreams_uuid": uuid,
        "aiostreams_password": password,
    })
    _maybe_complete()
    return {"ok": True, "saved": True}


@router.post("/api/setup/plex/test")
async def test_plex(form: PlexForm):
    try:
        return await plex.test(
            _fallback(form.url, "plex_url"),
            _fallback(form.token, "plex_token"),
        )
    except PlexError as exc:
        raise HTTPException(400, str(exc))


@router.post("/api/setup/plex")
async def save_plex(form: PlexForm):
    url = _fallback(form.url, "plex_url")
    token = _fallback(form.token, "plex_token")
    if not url or not token:
        raise HTTPException(400, "The URL and token are both needed")

    config.set_many({"plex_url": url, "plex_token": token})
    _maybe_complete()
    return {"ok": True, "saved": True}


def _maybe_complete() -> None:
    if config.is_configured() and not config.get("setup_complete"):
        config.set_many({"setup_complete": True})
        logger.info("Setup complete")


class WizardRestore(BaseModel):
    payload: dict


@router.post("/api/setup/restore")
async def setup_restore(body: WizardRestore):
    """Restore a backup during first-start, before any account exists.

    This is the only way an old backup's saved connection details are
    actually useful. The normal restore lives behind an admin session,
    but signing in requires Plex to be configured — so by the time you
    could reach it you'd have already retyped everything the backup was
    holding.

    Unauthenticated, and therefore fenced hard: it refuses once either
    connection is configured or any account exists. That is the same
    window the wizard itself is open in, so it grants nothing the wizard
    doesn't already grant, and it closes permanently the moment setup
    finishes.
    """
    if config.is_configured() or auth.admin_count() > 0:
        raise HTTPException(
            403,
            "This install is already set up. Restore from Config → "
            "Backup/Restore instead.",
        )
    try:
        result = backup.restore(state.need_library(), body.payload, replace=True)
    except ValueError as exc:
        raise HTTPException(400, str(exc))

    _maybe_complete()
    result["setup_complete"] = bool(config.get("setup_complete")) and config.is_configured()
    return result


# ── sign-in ─────────────────────────────────────────────────────────────
def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for", "")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


@router.post("/api/auth/plex/start")
async def auth_start(request: Request):
    try:
        return await auth.start_login(_client_ip(request))
    except PermissionError as exc:
        raise HTTPException(429, str(exc))
    except Exception as exc:
        raise HTTPException(502, f"Plex sign-in unavailable: {exc}")


@router.get("/api/auth/plex/poll/{pin_id}")
async def auth_poll(pin_id: str, request: Request, response: Response):
    try:
        result = await auth.poll_login(
            pin_id, request.headers.get("user-agent", ""), _client_ip(request))
    except PermissionError as exc:
        raise HTTPException(403, str(exc))
    except Exception as exc:
        raise HTTPException(400, str(exc))

    if result is None:
        return {"pending": True}

    response.set_cookie(
        auth.SESSION_COOKIE, result["session_token"],
        httponly=True, samesite="strict",
        secure=auth.cookie_is_secure(request),
        max_age=int(auth.SESSION_MAX_AGE_DAYS * 86400),
        path="/",
    )
    return {"pending": False, "user": result["user"]}


@router.get("/api/auth/me")
async def auth_me(request: Request):
    user = state.current_user(request)
    if user is None:
        return {"authenticated": False}
    return {"authenticated": True, "user": user}


@router.post("/api/auth/logout")
async def auth_logout(request: Request, response: Response):
    auth.destroy_session(request.cookies.get(auth.SESSION_COOKIE))
    response.delete_cookie(auth.SESSION_COOKIE, path="/")
    return {"ok": True}
