"""
api/media_routes.py
~~~~~~~~~~~~~~~~~~~
Home, Search, Calendar and Library.

Browsing and searching are open to any signed-in account. Changing the
library — adding or removing titles — needs an admin, matching the
existing split where a plain user gets Home, Search and Calendar.
"""
from __future__ import annotations

import asyncio
import logging
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from api import state
from gateway import cinemeta, requests as reqs
from gateway.aiostreams import AIOStreamsError
from gateway.paths import mountpoint
from gateway.models import MediaType, Quality

logger = logging.getLogger("aiogateway.api.media")
router = APIRouter(dependencies=[Depends(state.require_user)])
admin_router = APIRouter(dependencies=[Depends(state.require_admin)])


# ── browse ──────────────────────────────────────────────────────────────
@router.get("/api/catalog/{kind}")
async def catalog(kind: str, name: str = "top", skip: int = 0):
    if kind not in ("movie", "series"):
        raise HTTPException(400, "kind must be movie or series")
    return {"metas": await cinemeta.catalog(kind, name, skip)}


@router.get("/api/search")
async def search(q: str, kind: str = "all"):
    query = (q or "").strip()
    if len(query) < 2:
        return {"metas": []}

    kinds = ("movie", "series") if kind == "all" else (kind,)
    for value in kinds:
        if value not in ("movie", "series"):
            raise HTTPException(400, "kind must be movie, series or all")

    results = await asyncio.gather(*(cinemeta.search(k, query) for k in kinds))
    metas = []
    for kind_name, rows in zip(kinds, results):
        for row in rows:
            row.setdefault("type", kind_name)
            metas.append(row)
    return {"metas": metas}


@router.get("/api/meta/{kind}/{imdb_id}")
async def meta(kind: str, imdb_id: str, refresh: bool = False):
    if kind not in ("movie", "series"):
        raise HTTPException(400, "kind must be movie or series")
    record = await cinemeta.meta(kind, imdb_id, refresh=refresh)
    if not record:
        raise HTTPException(404, "No metadata for that title")

    library = state.need_library()
    entries = library.for_imdb(imdb_id)
    payload = {
        "meta": record,
        "in_library": bool(entries),
        "pending": reqs.is_pending_movie(imdb_id),
        "watching": reqs.is_season_watched(imdb_id),
        "wanted_seasons": sorted(reqs.wanted_seasons_for(imdb_id)),
    }

    if kind == "series":
        episodes = cinemeta.episodes_of(record)
        have = {(e.season, e.episode) for e in entries}
        seasons: dict[int, dict] = {}
        for episode in episodes:
            bucket = seasons.setdefault(episode["season"], {"total": 0, "have": 0})
            bucket["total"] += 1
            if (episode["season"], episode["episode"]) in have:
                bucket["have"] += 1
        for number in reqs.wanted_seasons_for(imdb_id):
            # A season with nothing aired has no episodes to count, so it
            # would otherwise not appear in the picker at all — and the
            # person who requested it would have no way to see that it
            # was registered.
            seasons.setdefault(number, {"total": 0, "have": 0})
        wanted = reqs.wanted_seasons_for(imdb_id)
        payload["seasons"] = [
            {"season": number, "wanted": number in wanted, **counts}
            for number, counts in sorted(seasons.items())
        ]
        payload["episodes"] = episodes
    else:
        payload["qualities"] = sorted({e.quality.value for e in entries})
    return payload


# ── library ─────────────────────────────────────────────────────────────
@router.get("/api/library")
async def list_library():
    """Every title in the library, plus everything being tracked toward it.

    Returns the whole set rather than a page. The Library view splits
    Movies and TV Shows into two sections that page independently, so
    neither one maps onto a single server-side page number — and a group
    is a handful of small fields, so sending the lot is cheaper than the
    round trips paging them separately would cost.

    Tracking entries (a pending film, a season registered before it
    aired, a show under season-watch) come back as groups too. They
    describe a *status*, not a separate title: if the title already has
    real files, the status is attached to that group rather than
    creating a second card for the same thing.
    """
    library = state.need_library()

    groups: dict[str, dict] = {}

    def group_for(imdb_id, title, media_type, year=None, poster=""):
        g = groups.get(imdb_id)
        if g is None:
            g = {
                "imdb_id": imdb_id, "title": title, "year": year,
                "poster": poster, "media_type": media_type,
                "files": 0, "activated": 0, "needs_repair": 0,
                "qualities": set(), "seasons": set(),
                "added_at": None, "added_by": "",
                "pending": False, "wanted_seasons": [], "watching": False,
            }
            groups[imdb_id] = g
        if poster and not g["poster"]:
            g["poster"] = poster
        if year and not g["year"]:
            g["year"] = year
        return g

    for entry in library.all():
        g = group_for(entry.imdb_id,
                      entry.show_title or entry.title,
                      entry.media_type.value, entry.year, entry.poster)
        g["files"] += 1
        g["qualities"].add(entry.quality.value)
        if entry.season:
            g["seasons"].add(entry.season)
        if entry.activated:
            g["activated"] += 1
        if entry.state.value == "missing":
            g["needs_repair"] += 1
        if g["added_at"] is None or entry.created_at < g["added_at"]:
            g["added_at"] = entry.created_at
        if entry.added_by and not g["added_by"]:
            g["added_by"] = entry.added_by

    for row in reqs.list_pending_movies():
        g = group_for(row["imdb_id"], row.get("title") or row["imdb_id"],
                      "movie", row.get("year"), row.get("poster", ""))
        g["pending"] = True
        g["added_at"] = g["added_at"] or row.get("requested_at")
        g["added_by"] = g["added_by"] or row.get("requested_by", "")

    for row in reqs.list_wanted_seasons():
        g = group_for(row["imdb_id"], row.get("title") or row["imdb_id"],
                      "series", row.get("year"), row.get("poster", ""))
        g["wanted_seasons"].append(row["season"])
        g["added_at"] = g["added_at"] or row.get("requested_at")
        g["added_by"] = g["added_by"] or row.get("requested_by", "")

    for row in reqs.list_season_watch():
        g = group_for(row["imdb_id"], row.get("title") or row["imdb_id"],
                      "series", row.get("year"), row.get("poster", ""))
        g["watching"] = True
        g["added_at"] = g["added_at"] or row.get("enabled_at")

    waiting: dict[str, int] = {}
    for row in reqs.list_waiting_episodes():
        waiting[row["imdb_id"]] = waiting.get(row["imdb_id"], 0) + 1

    items = []
    for g in groups.values():
        g["qualities"] = sorted(g["qualities"])
        g["seasons"] = sorted(g["seasons"])
        g["wanted_seasons"] = sorted(g["wanted_seasons"])
        g["waiting_episodes"] = waiting.get(g["imdb_id"], 0)
        # A group with no files at all is being tracked, not held.
        g["tracking_only"] = g["files"] == 0
        items.append(g)

    items.sort(key=lambda g: (g["title"] or "").lower())
    counts = library.counts()
    return {
        "items": items,
        "total": len(items),
        "counts": counts,
        "movies": sum(1 for g in items if g["media_type"] != "series"),
        "series": sum(1 for g in items if g["media_type"] == "series"),
    }


@router.get("/api/library/missing-counts")
async def missing_counts():
    """Aired episodes a tracked season doesn't have a file for.

    Fetched separately and after the first paint, because it needs
    metadata for every series in the library and the grid shouldn't wait
    on that to draw. Scoped to seasons that actually have files, so a
    season nobody asked for never counts as missing just because
    Cinemeta lists it.
    """
    library = state.need_library()
    out: dict[str, int] = {}

    for imdb_id in sorted(library.series_ids()):
        entries = library.for_imdb(imdb_id)
        have = {(e.season, e.episode) for e in entries if e.season and e.episode}
        tracked = {e.season for e in entries if e.season}
        if not tracked:
            continue
        try:
            record = await cinemeta.meta("series", imdb_id)
        except Exception:
            continue
        if not record:
            continue
        missing = 0
        for episode in cinemeta.episodes_of(record):
            if episode["season"] not in tracked:
                continue
            if not cinemeta.has_aired(episode["released"]):
                continue
            if (episode["season"], episode["episode"]) not in have:
                missing += 1
        if missing:
            out[imdb_id] = missing
    return {"counts": out}


@router.get("/api/library/{imdb_id}")
async def library_detail(imdb_id: str, page: int = 1, page_size: int = 25,
                         season: Optional[int] = None, quality: str = "all"):
    """Files for one title, paginated.

    A long-running series can hold several hundred episodes across both
    qualities. Returning the lot made the detail view slow to open and
    impossible to find anything in, so it pages and can be narrowed to a
    single season.
    """
    library = state.need_library()
    entries = library.for_imdb(imdb_id)
    if not entries:
        raise HTTPException(404, "Not in the library")

    first = entries[0]
    seasons = sorted({e.season for e in entries if e.season})

    rows = entries
    if season is not None:
        rows = [e for e in rows if e.season == season]
    if quality in ("hd", "4k"):
        rows = [e for e in rows if e.quality.value == quality]

    rows.sort(key=lambda e: (e.season or 0, e.episode or 0, e.quality.value))

    page_size = max(1, min(int(page_size), 200))
    total = len(rows)
    pages = max(1, (total + page_size - 1) // page_size)
    page = max(1, min(int(page), pages))
    start = (page - 1) * page_size

    return {
        "imdb_id": imdb_id,
        "title": first.show_title or first.title,
        "media_type": first.media_type.value,
        "poster": first.poster,
        "seasons": seasons,
        "page": page,
        "pages": pages,
        "total": total,
        "page_size": page_size,
        "counts": {
            "all": len(entries),
            "hd": sum(1 for e in entries if e.quality.value == "hd"),
            "4k": sum(1 for e in entries if e.quality.value == "4k"),
        },
        "entries": [{
            "entry_id": e.entry_id,
            "name": e.display_name,
            "quality": e.quality.value,
            "season": e.season,
            "episode": e.episode,
            "state": e.state.value,
            "activated": e.activated,
            "activated_at": e.activated_at,
            "size": e.size,
            "source": e.source_filename,
            "service": e.source_service,
            "has_link": bool(e.url),
            "pinned": e.pinned,
            "path": e.virtual_path,
            "last_repair_at": e.last_repair_at,
            "repair_failures": e.repair_failures,
        } for e in rows[start:start + page_size]],
    }


# ── calendar ────────────────────────────────────────────────────────────
@router.get("/api/calendar")
async def calendar(days_back: int = 14, days_ahead: int = 45, refresh: bool = False):
    """Everything tracked that releases inside the window.

    Covers three things, not just one:

      - episodes of series in the library, from per-episode air dates,
        which are accurate because streaming shows air and go digital on
        the same day;
      - films in the library and films still on order, from the release
        date, which is the *theatrical* one and is labelled as such —
        there's no free source for the digital date and it can be weeks
        later;
      - seasons registered as wanted, at their first episode's air date,
        so something you asked for before it started airing is visible
        on the day it does.

    `refresh` re-fetches metadata rather than redisplaying what's
    cached — the "this looks wrong, go and check" path. Without it the
    page can only ever show what it already had.
    """
    library = state.need_library()
    now = datetime.now(timezone.utc)
    window_start = now - timedelta(days=max(0, days_back))
    window_end = now + timedelta(days=max(0, days_ahead))

    def parse(value) -> Optional[datetime]:
        if not value:
            return None
        try:
            when = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except ValueError:
            return None
        return when.replace(tzinfo=timezone.utc) if when.tzinfo is None else when

    def in_window(when: Optional[datetime]) -> bool:
        return bool(when) and window_start <= when <= window_end

    # One pass over the library for every lookup below, rather than each
    # title rescanning the whole thing.
    series_ids: set[str] = set()
    movie_ids: set[str] = set()
    have_episodes: set[tuple] = set()
    have_movies: set[str] = set()
    poster_by_id: dict[str, str] = {}
    title_by_id: dict[str, str] = {}

    for entry in library.all():
        if not entry.imdb_id:
            continue
        if entry.media_type == MediaType.SERIES:
            series_ids.add(entry.imdb_id)
            if entry.season and entry.episode:
                have_episodes.add((entry.imdb_id, entry.season, entry.episode))
        else:
            movie_ids.add(entry.imdb_id)
            have_movies.add(entry.imdb_id)
        if entry.poster:
            poster_by_id.setdefault(entry.imdb_id, entry.poster)
        title_by_id.setdefault(entry.imdb_id, entry.show_title or entry.title)

    # Things on order belong on the calendar too — a film that isn't out
    # is exactly the kind of thing someone opens this page to look for.
    pending = {r["imdb_id"]: r for r in reqs.list_pending_movies()}
    wanted = reqs.list_wanted_seasons()
    movie_ids |= set(pending)
    series_ids |= {r["imdb_id"] for r in wanted}
    for record in list(pending.values()) + wanted:
        if record.get("poster"):
            poster_by_id.setdefault(record["imdb_id"], record["poster"])
        if record.get("title"):
            title_by_id.setdefault(record["imdb_id"], record["title"])

    wanted_by_show: dict[str, set[int]] = {}
    for record in wanted:
        wanted_by_show.setdefault(record["imdb_id"], set()).add(record["season"])

    series_meta, series_failed = await cinemeta.meta_many(
        "series", sorted(series_ids), refresh=refresh)
    movie_meta, movie_failed = await cinemeta.meta_many(
        "movie", sorted(movie_ids), refresh=refresh)

    entries = []

    for imdb_id, record in series_meta.items():
        title = title_by_id.get(imdb_id) or record.get("name") or imdb_id
        poster = poster_by_id.get(imdb_id) or record.get("poster", "")
        age = cinemeta.age_of("series", imdb_id)
        show_wanted = wanted_by_show.get(imdb_id, set())
        for episode in cinemeta.episodes_of(record):
            when = parse(episode["released"])
            if not in_window(when):
                continue
            key = (imdb_id, episode["season"], episode["episode"])
            entries.append({
                "kind": "episode",
                "imdb_id": imdb_id,
                "title": title,
                "poster": poster,
                "season": episode["season"],
                "episode": episode["episode"],
                "episode_title": episode["title"],
                "year": cinemeta.year_of(record),
                "date": when.date().isoformat(),
                "timestamp": when.timestamp(),
                "in_library": key in have_episodes,
                "requested": episode["season"] in show_wanted,
                "future": when > now,
                # Accurate for series: streaming shows air and go digital
                # on the same date.
                "date_type": "air date",
                "meta_age": age,
            })

    for imdb_id, record in movie_meta.items():
        when = parse(record.get("released"))
        if not in_window(when):
            continue
        entries.append({
            "kind": "movie",
            "imdb_id": imdb_id,
            "title": record.get("name") or title_by_id.get(imdb_id) or imdb_id,
            "poster": record.get("poster") or poster_by_id.get(imdb_id, ""),
            "year": cinemeta.year_of(record),
            "date": when.date().isoformat(),
            "timestamp": when.timestamp(),
            "in_library": imdb_id in have_movies,
            "requested": imdb_id in pending,
            "future": when > now,
            # Deliberately labelled: this is the cinema date, and a
            # digital copy can be weeks behind it. No free source has the
            # digital date, so the honest thing is to say which one this
            # is rather than imply a precision that isn't there.
            "date_type": "cinema release",
            "meta_age": cinemeta.age_of("movie", imdb_id),
        })

    entries.sort(key=lambda e: (e["timestamp"], e["title"]))

    failures = []
    for row in series_failed + movie_failed:
        failures.append({**row, "title": title_by_id.get(row["imdb_id"], row["imdb_id"])})

    ages = [e["meta_age"] for e in entries if e.get("meta_age") is not None]
    return {
        "entries": entries,
        "from": window_start.date().isoformat(),
        "to": window_end.date().isoformat(),
        "days_back": days_back,
        "days_ahead": days_ahead,
        "generated_at": now.timestamp(),
        "refreshed": refresh,
        # The oldest metadata behind anything on screen. If this is large,
        # the dates shown are old news however recently the page loaded.
        "oldest_meta_age": max(ages) if ages else None,
        # Surfaced, not swallowed. A calendar missing a show looks
        # complete and correct while being neither.
        "unavailable": failures,
    }


# ── manual stream selection ─────────────────────────────────────────────
# Search results are held server-side and the client picks by index.
#
# The alternative — letting the browser post back a full candidate — would
# mean accepting an arbitrary URL and request headers from the client and
# writing them into a file Plex will stream. Handing back an opaque token
# keeps the set of reachable URLs to exactly what AIOStreams just returned.
_manual_results: dict[str, dict] = {}
_MANUAL_TTL = 900


def _prune_manual() -> None:
    now = time.time()
    for token in [t for t, r in _manual_results.items() if now - r["at"] > _MANUAL_TTL]:
        _manual_results.pop(token, None)


def _candidate_row(index: int, cand, current_hash: Optional[str]) -> dict:
    parsed = cand.parsed
    return {
        "index": index,
        "filename": cand.filename or "(unnamed release)",
        "size": cand.size,
        "service": cand.service,
        "addon": cand.addon,
        "resolution": (parsed.resolution if parsed else None),
        "quality": (parsed.quality if parsed else None),
        "encode": (parsed.encode if parsed else None),
        "hdr": (parsed.hdr if parsed else []),
        "languages": (parsed.languages if parsed else []),
        "audio": (parsed.audio_tags if parsed else []),
        "is_4k": cand.is_4k,
        "usenet": cand.is_usenet,
        "cached": cand.is_cached,
        # None means nobody could give a verdict, which is different from
        # a confirmed no — the UI labels the two differently.
        "cached_verified": cand.cached_verified,
        "info_hash": cand.info_hash,
        "current": bool(current_hash and cand.info_hash
                        and cand.info_hash.lower() == current_hash.lower()),
    }


@admin_router.get("/api/streams")
async def browse_streams(imdb_id: str, kind: str = "movie",
                         season: Optional[int] = None,
                         episode: Optional[int] = None,
                         quality: str = "all"):
    """List every stream available for one title, for manual selection."""
    if kind not in ("movie", "series"):
        raise HTTPException(400, "kind must be movie or series")
    if kind == "series" and (season is None or episode is None):
        raise HTTPException(400, "A series needs a season and episode")
    if quality not in ("all", "hd", "4k"):
        raise HTTPException(400, "quality must be all, hd or 4k")

    media = state.need_media()
    library = state.need_library()
    wanted = None if quality == "all" else Quality(quality)

    try:
        item, candidates = await media.manual_search(
            imdb_id, kind, season, episode, wanted)
    except AIOStreamsError as exc:
        raise HTTPException(502, str(exc))

    # What's in use right now, per quality, so the list can mark it.
    current = {}
    for q in (Quality.HD, Quality.UHD):
        entry = library.by_media(item.media_id, q)
        if entry is not None:
            current[q.value] = {
                "entry_id": entry.entry_id,
                "info_hash": entry.info_hash,
                "filename": entry.source_filename,
                "size": entry.size,
                "service": entry.source_service,
                "pinned": entry.pinned,
                "activated": entry.activated,
            }

    _prune_manual()
    token = uuid.uuid4().hex[:16]
    _manual_results[token] = {"at": time.time(), "item": item, "candidates": candidates}

    rows = []
    for i, cand in enumerate(candidates):
        q = "4k" if cand.is_4k else "hd"
        rows.append(_candidate_row(i, cand, (current.get(q) or {}).get("info_hash")))

    return {
        "token": token,
        "title": item.title,
        "media_id": item.media_id,
        "kind": kind,
        "season": season,
        "episode": episode,
        "streams": rows,
        "counts": {
            "all": len(rows),
            "hd": sum(1 for r in rows if not r["is_4k"]),
            "4k": sum(1 for r in rows if r["is_4k"]),
        },
        "current": current,
    }


class SelectStream(BaseModel):
    token: str
    index: int


@admin_router.post("/api/streams/select")
async def select_stream(body: SelectStream, user: dict = Depends(state.require_admin)):
    """Swap in a chosen stream, creating the file if it doesn't exist."""
    _prune_manual()
    cached = _manual_results.get(body.token)
    if cached is None:
        raise HTTPException(
            410, "Those results have expired. Search again and pick from the new list.")
    candidates = cached["candidates"]
    if not 0 <= body.index < len(candidates):
        raise HTTPException(400, "That stream isn't in the result list")

    candidate = candidates[body.index]
    # Quality comes from the stream itself, not from the client: a 2160p
    # release belongs in Movies4K whatever list it was picked from.
    quality = candidate.quality
    entry = state.need_media().apply_manual_choice(
        cached["item"], quality, candidate, added_by=user["username"])

    return {
        "ok": True,
        "entry_id": entry.entry_id,
        "quality": quality.value,
        "path": entry.virtual_path,
        "filename": entry.source_filename,
        "size": entry.size,
        "created": entry.source_filename == candidate.filename,
    }



class AddBody(BaseModel):
    imdb_id: str
    kind: str = "movie"
    seasons: Optional[list[int]] = None
    # Keep tracking this show's future seasons indefinitely, so a new
    # season is picked up without anyone having to ask again.
    watch_for_new_seasons: bool = False


@admin_router.post("/api/add")
async def add(body: AddBody, user: dict = Depends(state.require_admin)):
    media = state.need_media()
    if body.kind not in ("movie", "series"):
        raise HTTPException(400, "kind must be movie or series")
    try:
        if body.kind == "movie":
            return await media.add_movie(body.imdb_id, added_by=user["username"])
        return await media.add_series(
            body.imdb_id, body.seasons, added_by=user["username"],
            watch_for_new_seasons=body.watch_for_new_seasons)
    except ValueError as exc:
        raise HTTPException(404, str(exc))
    except Exception as exc:
        logger.error("Add failed for %s: %s", body.imdb_id, exc)
        raise HTTPException(502, str(exc))


@admin_router.delete("/api/library/{imdb_id}")
async def remove_title(imdb_id: str, quality: Optional[str] = None,
                       season: Optional[int] = None):
    library = state.need_library()
    removed = library.remove_title(
        imdb_id,
        Quality(quality) if quality else None,
        season,
    )
    if not removed:
        raise HTTPException(404, "Nothing matched")
    library.save()
    return {"ok": True, "removed": removed}


@admin_router.delete("/api/entry/{entry_id}")
async def remove_entry(entry_id: str):
    library = state.need_library()
    if not library.remove(entry_id):
        raise HTTPException(404, "No such file")
    library.save()
    return {"ok": True}


@admin_router.post("/api/entry/{entry_id}/repair")
async def repair_entry(entry_id: str):
    """Refresh one file's link now, without waiting for the schedule."""
    library = state.need_library()
    if library.get(entry_id) is None:
        raise HTTPException(404, "No such file")
    result = await state.need_repairer().run_pass("manual", {entry_id})
    return result


@router.get("/api/status")
async def status():
    library = state.need_library()
    repairer = state.need_repairer()
    return {
        "library": library.counts(),
        "mounted": state.mounted,
        "mountpoint": mountpoint(),
        "repair": repairer.status(),
        "requests": reqs.summary(),
    }
