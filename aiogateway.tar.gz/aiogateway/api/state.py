"""
api/state.py
~~~~~~~~~~~~
The long-lived objects, and the dependencies that guard routes.

Built once in main.py's lifespan and read from here, so routers don't
have to import main and create a cycle.
"""
from __future__ import annotations

from typing import Optional

from fastapi import HTTPException, Request

from gateway import auth
from gateway.aiostreams import AIOStreamsClient
from gateway.library import Library
from gateway.repair import Repairer
from gateway.service import MediaService
from webhook.handler import PlexWebhook

library: Optional[Library] = None
client: Optional[AIOStreamsClient] = None
media: Optional[MediaService] = None
repairer: Optional[Repairer] = None
webhook: Optional[PlexWebhook] = None
mounted: bool = False


def need_library() -> Library:
    if library is None:
        raise HTTPException(503, "Still starting up")
    return library


def need_media() -> MediaService:
    if media is None:
        raise HTTPException(503, "Still starting up")
    return media


def need_client() -> AIOStreamsClient:
    if client is None:
        raise HTTPException(503, "Still starting up")
    return client


def need_repairer() -> Repairer:
    if repairer is None:
        raise HTTPException(503, "Still starting up")
    return repairer


def current_user(request: Request) -> Optional[dict]:
    token = request.cookies.get(auth.SESSION_COOKIE)
    return auth.validate_session(token, request.headers.get("user-agent", ""))


def require_user(request: Request) -> dict:
    user = current_user(request)
    if user is None:
        raise HTTPException(401, "Sign in to continue")
    return user


def require_admin(request: Request) -> dict:
    user = require_user(request)
    if user.get("role") != "admin":
        raise HTTPException(403, "This needs an admin account")
    return user
