"""
api/request_routes.py
~~~~~~~~~~~~~~~~~~~~~
The Requests page: what's been asked for but isn't here yet.

Viewing is open to any signed-in account, since a user who requested
something should be able to see where it got to. Cancelling a request or
running a sweep by hand is admin-only, matching the rest of the app.
"""
from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from api import state
from gateway import requests as reqs

logger = logging.getLogger("aiogateway.api.requests")
router = APIRouter(dependencies=[Depends(state.require_user)])
admin_router = APIRouter(dependencies=[Depends(state.require_admin)])


@router.get("/api/requests")
async def list_requests():
    library = state.need_library()

    pending = reqs.list_pending_movies()
    waiting = reqs.list_waiting_episodes()
    wanted = reqs.list_wanted_seasons()
    watching = reqs.list_season_watch()

    # How many files each watched show already has, so the UI can say
    # "watching for season 5" next to something rather than just listing
    # a title with no context.
    for record in watching:
        entries = library.for_imdb(record["imdb_id"])
        record["files"] = len(entries)
        record["seasons"] = sorted({e.season for e in entries if e.season})

    return {
        "pending_movies": pending,
        "waiting_episodes": waiting,
        "wanted_seasons": wanted,
        "season_watch": watching,
        "summary": reqs.summary(),
    }


@admin_router.delete("/api/requests/movie/{imdb_id}")
async def cancel_pending_movie(imdb_id: str):
    if not reqs.remove_pending_movie(imdb_id):
        raise HTTPException(404, "That film isn't being tracked")
    return {"ok": True}


@admin_router.delete("/api/requests/season/{imdb_id}/{season}")
async def cancel_wanted_season(imdb_id: str, season: int):
    if not reqs.remove_wanted_season(imdb_id, season):
        raise HTTPException(404, "That season isn't being tracked")
    return {"ok": True}


@admin_router.delete("/api/requests/episode/{imdb_id}/{season}/{episode}")
async def cancel_waiting_episode(imdb_id: str, season: int, episode: int):
    reqs.clear_waiting_episode(imdb_id, season, episode)
    reqs.save()
    return {"ok": True}


class WatchBody(BaseModel):
    title: str = ""
    poster: str = ""
    year: Optional[int] = None


@admin_router.post("/api/requests/watch/{imdb_id}")
async def enable_watch(imdb_id: str, body: WatchBody,
                       user: dict = Depends(state.require_admin)):
    """Keep tracking this show's future seasons indefinitely.

    Falls back to whatever is already in the library for the title and
    poster, so the caller doesn't have to supply them — the Library page
    has them to hand, the Calendar doesn't.
    """
    library = state.need_library()
    entries = library.for_imdb(imdb_id)
    title = body.title or next((e.show_title or e.title for e in entries), "") or imdb_id
    poster = body.poster or next((e.poster for e in entries if e.poster), "")
    year = body.year or next((e.year for e in entries if e.year), None)

    created = reqs.enable_season_watch(imdb_id, title, poster, year, user["username"])
    return {"ok": True, "watching": True, "already": not created, "title": title}


@admin_router.delete("/api/requests/watch/{imdb_id}")
async def disable_watch(imdb_id: str):
    if not reqs.disable_season_watch(imdb_id):
        raise HTTPException(404, "That show isn't being watched")
    return {"ok": True, "watching": False}


@router.get("/api/requests/watch/{imdb_id}")
async def watch_status(imdb_id: str):
    return {
        "watching": reqs.is_season_watched(imdb_id),
        "wanted_seasons": sorted(reqs.wanted_seasons_for(imdb_id)),
        "pending": reqs.is_pending_movie(imdb_id),
    }


@admin_router.post("/api/requests/sweep")
async def sweep_now(kind: str = "all"):
    """Run the sweeps now rather than waiting for the schedule. Forced,
    so this works even with the recurring behaviour switched off."""
    media = state.need_media()
    result = {}
    if kind in ("all", "episodes"):
        result["episodes"] = await media.discover_episodes(force=True)
    if kind in ("all", "movies"):
        result["movies"] = await media.sweep_pending_movies(force=True)
    if not result:
        raise HTTPException(400, "kind must be all, episodes or movies")
    return result
