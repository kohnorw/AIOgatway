"""Request front end (http://<host>:8770/): browse/search Cinemeta, request titles.

A request adds the title to the Plex libraries (placeholders only) and runs a
background 4K check; titles with 4K also appear in the 4K libraries.
"""
import logging
import os

from aiohttp import web

from . import clients, config, db, library

log = logging.getLogger("aio.requests")


def _status(item):
    if not item:
        return {"in_library": False}
    key = item["key"]
    s4k = sorted(db.seasons_4k(key)) if item["kind"] == "show" else []
    return {
        "in_library": True, "key": key, "kind": item["kind"],
        "has_4k": bool(item.get("has_4k")) or bool(s4k), "seasons_4k": s4k,
        "checking_4k": key in library.checking_4k,
    }


async def cinemeta(req):
    path = req.match_info["path"]
    try:
        async with clients.session().get(f"{config.CINEMETA_URL}/{path}") as r:
            return web.json_response(await r.json(content_type=None), status=r.status)
    except Exception as e:  # noqa: BLE001
        return web.json_response({"error": f"Cinemeta unreachable: {e}"}, status=502)


async def status(req):
    ids = [i for i in req.query.get("ids", "").split(",") if i]
    return web.json_response({i: _status(db.find_by_imdb(i)) for i in ids[:200]})


async def library_list(_):
    out = []
    for it in sorted(db.all_items(), key=lambda i: -i["added_at"]):
        out.append({"imdb": it.get("imdb"), "title": it["title"], "year": it.get("year"),
                    "poster": it.get("poster"), "requested_by": it.get("requested_by"),
                    "added_at": it.get("added_at"), **_status(it)})
    return web.json_response(out)


async def request_title(req):
    b = await req.json()
    sid, stype = (b.get("id") or "").strip(), b.get("type", "movie")
    if not sid.startswith("tt"):
        return web.json_response({"error": "expected an IMDb id (tt...)"}, status=400)
    try:
        key, new = await library.add_stremio(sid, "movie" if stype == "movie" else "series", "request")
    except Exception as e:  # noqa: BLE001
        log.warning("request %s failed: %s", sid, e)
        return web.json_response({"error": str(e)}, status=502)
    if not key:
        return web.json_response({"error": "not found on TMDB"}, status=404)
    user = req.get("user") or {}
    if user.get("username"):
        db.set_requested_by(key, user["username"])
    log.info("requested %s (%s) by %s%s", sid, key, user.get("username", "?"), "" if new else " - already in library")
    return web.json_response({"new": new, **_status(db.get_item(key))})


async def recheck_4k(req):
    key = req.match_info["key"]
    item = db.get_item(key)
    if not item:
        return web.json_response({"error": "unknown item"}, status=404)
    fn = library.check_4k_movie if item["kind"] == "movie" else library.check_4k_show
    library._bg(fn(key), key)
    return web.json_response(_status(db.get_item(key)))


async def remove(req):
    library.remove(req.match_info["key"])
    return web.json_response({"ok": True})


async def page(_):
    return web.Response(text=PAGE, content_type="text/html")


def routes(app: web.Application):
    app.router.add_get("/", page)
    app.router.add_get("/api/cinemeta/{path:.*}", cinemeta)
    app.router.add_get("/api/status", status)
    app.router.add_get("/api/library", library_list)
    app.router.add_post("/api/request", request_title)
    app.router.add_post("/api/items/{key}/check-4k", recheck_4k)
    app.router.add_delete("/api/items/{key}", remove)


_STATIC = os.path.join(os.path.dirname(__file__), "static")


def _build_page() -> str:
    with open(os.path.join(_STATIC, "requests.html"), encoding="utf-8") as f:
        html = f.read()
    with open(os.path.join(_STATIC, "aiogw.css"), encoding="utf-8") as f:
        css = f.read()
    return html.replace("/*__AIOGW_CSS__*/", css)


PAGE = _build_page()
