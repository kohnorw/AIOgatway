"""Request front end (http://<host>:8770/): browse/search Cinemeta, request titles.

A request adds the title to the Plex libraries (placeholders only) and runs a
background 4K check; titles with 4K also appear in the 4K libraries.
"""
import logging
import os
import re
import time
import urllib.parse

import aiohttp

from aiohttp import web

from . import clients, config, db, library, naming, vfs

log = logging.getLogger("aio.requests")

# Episodes that aired within this window count as "new" (badge + filter).
NEW_EPISODE_DAYS = 7


def _status(item, new_stats=None):
    if not item:
        return {"in_library": False}
    key = item["key"]
    out = {"in_library": True, "key": key, "kind": item["kind"], "checking_4k": key in library.checking_4k}
    if item["kind"] == "show":
        s4k = sorted(db.seasons_4k(key))
        out.update(has_4k=bool(s4k), seasons_4k=s4k, monitor=item.get("monitor") or "all",
                   monitor_since=item.get("monitor_since"),
                   seasons=sorted(library.wanted_seasons(key)),
                   requested_seasons=sorted(db.requested_seasons(key)),
                   tv_status=item.get("status"), ended=library.ended(item))
        if new_stats is None:
            new_stats = db.new_episode_stats(time.time() - NEW_EPISODE_DAYS * 86400)
        n, last = new_stats.get(key, (0, None))
        # Tracking = new episodes will keep arriving on their own.
        out.update(new_episodes=n, last_episode_at=last,
                   tracking=not out["ended"] and out["monitor"] in ("all", "new"))
    else:
        out.update(has_4k=bool(item.get("has_4k")), seasons_4k=[])
    return out


async def cinemeta(req):
    path = req.match_info["path"]
    try:
        async with clients.session().get(f"{config.CINEMETA_URL}/{path}") as r:
            return web.json_response(await r.json(content_type=None), status=r.status)
    except Exception as e:  # noqa: BLE001
        return web.json_response({"error": f"Cinemeta unreachable: {e}"}, status=502)


async def status(req):
    ids = [i for i in req.query.get("ids", "").split(",") if i]
    return web.json_response({i: _status(db.find_by_imdb(i)) for i in ids[:200]})


async def library_list(_):
    out = []
    stats = db.new_episode_stats(time.time() - NEW_EPISODE_DAYS * 86400)
    for it in sorted(db.all_items(), key=lambda i: -i["added_at"]):
        out.append({"imdb": it.get("imdb"), "title": it["title"], "year": it.get("year"),
                    "poster": it.get("poster"), "requested_by": it.get("requested_by"),
                    "added_at": it.get("added_at"), **_status(it, stats)})
    return web.json_response(out)


async def episodes(req):
    """Every known episode of a show (aired and upcoming), with whether it's in Plex."""
    key = req.match_info["key"]
    item = db.get_item(key)
    if not item or item["kind"] != "show":
        return web.json_response({"error": "unknown show"}, status=404)
    req_seasons = db.requested_seasons(key)
    excluded = db.excluded_seasons(key)
    hidden = db.hidden_episodes(key)
    s4k = db.seasons_4k(key)
    new_since = time.time() - NEW_EPISODE_DAYS * 86400
    eps = []
    for e in db.episodes(key):
        if e["season"] <= 0:
            continue
        aired = naming.aired(e.get("air_date"))
        sn, en = e["season"], e["episode"]
        wanted = naming.wanted_episode(item, sn, e.get("air_date"), req_seasons, excluded)
        rel = naming.released(item, e)
        waiting = aired and wanted and not rel
        has_hd = rel and wanted and (sn, en, False) not in hidden
        has_4k = rel and wanted and sn in s4k and (sn, en, True) not in hidden
        streams = {}
        for q, on in (("hd", has_hd), ("4k", has_4k)):
            st = db.get_stream(naming.stream_key_episode(item, sn, en, q == "4k")) if on else None
            if st and st.get("url"):
                streams[q] = {"filename": st.get("filename"), "size": st.get("size")}
        eps.append({"season": sn, "episode": en, "title": e.get("title"),
                    "air_date": e.get("air_date"), "aired": aired, "wanted": wanted,
                    "in_library": has_hd or has_4k, "has_hd": has_hd, "has_4k": has_4k,
                    "season_4k": sn in s4k, "streams": streams, "waiting": waiting,
                    "air_ts": e.get("air_ts"), "next_check": e.get("next_check") if waiting else None,
                    "gave_up": waiting and library.gave_up(e),
                    "new": bool(e.get("announced_at") and e["announced_at"] >= new_since)})
    return web.json_response({"episodes": eps, "excluded_seasons": sorted(excluded), **_status(item)})


# --- per-episode / per-movie stream management (same actions as aiogateway) -------

_RES_RE = re.compile(r"\b(2160p|1440p|1080p|720p|576p|480p)\b", re.I)
_ENC_RE = re.compile(r"\b(hevc|x265|h\.?265|avc|x264|h\.?264|av1)\b", re.I)
_HDR_RE = re.compile(r"\b(DV|Dolby ?Vision|HDR10\+?|HDR)\b", re.I)


def _stream_key(req, item):
    q = req.query.get("q") or req.match_info.get("q") or "hd"
    if q not in ("hd", "4k"):
        raise web.HTTPBadRequest(text="q must be hd or 4k")
    if item["kind"] == "movie":
        return naming.stream_key_movie(item, q == "4k")
    try:
        season, episode = int(req.query["season"]), int(req.query["episode"])
    except (KeyError, ValueError):
        raise web.HTTPBadRequest(text="season and episode are required")
    return naming.stream_key_episode(item, season, episode, q == "4k")


def _fmt_candidate(st):
    hints = st.get("behaviorHints") or {}
    sd = st.get("streamData") or {}
    pf = sd.get("parsedFile") or {}
    text = " ".join(str(x) for x in (st.get("name"), st.get("title"), st.get("description"), hints.get("filename")) if x)
    size = hints.get("videoSize") or sd.get("size")
    raw_svc = sd.get("service")
    svc = (raw_svc.get("id") or raw_svc.get("name")) if isinstance(raw_svc, dict) else raw_svc
    cached = raw_svc.get("cached") if isinstance(raw_svc, dict) else sd.get("cached")
    if cached is None:
        cached = True if "⚡" in text or "[+]" in text else (False if "⏳" in text else None)
    res = pf.get("resolution") or (_RES_RE.search(text).group(1) if _RES_RE.search(text) else None)
    hdr = pf.get("visualTags") or pf.get("hdr") or [m.group(1) for m in _HDR_RE.finditer(text)][:2]
    return {"url": st.get("url"), "filename": hints.get("filename") or sd.get("filename") or (st.get("title") or st.get("name") or "").split("\n")[0],
            "size": size, "size_gb": round(size / 1024 ** 3, 2) if size else None,
            "resolution": res, "encode": pf.get("encode") or (_ENC_RE.search(text).group(1) if _ENC_RE.search(text) else None),
            "hdr": " ".join(hdr) if isinstance(hdr, list) else hdr, "service": svc, "cached": cached,
            "stream_type": sd.get("type"), "quality": "4k" if vfs.is_4k(st) else "hd",
            "pack": vfs.pack_type(st)[0] if vfs.pack_type(st)[0] != "episode" else None}


async def stream_candidates(req):
    """AIOStreams results for one file, plus which one is pinned now."""
    item = db.get_item(req.match_info["key"])
    if not item:
        return web.json_response({"error": "unknown item"}, status=404)
    skey = _stream_key(req, item)
    stype, sid, uhd = naming.split_stream_key(skey)
    if not config.AIOSTREAMS_MANIFEST_URL:
        return web.json_response({"error": "AIOStreams isn't configured"}, status=400)
    base = clients.addon_base(config.AIOSTREAMS_MANIFEST_URL)
    try:
        async with clients.session().get(f"{base}/stream/{stype}/{urllib.parse.quote(sid, safe=':')}.json",
                                         timeout=aiohttp.ClientTimeout(total=60)) as r:
            r.raise_for_status()
            data = await r.json(content_type=None)
    except Exception as e:  # noqa: BLE001
        return web.json_response({"error": f"AIOStreams: {e}"}, status=502)
    cur = db.get_stream(skey) or {}
    out = []
    streams = data.get("streams") or []
    if stype == "series" and config.PREFER_PACKS:      # list in the order playback would try them
        season = int(sid.split(":")[-2])
        streams = sorted(streams, key=lambda st: vfs._pack_tier(st, season))
    allowed = {id(x) for x in vfs.filter_streams(streams)}
    for st in streams:
        if not (st.get("url") or "").startswith("http") or vfs.is_4k(st) != uhd:
            continue
        c = _fmt_candidate(st)
        c["filtered"] = id(st) not in allowed
        c["languages"] = sorted(vfs.stream_languages(st))
        c["is_current"] = bool(cur.get("url") and (c["url"] == cur["url"] or (c["filename"] and c["filename"] == cur.get("filename"))))
        out.append(c)
    return web.json_response({"current_url": cur.get("url"), "current_filename": cur.get("filename"), "candidates": out})


async def stream_select(req):
    item = db.get_item(req.match_info["key"])
    if not item:
        return web.json_response({"error": "unknown item"}, status=404)
    skey = _stream_key(req, item)
    b = await req.json()
    url = (b.get("url") or "").strip()
    if not url.startswith("http"):
        return web.json_response({"error": "url required"}, status=400)
    db.set_stream(skey, url, b.get("size"), b.get("filename") or None)
    if item["kind"] == "show":
        sn, en = int(req.query["season"]), int(req.query["episode"])
        db.set_episode_available(item["key"], sn, en, True)        # a stream was picked by hand
        library.set_episode_file(item["key"], sn, en, skey.endswith(naming.UHD_SUFFIX), True)
        library._announce_visible(item["key"], track_new=True)
    log.info("stream for %s set by hand -> %s", skey, b.get("filename") or url)
    return web.json_response({"ok": True})


async def stream_clear(req):
    """Forget the pinned link; the next play resolves a fresh one."""
    item = db.get_item(req.match_info["key"])
    if not item:
        return web.json_response({"error": "unknown item"}, status=404)
    db.delete_stream(_stream_key(req, item))
    return web.json_response({"ok": True})


async def episode_file(req):
    """DELETE: remove one episode's HD or 4K file. POST: bring it back."""
    key = req.match_info["key"]
    item = db.get_item(key)
    if not item or item["kind"] != "show":
        return web.json_response({"error": "unknown show"}, status=404)
    q = req.match_info["q"]
    if q not in ("hd", "4k"):
        return web.json_response({"error": "q must be hd or 4k"}, status=400)
    library.set_episode_file(key, int(req.match_info["season"]), int(req.match_info["episode"]),
                             q == "4k", req.method == "POST")
    return web.json_response({"ok": True})


async def remove_season(req):
    key = req.match_info["key"]
    item = db.get_item(key)
    if not item or item["kind"] != "show":
        return web.json_response({"error": "unknown show"}, status=404)
    library.remove_season(key, int(req.match_info["season"]))
    return web.json_response(_status(db.get_item(key)))


async def request_title(req):
    b = await req.json()
    sid, stype = (b.get("id") or "").strip(), b.get("type", "movie")
    mode = b.get("mode", "all")
    if mode not in ("all", "new", "seasons"):
        return web.json_response({"error": "mode must be all, new or seasons"}, status=400)
    seasons = [int(n) for n in (b.get("seasons") or []) if str(n).isdigit()]
    if mode == "seasons" and not seasons and stype != "movie":
        return web.json_response({"error": "pick at least one season"}, status=400)
    if not sid.startswith("tt"):
        return web.json_response({"error": "expected an IMDb id (tt...)"}, status=400)
    try:
        key, new = await library.add_stremio(sid, "movie" if stype == "movie" else "series", "request", mode, seasons)
    except Exception as e:  # noqa: BLE001
        log.warning("request %s failed: %s", sid, e)
        return web.json_response({"error": str(e)}, status=502)
    if not key:
        return web.json_response({"error": "not found on TMDB"}, status=404)
    user = req.get("user") or {}
    if user.get("username"):
        db.set_requested_by(key, user["username"])
    log.info("requested %s (%s) by %s%s", sid, key, user.get("username", "?"), "" if new else " - already in library")
    return web.json_response({"new": new, **_status(db.get_item(key))})


async def recheck_4k(req):
    key = req.match_info["key"]
    item = db.get_item(key)
    if not item:
        return web.json_response({"error": "unknown item"}, status=404)
    if item["kind"] == "movie":
        library._bg(library.check_4k_movie(key), key)
    else:
        season = req.query.get("season")
        library._bg(library.check_4k_show(key, {int(season)} if season and season.isdigit() else None), key)
    return web.json_response(_status(db.get_item(key)))


async def remove(req):
    library.remove(req.match_info["key"])
    return web.json_response({"ok": True})


async def page(_):
    return web.Response(text=PAGE, content_type="text/html")


def routes(app: web.Application):
    app.router.add_get("/", page)
    app.router.add_get("/api/cinemeta/{path:.*}", cinemeta)
    app.router.add_get("/api/status", status)
    app.router.add_get("/api/library", library_list)
    app.router.add_post("/api/request", request_title)
    app.router.add_post("/api/items/{key}/check-4k", recheck_4k)
    app.router.add_get("/api/items/{key}/episodes", episodes)
    app.router.add_get("/api/items/{key}/stream", stream_candidates)
    app.router.add_post("/api/items/{key}/stream", stream_select)
    app.router.add_delete("/api/items/{key}/stream", stream_clear)
    app.router.add_post("/api/items/{key}/episodes/{season}/{episode}/{q}", episode_file)
    app.router.add_delete("/api/items/{key}/episodes/{season}/{episode}/{q}", episode_file)
    app.router.add_delete("/api/items/{key}/seasons/{season}", remove_season)
    app.router.add_delete("/api/items/{key}", remove)


_STATIC = os.path.join(os.path.dirname(__file__), "static")


def _build_page() -> str:
    with open(os.path.join(_STATIC, "requests.html"), encoding="utf-8") as f:
        html = f.read()
    with open(os.path.join(_STATIC, "aiogw.css"), encoding="utf-8") as f:
        css = f.read()
    return html.replace("/*__AIOGW_CSS__*/", css)


PAGE = _build_page()
