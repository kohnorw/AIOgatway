"""Read-only FUSE filesystem at /media/aio (pyfuse3 + trio).

Modelled on aiogateway's fuse_fs.py:

* Placeholder vs real is decided on a handle's FIRST READ, not by who opened
  it. A read is real playback only if Plex's /status/sessions lists a session
  on this exact file (polled up to FUSE_PLAY_DETECT_SECONDS). The scanner,
  analyzer and thumbnailer never appear as sessions, so they get placeholder
  bytes and never trigger an AIOStreams lookup.
* Handles are sticky: a handle that got placeholder bytes keeps getting them;
  a handle that got real bytes never falls back to placeholder (EIO instead).
* getattr always reports the real size once known, else 50 GB, and the
  placeholder clip is zero-padded past its end, so Plex never caps reads at
  the clip length.
* Real reads go through an 8 MB block LRU cache with prefetch and de-duplicated
  fetches; broken links (401/403/404/410, error bodies served as 200, servers
  ignoring Range) are repaired by re-resolving through AIOStreams, preferring
  the same file.
"""
import errno
import logging
import os
import stat
import sys
import time
import urllib.parse
from collections import OrderedDict

import httpx
import pyfuse3
import trio

from . import clients, config, db, vfs

log = logging.getLogger("aio.fs")

# ── tuning (same knobs as aiogateway) ─────────────────────────────────────────
BLOCK = int(os.environ.get("FUSE_BLOCK_MB", "8")) * 1024 * 1024
CACHE_BLOCKS = int(os.environ.get("FUSE_CACHE_BLOCKS", "32"))
PREFETCH_AHEAD = int(os.environ.get("FUSE_PREFETCH_AHEAD", "2"))
READ_TIMEOUT = float(os.environ.get("FUSE_READ_TIMEOUT", "15"))
READ_ATTEMPTS = max(1, int(os.environ.get("FUSE_READ_ATTEMPTS", "3")))
MAX_INFLIGHT = int(os.environ.get("FUSE_MAX_INFLIGHT", "6"))
PLAY_DETECT_S = float(os.environ.get("FUSE_PLAY_DETECT_SECONDS", "4"))
# false (default): every non-scanner read is treated as playback and streams the
# real file. true: additionally require a matching Plex session (aiogateway mode).
REQUIRE_SESSION = os.environ.get("FUSE_REQUIRE_SESSION", "true").lower() in ("1", "true", "yes")
# With no Plex session at all, a read can't be playback; release it this fast.
IDLE_GIVEUP_S = float(os.environ.get("FUSE_IDLE_GIVEUP_SECONDS", "1.5"))
UNKNOWN_SIZE = 50 * 1024 ** 3
UA = os.environ.get("STREAM_USER_AGENT",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

OK, EOF, DEAD, FAIL = "ok", "eof", "dead", "fail"


class BlockCache:
    def __init__(self, n):
        self.n, self.d = n, OrderedDict()

    def get(self, k):
        v = self.d.get(k)
        if v is not None:
            self.d.move_to_end(k)
        return v

    def put(self, k, v):
        self.d[k] = v
        self.d.move_to_end(k)
        while len(self.d) > self.n:
            self.d.popitem(last=False)

    def drop_url(self, url):
        for k in [k for k in self.d if k[0] == url]:
            del self.d[k]


class Handle:
    __slots__ = ("node", "mode", "ph_file", "who")

    def __init__(self, node):
        self.node = node
        self.mode = None          # None (undecided) | "placeholder" | "real"
        self.ph_file = None
        self.who = ""


class Sessions:
    """Cached view of Plex's /status/sessions: playing file path -> ratingKey."""

    def __init__(self, http):
        self.http, self.at, self.files, self.err_until = http, 0.0, {}, 0.0

    async def playing(self):
        now = time.monotonic()
        if now < self.err_until:
            return {}
        if now - self.at <= 0.5:
            return self.files
        tok = clients.plex_token()
        if not tok:
            if not getattr(self, "_warned_tok", False):
                log.warning("no Plex token readable at %s - cannot detect playback", config.PLEX_PREFS)
                self._warned_tok = True
            return {}
        try:
            r = await self.http.get(f"{config.PLEX_URL}/status/sessions",
                                    params={"X-Plex-Token": tok},
                                    headers={"Accept": "application/json"}, timeout=2)
            r.raise_for_status()
            out = {}
            for md in (r.json().get("MediaContainer") or {}).get("Metadata") or []:
                for media in md.get("Media") or []:
                    for part in media.get("Part") or []:
                        if part.get("file"):
                            out[part["file"]] = str(md.get("ratingKey") or "")
            self.files, self.at = out, time.monotonic()
        except Exception as e:  # noqa: BLE001
            log.warning("could not read Plex sessions: %s", e)
            self.err_until, self.files = now + 10, {}
        return self.files

    async def wait_for(self, path, timeout):
        start = time.monotonic()
        deadline = start + max(0.0, timeout)
        name = path.rsplit("/", 1)[-1]
        while True:
            files = await self.playing()
            if path in files or any(f.rsplit("/", 1)[-1] == name for f in files):
                return True
            if not files and time.monotonic() - start >= IDLE_GIVEUP_S:
                return False                    # nothing is playing anywhere: not a playback
            if time.monotonic() >= deadline:
                files = await self.playing()
                log.info("no Plex session on %s after %.1fs; sessions list %d file(s): %s",
                         path, timeout, len(files), "; ".join(list(files)[:5]) or "-")
                return False
            await trio.sleep(0.25)


class AioFS(pyfuse3.Operations):
    def __init__(self):
        super().__init__()
        self.tree = vfs.Tree()
        self.paths = {pyfuse3.ROOT_INODE: ""}
        self.inodes = {"": pyfuse3.ROOT_INODE}
        self.next_inode = pyfuse3.ROOT_INODE + 1
        self.handles: dict[int, Handle] = {}
        self.next_fh = 1
        self.http = httpx.AsyncClient(
            timeout=httpx.Timeout(READ_TIMEOUT, connect=10), follow_redirects=True,
            headers={"User-Agent": UA},
            limits=httpx.Limits(max_connections=20, max_keepalive_connections=10))
        self.cache = BlockCache(CACHE_BLOCKS)
        self.inflight: dict[tuple, trio.Event] = {}
        self.results: dict[tuple, tuple] = {}
        self.sem = trio.Semaphore(MAX_INFLIGHT)
        self.resolving: dict[str, trio.Event] = {}
        self.sessions = Sessions(self.http)
        self.mtime = time.time_ns()

    # ── inode bookkeeping ───────────────────────────────────────────────────
    def _ino(self, rel):
        ino = self.inodes.get(rel)
        if ino is None:
            ino = self.next_inode
            self.next_inode += 1
            self.inodes[rel], self.paths[ino] = ino, rel
        return ino

    def _node(self, inode):
        rel = self.paths.get(inode)
        node = self.tree.resolve(rel) if rel is not None else None
        if node is None:
            raise pyfuse3.FUSEError(errno.ENOENT)
        return node

    @staticmethod
    def _size(node):
        s = db.get_stream(node.stream_key)
        return int(s["size"]) if s and s.get("size") else UNKNOWN_SIZE

    def _attr(self, node):
        a = pyfuse3.EntryAttributes()
        a.st_ino = self._ino(node.rel)
        a.generation = 0
        a.entry_timeout = 5
        a.attr_timeout = 5
        if node.is_dir:
            a.st_mode, a.st_nlink, a.st_size = stat.S_IFDIR | 0o555, 2, 4096
        else:
            a.st_mode, a.st_nlink, a.st_size = stat.S_IFREG | 0o444, 1, self._size(node)
        a.st_uid, a.st_gid = os.getuid(), os.getgid()
        a.st_atime_ns = a.st_mtime_ns = a.st_ctime_ns = self.mtime
        a.st_blksize = 128 * 1024
        a.st_blocks = (a.st_size + 511) // 512
        return a

    # ── metadata ops ────────────────────────────────────────────────────────
    async def lookup(self, parent_inode, name, ctx=None):
        parent = self._node(parent_inode)
        name = os.fsdecode(name)
        if name == ".":
            return self._attr(parent)
        if not parent.is_dir or name not in parent.children:
            raise pyfuse3.FUSEError(errno.ENOENT)
        return self._attr(parent.children[name])

    async def getattr(self, inode, ctx=None):
        return self._attr(self._node(inode))

    async def opendir(self, inode, ctx):
        if not self._node(inode).is_dir:
            raise pyfuse3.FUSEError(errno.ENOTDIR)
        return inode

    async def readdir(self, fh, start_id, token):
        node = self._node(fh)
        names = sorted(node.children)
        for i, name in enumerate(names[start_id:], start=start_id):
            if not pyfuse3.readdir_reply(token, os.fsencode(name), self._attr(node.children[name]), i + 1):
                break

    async def releasedir(self, fh):
        return None

    async def statfs(self, ctx):
        s = pyfuse3.StatvfsData()
        s.f_bsize = s.f_frsize = 4096
        s.f_files = len(self.inodes)
        s.f_namemax = 255
        return s

    # ── file ops ────────────────────────────────────────────────────────────
    async def open(self, inode, flags, ctx):
        node = self._node(inode)
        if node.is_dir:
            raise pyfuse3.FUSEError(errno.EISDIR)
        if flags & (os.O_WRONLY | os.O_RDWR):
            raise pyfuse3.FUSEError(errno.EROFS)
        h = Handle(node)
        h.who = f"{vfs.comm(vfs.tgid(ctx.pid))}/{vfs.comm(ctx.pid)}"
        # The scanner/analyzer is never a playback: skip the session wait and
        # give it the real file only if a live link already exists (so a
        # post-play re-analysis stores real media info), else the placeholder.
        if vfs.caller_class(ctx.pid) == "scanner":
            h.mode = "real" if vfs.stream_url_fresh(db.get_stream(node.stream_key)) else "placeholder"
        fh, self.next_fh = self.next_fh, self.next_fh + 1
        self.handles[fh] = h
        return pyfuse3.FileInfo(fh=fh, direct_io=True, keep_cache=False)

    async def release(self, fh):
        h = self.handles.pop(fh, None)
        if h and h.ph_file:
            h.ph_file.close()

    async def read(self, fh, off, size):
        h = self.handles.get(fh)
        if h is None:
            raise pyfuse3.FUSEError(errno.EBADF)
        if h.mode is None:
            h.mode = await self._decide(h.node)
            log.info("read %s by %s -> %s", h.node.rel, h.who, h.mode)
            if h.mode == "real":
                trio.lowlevel.spawn_system_task(self._notify_activated, h.node.rel)
        if h.mode == "placeholder":
            return self._placeholder(h, off, size)
        return await self._read_real(h.node, off, size)

    # ── placeholder vs real ─────────────────────────────────────────────────
    async def _decide(self, node):
        s = db.get_stream(node.stream_key)
        if vfs.stream_url_fresh(s):
            return "real"                       # already switched and link still valid
        full = f"{config.MOUNT_POINT}/{node.rel}"
        if not REQUIRE_SESSION or (PLAY_DETECT_S > 0 and await self.sessions.wait_for(full, PLAY_DETECT_S)):
            log.info("playback of %s - switching to the real stream", node.rel)
            try:
                await self._resolve(node)
                return "real"
            except Exception as e:  # noqa: BLE001
                log.warning("could not resolve %s: %s", node.rel, e)
        return "placeholder"

    def _placeholder(self, h, off, size):
        if h.ph_file is None:
            try:
                h.ph_file = open(h.node.placeholder_path(), "rb")
            except OSError:
                return b"\x00" * size
        h.ph_file.seek(off)
        data = h.ph_file.read(size)
        return data + b"\x00" * (size - len(data)) if len(data) < size else data

    # ── resolution ──────────────────────────────────────────────────────────
    async def _resolve(self, node, failed_url=None):
        """Resolve (or repair) the node's link once, sharing concurrent callers."""
        key = node.stream_key
        ev = self.resolving.get(key)
        if ev is not None:
            await ev.wait()
            return
        ev = self.resolving[key] = trio.Event()
        try:
            prev = db.get_stream(key) or {}
            if failed_url:
                self.cache.drop_url(failed_url)
                db.expire_stream_url(key)
            stype, sid = key.split("/", 1)
            base = clients.addon_base(config.AIOSTREAMS_MANIFEST_URL)
            r = await self.http.get(f"{base}/stream/{stype}/{urllib.parse.quote(sid, safe=':')}.json", timeout=40)
            r.raise_for_status()
            streams = [s for s in r.json().get("streams") or [] if s.get("url") != failed_url]
            pick = vfs.pick_stream(streams, prev.get("filename"))
            if not pick:
                raise RuntimeError("AIOStreams returned no playable stream")
            hints = pick.get("behaviorHints") or {}
            size = hints.get("videoSize") or await self._probe_size(pick["url"])
            db.save_stream(key, pick["url"], size, hints.get("filename"))
            log.info("resolved %s -> %s (%s bytes)", key, hints.get("filename") or "stream", size)
        finally:
            ev.set()
            self.resolving.pop(key, None)

    async def _probe_size(self, url):
        try:
            async with self.http.stream("GET", url, headers={"Range": "bytes=0-0"}) as r:
                cr = r.headers.get("Content-Range", "")
                if "/" in cr and cr.rsplit("/", 1)[1].strip().isdigit():
                    return int(cr.rsplit("/", 1)[1])
        except httpx.HTTPError:
            pass
        return None

    async def _notify_activated(self, rel):
        try:
            await self.http.post(f"{config.BRIDGE_INTERNAL}/internal/activated", params={"rel": rel}, timeout=5)
        except httpx.HTTPError as e:
            log.warning("could not notify bridge: %s", e)

    # ── real reads ──────────────────────────────────────────────────────────
    async def _read_real(self, node, off, size):
        s = db.get_stream(node.stream_key) or {}
        total = s.get("size")
        if total and off >= total:
            return b""
        bi = off // BLOCK
        first = await self._get_block(node, bi)
        if first is None:
            return b""
        so = off - bi * BLOCK
        chunk = first[so:so + size]
        url = (db.get_stream(node.stream_key) or {}).get("url")
        for a in range(1, PREFETCH_AHEAD + 1):
            nb = bi + a
            if total and nb * BLOCK >= total:
                break
            if url and self.cache.get((url, nb)) is None and (url, nb) not in self.inflight:
                trio.lowlevel.spawn_system_task(self._prefetch, node, url, nb)
        nb = bi + 1
        while len(chunk) < size and len(first) == BLOCK:
            if total and nb * BLOCK >= total:
                break
            nxt = await self._get_block(node, nb)
            if not nxt:
                break
            chunk += nxt[: size - len(chunk)]
            if len(nxt) < BLOCK:
                break
            nb += 1
        return chunk

    async def _prefetch(self, node, url, bi):
        status, _ = await self._fetch(url, bi, node)
        if status in (DEAD, FAIL) and (db.get_stream(node.stream_key) or {}).get("url") == url:
            try:
                await self._resolve(node, failed_url=url)
            except Exception as e:  # noqa: BLE001
                log.warning("background repair failed for %s: %s", node.rel, e)

    async def _get_block(self, node, bi):
        for _ in range(3):
            s = db.get_stream(node.stream_key) or {}
            url = s.get("url")
            if not url:
                await self._resolve(node)
                continue
            data = self.cache.get((url, bi))
            if data is not None:
                return data
            status, data = await self._fetch(url, bi, node)
            if status == OK:
                return data
            if status == EOF:
                return None
            log.warning("link broken for %s at block %d - repairing", node.rel, bi)
            try:
                await self._resolve(node, failed_url=url)
            except Exception as e:  # noqa: BLE001
                log.warning("repair failed for %s: %s", node.rel, e)
                raise pyfuse3.FUSEError(errno.EIO)
        raise pyfuse3.FUSEError(errno.EIO)

    async def _fetch(self, url, bi, node):
        """De-duplicated block fetch -> (status, data)."""
        k = (url, bi)
        ev = self.inflight.get(k)
        if ev is not None:
            await ev.wait()
            data = self.cache.get(k)
            return (OK, data) if data is not None else self.results.get(k, (FAIL, None))
        ev = self.inflight[k] = trio.Event()
        try:
            res = await self._fetch_uncached(url, bi, node)
            self.results[k] = res
            return res
        finally:
            ev.set()
            self.inflight.pop(k, None)
            if len(self.results) > 256:
                self.results.clear()

    async def _fetch_uncached(self, url, bi, node):
        start = bi * BLOCK
        total = (db.get_stream(node.stream_key) or {}).get("size")
        async with self.sem:
            for attempt in range(READ_ATTEMPTS):
                try:
                    async with self.http.stream("GET", url, headers={"Range": f"bytes={start}-{start + BLOCK - 1}"}) as r:
                        if r.status_code == 200 and start > 0:
                            log.warning("%s: server ignored Range", node.rel)
                            return DEAD, None
                        if r.status_code in (200, 206):
                            ctype = (r.headers.get("Content-Type") or "").lower()
                            buf = bytearray()
                            async for part in r.aiter_bytes(256 * 1024):
                                buf += part
                                if len(buf) >= BLOCK:
                                    break
                            data = bytes(buf[:BLOCK])
                            near_eof = bool(total and start + len(data) >= total - 1)
                            if any(t in ctype for t in ("json", "text/html", "text/plain")) or \
                                    (len(data) < 4096 and not near_eof):
                                log.warning("%s: rejected non-media response (%s, %d bytes)", node.rel, ctype, len(data))
                                return DEAD, None
                            self.cache.put((url, bi), data)
                            return OK, data
                        if r.status_code == 416:
                            return EOF, None
                        if r.status_code in (401, 403, 404, 410, 451):
                            return DEAD, None
                        log.warning("%s: CDN returned %d (attempt %d)", node.rel, r.status_code, attempt + 1)
                except httpx.HTTPError as e:
                    log.warning("%s: block %d attempt %d: %s", node.rel, bi, attempt + 1, e)
                await trio.sleep(min(0.5 * (attempt + 1), 2.0))
        return FAIL, None


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)
    db.init()
    os.makedirs(config.MOUNT_POINT, exist_ok=True)
    ops = AioFS()
    opts = set(pyfuse3.default_options)
    opts |= {"fsname=plexaio", "allow_other", "ro"}
    opts.discard("default_permissions")
    pyfuse3.init(ops, config.MOUNT_POINT, opts)
    log.info("mounted at %s (block=%dMB, cache=%d blocks)", config.MOUNT_POINT, BLOCK >> 20, CACHE_BLOCKS)
    _drop_privileges()
    try:
        trio.run(pyfuse3.main)
    finally:
        try:
            pyfuse3.close(unmount=os.geteuid() == 0)
        except Exception:  # noqa: BLE001
            pass                                   # s6 finish script unmounts as root


def _drop_privileges():
    """Mount as root (needed inside containers), then serve as the Plex user so
    the shared SQLite files stay writable by the bridge."""
    if os.geteuid() != 0:
        return
    import pwd
    user = os.environ.get("AIO_RUN_AS", "abc")
    try:
        pw = pwd.getpwnam(user)
    except KeyError:
        log.warning("user %s not found; continuing as root", user)
        return
    os.setgroups([])
    os.setgid(pw.pw_gid)
    os.setuid(pw.pw_uid)
    log.info("serving as %s (uid %d)", user, pw.pw_uid)


if __name__ == "__main__":
    sys.exit(main())
