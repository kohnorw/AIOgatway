"""Read-only FUSE filesystem at /media/aio (pyfuse3 + trio).

Scanner / unknown callers  -> bytes of the local placeholder clip (no network).
Plex Media Server / Transcoder (playback) -> resolve via AIOStreams on open,
    then proxy byte-range reads from the debrid link with sequential readahead.
"""
import errno
import logging
import os
import stat
import sys
import time
import urllib.parse

import httpx
import pyfuse3
import trio

from . import clients, config, db, vfs

log = logging.getLogger("aio.fs")
CHUNK_REOPEN_GAP = 4 * 1024 * 1024     # forward seeks smaller than this are read through
UA = {"User-Agent": "plex-aio/1.0"}


class Handle:
    def __init__(self, node, real, url=None, size=0):
        self.node, self.real, self.url, self.size = node, real, url, size
        self.file = None
        self.resp = None
        self.it = None
        self.pos = 0
        self.buf = bytearray()
        self.lock = trio.Lock()


class AioFS(pyfuse3.Operations):
    def __init__(self):
        super().__init__()
        self.tree = vfs.Tree()
        self.paths = {pyfuse3.ROOT_INODE: ""}
        self.inodes = {"": pyfuse3.ROOT_INODE}
        self.next_inode = pyfuse3.ROOT_INODE + 1
        self.handles: dict[int, Handle] = {}
        self.next_fh = 1
        self.http = httpx.AsyncClient(timeout=httpx.Timeout(30, read=60), follow_redirects=True, headers=UA)
        self.mtime = time.time_ns()

    # --- inode bookkeeping ---------------------------------------------------------
    def _ino(self, rel):
        ino = self.inodes.get(rel)
        if ino is None:
            ino = self.next_inode
            self.next_inode += 1
            self.inodes[rel], self.paths[ino] = ino, rel
        return ino

    def _node(self, inode):
        rel = self.paths.get(inode)
        node = self.tree.resolve(rel) if rel is not None else None
        if node is None:
            raise pyfuse3.FUSEError(errno.ENOENT)
        return node

    def _attr(self, node, cls):
        a = pyfuse3.EntryAttributes()
        a.st_ino = self._ino(node.rel)
        a.generation = 0
        a.entry_timeout = 1
        a.attr_timeout = 0                 # size depends on who is asking
        if node.is_dir:
            a.st_mode = stat.S_IFDIR | 0o555
            a.st_nlink = 2
            a.st_size = 4096
        else:
            a.st_mode = stat.S_IFREG | 0o444
            a.st_nlink = 1
            a.st_size = vfs.visible_size(node, cls)
        a.st_uid, a.st_gid = os.getuid(), os.getgid()
        a.st_atime_ns = a.st_mtime_ns = a.st_ctime_ns = self.mtime
        a.st_blksize = 128 * 1024
        a.st_blocks = (a.st_size + 511) // 512
        return a

    # --- metadata ops -----------------------------------------------------------------
    async def lookup(self, parent_inode, name, ctx=None):
        parent = self._node(parent_inode)
        name = os.fsdecode(name)
        if name == ".":
            return self._attr(parent, "other")
        if not parent.is_dir or name not in parent.children:
            raise pyfuse3.FUSEError(errno.ENOENT)
        return self._attr(parent.children[name], vfs.caller_class(ctx.pid) if ctx else "other")

    async def getattr(self, inode, ctx=None):
        return self._attr(self._node(inode), vfs.caller_class(ctx.pid) if ctx else "other")

    async def opendir(self, inode, ctx):
        node = self._node(inode)
        if not node.is_dir:
            raise pyfuse3.FUSEError(errno.ENOTDIR)
        return inode

    async def readdir(self, fh, start_id, token):
        node = self._node(fh)
        names = sorted(node.children)
        for i, name in enumerate(names[start_id:], start=start_id):
            if not pyfuse3.readdir_reply(token, os.fsencode(name), self._attr(node.children[name], "other"), i + 1):
                break

    async def releasedir(self, fh):
        return None

    async def statfs(self, ctx):
        s = pyfuse3.StatvfsData()
        s.f_bsize = s.f_frsize = 4096
        s.f_blocks = s.f_bfree = s.f_bavail = 0
        s.f_files = len(self.inodes)
        s.f_namemax = 255
        return s

    # --- file ops -------------------------------------------------------------------------
    async def open(self, inode, flags, ctx):
        node = self._node(inode)
        if node.is_dir:
            raise pyfuse3.FUSEError(errno.EISDIR)
        if flags & (os.O_WRONLY | os.O_RDWR):
            raise pyfuse3.FUSEError(errno.EROFS)
        cls = vfs.caller_class(ctx.pid)
        if vfs.serves_real(node, cls):
            try:
                url, size, first = await self._resolve(node)
            except Exception as e:  # noqa: BLE001
                log.warning("no stream for %s: %s", node.rel, e)
                raise pyfuse3.FUSEError(errno.EIO)
            h = Handle(node, True, url, size)
            if first:
                trio.lowlevel.spawn_system_task(self._notify_activated, node.item_rel)
        else:
            h = Handle(node, False)
            try:
                h.file = open(node.placeholder_path(), "rb")
            except OSError:
                raise pyfuse3.FUSEError(errno.EIO)
        fh, self.next_fh = self.next_fh, self.next_fh + 1
        self.handles[fh] = h
        log.info("open %s by %s -> %s", node.rel, cls, "stream" if h.real else "placeholder")
        return pyfuse3.FileInfo(fh=fh, direct_io=True, keep_cache=False)

    async def read(self, fh, off, size):
        h = self.handles.get(fh)
        if h is None:
            raise pyfuse3.FUSEError(errno.EBADF)
        if not h.real:
            h.file.seek(off)
            return h.file.read(size)
        async with h.lock:
            return await self._read_stream(h, off, size)

    async def release(self, fh):
        h = self.handles.pop(fh, None)
        if h:
            if h.file:
                h.file.close()
            await self._close_resp(h)

    # --- streaming --------------------------------------------------------------------------
    async def _close_resp(self, h):
        if h.resp is not None:
            await h.resp.aclose()
        h.resp, h.it = None, None
        h.buf = bytearray()

    async def _open_at(self, h, off, retry=True):
        await self._close_resp(h)
        req = self.http.build_request("GET", h.url, headers={"Range": f"bytes={off}-"})
        resp = await self.http.send(req, stream=True)
        if resp.status_code in (401, 403, 404, 410) and retry:
            await resp.aclose()
            db.expire_stream_url(h.node.stream_key)
            h.url, h.size, _ = await self._resolve(h.node)
            return await self._open_at(h, off, retry=False)
        if resp.status_code not in (200, 206):
            await resp.aclose()
            raise pyfuse3.FUSEError(errno.EIO)
        if resp.status_code == 200 and off:
            # server ignored Range; discard up to offset
            h.resp, h.it, h.pos = resp, resp.aiter_bytes(256 * 1024), 0
            await self._skip(h, off)
            return
        h.resp, h.it, h.pos = resp, resp.aiter_bytes(256 * 1024), off

    async def _skip(self, h, off):
        while h.pos < off:
            need = off - h.pos
            if len(h.buf) >= need:
                del h.buf[:need]
                h.pos = off
                return
            h.pos += len(h.buf)
            h.buf = bytearray()
            try:
                h.buf += await h.it.__anext__()
            except StopAsyncIteration:
                return

    async def _read_stream(self, h, off, size):
        if h.size and off >= h.size:
            return b""
        if h.resp is None or off < h.pos or off - h.pos > CHUNK_REOPEN_GAP:
            await self._open_at(h, off)
        elif off > h.pos:
            await self._skip(h, off)
        while len(h.buf) < size:
            try:
                h.buf += await h.it.__anext__()
            except StopAsyncIteration:
                break
            except httpx.HTTPError:
                await self._open_at(h, h.pos + len(h.buf))
                continue
        out = bytes(h.buf[:size])
        del h.buf[:size]
        h.pos += len(out)
        return out

    async def _resolve(self, node):
        """Returns (url, size, first_activation)."""
        s = db.get_stream(node.stream_key)
        if vfs.stream_url_fresh(s):
            return s["url"], int(s["size"] or 0), False
        if not config.AIOSTREAMS_MANIFEST_URL:
            raise RuntimeError("AIOSTREAMS_MANIFEST_URL not set")
        stype, sid = node.stream_key.split("/", 1)
        base = clients.addon_base(config.AIOSTREAMS_MANIFEST_URL)
        r = await self.http.get(f"{base}/stream/{stype}/{urllib.parse.quote(sid, safe=':')}.json")
        r.raise_for_status()
        pick = vfs.pick_stream(r.json().get("streams") or [], (s or {}).get("filename"))
        if not pick:
            raise RuntimeError("AIOStreams returned no playable stream")
        hints = pick.get("behaviorHints") or {}
        url = pick["url"]
        size = hints.get("videoSize") or await self._probe_size(url)
        first = not (s and s.get("activated"))
        db.save_stream(node.stream_key, url, size, hints.get("filename"))
        log.info("resolved %s -> %s (%s bytes)", node.stream_key, hints.get("filename") or url[:60], size)
        return url, int(size or 0), first

    async def _probe_size(self, url):
        try:
            async with self.http.stream("GET", url, headers={"Range": "bytes=0-0"}) as r:
                cr = r.headers.get("Content-Range", "")
                if "/" in cr and cr.rsplit("/", 1)[1].isdigit():
                    return int(cr.rsplit("/", 1)[1])
                return int(r.headers.get("Content-Length") or 0) or None
        except httpx.HTTPError:
            return None

    async def _notify_activated(self, rel):
        await trio.sleep(20)        # let playback get going before Plex re-analyses
        try:
            await self.http.post(f"{config.BRIDGE_INTERNAL}/internal/activated", params={"rel": rel})
        except httpx.HTTPError as e:
            log.warning("could not notify bridge: %s", e)


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    db.init()
    os.makedirs(config.MOUNT_POINT, exist_ok=True)
    ops = AioFS()
    opts = set(pyfuse3.default_options)
    opts |= {"fsname=plexaio", "allow_other", "ro"}
    opts.discard("default_permissions")
    pyfuse3.init(ops, config.MOUNT_POINT, opts)
    log.info("mounted at %s", config.MOUNT_POINT)
    _drop_privileges()
    try:
        trio.run(pyfuse3.main)
    finally:
        try:
            pyfuse3.close(unmount=os.geteuid() == 0)
        except Exception:  # noqa: BLE001
            pass                                   # s6 finish script unmounts as root


def _drop_privileges():
    """Mount as root (needed inside containers), then serve as the Plex user so
    the shared SQLite files stay writable by the bridge."""
    if os.geteuid() != 0:
        return
    import pwd
    user = os.environ.get("AIO_RUN_AS", "abc")
    try:
        pw = pwd.getpwnam(user)
    except KeyError:
        log.warning("user %s not found; continuing as root", user)
        return
    os.setgroups([])
    os.setgid(pw.pw_gid)
    os.setuid(pw.pw_uid)
    log.info("serving as %s (uid %d)", user, pw.pw_uid)


if __name__ == "__main__":
    sys.exit(main())
