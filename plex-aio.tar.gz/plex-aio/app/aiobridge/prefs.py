"""Write Plex preferences that stop scanning/analysis work, before PMS starts.

Preference names were confirmed as strings inside the Plex Media Server
1.43.4 binary. Values follow Plex's convention ("0" off for booleans and
Butler tasks, "never" for the *Behavior settings).
"""
import os
import sys
import xml.etree.ElementTree as ET

from . import config

OFF = {
    # automatic scans: only plex-aio's targeted refreshes trigger scanning
    "FSEventLibraryUpdatesEnabled": "0",
    "FSEventLibraryPartialScanEnabled": "0",
    "ScheduledLibraryUpdatesEnabled": "0",
    # never remove titles that briefly vanish (e.g. mount restart)
    "autoEmptyTrash": "0",
    # per-file analysis extras
    "GenerateBIFBehavior": "never",
    "GenerateChapterThumbBehavior": "never",
    "GenerateIntroMarkerBehavior": "never",
    "GenerateCreditsMarkerBehavior": "never",
    "GenerateAdMarkerBehavior": "never",
    "GenerateVADBehavior": "never",
    "LoudnessAnalysisBehavior": "never",
    "MusicAnalysisBehavior": "never",
    # scheduled maintenance that would read media files
    "ButlerTaskDeepMediaAnalysis": "0",
    "ButlerTaskUpgradeMediaAnalysis": "0",
    "ButlerTaskRefreshLibraries": "0",
    "ButlerTaskRefreshLocalMedia": "0",
    "ButlerTaskRefreshPeriodicMetadata": "0",
    "ButlerTaskGenerateMediaIndexFiles": "0",
    "ButlerTaskGenerateIntroMarkers": "0",
    "ButlerTaskGenerateCreditsMarkers": "0",
    "ButlerTaskGenerateAdMarkers": "0",
    "ButlerTaskGenerateVoiceActivity": "0",
}


def apply(path: str = config.PLEX_PREFS, advertise: str | None = None) -> dict:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path) and os.path.getsize(path) > 0:
        tree = ET.parse(path)
        root = tree.getroot()
    else:
        root = ET.Element("Preferences")
        tree = ET.ElementTree(root)
    changed = {}
    wanted = dict(OFF)
    if advertise:
        wanted["customConnections"] = advertise
    for k, v in wanted.items():
        if root.get(k) != v:
            changed[k] = (root.get(k), v)
            root.set(k, v)
    if changed:
        tree.write(path, encoding="utf-8", xml_declaration=True)
    return changed


if __name__ == "__main__":
    adv = os.environ.get("PLEX_ADVERTISE_URL") or None
    ch = apply(advertise=adv)
    print(f"[plex-aio] Plex preferences: {len(ch)} changed" + (f" ({', '.join(ch)})" if ch else ""))
    sys.exit(0)
