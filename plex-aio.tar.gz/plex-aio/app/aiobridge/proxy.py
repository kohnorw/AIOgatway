"""Front door for Plex clients: a transparent reverse proxy in front of PMS.

Clients reach Plex through this proxy (host port 32400 -> proxy 8771, with
PMS itself on the unpublished internal 32400). Everything is passed through
untouched, including WebSockets, except library searches: when someone
searches, the query is looked up on Cinemeta first, matching movies and shows
are added to the library, and the proxy waits briefly for Plex to index them
before forwarding the search. So any title you search for "is in the library".

Search-as-you-type sends a request per keystroke, so a query only triggers
Cinemeta once it has been stable for SEARCH_DEBOUNCE_MS for that client.
"""
import asyncio
import logging
import time

import aiohttp
from aiohttp import web

from . import config, library, naming, playback
from .clients import plex

log = logging.getLogger("aio.proxy")

SEARCH_PATHS = ("/hubs/search", "/hubs/search/voice", "/search", "/library/search")
# requests clients send when playback starts; the item is prepared before they reach Plex
PLAY_PATHS = ("/playQueues", "/video/:/transcode/universal/decision", "/video/:/transcode/universal/start",
              "/video/:/transcode/universal/start.m3u8", "/video/:/transcode/universal/start.mpd")
HOP = {"connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailers",
       "transfer-encoding", "upgrade", "host", "content-length"}

_latest: dict[str, tuple[str, float]] = {}
_done: dict[str, float] = {}
_upstream: aiohttp.ClientSession | None = None
_plex_base: str | None = None


def plex_base() -> str:
    """Reach PMS on the container's network IP, never loopback: Plex treats
    127.0.0.1 specially, and proxied remote users must still authenticate."""
    global _plex_base
    if _plex_base is None:
        import socket
        ip = "127.0.0.1"
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("10.255.255.255", 1))
                ip = s.getsockname()[0]
        except OSError:
            pass
        port = config.PLEX_URL.rsplit(":", 1)[-1]
        _plex_base = f"http://{ip}:{port}"
        log.info("proxying clients to Plex at %s", _plex_base)
    return _plex_base


def upstream() -> aiohttp.ClientSession:
    global _upstream
    if _upstream is None or _upstream.closed:
        _upstream = aiohttp.ClientSession(
            auto_decompress=False,
            timeout=aiohttp.ClientTimeout(total=None, sock_connect=10),
            connector=aiohttp.TCPConnector(limit=0),
        )
    return _upstream


async def _search_hook(req: web.Request):
    q = (req.query.get("query") or "").strip()
    if len(q) < 3:
        return
    norm = naming.norm_title(q)
    if not norm or _done.get(norm, 0) > time.time():
        return
    client = req.headers.get("X-Plex-Client-Identifier") or req.query.get("X-Plex-Client-Identifier") or req.remote
    stamp = time.monotonic()
    _latest[client] = (norm, stamp)
    await asyncio.sleep(config.SEARCH_DEBOUNCE_MS / 1000)
    if _latest.get(client, ("", 0))[1] != stamp:
        return                                  # user kept typing; a newer request owns it
    _done[norm] = time.time() + 3600
    try:
        added = await library.search_and_add(q)
    except Exception as e:  # noqa: BLE001
        log.warning("search hook failed for %r: %s", q, e)
        return
    if not added:
        return
    log.info("search %r added %d title(s); waiting for Plex to index", q, len(added))
    titles = set()
    for key in added:
        item = library.db.get_item(key)
        if item:
            titles.add(item["title"])
    deadline = time.monotonic() + 12
    while time.monotonic() < deadline:
        await asyncio.sleep(1)
        try:
            if titles & await plex.search_titles(q):
                await asyncio.sleep(0.5)
                return
        except Exception:  # noqa: BLE001
            pass


async def _ws_proxy(req: web.Request):
    ws_client = web.WebSocketResponse(autoping=True)
    await ws_client.prepare(req)
    headers = {k: v for k, v in req.headers.items() if k.lower() not in HOP and not k.lower().startswith("sec-websocket")}
    try:
        async with upstream().ws_connect(plex_base().replace("http", "ws", 1) + req.path_qs, headers=headers) as ws_up:
            async def pump(src, dst):
                async for msg in src:
                    if msg.type == aiohttp.WSMsgType.TEXT:
                        await dst.send_str(msg.data)
                    elif msg.type == aiohttp.WSMsgType.BINARY:
                        await dst.send_bytes(msg.data)
                    else:
                        break
            await asyncio.wait([asyncio.create_task(pump(ws_client, ws_up)),
                                asyncio.create_task(pump(ws_up, ws_client))],
                               return_when=asyncio.FIRST_COMPLETED)
    except Exception as e:  # noqa: BLE001
        log.debug("websocket proxy closed: %s", e)
    await ws_client.close()
    return ws_client


async def handler(req: web.Request):
    if req.headers.get("Upgrade", "").lower() == "websocket":
        return await _ws_proxy(req)
    if config.SEARCH_HOOK and req.method == "GET" and req.path.rstrip("/") in SEARCH_PATHS:
        await _search_hook(req)
    if req.path.rstrip("/") in PLAY_PATHS or (req.path.startswith("/library/metadata/") and "checkFiles" in req.query):
        rk = playback.rating_key_from(req.query) or (playback.RK_RE.search(req.path).group(1)
                                                      if playback.RK_RE.search(req.path) else None)
        if rk:
            await playback.prepare(rk)

    headers = {k: v for k, v in req.headers.items() if k.lower() not in HOP}
    headers["X-Forwarded-For"] = req.remote or ""
    headers["X-Forwarded-Proto"] = req.scheme
    headers["X-Forwarded-Host"] = req.host
    data = req.content if req.body_exists else None
    try:
        up = await upstream().request(req.method, plex_base() + req.path_qs, headers=headers,
                                      data=data, allow_redirects=False)
    except aiohttp.ClientError as e:
        return web.Response(status=502, text=f"Plex is not reachable: {e}")
    resp = web.StreamResponse(status=up.status, reason=up.reason)
    for k, v in up.headers.items():
        if k.lower() not in HOP:
            resp.headers.add(k, v)
    if up.headers.get("Content-Length"):
        resp.content_length = int(up.headers["Content-Length"])
    try:
        await resp.prepare(req)
        async for chunk in up.content.iter_chunked(256 * 1024):
            await resp.write(chunk)
        await resp.write_eof()
    except (ConnectionResetError, asyncio.CancelledError, aiohttp.ClientError):
        pass
    finally:
        up.release()
    return resp


def make_app() -> web.Application:
    app = web.Application(client_max_size=1024 ** 3)
    app.router.add_route("*", "/{tail:.*}", handler)
    return app
