"""Virtual library layout. Pure functions so the FS and the bridge agree on paths.

    movies/<Title> (<Year>) {tmdb-<id>}/<Title> (<Year>) {tmdb-<id>}.mkv
    tv/<Title> (<Year>) {tmdb-<id>}/Season NN/<Title> (<Year>) - SNNENN.mkv

The {tmdb-<id>} tag follows Plex's documented naming hint, and the custom
provider also resolves folders back to items through the database.
"""
import datetime
import re
import unicodedata

_BAD = re.compile(r'[\\/:*?"<>|\x00-\x1f]')
_TAG = re.compile(r"\{tmdb-(\d+)\}")
_EP = re.compile(r"S(\d{2,})E(\d{2,})\.mkv$")
_SEASON = re.compile(r"^Season (\d+)$")


def safe(name: str) -> str:
    name = unicodedata.normalize("NFC", name or "Unknown")
    name = _BAD.sub(" ", name).strip().rstrip(".")
    return re.sub(r"\s+", " ", name) or "Unknown"


def base_name(item) -> str:
    year = f" ({item['year']})" if item.get("year") else ""
    return f"{safe(item['title'])}{year}"


def folder(item) -> str:
    return f"{base_name(item)} {{tmdb-{item['tmdb']}}}"


def movie_file(item) -> str:
    return folder(item) + ".mkv"


def season_dir(n: int) -> str:
    return f"Season {n:02d}"


def episode_file(item, season: int, episode: int) -> str:
    return f"{base_name(item)} - S{season:02d}E{episode:02d}.mkv"


def top_dir(kind: str) -> str:
    return "movies" if kind == "movie" else "tv"


def item_rel_path(item) -> str:
    return f"{top_dir(item['kind'])}/{folder(item)}"


def tmdb_from_name(name: str):
    m = _TAG.search(name or "")
    return int(m.group(1)) if m else None


def parse_episode_file(name: str):
    m = _EP.search(name)
    return (int(m.group(1)), int(m.group(2))) if m else None


def parse_season_dir(name: str):
    m = _SEASON.match(name)
    return int(m.group(1)) if m else None


def aired(air_date, today=None) -> bool:
    if not air_date:
        return False
    today = today or datetime.date.today().isoformat()
    return air_date <= today


def norm_title(t: str) -> str:
    t = unicodedata.normalize("NFKD", t or "").encode("ascii", "ignore").decode().lower()
    t = re.sub(r"[^a-z0-9]+", " ", t)
    return re.sub(r"^(the|a|an) ", "", t.strip())


def stream_key_movie(item) -> str:
    return f"movie/{item.get('imdb') or 'tmdb:' + str(item['tmdb'])}"


def stream_key_episode(item, season: int, episode: int) -> str:
    sid = item.get("imdb") or f"tmdb:{item['tmdb']}"
    return f"series/{sid}:{season}:{episode}"
