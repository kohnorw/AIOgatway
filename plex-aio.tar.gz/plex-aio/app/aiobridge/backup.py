"""Backup and restore (Settings → Backup/Restore), modelled on aiogateway's.

A backup is one JSON file with:
  * settings  - everything from Settings, secrets included (TMDB key, AIOStreams URL)
  * users     - accounts and roles, never Plex tokens (people sign in again)
  * library   - every requested movie/show with request mode, requested seasons,
                4K flags, requester, episode list and which episodes Plex has
                already been asked to scan
Live stream links are not included: they re-resolve on the next play.

Restore merges by default (titles already in the library are kept as they are);
replace=True removes the current library first. Plex is asked to rescan afterwards.
"""
import datetime
import logging

from . import auth, config, db, library, naming

log = logging.getLogger("aio.backup")
FORMAT = "plex-aio-backup"
VERSION = 1

ITEM_FIELDS = ("key", "kind", "tmdb", "imdb", "title", "year", "runtime", "status", "added_at",
               "refreshed_at", "has_4k", "poster", "requested_by", "monitor", "monitor_since")


def export() -> dict:
    with db.conn() as c:
        items = [dict(r) for r in c.execute("SELECT * FROM items ORDER BY added_at")]
        eps = [dict(r) for r in c.execute("SELECT * FROM episodes")]
        req = [dict(r) for r in c.execute("SELECT * FROM show_seasons")]
        s4k = [dict(r) for r in c.execute("SELECT * FROM seasons_4k")]
        src = [dict(r) for r in c.execute("SELECT * FROM sources")]
    by = lambda rows, k: {r[k]: [] for r in rows}  # noqa: E731
    ep_map, req_map, s4k_map, src_map = by(eps, "show_key"), by(req, "show_key"), by(s4k, "show_key"), by(src, "item_key")
    for r in eps:
        ep_map[r["show_key"]].append([r["season"], r["episode"], r["title"], r["runtime"], r["air_date"], r["announced"]])
    for r in req:
        req_map[r["show_key"]].append(r["season"])
    for r in s4k:
        s4k_map[r["show_key"]].append(r["season"])
    for r in src:
        src_map[r["item_key"]].append(r["source"])
    lib = []
    for it in items:
        e = {k: it.get(k) for k in ITEM_FIELDS}
        e["sources"] = sorted(set(src_map.get(it["key"], [])))
        if it["kind"] == "show":
            e["episodes"] = ep_map.get(it["key"], [])
            e["requested_seasons"] = sorted(req_map.get(it["key"], []))
            e["seasons_4k"] = sorted(s4k_map.get(it["key"], []))
        lib.append(e)
    return {
        "format": FORMAT, "format_version": VERSION,
        "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "settings": config.current(),
        "users": [{k: u.get(k) for k in ("plex_user_id", "username", "email", "thumb", "role", "created_at", "last_login")}
                  for u in auth.list_users()],
        "library": lib,
    }


def restore(bundle: dict, replace: bool = False, restore_settings: bool = True, restore_users: bool = True) -> dict:
    if not isinstance(bundle, dict) or bundle.get("format") != FORMAT:
        raise ValueError("Not a plex-aio backup file")
    if int(bundle.get("format_version") or 0) > VERSION:
        raise ValueError("This backup was made by a newer plex-aio version")
    out = {"settings": 0, "users": 0, "added": 0, "skipped": 0, "removed": 0}

    if restore_settings and isinstance(bundle.get("settings"), dict):
        changes = {k: v for k, v in bundle["settings"].items() if k in config.SPEC and v not in (None, "")}
        out["settings"] = len(config.save(changes))

    if restore_users and isinstance(bundle.get("users"), list):
        out["users"] = auth.import_users(bundle["users"])

    removed = []
    if replace:
        for it in db.all_items():
            removed.append(it)
            db.delete_item(it["key"])
        out["removed"] = len(removed)

    restored = []
    for e in bundle.get("library") or []:
        key = e.get("key")
        if not key or e.get("kind") not in ("movie", "show") or not e.get("tmdb") or not e.get("title"):
            continue
        if db.get_item(key):
            out["skipped"] += 1
            continue
        with db.conn() as c:
            cols = [k for k in ITEM_FIELDS if e.get(k) is not None]
            c.execute(f"INSERT INTO items({','.join(cols)}) VALUES({','.join('?' * len(cols))})",
                      [e[k] for k in cols])
            if e["kind"] == "show":
                c.executemany(
                    "INSERT OR REPLACE INTO episodes(show_key,season,episode,title,runtime,air_date,announced) VALUES(?,?,?,?,?,?,?)",
                    [(key, *ep[:5], int(ep[5]) if len(ep) > 5 else 1) for ep in e.get("episodes") or []])
                c.executemany("INSERT OR IGNORE INTO show_seasons(show_key,season) VALUES(?,?)",
                              [(key, int(n)) for n in e.get("requested_seasons") or []])
                c.executemany("INSERT OR IGNORE INTO seasons_4k(show_key,season) VALUES(?,?)",
                              [(key, int(n)) for n in e.get("seasons_4k") or []])
        for src in e.get("sources") or ["restore"]:
            db.touch_source(key, src)
        restored.append(db.get_item(key))
        out["added"] += 1

    # Ask Plex to pick up the changes (large batches become one library scan).
    for it in removed:
        if not db.get_item(it["key"]):
            library.scans.add(naming.item_rel_path(it), removed=True)
            library.scans.add(naming.item_rel_path(it, uhd=True), removed=True)
    for it in restored:
        library.scans.add(naming.item_rel_path(it))
        if it.get("has_4k") or db.seasons_4k(it["key"]):
            library.scans.add(naming.item_rel_path(it, uhd=True))
    log.info("restore: %s", out)
    return out
