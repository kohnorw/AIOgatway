"""Bridge process: request UI + TMDB providers (8770) and the client proxy (8771)."""
import asyncio
import logging

from aiohttp import web

from . import config, db, library, playback, provider, proxy, requests_ui

log = logging.getLogger("aio.bridge")

async def api_search(req):
    q = req.query.get("q", "")
    return web.json_response({"added": await library.search_and_add(q)})


async def api_add(req):
    """POST {"id": "tt0111161", "type": "movie"} or {"tmdb": 1399, "type": "series"}"""
    b = await req.json()
    stype = b.get("type", "movie")
    if b.get("tmdb"):
        fn = library.add_movie if stype == "movie" else library.add_show
        key, new = await fn(int(b["tmdb"]), "manual")
    else:
        key, new = await library.add_stremio(b["id"], stype, "manual")
    return web.json_response({"key": key, "new": new})


async def internal_activated(req):
    """Called by the filesystem when a title is first played: re-scan so Plex
    replaces the placeholder's media info with the real stream's."""
    rel = req.query.get("rel", "")
    if rel.endswith(".mkv"):
        asyncio.create_task(playback.heal(rel))      # exact file: analyze its Plex item
    elif rel:
        library.scans.add(rel)
    return web.json_response({"ok": True})


async def healthz(_):
    return web.json_response({"ok": True, "items": db.count_items()})


async def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    db.init()
    from . import placeholder
    await placeholder.ensure()          # one shared clip, built once
    app = web.Application()
    provider.routes(app)
    requests_ui.routes(app)
    app.router.add_get("/api/search", api_search)
    app.router.add_post("/api/add", api_add)
    app.router.add_post("/internal/activated", internal_activated)
    app.router.add_get("/healthz", healthz)

    runners = []
    for a, port in ((app, config.BRIDGE_PORT), (proxy.make_app(), config.PROXY_PORT)):
        r = web.AppRunner(a, access_log=None)
        await r.setup()
        await web.TCPSite(r, "0.0.0.0", port).start()
        runners.append(r)
    log.info("bridge on :%d, client proxy on :%d", config.BRIDGE_PORT, config.PROXY_PORT)

    tasks = [asyncio.create_task(library.scans.run()),
             asyncio.create_task(library.ensure_libraries()),
             asyncio.create_task(library.scheduler())]
    await asyncio.gather(*tasks)


if __name__ == "__main__":
    asyncio.run(main())
