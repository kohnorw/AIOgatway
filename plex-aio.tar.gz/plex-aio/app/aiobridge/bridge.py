"""Bridge process: TMDB providers + web UI (8770) and the client proxy (8771)."""
import asyncio
import html
import logging

from aiohttp import web

from . import clients, config, db, library, playback, provider, proxy

log = logging.getLogger("aio.bridge")

PAGE = """<!doctype html><html><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>plex-aio</title><style>
:root{color-scheme:light dark;--bg:#f6f6f4;--fg:#1b1b1b;--mut:#6b6b6b;--card:#fff;--line:#e3e3df;--acc:#e5a00d}
@media (prefers-color-scheme:dark){:root{--bg:#141414;--fg:#ececec;--mut:#9a9a9a;--card:#1f1f1f;--line:#2e2e2e}}
body{margin:0;font:15px/1.45 system-ui,sans-serif;background:var(--bg);color:var(--fg)}
main{max-width:860px;margin:0 auto;padding:24px 16px}h1{font-size:22px;margin:0 0 4px}
.mut{color:var(--mut)}.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px;margin:16px 0}
form{display:flex;gap:8px}input{flex:1;padding:9px 11px;border-radius:8px;border:1px solid var(--line);background:var(--bg);color:var(--fg)}
button{padding:9px 14px;border:0;border-radius:8px;background:var(--acc);color:#1b1b1b;font-weight:600;cursor:pointer}
ul{list-style:none;padding:0;margin:0}li{padding:7px 0;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;gap:12px}
code{font-size:13px;word-break:break-all}</style></head><body><main>
<h1>plex-aio</h1><div class=mut>{status}</div>
<div class=card><form method=post action="/ui/search"><input name=q placeholder="Search Cinemeta and add to Plex" required><button>Add</button></form>{msg}</div>
<div class=card><b>Metadata providers</b> <span class=mut>(Plex → Settings → Metadata Agents → Add Provider)</span>
<ul><li>Movies <code>{base}/movie</code></li><li>TV <code>{base}/tv</code></li></ul></div>
<div class=card><form method=post action="/ui/sync"><span style="flex:1">AIOStreams catalog sync <span class=mut>every {hours}h</span></span><button>Sync now</button></form></div>
<div class=card><b>Recently added</b><ul>{recent}</ul></div></main></body></html>"""


async def ui(req: web.Request, msg: str = ""):
    counts = db.count_items()
    items = sorted(db.all_items(), key=lambda i: -i["added_at"])[:25]
    recent = "".join(f"<li><span>{html.escape(i['title'])} <span class=mut>{i['year'] or ''}</span></span>"
                     f"<span class=mut>{'Movie' if i['kind'] == 'movie' else 'Show'}</span></li>" for i in items) \
        or "<li class=mut>Nothing yet.</li>"
    status = (f"{counts.get('movie', 0)} movies · {counts.get('show', 0)} shows · "
              f"Plex {'claimed' if clients.plex_token() else 'not claimed yet'} · "
              f"TMDB {'ok' if config.TMDB_API_KEY else 'key missing'} · "
              f"AIOStreams {'set' if config.AIOSTREAMS_MANIFEST_URL else 'not set'}")
    base = f"http://{req.host}"
    body = PAGE.replace("{status}", status).replace("{msg}", msg).replace("{base}", html.escape(base)) \
        .replace("{hours}", str(config.SYNC_INTERVAL_HOURS)).replace("{recent}", recent)
    return web.Response(text=body, content_type="text/html")


async def ui_search(req):
    q = (await req.post()).get("q", "").strip()
    added = await library.search_and_add(q, per_type=5) if q else []
    names = [html.escape(db.get_item(k)["title"]) for k in added if db.get_item(k)]
    msg = f"<p>Added: {', '.join(names)}</p>" if names else "<p class=mut>No new titles (already in library or no match).</p>"
    return await ui(req, msg)


async def ui_sync(req):
    asyncio.create_task(library.sync_catalogs())
    return await ui(req, "<p>Sync started.</p>")


async def api_search(req):
    q = req.query.get("q", "")
    return web.json_response({"added": await library.search_and_add(q)})


async def api_add(req):
    """POST {"id": "tt0111161", "type": "movie"} or {"tmdb": 1399, "type": "series"}"""
    b = await req.json()
    stype = b.get("type", "movie")
    if b.get("tmdb"):
        fn = library.add_movie if stype == "movie" else library.add_show
        key, new = await fn(int(b["tmdb"]), "manual")
    else:
        key, new = await library.add_stremio(b["id"], stype, "manual")
    return web.json_response({"key": key, "new": new})


async def api_remove(req):
    library.remove(req.match_info["key"])
    return web.json_response({"ok": True})


async def internal_activated(req):
    """Called by the filesystem when a title is first played: re-scan so Plex
    replaces the placeholder's media info with the real stream's."""
    rel = req.query.get("rel", "")
    if rel.endswith(".mkv"):
        asyncio.create_task(playback.heal(rel))      # exact file: analyze its Plex item
    elif rel:
        library.scans.add(rel)
    return web.json_response({"ok": True})


async def healthz(_):
    return web.json_response({"ok": True, "items": db.count_items()})


async def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    db.init()
    app = web.Application()
    provider.routes(app)
    app.router.add_get("/", ui)
    app.router.add_post("/ui/search", ui_search)
    app.router.add_post("/ui/sync", ui_sync)
    app.router.add_get("/api/search", api_search)
    app.router.add_post("/api/add", api_add)
    app.router.add_delete("/api/items/{key}", api_remove)
    app.router.add_post("/internal/activated", internal_activated)
    app.router.add_get("/healthz", healthz)

    runners = []
    for a, port in ((app, config.BRIDGE_PORT), (proxy.make_app(), config.PROXY_PORT)):
        r = web.AppRunner(a, access_log=None)
        await r.setup()
        await web.TCPSite(r, "0.0.0.0", port).start()
        runners.append(r)
    log.info("bridge on :%d, client proxy on :%d", config.BRIDGE_PORT, config.PROXY_PORT)

    tasks = [asyncio.create_task(library.scans.run()),
             asyncio.create_task(library.ensure_libraries()),
             asyncio.create_task(library.scheduler())]
    await asyncio.gather(*tasks)


if __name__ == "__main__":
    asyncio.run(main())
