"""Plex custom metadata providers backed by TMDB.

Implements the provider API Plex documents (MediaProvider definition,
/library/metadata/matches, /library/metadata/{ratingKey}[/children|/grandchildren|/images]).
Two providers are exposed, as Plex recommends one per library type:

    http://<host>:8770/movie   -> tv.plex.agents.custom.plexaio.tmdb.movie
    http://<host>:8770/tv      -> tv.plex.agents.custom.plexaio.tmdb.tv

ratingKeys:  m<tmdb> | s<tmdb> | s<tmdb>_<season> | e<tmdb>_<season>_<episode>
Matching checks the plex-aio database first (exact, via the {tmdb-id} folder
tag or title/year), then falls back to TMDB search.
"""
import logging
import re

from aiohttp import web

from . import config, db, naming
from .clients import TMDB, tmdb

log = logging.getLogger("aio.provider")
MOVIE, SHOW, SEASON, EPISODE = 1, 2, 3, 4


def _container(identifier, items, total=None, offset=0):
    return {"MediaContainer": {"offset": offset, "totalSize": total if total is not None else len(items),
                               "identifier": identifier, "size": len(items), "Metadata": items}}


def _lang(req):
    return req.headers.get("X-Plex-Language") or req.query.get("X-Plex-Language") or config.TMDB_LANGUAGE


def _country(req):
    return (req.headers.get("X-Plex-Country") or req.query.get("X-Plex-Country") or "US").upper()


def _year(d):
    return int(d[:4]) if d and d[:4].isdigit() else None


def _people(credits, limit=30):
    cast = [{"tag": c["name"], "role": c.get("character") or "", "order": i + 1,
             **({"thumb": TMDB.img(c["profile_path"])} if c.get("profile_path") else {})}
            for i, c in enumerate((credits.get("cast") or [])[:limit])]
    crew = credits.get("crew") or []

    def pick(jobs):
        seen, out = set(), []
        for c in crew:
            if c.get("job") in jobs and c["name"] not in seen:
                seen.add(c["name"])
                out.append({"tag": c["name"], "role": c.get("job"),
                            **({"thumb": TMDB.img(c["profile_path"])} if c.get("profile_path") else {})})
        return out[:10]

    return {"Role": cast, "Director": pick({"Director"}),
            "Writer": pick({"Screenplay", "Writer", "Story", "Novel", "Creator"}),
            "Producer": pick({"Producer", "Executive Producer"})}


def _images(data, alt, poster_type="coverPoster"):
    imgs = []
    if data.get("poster_path"):
        imgs.append({"type": poster_type, "url": TMDB.img(data["poster_path"]), "alt": alt})
    if data.get("backdrop_path"):
        imgs.append({"type": "background", "url": TMDB.img(data["backdrop_path"]), "alt": alt})
    logos = (data.get("images") or {}).get("logos") or []
    if logos:
        imgs.append({"type": "clearLogo", "url": TMDB.img(logos[0]["file_path"]), "alt": alt})
    return imgs


def _guids(ext, tmdb_id):
    g = [{"id": f"tmdb://{tmdb_id}"}]
    if ext.get("imdb_id"):
        g.append({"id": f"imdb://{ext['imdb_id']}"})
    if ext.get("tvdb_id"):
        g.append({"id": f"tvdb://{ext['tvdb_id']}"})
    return g


def _rating(v):
    return [{"image": "themoviedb://image.rating", "type": "audience", "value": round(float(v), 3)}] if v else []


# ===================================================================== movies ==

def movie_meta(m, country="US"):
    pid = config.MOVIE_PROVIDER_ID
    rk = f"m{m['id']}"
    cert = None
    for rel in (m.get("release_dates") or {}).get("results") or []:
        if rel.get("iso_3166_1") == country:
            for d in rel.get("release_dates") or []:
                if d.get("certification"):
                    cert = d["certification"]
                    break
    meta = {
        "type": "movie", "ratingKey": rk, "key": f"/library/metadata/{rk}",
        "guid": f"{pid}://movie/{rk}", "title": m.get("title") or m.get("original_title"),
        "originallyAvailableAt": m.get("release_date") or None, "year": _year(m.get("release_date")),
        "summary": m.get("overview") or "", "tagline": m.get("tagline") or None,
        "thumb": TMDB.img(m.get("poster_path")), "art": TMDB.img(m.get("backdrop_path")),
        "duration": (m.get("runtime") or 0) * 60000 or None,
        "studio": ((m.get("production_companies") or [{}])[0] or {}).get("name"),
        "Image": _images(m, m.get("title")),
        "Genre": [{"tag": g["name"]} for g in m.get("genres") or []],
        "Guid": _guids({**(m.get("external_ids") or {}), "imdb_id": m.get("imdb_id")}, m["id"]),
        "Rating": _rating(m.get("vote_average")),
        "Country": [{"tag": c["name"]} for c in m.get("production_countries") or []],
        "Studio": [{"tag": c["name"]} for c in m.get("production_companies") or []],
        **_people(m.get("credits") or {}),
    }
    if cert:
        meta["contentRating"] = cert if country == "US" else f"{country.lower()}/{cert}"
    if m.get("original_title") and m.get("original_title") != meta["title"]:
        meta["originalTitle"] = m["original_title"]
    if m.get("belongs_to_collection"):
        c = m["belongs_to_collection"]
        meta["Collection"] = [{"tag": c["name"], "guid": f"{pid}://collection/c{c['id']}",
                               "key": f"/library/collections/c{c['id']}"}]
    return {k: v for k, v in meta.items() if v not in (None, [], "")}


async def movie_match(body, lang):
    title, year = body.get("title") or "", body.get("year")
    tmdb_ids = []
    # 1. explicit ids from Plex (guid hints such as tmdb://, imdb://)
    for g in [body.get("guid")] + [x.get("id") for x in body.get("Guid") or [] if isinstance(x, dict)]:
        if not g:
            continue
        if g.startswith("tmdb://"):
            tmdb_ids.append(int(re.sub(r"\D", "", g.split("://")[1]) or 0))
        elif g.startswith("imdb://"):
            found = await tmdb.find_imdb(g.split("://")[1])
            tmdb_ids += [r["id"] for r in found.get("movie_results") or []]
    # 2. our own library: {tmdb-id} tag in any path hint, then title + year
    for hint in (body.get("filename"), body.get("path"), title):
        t = naming.tmdb_from_name(hint or "")
        if t:
            tmdb_ids.append(t)
    if not tmdb_ids:
        nt = naming.norm_title(title)
        for it in db.all_items("movie"):
            if naming.norm_title(it["title"]) == nt and (not year or not it["year"] or abs(it["year"] - int(year)) <= 1):
                tmdb_ids.append(it["tmdb"])
    # 3. TMDB search
    if not tmdb_ids or body.get("manual"):
        res = await tmdb.search("movie", title, year, lang) if title else []
        tmdb_ids += [r["id"] for r in res[: 10 if body.get("manual") else 1]]
    out, seen = [], set()
    for t in tmdb_ids:
        if t and t not in seen:
            seen.add(t)
            try:
                out.append(movie_meta(await tmdb.movie(t, lang)))
            except KeyError:
                pass
        if not body.get("manual") and out:
            break
    return out


# ======================================================================= shows ==

def _show_ref(s):
    rk = f"s{s['id']}"
    return {"rk": rk, "guid": f"{config.TV_PROVIDER_ID}://show/{rk}", "key": f"/library/metadata/{rk}",
            "title": s.get("name"), "thumb": TMDB.img(s.get("poster_path")), "art": TMDB.img(s.get("backdrop_path"))}


def show_meta(s, country="US"):
    ref = _show_ref(s)
    cert = next((r.get("rating") for r in (s.get("content_ratings") or {}).get("results") or []
                 if r.get("iso_3166_1") == country and r.get("rating")), None)
    meta = {
        "type": "show", "ratingKey": ref["rk"], "key": ref["key"] + "/children", "guid": ref["guid"],
        "title": s.get("name") or s.get("original_name"), "originallyAvailableAt": s.get("first_air_date") or None,
        "year": _year(s.get("first_air_date")), "summary": s.get("overview") or "",
        "tagline": s.get("tagline") or None, "thumb": ref["thumb"], "art": ref["art"],
        "duration": ((s.get("episode_run_time") or [0])[0] or 0) * 60000 or None,
        "studio": ((s.get("production_companies") or [{}])[0] or {}).get("name"),
        "Image": _images(s, s.get("name")),
        "Genre": [{"tag": g["name"]} for g in s.get("genres") or []],
        "Guid": _guids(s.get("external_ids") or {}, s["id"]),
        "Rating": _rating(s.get("vote_average")),
        "Network": [{"tag": n["name"]} for n in s.get("networks") or []],
        "Country": [{"tag": c["name"]} for c in s.get("production_countries") or []],
        "Studio": [{"tag": c["name"]} for c in s.get("production_companies") or []],
        **_people(s.get("credits") or {}),
    }
    if cert:
        meta["contentRating"] = cert if country == "US" else f"{country.lower()}/{cert}"
    return {k: v for k, v in meta.items() if v not in (None, [], "")}


def season_meta(s, se):
    ref = _show_ref(s)
    n = se["season_number"]
    rk = f"s{s['id']}_{n}"
    meta = {
        "type": "season", "ratingKey": rk, "key": f"/library/metadata/{rk}/children",
        "guid": f"{config.TV_PROVIDER_ID}://season/{rk}", "title": se.get("name") or f"Season {n}",
        "index": n, "originallyAvailableAt": se.get("air_date") or None, "year": _year(se.get("air_date")),
        "summary": se.get("overview") or "", "thumb": TMDB.img(se.get("poster_path")) or ref["thumb"],
        "parentRatingKey": ref["rk"], "parentKey": ref["key"], "parentGuid": ref["guid"],
        "parentType": "show", "parentTitle": ref["title"], "parentThumb": ref["thumb"],
        "Image": [i for i in [{"type": "coverPoster", "url": TMDB.img(se.get("poster_path"))} if se.get("poster_path") else None,
                              {"type": "background", "url": ref["art"]} if ref["art"] else None] if i],
    }
    if se.get("id"):
        meta["Guid"] = [{"id": f"tmdb://{se['id']}"}]
    return {k: v for k, v in meta.items() if v not in (None, [], "")}


def episode_meta(s, season_n, ep, season_title=None):
    ref = _show_ref(s)
    srk = f"s{s['id']}_{season_n}"
    rk = f"e{s['id']}_{season_n}_{ep['episode_number']}"
    meta = {
        "type": "episode", "ratingKey": rk, "key": f"/library/metadata/{rk}",
        "guid": f"{config.TV_PROVIDER_ID}://episode/{rk}", "title": ep.get("name") or f"Episode {ep['episode_number']}",
        "index": ep["episode_number"], "parentIndex": season_n,
        "originallyAvailableAt": ep.get("air_date") or None, "year": _year(ep.get("air_date")),
        "summary": ep.get("overview") or "", "thumb": TMDB.img(ep.get("still_path")),
        "duration": (ep.get("runtime") or 0) * 60000 or None,
        "parentRatingKey": srk, "parentKey": f"/library/metadata/{srk}",
        "parentGuid": f"{config.TV_PROVIDER_ID}://season/{srk}", "parentType": "season",
        "parentTitle": season_title or f"Season {season_n}",
        "grandparentRatingKey": ref["rk"], "grandparentKey": ref["key"], "grandparentGuid": ref["guid"],
        "grandparentType": "show", "grandparentTitle": ref["title"], "grandparentThumb": ref["thumb"],
        "Image": [{"type": "snapshot", "url": TMDB.img(ep["still_path"])}] if ep.get("still_path") else [],
        "Rating": _rating(ep.get("vote_average")),
        "Guid": [{"id": f"tmdb://{ep['id']}"}] if ep.get("id") else [],
        "Director": [{"tag": c["name"]} for c in ep.get("crew") or [] if c.get("job") == "Director"][:5],
        "Writer": [{"tag": c["name"]} for c in ep.get("crew") or [] if c.get("job") in ("Writer", "Screenplay")][:5],
        "Role": [{"tag": c["name"], "role": c.get("character") or ""} for c in ep.get("guest_stars") or []][:15],
    }
    return {k: v for k, v in meta.items() if v not in (None, [], "")}


async def _seasons(s, lang):
    return [se for se in s.get("seasons") or [] if se.get("season_number") is not None]


async def show_tree_meta(rk, lang, country, include_children):
    """Resolve any TV ratingKey to its Metadata object (with Children if asked)."""
    m = re.fullmatch(r"([se])(\d+)(?:_(\d+))?(?:_(\d+))?", rk)
    if not m:
        raise KeyError(rk)
    kind, sid, sn, en = m.group(1), int(m.group(2)), m.group(3), m.group(4)
    s = await tmdb.show(sid, lang)
    if kind == "s" and sn is None:
        meta = show_meta(s, country)
        if include_children:
            kids = [season_meta(s, se) for se in await _seasons(s, lang)]
            meta["Children"] = {"size": len(kids), "Metadata": kids}
        return meta
    season = await tmdb.season(sid, int(sn), lang)
    if kind == "s":
        se = next((x for x in s.get("seasons") or [] if x.get("season_number") == int(sn)), season)
        meta = season_meta(s, {**se, **{k: season.get(k) for k in ("name", "overview", "poster_path", "air_date") if season.get(k)}})
        if include_children:
            kids = [episode_meta(s, int(sn), e, meta.get("title")) for e in season.get("episodes") or []]
            meta["Children"] = {"size": len(kids), "Metadata": kids}
        return meta
    ep = next((e for e in season.get("episodes") or [] if e["episode_number"] == int(en)), None)
    if not ep:
        raise KeyError(rk)
    return episode_meta(s, int(sn), ep, season.get("name"))


def _library_show(title, year):
    nt = naming.norm_title(title or "")
    t = naming.tmdb_from_name(title or "")
    for it in db.all_items("show"):
        if t and it["tmdb"] == t:
            return it["tmdb"]
        if naming.norm_title(it["title"]) == nt and (not year or not it["year"] or abs(it["year"] - int(year)) <= 1):
            return it["tmdb"]
    return None


async def _show_id_for(title, year, guids, lang):
    for g in guids:
        if g and g.startswith("tmdb://"):
            return int(re.sub(r"\D", "", g.split("://")[1]))
        if g and (g.startswith("imdb://") or g.startswith("tvdb://")):
            src = "imdb_id" if g.startswith("imdb") else "tvdb_id"
            found = await tmdb.get(f"/find/{g.split('://')[1]}", external_source=src)
            if found.get("tv_results"):
                return found["tv_results"][0]["id"]
    sid = _library_show(title, year)
    if sid:
        return sid
    res = await tmdb.search("tv", title, year, lang) if title else []
    return res[0]["id"] if res else None


async def tv_match(body, lang, country):
    t = int(body.get("type") or SHOW)
    guids = [body.get("guid")] + [x.get("id") for x in body.get("Guid") or [] if isinstance(x, dict)]
    if t == SHOW:
        if body.get("manual"):
            res = await tmdb.search("tv", body.get("title") or "", body.get("year"), lang)
            return [show_meta(await tmdb.show(r["id"], lang), country) for r in res[:10]]
        sid = await _show_id_for(body.get("title"), body.get("year"), guids, lang)
        return [show_meta(await tmdb.show(sid, lang), country)] if sid else []
    if t == SEASON:
        sid = await _show_id_for(body.get("parentTitle"), body.get("parentYear") or body.get("year"),
                                 [body.get("parentGuid")], lang)
        return [await show_tree_meta(f"s{sid}_{int(body.get('index') or 0)}", lang, country, False)] if sid else []
    if t == EPISODE:
        sid = await _show_id_for(body.get("grandparentTitle"), body.get("grandparentYear") or body.get("year"),
                                 [body.get("grandparentGuid")], lang)
        if not sid:
            return []
        if body.get("parentIndex") is None and body.get("date"):
            # air-date matching
            s = await tmdb.show(sid, lang)
            for se in s.get("seasons") or []:
                season = await tmdb.season(sid, se["season_number"], lang)
                for e in season.get("episodes") or []:
                    if e.get("air_date") == body["date"]:
                        return [episode_meta(s, se["season_number"], e, season.get("name"))]
            return []
        rk = f"e{sid}_{int(body.get('parentIndex') or 1)}_{int(body.get('index') or 1)}"
        try:
            return [await show_tree_meta(rk, lang, country, False)]
        except KeyError:
            return []
    return []


# ======================================================================= routes ==

def _provider_def(identifier, title, types):
    return {"MediaProvider": {
        "identifier": identifier, "title": title, "version": "1.0.0",
        "Types": [{"type": t, "Scheme": [{"scheme": identifier}]} for t in types],
        "Feature": [{"type": "metadata", "key": "/library/metadata"},
                    {"type": "match", "key": "/library/metadata/matches"}],
    }}


def _err(e):
    status = 404 if isinstance(e, KeyError) else 500
    if status == 500:
        log.exception("provider error")
    return web.json_response({"error": str(e)}, status=status)


def _paging(req):
    size = int(req.headers.get("X-Plex-Container-Size") or req.query.get("X-Plex-Container-Size") or 20)
    start = int(req.headers.get("X-Plex-Container-Start") or req.query.get("X-Plex-Container-Start") or 1)
    return size, max(1, start)


def routes(app: web.Application):
    mid, tid = config.MOVIE_PROVIDER_ID, config.TV_PROVIDER_ID

    async def movie_root(_):
        return web.json_response(_provider_def(mid, "plex-aio TMDB Movies", [MOVIE]))

    async def movie_matches(req):
        try:
            body = await req.json() if req.can_read_body else dict(req.query)
            return web.json_response(_container(mid, await movie_match(body, _lang(req))))
        except Exception as e:  # noqa: BLE001
            return _err(e)

    async def movie_get(req):
        try:
            rk = req.match_info["rk"]
            if not rk.startswith("m"):
                raise KeyError(rk)
            m = await tmdb.movie(int(rk[1:]), _lang(req))
            meta = movie_meta(m, _country(req))
            if req.match_info.get("sub") == "images":
                return web.json_response({"MediaContainer": {"offset": 0, "identifier": mid,
                                                             "size": len(meta.get("Image", [])), "totalSize": len(meta.get("Image", [])),
                                                             "Image": meta.get("Image", [])}})
            return web.json_response(_container(mid, [meta]))
        except Exception as e:  # noqa: BLE001
            return _err(e)

    async def tv_root(_):
        return web.json_response(_provider_def(tid, "plex-aio TMDB TV", [SHOW, SEASON, EPISODE]))

    async def tv_matches(req):
        try:
            body = await req.json() if req.can_read_body else dict(req.query)
            return web.json_response(_container(tid, await tv_match(body, _lang(req), _country(req))))
        except Exception as e:  # noqa: BLE001
            return _err(e)

    async def tv_get(req):
        try:
            rk, sub = req.match_info["rk"], req.match_info.get("sub")
            lang, country = _lang(req), _country(req)
            if sub == "images":
                meta = await show_tree_meta(rk, lang, country, False)
                imgs = meta.get("Image", [])
                return web.json_response({"MediaContainer": {"offset": 0, "identifier": tid, "size": len(imgs),
                                                             "totalSize": len(imgs), "Image": imgs}})
            if sub in ("children", "grandchildren"):
                size, start = _paging(req)
                if sub == "children":
                    parent = await show_tree_meta(rk, lang, country, True)
                    kids = (parent.get("Children") or {}).get("Metadata", [])
                else:
                    show = await show_tree_meta(rk, lang, country, True)
                    kids = []
                    for se in (show.get("Children") or {}).get("Metadata", []):
                        sm = await show_tree_meta(se["ratingKey"], lang, country, True)
                        kids += (sm.get("Children") or {}).get("Metadata", [])
                page = kids[start - 1: start - 1 + size]
                return web.json_response(_container(tid, page, total=len(kids), offset=start - 1))
            include = (req.query.get("includeChildren") == "1")
            return web.json_response(_container(tid, [await show_tree_meta(rk, lang, country, include)]))
        except Exception as e:  # noqa: BLE001
            return _err(e)

    app.router.add_get("/movie", movie_root)
    app.router.add_post("/movie/library/metadata/matches", movie_matches)
    app.router.add_get("/movie/library/metadata/matches", movie_matches)
    app.router.add_get(r"/movie/library/metadata/{rk}", movie_get)
    app.router.add_get(r"/movie/library/metadata/{rk}/{sub:images}", movie_get)
    app.router.add_get("/tv", tv_root)
    app.router.add_post("/tv/library/metadata/matches", tv_matches)
    app.router.add_get("/tv/library/metadata/matches", tv_matches)
    app.router.add_get(r"/tv/library/metadata/{rk}", tv_get)
    app.router.add_get(r"/tv/library/metadata/{rk}/{sub:children|grandchildren|images}", tv_get)
