"""Make Plex know the real file before the first play.

Plex stores media info from the scanner's probe, which saw the placeholder
(black 1 fps H.264). If playback starts from that, Plex streams/transcodes the
wrong layout and clients show a black picture. So when a client asks Plex for
a playback decision, the proxy calls `prepare()` first:

  1. map the Plex item to its plex-aio file(s),
  2. resolve the real stream through AIOStreams (once) and mark it activated,
     so every reader, including the scanner, now sees the real file,
  3. ask Plex to analyze the item and wait until it has stored the real size.
"""
import asyncio
import logging
import re
import time
import urllib.parse

from . import clients, config, db, naming, vfs
from .clients import plex

log = logging.getLogger("aio.playback")
_tree = vfs.Tree()
_inflight: dict[str, asyncio.Task] = {}
_ready: dict[str, float] = {}

RK_RE = re.compile(r"/library/metadata/(\d+)")


def rating_key_from(req_query) -> str | None:
    for k in ("path", "key", "uri"):
        v = urllib.parse.unquote(req_query.get(k, "") or "")
        m = RK_RE.search(v)
        if m:
            return m.group(1)
    return None


async def _parts(rk: str) -> list[dict]:
    data = await plex.req("GET", f"/library/metadata/{rk}")
    out = []
    for md in data.get("MediaContainer", {}).get("Metadata", []) or []:
        for media in md.get("Media", []) or []:
            for part in media.get("Part", []) or []:
                out.append(part)
    return out


async def resolve(node) -> int | None:
    """Resolve and persist the real stream for a node. Returns its size."""
    s = db.get_stream(node.stream_key)
    if s and s.get("activated") and s.get("size") and vfs.stream_url_fresh(s):
        return int(s["size"])
    stype, sid, uhd = naming.split_stream_key(node.stream_key)
    base = clients.addon_base(config.AIOSTREAMS_MANIFEST_URL)
    async with clients.session().get(f"{base}/stream/{stype}/{urllib.parse.quote(sid, safe=':')}.json") as r:
        r.raise_for_status()
        data = await r.json(content_type=None)
    pick = vfs.pick_stream(data.get("streams") or [], (s or {}).get("filename"), uhd, node.stream_key)
    if not pick:
        raise RuntimeError(f"AIOStreams has no playable stream for {node.stream_key}")
    hints = pick.get("behaviorHints") or {}
    size = hints.get("videoSize")
    if not size:
        async with clients.session().get(pick["url"], headers={"Range": "bytes=0-0"}) as r:
            cr = r.headers.get("Content-Range", "")
            size = int(cr.rsplit("/", 1)[1]) if "/" in cr and cr.rsplit("/", 1)[1].isdigit() \
                else int(r.headers.get("Content-Length") or 0) or None
    if not size:
        raise RuntimeError("could not determine stream size")
    db.save_stream(node.stream_key, pick["url"], int(size), hints.get("filename"))
    vfs.remember_pick(node.stream_key, pick)
    log.info("resolved %s -> %s (%s bytes)", node.stream_key, hints.get("filename") or "stream", size)
    return int(size)


async def _prepare(rk: str):
    parts = await _parts(rk)
    targets = []
    for part in parts:
        f = part.get("file") or ""
        if not f.startswith(config.MOUNT_POINT + "/"):
            continue
        node = _tree.resolve(f[len(config.MOUNT_POINT) + 1:])
        if node is None or node.is_dir:
            continue
        size = await resolve(node)
        if int(part.get("size") or 0) != size:
            targets.append(size)
    if not targets:
        return False                            # Plex already has the real file info
    log.info("analyzing item %s so Plex sees the real stream", rk)
    await plex.req("PUT", f"/library/metadata/{rk}/analyze")
    deadline = time.monotonic() + 45
    want = set(targets)
    while time.monotonic() < deadline:
        await asyncio.sleep(1.5)
        sizes = {int(p.get("size") or 0) for p in await _parts(rk)}
        if want <= sizes:
            log.info("item %s ready for playback", rk)
            return True
    log.warning("item %s: Plex did not finish analysis in time; playing anyway", rk)
    return True


async def prepare(rk: str) -> bool:
    """Idempotent and shared across concurrent requests for the same item.
    Returns True if it had Plex analyze the item."""
    if _ready.get(rk, 0) > time.time():
        return False
    task = _inflight.get(rk)
    if task is None:
        task = _inflight[rk] = asyncio.create_task(_prepare(rk))
    try:
        analyzed = await asyncio.shield(task)
        _ready[rk] = time.time() + 600
        return bool(analyzed)
    except Exception as e:  # noqa: BLE001
        log.warning("prepare %s failed: %s", rk, e)
        return False
    finally:
        if task.done():
            _inflight.pop(rk, None)


# --- healing from the filesystem side ------------------------------------------
# Clients that reach Plex without going through the proxy never trigger
# prepare(). The filesystem therefore reports every switch to the real
# stream; we find the Plex item that owns that file and analyze it if Plex
# still holds the placeholder's media info.

_healed: dict[str, float] = {}


async def _find_rating_key(node) -> str | None:
    path = f"{config.MOUNT_POINT}/{node.rel}"
    section = await plex.section_for(path)
    if not section:
        return None
    item = node.item
    kind = 1 if item["kind"] == "movie" else 2
    data = await plex.req("GET", f"/library/sections/{section['key']}/all", type=kind, title=item["title"])
    for md in data.get("MediaContainer", {}).get("Metadata", []) or []:
        if kind == 1:
            for media in md.get("Media", []) or []:
                for part in media.get("Part", []) or []:
                    if part.get("file") == path:
                        return str(md["ratingKey"])
        else:
            leaves = await plex.req("GET", f"/library/metadata/{md['ratingKey']}/allLeaves")
            for ep in leaves.get("MediaContainer", {}).get("Metadata", []) or []:
                for media in ep.get("Media", []) or []:
                    for part in media.get("Part", []) or []:
                        if part.get("file") == path:
                            return str(ep["ratingKey"])
    return None




async def heal(rel: str):
    """Runs on every playback (any player): analyze the played file and
    refresh its metadata, so Plex holds the real stream's media info."""
    if _healed.get(rel, 0) > time.time():
        return
    _healed[rel] = time.time() + max(1, config.PLAYBACK_REANALYZE_MINUTES) * 60
    node = _tree.resolve(rel)
    if node is None or node.is_dir:
        return
    try:
        rk = await _find_rating_key(node)
        if not rk:
            log.info("no Plex item for %s yet; rescanning its folder", rel)
            from . import library
            library.scans.add(node.item_rel)
            return
        _ready.pop(rk, None)
        analyzed = await prepare(rk)           # resolve; analyze + wait if size is wrong
        log.info("playback of item %s: analyzing file and refreshing metadata", rk)
        if not analyzed:
            await plex.req("PUT", f"/library/metadata/{rk}/analyze")
        await plex.req("PUT", f"/library/metadata/{rk}/refresh")
    except Exception as e:  # noqa: BLE001
        log.warning("heal %s failed: %s", rel, e)
        _healed.pop(rel, None)
