"""Make Plex know the real file before the first play.

Plex stores media info from the scanner's probe, which saw the placeholder
(black 1 fps H.264). If playback starts from that, Plex streams/transcodes the
wrong layout and clients show a black picture. So when a client asks Plex for
a playback decision, the proxy calls `prepare()` first:

  1. map the Plex item to its plex-aio file(s),
  2. resolve the real stream through AIOStreams (once) and mark it activated,
     so every reader, including the scanner, now sees the real file,
  3. ask Plex to analyze the item and wait until it has stored the real size.
"""
import asyncio
import logging
import re
import time
import urllib.parse

from . import clients, config, db, vfs
from .clients import plex

log = logging.getLogger("aio.playback")
_tree = vfs.Tree()
_inflight: dict[str, asyncio.Task] = {}
_ready: dict[str, float] = {}

RK_RE = re.compile(r"/library/metadata/(\d+)")


def rating_key_from(req_query) -> str | None:
    for k in ("path", "key", "uri"):
        v = urllib.parse.unquote(req_query.get(k, "") or "")
        m = RK_RE.search(v)
        if m:
            return m.group(1)
    return None


async def _parts(rk: str) -> list[dict]:
    data = await plex.req("GET", f"/library/metadata/{rk}")
    out = []
    for md in data.get("MediaContainer", {}).get("Metadata", []) or []:
        for media in md.get("Media", []) or []:
            for part in media.get("Part", []) or []:
                out.append(part)
    return out


async def resolve(node) -> int | None:
    """Resolve and persist the real stream for a node. Returns its size."""
    s = db.get_stream(node.stream_key)
    if s and s.get("activated") and s.get("size") and vfs.stream_url_fresh(s):
        return int(s["size"])
    stype, sid = node.stream_key.split("/", 1)
    base = clients.addon_base(config.AIOSTREAMS_MANIFEST_URL)
    async with clients.session().get(f"{base}/stream/{stype}/{urllib.parse.quote(sid, safe=':')}.json") as r:
        r.raise_for_status()
        data = await r.json(content_type=None)
    pick = vfs.pick_stream(data.get("streams") or [], (s or {}).get("filename"))
    if not pick:
        raise RuntimeError(f"AIOStreams has no playable stream for {node.stream_key}")
    hints = pick.get("behaviorHints") or {}
    size = hints.get("videoSize")
    if not size:
        async with clients.session().get(pick["url"], headers={"Range": "bytes=0-0"}) as r:
            cr = r.headers.get("Content-Range", "")
            size = int(cr.rsplit("/", 1)[1]) if "/" in cr and cr.rsplit("/", 1)[1].isdigit() \
                else int(r.headers.get("Content-Length") or 0) or None
    if not size:
        raise RuntimeError("could not determine stream size")
    db.save_stream(node.stream_key, pick["url"], int(size), hints.get("filename"))
    log.info("resolved %s -> %s (%s bytes)", node.stream_key, hints.get("filename") or "stream", size)
    return int(size)


async def _prepare(rk: str):
    parts = await _parts(rk)
    targets = []
    for part in parts:
        f = part.get("file") or ""
        if not f.startswith(config.MOUNT_POINT + "/"):
            continue
        node = _tree.resolve(f[len(config.MOUNT_POINT) + 1:])
        if node is None or node.is_dir:
            continue
        size = await resolve(node)
        if int(part.get("size") or 0) != size:
            targets.append(size)
    if not targets:
        return                                  # Plex already has the real file info
    log.info("analyzing item %s so Plex sees the real stream", rk)
    await plex.req("PUT", f"/library/metadata/{rk}/analyze")
    deadline = time.monotonic() + 45
    want = set(targets)
    while time.monotonic() < deadline:
        await asyncio.sleep(1.5)
        sizes = {int(p.get("size") or 0) for p in await _parts(rk)}
        if want <= sizes:
            log.info("item %s ready for playback", rk)
            return
    log.warning("item %s: Plex did not finish analysis in time; playing anyway", rk)


async def prepare(rk: str):
    """Idempotent and shared across concurrent requests for the same item."""
    if _ready.get(rk, 0) > time.time():
        return
    task = _inflight.get(rk)
    if task is None:
        task = _inflight[rk] = asyncio.create_task(_prepare(rk))
    try:
        await asyncio.shield(task)
        _ready[rk] = time.time() + 600
    except Exception as e:  # noqa: BLE001
        log.warning("prepare %s failed: %s", rk, e)
    finally:
        if task.done():
            _inflight.pop(rk, None)
