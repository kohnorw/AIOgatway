"""One tiny MKV that Plex's scanner probes instead of the real stream.

Plex's scanner pipeline always runs a media-analysis stage on new files
(ScannerPiplineStagePerformMediaAnalysis in the PMS binary). Every title
shares this single 45-second black 1080p H.264 + silent AAC clip (~130 KB),
built once, so adding titles never waits on ffmpeg and each probe is
near-instant. Runtime shown in Plex comes from the TMDB metadata, and the
real stream's media info replaces this on first playback.

The FUSE layer zero-pads reads past the clip's end, and files report the
real (or a large) size, so Plex never caps reads at the clip length.
"""
import asyncio
import logging
import os

from . import config

log = logging.getLogger("aio.placeholder")
SECONDS = 45
_lock = asyncio.Lock()


def path_for(_minutes=None) -> str:
    return os.path.join(config.PLACEHOLDER_DIR, "placeholder.mkv")


async def ensure(_minutes=None) -> str:
    out = path_for()
    if os.path.exists(out):
        return out
    async with _lock:
        if os.path.exists(out):
            return out
        os.makedirs(config.PLACEHOLDER_DIR, exist_ok=True)
        tmp = out + ".tmp.mkv"
        proc = await asyncio.create_subprocess_exec(
            "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
            "-f", "lavfi", "-i", "color=c=black:s=1920x1080:r=1",
            "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-t", str(SECONDS),
            "-c:v", "libx264", "-preset", "ultrafast", "-tune", "stillimage", "-crf", "51",
            "-g", "60", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "8k",
            "-metadata", "title=plex-aio placeholder", tmp,
            stderr=asyncio.subprocess.PIPE)
        _, err = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(f"ffmpeg failed: {err.decode(errors='replace')[-400:]}")
        os.replace(tmp, out)
        log.info("generated placeholder %s (%d bytes)", out, os.path.getsize(out))
        return out
