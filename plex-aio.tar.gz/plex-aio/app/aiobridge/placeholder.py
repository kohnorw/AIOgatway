"""Tiny, valid MKV files that Plex's scanner probes instead of the real stream.

Plex's scanner pipeline has a mandatory media-analysis stage (found in the PMS
binary as ScannerPiplineStagePerformMediaAnalysis), so every new file is
opened once. We hand the scanner a black 1080p H.264 + silent AAC clip of the
right runtime, which keeps the analysis fast and never touches debrid.

Clips are bucketed to 5-minute steps and shared by every title of that length.
"""
import asyncio
import logging
import os

from . import config

log = logging.getLogger("aio.placeholder")
BUCKET_MIN = 5
_locks: dict[int, asyncio.Lock] = {}


def bucket(minutes) -> int:
    m = int(minutes or 0) or 45
    m = max(BUCKET_MIN, min(m, 600))
    return ((m + BUCKET_MIN - 1) // BUCKET_MIN) * BUCKET_MIN


def path_for(minutes) -> str:
    return os.path.join(config.PLACEHOLDER_DIR, f"{bucket(minutes)}.mkv")


async def ensure(minutes) -> str:
    b = bucket(minutes)
    out = path_for(b)
    if os.path.exists(out):
        return out
    lock = _locks.setdefault(b, asyncio.Lock())
    async with lock:
        if os.path.exists(out):
            return out
        os.makedirs(config.PLACEHOLDER_DIR, exist_ok=True)
        seed = await _seed()
        tmp = out + ".tmp.mkv"
        # stream-copy the 1-minute seed: no re-encode, takes well under a second
        await _ffmpeg("-stream_loop", str(b - 1), "-i", seed, "-c", "copy", "-t", str(b * 60),
                      "-metadata", "title=plex-aio placeholder", tmp)
        os.replace(tmp, out)
        log.info("generated placeholder %s (%d bytes)", out, os.path.getsize(out))
        return out


async def _ffmpeg(*args):
    proc = await asyncio.create_subprocess_exec("ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *args,
                                                stderr=asyncio.subprocess.PIPE)
    _, err = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg failed: {err.decode(errors='replace')[-400:]}")


_seed_lock = asyncio.Lock()


async def _seed() -> str:
    """One minute of black 1080p H.264 + silent stereo AAC, encoded once."""
    seed = os.path.join(config.PLACEHOLDER_DIR, "seed-60s.mkv")
    async with _seed_lock:
        if not os.path.exists(seed):
            tmp = seed + ".tmp.mkv"
            await _ffmpeg("-f", "lavfi", "-i", "color=c=black:s=1920x1080:r=1",
                          "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-t", "60",
                          "-c:v", "libx264", "-preset", "ultrafast", "-tune", "stillimage", "-crf", "51",
                          "-g", "60", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "8k", tmp)
            os.replace(tmp, seed)
    return seed
