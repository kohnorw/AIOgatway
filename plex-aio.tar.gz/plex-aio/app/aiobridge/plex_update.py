"""Update Plex Media Server from the Settings page.

Two halves, split on purpose:

* Bridge (runs as the unprivileged `abc` user): shows the installed and the
  newest version, and *asks* for an update by writing a tiny request file
  (just the channel). It never downloads or hands over a package.
* Installer (`python -m aiobridge.plex_update`, run as root by the
  svc-aio-updater service): reads that request, looks the release up on
  plex.tv itself, downloads it into a root-only folder, checks plex.tv's
  checksum and that the package really is `plexmediaserver`, then stops
  Plex, installs it with dpkg and starts Plex again.

Nothing the `abc` user can write is ever installed, so a bug in the web app
can't be turned into root. Status goes to /run (root-owned, world-readable).

The wanted version is remembered in /config, so after the container is
recreated from an older image the installer brings Plex back up to it -
by downloading it from plex.tv again, not by trusting a cached file.
"""
import asyncio
import hashlib
import json
import logging
import os
import re
import subprocess
import sys
import time
import urllib.request
import xml.etree.ElementTree as ET

DOWNLOADS = "https://plex.tv/api/downloads/5.json"
REQ_DIR = "/config/aio/plex-update"                 # abc-writable: requests only
REQUEST = f"{REQ_DIR}/request.json"                 # {"channel": "public"|"beta"}
WANT = f"{REQ_DIR}/want.json"                       # version to keep after recreation
STATUS_DIR = "/run/plex-aio-update"                 # root-owned, readable by abc
STATUS = f"{STATUS_DIR}/status.json"
PKG_DIR = "/var/lib/plex-aio-update"                # root-only: downloads live here
PLEX_PREFS = "/config/Library/Application Support/Plex Media Server/Preferences.xml"
PLEX_SERVICE = "/run/service/svc-plex"
CHANNELS = ("public", "beta")

log = logging.getLogger("aio.plexupdate")


# ── shared helpers ─────────────────────────────────────────────────────────────

def vkey(v: str):
    """'1.41.2.9200-c6bbc1b53' -> (1, 41, 2, 9200)"""
    return tuple(int(x) for x in re.findall(r"\d+", (v or "").split("-")[0])[:4])


def installed_version() -> str | None:
    try:
        out = subprocess.run(["dpkg-query", "-W", "-f=${Version}", "plexmediaserver"],
                             capture_output=True, text=True, timeout=10)
        return out.stdout.strip() or None
    except (OSError, subprocess.SubprocessError):
        return None


def _build() -> str:
    try:
        arch = subprocess.run(["dpkg", "--print-architecture"], capture_output=True, text=True, timeout=10).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        arch = "amd64"
    return {"amd64": "linux-x86_64", "arm64": "linux-aarch64", "armhf": "linux-armv7hf_neon"}.get(arch, "linux-x86_64")


def pick_release(data: dict, build: str) -> dict:
    """plex.tv downloads JSON -> {'version', 'url', 'checksum', 'notes', 'date'} for our machine."""
    linux = (data.get("computer") or {}).get("Linux") or {}
    rel = next((x for x in linux.get("releases") or [] if x.get("build") == build and x.get("distro") == "debian"), None)
    if not rel or not str(rel.get("url", "")).startswith("https://"):
        raise RuntimeError(f"plex.tv has no Debian package for {build}")
    notes = "\n".join(x for x in (linux.get("items_added"), linux.get("items_fixed")) if x)
    return {"version": linux.get("version"), "url": rel["url"], "checksum": rel.get("checksum"),
            "notes": notes, "date": linux.get("release_date")}


def _read_small(path: str, limit: int = 4096):
    """Read a small file without following symlinks (abc controls REQ_DIR)."""
    import stat
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise OSError(f"{path} is not a regular file")
        return os.read(fd, limit)
    finally:
        os.close(fd)


def read_status() -> dict:
    try:
        return json.loads(_read_small(STATUS, 65536))
    except (OSError, ValueError):
        return {}


# ── bridge side (abc) ──────────────────────────────────────────────────────────

async def latest(channel: str) -> dict:
    from . import clients
    import aiohttp
    params = {"channel": "plexpass"} if channel == "beta" else {}
    headers = {"Accept": "application/json"}
    if channel == "beta" and clients.plex_token():
        headers["X-Plex-Token"] = clients.plex_token()
    async with clients.session().get(DOWNLOADS, params=params, headers=headers,
                                     timeout=aiohttp.ClientTimeout(total=30)) as r:
        r.raise_for_status()
        return pick_release(await r.json(content_type=None), _build())


async def status_handler(req):
    from aiohttp import web
    channel = req.query.get("channel") if req.query.get("channel") in CHANNELS else "public"
    out = {"installed": installed_version(), "channel": channel, "job": read_status()}
    if os.path.exists(REQUEST):
        out["job"] = {"state": "queued", "message": "Update requested - starting…", "at": time.time()}
    try:
        rel = await latest(channel)
        out["latest"] = {k: rel[k] for k in ("version", "notes", "date")}
        out["update_available"] = bool(out["installed"]) and vkey(rel["version"]) > vkey(out["installed"])
    except Exception as e:  # noqa: BLE001
        out["error"] = f"Couldn't check plex.tv: {e}"
    return web.json_response(out)


async def update_handler(req):
    from aiohttp import web
    job = read_status()
    if job.get("state") in ("checking", "downloading", "installing") and time.time() - job.get("at", 0) < 1800:
        return web.json_response({"error": "An update is already running"}, status=409)
    b = await req.json() if req.can_read_body else {}
    channel = b.get("channel") if b.get("channel") in CHANNELS else "public"
    os.makedirs(REQ_DIR, exist_ok=True)
    tmp = f"{REQUEST}.{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"channel": channel}, f)
    os.replace(tmp, REQUEST)
    log.info("Plex update requested (%s channel)", channel)
    return web.json_response({"job": {"state": "queued", "message": "Update requested…", "at": time.time()}})


def routes(app):
    app.router.add_get("/api/plex/version", status_handler)
    app.router.add_post("/api/plex/update", update_handler)


# ── installer side (root) ──────────────────────────────────────────────────────

def _status(state: str, message: str, **extra):
    os.makedirs(STATUS_DIR, mode=0o755, exist_ok=True)
    tmp = f"{STATUS}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"state": state, "message": message, "at": time.time(), **extra}, f)
    os.chmod(tmp, 0o644)
    os.replace(tmp, STATUS)
    print(f"[plex-aio] Plex update: {message}", flush=True)


def _plex_token() -> str | None:
    try:
        return ET.fromstring(_read_small(PLEX_PREFS, 1 << 20)).get("PlexOnlineToken")
    except (OSError, ET.ParseError):
        return None


def _fetch_release(channel: str) -> dict:
    url = DOWNLOADS + ("?channel=plexpass" if channel == "beta" else "")
    headers = {"Accept": "application/json", "User-Agent": "plex-aio"}
    tok = _plex_token() if channel == "beta" else None
    if tok:
        headers["X-Plex-Token"] = tok
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=30) as r:
        return pick_release(json.loads(r.read()), _build())


def _download(rel: dict) -> str:
    os.makedirs(PKG_DIR, mode=0o700, exist_ok=True)
    os.chmod(PKG_DIR, 0o700)
    path = os.path.join(PKG_DIR, "plexmediaserver.deb")
    sha1 = hashlib.sha1()
    req = urllib.request.Request(rel["url"], headers={"User-Agent": "plex-aio"})
    with urllib.request.urlopen(req, timeout=60) as r, open(path + ".part", "wb") as f:
        while chunk := r.read(1 << 20):
            f.write(chunk)
            sha1.update(chunk)
    want = (rel.get("checksum") or "").lower()
    if want and sha1.hexdigest() != want:
        os.remove(path + ".part")
        raise RuntimeError("download checksum doesn't match plex.tv's - not installing")
    os.replace(path + ".part", path)
    pkg = subprocess.run(["dpkg-deb", "-f", path, "Package"], capture_output=True, text=True, timeout=30).stdout.strip()
    if pkg != "plexmediaserver":
        raise RuntimeError(f"downloaded file isn't the Plex package ({pkg or 'unreadable'}) - not installing")
    return path


def install(channel: str, minimum: str | None = None):
    _status("checking", "Checking plex.tv…")
    rel = _fetch_release(channel)
    cur = installed_version()
    if cur and vkey(rel["version"]) <= vkey(cur):
        _status("done", f"Already on the newest version ({cur})", installed=cur)
        return
    if minimum and vkey(rel["version"]) < vkey(minimum):
        raise RuntimeError(f"plex.tv offers {rel['version']}, older than the wanted {minimum}")
    _status("downloading", f"Downloading Plex {rel['version']}…")
    path = _download(rel)
    _status("installing", f"Installing Plex {rel['version']} - Plex restarts, playback stops for about a minute…")
    subprocess.run(["s6-svc", "-d", PLEX_SERVICE], timeout=30)
    time.sleep(3)
    res = subprocess.run(["dpkg", "-i", "--force-confold", path], capture_output=True, text=True, timeout=600)
    subprocess.run(["s6-svc", "-u", PLEX_SERVICE], timeout=30)
    if res.returncode != 0:
        with open(os.path.join(PKG_DIR, "dpkg.log"), "w") as f:
            f.write(res.stdout + res.stderr)
        raise RuntimeError(f"dpkg failed (exit {res.returncode}) - Plex restarted on the old version")
    new = installed_version()
    _write_want(new, channel)       # so a recreated container comes back up to this version
    _status("done", f"Plex updated to {new} and restarted", installed=new)


def _write_want(version, channel):
    """Version + channel only (no package). Root writes it; it's just a hint."""
    try:
        tmp = WANT + ".tmp"
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        # O_EXCL: always a fresh file root just created - never a pre-planted file, link or hard link
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
        with os.fdopen(fd, "w") as f:
            json.dump({"version": version, "channel": channel}, f)
        os.replace(tmp, WANT)
    except OSError as e:
        print(f"[plex-aio] couldn't save wanted Plex version: {e}", flush=True)


def _take_request():
    try:
        raw = _read_small(REQUEST)
    except OSError:
        return None
    try:
        os.remove(REQUEST)
    except OSError:
        pass
    try:
        ch = json.loads(raw).get("channel")
    except (ValueError, AttributeError):
        ch = None
    return ch if ch in CHANNELS else "public"


def _restore_after_recreate():
    """Container recreated from an older image: bring Plex back to the last updated version."""
    try:
        want = json.loads(_read_small(WANT))
    except (OSError, ValueError):
        return
    ver, ch = str(want.get("version") or ""), want.get("channel")
    cur = installed_version()
    if ver and cur and vkey(ver) > vkey(cur):
        print(f"[plex-aio] Plex {cur} is older than the last update ({ver}) - updating again", flush=True)
        install(ch if ch in CHANNELS else "public", minimum=ver)


def run_installer():
    if os.geteuid() != 0:
        sys.exit("the Plex installer must run as root")
    time.sleep(20)                       # let Plex finish starting first
    try:
        _restore_after_recreate()
    except Exception as e:  # noqa: BLE001
        _status("error", f"Update failed: {e}")
    while True:
        ch = _take_request()
        if ch:
            try:
                install(ch)
            except Exception as e:  # noqa: BLE001
                _status("error", f"Update failed: {e}")
        time.sleep(5)


if __name__ == "__main__":
    run_installer()
