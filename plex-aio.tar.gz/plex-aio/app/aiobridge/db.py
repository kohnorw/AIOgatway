"""SQLite state shared by the bridge (asyncio) and filesystem (trio) processes.

Each call opens its own short-lived connection, which keeps it safe across
processes and event loops. WAL mode lets the FUSE reader and the sync writer
work at the same time.
"""
import os
import sqlite3
import time
from contextlib import contextmanager

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS items (
    key        TEXT PRIMARY KEY,          -- movie:<tmdb> | show:<tmdb>
    kind       TEXT NOT NULL,             -- movie | show
    tmdb       INTEGER NOT NULL,
    imdb       TEXT,
    title      TEXT NOT NULL,
    year       INTEGER,
    runtime    INTEGER,                   -- minutes (movie runtime / typical episode)
    status     TEXT,                      -- TMDB status (Ended, Returning Series...)
    added_at   REAL NOT NULL,
    refreshed_at REAL
);
CREATE TABLE IF NOT EXISTS episodes (
    show_key  TEXT NOT NULL,
    season    INTEGER NOT NULL,
    episode   INTEGER NOT NULL,
    title     TEXT,
    runtime   INTEGER,
    air_date  TEXT,
    PRIMARY KEY (show_key, season, episode)
);
CREATE TABLE IF NOT EXISTS sources (
    item_key  TEXT NOT NULL,
    source    TEXT NOT NULL,              -- catalog:<id> | search | manual
    last_seen REAL NOT NULL,
    PRIMARY KEY (item_key, source)
);
CREATE TABLE IF NOT EXISTS streams (
    stream_key  TEXT PRIMARY KEY,         -- movie/tt123 | series/tt123:1:2
    url         TEXT,
    size        INTEGER,
    filename    TEXT,
    resolved_at REAL,
    activated   INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS show_seasons (
    show_key TEXT NOT NULL,
    season   INTEGER NOT NULL,
    PRIMARY KEY (show_key, season)
);
CREATE TABLE IF NOT EXISTS seasons_4k (
    show_key TEXT NOT NULL,
    season   INTEGER NOT NULL,
    PRIMARY KEY (show_key, season)
);
CREATE TABLE IF NOT EXISTS excluded_seasons (   -- seasons removed by hand
    show_key TEXT NOT NULL,
    season   INTEGER NOT NULL,
    PRIMARY KEY (show_key, season)
);
CREATE TABLE IF NOT EXISTS hidden_episodes (    -- one episode's HD or 4K file deleted by hand
    show_key TEXT NOT NULL,
    season   INTEGER NOT NULL,
    episode  INTEGER NOT NULL,
    uhd      INTEGER NOT NULL,
    PRIMARY KEY (show_key, season, episode, uhd)
);
CREATE INDEX IF NOT EXISTS idx_items_title ON items(kind, title);
"""


def _add_column(c, sql):
    """The bridge and FUSE processes both run init() at startup, so another
    process may add the column between our check and the ALTER — that's fine."""
    try:
        c.execute(sql)
    except sqlite3.OperationalError as e:
        if "duplicate column" not in str(e).lower():
            raise


def init() -> None:
    os.makedirs(config.CONFIG_DIR, exist_ok=True)
    with conn() as c:
        c.executescript(SCHEMA)
        cols = {r["name"] for r in c.execute("PRAGMA table_info(items)").fetchall()}
        if "has_4k" not in cols:
            _add_column(c, "ALTER TABLE items ADD COLUMN has_4k INTEGER NOT NULL DEFAULT 0")
        if "poster" not in cols:
            _add_column(c, "ALTER TABLE items ADD COLUMN poster TEXT")
        if "requested_by" not in cols:
            _add_column(c, "ALTER TABLE items ADD COLUMN requested_by TEXT")
        if "monitor" not in cols:      # shows: all | new | seasons
            _add_column(c, "ALTER TABLE items ADD COLUMN monitor TEXT NOT NULL DEFAULT 'all'")
        if "monitor_since" not in cols:
            _add_column(c, "ALTER TABLE items ADD COLUMN monitor_since TEXT")
        ecols = {r["name"] for r in c.execute("PRAGMA table_info(episodes)").fetchall()}
        if "announced" not in ecols:   # 1 once Plex has been asked to scan it
            _add_column(c, "ALTER TABLE episodes ADD COLUMN announced INTEGER NOT NULL DEFAULT 0")
            c.execute("UPDATE episodes SET announced=1")   # existing library was already scanned
        if "announced_at" not in ecols:  # when a newly aired episode appeared (NULL = part of the original request)
            _add_column(c, "ALTER TABLE episodes ADD COLUMN announced_at REAL")


@contextmanager
def conn():
    c = sqlite3.connect(config.DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA busy_timeout=30000")
    try:
        yield c
        c.commit()
    finally:
        c.close()


# --- items ------------------------------------------------------------------

def upsert_item(key, kind, tmdb, imdb, title, year, runtime, status):
    now = time.time()
    with conn() as c:
        c.execute(
            """INSERT INTO items(key,kind,tmdb,imdb,title,year,runtime,status,added_at,refreshed_at)
               VALUES(?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(key) DO UPDATE SET imdb=excluded.imdb, title=excluded.title,
                 year=excluded.year, runtime=excluded.runtime, status=excluded.status,
                 refreshed_at=excluded.refreshed_at""",
            (key, kind, tmdb, imdb, title, year, runtime, status, now, now),
        )


def get_item(key):
    with conn() as c:
        r = c.execute("SELECT * FROM items WHERE key=?", (key,)).fetchone()
        return dict(r) if r else None


def all_items(kind=None):
    with conn() as c:
        if kind:
            rows = c.execute("SELECT * FROM items WHERE kind=? ORDER BY title", (kind,)).fetchall()
        else:
            rows = c.execute("SELECT * FROM items ORDER BY title").fetchall()
        return [dict(r) for r in rows]


def delete_item(key):
    with conn() as c:
        c.execute("DELETE FROM items WHERE key=?", (key,))
        c.execute("DELETE FROM episodes WHERE show_key=?", (key,))
        c.execute("DELETE FROM sources WHERE item_key=?", (key,))
        c.execute("DELETE FROM seasons_4k WHERE show_key=?", (key,))
        c.execute("DELETE FROM show_seasons WHERE show_key=?", (key,))
        c.execute("DELETE FROM excluded_seasons WHERE show_key=?", (key,))
        c.execute("DELETE FROM hidden_episodes WHERE show_key=?", (key,))


def set_has_4k(key, value: bool):
    with conn() as c:
        c.execute("UPDATE items SET has_4k=? WHERE key=?", (1 if value else 0, key))


def set_requested_by(key, who):
    with conn() as c:
        c.execute("UPDATE items SET requested_by=COALESCE(requested_by, ?) WHERE key=?", (who, key))


def set_poster(key, poster):
    with conn() as c:
        c.execute("UPDATE items SET poster=? WHERE key=?", (poster, key))


def seasons_4k(show_key):
    with conn() as c:
        return {r["season"] for r in c.execute("SELECT season FROM seasons_4k WHERE show_key=?", (show_key,))}


def set_season_4k(show_key, season, value: bool):
    with conn() as c:
        if value:
            c.execute("INSERT OR IGNORE INTO seasons_4k(show_key,season) VALUES(?,?)", (show_key, season))
        else:
            c.execute("DELETE FROM seasons_4k WHERE show_key=? AND season=?", (show_key, season))


def find_by_imdb(imdb):
    with conn() as c:
        r = c.execute("SELECT * FROM items WHERE imdb=?", (imdb,)).fetchone()
        return dict(r) if r else None


def count_items():
    with conn() as c:
        rows = c.execute("SELECT kind, COUNT(*) n FROM items GROUP BY kind").fetchall()
        return {r["kind"]: r["n"] for r in rows}


# --- episodes -----------------------------------------------------------------

def replace_episodes(show_key, eps):
    """eps: iterable of (season, episode, title, runtime, air_date), including
    future episodes. Keeps each episode's `announced` flag. Returns True if changed."""
    eps = sorted(set(eps))
    with conn() as c:
        old = c.execute(
            "SELECT season,episode,title,runtime,air_date FROM episodes WHERE show_key=? ORDER BY season,episode",
            (show_key,),
        ).fetchall()
        if [tuple(r) for r in old] == eps:
            return False
        keep = {(e[0], e[1]) for e in eps}
        for r in old:
            if (r["season"], r["episode"]) not in keep:
                c.execute("DELETE FROM episodes WHERE show_key=? AND season=? AND episode=?",
                          (show_key, r["season"], r["episode"]))
        c.executemany(
            """INSERT INTO episodes(show_key,season,episode,title,runtime,air_date) VALUES(?,?,?,?,?,?)
               ON CONFLICT(show_key,season,episode) DO UPDATE SET title=excluded.title,
                 runtime=excluded.runtime, air_date=excluded.air_date""",
            [(show_key, *e) for e in eps],
        )
        return True


def mark_announced(show_key, pairs, new: bool = False):
    """new=True: these episodes aired after the request (tracked as new episodes)."""
    ts = time.time() if new else None
    with conn() as c:
        c.executemany("UPDATE episodes SET announced=1, announced_at=? WHERE show_key=? AND season=? AND episode=?",
                      [(ts, show_key, s, e) for s, e in pairs])


def new_episode_stats(since: float):
    """{show_key: (count of episodes announced as new since `since`, latest announced_at ever)}."""
    with conn() as c:
        rows = c.execute(
            """SELECT show_key, SUM(CASE WHEN announced_at>=? THEN 1 ELSE 0 END) n, MAX(announced_at) last
               FROM episodes WHERE announced_at IS NOT NULL GROUP BY show_key""", (since,)).fetchall()
        return {r["show_key"]: (r["n"] or 0, r["last"]) for r in rows}


def requested_seasons(show_key):
    with conn() as c:
        return {r["season"] for r in c.execute("SELECT season FROM show_seasons WHERE show_key=?", (show_key,))}


def add_requested_seasons(show_key, seasons):
    with conn() as c:
        c.executemany("INSERT OR IGNORE INTO show_seasons(show_key,season) VALUES(?,?)",
                      [(show_key, int(n)) for n in seasons])


def set_monitor(show_key, mode, since=None):
    with conn() as c:
        c.execute("UPDATE items SET monitor=?, monitor_since=COALESCE(monitor_since, ?) WHERE key=?",
                  (mode, since, show_key))


def episodes(show_key):
    with conn() as c:
        rows = c.execute(
            "SELECT * FROM episodes WHERE show_key=? ORDER BY season, episode", (show_key,)
        ).fetchall()
        return [dict(r) for r in rows]


# --- sources --------------------------------------------------------------------

def touch_source(item_key, source):
    with conn() as c:
        c.execute(
            """INSERT INTO sources(item_key,source,last_seen) VALUES(?,?,?)
               ON CONFLICT(item_key,source) DO UPDATE SET last_seen=excluded.last_seen""",
            (item_key, source, time.time()),
        )


def prune_source(source, older_than):
    """Drop a source's links not refreshed since `older_than`. Returns item keys left with no source."""
    with conn() as c:
        c.execute("DELETE FROM sources WHERE source=? AND last_seen<?", (source, older_than))
        rows = c.execute(
            "SELECT key FROM items WHERE key NOT IN (SELECT item_key FROM sources)"
        ).fetchall()
        return [r["key"] for r in rows]


# --- streams --------------------------------------------------------------------

def get_stream(stream_key):
    with conn() as c:
        r = c.execute("SELECT * FROM streams WHERE stream_key=?", (stream_key,)).fetchone()
        return dict(r) if r else None


def save_stream(stream_key, url, size, filename):
    with conn() as c:
        c.execute(
            """INSERT INTO streams(stream_key,url,size,filename,resolved_at,activated)
               VALUES(?,?,?,?,?,1)
               ON CONFLICT(stream_key) DO UPDATE SET url=excluded.url,
                 size=COALESCE(excluded.size, streams.size),
                 filename=COALESCE(excluded.filename, streams.filename),
                 resolved_at=excluded.resolved_at, activated=1""",
            (stream_key, url, size, filename, time.time()),
        )


def expire_stream_url(stream_key):
    with conn() as c:
        c.execute("UPDATE streams SET url=NULL WHERE stream_key=?", (stream_key,))


def delete_stream(stream_key):
    with conn() as c:
        c.execute("DELETE FROM streams WHERE stream_key=?", (stream_key,))


def set_stream(stream_key, url, size, filename):
    """Pin a hand-picked stream (replaces size/filename too)."""
    with conn() as c:
        c.execute(
            """INSERT INTO streams(stream_key,url,size,filename,resolved_at,activated) VALUES(?,?,?,?,?,1)
               ON CONFLICT(stream_key) DO UPDATE SET url=excluded.url, size=excluded.size,
                 filename=excluded.filename, resolved_at=excluded.resolved_at, activated=1""",
            (stream_key, url, size, filename, time.time()),
        )


# --- removed seasons / episodes ---------------------------------------------------

def excluded_seasons(show_key):
    with conn() as c:
        return {r["season"] for r in c.execute("SELECT season FROM excluded_seasons WHERE show_key=?", (show_key,))}


def exclude_season(show_key, season):
    with conn() as c:
        c.execute("INSERT OR IGNORE INTO excluded_seasons(show_key,season) VALUES(?,?)", (show_key, season))
        c.execute("DELETE FROM show_seasons WHERE show_key=? AND season=?", (show_key, season))
        c.execute("DELETE FROM seasons_4k WHERE show_key=? AND season=?", (show_key, season))
        c.execute("DELETE FROM hidden_episodes WHERE show_key=? AND season=?", (show_key, season))


def unexclude_seasons(show_key, seasons=None):
    """seasons=None: all of them."""
    with conn() as c:
        if seasons is None:
            c.execute("DELETE FROM excluded_seasons WHERE show_key=?", (show_key,))
        else:
            c.executemany("DELETE FROM excluded_seasons WHERE show_key=? AND season=?",
                          [(show_key, int(n)) for n in seasons])


def hidden_episodes(show_key):
    """{(season, episode, uhd_bool)}"""
    with conn() as c:
        return {(r["season"], r["episode"], bool(r["uhd"])) for r in
                c.execute("SELECT season,episode,uhd FROM hidden_episodes WHERE show_key=?", (show_key,))}


def set_episode_hidden(show_key, season, episode, uhd: bool, hidden: bool):
    with conn() as c:
        if hidden:
            c.execute("INSERT OR IGNORE INTO hidden_episodes(show_key,season,episode,uhd) VALUES(?,?,?,?)",
                      (show_key, season, episode, 1 if uhd else 0))
        else:
            c.execute("DELETE FROM hidden_episodes WHERE show_key=? AND season=? AND episode=? AND uhd=?",
                      (show_key, season, episode, 1 if uhd else 0))
