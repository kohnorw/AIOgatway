"""SQLite state shared by the bridge (asyncio) and filesystem (trio) processes.

Each call opens its own short-lived connection, which keeps it safe across
processes and event loops. WAL mode lets the FUSE reader and the sync writer
work at the same time.
"""
import os
import sqlite3
import time
from contextlib import contextmanager

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS items (
    key        TEXT PRIMARY KEY,          -- movie:<tmdb> | show:<tmdb>
    kind       TEXT NOT NULL,             -- movie | show
    tmdb       INTEGER NOT NULL,
    imdb       TEXT,
    title      TEXT NOT NULL,
    year       INTEGER,
    runtime    INTEGER,                   -- minutes (movie runtime / typical episode)
    status     TEXT,                      -- TMDB status (Ended, Returning Series...)
    added_at   REAL NOT NULL,
    refreshed_at REAL
);
CREATE TABLE IF NOT EXISTS episodes (
    show_key  TEXT NOT NULL,
    season    INTEGER NOT NULL,
    episode   INTEGER NOT NULL,
    title     TEXT,
    runtime   INTEGER,
    air_date  TEXT,
    PRIMARY KEY (show_key, season, episode)
);
CREATE TABLE IF NOT EXISTS sources (
    item_key  TEXT NOT NULL,
    source    TEXT NOT NULL,              -- catalog:<id> | search | manual
    last_seen REAL NOT NULL,
    PRIMARY KEY (item_key, source)
);
CREATE TABLE IF NOT EXISTS streams (
    stream_key  TEXT PRIMARY KEY,         -- movie/tt123 | series/tt123:1:2
    url         TEXT,
    size        INTEGER,
    filename    TEXT,
    resolved_at REAL,
    activated   INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_items_title ON items(kind, title);
"""


def init() -> None:
    os.makedirs(config.CONFIG_DIR, exist_ok=True)
    with conn() as c:
        c.executescript(SCHEMA)


@contextmanager
def conn():
    c = sqlite3.connect(config.DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA busy_timeout=30000")
    try:
        yield c
        c.commit()
    finally:
        c.close()


# --- items ------------------------------------------------------------------

def upsert_item(key, kind, tmdb, imdb, title, year, runtime, status):
    now = time.time()
    with conn() as c:
        c.execute(
            """INSERT INTO items(key,kind,tmdb,imdb,title,year,runtime,status,added_at,refreshed_at)
               VALUES(?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(key) DO UPDATE SET imdb=excluded.imdb, title=excluded.title,
                 year=excluded.year, runtime=excluded.runtime, status=excluded.status,
                 refreshed_at=excluded.refreshed_at""",
            (key, kind, tmdb, imdb, title, year, runtime, status, now, now),
        )


def get_item(key):
    with conn() as c:
        r = c.execute("SELECT * FROM items WHERE key=?", (key,)).fetchone()
        return dict(r) if r else None


def all_items(kind=None):
    with conn() as c:
        if kind:
            rows = c.execute("SELECT * FROM items WHERE kind=? ORDER BY title", (kind,)).fetchall()
        else:
            rows = c.execute("SELECT * FROM items ORDER BY title").fetchall()
        return [dict(r) for r in rows]


def delete_item(key):
    with conn() as c:
        c.execute("DELETE FROM items WHERE key=?", (key,))
        c.execute("DELETE FROM episodes WHERE show_key=?", (key,))
        c.execute("DELETE FROM sources WHERE item_key=?", (key,))


def count_items():
    with conn() as c:
        rows = c.execute("SELECT kind, COUNT(*) n FROM items GROUP BY kind").fetchall()
        return {r["kind"]: r["n"] for r in rows}


# --- episodes -----------------------------------------------------------------

def replace_episodes(show_key, eps):
    """eps: iterable of (season, episode, title, runtime, air_date). Returns True if changed."""
    eps = sorted(set(eps))
    with conn() as c:
        old = c.execute(
            "SELECT season,episode,title,runtime,air_date FROM episodes WHERE show_key=? ORDER BY season,episode",
            (show_key,),
        ).fetchall()
        if [tuple(r) for r in old] == eps:
            return False
        c.execute("DELETE FROM episodes WHERE show_key=?", (show_key,))
        c.executemany(
            "INSERT INTO episodes(show_key,season,episode,title,runtime,air_date) VALUES(?,?,?,?,?,?)",
            [(show_key, *e) for e in eps],
        )
        return True


def episodes(show_key):
    with conn() as c:
        rows = c.execute(
            "SELECT * FROM episodes WHERE show_key=? ORDER BY season, episode", (show_key,)
        ).fetchall()
        return [dict(r) for r in rows]


# --- sources --------------------------------------------------------------------

def touch_source(item_key, source):
    with conn() as c:
        c.execute(
            """INSERT INTO sources(item_key,source,last_seen) VALUES(?,?,?)
               ON CONFLICT(item_key,source) DO UPDATE SET last_seen=excluded.last_seen""",
            (item_key, source, time.time()),
        )


def prune_source(source, older_than):
    """Drop a source's links not refreshed since `older_than`. Returns item keys left with no source."""
    with conn() as c:
        c.execute("DELETE FROM sources WHERE source=? AND last_seen<?", (source, older_than))
        rows = c.execute(
            "SELECT key FROM items WHERE key NOT IN (SELECT item_key FROM sources)"
        ).fetchall()
        return [r["key"] for r in rows]


# --- streams --------------------------------------------------------------------

def get_stream(stream_key):
    with conn() as c:
        r = c.execute("SELECT * FROM streams WHERE stream_key=?", (stream_key,)).fetchone()
        return dict(r) if r else None


def save_stream(stream_key, url, size, filename):
    with conn() as c:
        c.execute(
            """INSERT INTO streams(stream_key,url,size,filename,resolved_at,activated)
               VALUES(?,?,?,?,?,1)
               ON CONFLICT(stream_key) DO UPDATE SET url=excluded.url,
                 size=COALESCE(excluded.size, streams.size),
                 filename=COALESCE(excluded.filename, streams.filename),
                 resolved_at=excluded.resolved_at, activated=1""",
            (stream_key, url, size, filename, time.time()),
        )


def expire_stream_url(stream_key):
    with conn() as c:
        c.execute("UPDATE streams SET url=NULL WHERE stream_key=?", (stream_key,))
