"""Login endpoints, access control, Users and Settings APIs (admin)."""
import logging

import aiohttp
from aiohttp import web

from . import auth, clients, config, library

log = logging.getLogger("aio.admin")

# Paths nobody needs to be signed in for.
PUBLIC_PREFIXES = ("/api/auth/", "/movie", "/tv", "/healthz")
PUBLIC_EXACT = {"/"}
# Paths any signed-in user may use; everything else under /api needs admin.
USER_PREFIXES = ("/api/cinemeta/",)
USER_EXACT = {("GET", "/api/status"), ("POST", "/api/request")}


def _ip(request):
    return request.headers.get("X-Forwarded-For", request.remote or "").split(",")[0].strip()


def _is_local(request):
    return (request.remote or "") in ("127.0.0.1", "::1")


@web.middleware
async def access(request, handler):
    path, method = request.path, request.method
    if path.startswith("/internal/"):
        if not _is_local(request):
            return web.json_response({"error": "forbidden"}, status=403)
        return await handler(request)
    user = auth.validate_session(request.cookies.get(auth.COOKIE), request.headers.get("User-Agent", ""))
    request["user"] = user
    if path in PUBLIC_EXACT or path.startswith(PUBLIC_PREFIXES):
        return await handler(request)
    if user is None:
        return web.json_response({"error": "sign in required"}, status=401)
    if path.startswith(USER_PREFIXES) or (method, path) in USER_EXACT:
        return await handler(request)
    if user.get("role") != "admin":
        return web.json_response({"error": "admin only"}, status=403)
    return await handler(request)


# ── auth ─────────────────────────────────────────────────────────────────────

async def login_start(request):
    try:
        return web.json_response(await auth.start_login(_ip(request)))
    except Exception as e:  # noqa: BLE001
        return web.json_response({"error": str(e)}, status=429 if "Too many" in str(e) else 502)


async def login_poll(request):
    try:
        res = await auth.poll_login(request.match_info["pin_id"], request.headers.get("User-Agent", ""), _ip(request))
    except Exception as e:  # noqa: BLE001
        return web.json_response({"error": str(e)}, status=403)
    if res is None:
        return web.json_response({"pending": True})
    resp = web.json_response({"user": res["user"]})
    resp.set_cookie(auth.COOKIE, res["session_token"], httponly=True, samesite="Strict",
                    secure=auth.cookie_secure(request), max_age=int(config.SESSION_MAX_AGE_DAYS * 86400), path="/")
    return resp


async def me(request):
    u = request["user"]
    if not u:
        return web.json_response({"user": None, "claimed": bool(clients.plex_token())})
    return web.json_response({"user": auth._public(u)})


async def logout(request):
    tok = request.cookies.get(auth.COOKIE)
    if tok:
        auth.destroy_session(tok)
    resp = web.json_response({"ok": True})
    resp.del_cookie(auth.COOKIE, path="/")
    return resp


# ── users ──────────────────────────────────────────────────────────────────────

async def users(_):
    return web.json_response({"users": auth.list_users()})


async def set_role(request):
    body = await request.json()
    try:
        ok = auth.set_role(request.match_info["uid"], body.get("role", ""))
    except ValueError as e:
        return web.json_response({"error": str(e)}, status=400)
    return web.json_response({"ok": ok}, status=200 if ok else 404)


async def delete_user(request):
    try:
        ok = auth.delete_user(request.match_info["uid"])
    except ValueError as e:
        return web.json_response({"error": str(e)}, status=400)
    return web.json_response({"ok": ok}, status=200 if ok else 404)


# ── settings ───────────────────────────────────────────────────────────────────

def _settings_payload():
    cur = config.current()
    out = []
    for key, kind, default, tab, label, help_, flags in config.SETTINGS:
        v = cur[key]
        secret = "secret" in flags
        out.append({"key": key, "type": kind, "tab": tab, "label": label, "help": help_,
                    "secret": secret, "restart": "restart" in flags, "default": default,
                    "value": ("" if secret else v), "is_set": bool(v) if secret else None,
                    "preview": _mask(v) if secret else None})
    return out


def _mask(v):
    v = str(v or "")
    if not v:
        return ""
    return (v[:12] + "…" + v[-4:]) if len(v) > 20 else "•" * 8


async def settings_get(_):
    return web.json_response({"settings": _settings_payload(), "status": await _status()})


async def settings_save(request):
    body = await request.json()
    changes = {}
    for k, v in (body.get("settings") or {}).items():
        spec = config.SPEC.get(k)
        if not spec:
            continue
        if "secret" in spec[6] and (v is None or v == ""):
            continue                    # blank secret = keep the saved one
        changes[k] = v
    try:
        applied = config.save(changes)
    except ValueError as e:
        return web.json_response({"error": str(e)}, status=400)
    restart = [k for k in applied if "restart" in config.SPEC[k][6]]
    log.info("settings saved: %s", ", ".join(applied) or "nothing")
    return web.json_response({"saved": list(applied), "restart_required": restart, "settings": _settings_payload()})


async def _status():
    st = {"plex_claimed": bool(clients.plex_token()), "tmdb": None, "aiostreams": None}
    return st


async def test_connections(_):
    out = {}
    try:
        await clients.tmdb.get("/configuration", ttl=60)
        out["tmdb"] = {"ok": True, "detail": "TMDB key works"}
    except Exception as e:  # noqa: BLE001
        out["tmdb"] = {"ok": False, "detail": str(e) or "TMDB request failed"}
    if not config.AIOSTREAMS_MANIFEST_URL:
        out["aiostreams"] = {"ok": False, "detail": "Manifest URL not set"}
    else:
        try:
            async with clients.session().get(config.AIOSTREAMS_MANIFEST_URL,
                                             timeout=aiohttp.ClientTimeout(total=15)) as r:
                r.raise_for_status()
                m = await r.json(content_type=None)
            out["aiostreams"] = {"ok": True, "detail": f"{m.get('name', 'AIOStreams')} {m.get('version', '')}".strip()}
        except Exception as e:  # noqa: BLE001
            out["aiostreams"] = {"ok": False, "detail": str(e) or "request failed"}
    try:
        async with clients.session().get(f"{config.CINEMETA_URL}/manifest.json",
                                         timeout=aiohttp.ClientTimeout(total=10)) as r:
            out["cinemeta"] = {"ok": r.status == 200, "detail": f"HTTP {r.status}"}
    except Exception as e:  # noqa: BLE001
        out["cinemeta"] = {"ok": False, "detail": str(e)}
    out["plex"] = {"ok": bool(clients.plex_token()),
                   "detail": "Claimed" if clients.plex_token() else "Not claimed — set PLEX_CLAIM and restart"}
    return web.json_response(out)


async def plex_setup(request):
    host = request.host.split(":")[0]
    return web.json_response({
        "providers": {"movie": f"http://127.0.0.1:{config.BRIDGE_PORT}/movie",
                      "tv": f"http://127.0.0.1:{config.BRIDGE_PORT}/tv"},
        "libraries": [f"{config.MOUNT_POINT}/{d}" for d in ("movies", "tv", "movies4k", "tv4k")],
        "client_url": f"http://{host}:32400",
        "counts": library.db.count_items(),
    })


def routes(app: web.Application):
    app.router.add_post("/api/auth/plex/start", login_start)
    app.router.add_get("/api/auth/plex/poll/{pin_id}", login_poll)
    app.router.add_get("/api/auth/me", me)
    app.router.add_post("/api/auth/logout", logout)
    app.router.add_get("/api/users", users)
    app.router.add_post("/api/users/{uid}/role", set_role)
    app.router.add_delete("/api/users/{uid}", delete_user)
    app.router.add_get("/api/settings", settings_get)
    app.router.add_post("/api/settings", settings_save)
    app.router.add_post("/api/settings/test", test_connections)
    app.router.add_get("/api/settings/plex", plex_setup)
