"""Runtime configuration.

Every user-facing setting is declared once in SETTINGS. Its starting value
comes from the environment (so an existing .env keeps working), and anything
an admin changes in the Settings page is saved to <CONFIG_DIR>/settings.json,
which overrides the environment. Both processes (bridge and filesystem) call
reload() so changes apply without a restart, except the few marked restart.
"""
import json
import os
import threading


def _env(name, default, kind):
    v = os.environ.get(name)
    if v is None or v.strip() == "":
        return default
    return _coerce(v, kind, default)


def _coerce(v, kind, default=None):
    try:
        if kind == "bool":
            return v if isinstance(v, bool) else str(v).strip().lower() in ("1", "true", "yes", "on")
        if kind == "int":
            return int(float(v))
        if kind == "float":
            return float(v)
        return str(v).strip()
    except (TypeError, ValueError):
        return default


# key, kind, default, tab, label, help, flags ("secret", "restart")
SETTINGS = [
    # ── Connections
    ("AIOSTREAMS_MANIFEST_URL", "str", "", "connections", "AIOStreams manifest URL",
     "From AIOStreams' /stremio/configure page (Save & Install). Used for streams and 4K checks.", ("secret",)),
    ("TMDB_API_KEY", "str", "", "connections", "TMDB API key",
     "v3 API key or v4 read-access token from themoviedb.org/settings/api.", ("secret",)),
    ("TMDB_LANGUAGE", "str", "en-US", "connections", "Metadata language", "TMDB language code, e.g. en-US.", ()),
    ("CINEMETA_URL", "str", "https://v3-cinemeta.strem.io", "connections", "Cinemeta URL",
     "Source for Home, Search and Plex search adds.", ()),
    # ── Users / login
    ("PLEX_SERVER_CHECK", "bool", True, "users", "Require access to this Plex server",
     "Only Plex accounts that own or are shared this server can sign in. Off = any Plex account (starts as user).", ()),
    ("SESSION_MAX_AGE_DAYS", "float", 30.0, "users", "Session length (days)",
     "Sliding: refreshed on every visit.", ()),
    # ── Library
    ("CHECK_4K", "bool", True, "library", "Check for 4K on request",
     "One AIOStreams lookup per movie / per season decides whether the 4K version is added.", ()),
    ("MIN_4K_CANDIDATES", "int", 2, "library", "4K results needed", "Minimum 2160p/4K results to add the 4K version.", ()),
    ("SYNC_INTERVAL_HOURS", "int", 6, "library", "Show refresh interval (hours)",
     "Ongoing shows get new episodes, and new seasons are checked for 4K.", ()),
    ("SERIES_REFRESH_STAGGER_SECONDS", "int", 15, "library", "Pause between season scans (seconds)",
     "Shows are scanned one season folder at a time; movies are scanned immediately on add.", ()),
    ("SEARCH_HOOK", "bool", True, "library", "Add titles when searching in Plex",
     "Searches in Plex apps (through port 32400) add matching Cinemeta titles.", ()),
    ("SEARCH_RESULTS_PER_TYPE", "int", 3, "library", "Titles added per Plex search", "Per type (movies, shows).", ()),
    ("PLAYBACK_REANALYZE_MINUTES", "int", 10, "library", "Re-analyze on playback (minutes)",
     "On playback Plex re-analyzes the file and refreshes metadata, at most once per file per this many minutes.", ()),
    ("PLEX_MOVIE_AGENT", "str", "tv.plex.agents.movie", "library", "Agent for new movie libraries", "", ()),
    ("PLEX_TV_AGENT", "str", "tv.plex.agents.series", "library", "Agent for new TV libraries", "", ()),
    # ── Streams / FUSE
    ("FUSE_REQUIRE_SESSION", "bool", False, "streams", "Require a Plex session to stream",
     "On: a file streams only while Plex lists it as playing (Plex's own analysis never pulls from debrid). "
     "Off: any non-scanner read streams.", ()),
    ("FUSE_PLAY_DETECT_SECONDS", "float", 4.0, "streams", "Session wait (seconds)", "How long a first read waits for Plex to list the session.", ()),
    ("FUSE_IDLE_GIVEUP_SECONDS", "float", 1.5, "streams", "Give up when nothing plays (seconds)", "", ()),
    ("EMPTY_TRASH_AFTER_SCAN", "bool", True, "library", "Empty Plex's trash after every scan",
     "Removed titles and episodes disappear from Plex straight away. Skipped whenever the virtual library "
     "isn't fully mounted, so a mount hiccup can never wipe your library or watch history.", ()),
    ("WAIT_FOR_STREAMS", "bool", True, "library", "Hold new episodes until a stream exists",
     "A newly aired episode is only added to Plex once AIOStreams returns a playable HD stream for it. "
     "Checks start 15 min after the episode airs and repeat every 2 hours for 24 hours. Once a stream is found "
     "the episode is added and not checked again; if none turns up in 24 hours checking stops (search for it "
     "from the series view).", ()),
    ("WAIT_LOOKBACK_DAYS", "int", 3, "library", "Also hold episodes that aired this many days before the request",
     "Older back-catalogue episodes are added straight away without a check (keeps big shows cheap).", ()),
    ("PREFER_PACKS", "bool", True, "streams", "Prefer series and season packs",
     "For episodes, pick a stream from a whole-series pack first, then a season pack, then a single-episode "
     "release (AIOStreams' own order is kept within each group). Once a pack plays, the next episodes try "
     "that same pack first. Packs are usually better seeded/cached and keep a season consistent.", ()),
    ("STREAM_URL_TTL_MIN", "int", 180, "streams", "Reuse a resolved link for (minutes)", "", ()),
    ("FUSE_PREFETCH_AHEAD", "int", 2, "streams", "Prefetch blocks", "", ()),
    ("FUSE_READ_TIMEOUT", "float", 15.0, "streams", "CDN read timeout (seconds)", "", ()),
    ("FUSE_READ_ATTEMPTS", "int", 3, "streams", "Attempts per block", "Before a link is treated as broken and repaired.", ()),
    ("FUSE_MAX_INFLIGHT", "int", 6, "streams", "Max concurrent CDN requests", "", ("restart",)),
    ("FUSE_BLOCK_MB", "int", 8, "streams", "Block size (MB)", "", ("restart",)),
    ("FUSE_CACHE_BLOCKS", "int", 32, "streams", "Block cache size (blocks)", "", ("restart",)),
    ("STREAM_USER_AGENT", "str", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
     "(KHTML, like Gecko) Chrome/124.0 Safari/537.36", "streams", "User-Agent for debrid CDNs", "", ("restart",)),
]
SPEC = {s[0]: s for s in SETTINGS}

for _k, _kind, _default, *_ in SETTINGS:
    globals()[_k] = _env(_k, _default, _kind)
CINEMETA_URL = CINEMETA_URL.rstrip("/")  # noqa: F821

# Not user-editable
SEARCH_DEBOUNCE_MS = int(os.environ.get("SEARCH_DEBOUNCE_MS", "1200"))
AUTO_CREATE_LIBRARIES = _env("AUTO_CREATE_LIBRARIES", True, "bool")

# --- paths / ports ------------------------------------------------------------
CONFIG_DIR = os.environ.get("AIO_CONFIG_DIR", "/config/aio")
DB_PATH = os.path.join(CONFIG_DIR, "aio.db")
PLACEHOLDER_DIR = os.path.join(CONFIG_DIR, "placeholders")
SETTINGS_PATH = os.path.join(CONFIG_DIR, "settings.json")
MOUNT_POINT = os.environ.get("AIO_MOUNT", "/media/aio")
PLEX_PREFS = os.environ.get(
    "PLEX_PREFS",
    "/config/Library/Application Support/Plex Media Server/Preferences.xml",
)
PLEX_URL = os.environ.get("PLEX_INTERNAL_URL", "http://127.0.0.1:32400")
BRIDGE_PORT = int(os.environ.get("BRIDGE_PORT", "8770"))    # request UI + providers
PROXY_PORT = int(os.environ.get("PROXY_PORT", "8771"))      # front door for Plex clients
BRIDGE_INTERNAL = f"http://127.0.0.1:{BRIDGE_PORT}"

MOVIE_PROVIDER_ID = "tv.plex.agents.custom.plexaio.tmdb.movie"
TV_PROVIDER_ID = "tv.plex.agents.custom.plexaio.tmdb.tv"

# --- saved overrides --------------------------------------------------------------
_lock = threading.Lock()
_mtime = None


def _read_saved() -> dict:
    try:
        with open(SETTINGS_PATH, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def reload(force: bool = False) -> bool:
    """Apply settings.json if it changed. Returns True if anything was applied."""
    global _mtime, CINEMETA_URL
    try:
        m = os.path.getmtime(SETTINGS_PATH)
    except OSError:
        m = None
    with _lock:
        if m == _mtime and not force:
            return False
        _mtime = m
        for k, v in _read_saved().items():
            if k in SPEC:
                globals()[k] = _coerce(v, SPEC[k][1], globals().get(k))
        CINEMETA_URL = str(CINEMETA_URL).rstrip("/")
    return True


def current() -> dict:
    return {k: globals()[k] for k in SPEC}


def save(changes: dict) -> dict:
    """Validate, persist and apply changes. Returns {key: new_value} applied."""
    applied = {}
    saved = _read_saved()
    for k, v in changes.items():
        if k not in SPEC:
            continue
        kind = SPEC[k][1]
        val = _coerce(v, kind, None)
        if val is None:
            raise ValueError(f"invalid value for {k}")
        if kind in ("int", "float") and val < 0:
            raise ValueError(f"{k} must not be negative")
        saved[k] = val
        applied[k] = val
    os.makedirs(CONFIG_DIR, exist_ok=True)
    tmp = SETTINGS_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(saved, f, indent=2)
    os.replace(tmp, SETTINGS_PATH)
    try:
        os.chmod(SETTINGS_PATH, 0o600)
    except OSError:
        pass
    reload(force=True)
    return applied


reload()
