"""Runtime configuration, all from environment variables."""
import os


def _bool(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    if v is None or v == "":
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


# --- external services -------------------------------------------------------
TMDB_API_KEY = os.environ.get("TMDB_API_KEY", "").strip()       # v3 key or v4 read token
TMDB_LANGUAGE = os.environ.get("TMDB_LANGUAGE", "en-US")
AIOSTREAMS_MANIFEST_URL = os.environ.get("AIOSTREAMS_MANIFEST_URL", "").strip()
AIOSTREAMS_CATALOGS = [c.strip() for c in os.environ.get("AIOSTREAMS_CATALOGS", "").split(",") if c.strip()]
CINEMETA_URL = os.environ.get("CINEMETA_URL", "https://v3-cinemeta.strem.io").rstrip("/")

# --- behaviour ----------------------------------------------------------------
SYNC_INTERVAL_HOURS = _int("SYNC_INTERVAL_HOURS", 6)
CATALOG_LIMIT = _int("CATALOG_LIMIT", 100)              # items per catalog per sync
SEARCH_HOOK = _bool("SEARCH_HOOK", True)                # add Cinemeta results on Plex search
SEARCH_RESULTS_PER_TYPE = _int("SEARCH_RESULTS_PER_TYPE", 3)
SEARCH_DEBOUNCE_MS = _int("SEARCH_DEBOUNCE_MS", 1200)
STREAM_URL_TTL_MIN = _int("STREAM_URL_TTL_MIN", 180)
PLAYBACK_REANALYZE_MINUTES = _int("PLAYBACK_REANALYZE_MINUTES", 10)   # per-file debounce
AUTO_CREATE_LIBRARIES = _bool("AUTO_CREATE_LIBRARIES", True)
PLEX_MOVIE_AGENT = os.environ.get("PLEX_MOVIE_AGENT", "tv.plex.agents.movie")
PLEX_TV_AGENT = os.environ.get("PLEX_TV_AGENT", "tv.plex.agents.series")

# --- paths / ports ------------------------------------------------------------
CONFIG_DIR = os.environ.get("AIO_CONFIG_DIR", "/config/aio")
DB_PATH = os.path.join(CONFIG_DIR, "aio.db")
PLACEHOLDER_DIR = os.path.join(CONFIG_DIR, "placeholders")
MOUNT_POINT = os.environ.get("AIO_MOUNT", "/media/aio")
PLEX_PREFS = os.environ.get(
    "PLEX_PREFS",
    "/config/Library/Application Support/Plex Media Server/Preferences.xml",
)
PLEX_URL = os.environ.get("PLEX_INTERNAL_URL", "http://127.0.0.1:32400")
BRIDGE_PORT = _int("BRIDGE_PORT", 8770)    # provider + web UI
PROXY_PORT = _int("PROXY_PORT", 8771)      # front door for Plex clients
BRIDGE_INTERNAL = f"http://127.0.0.1:{BRIDGE_PORT}"

MOVIE_PROVIDER_ID = "tv.plex.agents.custom.plexaio.tmdb.movie"
TV_PROVIDER_ID = "tv.plex.agents.custom.plexaio.tmdb.tv"
