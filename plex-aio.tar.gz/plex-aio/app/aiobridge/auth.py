"""Sign-in through Plex (OAuth PIN flow), users and sessions — ported from
aiogateway's gateway/auth.py.

* We never see a password: Plex handles the login on plex.tv and hands back a
  per-user token once the person approves it there.
* The account must own or have been shared this Plex server
  (PLEX_SERVER_CHECK). The check uses the server's own token from
  Preferences.xml, so there is nothing to configure.
* The first person to ever sign in becomes admin; everyone else starts as user.
* Sessions: 256-bit random tokens in an httpOnly, SameSite=Strict cookie, bound
  to the browser's User-Agent, sliding expiry, invalidated on role change.
* Plex tokens are stored server-side only and never returned by any API.
"""
import hashlib
import json
import logging
import os
import secrets
import threading
import time
import uuid
import xml.etree.ElementTree as ET

import aiohttp

from . import clients, config

log = logging.getLogger("aio.auth")

COOKIE = "plexaio_session"
_PRODUCT = "plex-aio"
_PIN_RATE_PER_HOUR = 20
_lock = threading.RLock()
_pin_attempts: dict[str, list] = {}
_pins: dict[str, dict] = {}


def _path(name):
    return os.path.join(config.CONFIG_DIR, name)


def _read(name, default):
    try:
        with open(_path(name), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def _write(name, data):
    os.makedirs(config.CONFIG_DIR, exist_ok=True)
    tmp = _path(name) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, _path(name))
    try:
        os.chmod(_path(name), 0o600)
    except OSError:
        pass


def client_id() -> str:
    with _lock:
        d = _read("plex_client_id.json", {})
        if not d.get("client_id"):
            d = {"client_id": str(uuid.uuid4())}
            _write("plex_client_id.json", d)
        return d["client_id"]


# ── users ───────────────────────────────────────────────────────────────────

def _users() -> dict:
    return {u["plex_user_id"]: u for u in _read("users.json", [])}


def _save_users(users: dict):
    _write("users.json", list(users.values()))


def _public(u):
    return {k: v for k, v in u.items() if k != "plex_token"}


def list_users():
    with _lock:
        return [_public(u) for u in _users().values()]


def get_user(uid):
    with _lock:
        return _users().get(uid)


def admin_count():
    with _lock:
        return sum(1 for u in _users().values() if u.get("role") == "admin")


def set_role(uid, role):
    if role not in ("admin", "user"):
        raise ValueError("role must be 'admin' or 'user'")
    with _lock:
        users = _users()
        if uid not in users:
            return False
        if role == "user" and users[uid].get("role") == "admin" and admin_count() <= 1:
            raise ValueError("Can't demote the last remaining admin")
        users[uid]["role"] = role
        _save_users(users)
        _invalidate_user_sessions(uid)
        return True


def delete_user(uid):
    with _lock:
        users = _users()
        if uid not in users:
            return False
        if users[uid].get("role") == "admin" and admin_count() <= 1:
            raise ValueError("Can't remove the last remaining admin")
        del users[uid]
        _save_users(users)
        _invalidate_user_sessions(uid)
        return True


def _upsert(plex_id, username, email, thumb, token):
    with _lock:
        users = _users()
        now = time.time()
        if plex_id in users:
            u = users[plex_id]
            u.update(username=username, email=email, thumb=thumb, plex_token=token, last_login=now)
        else:
            u = users[plex_id] = {
                "plex_user_id": plex_id, "username": username, "email": email, "thumb": thumb,
                "plex_token": token, "role": "admin" if not users else "user",
                "created_at": now, "last_login": now,
            }
        _save_users(users)
        return u


# ── sessions ──────────────────────────────────────────────────────────────────

def _ua_hash(ua):
    return hashlib.sha256((ua or "").encode()).hexdigest()[:32]


def create_session(uid, ua, ip):
    with _lock:
        sessions = _read("sessions.json", {})
        token = secrets.token_urlsafe(32)
        now = time.time()
        sessions[token] = {"plex_user_id": uid, "created_at": now, "ua_hash": _ua_hash(ua), "ip": ip,
                           "last_seen": now, "expires_at": now + config.SESSION_MAX_AGE_DAYS * 86400}
        _write("sessions.json", sessions)
        return token


def validate_session(token, ua):
    if not token:
        return None
    with _lock:
        sessions = _read("sessions.json", {})
        s = sessions.get(token)
        if not s:
            return None
        now = time.time()
        if now > s["expires_at"] or s["ua_hash"] != _ua_hash(ua):
            if s["ua_hash"] != _ua_hash(ua):
                log.warning("session %s… used with a different User-Agent — destroying it", token[:8])
            del sessions[token]
            _write("sessions.json", sessions)
            return None
        user = _users().get(s["plex_user_id"])
        if not user:
            del sessions[token]
            _write("sessions.json", sessions)
            return None
        if now - s.get("last_seen", 0) > 300:          # sliding expiry, written at most every 5 min
            s["last_seen"] = now
            s["expires_at"] = now + config.SESSION_MAX_AGE_DAYS * 86400
            _write("sessions.json", sessions)
        return user


def destroy_session(token):
    with _lock:
        sessions = _read("sessions.json", {})
        if sessions.pop(token, None):
            _write("sessions.json", sessions)


def _invalidate_user_sessions(uid):
    sessions = _read("sessions.json", {})
    dead = [t for t, s in sessions.items() if s.get("plex_user_id") == uid]
    for t in dead:
        del sessions[t]
    if dead:
        _write("sessions.json", sessions)


def cookie_secure(request) -> bool:
    return request.headers.get("X-Forwarded-Proto", "").lower() == "https" or request.secure


# ── Plex PIN login ────────────────────────────────────────────────────────────

def _rate_ok(ip):
    now = time.time()
    a = _pin_attempts.setdefault(ip, [])
    a[:] = [t for t in a if now - t < 3600]
    if len(a) >= _PIN_RATE_PER_HOUR:
        return False
    a.append(now)
    return True


def _plex_headers(token=None):
    h = {"X-Plex-Product": _PRODUCT, "X-Plex-Client-Identifier": client_id(), "Accept": "application/json"}
    if token:
        h["X-Plex-Token"] = token
    return h


async def start_login(ip):
    if not _rate_ok(ip):
        raise RuntimeError("Too many login attempts from this address — wait a bit and try again.")
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as s:
        async with s.post("https://plex.tv/api/v2/pins", params={"strong": "true"}, headers=_plex_headers()) as r:
            if r.status != 201:
                raise RuntimeError(f"Plex rejected the login request (HTTP {r.status})")
            data = await r.json()
    pin_id, code = str(data["id"]), data["code"]
    _pins[pin_id] = {"code": code, "created_at": time.time()}
    auth_url = (f"https://app.plex.tv/auth#?clientID={client_id()}&code={code}"
                f"&context%5Bdevice%5D%5Bproduct%5D={_PRODUCT}")
    return {"pin_id": pin_id, "auth_url": auth_url}


async def poll_login(pin_id, ua, ip):
    if pin_id not in _pins:
        raise RuntimeError("Unknown or expired login attempt — start over.")
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as s:
        async with s.get(f"https://plex.tv/api/v2/pins/{pin_id}", headers=_plex_headers()) as r:
            if r.status != 200:
                return None
            data = await r.json()
        token = data.get("authToken")
        if not token:
            return None
        _pins.pop(pin_id, None)
        async with s.get("https://plex.tv/api/v2/user", headers=_plex_headers(token)) as r:
            if r.status != 200:
                raise RuntimeError("Could not verify the Plex account after login.")
            acct = await r.json()
    plex_id = str(acct.get("id"))
    username = acct.get("username") or acct.get("title") or acct.get("email") or plex_id
    if config.PLEX_SERVER_CHECK and not await has_server_access(plex_id):
        raise RuntimeError("This Plex account doesn't have access to this Plex server — ask the "
                           "server owner to share it with you.")
    user = _upsert(plex_id, username, acct.get("email", ""), acct.get("thumb", ""), token)
    session = create_session(plex_id, ua, ip)
    log.info("Plex login: %s (%s) — role=%s", username, plex_id, user["role"])
    return {"session_token": session, "user": _public(user)}


async def has_server_access(plex_id) -> bool:
    """Owner of this server, or a user it has been shared with."""
    owner_token = clients.plex_token()
    if not owner_token:
        log.warning("server not claimed yet — allowing login so the owner can finish setup")
        return True
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as s:
            async with s.get("https://plex.tv/api/v2/user", headers=_plex_headers(owner_token)) as r:
                if r.status == 200 and str((await r.json()).get("id")) == plex_id:
                    return True
            # users the owner has shared with (plex.tv friends list)
            async with s.get("https://plex.tv/api/users", headers={**_plex_headers(owner_token), "Accept": "application/xml"}) as r:
                if r.status == 200:
                    root = ET.fromstring(await r.text())
                    if any(u.get("id") == plex_id for u in root.iter("User")):
                        return True
            # accounts known to this server (managed / home users)
            async with s.get(f"{config.PLEX_URL}/accounts", headers=_plex_headers(owner_token)) as r:
                if r.status == 200:
                    data = await r.json(content_type=None)
                    for a in (data.get("MediaContainer") or {}).get("Account") or []:
                        if str(a.get("id")) == plex_id:
                            return True
    except Exception as e:  # noqa: BLE001
        log.warning("could not verify server access for %s: %s", plex_id, e)
    return False
