"""plex-aio: Plex + TMDB metadata + AIOStreams streams, with no media scanning."""
