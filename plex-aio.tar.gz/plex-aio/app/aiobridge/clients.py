"""HTTP clients used by the bridge process (asyncio / aiohttp)."""
import asyncio
import logging
import time
import urllib.parse
import xml.etree.ElementTree as ET

import aiohttp

from . import config

log = logging.getLogger("aio.clients")
_session: aiohttp.ClientSession | None = None


def session() -> aiohttp.ClientSession:
    global _session
    if _session is None or _session.closed:
        _session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30))
    return _session


# --- TMDB ---------------------------------------------------------------------

class TMDB:
    BASE = "https://api.themoviedb.org/3"
    IMG = "https://image.tmdb.org/t/p/original"

    def __init__(self):
        self._cache: dict[str, tuple[float, dict]] = {}
        self._sem = asyncio.Semaphore(8)

    def _auth(self):
        key = config.TMDB_API_KEY
        if key.startswith("eyJ"):            # v4 read-access token (JWT)
            return {"Authorization": f"Bearer {key}"}, {}
        return {}, {"api_key": key}

    async def get(self, path: str, ttl: int = 6 * 3600, **params) -> dict:
        if not config.TMDB_API_KEY:
            raise RuntimeError("TMDB_API_KEY is not set")
        headers, auth = self._auth()
        params = {k: v for k, v in {**auth, **params}.items() if v is not None}
        ck = path + "?" + urllib.parse.urlencode(sorted((k, str(v)) for k, v in params.items() if k != "api_key"))
        hit = self._cache.get(ck)
        if hit and hit[0] > time.time():
            return hit[1]
        async with self._sem:
            for attempt in range(4):
                async with session().get(self.BASE + path, params=params, headers=headers) as r:
                    if r.status == 429:
                        await asyncio.sleep(float(r.headers.get("Retry-After", 1 + attempt)))
                        continue
                    if r.status == 404:
                        raise KeyError(path)
                    r.raise_for_status()
                    data = await r.json()
                    break
            else:
                raise RuntimeError(f"TMDB rate limited: {path}")
        if len(self._cache) > 5000:
            self._cache.clear()
        self._cache[ck] = (time.time() + ttl, data)
        return data

    @classmethod
    def img(cls, path):
        return cls.IMG + path if path else None

    async def find_imdb(self, imdb: str) -> dict:
        return await self.get(f"/find/{imdb}", external_source="imdb_id")

    async def movie(self, tmdb: int, language=None) -> dict:
        return await self.get(
            f"/movie/{tmdb}", language=language or config.TMDB_LANGUAGE,
            append_to_response="credits,images,external_ids,release_dates,keywords",
            include_image_language="en,null",
        )

    async def show(self, tmdb: int, language=None) -> dict:
        return await self.get(
            f"/tv/{tmdb}", language=language or config.TMDB_LANGUAGE,
            append_to_response="credits,images,external_ids,content_ratings",
            include_image_language="en,null",
        )

    async def season(self, tmdb: int, n: int, language=None) -> dict:
        return await self.get(f"/tv/{tmdb}/season/{n}", language=language or config.TMDB_LANGUAGE,
                              append_to_response="images,external_ids", include_image_language="en,null")

    async def search(self, kind: str, query: str, year=None, language=None) -> list:
        path = "/search/movie" if kind == "movie" else "/search/tv"
        yk = "year" if kind == "movie" else "first_air_date_year"
        data = await self.get(path, ttl=3600, query=query, language=language or config.TMDB_LANGUAGE,
                              **({yk: year} if year else {}))
        return data.get("results", [])


tmdb = TMDB()


# --- Stremio addons (Cinemeta / AIOStreams) -----------------------------------

def addon_base(manifest_url: str) -> str:
    u = manifest_url.strip()
    if u.startswith("stremio://"):
        u = "https://" + u[len("stremio://"):]
    return u[: -len("/manifest.json")] if u.endswith("/manifest.json") else u.rstrip("/")


async def _json(url: str):
    async with session().get(url) as r:
        r.raise_for_status()
        return await r.json(content_type=None)


async def cinemeta_search(query: str, kind: str) -> list:
    """kind: movie | series. Returns Stremio metas (id = tt...)."""
    q = urllib.parse.quote(query.strip(), safe="")
    try:
        data = await _json(f"{config.CINEMETA_URL}/catalog/{kind}/top/search={q}.json")
    except Exception as e:  # noqa: BLE001
        log.warning("cinemeta search failed: %s", e)
        return []
    return data.get("metas", []) or []


async def aio_manifest() -> dict:
    return await _json(config.AIOSTREAMS_MANIFEST_URL)


async def aio_catalog(ctype: str, cid: str, skip: int = 0) -> list:
    base = addon_base(config.AIOSTREAMS_MANIFEST_URL)
    extra = f"/skip={skip}" if skip else ""
    data = await _json(f"{base}/catalog/{ctype}/{urllib.parse.quote(cid, safe='')}{extra}.json")
    return data.get("metas", []) or []


# --- Plex -------------------------------------------------------------------------

def plex_token() -> str | None:
    try:
        root = ET.parse(config.PLEX_PREFS).getroot()
        return root.get("PlexOnlineToken")
    except (OSError, ET.ParseError):
        return None


class Plex:
    async def req(self, method: str, endpoint: str, **params):
        tok = plex_token()
        if not tok:
            raise RuntimeError("Plex not claimed yet (no PlexOnlineToken)")
        params["X-Plex-Token"] = tok
        async with session().request(method, config.PLEX_URL + endpoint, params=params,
                                     headers={"Accept": "application/json"}) as r:
            r.raise_for_status()
            if "json" in r.headers.get("Content-Type", ""):
                return await r.json()
            return await r.text()

    async def sections(self) -> list:
        data = await self.req("GET", "/library/sections")
        return data.get("MediaContainer", {}).get("Directory", []) or []

    async def section_for(self, path: str):
        for s in await self.sections():
            for loc in s.get("Location", []) or []:
                lp = loc.get("path", "").rstrip("/")
                if path == lp or path.startswith(lp + "/"):
                    return s
        return None

    async def refresh_path(self, path: str) -> bool:
        s = await self.section_for(path)
        if not s:
            log.info("no Plex library covers %s yet", path)
            return False
        await self.req("GET", f"/library/sections/{s['key']}/refresh", path=path)
        return True

    async def refresh_section_of(self, path: str):
        s = await self.section_for(path)
        if s:
            await self.req("GET", f"/library/sections/{s['key']}/refresh")

    async def empty_trash_of(self, path: str):
        s = await self.section_for(path)
        if s:
            await self.req("PUT", f"/library/sections/{s['key']}/emptyTrash")

    async def search_titles(self, query: str) -> set:
        data = await self.req("GET", "/hubs/search", query=query, limit=30)
        titles = set()
        for hub in data.get("MediaContainer", {}).get("Hub", []) or []:
            for m in hub.get("Metadata", []) or []:
                titles.add(m.get("title", ""))
        return titles

    async def create_section(self, name, kind, agent, scanner, location):
        await self.req("POST", "/library/sections", name=name, type=kind, agent=agent,
                       scanner=scanner, language="en-US", location=location)


plex = Plex()
