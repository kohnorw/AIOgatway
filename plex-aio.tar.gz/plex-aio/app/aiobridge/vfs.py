"""Pure logic behind the FUSE filesystem (no pyfuse3 import, so it is testable).

* Tree: built from the database, cached for a couple of seconds.
* Caller policy: who sees the placeholder and who sees the real stream.
* Stream choice: which AIOStreams result to play.
"""
import re
import time

from . import config, db, naming, placeholder

# /proc/<pid>/comm is truncated to 15 characters.
SCANNER_COMMS = ("Plex Media Scan", "Plex Media Fing", "Plex Commercial", "Plex Media Tagg")
PLAYER_COMMS = ("Plex Media Serv", "Plex Transcoder")


def comm(pid: int) -> str:
    try:
        with open(f"/proc/{pid}/comm") as f:
            return f.read().strip()
    except OSError:
        return ""


def _status_field(pid: int, field: str) -> int:
    try:
        with open(f"/proc/{pid}/status") as f:
            for line in f:
                if line.startswith(field + ":"):
                    return int(line.split()[1])
    except (OSError, ValueError):
        pass
    return 0


def ppid(pid: int) -> int:
    return _status_field(pid, "PPid")


def tgid(pid: int) -> int:
    """FUSE reports the *thread* id. Plex names its worker threads, so use the
    owning process (thread group leader) to read the real program name."""
    return _status_field(pid, "Tgid") or pid


def caller_class(pid: int, comm_fn=comm, ppid_fn=ppid, tgid_fn=tgid) -> str:
    """'scanner' | 'player' | 'other'.

    A Plex Transcoder started *by the scanner* (e.g. for analysis) counts as a
    scanner, so only real playback ever reaches the debrid service.
    """
    chain, p = [], tgid_fn(pid)
    for _ in range(4):
        if p <= 1:
            break
        chain.append(comm_fn(p))
        p = ppid_fn(p)
    if any(c.startswith(SCANNER_COMMS) for c in chain):
        return "scanner"
    if chain and chain[0].startswith(PLAYER_COMMS):
        return "player"
    return "other"


class Node:
    __slots__ = ("name", "is_dir", "children", "item", "season", "episode", "rel", "uhd")

    def __init__(self, name, is_dir, rel, item=None, season=None, episode=None, uhd=False):
        self.name, self.is_dir, self.rel = name, is_dir, rel
        self.children: dict[str, "Node"] = {} if is_dir else None
        self.item, self.season, self.episode, self.uhd = item, season, episode, uhd

    # --- file properties -------------------------------------------------------
    @property
    def runtime(self):
        if self.episode is not None:
            return self.episode.get("runtime") or self.item.get("runtime") or 45
        return self.item.get("runtime") or 110

    @property
    def stream_key(self):
        if self.episode is not None:
            return naming.stream_key_episode(self.item, self.season, self.episode["episode"], self.uhd)
        return naming.stream_key_movie(self.item, self.uhd)

    @property
    def item_rel(self):
        return naming.item_rel_path(self.item, self.uhd)

    def placeholder_path(self):
        return placeholder.path_for(self.runtime)


def _add_movie(top: Node, it, uhd):
    fname = naming.folder(it)
    d = top.children[fname] = Node(fname, True, f"{top.rel}/{fname}", it, uhd=uhd)
    f = naming.movie_file(it)
    d.children[f] = Node(f, False, f"{d.rel}/{f}", it, uhd=uhd)


def _add_show(top: Node, it, eps, uhd, seasons=None):
    fname = naming.folder(it)
    d = None
    for ep in eps:
        if seasons is not None and ep["season"] not in seasons:
            continue
        if d is None:
            d = top.children[fname] = Node(fname, True, f"{top.rel}/{fname}", it, uhd=uhd)
        sd = naming.season_dir(ep["season"])
        sn = d.children.get(sd) or d.children.setdefault(
            sd, Node(sd, True, f"{d.rel}/{sd}", it, ep["season"], uhd=uhd))
        f = naming.episode_file(it, ep["season"], ep["episode"])
        sn.children[f] = Node(f, False, f"{sn.rel}/{f}", it, ep["season"], ep, uhd=uhd)


def build_tree(today=None) -> Node:
    """movies/ tv/ for every title; movies4k/ tv4k/ only where 4K exists
    (per movie, and per season for shows)."""
    root = Node("", True, "")
    tops = {n: root.children.setdefault(n, Node(n, True, n)) for n in ("movies", "movies4k", "tv", "tv4k")}
    for it in db.all_items():
        if it["kind"] == "movie":
            _add_movie(tops["movies"], it, False)
            if it.get("has_4k"):
                _add_movie(tops["movies4k"], it, True)
        else:
            eps = [e for e in db.episodes(it["key"]) if naming.aired(e.get("air_date"), today)]
            if not eps:
                continue
            _add_show(tops["tv"], it, eps, False)
            s4k = db.seasons_4k(it["key"])
            if s4k:
                _add_show(tops["tv4k"], it, eps, True, s4k)
    return root


class Tree:
    TTL = 3.0

    def __init__(self):
        self._root, self._at = None, 0.0

    def root(self) -> Node:
        if self._root is None or time.monotonic() - self._at > self.TTL:
            self._root, self._at = build_tree(), time.monotonic()
        return self._root

    def resolve(self, rel: str):
        node = self.root()
        for part in [p for p in rel.split("/") if p]:
            if not node.is_dir or part not in node.children:
                return None
            node = node.children[part]
        return node


# --- stream choice ---------------------------------------------------------------

_UHD_RE = re.compile(r"(2160p|\b4k\b|\buhd\b)", re.I)


def is_4k(stream: dict) -> bool:
    """AIOStreams puts the resolution in the name/description/filename."""
    hints = stream.get("behaviorHints") or {}
    text = " ".join(str(x) for x in (stream.get("name"), stream.get("title"), stream.get("description"),
                                     hints.get("filename")) if x)
    return bool(_UHD_RE.search(text))


def pick_stream(streams: list, prefer_filename: str | None = None, uhd: bool | None = None):
    """AIOStreams already sorts by the user's rules; take the first playable
    HTTP stream of the wanted quality (uhd=True: 4K only, False: non-4K only,
    None: any), keeping the previously used file when it is still offered so
    Plex's stored media info stays valid."""
    playable = [s for s in streams if (s.get("url") or "").startswith("http")
                and (uhd is None or is_4k(s) == uhd)]
    if not playable:
        return None
    if prefer_filename:
        for s in playable:
            if ((s.get("behaviorHints") or {}).get("filename")) == prefer_filename:
                return s
    return playable[0]


def stream_url_fresh(s) -> bool:
    return bool(s and s.get("url") and s.get("resolved_at")
                and time.time() - s["resolved_at"] < config.STREAM_URL_TTL_MIN * 60)
