"""Pure logic behind the FUSE filesystem (no pyfuse3 import, so it is testable).

* Tree: built from the database, cached for a couple of seconds.
* Caller policy: who sees the placeholder and who sees the real stream.
* Stream choice: which AIOStreams result to play.
"""
import os
import time

from . import config, db, naming, placeholder

# /proc/<pid>/comm is truncated to 15 characters.
SCANNER_COMMS = ("Plex Media Scan", "Plex Media Fing", "Plex Commercial", "Plex Media Tagg")
PLAYER_COMMS = ("Plex Media Serv", "Plex Transcoder")


def comm(pid: int) -> str:
    try:
        with open(f"/proc/{pid}/comm") as f:
            return f.read().strip()
    except OSError:
        return ""


def ppid(pid: int) -> int:
    try:
        with open(f"/proc/{pid}/status") as f:
            for line in f:
                if line.startswith("PPid:"):
                    return int(line.split()[1])
    except (OSError, ValueError):
        pass
    return 0


def caller_class(pid: int, comm_fn=comm, ppid_fn=ppid) -> str:
    """'scanner' | 'player' | 'other'.

    A Plex Transcoder started *by the scanner* (e.g. for analysis) counts as a
    scanner, so only real playback ever reaches the debrid service.
    """
    chain, p = [], pid
    for _ in range(4):
        if p <= 1:
            break
        chain.append(comm_fn(p))
        p = ppid_fn(p)
    if any(c.startswith(SCANNER_COMMS) for c in chain):
        return "scanner"
    if chain and chain[0].startswith(PLAYER_COMMS):
        return "player"
    return "other"


class Node:
    __slots__ = ("name", "is_dir", "children", "item", "season", "episode", "rel")

    def __init__(self, name, is_dir, rel, item=None, season=None, episode=None):
        self.name, self.is_dir, self.rel = name, is_dir, rel
        self.children: dict[str, "Node"] = {} if is_dir else None
        self.item, self.season, self.episode = item, season, episode

    # --- file properties -------------------------------------------------------
    @property
    def runtime(self):
        if self.episode is not None:
            return self.episode.get("runtime") or self.item.get("runtime") or 45
        return self.item.get("runtime") or 110

    @property
    def stream_key(self):
        if self.episode is not None:
            return naming.stream_key_episode(self.item, self.season, self.episode["episode"])
        return naming.stream_key_movie(self.item)

    @property
    def item_rel(self):
        return naming.item_rel_path(self.item)

    def placeholder_path(self):
        return placeholder.path_for(self.runtime)


def build_tree(today=None) -> Node:
    root = Node("", True, "")
    movies = root.children["movies"] = Node("movies", True, "movies")
    tv = root.children["tv"] = Node("tv", True, "tv")
    for it in db.all_items():
        fname = naming.folder(it)
        if it["kind"] == "movie":
            d = movies.children[fname] = Node(fname, True, f"movies/{fname}", it)
            f = naming.movie_file(it)
            d.children[f] = Node(f, False, f"{d.rel}/{f}", it)
        else:
            d = tv.children[fname] = Node(fname, True, f"tv/{fname}", it)
            for ep in db.episodes(it["key"]):
                if not naming.aired(ep.get("air_date"), today):
                    continue
                sd = naming.season_dir(ep["season"])
                sn = d.children.get(sd) or d.children.setdefault(sd, Node(sd, True, f"{d.rel}/{sd}", it, ep["season"]))
                f = naming.episode_file(it, ep["season"], ep["episode"])
                sn.children[f] = Node(f, False, f"{sn.rel}/{f}", it, ep["season"], ep)
    return root


class Tree:
    TTL = 3.0

    def __init__(self):
        self._root, self._at = None, 0.0

    def root(self) -> Node:
        if self._root is None or time.monotonic() - self._at > self.TTL:
            self._root, self._at = build_tree(), time.monotonic()
        return self._root

    def resolve(self, rel: str):
        node = self.root()
        for part in [p for p in rel.split("/") if p]:
            if not node.is_dir or part not in node.children:
                return None
            node = node.children[part]
        return node


def placeholder_size(node: Node) -> int:
    try:
        return os.path.getsize(node.placeholder_path())
    except OSError:
        return 0


def visible_size(node: Node, cls: str) -> int:
    """Scanners and unknown callers see the placeholder; once a title has been
    played ('activated'), everyone sees the real size so Plex re-analyses it."""
    s = db.get_stream(node.stream_key)
    if s and s.get("activated") and s.get("size"):
        return int(s["size"])
    if cls == "player":
        return int(s["size"]) if s and s.get("size") else placeholder_size(node)
    return placeholder_size(node)


def serves_real(node: Node, cls: str) -> bool:
    if cls == "player":
        return True
    s = db.get_stream(node.stream_key)
    return bool(cls == "scanner" and s and s.get("activated") and s.get("size"))


# --- stream choice ---------------------------------------------------------------

def pick_stream(streams: list, prefer_filename: str | None = None):
    """AIOStreams already sorts by the user's rules; take the first playable
    HTTP stream, but keep the previously used file when it is still offered so
    Plex's stored media info stays valid."""
    playable = [s for s in streams if (s.get("url") or "").startswith("http")]
    if not playable:
        return None
    if prefer_filename:
        for s in playable:
            if ((s.get("behaviorHints") or {}).get("filename")) == prefer_filename:
                return s
    return playable[0]


def stream_url_fresh(s) -> bool:
    return bool(s and s.get("url") and s.get("resolved_at")
                and time.time() - s["resolved_at"] < config.STREAM_URL_TTL_MIN * 60)
