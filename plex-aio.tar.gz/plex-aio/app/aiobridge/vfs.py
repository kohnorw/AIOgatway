"""Pure logic behind the FUSE filesystem (no pyfuse3 import, so it is testable).

* Tree: built from the database, cached for a couple of seconds.
* Caller policy: who sees the placeholder and who sees the real stream.
* Stream choice: which AIOStreams result to play.
"""
import re
import time

from . import config, db, naming, placeholder

# /proc/<pid>/comm is truncated to 15 characters.
SCANNER_COMMS = ("Plex Media Scan", "Plex Media Fing", "Plex Commercial", "Plex Media Tagg")
PLAYER_COMMS = ("Plex Media Serv", "Plex Transcoder")


def comm(pid: int) -> str:
    try:
        with open(f"/proc/{pid}/comm") as f:
            return f.read().strip()
    except OSError:
        return ""


def _status_field(pid: int, field: str) -> int:
    try:
        with open(f"/proc/{pid}/status") as f:
            for line in f:
                if line.startswith(field + ":"):
                    return int(line.split()[1])
    except (OSError, ValueError):
        pass
    return 0


def ppid(pid: int) -> int:
    return _status_field(pid, "PPid")


def tgid(pid: int) -> int:
    """FUSE reports the *thread* id. Plex names its worker threads, so use the
    owning process (thread group leader) to read the real program name."""
    return _status_field(pid, "Tgid") or pid


def caller_class(pid: int, comm_fn=comm, ppid_fn=ppid, tgid_fn=tgid) -> str:
    """'scanner' | 'player' | 'other'.

    A Plex Transcoder started *by the scanner* (e.g. for analysis) counts as a
    scanner, so only real playback ever reaches the debrid service.
    """
    chain, p = [], tgid_fn(pid)
    for _ in range(4):
        if p <= 1:
            break
        chain.append(comm_fn(p))
        p = ppid_fn(p)
    if any(c.startswith(SCANNER_COMMS) for c in chain):
        return "scanner"
    if chain and chain[0].startswith(PLAYER_COMMS):
        return "player"
    return "other"


class Node:
    __slots__ = ("name", "is_dir", "children", "item", "season", "episode", "rel", "uhd")

    def __init__(self, name, is_dir, rel, item=None, season=None, episode=None, uhd=False):
        self.name, self.is_dir, self.rel = name, is_dir, rel
        self.children: dict[str, "Node"] = {} if is_dir else None
        self.item, self.season, self.episode, self.uhd = item, season, episode, uhd

    # --- file properties -------------------------------------------------------
    @property
    def runtime(self):
        if self.episode is not None:
            return self.episode.get("runtime") or self.item.get("runtime") or 45
        return self.item.get("runtime") or 110

    @property
    def stream_key(self):
        if self.episode is not None:
            return naming.stream_key_episode(self.item, self.season, self.episode["episode"], self.uhd)
        return naming.stream_key_movie(self.item, self.uhd)

    @property
    def item_rel(self):
        return naming.item_rel_path(self.item, self.uhd)

    def placeholder_path(self):
        return placeholder.path_for(self.runtime)


def _add_movie(top: Node, it, uhd):
    fname = naming.folder(it)
    d = top.children[fname] = Node(fname, True, f"{top.rel}/{fname}", it, uhd=uhd)
    f = naming.movie_file(it)
    d.children[f] = Node(f, False, f"{d.rel}/{f}", it, uhd=uhd)


def _add_show(top: Node, it, eps, uhd, seasons=None, hidden=frozenset()):
    fname = naming.folder(it)
    d = None
    for ep in eps:
        if seasons is not None and ep["season"] not in seasons:
            continue
        if (ep["season"], ep["episode"], uhd) in hidden:
            continue
        if d is None:
            d = top.children[fname] = Node(fname, True, f"{top.rel}/{fname}", it, uhd=uhd)
        sd = naming.season_dir(ep["season"])
        sn = d.children.get(sd) or d.children.setdefault(
            sd, Node(sd, True, f"{d.rel}/{sd}", it, ep["season"], uhd=uhd))
        f = naming.episode_file(it, ep["season"], ep["episode"])
        sn.children[f] = Node(f, False, f"{sn.rel}/{f}", it, ep["season"], ep, uhd=uhd)


def build_tree(today=None) -> Node:
    """movies/ tv/ for every title; movies4k/ tv4k/ only where 4K exists
    (per movie, and per season for shows)."""
    root = Node("", True, "")
    tops = {n: root.children.setdefault(n, Node(n, True, n)) for n in ("movies", "movies4k", "tv", "tv4k")}
    for it in db.all_items():
        if it["kind"] == "movie":
            _add_movie(tops["movies"], it, False)
            if it.get("has_4k"):
                _add_movie(tops["movies4k"], it, True)
        else:
            req = db.requested_seasons(it["key"])
            exc = db.excluded_seasons(it["key"])
            eps = [e for e in db.episodes(it["key"]) if naming.released(it, e, today)
                   and naming.wanted_episode(it, e["season"], e.get("air_date"), req, exc)]
            if not eps:
                continue
            hidden = db.hidden_episodes(it["key"])
            _add_show(tops["tv"], it, eps, False, None, hidden)
            s4k = db.seasons_4k(it["key"])
            if s4k:
                _add_show(tops["tv4k"], it, eps, True, s4k, hidden)
    return root


class Tree:
    TTL = 3.0

    def __init__(self):
        self._root, self._at = None, 0.0

    def root(self) -> Node:
        if self._root is None or time.monotonic() - self._at > self.TTL:
            self._root, self._at = build_tree(), time.monotonic()
        return self._root

    def resolve(self, rel: str):
        node = self.root()
        for part in [p for p in rel.split("/") if p]:
            if not node.is_dir or part not in node.children:
                return None
            node = node.children[part]
        return node


# --- stream choice ---------------------------------------------------------------

_UHD_RE = re.compile(r"(2160p|\b4k\b|\buhd\b)", re.I)


def is_4k(stream: dict) -> bool:
    """AIOStreams puts the resolution in the name/description/filename."""
    hints = stream.get("behaviorHints") or {}
    text = " ".join(str(x) for x in (stream.get("name"), stream.get("title"), stream.get("description"),
                                     hints.get("filename")) if x)
    return bool(_UHD_RE.search(text))


# --- packs (same detection as aiogateway) ------------------------------------------

_T = r"(?<![a-z0-9])"
_EPISODE_RE = re.compile(_T + r"s(\d{1,2})[\s._-]?e(\d{1,3})", re.I)
_SEASON_PACK_RE = re.compile(
    "(?:" + _T + r"s(?:eason[\s._-]?)?(\d{1,2})(?![eE\d])(?:[\s._-]?(?:complete|pack|full|bluray|web|hdtv))?"
    "|" + _T + r"complete[\s._-]?s(?:eason[\s._-]?)?(\d{1,2})(?![eE\d]))", re.I)
_SERIES_PACK_RE = re.compile(r"(?:complete[\s._-]?series|full[\s._-]?series|all[\s._-]?seasons|"
                             r"series[\s._-]?pack|box[\s._-]?set|\bcollection\b)", re.I)
_SEASON_RANGE_RE = re.compile(
    _T + r"s(?:easons?[\s._-]?)?(\d{1,2})[\s._-]?(?:-|~|to)[\s._-]?(?:s(?:easons?)?[\s._-]?)?(\d{1,2})\b", re.I)
_BARE_COMPLETE_RE = re.compile(r"\bcomplete\b", re.I)
_FOLDER_LINE_RE = re.compile(r"(?:📁|🗂️?|folder:)\s*([^\n]+)", re.I)


def pack_type_of_name(name: str):
    """('series', None) | ('season', N) | ('episode', None) for a release/folder name."""
    if not name or _EPISODE_RE.search(name):
        return "episode", None
    if _SERIES_PACK_RE.search(name) or _SEASON_RANGE_RE.search(name):
        return "series", None
    m = _SEASON_PACK_RE.search(name)
    if m:
        return "season", int(m.group(1) or m.group(2))
    if _BARE_COMPLETE_RE.search(name):
        return "series", None
    return "episode", None


def _ints(v):
    out = set()
    for x in v or []:
        try:
            out.add(int(x))
        except (TypeError, ValueError):
            pass
    return sorted(out)


def _folder_name(st: dict):
    sd = st.get("streamData") or {}
    hints = st.get("behaviorHints") or {}
    name = sd.get("folderName") or hints.get("folderName") or (sd.get("torrent") or {}).get("folderName")
    if name:
        return name
    m = _FOLDER_LINE_RE.search(str(st.get("description") or st.get("title") or ""))
    return m.group(1).strip() if m else None


def pack_type(st: dict):
    """Classify one AIOStreams result, most reliable signal first (as aiogateway)."""
    sd = st.get("streamData") or {}
    pf = sd.get("parsedFile") or {}
    fs = _ints(pf.get("folderSeasons"))
    if fs:
        if len(fs) > 1:
            return "series", None
        return ("episode", None) if len(_ints(pf.get("folderEpisodes"))) == 1 else ("season", fs[0])
    folder = _folder_name(st)
    if folder:
        kind, n = pack_type_of_name(folder)
        if kind != "episode":
            return kind, n
    if pf.get("seasonPack"):
        ss = _ints(pf.get("seasons"))
        if len(ss) > 1:
            return "series", None
        if len(ss) == 1:
            return "season", ss[0]
    return pack_type_of_name((st.get("behaviorHints") or {}).get("filename") or "")


def pack_signature(st: dict):
    """Same for every file of one pack (infoHash, else folder); None for single episodes."""
    if pack_type(st)[0] == "episode":
        return None
    sd = st.get("streamData") or {}
    ih = st.get("infoHash") or (sd.get("torrent") or {}).get("infoHash") or sd.get("infoHash")
    if ih:
        return "ih:" + str(ih).lower()
    folder = _folder_name(st)
    return ("fn:" + folder.strip().lower()) if folder else None


def _pack_tier(st: dict, season):
    """0 = series pack, 1 = season pack for this season, 2 = anything else."""
    kind, n = pack_type(st)
    if kind == "series":
        return 0
    if kind == "season" and (n is None or season is None or n == season):
        return 1
    return 2


def _pack_scopes(stream_key):
    """'series/tt1:2:5|4k' -> ['tt1|4k|s2', 'tt1|4k|series'] (episodes only)."""
    from . import naming
    stype, sid, uhd = naming.split_stream_key(stream_key)
    parts = sid.split(":")
    if stype != "series" or len(parts) < 3:
        return [], None
    show, season = ":".join(parts[:-2]), int(parts[-2])
    q = "4k" if uhd else "hd"
    return [f"{show}|{q}|s{season}", f"{show}|{q}|series"], season


PACK_MEMORY_SECONDS = 24 * 3600

# --- stream selection filters (Settings → Streams → Stream selection) -------------

_LANG_ALIASES = {
    "en": "english", "eng": "english", "es": "spanish", "spa": "spanish", "fr": "french", "fre": "french",
    "fra": "french", "de": "german", "ger": "german", "deu": "german", "it": "italian", "ita": "italian",
    "pt": "portuguese", "por": "portuguese", "ru": "russian", "rus": "russian", "ja": "japanese",
    "jpn": "japanese", "ko": "korean", "kor": "korean", "zh": "chinese", "chi": "chinese", "hi": "hindi",
    "hin": "hindi", "ar": "arabic", "ara": "arabic", "nl": "dutch", "pl": "polish", "pol": "polish",
    "tr": "turkish", "sv": "swedish", "multi": "multi", "dual": "dual audio",
}


def _stream_text(st: dict) -> str:
    hints = st.get("behaviorHints") or {}
    sd = st.get("streamData") or {}
    return " ".join(str(x) for x in (st.get("name"), st.get("title"), st.get("description"),
                                     hints.get("filename"), sd.get("filename"), _folder_name(st)) if x)


def _exclude_patterns():
    out = []
    for term in config.list_setting("STREAM_EXCLUDE"):
        if len(term) > 2 and term.startswith("/") and term.endswith("/"):
            try:
                out.append(re.compile(term[1:-1], re.I))
                continue
            except re.error:
                term = term[1:-1]
        # whole-word match, so "TS" doesn't hit "HDTS"-free names like "Tsunami" or "DTS"
        out.append(re.compile(r"(?<![a-z0-9])" + re.escape(term) + r"(?![a-z0-9])", re.I))
    return out


def stream_languages(st: dict) -> set:
    pf = ((st.get("streamData") or {}).get("parsedFile")) or {}
    langs = set()
    for v in pf.get("languages") or []:
        v = str(v).strip().lower()
        langs.add(_LANG_ALIASES.get(v, v))
    return langs


def _wanted_languages():
    return [_LANG_ALIASES.get(x.lower(), x.lower()) for x in config.list_setting("STREAM_REQUIRED_LANGUAGES")]


def language_ok(st: dict, wanted=None) -> bool:
    wanted = _wanted_languages() if wanted is None else wanted
    if not wanted:
        return True
    have = stream_languages(st)
    if have:
        return any(w in have for w in wanted)
    text = _stream_text(st)        # no parsed languages: look in the release name
    return any(re.search(r"(?<![a-z])" + re.escape(w) + r"(?![a-z])", text, re.I) for w in wanted)


def excluded(st: dict, patterns=None) -> bool:
    patterns = _exclude_patterns() if patterns is None else patterns
    if not patterns:
        return False
    text = _stream_text(st)
    return any(p.search(text) for p in patterns)


def filter_streams(streams: list) -> list:
    """Drop excluded streams, then keep only the required languages (falling
    back to every non-excluded stream when that's enabled and nothing matches).
    Order is kept, so AIOStreams' own sorting still decides among the rest."""
    pats, wanted = _exclude_patterns(), _wanted_languages()
    kept = [s for s in streams if not excluded(s, pats)]
    if not wanted:
        return kept
    lang = [s for s in kept if language_ok(s, wanted)]
    if lang or not config.STREAM_LANGUAGE_FALLBACK:
        return lang
    return kept


def pick_stream(streams: list, prefer_filename: str | None = None, uhd: bool | None = None,
                stream_key: str | None = None):
    """AIOStreams already sorts by the user's rules; take the first playable
    HTTP stream of the wanted quality (uhd=True: 4K only, False: non-4K only,
    None: any), keeping the previously used file when it is still offered so
    Plex's stored media info stays valid.

    Streams removed by the exclusion / required-language settings are never picked.

    Episodes (stream_key given, PREFER_PACKS on): a pack that already played
    for this season/show goes first, then series packs, season packs, and
    single-episode releases, keeping AIOStreams' order within each group."""
    playable = filter_streams([s for s in streams if (s.get("url") or "").startswith("http")
                               and (uhd is None or is_4k(s) == uhd)])
    if not playable:
        return None
    if prefer_filename:
        for s in playable:
            if ((s.get("behaviorHints") or {}).get("filename")) == prefer_filename:
                return s
    scopes, season = _pack_scopes(stream_key) if stream_key else ([], None)
    if not scopes or not config.PREFER_PACKS:
        return playable[0]
    for scope in scopes:
        known = db.get_pack(scope, PACK_MEMORY_SECONDS)
        if known:
            for s in playable:
                if pack_signature(s) == known["sig"]:
                    return s
    return sorted(playable, key=lambda s: _pack_tier(s, season))[0]   # stable sort


def remember_pick(stream_key: str, st: dict):
    """Remember the pack a working pick came from, so its next episodes try it first."""
    scopes, _ = _pack_scopes(stream_key)
    sig = pack_signature(st) if scopes else None
    if not sig:
        return
    kind, _ = pack_type(st)
    db.remember_pack(scopes[1] if kind == "series" else scopes[0], sig, st.get("url"))


def stream_url_fresh(s) -> bool:
    return bool(s and s.get("url") and s.get("resolved_at")
                and time.time() - s["resolved_at"] < config.STREAM_URL_TTL_MIN * 60)
