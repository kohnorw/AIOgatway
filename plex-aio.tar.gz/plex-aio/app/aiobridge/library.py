"""Library management: add/remove titles, catalog sync, Cinemeta search, scan batching."""
import asyncio
import datetime
import logging
import urllib.parse

import aiohttp

from . import clients, config, db, naming, placeholder, vfs
from .clients import TMDB, plex, tmdb

log = logging.getLogger("aio.library")


# --- scan batching -------------------------------------------------------------

class ScanQueue:
    """Collects changed folders and asks Plex to scan only those paths.

    Bursts (e.g. a catalog sync adding hundreds of titles) collapse into one
    section scan, which only stats unchanged files. Automatic scanning in
    Plex itself is switched off, so this queue is the only trigger.
    """

    BURST = 40

    def __init__(self):
        self.paths: set[str] = set()
        self.removed = False
        self._event = asyncio.Event()

    def add(self, rel_path: str, removed: bool = False):
        self.paths.add(f"{config.MOUNT_POINT}/{rel_path}")
        self.removed |= removed
        self._event.set()

    async def run(self):
        while True:
            await self._event.wait()
            await asyncio.sleep(2)            # let a burst settle
            self._event.clear()
            paths, self.paths = self.paths, set()
            removed, self.removed = self.removed, False
            try:
                await self._flush(paths, removed)
            except Exception as e:  # noqa: BLE001
                log.warning("plex scan request failed: %s (will retry)", e)
                self.paths |= paths
                self.removed |= removed
                await asyncio.sleep(30)
                self._event.set()

    async def _flush(self, paths, removed):
        by_top: dict[str, list[str]] = {}
        for p in paths:
            top = "/".join(p.split("/")[: len(config.MOUNT_POINT.split("/")) + 1])
            by_top.setdefault(top, []).append(p)
        for top, ps in by_top.items():
            if len(ps) > self.BURST:
                await plex.refresh_section_of(top)
            else:
                for p in ps:
                    await plex.refresh_path(p)
            if removed:
                await asyncio.sleep(5)
                await plex.empty_trash_of(top)
        log.info("requested Plex scan of %d path(s)", len(paths))


scans = ScanQueue()


class SeriesRefresher:
    """Scans a show one season folder at a time, pausing between seasons,
    so a big show doesn't make Plex analyze hundreds of files at once."""

    def __init__(self):
        self.queue: asyncio.Queue = asyncio.Queue()
        self.pending: set = set()

    def add(self, rel_path: str):
        path = f"{config.MOUNT_POINT}/{rel_path}"
        if path not in self.pending:
            self.pending.add(path)
            self.queue.put_nowait(path)

    def add_show(self, item, seasons, uhd: bool = False):
        base = naming.item_rel_path(item, uhd)
        for n in sorted(seasons):
            self.add(f"{base}/{naming.season_dir(n)}")

    async def run(self):
        while True:
            path = await self.queue.get()
            self.pending.discard(path)
            try:
                if not await plex.refresh_path(path):
                    # no library covers it yet / show folder not scanned yet: fall back to the show folder
                    await plex.refresh_path(path.rsplit("/", 1)[0])
                log.info("scanned %s", path[len(config.MOUNT_POINT) + 1:])
            except Exception as e:  # noqa: BLE001
                log.warning("season scan failed for %s: %s (retrying later)", path, e)
                await asyncio.sleep(30)
                self.add(path[len(config.MOUNT_POINT) + 1:])
            await asyncio.sleep(max(0, config.SERIES_REFRESH_STAGGER_SECONDS))


series_scans = SeriesRefresher()


async def scan_now(rel_path: str):
    """Movies: ask Plex to scan the folder right away (queue as fallback)."""
    try:
        if await plex.refresh_path(f"{config.MOUNT_POINT}/{rel_path}"):
            log.info("scanned %s", rel_path)
            return
    except Exception as e:  # noqa: BLE001
        log.warning("immediate scan failed for %s: %s", rel_path, e)
    scans.add(rel_path)


# --- adding titles --------------------------------------------------------------

def _year(date: str | None):
    return int(date[:4]) if date and len(date) >= 4 and date[:4].isdigit() else None


async def resolve_ids(stremio_id: str, kind: str):
    """Map a Stremio id (tt..., tmdb:123) to (tmdb_id, imdb_id)."""
    if stremio_id.startswith("tmdb:"):
        return int(stremio_id.split(":")[1]), None
    if stremio_id.startswith("tt"):
        found = await tmdb.find_imdb(stremio_id.split(":")[0])
        res = found.get("movie_results" if kind == "movie" else "tv_results") or []
        if res:
            return res[0]["id"], stremio_id.split(":")[0]
    return None, None


# --- 4K availability --------------------------------------------------------------

async def count_4k(stype: str, sid: str) -> int:
    """One AIOStreams stream lookup; how many playable 4K results it returns."""
    if not config.AIOSTREAMS_MANIFEST_URL:
        return 0
    base = clients.addon_base(config.AIOSTREAMS_MANIFEST_URL)
    url = f"{base}/stream/{stype}/{urllib.parse.quote(sid, safe=':')}.json"
    async with clients.session().get(url, timeout=aiohttp.ClientTimeout(total=60)) as r:
        r.raise_for_status()
        data = await r.json(content_type=None)
    return sum(1 for st in data.get("streams") or []
               if (st.get("url") or "").startswith("http") and vfs.is_4k(st))


async def check_4k_movie(key: str) -> bool:
    item = db.get_item(key)
    if not config.CHECK_4K or not item or not item.get("imdb"):
        return False
    try:
        n = await count_4k("movie", item["imdb"])
    except Exception as e:  # noqa: BLE001
        log.warning("4K check failed for %s: %s (HD only)", item["title"], e)
        return False
    has = n >= config.MIN_4K_CANDIDATES
    log.info("4K check %s: %d 4K source(s) (need %d) -> %s", item["title"], n, config.MIN_4K_CANDIDATES,
             "4K" if has else "HD only")
    db.set_has_4k(key, has)
    if has:
        await scan_now(naming.item_rel_path(db.get_item(key), uhd=True))
    return has


async def check_4k_show(key: str, only_seasons=None) -> set:
    """One lookup per season (its first aired episode; season packs cover it)."""
    item = db.get_item(key)
    if not config.CHECK_4K or not item or not item.get("imdb"):
        return set()
    firsts = {}
    wanted = wanted_seasons(key)
    for ep in db.episodes(key):
        if naming.aired(ep.get("air_date")) and ep["season"] > 0 and ep["season"] in wanted:
            firsts.setdefault(ep["season"], ep["episode"])
    found = set()
    for season, first_ep in sorted(firsts.items()):
        if only_seasons is not None and season not in only_seasons:
            continue
        try:
            n = await count_4k("series", f"{item['imdb']}:{season}:{first_ep}")
        except Exception as e:  # noqa: BLE001
            log.warning("4K check failed for %s S%02d: %s", item["title"], season, e)
            continue
        has = n >= config.MIN_4K_CANDIDATES
        db.set_season_4k(key, season, has)
        if has:
            found.add(season)
    log.info("4K check %s: seasons with 4K: %s", item["title"], sorted(found) or "none")
    if found:
        series_scans.add_show(db.get_item(key), found & visible_seasons(key), uhd=True)
    return found


_background: set = set()
checking_4k: set = set()          # item keys whose 4K check is running (shown in the UI)


def _bg(coro, key=None):
    if key:
        checking_4k.add(key)
    t = asyncio.create_task(coro)
    _background.add(t)

    def done(task):
        _background.discard(task)
        if key:
            checking_4k.discard(key)
    t.add_done_callback(done)


async def add_movie(tmdb_id: int, source: str, imdb: str | None = None):
    key = f"movie:{tmdb_id}"
    existed = db.get_item(key) is not None
    if not existed:
        m = await tmdb.movie(tmdb_id)
        imdb = m.get("imdb_id") or (m.get("external_ids") or {}).get("imdb_id") or imdb
        db.upsert_item(key, "movie", tmdb_id, imdb, m.get("title") or m.get("original_title"),
                       _year(m.get("release_date")), m.get("runtime") or None, m.get("status"))
        db.set_poster(key, TMDB.img(m.get("poster_path")))
        await placeholder.ensure()
        await scan_now(naming.item_rel_path(db.get_item(key)))
        log.info("added movie %s (%s) via %s", m.get("title"), tmdb_id, source)
        _bg(check_4k_movie(key), key)
    db.touch_source(key, source)
    return key, not existed


async def refresh_show(key: str) -> bool:
    """Store every known episode (aired and upcoming, with air dates).
    Returns True if the episode list changed."""
    item = db.get_item(key)
    s = await tmdb.show(item["tmdb"])
    imdb = (s.get("external_ids") or {}).get("imdb_id") or item.get("imdb")
    runtimes = s.get("episode_run_time") or []
    rt = runtimes[0] if runtimes else (item.get("runtime") or 45)
    db.upsert_item(key, "show", item["tmdb"], imdb, s.get("name") or item["title"],
                   _year(s.get("first_air_date")), rt, s.get("status"))
    eps = []
    for se in s.get("seasons") or []:
        n = se.get("season_number")
        if n is None or not se.get("episode_count"):
            continue
        try:
            data = await tmdb.season(item["tmdb"], n)
        except KeyError:
            continue
        for e in data.get("episodes") or []:
            eps.append((n, e["episode_number"], e.get("name"), e.get("runtime") or rt, e.get("air_date")))
    await placeholder.ensure()
    return db.replace_episodes(key, eps)


def visible_seasons(key) -> set:
    """Seasons that currently have at least one aired, wanted episode."""
    item = db.get_item(key)
    req = db.requested_seasons(key)
    exc = db.excluded_seasons(key)
    return {e["season"] for e in db.episodes(key)
            if naming.aired(e.get("air_date")) and naming.wanted_episode(item, e["season"], e.get("air_date"), req, exc)}


def wanted_seasons(key) -> set:
    """Seasons the request covers, aired or not (4K checks use this)."""
    item = db.get_item(key)
    req = db.requested_seasons(key)
    exc = db.excluded_seasons(key)
    return {e["season"] for e in db.episodes(key)
            if naming.wanted_episode(item, e["season"], e.get("air_date"), req, exc)}


def _announce_visible(key, track_new: bool = False):
    """Queue staggered scans for newly visible episodes and mark them announced.
    track_new: they appeared because they aired (not because they were just
    requested), so they count as new episodes in the UI."""
    item = db.get_item(key)
    req = db.requested_seasons(key)
    exc = db.excluded_seasons(key)
    new = [e for e in db.episodes(key) if not e.get("announced") and naming.aired(e.get("air_date"))
           and naming.wanted_episode(item, e["season"], e.get("air_date"), req, exc)]
    if not new:
        return 0
    seasons = {e["season"] for e in new}
    series_scans.add_show(item, seasons)
    s4k = db.seasons_4k(key) & seasons
    if s4k:
        series_scans.add_show(item, s4k, uhd=True)
    db.mark_announced(key, [(e["season"], e["episode"]) for e in new], new=track_new)
    if track_new:
        log.info("new episode(s) of %s: %s", item["title"],
                 ", ".join(f"S{e['season']:02d}E{e['episode']:02d}" for e in new))
    return len(new)


def ended(item) -> bool:
    return (item or {}).get("status") in ("Ended", "Canceled")


def _today():
    return datetime.date.today().isoformat()


async def add_show(tmdb_id: int, source: str, imdb: str | None = None,
                   mode: str = "all", seasons=None):
    """mode: 'all' (every season incl. future), 'new' (only episodes airing from
    now on), 'seasons' (the given seasons). Requesting again adds to it."""
    key = f"show:{tmdb_id}"
    existed = db.get_item(key) is not None
    if not existed:
        s = await tmdb.show(tmdb_id)
        db.upsert_item(key, "show", tmdb_id, (s.get("external_ids") or {}).get("imdb_id") or imdb,
                       s.get("name") or s.get("original_name"), _year(s.get("first_air_date")),
                       (s.get("episode_run_time") or [45])[0], s.get("status"))
        db.set_poster(key, TMDB.img(s.get("poster_path")))
        db.set_monitor(key, "seasons")          # narrowest; widened below
        await refresh_show(key)
        log.info("added show %s (%s) via %s", s.get("name"), tmdb_id, source)
    before = visible_seasons(key)
    before_wanted = wanted_seasons(key)
    _apply_request(key, mode, seasons)
    added = wanted_seasons(key) - before_wanted
    _announce_visible(key)
    if added or not existed:
        _bg(check_4k_show(key, added or None), key)
    db.touch_source(key, source)
    changed = not existed or bool(visible_seasons(key) - before)
    return key, changed


def _apply_request(key, mode, seasons):
    item = db.get_item(key)
    cur = item.get("monitor") or "all"
    if mode == "all":
        db.unexclude_seasons(key)
        db.set_monitor(key, "all")
    elif mode == "new":
        if cur != "all":
            with db.conn() as c:
                c.execute("UPDATE items SET monitor='new', monitor_since=COALESCE(monitor_since, ?) WHERE key=?",
                          (_today(), key))
    if seasons:
        db.unexclude_seasons(key, seasons)
        db.add_requested_seasons(key, [int(n) for n in seasons])
        if cur == "all" and mode != "all":
            pass                                # already covers everything


async def request_show(tmdb_id: int, source: str, mode="all", seasons=None, imdb=None):
    return await add_show(tmdb_id, source, imdb, mode, seasons)


async def add_stremio(stremio_id: str, stype: str, source: str, mode: str = "all", seasons=None):
    kind = "movie" if stype == "movie" else "show"
    tmdb_id, imdb = await resolve_ids(stremio_id, kind)
    if not tmdb_id:
        return None, False
    if kind == "movie":
        return await add_movie(tmdb_id, source, imdb)
    return await add_show(tmdb_id, source, imdb, mode, seasons)


def remove(key: str):
    item = db.get_item(key)
    if not item:
        return
    had_4k = item.get("has_4k") or db.seasons_4k(key)
    db.delete_item(key)
    scans.add(naming.item_rel_path(item), removed=True)
    if had_4k:
        scans.add(naming.item_rel_path(item, uhd=True), removed=True)
    log.info("removed %s", key)


# --- Cinemeta search ----------------------------------------------------------------

def _relevant(query: str, name: str) -> bool:
    q, n = naming.norm_title(query), naming.norm_title(name)
    if not q or not n:
        return False
    return q in n or n in q or all(w in n.split() for w in q.split())


async def search_and_add(query: str, per_type: int | None = None):
    """Look the query up on Cinemeta and add the best matches. Returns new item keys."""
    per_type = per_type or config.SEARCH_RESULTS_PER_TYPE
    added = []
    results = await asyncio.gather(clients.cinemeta_search(query, "movie"),
                                   clients.cinemeta_search(query, "series"))
    for stype, metas in zip(("movie", "series"), results):
        picks = [m for m in metas if m.get("id", "").startswith("tt") and _relevant(query, m.get("name", ""))]
        for m in picks[:per_type]:
            try:
                key, new = await add_stremio(m["id"], stype, "search")
                if new:
                    added.append(key)
            except Exception as e:  # noqa: BLE001
                log.warning("could not add %s: %s", m.get("id"), e)
    return added


async def refresh_continuing_shows():
    """Pull new episodes/seasons from TMDB for shows that are still airing."""
    for item in db.all_items("show"):
        if ended(item):
            continue
        try:
            before = wanted_seasons(item["key"])
            await refresh_show(item["key"])
            new_seasons = wanted_seasons(item["key"]) - before
            if new_seasons:
                await check_4k_show(item["key"], new_seasons)
        except Exception as e:  # noqa: BLE001
            log.warning("refresh %s failed: %s", item["key"], e)


async def episode_watcher():
    """Every 30 minutes: episodes that have aired since the last check appear
    in the library (their air date passed), so ask Plex to scan their season."""
    while True:
        total = 0
        for item in db.all_items("show"):
            try:
                total += _announce_visible(item["key"], track_new=True)
            except Exception as e:  # noqa: BLE001
                log.warning("episode check %s failed: %s", item["key"], e)
        if total:
            log.info("new episodes available: %d (scanning their seasons)", total)
        await asyncio.sleep(1800)


async def scheduler():
    """Keeps ongoing shows current (new episodes, 4K for new seasons)."""
    while True:
        try:
            await refresh_continuing_shows()
        except Exception as e:  # noqa: BLE001
            log.exception("scheduled sync failed: %s", e)
        await asyncio.sleep(max(1, config.SYNC_INTERVAL_HOURS) * 3600)


async def ensure_libraries():
    """Create the Movies / TV Shows libraries once Plex is claimed."""
    if not config.AUTO_CREATE_LIBRARIES:
        return
    for _ in range(120):
        if clients.plex_token():
            break
        await asyncio.sleep(30)
    else:
        return
    wanted = [
        ("Movies", "movie", config.PLEX_MOVIE_AGENT, "Plex Movie", f"{config.MOUNT_POINT}/movies"),
        ("TV Shows", "show", config.PLEX_TV_AGENT, "Plex TV Series", f"{config.MOUNT_POINT}/tv"),
        ("Movies 4K", "movie", config.PLEX_MOVIE_AGENT, "Plex Movie", f"{config.MOUNT_POINT}/movies4k"),
        ("TV Shows 4K", "show", config.PLEX_TV_AGENT, "Plex TV Series", f"{config.MOUNT_POINT}/tv4k"),
    ]
    for attempt in range(20):
        try:
            for name, kind, agent, scanner, loc in wanted:
                if not await plex.section_for(loc):
                    await plex.create_section(name, kind, agent, scanner, loc)
                    log.info("created Plex library %s -> %s (agent %s)", name, loc, agent)
            return
        except Exception as e:  # noqa: BLE001
            log.warning("library setup attempt %d failed: %s", attempt + 1, e)
            await asyncio.sleep(30)


def remove_season(key: str, season: int):
    """Drop one season from a show (HD and 4K). It stays out, including future
    episodes, until it's requested again."""
    item = db.get_item(key)
    db.exclude_season(key, season)
    for uhd in (False, True):
        scans.add(f"{naming.item_rel_path(item, uhd)}/{naming.season_dir(season)}", removed=True)
    log.info("removed %s season %d", item["title"], season)


def set_episode_file(key: str, season: int, episode: int, uhd: bool, present: bool):
    """Delete (present=False) or restore one episode's HD or 4K file."""
    item = db.get_item(key)
    db.set_episode_hidden(key, season, episode, uhd, not present)
    if not present:
        db.delete_stream(naming.stream_key_episode(item, season, episode, uhd))
    path = f"{naming.item_rel_path(item, uhd)}/{naming.season_dir(season)}"
    if present:
        series_scans.add(path)
    else:
        scans.add(path, removed=True)
