"""Library management: add/remove titles, catalog sync, Cinemeta search, scan batching."""
import asyncio
import datetime
import logging
import urllib.parse

import aiohttp

from . import clients, config, db, naming, placeholder, vfs
from .clients import TMDB, plex, tmdb

log = logging.getLogger("aio.library")


# --- scan batching -------------------------------------------------------------

class ScanQueue:
    """Collects changed folders and asks Plex to scan only those paths.

    Bursts (e.g. a catalog sync adding hundreds of titles) collapse into one
    section scan, which only stats unchanged files. Automatic scanning in
    Plex itself is switched off, so this queue is the only trigger.
    """

    BURST = 40

    def __init__(self):
        self.paths: set[str] = set()
        self.removed = False
        self._event = asyncio.Event()

    def add(self, rel_path: str, removed: bool = False):
        self.paths.add(f"{config.MOUNT_POINT}/{rel_path}")
        self.removed |= removed
        self._event.set()

    async def run(self):
        while True:
            await self._event.wait()
            await asyncio.sleep(2)            # let a burst settle
            self._event.clear()
            paths, self.paths = self.paths, set()
            removed, self.removed = self.removed, False
            try:
                await self._flush(paths, removed)
            except Exception as e:  # noqa: BLE001
                log.warning("plex scan request failed: %s (will retry)", e)
                self.paths |= paths
                self.removed |= removed
                await asyncio.sleep(30)
                self._event.set()

    async def _flush(self, paths, removed):
        by_top: dict[str, list[str]] = {}
        for p in paths:
            top = "/".join(p.split("/")[: len(config.MOUNT_POINT.split("/")) + 1])
            by_top.setdefault(top, []).append(p)
        for top, ps in by_top.items():
            if len(ps) > self.BURST:
                await plex.refresh_section_of(top)
            else:
                for p in ps:
                    await plex.refresh_path(p)
            if removed:
                await asyncio.sleep(5)
                await plex.empty_trash_of(top)
        log.info("requested Plex scan of %d path(s)", len(paths))


scans = ScanQueue()


# --- adding titles --------------------------------------------------------------

def _year(date: str | None):
    return int(date[:4]) if date and len(date) >= 4 and date[:4].isdigit() else None


async def resolve_ids(stremio_id: str, kind: str):
    """Map a Stremio id (tt..., tmdb:123) to (tmdb_id, imdb_id)."""
    if stremio_id.startswith("tmdb:"):
        return int(stremio_id.split(":")[1]), None
    if stremio_id.startswith("tt"):
        found = await tmdb.find_imdb(stremio_id.split(":")[0])
        res = found.get("movie_results" if kind == "movie" else "tv_results") or []
        if res:
            return res[0]["id"], stremio_id.split(":")[0]
    return None, None


# --- 4K availability --------------------------------------------------------------

async def count_4k(stype: str, sid: str) -> int:
    """One AIOStreams stream lookup; how many playable 4K results it returns."""
    if not config.AIOSTREAMS_MANIFEST_URL:
        return 0
    base = clients.addon_base(config.AIOSTREAMS_MANIFEST_URL)
    url = f"{base}/stream/{stype}/{urllib.parse.quote(sid, safe=':')}.json"
    async with clients.session().get(url, timeout=aiohttp.ClientTimeout(total=60)) as r:
        r.raise_for_status()
        data = await r.json(content_type=None)
    return sum(1 for st in data.get("streams") or []
               if (st.get("url") or "").startswith("http") and vfs.is_4k(st))


async def check_4k_movie(key: str) -> bool:
    item = db.get_item(key)
    if not config.CHECK_4K or not item or not item.get("imdb"):
        return False
    try:
        n = await count_4k("movie", item["imdb"])
    except Exception as e:  # noqa: BLE001
        log.warning("4K check failed for %s: %s (HD only)", item["title"], e)
        return False
    has = n >= config.MIN_4K_CANDIDATES
    log.info("4K check %s: %d 4K source(s) (need %d) -> %s", item["title"], n, config.MIN_4K_CANDIDATES,
             "4K" if has else "HD only")
    db.set_has_4k(key, has)
    if has:
        scans.add(naming.item_rel_path(db.get_item(key), uhd=True))
    return has


async def check_4k_show(key: str, only_seasons=None) -> set:
    """One lookup per season (its first aired episode; season packs cover it)."""
    item = db.get_item(key)
    if not config.CHECK_4K or not item or not item.get("imdb"):
        return set()
    firsts = {}
    for ep in db.episodes(key):
        if naming.aired(ep.get("air_date")) and ep["season"] > 0:
            firsts.setdefault(ep["season"], ep["episode"])
    found = set()
    for season, first_ep in sorted(firsts.items()):
        if only_seasons is not None and season not in only_seasons:
            continue
        try:
            n = await count_4k("series", f"{item['imdb']}:{season}:{first_ep}")
        except Exception as e:  # noqa: BLE001
            log.warning("4K check failed for %s S%02d: %s", item["title"], season, e)
            continue
        has = n >= config.MIN_4K_CANDIDATES
        db.set_season_4k(key, season, has)
        if has:
            found.add(season)
    log.info("4K check %s: seasons with 4K: %s", item["title"], sorted(found) or "none")
    if found:
        scans.add(naming.item_rel_path(db.get_item(key), uhd=True))
    return found


_background: set = set()
checking_4k: set = set()          # item keys whose 4K check is running (shown in the UI)


def _bg(coro, key=None):
    if key:
        checking_4k.add(key)
    t = asyncio.create_task(coro)
    _background.add(t)

    def done(task):
        _background.discard(task)
        if key:
            checking_4k.discard(key)
    t.add_done_callback(done)


async def add_movie(tmdb_id: int, source: str, imdb: str | None = None):
    key = f"movie:{tmdb_id}"
    existed = db.get_item(key) is not None
    if not existed:
        m = await tmdb.movie(tmdb_id)
        imdb = m.get("imdb_id") or (m.get("external_ids") or {}).get("imdb_id") or imdb
        db.upsert_item(key, "movie", tmdb_id, imdb, m.get("title") or m.get("original_title"),
                       _year(m.get("release_date")), m.get("runtime") or None, m.get("status"))
        db.set_poster(key, TMDB.img(m.get("poster_path")))
        await placeholder.ensure()
        scans.add(naming.item_rel_path(db.get_item(key)))
        log.info("added movie %s (%s) via %s", m.get("title"), tmdb_id, source)
        _bg(check_4k_movie(key), key)
    db.touch_source(key, source)
    return key, not existed


async def refresh_show(key: str) -> bool:
    item = db.get_item(key)
    s = await tmdb.show(item["tmdb"])
    imdb = (s.get("external_ids") or {}).get("imdb_id") or item.get("imdb")
    runtimes = s.get("episode_run_time") or []
    rt = runtimes[0] if runtimes else (item.get("runtime") or 45)
    db.upsert_item(key, "show", item["tmdb"], imdb, s.get("name") or item["title"],
                   _year(s.get("first_air_date")), rt, s.get("status"))
    today = datetime.date.today().isoformat()
    eps = []
    for se in s.get("seasons") or []:
        n = se.get("season_number")
        if n is None or not se.get("episode_count"):
            continue
        if se.get("air_date") and se["air_date"] > today:
            continue
        data = await tmdb.season(item["tmdb"], n)
        for e in data.get("episodes") or []:
            if naming.aired(e.get("air_date"), today):
                eps.append((n, e["episode_number"], e.get("name"), e.get("runtime") or rt, e.get("air_date")))
    await placeholder.ensure()
    return db.replace_episodes(key, eps)


async def add_show(tmdb_id: int, source: str, imdb: str | None = None):
    key = f"show:{tmdb_id}"
    existed = db.get_item(key) is not None
    if not existed:
        s = await tmdb.show(tmdb_id)
        db.upsert_item(key, "show", tmdb_id, (s.get("external_ids") or {}).get("imdb_id") or imdb,
                       s.get("name") or s.get("original_name"), _year(s.get("first_air_date")),
                       (s.get("episode_run_time") or [45])[0], s.get("status"))
        db.set_poster(key, TMDB.img(s.get("poster_path")))
        await refresh_show(key)
        scans.add(naming.item_rel_path(db.get_item(key)))
        log.info("added show %s (%s) via %s", s.get("name"), tmdb_id, source)
        _bg(check_4k_show(key), key)
    db.touch_source(key, source)
    return key, not existed


async def add_stremio(stremio_id: str, stype: str, source: str):
    kind = "movie" if stype == "movie" else "show"
    tmdb_id, imdb = await resolve_ids(stremio_id, kind)
    if not tmdb_id:
        return None, False
    return await (add_movie if kind == "movie" else add_show)(tmdb_id, source, imdb)


def remove(key: str):
    item = db.get_item(key)
    if not item:
        return
    had_4k = item.get("has_4k") or db.seasons_4k(key)
    db.delete_item(key)
    scans.add(naming.item_rel_path(item), removed=True)
    if had_4k:
        scans.add(naming.item_rel_path(item, uhd=True), removed=True)
    log.info("removed %s", key)


# --- Cinemeta search ----------------------------------------------------------------

def _relevant(query: str, name: str) -> bool:
    q, n = naming.norm_title(query), naming.norm_title(name)
    if not q or not n:
        return False
    return q in n or n in q or all(w in n.split() for w in q.split())


async def search_and_add(query: str, per_type: int | None = None):
    """Look the query up on Cinemeta and add the best matches. Returns new item keys."""
    per_type = per_type or config.SEARCH_RESULTS_PER_TYPE
    added = []
    results = await asyncio.gather(clients.cinemeta_search(query, "movie"),
                                   clients.cinemeta_search(query, "series"))
    for stype, metas in zip(("movie", "series"), results):
        picks = [m for m in metas if m.get("id", "").startswith("tt") and _relevant(query, m.get("name", ""))]
        for m in picks[:per_type]:
            try:
                key, new = await add_stremio(m["id"], stype, "search")
                if new:
                    added.append(key)
            except Exception as e:  # noqa: BLE001
                log.warning("could not add %s: %s", m.get("id"), e)
    return added


async def refresh_continuing_shows():
    for item in db.all_items("show"):
        if item.get("status") in ("Ended", "Canceled"):
            continue
        try:
            before = {e["season"] for e in db.episodes(item["key"])}
            if await refresh_show(item["key"]):
                scans.add(naming.item_rel_path(db.get_item(item["key"])))
                new_seasons = {e["season"] for e in db.episodes(item["key"])} - before
                if new_seasons:
                    await check_4k_show(item["key"], new_seasons)
        except Exception as e:  # noqa: BLE001
            log.warning("refresh %s failed: %s", item["key"], e)


async def scheduler():
    """Keeps ongoing shows current (new episodes, 4K for new seasons)."""
    while True:
        try:
            await refresh_continuing_shows()
        except Exception as e:  # noqa: BLE001
            log.exception("scheduled sync failed: %s", e)
        await asyncio.sleep(max(1, config.SYNC_INTERVAL_HOURS) * 3600)


async def ensure_libraries():
    """Create the Movies / TV Shows libraries once Plex is claimed."""
    if not config.AUTO_CREATE_LIBRARIES:
        return
    for _ in range(120):
        if clients.plex_token():
            break
        await asyncio.sleep(30)
    else:
        return
    wanted = [
        ("Movies", "movie", config.PLEX_MOVIE_AGENT, "Plex Movie", f"{config.MOUNT_POINT}/movies"),
        ("TV Shows", "show", config.PLEX_TV_AGENT, "Plex TV Series", f"{config.MOUNT_POINT}/tv"),
        ("Movies 4K", "movie", config.PLEX_MOVIE_AGENT, "Plex Movie", f"{config.MOUNT_POINT}/movies4k"),
        ("TV Shows 4K", "show", config.PLEX_TV_AGENT, "Plex TV Series", f"{config.MOUNT_POINT}/tv4k"),
    ]
    for attempt in range(20):
        try:
            for name, kind, agent, scanner, loc in wanted:
                if not await plex.section_for(loc):
                    await plex.create_section(name, kind, agent, scanner, loc)
                    log.info("created Plex library %s -> %s (agent %s)", name, loc, agent)
            return
        except Exception as e:  # noqa: BLE001
            log.warning("library setup attempt %d failed: %s", attempt + 1, e)
            await asyncio.sleep(30)
