"""Library management: add/remove titles, catalog sync, Cinemeta search, scan batching."""
import asyncio
import datetime
import logging
import time

from . import clients, config, db, naming, placeholder
from .clients import plex, tmdb

log = logging.getLogger("aio.library")


# --- scan batching -------------------------------------------------------------

class ScanQueue:
    """Collects changed folders and asks Plex to scan only those paths.

    Bursts (e.g. a catalog sync adding hundreds of titles) collapse into one
    section scan, which only stats unchanged files. Automatic scanning in
    Plex itself is switched off, so this queue is the only trigger.
    """

    BURST = 40

    def __init__(self):
        self.paths: set[str] = set()
        self.removed = False
        self._event = asyncio.Event()

    def add(self, rel_path: str, removed: bool = False):
        self.paths.add(f"{config.MOUNT_POINT}/{rel_path}")
        self.removed |= removed
        self._event.set()

    async def run(self):
        while True:
            await self._event.wait()
            await asyncio.sleep(2)            # let a burst settle
            self._event.clear()
            paths, self.paths = self.paths, set()
            removed, self.removed = self.removed, False
            try:
                await self._flush(paths, removed)
            except Exception as e:  # noqa: BLE001
                log.warning("plex scan request failed: %s (will retry)", e)
                self.paths |= paths
                self.removed |= removed
                await asyncio.sleep(30)
                self._event.set()

    async def _flush(self, paths, removed):
        by_top: dict[str, list[str]] = {}
        for p in paths:
            top = "/".join(p.split("/")[: len(config.MOUNT_POINT.split("/")) + 1])
            by_top.setdefault(top, []).append(p)
        for top, ps in by_top.items():
            if len(ps) > self.BURST:
                await plex.refresh_section_of(top)
            else:
                for p in ps:
                    await plex.refresh_path(p)
            if removed:
                await asyncio.sleep(5)
                await plex.empty_trash_of(top)
        log.info("requested Plex scan of %d path(s)", len(paths))


scans = ScanQueue()


# --- adding titles --------------------------------------------------------------

def _year(date: str | None):
    return int(date[:4]) if date and len(date) >= 4 and date[:4].isdigit() else None


async def resolve_ids(stremio_id: str, kind: str):
    """Map a Stremio id (tt..., tmdb:123) to (tmdb_id, imdb_id)."""
    if stremio_id.startswith("tmdb:"):
        return int(stremio_id.split(":")[1]), None
    if stremio_id.startswith("tt"):
        found = await tmdb.find_imdb(stremio_id.split(":")[0])
        res = found.get("movie_results" if kind == "movie" else "tv_results") or []
        if res:
            return res[0]["id"], stremio_id.split(":")[0]
    return None, None


async def add_movie(tmdb_id: int, source: str, imdb: str | None = None):
    key = f"movie:{tmdb_id}"
    existed = db.get_item(key) is not None
    if not existed:
        m = await tmdb.movie(tmdb_id)
        imdb = m.get("imdb_id") or (m.get("external_ids") or {}).get("imdb_id") or imdb
        db.upsert_item(key, "movie", tmdb_id, imdb, m.get("title") or m.get("original_title"),
                       _year(m.get("release_date")), m.get("runtime") or None, m.get("status"))
        await placeholder.ensure(m.get("runtime") or 110)
        scans.add(naming.item_rel_path(db.get_item(key)))
        log.info("added movie %s (%s) via %s", m.get("title"), tmdb_id, source)
    db.touch_source(key, source)
    return key, not existed


async def refresh_show(key: str) -> bool:
    item = db.get_item(key)
    s = await tmdb.show(item["tmdb"])
    imdb = (s.get("external_ids") or {}).get("imdb_id") or item.get("imdb")
    runtimes = s.get("episode_run_time") or []
    rt = runtimes[0] if runtimes else (item.get("runtime") or 45)
    db.upsert_item(key, "show", item["tmdb"], imdb, s.get("name") or item["title"],
                   _year(s.get("first_air_date")), rt, s.get("status"))
    today = datetime.date.today().isoformat()
    eps = []
    for se in s.get("seasons") or []:
        n = se.get("season_number")
        if n is None or not se.get("episode_count"):
            continue
        if se.get("air_date") and se["air_date"] > today:
            continue
        data = await tmdb.season(item["tmdb"], n)
        for e in data.get("episodes") or []:
            if naming.aired(e.get("air_date"), today):
                eps.append((n, e["episode_number"], e.get("name"), e.get("runtime") or rt, e.get("air_date")))
    for r in {e[3] for e in eps} | {rt}:
        await placeholder.ensure(r)
    return db.replace_episodes(key, eps)


async def add_show(tmdb_id: int, source: str, imdb: str | None = None):
    key = f"show:{tmdb_id}"
    existed = db.get_item(key) is not None
    if not existed:
        s = await tmdb.show(tmdb_id)
        db.upsert_item(key, "show", tmdb_id, (s.get("external_ids") or {}).get("imdb_id") or imdb,
                       s.get("name") or s.get("original_name"), _year(s.get("first_air_date")),
                       (s.get("episode_run_time") or [45])[0], s.get("status"))
        await refresh_show(key)
        scans.add(naming.item_rel_path(db.get_item(key)))
        log.info("added show %s (%s) via %s", s.get("name"), tmdb_id, source)
    db.touch_source(key, source)
    return key, not existed


async def add_stremio(stremio_id: str, stype: str, source: str):
    kind = "movie" if stype == "movie" else "show"
    tmdb_id, imdb = await resolve_ids(stremio_id, kind)
    if not tmdb_id:
        return None, False
    return await (add_movie if kind == "movie" else add_show)(tmdb_id, source, imdb)


def remove(key: str):
    item = db.get_item(key)
    if not item:
        return
    rel = naming.item_rel_path(item)
    db.delete_item(key)
    scans.add(rel, removed=True)
    log.info("removed %s", key)


# --- Cinemeta search ----------------------------------------------------------------

def _relevant(query: str, name: str) -> bool:
    q, n = naming.norm_title(query), naming.norm_title(name)
    if not q or not n:
        return False
    return q in n or n in q or all(w in n.split() for w in q.split())


async def search_and_add(query: str, per_type: int | None = None):
    """Look the query up on Cinemeta and add the best matches. Returns new item keys."""
    per_type = per_type or config.SEARCH_RESULTS_PER_TYPE
    added = []
    results = await asyncio.gather(clients.cinemeta_search(query, "movie"),
                                   clients.cinemeta_search(query, "series"))
    for stype, metas in zip(("movie", "series"), results):
        picks = [m for m in metas if m.get("id", "").startswith("tt") and _relevant(query, m.get("name", ""))]
        for m in picks[:per_type]:
            try:
                key, new = await add_stremio(m["id"], stype, "search")
                if new:
                    added.append(key)
            except Exception as e:  # noqa: BLE001
                log.warning("could not add %s: %s", m.get("id"), e)
    return added


# --- AIOStreams catalog sync -------------------------------------------------------

def _catalog_wanted(cat: dict) -> bool:
    if cat.get("type") not in ("movie", "series"):
        return False
    if config.AIOSTREAMS_CATALOGS and cat.get("id") not in config.AIOSTREAMS_CATALOGS:
        return False
    for ex in cat.get("extra") or []:
        if ex.get("isRequired"):
            return False
    return True


async def sync_catalogs() -> dict:
    if not config.AIOSTREAMS_MANIFEST_URL:
        return {"skipped": "AIOSTREAMS_MANIFEST_URL not set"}
    started = time.time()
    manifest = await clients.aio_manifest()
    stats = {"catalogs": 0, "added": 0, "removed": 0}
    for cat in manifest.get("catalogs") or []:
        if not _catalog_wanted(cat):
            continue
        source = f"catalog:{cat['type']}:{cat['id']}"
        seen, skip = 0, 0
        try:
            while seen < config.CATALOG_LIMIT:
                metas = await clients.aio_catalog(cat["type"], cat["id"], skip)
                if not metas:
                    break
                for m in metas[: config.CATALOG_LIMIT - seen]:
                    try:
                        _, new = await add_stremio(m.get("id", ""), cat["type"], source)
                        stats["added"] += int(new)
                    except Exception as e:  # noqa: BLE001
                        log.debug("skip %s: %s", m.get("id"), e)
                seen += len(metas)
                skip += len(metas)
        except Exception as e:  # noqa: BLE001
            log.warning("catalog %s failed, keeping its titles this round: %s", source, e)
            continue
        stats["catalogs"] += 1
        for key in db.prune_source(source, started):
            remove(key)
            stats["removed"] += 1
    log.info("catalog sync done: %s", stats)
    return stats


async def refresh_continuing_shows():
    for item in db.all_items("show"):
        if item.get("status") in ("Ended", "Canceled"):
            continue
        try:
            if await refresh_show(item["key"]):
                scans.add(naming.item_rel_path(db.get_item(item["key"])))
        except Exception as e:  # noqa: BLE001
            log.warning("refresh %s failed: %s", item["key"], e)


async def scheduler():
    while True:
        try:
            await sync_catalogs()
            await refresh_continuing_shows()
        except Exception as e:  # noqa: BLE001
            log.exception("scheduled sync failed: %s", e)
        await asyncio.sleep(max(1, config.SYNC_INTERVAL_HOURS) * 3600)


async def ensure_libraries():
    """Create the Movies / TV Shows libraries once Plex is claimed."""
    if not config.AUTO_CREATE_LIBRARIES:
        return
    for _ in range(120):
        if clients.plex_token():
            break
        await asyncio.sleep(30)
    else:
        return
    wanted = [
        ("Movies", "movie", config.PLEX_MOVIE_AGENT, "Plex Movie", f"{config.MOUNT_POINT}/movies"),
        ("TV Shows", "show", config.PLEX_TV_AGENT, "Plex TV Series", f"{config.MOUNT_POINT}/tv"),
    ]
    for attempt in range(20):
        try:
            for name, kind, agent, scanner, loc in wanted:
                if not await plex.section_for(loc):
                    await plex.create_section(name, kind, agent, scanner, loc)
                    log.info("created Plex library %s -> %s (agent %s)", name, loc, agent)
            return
        except Exception as e:  # noqa: BLE001
            log.warning("library setup attempt %d failed: %s", attempt + 1, e)
            await asyncio.sleep(30)
