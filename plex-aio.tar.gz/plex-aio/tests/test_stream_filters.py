import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))

from aiobridge import config, vfs  # noqa: E402


def st(name, langs=None, url="http://x/1"):
    s = {"name": name, "url": url, "behaviorHints": {"filename": name + ".mkv"}}
    if langs is not None:
        s["streamData"] = {"parsedFile": {"languages": langs}}
    return s


def test_list_coercion():
    assert config._coerce("CAM,  TS\nHDTS,,", "list") == "CAM, TS, HDTS"
    assert config._coerce(["a", " b "], "list") == "a, b"


def test_exclude_whole_word_and_regex(monkeypatch):
    monkeypatch.setattr(config, "STREAM_EXCLUDE", "TS, /\\bDV\\b/")
    monkeypatch.setattr(config, "STREAM_REQUIRED_LANGUAGES", "")
    streams = [st("Movie.2024.HDTS"), st("Movie.2024.TS.x264"), st("Movie.2024.DV.2160p"), st("Movie.2024.DTS.1080p")]
    kept = [s["name"] for s in vfs.filter_streams(streams)]
    assert kept == ["Movie.2024.HDTS", "Movie.2024.DTS.1080p"]


def test_required_language(monkeypatch):
    monkeypatch.setattr(config, "STREAM_EXCLUDE", "")
    monkeypatch.setattr(config, "STREAM_REQUIRED_LANGUAGES", "en")
    monkeypatch.setattr(config, "STREAM_LANGUAGE_FALLBACK", False)
    a, b, c = st("A", ["French"]), st("B", ["English", "Spanish"]), st("C.ENGLISH.1080p")
    assert vfs.filter_streams([a, b, c]) == [b, c]
    assert vfs.filter_streams([a]) == []
    monkeypatch.setattr(config, "STREAM_LANGUAGE_FALLBACK", True)
    assert vfs.filter_streams([a]) == [a]


def test_pick_stream_respects_filters(monkeypatch):
    monkeypatch.setattr(config, "STREAM_EXCLUDE", "CAM")
    monkeypatch.setattr(config, "STREAM_REQUIRED_LANGUAGES", "")
    cam, good = st("X.CAM.1080p", url="http://cam"), st("X.WEB.1080p", url="http://good")
    assert vfs.pick_stream([cam, good], uhd=False)["url"] == "http://good"
    assert vfs.pick_stream([cam], uhd=False) is None


def test_external_plex(monkeypatch):
    monkeypatch.setattr(config, "PLEX_BUILTIN", False)
    monkeypatch.setattr(config, "PLEX_EXTERNAL_URL", "http://10.0.0.5:32400/")
    monkeypatch.setattr(config, "PLEX_EXTERNAL_TOKEN", "tok")
    config._apply_derived()
    from aiobridge import clients
    assert config.PLEX_URL == "http://10.0.0.5:32400" and clients.plex_token() == "tok"
    monkeypatch.setattr(config, "PLEX_BUILTIN", True)
    config._apply_derived()
    assert config.PLEX_URL == config.PLEX_INTERNAL_URL
