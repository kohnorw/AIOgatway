import asyncio, os, sys
_real_sleep = asyncio.sleep
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))
from test_core import tmp_cfg, _seed  # noqa: F401,E402


def test_prepare_analyzes_until_real_size(monkeypatch):
    from aiobridge import playback, config, db
    _seed()
    path = f"{config.MOUNT_POINT}/movies/The Matrix (1999) {{tmdb-603}}/The Matrix (1999) {{tmdb-603}}.mkv"
    state = {"size": 5_000_000, "analyzed": 0}

    async def req(method, p, **kw):
        if method == "PUT" and p.endswith("/analyze"):
            state["analyzed"] += 1; state["size"] = 9_000_000_000; return ""
        return {"MediaContainer": {"Metadata": [{"Media": [{"Part": [{"file": path, "size": state["size"]}]}]}]}}

    async def resolve(node):
        db.save_stream(node.stream_key, "https://cdn/x", 9_000_000_000, "x.mkv"); return 9_000_000_000

    monkeypatch.setattr(playback.plex, "req", req)
    monkeypatch.setattr(playback, "resolve", resolve)
    monkeypatch.setattr(playback.asyncio, "sleep", lambda s: _real_sleep(0))
    playback._ready.clear()
    asyncio.run(playback.prepare("42"))
    assert state["analyzed"] == 1
    assert db.get_stream("movie/tt0133093")["activated"] == 1
    asyncio.run(playback.prepare("42"))          # cached: no second analyze
    assert state["analyzed"] == 1


def test_rating_key_parsing():
    from aiobridge import playback
    assert playback.rating_key_from({"path": "/library/metadata/123"}) == "123"
    assert playback.rating_key_from({"uri": "server://abc/com.plexapp.plugins.library/library/metadata/77"}) == "77"
    assert playback.rating_key_from({"uri": "server%3A%2F%2Fx%2Flibrary%2Fmetadata%2F9"}) == "9"
    assert playback.rating_key_from({}) is None


def test_heal_finds_item_by_file_and_analyzes(monkeypatch):
    from aiobridge import playback, config, db
    _seed()
    rel = "movies/The Matrix (1999) {tmdb-603}/The Matrix (1999) {tmdb-603}.mkv"
    path = f"{config.MOUNT_POINT}/{rel}"
    db.save_stream("movie/tt0133093", "https://cdn/x", 9_000_000_000, "x.mkv")
    state = {"size": 50 * 1024 ** 3, "analyzed": 0, "calls": []}

    async def req(method, p, **kw):
        state["calls"].append((method, p, kw.get("title")))
        if p == "/library/sections":
            return {"MediaContainer": {"Directory": [{"key": "1", "Location": [{"path": f"{config.MOUNT_POINT}/movies"}]}]}}
        if method == "PUT" and p.endswith("/refresh"):
            return ""
        if method == "PUT":
            state["analyzed"] += 1; state["size"] = 9_000_000_000; return ""
        md = [{"ratingKey": "42", "Media": [{"Part": [{"file": path, "size": state["size"]}]}]}]
        return {"MediaContainer": {"Metadata": md}}

    monkeypatch.setattr(playback.plex, "req", req)
    monkeypatch.setattr(playback.asyncio, "sleep", lambda s: _real_sleep(0))
    playback._ready.clear(); playback._healed.clear()
    asyncio.run(playback.heal(rel))
    assert state["analyzed"] == 1              # size-fix analyze covers this playback
    assert ("PUT", "/library/metadata/42/refresh", None) in state["calls"]
    assert ("GET", "/library/sections/1/all", "The Matrix") in state["calls"]
    asyncio.run(playback.heal(rel))            # debounced
    assert state["analyzed"] == 1
    playback._healed.clear()
    asyncio.run(playback.heal(rel))            # next playback: size already right -> plain analyze
    assert state["analyzed"] == 2
