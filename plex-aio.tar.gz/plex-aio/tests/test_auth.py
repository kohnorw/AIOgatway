import asyncio, os, sys, json
import pytest
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))
from test_core import tmp_cfg  # noqa: F401,E402

UA = "pytest-browser"


def _app():
    from aiobridge import admin_api, requests_ui, provider
    app = web.Application(middlewares=[admin_api.access])
    admin_api.routes(app); requests_ui.routes(app); provider.routes(app)
    return app


def test_roles_first_admin_and_last_admin_protection():
    from aiobridge import auth
    a = auth._upsert("1", "owner", "", "", "tokA")
    b = auth._upsert("2", "friend", "", "", "tokB")
    assert a["role"] == "admin" and b["role"] == "user"
    with pytest.raises(ValueError):
        auth.set_role("1", "user")                 # last admin
    with pytest.raises(ValueError):
        auth.delete_user("1")
    assert all("plex_token" not in u for u in auth.list_users())
    s = auth.create_session("2", UA, "1.2.3.4")
    assert auth.validate_session(s, UA)["username"] == "friend"
    assert auth.validate_session(s, "other-browser") is None     # UA mismatch destroys it
    assert auth.validate_session(s, UA) is None
    s = auth.create_session("2", UA, "1.2.3.4")
    auth.set_role("2", "admin")                                   # role change signs them out
    assert auth.validate_session(s, UA) is None


def test_access_control():
    from aiobridge import auth
    auth._upsert("1", "owner", "", "", "tokA"); auth._upsert("2", "friend", "", "", "tokB")
    admin = auth.create_session("1", UA, "x"); user = auth.create_session("2", UA, "x")
    async def go():
        async with TestClient(TestServer(_app())) as c:
            h = {"User-Agent": UA}
            assert (await c.get("/", headers=h)).status == 200
            assert (await c.get("/api/auth/me", headers=h)).status == 200
            assert (await c.get("/movie", headers=h)).status == 200          # Plex provider stays open
            assert (await c.get("/api/status?ids=tt1", headers=h)).status == 401
            assert (await c.get("/api/settings", headers=h)).status == 401
            c.session.cookie_jar.update_cookies({auth.COOKIE: user})
            assert (await c.get("/api/status?ids=tt1", headers=h)).status == 200
            assert (await c.get("/api/library", headers=h)).status == 403
            assert (await c.get("/api/settings", headers=h)).status == 403
            assert (await c.get("/api/users", headers=h)).status == 403
            assert (await c.delete("/api/items/movie:1", headers=h)).status == 403
            c.session.cookie_jar.update_cookies({auth.COOKIE: admin})
            assert (await c.get("/api/library", headers=h)).status == 200
            r = await c.get("/api/users", headers=h); d = await r.json()
            assert {u["username"] for u in d["users"]} == {"owner", "friend"}
            assert all("plex_token" not in u for u in d["users"])
            assert (await c.get("/internal/activated", headers=h)).status in (403, 404, 405)
    asyncio.run(go())


def test_settings_roundtrip(tmp_cfg, monkeypatch):
    from aiobridge import auth, config
    monkeypatch.setattr(config, "SETTINGS_PATH", str(tmp_cfg / "settings.json"))
    monkeypatch.setattr(config, "CONFIG_DIR", str(tmp_cfg))
    for k in config.SPEC:                       # restore every setting after the test
        monkeypatch.setattr(config, k, getattr(config, k))
    auth._upsert("1", "owner", "", "", "tokA"); admin = auth.create_session("1", UA, "x")
    async def go():
        async with TestClient(TestServer(_app())) as c:
            h = {"User-Agent": UA}; c.session.cookie_jar.update_cookies({auth.COOKIE: admin})
            d = await (await c.get("/api/settings", headers=h)).json()
            keys = {s["key"]: s for s in d["settings"]}
            assert keys["TMDB_API_KEY"]["secret"] and keys["TMDB_API_KEY"]["value"] == ""
            assert {s["tab"] for s in d["settings"]} == {"connections", "users", "library", "streams", "streamsel", "plex"}
            r = await c.post("/api/settings", headers=h, json={"settings": {"MIN_4K_CANDIDATES": "3", "CHECK_4K": False,
                                                                          "TMDB_API_KEY": "abcdefghijklmnopqrstuvwxyz", "FUSE_BLOCK_MB": 4}})
            body = await r.json()
            assert r.status == 200 and body["restart_required"] == ["FUSE_BLOCK_MB"]
            assert config.MIN_4K_CANDIDATES == 3 and config.CHECK_4K is False
            assert config.TMDB_API_KEY == "abcdefghijklmnopqrstuvwxyz"
            k = {s["key"]: s for s in body["settings"]}["TMDB_API_KEY"]
            assert k["value"] == "" and k["is_set"] and "…" in k["preview"]      # never sent back
            await c.post("/api/settings", headers=h, json={"settings": {"TMDB_API_KEY": ""}})
            assert config.TMDB_API_KEY == "abcdefghijklmnopqrstuvwxyz"           # blank keeps it
            saved = json.load(open(config.SETTINGS_PATH))
            assert saved["MIN_4K_CANDIDATES"] == 3
            r = await c.post("/api/settings", headers=h, json={"settings": {"MIN_4K_CANDIDATES": "-1"}})
            assert r.status == 400
    asyncio.run(go())
