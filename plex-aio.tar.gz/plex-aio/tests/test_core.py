import asyncio
import os
import sys
import xml.etree.ElementTree as ET

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))


@pytest.fixture(autouse=True)
def tmp_cfg(tmp_path, monkeypatch):
    from aiobridge import config, db
    monkeypatch.setattr(config, "CONFIG_DIR", str(tmp_path))
    monkeypatch.setattr(config, "DB_PATH", str(tmp_path / "aio.db"))
    monkeypatch.setattr(config, "PLACEHOLDER_DIR", str(tmp_path / "ph"))
    db.init()
    yield tmp_path


# --- naming ---------------------------------------------------------------------

def test_naming_roundtrip():
    from aiobridge import naming
    it = {"kind": "movie", "tmdb": 693134, "title": "Dune: Part Two", "year": 2024}
    assert naming.folder(it) == "Dune  Part Two (2024) {tmdb-693134}".replace("  ", " ")
    assert naming.tmdb_from_name(naming.movie_file(it)) == 693134
    show = {"kind": "show", "tmdb": 1399, "title": "Game of Thrones", "year": 2011}
    f = naming.episode_file(show, 1, 9)
    assert f == "Game of Thrones (2011) - S01E09.mkv"
    assert naming.parse_episode_file(f) == (1, 9)
    assert naming.parse_season_dir("Season 03") == 3
    assert naming.norm_title("The Matrix") == naming.norm_title("matrix")
    assert naming.stream_key_episode({"tmdb": 1, "imdb": "tt1"}, 2, 3) == "series/tt1:2:3"
    assert naming.stream_key_movie({"tmdb": 5, "imdb": None}) == "movie/tmdb:5"


# --- vfs ------------------------------------------------------------------------------

def _seed():
    from aiobridge import db
    db.upsert_item("movie:603", "movie", 603, "tt0133093", "The Matrix", 1999, 136, "Released")
    db.upsert_item("show:1399", "show", 1399, "tt0944947", "Game of Thrones", 2011, 60, "Ended")
    db.replace_episodes("show:1399", [(1, 1, "Winter Is Coming", 62, "2011-04-17"),
                                       (1, 2, "The Kingsroad", 56, "2011-04-24"),
                                       (9, 1, "Future", 60, "2999-01-01")])


def test_tree_layout():
    from aiobridge import vfs
    _seed()
    root = vfs.build_tree(today="2026-10-12")
    assert sorted(root.children) == ["movies", "tv"]
    m = root.children["movies"].children["The Matrix (1999) {tmdb-603}"]
    assert list(m.children) == ["The Matrix (1999) {tmdb-603}.mkv"]
    show = root.children["tv"].children["Game of Thrones (2011) {tmdb-1399}"]
    assert list(show.children) == ["Season 01"]          # unaired season 9 hidden
    eps = show.children["Season 01"].children
    node = eps["Game of Thrones (2011) - S01E02.mkv"]
    assert node.stream_key == "series/tt0944947:1:2"
    assert node.runtime == 56


def test_caller_policy():
    from aiobridge import vfs
    comms = {10: "Plex Media Scan", 11: "Plex Transcoder", 12: "Plex Media Serv", 13: "bash"}
    parents = {10: 1, 11: 12, 12: 1, 13: 1, 20: 10}
    comms[20] = "Plex Transcoder"            # transcoder spawned by the scanner
    threads = {30: 12}                        # worker thread 30 of Plex Media Server (pid 12)
    comms[30] = "PMS Worker"
    cls = lambda pid: vfs.caller_class(pid, comms.get, lambda p: parents.get(p, 0),  # noqa: E731
                                       lambda p: threads.get(p, p))
    assert cls(10) == "scanner"
    assert cls(11) == "player"
    assert cls(12) == "player"
    assert cls(13) == "other"
    assert cls(20) == "scanner"
    assert cls(30) == "player"                # named thread still counts as Plex Media Server


def test_pick_stream_prefers_same_file():
    from aiobridge import vfs
    streams = [{"name": "magnet only"},
               {"url": "https://a/1.mkv", "behaviorHints": {"filename": "A.mkv"}},
               {"url": "https://a/2.mkv", "behaviorHints": {"filename": "B.mkv"}}]
    assert vfs.pick_stream(streams)["url"] == "https://a/1.mkv"
    assert vfs.pick_stream(streams, "B.mkv")["url"] == "https://a/2.mkv"
    assert vfs.pick_stream([{"externalUrl": "x"}]) is None


def test_placeholder_bucket():
    from aiobridge import placeholder
    assert placeholder.bucket(136) == 140
    assert placeholder.bucket(None) == 45
    assert placeholder.bucket(1) == 5


# --- prefs ------------------------------------------------------------------------------

def test_prefs_apply(tmp_path):
    from aiobridge import prefs
    p = tmp_path / "Preferences.xml"
    p.write_text('<?xml version="1.0"?><Preferences PlexOnlineToken="abc" GenerateBIFBehavior="asap"/>')
    ch = prefs.apply(str(p), advertise="http://1.2.3.4:32400")
    root = ET.parse(p).getroot()
    assert root.get("PlexOnlineToken") == "abc"
    assert root.get("GenerateBIFBehavior") == "never"
    assert root.get("FSEventLibraryUpdatesEnabled") == "0"
    assert root.get("customConnections") == "http://1.2.3.4:32400"
    assert "GenerateBIFBehavior" in ch
    assert prefs.apply(str(p), advertise="http://1.2.3.4:32400") == {}       # idempotent


# --- provider + library (TMDB mocked) ----------------------------------------------------

MATRIX = {"id": 603, "title": "The Matrix", "release_date": "1999-03-30", "runtime": 136, "imdb_id": "tt0133093",
          "overview": "Neo.", "genres": [{"name": "Action"}], "poster_path": "/p.jpg", "backdrop_path": "/b.jpg",
          "vote_average": 8.2, "credits": {"cast": [{"name": "Keanu Reeves", "character": "Neo"}],
                                           "crew": [{"name": "Lana Wachowski", "job": "Director"}]},
          "release_dates": {"results": [{"iso_3166_1": "US", "release_dates": [{"certification": "R"}]}]},
          "status": "Released"}


@pytest.fixture
def fake_tmdb(monkeypatch):
    from aiobridge import clients, library, placeholder

    async def movie(tid, language=None):
        if tid != 603:
            raise KeyError(tid)
        return MATRIX

    async def find_imdb(imdb):
        return {"movie_results": [{"id": 603}]} if imdb == "tt0133093" else {}

    async def search(kind, q, year=None, language=None):
        return [{"id": 603}] if "matrix" in q.lower() else []

    async def ensure(m):
        return placeholder.path_for(m)

    monkeypatch.setattr(clients.tmdb, "movie", movie)
    monkeypatch.setattr(clients.tmdb, "find_imdb", find_imdb)
    monkeypatch.setattr(clients.tmdb, "search", search)
    monkeypatch.setattr(placeholder, "ensure", ensure)
    library.scans.paths.clear()


def test_movie_meta_shape(fake_tmdb):
    from aiobridge import config, provider
    meta = provider.movie_meta(MATRIX)
    assert meta["ratingKey"] == "m603"
    assert meta["guid"] == f"{config.MOVIE_PROVIDER_ID}://movie/m603"
    assert meta["contentRating"] == "R"
    assert {"id": "imdb://tt0133093"} in meta["Guid"]
    assert meta["duration"] == 136 * 60000
    assert meta["Role"][0]["tag"] == "Keanu Reeves"
    assert config.MOVIE_PROVIDER_ID.startswith("tv.plex.agents.custom.")


def test_match_uses_library_and_ids(fake_tmdb):
    from aiobridge import db, provider
    db.upsert_item("movie:603", "movie", 603, "tt0133093", "The Matrix", 1999, 136, "Released")
    run = asyncio.run
    assert run(provider.movie_match({"type": 1, "title": "The Matrix", "year": 1999}, "en-US"))[0]["ratingKey"] == "m603"
    assert run(provider.movie_match({"type": 1, "guid": "imdb://tt0133093"}, "en-US"))[0]["ratingKey"] == "m603"
    assert run(provider.movie_match({"type": 1, "title": "The Matrix (1999) {tmdb-603}"}, "en-US"))[0]["ratingKey"] == "m603"


def test_add_and_search(fake_tmdb, monkeypatch):
    from aiobridge import clients, db, library

    async def cm(q, kind):
        return [{"id": "tt0133093", "name": "The Matrix"}, {"id": "tt9", "name": "Unrelated Thing"}] if kind == "movie" else []

    monkeypatch.setattr(clients, "cinemeta_search", cm)
    added = asyncio.run(library.search_and_add("matrix"))
    assert added == ["movie:603"]
    assert db.get_item("movie:603")["imdb"] == "tt0133093"
    assert any("The Matrix (1999) {tmdb-603}" in p for p in library.scans.paths)
    assert asyncio.run(library.search_and_add("matrix")) == []      # already there


def test_catalog_filter(monkeypatch):
    from aiobridge import config, library
    assert library._catalog_wanted({"type": "movie", "id": "x"})
    assert not library._catalog_wanted({"type": "movie", "id": "x", "extra": [{"name": "search", "isRequired": True}]})
    assert not library._catalog_wanted({"type": "tv", "id": "x"})
    monkeypatch.setattr(config, "AIOSTREAMS_CATALOGS", ["y"])
    assert not library._catalog_wanted({"type": "movie", "id": "x"})


def test_addon_base():
    from aiobridge.clients import addon_base
    assert addon_base("https://h/stremio/u/e/manifest.json") == "https://h/stremio/u/e"
    assert addon_base("stremio://h/x/manifest.json") == "https://h/x"
