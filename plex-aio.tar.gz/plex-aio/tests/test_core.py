import asyncio
import os
import sys
import xml.etree.ElementTree as ET

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))


@pytest.fixture(autouse=True)
def tmp_cfg(tmp_path, monkeypatch):
    from aiobridge import config, db
    monkeypatch.setattr(config, "CONFIG_DIR", str(tmp_path))
    monkeypatch.setattr(config, "DB_PATH", str(tmp_path / "aio.db"))
    monkeypatch.setattr(config, "PLACEHOLDER_DIR", str(tmp_path / "ph"))
    db.init()
    yield tmp_path


# --- naming ---------------------------------------------------------------------

def test_naming_roundtrip():
    from aiobridge import naming
    it = {"kind": "movie", "tmdb": 693134, "title": "Dune: Part Two", "year": 2024}
    assert naming.folder(it) == "Dune  Part Two (2024) {tmdb-693134}".replace("  ", " ")
    assert naming.tmdb_from_name(naming.movie_file(it)) == 693134
    show = {"kind": "show", "tmdb": 1399, "title": "Game of Thrones", "year": 2011}
    f = naming.episode_file(show, 1, 9)
    assert f == "Game of Thrones (2011) - S01E09.mkv"
    assert naming.parse_episode_file(f) == (1, 9)
    assert naming.parse_season_dir("Season 03") == 3
    assert naming.norm_title("The Matrix") == naming.norm_title("matrix")
    assert naming.stream_key_episode({"tmdb": 1, "imdb": "tt1"}, 2, 3) == "series/tt1:2:3"
    assert naming.stream_key_movie({"tmdb": 5, "imdb": None}) == "movie/tmdb:5"


# --- vfs ------------------------------------------------------------------------------

def _seed():
    from aiobridge import db
    db.upsert_item("movie:603", "movie", 603, "tt0133093", "The Matrix", 1999, 136, "Released")
    db.upsert_item("show:1399", "show", 1399, "tt0944947", "Game of Thrones", 2011, 60, "Ended")
    db.replace_episodes("show:1399", [(1, 1, "Winter Is Coming", 62, "2011-04-17"),
                                       (1, 2, "The Kingsroad", 56, "2011-04-24"),
                                       (9, 1, "Future", 60, "2999-01-01")])


def test_tree_layout():
    from aiobridge import vfs
    _seed()
    root = vfs.build_tree(today="2026-10-12")
    assert sorted(root.children) == ["movies", "movies4k", "tv", "tv4k"]
    assert not root.children["movies4k"].children            # no 4K yet
    m = root.children["movies"].children["The Matrix (1999) {tmdb-603}"]
    assert list(m.children) == ["The Matrix (1999) {tmdb-603}.mkv"]
    show = root.children["tv"].children["Game of Thrones (2011) {tmdb-1399}"]
    assert list(show.children) == ["Season 01"]          # unaired season 9 hidden
    eps = show.children["Season 01"].children
    node = eps["Game of Thrones (2011) - S01E02.mkv"]
    assert node.stream_key == "series/tt0944947:1:2"
    assert node.runtime == 56


def test_caller_policy():
    from aiobridge import vfs
    comms = {10: "Plex Media Scan", 11: "Plex Transcoder", 12: "Plex Media Serv", 13: "bash"}
    parents = {10: 1, 11: 12, 12: 1, 13: 1, 20: 10}
    comms[20] = "Plex Transcoder"            # transcoder spawned by the scanner
    threads = {30: 12}                        # worker thread 30 of Plex Media Server (pid 12)
    comms[30] = "PMS Worker"
    cls = lambda pid: vfs.caller_class(pid, comms.get, lambda p: parents.get(p, 0),  # noqa: E731
                                       lambda p: threads.get(p, p))
    assert cls(10) == "scanner"
    assert cls(11) == "player"
    assert cls(12) == "player"
    assert cls(13) == "other"
    assert cls(20) == "scanner"
    assert cls(30) == "player"                # named thread still counts as Plex Media Server


def test_pick_stream_prefers_same_file():
    from aiobridge import vfs
    streams = [{"name": "magnet only"},
               {"url": "https://a/1.mkv", "behaviorHints": {"filename": "A.mkv"}},
               {"url": "https://a/2.mkv", "behaviorHints": {"filename": "B.mkv"}}]
    assert vfs.pick_stream(streams)["url"] == "https://a/1.mkv"
    assert vfs.pick_stream(streams, "B.mkv")["url"] == "https://a/2.mkv"
    assert vfs.pick_stream([{"externalUrl": "x"}]) is None


def test_placeholder_single_shared_file():
    from aiobridge import placeholder
    assert placeholder.path_for(136) == placeholder.path_for(22) == placeholder.path_for()


# --- prefs ------------------------------------------------------------------------------

def test_prefs_apply(tmp_path):
    from aiobridge import prefs
    p = tmp_path / "Preferences.xml"
    p.write_text('<?xml version="1.0"?><Preferences PlexOnlineToken="abc" GenerateBIFBehavior="asap"/>')
    ch = prefs.apply(str(p), advertise="http://1.2.3.4:32400")
    root = ET.parse(p).getroot()
    assert root.get("PlexOnlineToken") == "abc"
    assert root.get("GenerateBIFBehavior") == "never"
    assert root.get("FSEventLibraryUpdatesEnabled") == "0"
    assert root.get("customConnections") == "http://1.2.3.4:32400"
    assert "GenerateBIFBehavior" in ch
    assert prefs.apply(str(p), advertise="http://1.2.3.4:32400") == {}       # idempotent


# --- provider + library (TMDB mocked) ----------------------------------------------------

MATRIX = {"id": 603, "title": "The Matrix", "release_date": "1999-03-30", "runtime": 136, "imdb_id": "tt0133093",
          "overview": "Neo.", "genres": [{"name": "Action"}], "poster_path": "/p.jpg", "backdrop_path": "/b.jpg",
          "vote_average": 8.2, "credits": {"cast": [{"name": "Keanu Reeves", "character": "Neo"}],
                                           "crew": [{"name": "Lana Wachowski", "job": "Director"}]},
          "release_dates": {"results": [{"iso_3166_1": "US", "release_dates": [{"certification": "R"}]}]},
          "status": "Released"}


@pytest.fixture
def fake_tmdb(monkeypatch):
    from aiobridge import clients, library, placeholder

    async def movie(tid, language=None):
        if tid != 603:
            raise KeyError(tid)
        return MATRIX

    async def find_imdb(imdb):
        return {"movie_results": [{"id": 603}]} if imdb == "tt0133093" else {}

    async def search(kind, q, year=None, language=None):
        return [{"id": 603}] if "matrix" in q.lower() else []

    async def ensure(m=None):
        return placeholder.path_for(m)

    monkeypatch.setattr(clients.tmdb, "movie", movie)
    monkeypatch.setattr(clients.tmdb, "find_imdb", find_imdb)
    monkeypatch.setattr(clients.tmdb, "search", search)
    monkeypatch.setattr(placeholder, "ensure", ensure)
    library.scans.paths.clear()


def test_movie_meta_shape(fake_tmdb):
    from aiobridge import config, provider
    meta = provider.movie_meta(MATRIX)
    assert meta["ratingKey"] == "m603"
    assert meta["guid"] == f"{config.MOVIE_PROVIDER_ID}://movie/m603"
    assert meta["contentRating"] == "R"
    assert {"id": "imdb://tt0133093"} in meta["Guid"]
    assert meta["duration"] == 136 * 60000
    assert meta["Role"][0]["tag"] == "Keanu Reeves"
    assert config.MOVIE_PROVIDER_ID.startswith("tv.plex.agents.custom.")


def test_match_uses_library_and_ids(fake_tmdb):
    from aiobridge import db, provider
    db.upsert_item("movie:603", "movie", 603, "tt0133093", "The Matrix", 1999, 136, "Released")
    run = asyncio.run
    assert run(provider.movie_match({"type": 1, "title": "The Matrix", "year": 1999}, "en-US"))[0]["ratingKey"] == "m603"
    assert run(provider.movie_match({"type": 1, "guid": "imdb://tt0133093"}, "en-US"))[0]["ratingKey"] == "m603"
    assert run(provider.movie_match({"type": 1, "title": "The Matrix (1999) {tmdb-603}"}, "en-US"))[0]["ratingKey"] == "m603"


def test_add_and_search(fake_tmdb, monkeypatch):
    from aiobridge import clients, db, library

    async def cm(q, kind):
        return [{"id": "tt0133093", "name": "The Matrix"}, {"id": "tt9", "name": "Unrelated Thing"}] if kind == "movie" else []

    monkeypatch.setattr(clients, "cinemeta_search", cm)
    added = asyncio.run(library.search_and_add("matrix"))
    assert added == ["movie:603"]
    assert db.get_item("movie:603")["imdb"] == "tt0133093"
    assert any("The Matrix (1999) {tmdb-603}" in p for p in library.scans.paths)
    assert asyncio.run(library.search_and_add("matrix")) == []      # already there


def test_addon_base():
    from aiobridge.clients import addon_base
    assert addon_base("https://h/stremio/u/e/manifest.json") == "https://h/stremio/u/e"
    assert addon_base("stremio://h/x/manifest.json") == "https://h/x"


def test_4k_tree_and_stream_keys():
    from aiobridge import db, vfs, naming
    _seed()
    db.set_has_4k("movie:603", True)
    db.set_season_4k("show:1399", 1, True)
    root = vfs.build_tree(today="2026-10-12")
    m4 = root.children["movies4k"].children["The Matrix (1999) {tmdb-603}"].children["The Matrix (1999) {tmdb-603}.mkv"]
    assert m4.uhd and m4.stream_key == "movie/tt0133093|4k" and m4.item_rel.startswith("movies4k/")
    hd = root.children["movies"].children["The Matrix (1999) {tmdb-603}"].children["The Matrix (1999) {tmdb-603}.mkv"]
    assert not hd.uhd and hd.stream_key == "movie/tt0133093"
    ep = root.children["tv4k"].children["Game of Thrones (2011) {tmdb-1399}"].children["Season 01"] \
        .children["Game of Thrones (2011) - S01E01.mkv"]
    assert ep.stream_key == "series/tt0944947:1:1|4k"
    assert naming.split_stream_key(ep.stream_key) == ("series", "tt0944947:1:1", True)
    db.set_season_4k("show:1399", 1, False)
    assert "Game of Thrones (2011) {tmdb-1399}" not in vfs.build_tree(today="2026-10-12").children["tv4k"].children


def test_pick_stream_by_quality():
    from aiobridge import vfs
    streams = [{"url": "https://a/uhd.mkv", "name": "AIO 4K", "behaviorHints": {"filename": "X.2160p.mkv"}},
               {"url": "https://a/hd.mkv", "name": "AIO 1080p", "behaviorHints": {"filename": "X.1080p.mkv"}}]
    assert vfs.pick_stream(streams, uhd=True)["url"] == "https://a/uhd.mkv"
    assert vfs.pick_stream(streams, uhd=False)["url"] == "https://a/hd.mkv"
    assert vfs.pick_stream(streams)["url"] == "https://a/uhd.mkv"
    assert vfs.is_4k({"description": "UHD Remux"}) and not vfs.is_4k({"name": "720p"})


def test_check_4k_movie(fake_tmdb, monkeypatch):
    from aiobridge import db, library, config
    db.upsert_item("movie:603", "movie", 603, "tt0133093", "The Matrix", 1999, 136, "Released")
    async def two(stype, sid):
        assert (stype, sid) == ("movie", "tt0133093"); return 2
    async def one(stype, sid):
        return 1
    monkeypatch.setattr(library, "count_4k", two)
    assert asyncio.run(library.check_4k_movie("movie:603")) is True
    assert db.get_item("movie:603")["has_4k"] == 1
    monkeypatch.setattr(library, "count_4k", one)
    assert asyncio.run(library.check_4k_movie("movie:603")) is False   # below MIN_4K_CANDIDATES
    assert db.get_item("movie:603")["has_4k"] == 0
    monkeypatch.setattr(config, "CHECK_4K", False)
    assert asyncio.run(library.check_4k_movie("movie:603")) is False


def test_pack_detection():
    from aiobridge import vfs
    assert vfs.pack_type_of_name("Show.S02.1080p.WEB-DL") == ("season", 2)
    assert vfs.pack_type_of_name("Show.Complete.Series.1080p") == ("series", None)
    assert vfs.pack_type_of_name("Show.S01-S05.1080p") == ("series", None)
    assert vfs.pack_type_of_name("Show.S02E05.The.Complete.Story.1080p") == ("episode", None)
    # pack seen through the folder, file inside is an episode
    st = {"url": "https://a", "behaviorHints": {"filename": "Show.S02E05.mkv"},
          "streamData": {"folderName": "Show.S02.1080p.BluRay"}}
    assert vfs.pack_type(st) == ("season", 2)
    assert vfs.pack_type({"streamData": {"parsedFile": {"folderSeasons": [1, 2, 3]}}}) == ("series", None)


def test_pick_prefers_packs_then_remembers(tmp_cfg):
    from aiobridge import config, db, vfs
    ep = {"url": "https://a/ep.mkv", "behaviorHints": {"filename": "Show.S02E05.1080p.mkv"}}
    other_season = {"url": "https://a/s3.mkv", "behaviorHints": {"filename": "x.mkv"}, "streamData": {"folderName": "Show.S03.1080p"}}
    season = {"url": "https://a/s2.mkv", "behaviorHints": {"filename": "y.mkv"}, "streamData": {"folderName": "Show.S02.1080p", "torrent": {"infoHash": "AB"}}}
    series = {"url": "https://a/all.mkv", "behaviorHints": {"filename": "z.mkv"}, "streamData": {"folderName": "Show.Complete.Series"}}
    key = "series/tt1:2:5"
    assert vfs.pick_stream([ep, other_season, season], stream_key=key)["url"] == "https://a/s2.mkv"
    assert vfs.pick_stream([ep, season, series], stream_key=key)["url"] == "https://a/all.mkv"
    assert vfs.pick_stream([ep, season], stream_key="movie/tt1")["url"] == "https://a/ep.mkv"   # movies untouched
    # remembered pack wins for the next episode, even over a series pack
    vfs.remember_pick(key, season)
    nxt = dict(season, url="https://a/s2e6.mkv")
    assert vfs.pick_stream([series, ep, nxt], stream_key="series/tt1:2:6")["url"] == "https://a/s2e6.mkv"
    db.forget_pack_url("https://a/s2.mkv")
    assert vfs.pick_stream([series, ep, nxt], stream_key="series/tt1:2:6")["url"] == "https://a/all.mkv"
    config.PREFER_PACKS = False
    try:
        assert vfs.pick_stream([ep, series], stream_key=key)["url"] == "https://a/ep.mkv"
    finally:
        config.PREFER_PACKS = True
