import asyncio, os, sys
import pytest
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))
from test_core import tmp_cfg, fake_tmdb, MATRIX  # noqa: F401,E402


def test_provider_routes(fake_tmdb):
    from aiobridge import provider, config
    async def go():
        app = web.Application(); provider.routes(app)
        async with TestClient(TestServer(app)) as c:
            r = await c.get("/movie"); d = await r.json()
            assert d["MediaProvider"]["identifier"] == config.MOVIE_PROVIDER_ID
            assert {f["type"] for f in d["MediaProvider"]["Feature"]} == {"metadata", "match"}
            r = await c.post("/movie/library/metadata/matches", json={"type": 1, "title": "The Matrix", "year": 1999})
            assert (await r.json())["MediaContainer"]["Metadata"][0]["title"] == "The Matrix"
            r = await c.get("/movie/library/metadata/m603"); assert r.status == 200
            r = await c.get("/movie/library/metadata/m999"); assert r.status == 404
            r = await c.get("/tv"); d = await r.json()
            assert [t["type"] for t in d["MediaProvider"]["Types"]] == [2, 3, 4]
    asyncio.run(go())


def test_proxy_passthrough_and_search_hook(monkeypatch):
    from aiobridge import proxy, config, library
    calls = []
    async def fake_search(q, per_type=None):
        calls.append(q); return []
    monkeypatch.setattr(library, "search_and_add", fake_search)
    monkeypatch.setattr(config, "SEARCH_DEBOUNCE_MS", 50)
    async def go():
        up = web.Application()
        async def anyp(req):
            body = await req.read()
            return web.json_response({"path": req.path_qs, "method": req.method, "len": len(body),
                                      "xff": req.headers.get("X-Forwarded-For")})
        up.router.add_route("*", "/{t:.*}", anyp)
        async with TestServer(up) as us:
            monkeypatch.setattr(proxy, "_plex_base", f"http://127.0.0.1:{us.port}")
            proxy._done.clear()
            async with TestClient(TestServer(proxy.make_app())) as c:
                r = await c.get("/library/sections?X-Plex-Token=t"); d = await r.json()
                assert d["path"] == "/library/sections?X-Plex-Token=t"
                r = await c.put("/:/prefs", data=b"x" * 1000); assert (await r.json())["len"] == 1000
                # typing "mat" then "matrix" quickly: only the final query hits Cinemeta
                t1 = asyncio.create_task(c.get("/hubs/search?query=mat", headers={"X-Plex-Client-Identifier": "A"}))
                await asyncio.sleep(0.01)
                r2 = await c.get("/hubs/search?query=matrix", headers={"X-Plex-Client-Identifier": "A"})
                await t1
                assert (await r2.json())["path"].startswith("/hubs/search")
                assert calls == ["matrix"]
    asyncio.run(go())
