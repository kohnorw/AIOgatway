import asyncio, datetime, os, sys
import pytest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))
from test_core import tmp_cfg  # noqa: F401,E402

TODAY = datetime.date.today()
D = lambda days: (TODAY + datetime.timedelta(days=days)).isoformat()  # noqa: E731

SHOW = {"id": 500, "name": "Test Show", "first_air_date": "2020-01-01", "episode_run_time": [42], "status": "Returning Series",
        "external_ids": {"imdb_id": "tt500"}, "poster_path": "/p.jpg",
        "seasons": [{"season_number": 1, "episode_count": 2}, {"season_number": 2, "episode_count": 2},
                    {"season_number": 3, "episode_count": 2}]}
SEASONS = {1: [(1, D(-900)), (2, D(-893))], 2: [(1, D(-30)), (2, D(-2))], 3: [(1, D(5)), (2, D(12))]}


@pytest.fixture
def fake(monkeypatch):
    from aiobridge import clients, library, placeholder
    async def show(tid, language=None): return SHOW
    async def season(tid, n, language=None):
        return {"episodes": [{"episode_number": e, "name": f"S{n}E{e}", "air_date": d} for e, d in SEASONS[n]]}
    async def ensure(m=None): return placeholder.path_for()
    async def no4k(stype, sid): return 0
    monkeypatch.setattr(clients.tmdb, "show", show); monkeypatch.setattr(clients.tmdb, "season", season)
    monkeypatch.setattr(placeholder, "ensure", ensure); monkeypatch.setattr(library, "count_4k", no4k)
    queued = []
    monkeypatch.setattr(library.series_scans, "add", lambda rel: queued.append(rel))
    return queued


def _tree_seasons():
    from aiobridge import vfs
    show = vfs.build_tree().children["tv"].children.get("Test Show (2020) {tmdb-500}")
    return {n: sorted(show.children[n].children) for n in sorted(show.children)} if show else {}


def run(coro):
    async def wrap():
        r = await coro
        await asyncio.sleep(0)       # let background 4K checks run
        return r
    return asyncio.run(wrap())


def test_request_all_seasons_and_staggered_scan(fake):
    from aiobridge import library
    key, new = run(library.add_show(500, "request", mode="all"))
    assert new
    t = _tree_seasons()
    assert list(t) == ["Season 01", "Season 02"]          # season 3 not aired yet
    assert fake == ["tv/Test Show (2020) {tmdb-500}/Season 01", "tv/Test Show (2020) {tmdb-500}/Season 02"]
    assert library.wanted_seasons(key) == {1, 2, 3}           # future season tracked


def test_request_specific_seasons_then_add_more(fake):
    from aiobridge import library, db
    key, _ = run(library.add_show(500, "request", mode="seasons", seasons=[2]))
    assert list(_tree_seasons()) == ["Season 02"]
    fake.clear()
    key, changed = run(library.add_show(500, "request", mode="seasons", seasons=[1]))
    assert changed and list(_tree_seasons()) == ["Season 01", "Season 02"]
    assert fake == ["tv/Test Show (2020) {tmdb-500}/Season 01"]   # only the newly added season is scanned
    assert db.requested_seasons(key) == {1, 2}


def test_request_new_episodes_only_then_track_airing(fake, monkeypatch):
    from aiobridge import library, db, naming
    key, _ = run(library.add_show(500, "request", mode="new"))
    assert _tree_seasons() == {}                              # nothing aired since today
    assert library.wanted_seasons(key) == {3}
    # time passes: S3E1 airs
    later = D(6)
    monkeypatch.setattr(naming, "aired", lambda d, today=None: bool(d) and d <= (today or later))
    monkeypatch.setattr(library, "_today", lambda: later)
    assert library._announce_visible(key) == 1
    assert fake[-1] == "tv/Test Show (2020) {tmdb-500}/Season 03"
    assert library._announce_visible(key) == 0                # announced only once
    assert [e["announced"] for e in db.episodes(key) if e["season"] == 3] == [1, 0]


def test_all_mode_wins_over_new(fake):
    from aiobridge import library, db
    key, _ = run(library.add_show(500, "request", mode="all"))
    run(library.add_show(500, "request", mode="new"))
    assert db.get_item(key)["monitor"] == "all"


def test_series_refresher_staggers(monkeypatch):
    from aiobridge import library, config
    calls = []
    async def refresh_path(path):
        calls.append((round(asyncio.get_event_loop().time(), 1), path)); return True
    monkeypatch.setattr(library.plex, "refresh_path", refresh_path)
    monkeypatch.setattr(config, "SERIES_REFRESH_STAGGER_SECONDS", 0.2)
    async def go():
        r = library.SeriesRefresher()
        item = {"kind": "show", "title": "X", "year": 2020, "tmdb": 1}
        r.add_show(item, {2, 1}); r.add_show(item, {1})       # duplicate ignored while pending
        t = asyncio.create_task(r.run()); await asyncio.sleep(0.5); t.cancel()
    asyncio.run(go())
    assert [p.rsplit("/", 1)[1] for _, p in calls] == ["Season 01", "Season 02"]
    assert calls[1][0] - calls[0][0] >= 0.15


def test_new_episode_tracking(fake):
    """Episodes present at request time aren't 'new'; ones that air later are."""
    import time
    from aiobridge import library, db, requests_ui
    key, _ = run(library.add_show(500, "request", mode="all"))
    assert db.new_episode_stats(0) == {}
    item = db.get_item(key)
    st = requests_ui._status(item)
    assert st["tracking"] and not st["ended"] and st["new_episodes"] == 0
    # S03E01 airs: move its air date into the past, then the watcher picks it up
    with db.conn() as c:
        c.execute("UPDATE episodes SET air_date=? WHERE show_key=? AND season=3 AND episode=1", (D(0), key))
    assert library._announce_visible(key, track_new=True) == 1
    n, last = db.new_episode_stats(time.time() - 60)[key]
    assert n == 1 and last
    assert requests_ui._status(db.get_item(key))["new_episodes"] == 1
    # a completed show is never "tracking"
    with db.conn() as c:
        c.execute("UPDATE items SET status='Ended' WHERE key=?", (key,))
    st = requests_ui._status(db.get_item(key))
    assert st["ended"] and not st["tracking"]
