import asyncio, datetime, os, sys
import pytest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))
from test_core import tmp_cfg  # noqa: F401,E402

TODAY = datetime.date.today()
D = lambda days: (TODAY + datetime.timedelta(days=days)).isoformat()  # noqa: E731

SHOW = {"id": 500, "name": "Test Show", "first_air_date": "2020-01-01", "episode_run_time": [42], "status": "Returning Series",
        "external_ids": {"imdb_id": "tt500"}, "poster_path": "/p.jpg",
        "seasons": [{"season_number": 1, "episode_count": 2}, {"season_number": 2, "episode_count": 2},
                    {"season_number": 3, "episode_count": 2}]}
SEASONS = {1: [(1, D(-900)), (2, D(-893))], 2: [(1, D(-30)), (2, D(-2))], 3: [(1, D(5)), (2, D(12))]}


@pytest.fixture
def fake(monkeypatch):
    from aiobridge import clients, library, placeholder
    async def show(tid, language=None): return SHOW
    async def season(tid, n, language=None):
        return {"episodes": [{"episode_number": e, "name": f"S{n}E{e}", "air_date": d} for e, d in SEASONS[n]]}
    async def ensure(m=None): return placeholder.path_for()
    async def no4k(stype, sid): return 0
    monkeypatch.setattr(clients.tmdb, "show", show); monkeypatch.setattr(clients.tmdb, "season", season)
    monkeypatch.setattr(placeholder, "ensure", ensure); monkeypatch.setattr(library, "count_4k", no4k)
    from aiobridge import config
    monkeypatch.setattr(config, "WAIT_LOOKBACK_DAYS", 0)      # back catalogue in these fixtures shows at once
    async def no_cinemeta(key, imdb): return None
    monkeypatch.setattr(library, "_store_air_times", no_cinemeta)
    stream_ok = {"v": True}
    async def has_stream(item, s, e): return stream_ok["v"]
    monkeypatch.setattr(library, "has_stream", has_stream)
    queued = []
    queued_stream_ok = stream_ok
    monkeypatch.setattr(library.series_scans, "add", lambda rel: queued.append(rel))
    library._test_stream_ok = stream_ok
    return queued


def _tree_seasons():
    from aiobridge import vfs
    show = vfs.build_tree().children["tv"].children.get("Test Show (2020) {tmdb-500}")
    return {n: sorted(show.children[n].children) for n in sorted(show.children)} if show else {}


def run(coro):
    async def wrap():
        r = await coro
        await asyncio.sleep(0)       # let background 4K checks run
        return r
    return asyncio.run(wrap())


def test_request_all_seasons_and_staggered_scan(fake):
    from aiobridge import library
    key, new = run(library.add_show(500, "request", mode="all"))
    assert new
    t = _tree_seasons()
    assert list(t) == ["Season 01", "Season 02"]          # season 3 not aired yet
    assert fake == ["tv/Test Show (2020) {tmdb-500}/Season 01", "tv/Test Show (2020) {tmdb-500}/Season 02"]
    assert library.wanted_seasons(key) == {1, 2, 3}           # future season tracked


def test_request_specific_seasons_then_add_more(fake):
    from aiobridge import library, db
    key, _ = run(library.add_show(500, "request", mode="seasons", seasons=[2]))
    assert list(_tree_seasons()) == ["Season 02"]
    fake.clear()
    key, changed = run(library.add_show(500, "request", mode="seasons", seasons=[1]))
    assert changed and list(_tree_seasons()) == ["Season 01", "Season 02"]
    assert fake == ["tv/Test Show (2020) {tmdb-500}/Season 01"]   # only the newly added season is scanned
    assert db.requested_seasons(key) == {1, 2}


def test_request_new_episodes_only_then_track_airing(fake, monkeypatch):
    from aiobridge import library, db, naming
    key, _ = run(library.add_show(500, "request", mode="new"))
    assert _tree_seasons() == {}                              # nothing aired since today
    assert library.wanted_seasons(key) == {3}
    # time passes: S3E1 airs
    later = D(6)
    monkeypatch.setattr(naming, "aired", lambda d, today=None: bool(d) and d <= (today or later))
    monkeypatch.setattr(library, "_air_start", lambda e: 0)  # ...and its air time has passed
    monkeypatch.setattr(library, "_today", lambda: later)
    assert library._announce_visible(key) == 0                # aired, but no stream confirmed yet
    assert run(library.check_waiting(db.get_item(key), force=True)) == 1
    assert fake[-1] == "tv/Test Show (2020) {tmdb-500}/Season 03"
    assert library._announce_visible(key) == 0                # announced only once
    assert [e["announced"] for e in db.episodes(key) if e["season"] == 3] == [1, 0]


def test_all_mode_wins_over_new(fake):
    from aiobridge import library, db
    key, _ = run(library.add_show(500, "request", mode="all"))
    run(library.add_show(500, "request", mode="new"))
    assert db.get_item(key)["monitor"] == "all"


def test_series_refresher_staggers(monkeypatch):
    from aiobridge import library, config
    calls = []
    async def refresh_path(path):
        calls.append((round(asyncio.get_event_loop().time(), 1), path)); return True
    monkeypatch.setattr(library.plex, "refresh_path", refresh_path)
    monkeypatch.setattr(config, "SERIES_REFRESH_STAGGER_SECONDS", 0.2)
    async def go():
        r = library.SeriesRefresher()
        item = {"kind": "show", "title": "X", "year": 2020, "tmdb": 1}
        r.add_show(item, {2, 1}); r.add_show(item, {1})       # duplicate ignored while pending
        t = asyncio.create_task(r.run()); await asyncio.sleep(0.5); t.cancel()
    asyncio.run(go())
    assert [p.rsplit("/", 1)[1] for _, p in calls] == ["Season 01", "Season 02"]
    assert calls[1][0] - calls[0][0] >= 0.15


def test_new_episode_tracking(fake):
    """Episodes present at request time aren't 'new'; ones that air later are."""
    import time
    from aiobridge import library, db, requests_ui
    key, _ = run(library.add_show(500, "request", mode="all"))
    assert db.new_episode_stats(0) == {}
    item = db.get_item(key)
    st = requests_ui._status(item)
    assert st["tracking"] and not st["ended"] and st["new_episodes"] == 0
    # S03E01 airs: move its air date into the past, then the watcher picks it up
    with db.conn() as c:
        c.execute("UPDATE episodes SET air_date=? WHERE show_key=? AND season=3 AND episode=1", (D(0), key))
    assert run(library.check_waiting(db.get_item(key), force=True)) == 1
    n, last = db.new_episode_stats(time.time() - 60)[key]
    assert n == 1 and last
    assert requests_ui._status(db.get_item(key))["new_episodes"] == 1
    # a completed show is never "tracking"
    with db.conn() as c:
        c.execute("UPDATE items SET status='Ended' WHERE key=?", (key,))
    st = requests_ui._status(db.get_item(key))
    assert st["ended"] and not st["tracking"]


def test_remove_season_and_rerequest(fake):
    from aiobridge import library, db
    key, _ = run(library.add_show(500, "request", mode="all"))
    library.remove_season(key, 1)
    assert list(_tree_seasons()) == ["Season 02"]
    assert 1 not in library.wanted_seasons(key)          # stays out even in "all" mode
    run(library.add_show(500, "request", mode="seasons", seasons=[1]))
    assert list(_tree_seasons()) == ["Season 01", "Season 02"]


def test_delete_and_restore_episode_file(fake):
    from aiobridge import library, db, naming
    key, _ = run(library.add_show(500, "request", mode="all"))
    item = db.get_item(key)
    skey = naming.stream_key_episode(item, 2, 1)
    db.set_stream(skey, "http://x/a.mkv", 100, "a.mkv")
    library.set_episode_file(key, 2, 1, False, False)
    assert len(_tree_seasons()["Season 02"]) == 1
    assert db.get_stream(skey) is None
    library.set_episode_file(key, 2, 1, False, True)
    assert len(_tree_seasons()["Season 02"]) == 2
    db.set_stream(skey, "http://x/b.mkv", 200, "b.mkv")
    assert db.get_stream(skey)["filename"] == "b.mkv"


def test_candidate_format():
    from aiobridge import requests_ui
    c = requests_ui._fmt_candidate({"url": "http://x", "name": "[RD⚡] 2160p", "description": "HEVC DV",
                                     "behaviorHints": {"filename": "Show.S01E01.2160p.mkv", "videoSize": 2 * 1024 ** 3}})
    assert c["quality"] == "4k" and c["resolution"] == "2160p" and c["cached"] is True and c["size_gb"] == 2.0


def test_specials_never_added(fake, monkeypatch):
    from aiobridge import library, db, naming
    SHOW["seasons"].insert(0, {"season_number": 0, "episode_count": 1})
    SEASONS[0] = [(1, D(-100))]
    try:
        key, _ = run(library.add_show(500, "request", mode="all"))
        assert all(e["season"] > 0 for e in db.episodes(key))
        assert "Season 00" not in _tree_seasons()
        assert not naming.wanted_episode(db.get_item(key), 0, D(-1), set())
    finally:
        SHOW["seasons"].pop(0); SEASONS.pop(0)


def test_new_episode_waits_for_stream(fake, monkeypatch):
    """An aired episode stays out of Plex until AIOStreams has a stream for it."""
    import time
    from aiobridge import library, db
    key, _ = run(library.add_show(500, "request", mode="all"))
    with db.conn() as c:     # S03E01 aired an hour ago (exact time from Cinemeta)
        c.execute("UPDATE episodes SET air_date=?, air_ts=? WHERE show_key=? AND season=3 AND episode=1",
                  (D(0), time.time() - 3600, key))
    library._test_stream_ok["v"] = False
    assert run(library.check_waiting(db.get_item(key))) == 0
    assert "Season 03" not in _tree_seasons()
    ep = next(e for e in db.episodes(key) if (e["season"], e["episode"]) == (3, 1))
    assert ep["checks"] == 1 and abs(ep["next_check"] - (time.time() + 2 * 3600)) < 60   # next check in 2 h
    assert run(library.check_waiting(db.get_item(key))) == 0              # not due yet: no call
    library._test_stream_ok["v"] = True
    assert run(library.check_waiting(db.get_item(key), force=True)) == 1
    assert _tree_seasons()["Season 03"] == ["Test Show (2020) - S03E01.mkv"]


def test_not_checked_before_air_time(fake):
    import time
    from aiobridge import library, db
    key, _ = run(library.add_show(500, "request", mode="all"))
    with db.conn() as c:     # airs today, but later tonight
        c.execute("UPDATE episodes SET air_date=?, air_ts=? WHERE show_key=? AND season=3 AND episode=1",
                  (D(0), time.time() + 5 * 3600, key))
    calls = []
    async def spy(item, s, e): calls.append((s, e)); return True
    library.has_stream = spy
    assert run(library.check_waiting(db.get_item(key))) == 0 and calls == []
    assert "Season 03" not in _tree_seasons()


def test_check_schedule_two_hours_for_a_day():
    from aiobridge import library
    air = 1_000_000.0
    ep = {"air_ts": air, "air_date": "2026-01-01"}
    assert library._air_start(ep) == air + 15 * 60
    assert library.next_check_after_miss(ep, air + 900) == air + 900 + 7200
    assert library.next_check_after_miss(ep, air + 23 * 3600) == air + 24 * 3600   # final check at 24 h
    assert library.next_check_after_miss(ep, air + 24 * 3600 + 1) is None                # then stop


def test_found_episode_not_checked_again(fake):
    import time
    from aiobridge import library, db
    key, _ = run(library.add_show(500, "request", mode="all"))
    with db.conn() as c:
        c.execute("UPDATE episodes SET air_date=?, air_ts=? WHERE show_key=? AND season=3 AND episode=1",
                  (D(0), time.time() - 3600, key))
    calls = []
    async def spy(item, s, e): calls.append((s, e)); return True
    library.has_stream = spy
    assert run(library.check_waiting(db.get_item(key))) == 1
    assert run(library.check_waiting(db.get_item(key), force=True)) == 0 and calls == [(3, 1)]


def test_stops_after_24h_but_old_episode_checked_once(fake):
    import time
    from aiobridge import library, db
    key, _ = run(library.add_show(500, "request", mode="all"))
    with db.conn() as c:     # aired 2 days ago, never checked
        c.execute("UPDATE episodes SET air_date=?, air_ts=? WHERE show_key=? AND season=3 AND episode=1",
                  (D(0), time.time() - 48 * 3600, key))
    calls = []
    async def miss(item, s, e): calls.append((s, e)); return False
    library.has_stream = miss
    assert run(library.check_waiting(db.get_item(key))) == 0 and calls == [(3, 1)]   # one check
    ep = next(e for e in db.episodes(key) if (e["season"], e["episode"]) == (3, 1))
    assert library.gave_up(ep)
    assert run(library.check_waiting(db.get_item(key))) == 0 and calls == [(3, 1)]   # no more
    assert run(library.check_waiting(db.get_item(key), force=True)) == 0 and len(calls) == 2  # manual still works


def test_ui_deletions_scan_parent_and_force_trash(tmp_path, monkeypatch):
    import os
    from aiobridge import config, library
    mnt = tmp_path / "aio"
    (mnt / "tv" / "Show (2020) {tmdb-1}" / "Season 01").mkdir(parents=True)
    monkeypatch.setattr(config, "MOUNT_POINT", str(mnt))
    monkeypatch.setattr(config, "EMPTY_TRASH_AFTER_SCAN", False)        # setting off...
    q, t = library.ScanQueue(), library.TrashEmptier()
    monkeypatch.setattr(library, "trash", t)
    # whole show deleted: its folder is gone -> scan the library folder
    q.add("tv/Gone Show (2019) {tmdb-2}", removed=True)
    # one episode deleted: its season folder still exists -> scan that season
    q.add("tv/Show (2020) {tmdb-1}/Season 01", removed=True)
    assert q.deleted == {f"{mnt}/tv", f"{mnt}/tv/Show (2020) {{tmdb-1}}/Season 01"}
    t.add(f"{mnt}/tv/x")                                                 # ordinary scan: skipped (setting off)
    assert not t.pending
    t.add(f"{mnt}/tv/x", force=True)                                     # ...but a deletion always purges
    assert t.pending == {f"{mnt}/tv"} and t.forced == {f"{mnt}/tv"}


def test_forced_purge_waits_for_scan_then_empties_twice(monkeypatch):
    import asyncio
    from aiobridge import library
    timeline = {"t": 0}
    calls = []
    class FakePlex:
        async def section_for(self, path): return {"key": "2", "title": "TV Shows"}
        async def sections(self):
            t = timeline["t"]
            return [{"key": "2", "refreshing": 15 <= t < 40}]             # scan starts late, runs 25 s
        async def req(self, method, ep, **kw): calls.append((timeline["t"], method, ep))
    async def fake_sleep(sec): timeline["t"] += sec
    monkeypatch.setattr(library, "plex", FakePlex())
    monkeypatch.setattr(library.asyncio, "sleep", fake_sleep)
    monkeypatch.setattr(library, "mount_healthy", lambda top: (True, ""))
    t = library.TrashEmptier()
    asyncio.run(t._empty("/media/aio/tv", forced=True))
    assert [c[2] for c in calls] == ["/library/sections/2/emptyTrash"] * 2
    assert calls[0][0] >= 40                                            # only after the scan finished


def test_purge_skipped_when_mount_unhealthy(monkeypatch):
    import asyncio
    from aiobridge import library
    calls = []
    class FakePlex:
        async def section_for(self, path): return {"key": "1"}
        async def sections(self): return [{"key": "1", "refreshing": False}]
        async def req(self, *a, **k): calls.append(a)
    async def fake_sleep(sec): pass
    monkeypatch.setattr(library, "plex", FakePlex())
    monkeypatch.setattr(library.asyncio, "sleep", fake_sleep)
    monkeypatch.setattr(library, "mount_healthy", lambda top: (False, "virtual library isn't mounted"))
    asyncio.run(library.TrashEmptier()._empty("/media/aio/movies", forced=True))
    assert calls == []


def test_current_season_request_checks_new_episodes(fake, monkeypatch):
    """Requesting the airing season of a show already in the library refreshes
    its episode list and checks held-back episodes for a stream straight away."""
    from aiobridge import config, db, library
    monkeypatch.setattr(config, "WAIT_FOR_STREAMS", True)
    key, _ = run(library.add_show(500, "request", mode="seasons", seasons=[1]))
    assert library.current_season(key) == 2 and library.live_seasons(key) == {2, 3}
    SEASONS[2].append((3, D(-1)))                    # aired after the last sync
    SHOW["seasons"][1]["episode_count"] = 3
    refreshed = []
    real = library.refresh_show
    async def spy(k):
        refreshed.append(k); return await real(k)
    monkeypatch.setattr(library, "refresh_show", spy)
    checked = []
    async def check(item, force=False, only_seasons=None):
        checked.append(only_seasons); return 0
    monkeypatch.setattr(library, "check_waiting", check)
    try:
        run(library.add_show(500, "request", mode="seasons", seasons=[2]))
    finally:
        SEASONS[2].pop(); SHOW["seasons"][1]["episode_count"] = 2
    assert refreshed == [key]
    assert (2, 3) in {(e["season"], e["episode"]) for e in db.episodes(key)}
    assert checked == [{2}]
    from aiobridge import requests_ui
    assert requests_ui._status(db.get_item(key))["tracking"]


def test_past_season_request_skips_refresh(fake, monkeypatch):
    from aiobridge import library
    key, _ = run(library.add_show(500, "request", mode="seasons", seasons=[2]))
    called = []
    async def spy(k): called.append(k)
    monkeypatch.setattr(library, "refresh_show", spy)
    run(library.add_show(500, "request", mode="seasons", seasons=[1]))
    assert called == []


def test_episode_airing_later_today_not_treated_as_aired(fake, monkeypatch):
    """Exact air time wins over the air date: tonight's episode isn't out this morning."""
    import time
    from aiobridge import config, db, library, naming
    monkeypatch.setattr(config, "WAIT_FOR_STREAMS", True)
    ep = {"air_date": D(0), "air_ts": time.time() + 6 * 3600}
    assert not naming.ep_aired(ep)
    assert naming.ep_aired({**ep, "air_ts": time.time() - 60})
    assert naming.ep_aired({"air_date": D(0)})          # no air time known: date decides
    SEASONS[2].append((3, D(0))); SHOW["seasons"][1]["episode_count"] = 3
    try:
        key, _ = run(library.add_show(500, "request", mode="seasons", seasons=[1]))
    finally:
        SEASONS[2].pop(); SHOW["seasons"][1]["episode_count"] = 2
    db.set_air_times(key, {(2, 3): time.time() + 6 * 3600})
    checked = []
    async def has_stream(item, s, e): checked.append((s, e)); return True
    monkeypatch.setattr(library, "has_stream", has_stream)
    run(library.check_waiting(db.get_item(key), force=True, only_seasons={2}))
    assert (2, 3) not in checked
