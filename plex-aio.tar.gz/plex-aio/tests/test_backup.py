import asyncio, os, sys, json
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))
from test_core import tmp_cfg  # noqa: F401,E402

UA = "pytest-browser"


def _seed():
    from aiobridge import db
    db.upsert_item("movie:603", "movie", 603, "tt0133093", "The Matrix", 1999, 136, "Released")
    db.set_has_4k("movie:603", True); db.set_requested_by("movie:603", "friend"); db.touch_source("movie:603", "request")
    db.upsert_item("show:1399", "show", 1399, "tt0944947", "Game of Thrones", 2011, 60, "Ended")
    db.set_monitor("show:1399", "seasons")
    db.replace_episodes("show:1399", [(1, 1, "Winter Is Coming", 62, "2011-04-17"), (2, 1, "The North", 55, "2012-04-01")])
    db.mark_announced("show:1399", [(1, 1)])
    db.add_requested_seasons("show:1399", [1]); db.set_season_4k("show:1399", 1, True)


def test_roundtrip_replace_and_merge(tmp_cfg, monkeypatch):
    from aiobridge import backup, db, library, auth, config
    monkeypatch.setattr(config, "SETTINGS_PATH", str(tmp_cfg / "settings.json"))
    for k in config.SPEC:
        monkeypatch.setattr(config, k, getattr(config, k))
    queued = []
    monkeypatch.setattr(library.scans, "add", lambda rel, removed=False: queued.append((rel, removed)))
    _seed()
    auth._upsert("1", "owner", "o@x", "", "secret-token"); auth._upsert("2", "friend", "f@x", "", "tok2")
    config.save({"MIN_4K_CANDIDATES": 5, "TMDB_API_KEY": "k" * 30})
    b = json.loads(json.dumps(backup.export()))                 # through JSON like a real file
    assert b["format"] == "plex-aio-backup" and len(b["library"]) == 2
    assert "secret-token" not in json.dumps(b)                  # Plex tokens never exported
    got = next(e for e in b["library"] if e["key"] == "show:1399")
    assert got["requested_seasons"] == [1] and got["seasons_4k"] == [1] and got["monitor"] == "seasons"

    # wipe everything, then restore
    for it in db.all_items(): db.delete_item(it["key"])
    config.save({"MIN_4K_CANDIDATES": 2})
    os.remove(os.path.join(config.CONFIG_DIR, "users.json"))
    res = backup.restore(b)
    assert res["added"] == 2 and res["users"] == 2 and res["settings"] > 0
    assert config.MIN_4K_CANDIDATES == 5
    show = db.get_item("show:1399")
    assert show["monitor"] == "seasons" and db.requested_seasons("show:1399") == {1} and db.seasons_4k("show:1399") == {1}
    eps = {(e["season"], e["episode"]): e["announced"] for e in db.episodes("show:1399")}
    assert eps == {(1, 1): 1, (2, 1): 0}
    m = db.get_item("movie:603"); assert m["has_4k"] == 1 and m["requested_by"] == "friend"
    assert {u["username"]: u["role"] for u in auth.list_users()} == {"owner": "admin", "friend": "user"}
    assert ("movies4k/The Matrix (1999) {tmdb-603}", False) in queued

    # merge again: nothing duplicated
    res = backup.restore(b)
    assert res["added"] == 0 and res["skipped"] == 2
    # replace with a library that only has the movie
    b2 = dict(b, library=[e for e in b["library"] if e["kind"] == "movie"])
    res = backup.restore(b2, replace=True, restore_settings=False, restore_users=False)
    assert res["removed"] == 2 and res["added"] == 1 and db.get_item("show:1399") is None


def test_restore_rejects_other_files():
    from aiobridge import backup
    import pytest
    with pytest.raises(ValueError):
        backup.restore({"format_version": 1, "settings": {}})     # e.g. an aiogateway backup
    with pytest.raises(ValueError):
        backup.restore({"format": "plex-aio-backup", "format_version": 99})


def test_backup_endpoints_are_admin_only(tmp_cfg):
    from aiobridge import admin_api, auth
    auth._upsert("1", "owner", "", "", "a"); auth._upsert("2", "friend", "", "", "b")
    admin, user = auth.create_session("1", UA, "x"), auth.create_session("2", UA, "x")
    async def go():
        app = web.Application(middlewares=[admin_api.access]); admin_api.routes(app)
        async with TestClient(TestServer(app)) as c:
            h = {"User-Agent": UA}
            c.session.cookie_jar.update_cookies({auth.COOKIE: user})
            assert (await c.get("/api/backup", headers=h)).status == 403
            assert (await c.post("/api/restore", headers=h, json={})).status == 403
            c.session.cookie_jar.update_cookies({auth.COOKIE: admin})
            r = await c.get("/api/backup", headers=h)
            assert r.status == 200 and "attachment" in r.headers["Content-Disposition"]
            assert (await r.json())["format"] == "plex-aio-backup"
            r = await c.post("/api/restore", headers=h, json={"bundle": {"nope": 1}})
            assert r.status == 400
    asyncio.run(go())
