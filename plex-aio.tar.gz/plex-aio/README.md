# plex-aio

One container with Plex Media Server, metadata pulled from TMDB, and streams and
requests and 4K from AIOStreams. **Plex never scans or analyzes your real streams.** Any
movie or show you search for in Plex is added to the library automatically, through
Cinemeta.

```
 Plex apps ──► :32400 ──► front proxy ──► Plex Media Server (internal :32400)
                           │   searches hook into Cinemeta → add to library
                           ▼
                 bridge :8770 ── TMDB metadata providers (/movie, /tv)
                           │      request page (Cinemeta), 4K checks
                           ▼
           /media/aio (FUSE, read-only; same design as aiogateway's fuse_fs)
             first read of a handle: is Plex /status/sessions playing this file?
               no  (scanner, analyzer, thumbnailer) → placeholder clip, zero-padded
               yes (playback)                       → AIOStreams /stream → debrid link
             real reads: 8 MB block LRU cache, prefetch, link repair
```

## Why there are placeholders

These findings come from the strings in the Plex Media Server 1.43.4 binary:

* **Analysis can't be turned off.** Plex's scanner pipeline always runs a media-analysis
  stage (`ScannerPiplineStagePerformMediaAnalysis`), and there's no switch for it. So
  every new file is opened once. The FUSE layer hands that read a 1080p H.264/AAC black
  clip of the right runtime, about 2 MB for a 45-minute episode, generated locally.
  Debrid is never touched while scanning.
* **The extras can be turned off.** Preview thumbnails, chapter thumbnails,
  intro/credits/ad markers, voice activity, loudness, deep media analysis, scheduled
  library scans, and filesystem watching all have preferences. They're switched off
  before Plex starts (see `app/aiobridge/prefs.py`).
* **Custom metadata providers are built in.** The binary requires their IDs to start
  with `tv.plex.agents.custom.`, and plex-aio's do.

The first time a title plays, the filesystem resolves the stream through AIOStreams,
serves the real bytes, and then asks Plex to rescan that folder. Plex then replaces the
placeholder's media info with the real file's.

## Setup

1. `cp .env.example .env`, then set `PLEX_ADVERTISE_URL` (your host's LAN IP) and a
   fresh `PLEX_CLAIM` from <https://plex.tv/claim>.
2. `docker compose up -d --build`
3. Open `http://<host>:32400/web` and finish Plex setup. plex-aio creates the
   **Movies**, **TV Shows**, **Movies 4K** and **TV Shows 4K** libraries for you.
4. **Switch the libraries to the TMDB provider.** This is done once, in Plex:
   * Go to Settings → Metadata Agents → **Add Provider**, and add
     `http://127.0.0.1:8770/movie`. Repeat with `http://127.0.0.1:8770/tv`.
   * Use **Add Agent** to make each provider the primary of its own agent.
   * Edit each library → Advanced → Agent, and pick the new agent.
5. Open `http://<host>:8770` and **Log in with Plex**. The first account to sign in becomes
   admin. Go to **Settings → Connections**, enter your TMDB key and AIOStreams manifest URL,
   and press **Test connections**.

## Users and settings

Sign-in works like aiogateway: Plex's PIN login, and only accounts that own or have
been shared this Plex server can get in (Settings → Users → "Require access").
The first person to sign in is admin; everyone after that starts as **user**, who can
browse, search and request titles. Admins also see **Library** and **Settings**, and
can promote, demote or remove users there (the last admin can't be removed).
Changing a role signs that person out everywhere.

Every plex-aio setting is in **Settings** (Connections, Users, Library, Streams, Plex
setup) and is saved to `config/aio/settings.json`. Changes apply live, except the few
marked **RESTART**. Values in `.env` are only starting defaults.

## Filesystem tuning

Same knobs as aiogateway: `FUSE_BLOCK_MB` (8), `FUSE_CACHE_BLOCKS` (32),
`FUSE_PREFETCH_AHEAD` (2), `FUSE_READ_TIMEOUT` (15), `FUSE_READ_ATTEMPTS` (3),
`FUSE_MAX_INFLIGHT` (6), `FUSE_PLAY_DETECT_SECONDS` (4), `STREAM_USER_AGENT`.
Files report their real size once known (50 GB until then), so Plex never caps
reads at the placeholder's length.

## Requesting titles

Open `http://<host>:8770` for the request page: browse popular movies and shows
from Cinemeta, search, open a title and press **Request**. Badges show what is
already in the library and which titles have 4K. The AIOStreams catalogs are no
longer synced; the library is exactly what was requested (plus Plex searches).

## Seasons and new episodes

When requesting a show, pick **All seasons** (including future ones), **New episodes**
(only what airs from today on), or specific seasons. Requesting again adds to it.
Upcoming episodes are stored with their air dates; every 30 minutes plex-aio checks
for episodes that have aired, adds them to the library and asks Plex to scan their
season. Ongoing shows are refreshed from TMDB every `SYNC_INTERVAL_HOURS` for new
episodes and seasons.

Movies are scanned in Plex the moment they're added. Shows are scanned one season
folder at a time, pausing `SERIES_REFRESH_STAGGER_SECONDS` (Settings → Library)
between seasons.

## Backup and restore

Settings → Backup/Restore downloads one JSON file with your settings (including the
TMDB key and AIOStreams URL — keep it safe), users and roles (no Plex tokens), and
the whole library: request modes, requested seasons, 4K, requester and episode
tracking. Restoring merges by default, or replaces the library if you tick
"Replace". Plex rescans afterwards.

## 4K

On request, one AIOStreams lookup decides whether a 4K version exists (at least
`MIN_4K_CANDIDATES` results tagged 2160p/4K/UHD; shows are checked per season).
Titles with 4K also appear in the **Movies 4K** (`/media/aio/movies4k`) and
**TV Shows 4K** (`/media/aio/tv4k`) libraries. Playing from a 4K library only
ever resolves 4K streams; the regular libraries only resolve non-4K streams.
Ongoing shows are re-checked for 4K when a new season appears, and the request
page has a "Check 4K again" button.

## How titles get in

| Trigger | What happens |
|---|---|
| Request page | Adds the title, then checks for 4K in the background. |
| Search in any Plex app | The proxy waits until you stop typing, looks the query up on Cinemeta, adds the best `SEARCH_RESULTS_PER_TYPE` movies and shows, waits for Plex to index them, and then returns the results. |
| UI / API | `POST /api/add {"id":"tt0133093","type":"movie"}` · `GET /api/search?q=...` · `DELETE /api/items/movie:603` |

Plex only scans the folders plex-aio changes. Large batches become one library scan,
which only stats the unchanged files. Ongoing shows get new episodes on each sync.

## Requirements and caveats

* **The container needs FUSE:** `--device /dev/fuse --cap-add SYS_ADMIN`, with AppArmor
  unconfined. This is already in `docker-compose.yml`.
* **The first play of a title may not start.** Plex chooses direct play from the
  placeholder's media info: H.264 1080p with stereo AAC. If the real file is
  HEVC/4K/Atmos and your client can't direct-play it, the first attempt may fail.
  Retry after about 30 seconds, once the automatic rescan has stored the real info.
* **Some actions read the whole file.** Download/Sync to a device, Optimize, and the
  manual Analyze button all stream through debrid.
* **Plex sees every client as local**, because traffic arrives through the proxy.
  Clients still have to sign in, since the proxy talks to Plex on the container
  address, not on loopback. But Plex's remote-bandwidth limits won't apply.
* **The default prefs follow Plex's naming conventions.** The preference *names* were
  confirmed from the binary. The *values* (`never`, `0`) follow Plex's usual
  convention.

## Development

```
pip install aiohttp httpx trio pyfuse3 pytest
python -m pytest tests
```
