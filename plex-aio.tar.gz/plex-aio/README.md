# plex-aio

One container with Plex Media Server, metadata pulled from TMDB, and streams and
catalogs from AIOStreams. **Plex never scans or analyzes your real streams.** Any
movie or show you search for in Plex is added to the library automatically, through
Cinemeta.

```
 Plex apps ──► :32400 ──► front proxy ──► Plex Media Server (internal :32400)
                           │   searches hook into Cinemeta → add to library
                           ▼
                 bridge :8770 ── TMDB metadata providers (/movie, /tv)
                           │      AIOStreams catalog sync, web UI
                           ▼
           /media/aio (FUSE, read-only)
             scanner reads   → tiny local placeholder clip (no network)
             playback reads  → AIOStreams /stream → debrid link (byte ranges)
```

## Why there are placeholders

These findings come from the strings in the Plex Media Server 1.43.4 binary:

* **Analysis can't be turned off.** Plex's scanner pipeline always runs a media-analysis
  stage (`ScannerPiplineStagePerformMediaAnalysis`), and there's no switch for it. So
  every new file is opened once. The FUSE layer hands that read a 1080p H.264/AAC black
  clip of the right runtime, about 2 MB for a 45-minute episode, generated locally.
  Debrid is never touched while scanning.
* **The extras can be turned off.** Preview thumbnails, chapter thumbnails,
  intro/credits/ad markers, voice activity, loudness, deep media analysis, scheduled
  library scans, and filesystem watching all have preferences. They're switched off
  before Plex starts (see `app/aiobridge/prefs.py`).
* **Custom metadata providers are built in.** The binary requires their IDs to start
  with `tv.plex.agents.custom.`, and plex-aio's do.

The first time a title plays, the filesystem resolves the stream through AIOStreams,
serves the real bytes, and then asks Plex to rescan that folder. Plex then replaces the
placeholder's media info with the real file's.

## Setup

1. `cp .env.example .env`, then fill in `TMDB_API_KEY`, `AIOSTREAMS_MANIFEST_URL`,
   `PLEX_ADVERTISE_URL` (your host's LAN IP), and a fresh `PLEX_CLAIM` from
   <https://plex.tv/claim>.
2. `docker compose up -d --build`
3. Open `http://<host>:32400/web` and finish Plex setup. plex-aio creates the
   **Movies** (`/media/aio/movies`) and **TV Shows** (`/media/aio/tv`) libraries for you.
4. **Switch the libraries to the TMDB provider.** This is done once, in Plex:
   * Go to Settings → Metadata Agents → **Add Provider**, and add
     `http://127.0.0.1:8770/movie`. Repeat with `http://127.0.0.1:8770/tv`.
   * Use **Add Agent** to make each provider the primary of its own agent.
   * Edit each library → Advanced → Agent, and pick the new agent.
5. Open the plex-aio UI at `http://<host>:8770`. There you can search and add titles,
   run a catalog sync, and see what's been added.

## How titles get in

| Trigger | What happens |
|---|---|
| AIOStreams catalogs | Every `SYNC_INTERVAL_HOURS`, each movie/series catalog is read, up to `CATALOG_LIMIT` items. Titles that drop out of every catalog are removed. |
| Search in any Plex app | The proxy waits until you stop typing, looks the query up on Cinemeta, adds the best `SEARCH_RESULTS_PER_TYPE` movies and shows, waits for Plex to index them, and then returns the results. |
| UI / API | `POST /api/add {"id":"tt0133093","type":"movie"}` · `GET /api/search?q=...` · `DELETE /api/items/movie:603` |

Plex only scans the folders plex-aio changes. Large batches become one library scan,
which only stats the unchanged files. Ongoing shows get new episodes on each sync.

## Requirements and caveats

* **The container needs FUSE:** `--device /dev/fuse --cap-add SYS_ADMIN`, with AppArmor
  unconfined. This is already in `docker-compose.yml`.
* **The first play of a title may not start.** Plex chooses direct play from the
  placeholder's media info: H.264 1080p with stereo AAC. If the real file is
  HEVC/4K/Atmos and your client can't direct-play it, the first attempt may fail.
  Retry after about 30 seconds, once the automatic rescan has stored the real info.
* **Some actions read the whole file.** Download/Sync to a device, Optimize, and the
  manual Analyze button all stream through debrid.
* **The AIOStreams "Library" catalog calls the debrid API.** Syncing it lists your
  debrid account each time. TMDB, Trakt and similar catalogs don't touch debrid.
* **Plex sees every client as local**, because traffic arrives through the proxy.
  Clients still have to sign in, since the proxy talks to Plex on the container
  address, not on loopback. But Plex's remote-bandwidth limits won't apply.
* **The default prefs follow Plex's naming conventions.** The preference *names* were
  confirmed from the binary. The *values* (`never`, `0`) follow Plex's usual
  convention.

## Development

```
pip install aiohttp httpx trio pyfuse3 pytest
python -m pytest tests
```
