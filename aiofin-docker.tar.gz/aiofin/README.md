# AIOFin

A Jellyfin-compatible server built for one job: turning your **AIOStreams** setup into a Jellyfin library that starts playing fast.

AIOStreams catalogs become Jellyfin libraries, its metadata fills the detail pages, and its stream results (from your debrid services, indexers and Usenet) become the versions you pick from. Any Jellyfin app works unchanged: Infuse, Swiftfin, Jellyfin for Android / Android TV, Streamyfin, Findroid and Jellyfin Web.

It's modelled on [Remux](https://github.com/lostb1t/remux) and uses the same look: Jellyfin Web 12.1 with the ElegantFin theme, and Remux's dashboard design for the admin page. Remux does much more (local files, torrents, music, IPTV). AIOFin drops all of that to focus on speed.

## Quick start

```sh
docker compose -f docker/compose.yml up -d --build
```

Then open `http://<server>:8096/admin`, create your admin account and paste your AIOStreams install link (the `…/manifest.json` URL from your AIOStreams configuration page). In any Jellyfin app, add the server `http://<server>:8096` and sign in.

To get a Docker image tarball for another machine, run `./build-image.sh`. It produces `aiofin-image.tar.gz`, which you load with `docker load -i aiofin-image.tar.gz`.

Without Docker, use Node.js 20+ and run `AIOSTREAMS_URL=… node src/index.js`. There are no dependencies to install. Point `WEB_PATH` at a Jellyfin Web build if you want the web client.

## How it gets streams fast

The first lookup for a title takes as long as AIOStreams takes. AIOFin makes sure that wait almost never happens when someone presses Play.

- **Looks up streams when a title is opened.** Opening a movie or episode starts the AIOStreams lookup in the background. By the time Play is pressed the list is cached, and Play answers in about 1 ms.
- **Prepares what you'll watch next.** Opening a series warms the episode you're most likely to play. While an episode plays, the next two are looked up, and the next one is refreshed in the last five minutes so autoplay is instant. The top of *Next up* and *Continue watching* is prepared too.
- **Shares lookups.** If several people or devices ask for the same title at once, AIOStreams is called once and everyone gets the result.
- **Serves stale lists instantly.** A stream list stays fresh for 20 minutes. After that it's still returned immediately while a refresh runs in the background. AIOStreams playback links resolve when opened, so an older list still plays.
- **Keeps the connection warm.** One pooled, kept-alive connection to AIOStreams means no TLS handshake per lookup.
- **Stays out of the video path.** Players get a redirect straight to the AIOStreams/debrid link. The server never relays video unless you ask it to.
- **Preloads libraries.** The first page of every library is fetched at startup and on a schedule, so home rows and library pages open instantly.

The admin page's **Overview** shows every recent lookup on a timeline against a 3-second target. It also has a speed test that measures AIOStreams with all caches skipped.

### Getting AIOStreams itself under 3 seconds

AIOFin can't make AIOStreams' own first lookup faster than its slowest add-on allows. In your AIOStreams configuration:

- Lower the per-add-on timeout. Slow scrapers that rarely return anything useful are usually what pushes lookups past 3 seconds.
- Remove add-ons and indexers you don't need.
- Turn on result caching if your AIOStreams version offers it.
- Run AIOStreams close to AIOFin, on the same machine or network if you can.

## Settings

Everything can be changed on the admin page, which overrides the environment. Environment variables set the defaults.

| Variable | Default | What it does |
|---|---|---|
| `AIOSTREAMS_URL` | | Your AIOStreams manifest URL |
| `ADMIN_USERNAME`, `ADMIN_PASSWORD` | | Create the admin on first start (otherwise use `/admin`) |
| `SERVER_NAME` | `AIOFin` | Name shown in Jellyfin apps |
| `PREFETCH_ON_OPEN` | `true` | Look up streams when a title is opened |
| `PREWARM_EPISODES` | `2` | Episodes looked up ahead during playback |
| `PREFETCH_NEXTUP` | `1` | Next up items prepared when the home screen loads |
| `STREAM_WAIT_MS` | `12000` | Longest a player waits for AIOStreams; the lookup still finishes and is cached |
| `STREAM_TTL_SEC` / `STREAM_STALE_SEC` | `1200` / `21600` | How long stream lists are fresh / still served while refreshing |
| `MAX_SOURCES` | `25` | Versions shown per title |
| `ONLY_CACHED` | `false` | Hide results your debrid service hasn't cached |
| `SOURCE_NAMES` | `clean` | `clean` labels like `4K DV · REMUX · TrueHD 7.1 Atmos · 58 GB · TorBox ⚡`, or `aiostreams` for your formatter's text |
| `STREAM_MODE` | `redirect` | `redirect` (fastest) or `proxy` (video passes through AIOFin) |
| `PROXY_INTERNAL_HOSTS` | `true` | Proxy links on LAN/Docker addresses that outside players can't reach |
| `SUBTITLES` | `true` | Add subtitles from AIOStreams' subtitle add-ons |
| `META_FALLBACK_URL` | Cinemeta | Metadata source when AIOStreams has none for a title |
| `IMAGE_MODE` | `redirect` | `redirect` or `proxy` for posters and backdrops |
| `TRANSCODE` | `true` | Browser fallback (see below) |
| `HWACCEL` | `none` | `vaapi`, `qsv` or `nvenc` for the browser fallback |
| `TRANSCODE_MAX_HEIGHT` | `1080` | Resolution cap for converted video |
| `TRANSCODE_AHEAD_SECS` | `90` | Conversion pauses once this far ahead of the viewer |
| `DEFAULT_AUDIO_LANGUAGE` | `eng` | Audio track picked when converting |
| `PUBLIC_URL` | | Your external address, if behind a reverse proxy that doesn't send `X-Forwarded-*` |
| `PORT` | `8096` | HTTP port |

## Playback in different apps

Native apps (Infuse, Swiftfin, Jellyfin Android/TV, Streamyfin) **direct play** everything. AIOFin hands them the link and they handle any format.

Browsers can't play every file. When Jellyfin Web gets a file it can't decode, AIOFin converts it to HLS on the fly using the same approach as Remux's Lumen tuning: video is copied when the browser supports it, otherwise re-encoded to H.264 (capped at 1080p, HDR tone-mapped), and audio becomes stereo AAC. Seeking anywhere works. Pass a GPU into the container and set `HWACCEL` if many people watch in browsers.

## Docker networking notes

- If AIOStreams runs in the same Docker network and hands out links on its internal name (like `http://aiostreams:3000/…`), AIOFin rewrites them to your AIOStreams' public address when the manifest URL is public. If the manifest URL is itself internal, those links are proxied so remote players can still reach them.
- Port `7359/udp` lets apps find the server on your LAN. It's optional.
- Jellyfin Web is copied from the Remux image (`ghcr.io/lostb1t/remux:nightly`) at build time. To build it from source instead, add `--build-arg WEB_FROM=web-source`.

## What's not included

AIOFin is deliberately narrow. Results that are only a torrent hash with no link (P2P without a debrid service) are skipped. Configure a debrid or Usenet service in AIOStreams. There's no local media, music, live TV, collections or SyncPlay. Embedded subtitle tracks inside a file can't be listed in advance (that would require probing every file); native players show them once playback starts.

## Development

```sh
node test/mock-aiostreams.js   # fake AIOStreams on :7001 (needs test videos, see below)
DATA_DIR=./data node src/index.js
node test/e2e.js               # 69 end-to-end checks against the running server
```

The e2e test expects two sample files in `test/`. Generate them with ffmpeg:

```sh
ffmpeg -f lavfi -i testsrc2=size=1280x720:rate=24 -f lavfi -i sine -t 60 -c:v libx264 -c:a ac3 -ac 6 test/sample-h264-ac3.mkv
ffmpeg -f lavfi -i testsrc2=size=1920x1080:rate=24 -f lavfi -i sine -t 40 -c:v libx265 -c:a aac test/sample-hevc.mkv
```

Layout: `src/aio.js` (AIOStreams client and caches), `src/library.js` (Stremio metadata to Jellyfin items), `src/playback.js` (streams to versions), `src/transcode.js` (browser fallback), `src/routes/` (Jellyfin API), `admin/` (admin page).

## License

AGPL-3.0, the same as Remux, which this project is derived from. The admin page uses Remux's dashboard theme.
