# AIOFin

A Jellyfin-compatible server built for one job: turning your **AIOStreams** setup into a Jellyfin library that starts playing fast.

AIOStreams catalogs become Jellyfin libraries, its metadata fills the detail pages, and its stream results (from your debrid services, indexers and Usenet) become the versions you pick from. Any Jellyfin app works unchanged: Infuse, Swiftfin, Jellyfin for Android / Android TV, Streamyfin, Findroid and Jellyfin Web.

It's modelled on [Remux](https://github.com/lostb1t/remux) and uses the same look: Jellyfin Web 12.1 with the ElegantFin theme, and Remux's dashboard design for the admin page. Remux does much more (local files, torrents, music, IPTV). AIOFin drops all of that to focus on speed.

## Quick start

```sh
docker compose -f docker/compose.yml up -d --build
```

Then open `http://<server>:8096/admin`, create your admin account and paste your AIOStreams install link (the `…/manifest.json` URL from your AIOStreams configuration page). In any Jellyfin app, add the server `http://<server>:8096` and sign in.

To get a Docker image tarball for another machine, run `./build-image.sh`. It produces `aiofin-image.tar.gz`, which you load with `docker load -i aiofin-image.tar.gz`.

Without Docker, use Node.js 20+ and run `AIOSTREAMS_URL=… node src/index.js`. There are no dependencies to install. Point `WEB_PATH` at a Jellyfin Web build if you want the web client.

## How it gets streams fast

The first lookup for a title takes as long as AIOStreams takes. AIOFin makes sure that wait almost never happens when someone presses Play.

- **Looks up streams when a title is opened.** Opening a movie or episode starts the AIOStreams lookup in the background. By the time Play is pressed the list is cached, and Play answers in about 1 ms.
- **Prepares what you'll watch next.** Opening a series warms the episode you're most likely to play. While an episode plays, the next two are looked up, and the next one is refreshed in the last five minutes so autoplay is instant. The top of *Continue watching* is prepared too.
- **Reads the real tracks ahead of time.** When a title is opened, the top three cached results are checked with ffprobe (only the first few MB are read), so by the time Play is pressed the server knows each file's actual audio and video.
- **Shares lookups.** If several people or devices ask for the same title at once, AIOStreams is called once and everyone gets the result.
- **Serves stale lists instantly.** A stream list stays fresh for 20 minutes. After that it's still returned immediately while a refresh runs in the background. AIOStreams playback links resolve when opened, so an older list still plays.
- **Keeps the connection warm.** One pooled, kept-alive connection to AIOStreams means no TLS handshake per lookup.
- **Stays out of the video path.** Players get a redirect straight to the AIOStreams/debrid link. The server never relays video unless you ask it to.
- **Preloads libraries.** The first page of every library is fetched at startup and on a schedule, so home rows and library pages open instantly.

The admin page's **Overview** shows every recent lookup on a timeline against a 3-second target. It also has a speed test that measures AIOStreams with all caches skipped.

### Getting AIOStreams itself under 3 seconds

AIOFin can't make AIOStreams' own first lookup faster than its slowest add-on allows. In your AIOStreams configuration:

- Lower the per-add-on timeout. Slow scrapers that rarely return anything useful are usually what pushes lookups past 3 seconds.
- Remove add-ons and indexers you don't need.
- Turn on result caching if your AIOStreams version offers it.
- Run AIOStreams close to AIOFin, on the same machine or network if you can.

## Settings

Everything can be changed on the admin page, which overrides the environment. Environment variables set the defaults.

| Variable | Default | What it does |
|---|---|---|
| `AIOSTREAMS_URL` | | Your AIOStreams manifest URL |
| `ADMIN_USERNAME`, `ADMIN_PASSWORD` | | Create the admin on first start (otherwise use `/admin`) |
| `SERVER_NAME` | `AIOFin` | Name shown in Jellyfin apps |
| `PREFETCH_ON_OPEN` | `true` | Look up streams when a title is opened |
| `PREWARM_EPISODES` | `2` | Episodes looked up ahead during playback |
| `STREAM_WAIT_MS` | `12000` | Longest a player waits for AIOStreams; the lookup still finishes and is cached |
| `STREAM_TTL_SEC` / `STREAM_STALE_SEC` | `1200` / `21600` | How long stream lists are fresh / still served while refreshing |
| `UPCOMING_LIBRARY` | `true` | Upcoming library and home row for favourited series |
| `UPCOMING_DAYS` | `60` | How far ahead Upcoming looks |
| `MAX_SOURCES` | `25` | Versions shown per title |
| `CHECK_MATCHES` | `true` | Remove results for a different show, episode or year |
| `ONLY_CACHED` | `false` | Hide results your debrid service hasn't cached |
| `SOURCE_NAMES` | `clean` | `clean` labels like `4K DV · REMUX · TrueHD 7.1 Atmos · 58 GB · TorBox ⚡`, or `aiostreams` for your formatter's text |
| `STREAM_MODE` | `redirect` | `redirect` (fastest) or `proxy` (video passes through AIOFin) |
| `PROXY_INTERNAL_HOSTS` | `true` | Proxy links on LAN/Docker addresses that outside players can't reach |
| `SUBTITLES` | `true` | Add subtitles from AIOStreams and the add-ons below |
| `SUBTITLE_ADDONS` | OpenSubtitles v3 | Extra Stremio subtitle add-ons, comma-separated |
| `SUBTITLE_LANGUAGES` | `eng` | Subtitle languages to offer (3-letter codes, comma-separated; empty = all) |
| `PROBE` | `true` | Read each stream's real tracks with ffprobe |
| `PROBE_TOP` | `3` | Results checked when a title is opened |
| `PROBE_WAIT_MS` | `4000` | How long a remuxing device waits for track info if Play is pressed instantly |
| `META_FALLBACK_URL` | Cinemeta | Metadata source when AIOStreams has none for a title |
| `IMAGE_MODE` | `redirect` | `redirect` or `proxy` for posters and backdrops |
| `TRANSCODE` | `true` | Remux and conversion (see below) |
| `REMUX_DEVICES` | `web,mobile` | Devices that always get a remux with AAC audio: any of `web`, `mobile`, `tv`, `desktop` |
| `HWACCEL` | `none` | `vaapi`, `qsv` or `nvenc` for conversion |
| `TRANSCODE_MAX_HEIGHT` | `1080` | Resolution cap for converted video |
| `TRANSCODE_AHEAD_SECS` | `90` | Conversion pauses once this far ahead of the viewer |
| `SUBTITLE_STYLE` | `plex` | Default subtitle look in Jellyfin Web: `plex` (smaller, outlined) or `jellyfin` |
| `EMBEDDED_SUBTITLES` | `true` | Offer subtitle tracks inside the file on web and phones too |
| `EMBEDDED_SUBTITLE_READERS` | `8` | Parts of the file read at once when pulling out its subtitles |
| `BURN_SUBTITLES` | `true` | Burn picture subtitles into the video for apps that can't draw them |
| `EXACT_SUBTITLE_SYNC` | `true` | Convert video for files without a keyframe index, so subtitles stay exactly in sync |
| `DEFAULT_AUDIO_LANGUAGE` | `eng` | Audio language picked by default (commentary tracks are skipped) |
| `PUBLIC_URL` | | The address apps should use (LAN discovery, links); e.g. `http://192.168.1.5:8096`. Learned automatically when unset |
| `PORT` | `8096` | HTTP port |

## Playback in different apps

**Sound on every device.** Web browsers and phones/tablets (`REMUX_DEVICES`) always get a remux: the video is copied untouched when the device can decode it, and the audio becomes stereo AAC, which every device plays. Dolby Digital, DD+, DTS and TrueHD never reach a device that would play them silently. Seeking anywhere works.

**TV boxes and desktop apps** (Android TV, Apple TV apps, Infuse, Kodi) play files directly whenever their device profile says they can handle the real tracks, and get the remux otherwise. If a file's codecs can't be confirmed, AIOFin assumes the hardest case for that device rather than risk silence.

**English audio by default.** Files often contain several audio tracks, and their own "default" flag is frequently a dub. AIOFin picks the track in `DEFAULT_AUDIO_LANGUAGE` (skipping commentary), tells direct-play apps to use it, and remuxes it for web and mobile. Picking another track in the player's audio menu switches the remux to it.

**Choosing a stream before playing.** In Jellyfin Web, a movie or episode page opens instantly and shows "Finding streams…" in the box next to the cast details; the **Version**, **Video**, **Audio** and **Subtitles** menus fill in as soon as AIOStreams answers. Picking a version that hasn't been checked yet reads its real tracks first ("Reading tracks…"), so the Audio menu always lists what's actually in the file. Play uses whatever is selected. Native apps (Swiftfin, Streamyfin, Jellyfin Android TV, Infuse and others) build their own details screen; AIOFin sends them every version with real tracks, so their **Version**, **Audio** and **Subtitles** pickers list them. For a title nobody has opened yet, those apps' details screen waits for AIOStreams (and up to a few seconds to read the tracks) before showing; after that, opening it again is instant.

**Switching streams in the player.** In Jellyfin Web, a Streams button sits next to Audio in the player controls. It lists every AIOStreams result for the title, and picking one restarts on it at the same position. The stream you choose is remembered for that title. Other apps don't allow added player buttons; in those, pick the stream with the version selector on the details page before playing. If a stream won't open during a remux, AIOFin moves on to the next one automatically.

**Subtitles stay in sync.** Two things keep them aligned:

- *The right subtitle file.* When a title is opened, AIOFin reads the top stream's OpenSubtitles hash and size (two small reads of the file's first and last 64 KiB) and sends them with the file name to the subtitle add-ons, as Stremio does. OpenSubtitles then puts subtitles made for that exact release (same cut, same frame rate) first.
- *An exact timeline in the remux.* Players time subtitles by the video's clock, and when playback starts mid-file (resume or seek), they set that clock from the first segment they load. AIOFin reads each file's keyframe index (MKV Cues or MP4 sync table, a few small range reads) and cuts segments exactly on keyframes, keeping the file's own timestamps, so every segment starts exactly where the playlist says. Measured error: under 0.03 s from the start and after resuming (previously about 2 s after a resume). Files without a keyframe index have their video converted with keyframes placed exactly, so the timeline stays exact for them too (`EXACT_SUBTITLE_SYNC`).

**Subtitles inside the file and from OpenSubtitles, side by side.** Subtitle tracks that are part of the video file are listed as "(in file)", e.g. "English SDH (in file)"; subtitles from add-ons are labelled by where they came from, e.g. "English (OpenSubtitles)". Apps that play files directly read in-file tracks themselves. For web and phones (remuxed playback), picking an in-file subtitle makes AIOFin read it out of the file: since subtitle lines are spread through the whole file, it reads the file in several parts at once (`EMBEDDED_SUBTITLE_READERS`, 8 by default), pulls out every text track in the same pass, and keeps the result, so other tracks and later plays are instant. Expect a short wait the first time on large files.

How each kind of in-file subtitle reaches web and phone apps:

| In the file | Jellyfin Web, Jellyfin iOS/Android | Swiftfin, Streamyfin (remuxed) |
|---|---|---|
| SRT / WebVTT | text | text |
| ASS / SSA (styled) | **styled**, with the file's own fonts (drawn by the player's libass) | plain text |
| PGS (Blu-ray pictures) | **pictures**, drawn by the player, no re-encode | burned into the video |
| VobSub (DVD pictures) | burned into the video | burned into the video |

Burning in converts the video while that subtitle is on (`BURN_SUBTITLES`); it reads a few seconds before a seek point, so a caption already on screen appears even when you resume mid-caption. Apps that play files directly (TV apps, Infuse) read every kind themselves.

**Choosing among add-on subtitles.** Per language, subtitles made for this exact release (same file name) come first, then hash matches and regular ones, then SDH/hearing-impaired, then AI-translated, and Forced last (they only translate foreign-language parts). Labels say which is which, e.g. "English SDH (OpenSubtitles)" or "English (OpenSubtitles, made for this release)".

**Subtitle look.** In Jellyfin Web and the Jellyfin iOS/Android apps, subtitles default to a Plex-like look: smaller text with a crisp black outline, one line from the bottom (`SUBTITLE_STYLE=plex`; `jellyfin` keeps Jellyfin's larger default). Anyone who changes size, edge or position in Jellyfin's own Subtitle settings keeps their choice. Native apps (Swiftfin, Streamyfin, Infuse, TV apps) draw subtitles themselves; use their subtitle size settings.

**Subtitles** come from AIOStreams and from OpenSubtitles v3 (or any Stremio subtitle add-ons you list), filtered to `SUBTITLE_LANGUAGES`, up to 8 per language. They're served in whichever format the player asks for: Jellyfin's JSON format (what Jellyfin Web and the iOS/Android apps load), WebVTT or SRT. Old Windows-1252 files are converted so accents display correctly, and styling codes players can't show are removed.

**The right show and episode.** AIOFin asks AIOStreams by IMDb id, never by name, so The Walking Dead and Fear the Walking Dead can't be confused at that step. But many indexers behind AIOStreams can only search by text and may return a similar-sounding show, a spin-off or the wrong episode. AIOFin checks each result's file name against what you opened (`CHECK_MATCHES`, on by default):

- **Show name:** must match after ignoring "the", "and", punctuation and country tags. "Fear the Walking Dead" is removed from The Walking Dead and vice versa; spin-offs like "Daryl Dixon" only match their own show; abbreviations such as TWD or SVU are understood.
- **Season and episode:** must match; multi-episode files and season packs that contain the episode are kept.
- **Year:** separates same-name shows and remakes (Doctor Who 2005 vs 1963, The Lion King 1994 vs 2019).
- Results that can't be judged (no file name, a title in another language, anime numbering) are kept. If every result looks wrong, they're all kept but marked ⚠ so there's still something to play.

The server log lists each removed result with the reason, and the admin timeline shows how many were removed per lookup. Turning on AIOStreams' own title and episode matching filters as well removes these results even earlier.

**Upcoming episodes.** Favourite a series (the heart button) and its next episodes appear in three places: an **Upcoming** library with a home-screen row in every Jellyfin app (each card starts with its air date, like "Today ·" or "Fri, Oct 9 ·"), and Jellyfin Web's **Upcoming** tab in TV libraries, grouped by date. Episodes airing today or within `UPCOMING_DAYS` are included, soonest first. Each person sees their own favourites. Episodes that haven't aired yet are marked unaired in every season list instead of showing a Play button that can't find streams, and no stream lookups are spent on them.

**Next up** is turned off; the row doesn't appear in any app. Autoplay of the next episode still works.

Pass a GPU into the container and set `HWACCEL` if many people watch on devices that need video converted (most remuxes only convert the audio, which is cheap).

## Docker networking notes

- If AIOStreams runs in the same Docker network and hands out links on its internal name (like `http://aiostreams:3000/…`), AIOFin rewrites them to your AIOStreams' public address when the manifest URL is public. If the manifest URL is itself internal, those links are proxied so remote players can still reach them.
- Port `7359/udp` lets apps find the server on your LAN. It's optional.
- Jellyfin Web is copied from the Remux image (`ghcr.io/lostb1t/remux:nightly`) at build time. To build it from source instead, use `docker/Dockerfile.web-source` (set `dockerfile:` in the compose file, or run `DOCKERFILE=docker/Dockerfile.web-source ./build-image.sh`). That takes several minutes and uses Node 24, which Jellyfin Web 12.1 requires.

## What's not included

AIOFin is deliberately narrow. Results that are only a torrent hash with no link (P2P without a debrid service) are skipped. Configure a debrid or Usenet service in AIOStreams. There's no local media, music, live TV, collections or SyncPlay. Picture-based in-file subtitles (PGS, VobSub) are only offered to apps that play the file directly. The in-player stream switcher is Jellyfin Web only.

## Troubleshooting

- **Jellyfin for Android TV.** It is built on Jellyfin's Kotlin SDK, which rejects any response missing a field Jellyfin's API marks as required, where other apps simply ignore gaps. `npm run test:androidtv` checks every response the app reads (sign-in, browsing, details, every playback path, WebSocket messages) against the exact SDK version the app uses.
- **Apps find the server on the LAN but can't connect** (common with Docker). LAN discovery has to tell apps an address they can reach, and inside Docker the server only knows its container address. AIOFin learns the right one from any device that reaches it (opening `/admin` from another device is enough) and remembers it; the admin Overview shows it under "Address apps find". To fix it explicitly, set `PUBLIC_URL`, e.g. `http://192.168.1.5:8096`.
- **Server logs:** `docker logs aiofin --tail 200`. Add `LOG_LEVEL: "debug"` to the compose file for more detail.
- **Did the container restart?** `docker ps` shows the uptime; `docker inspect -f '{{.RestartCount}}' aiofin` counts restarts.
- **Jellyfin Web problems:** open the browser's developer console (F12) on the page that misbehaves. Messages starting `failed to load alternate version item` are expected and harmless.
- **After updating,** reload Jellyfin Web with Ctrl+Shift+R so it picks up the new page script.

## Development

```sh
node test/mock-aiostreams.js   # fake AIOStreams on :7001 (needs test videos, see below)
DATA_DIR=./data node src/index.js
node test/match.test.js        # 61 title/episode matching cases
node test/e2e.js               # 165 end-to-end checks against the running server
node test/android-tv.test.js   # 47 responses checked against the Android TV app's SDK (fetches it with git)
```

The e2e test expects three sample files in `test/`. Generate them with ffmpeg:

```sh
ffmpeg -f lavfi -i testsrc2=size=1280x720:rate=24 -f lavfi -i sine -t 60 -c:v libx264 -c:a ac3 -ac 6 test/sample-h264-ac3.mkv
ffmpeg -f lavfi -i testsrc2=size=1920x1080:rate=24 -f lavfi -i sine -t 40 -c:v libx265 -c:a aac test/sample-hevc.mkv
ffmpeg -f lavfi -i testsrc2=size=1280x720:rate=24 -f lavfi -i sine=frequency=300 -f lavfi -i sine=frequency=600 -t 30 -map 0 -map 1 -map 2 \
  -c:v libx264 -c:a:0 aac -c:a:1 eac3 -ac:a:1 6 -metadata:s:a:0 language=spa -metadata:s:a:1 language=eng \
  -disposition:a:0 default -disposition:a:1 0 test/sample-multiaudio.mkv
```

Layout: `src/aio.js` (AIOStreams client and caches), `src/library.js` (Stremio metadata to Jellyfin items), `src/playback.js` (streams to versions, device decisions), `src/probe.js` (real track info), `src/transcode.js` (remux and conversion), `src/web.js` (Jellyfin Web, including the stream switcher), `src/routes/` (Jellyfin API), `admin/` (admin page).

## License

AGPL-3.0, the same as Remux, which this project is derived from. The admin page uses Remux's dashboard theme.
