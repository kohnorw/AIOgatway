# AIOFin

A Jellyfin-compatible server built for one job: turning your **AIOStreams** setup into a Jellyfin library that starts playing fast.

AIOStreams catalogs become Jellyfin libraries, its metadata fills the detail pages, and its stream results (from your debrid services, indexers and Usenet) become the versions you pick from. Any Jellyfin app works unchanged: Infuse, Swiftfin, Jellyfin for Android / Android TV, Streamyfin, Findroid and Jellyfin Web.

It's modelled on [Remux](https://github.com/lostb1t/remux) and uses the same look: Jellyfin Web 12.1 with the ElegantFin theme, and Remux's dashboard design for the admin page. Remux does much more (local files, torrents, music, IPTV). AIOFin drops all of that to focus on speed.

## Quick start

```sh
docker compose -f docker/compose.yml up -d --build
```

Then open `http://<server>:8096/admin`, create your admin account and paste your AIOStreams install link (the `…/manifest.json` URL from your AIOStreams configuration page). In any Jellyfin app, add the server `http://<server>:8096` and sign in.

To get a Docker image tarball for another machine, run `./build-image.sh`. It produces `aiofin-image.tar.gz`, which you load with `docker load -i aiofin-image.tar.gz`.

Without Docker, use Node.js 20+ and run `AIOSTREAMS_URL=… node src/index.js`. There are no dependencies to install. Point `WEB_PATH` at a Jellyfin Web build if you want the web client.

## How it gets streams fast

The first lookup for a title takes as long as AIOStreams takes. AIOFin makes sure that wait almost never happens when someone presses Play.

- **Looks up streams when a title is opened.** Opening a movie or episode starts the AIOStreams lookup in the background. By the time Play is pressed the list is cached, and Play answers in about 1 ms.
- **Prepares what you'll watch next.** Opening a series warms the episode you're most likely to play. While an episode plays, the next two are looked up, and the next one is refreshed in the last five minutes so autoplay is instant. The top of *Continue watching* is prepared too.
- **Reads the real tracks ahead of time.** When a title is opened, the top three cached results are checked with ffprobe (only the first few MB are read), so by the time Play is pressed the server knows each file's actual audio and video.
- **Shares lookups.** If several people or devices ask for the same title at once, AIOStreams is called once and everyone gets the result.
- **Serves stale lists instantly.** A stream list stays fresh for 20 minutes. After that it's still returned immediately while a refresh runs in the background. AIOStreams playback links resolve when opened, so an older list still plays.
- **Keeps the connection warm.** One pooled, kept-alive connection to AIOStreams means no TLS handshake per lookup.
- **Stays out of the video path.** Players get a redirect straight to the AIOStreams/debrid link. The server never relays video unless you ask it to.
- **Preloads libraries.** The first page of every library is fetched at startup and on a schedule, so home rows and library pages open instantly.

The admin page's **Overview** shows every recent lookup on a timeline against a 3-second target. It also has a speed test that measures AIOStreams with all caches skipped.

### Getting AIOStreams itself under 3 seconds

AIOFin can't make AIOStreams' own first lookup faster than its slowest add-on allows. In your AIOStreams configuration:

- Lower the per-add-on timeout. Slow scrapers that rarely return anything useful are usually what pushes lookups past 3 seconds.
- Remove add-ons and indexers you don't need.
- Turn on result caching if your AIOStreams version offers it.
- Run AIOStreams close to AIOFin, on the same machine or network if you can.

## Settings

Everything can be changed on the admin page, which overrides the environment. Environment variables set the defaults.

| Variable | Default | What it does |
|---|---|---|
| `AIOSTREAMS_URL` | | Your AIOStreams manifest URL |
| `ADMIN_USERNAME`, `ADMIN_PASSWORD` | | Create the admin on first start (otherwise use `/admin`) |
| `SERVER_NAME` | `AIOFin` | Name shown in Jellyfin apps |
| `PREFETCH_ON_OPEN` | `true` | Look up streams when a title is opened |
| `PREWARM_EPISODES` | `2` | Episodes looked up ahead during playback |
| `STREAM_WAIT_MS` | `12000` | Longest a player waits for AIOStreams; the lookup still finishes and is cached |
| `STREAM_TTL_SEC` / `STREAM_STALE_SEC` | `1200` / `21600` | How long stream lists are fresh / still served while refreshing |
| `UPCOMING_LIBRARY` | `true` | Upcoming library and home row for favourited series |
| `UPCOMING_DAYS` | `60` | How far ahead Upcoming looks |
| `MAX_SOURCES` | `25` | Versions shown per title |
| `ONLY_CACHED` | `false` | Hide results your debrid service hasn't cached |
| `SOURCE_NAMES` | `clean` | `clean` labels like `4K DV · REMUX · TrueHD 7.1 Atmos · 58 GB · TorBox ⚡`, or `aiostreams` for your formatter's text |
| `STREAM_MODE` | `redirect` | `redirect` (fastest) or `proxy` (video passes through AIOFin) |
| `PROXY_INTERNAL_HOSTS` | `true` | Proxy links on LAN/Docker addresses that outside players can't reach |
| `SUBTITLES` | `true` | Add subtitles from AIOStreams and the add-ons below |
| `SUBTITLE_ADDONS` | OpenSubtitles v3 | Extra Stremio subtitle add-ons, comma-separated |
| `SUBTITLE_LANGUAGES` | `eng` | Subtitle languages to offer (3-letter codes, comma-separated; empty = all) |
| `PROBE` | `true` | Read each stream's real tracks with ffprobe |
| `PROBE_TOP` | `3` | Results checked when a title is opened |
| `PROBE_WAIT_MS` | `4000` | How long a remuxing device waits for track info if Play is pressed instantly |
| `META_FALLBACK_URL` | Cinemeta | Metadata source when AIOStreams has none for a title |
| `IMAGE_MODE` | `redirect` | `redirect` or `proxy` for posters and backdrops |
| `TRANSCODE` | `true` | Remux and conversion (see below) |
| `REMUX_DEVICES` | `web,mobile` | Devices that always get a remux with AAC audio: any of `web`, `mobile`, `tv`, `desktop` |
| `HWACCEL` | `none` | `vaapi`, `qsv` or `nvenc` for conversion |
| `TRANSCODE_MAX_HEIGHT` | `1080` | Resolution cap for converted video |
| `TRANSCODE_AHEAD_SECS` | `90` | Conversion pauses once this far ahead of the viewer |
| `DEFAULT_AUDIO_LANGUAGE` | `eng` | Audio language picked by default (commentary tracks are skipped) |
| `PUBLIC_URL` | | Your external address, if behind a reverse proxy that doesn't send `X-Forwarded-*` |
| `PORT` | `8096` | HTTP port |

## Playback in different apps

**Sound on every device.** Web browsers and phones/tablets (`REMUX_DEVICES`) always get a remux: the video is copied untouched when the device can decode it, and the audio becomes stereo AAC, which every device plays. Dolby Digital, DD+, DTS and TrueHD never reach a device that would play them silently. Seeking anywhere works.

**TV boxes and desktop apps** (Android TV, Apple TV apps, Infuse, Kodi) play files directly whenever their device profile says they can handle the real tracks, and get the remux otherwise. If a file's codecs can't be confirmed, AIOFin assumes the hardest case for that device rather than risk silence.

**English audio by default.** Files often contain several audio tracks, and their own "default" flag is frequently a dub. AIOFin picks the track in `DEFAULT_AUDIO_LANGUAGE` (skipping commentary), tells direct-play apps to use it, and remuxes it for web and mobile. Picking another track in the player's audio menu switches the remux to it.

**Choosing a stream before playing.** In Jellyfin Web, a movie or episode page opens instantly and shows "Finding streams…" in the box next to the cast details; the **Version**, **Video**, **Audio** and **Subtitles** menus fill in as soon as AIOStreams answers. Picking a version that hasn't been checked yet reads its real tracks first ("Reading tracks…"), so the Audio menu always lists what's actually in the file. Play uses whatever is selected. Native apps (Swiftfin, Jellyfin Android TV, Infuse and others) build their own details screen; AIOFin sends them every version with real tracks, so their **Version**, **Audio** and **Subtitles** pickers list them. For a title nobody has opened yet, those apps' details screen waits for AIOStreams (and up to a few seconds to read the tracks) before showing; after that, opening it again is instant.

**Switching streams in the player.** In Jellyfin Web, a Streams button sits next to Audio in the player controls. It lists every AIOStreams result for the title, and picking one restarts on it at the same position. The stream you choose is remembered for that title. Other apps don't allow added player buttons; in those, pick the stream with the version selector on the details page before playing. If a stream won't open during a remux, AIOFin moves on to the next one automatically.

**Subtitles** come from AIOStreams and from OpenSubtitles v3 (or any Stremio subtitle add-ons you list), filtered to `SUBTITLE_LANGUAGES`, up to 8 per language. They're served in whichever format the player asks for: Jellyfin's JSON format (what Jellyfin Web and the iOS/Android apps load), WebVTT or SRT. Old Windows-1252 files are converted so accents display correctly, and styling codes players can't show are removed.

**Upcoming episodes.** Favourite a series (the heart button) and its next episodes appear in three places: an **Upcoming** library with a home-screen row in every Jellyfin app (each card starts with its air date, like "Today ·" or "Fri, Oct 9 ·"), and Jellyfin Web's **Upcoming** tab in TV libraries, grouped by date. Episodes airing today or within `UPCOMING_DAYS` are included, soonest first. Each person sees their own favourites. Episodes that haven't aired yet are marked unaired in every season list instead of showing a Play button that can't find streams, and no stream lookups are spent on them.

**Next up** is turned off; the row doesn't appear in any app. Autoplay of the next episode still works.

Pass a GPU into the container and set `HWACCEL` if many people watch on devices that need video converted (most remuxes only convert the audio, which is cheap).

## Docker networking notes

- If AIOStreams runs in the same Docker network and hands out links on its internal name (like `http://aiostreams:3000/…`), AIOFin rewrites them to your AIOStreams' public address when the manifest URL is public. If the manifest URL is itself internal, those links are proxied so remote players can still reach them.
- Port `7359/udp` lets apps find the server on your LAN. It's optional.
- Jellyfin Web is copied from the Remux image (`ghcr.io/lostb1t/remux:nightly`) at build time. To build it from source instead, use `docker/Dockerfile.web-source` (set `dockerfile:` in the compose file, or run `DOCKERFILE=docker/Dockerfile.web-source ./build-image.sh`). That takes several minutes and uses Node 24, which Jellyfin Web 12.1 requires.

## What's not included

AIOFin is deliberately narrow. Results that are only a torrent hash with no link (P2P without a debrid service) are skipped. Configure a debrid or Usenet service in AIOStreams. There's no local media, music, live TV, collections or SyncPlay. Embedded subtitle tracks are offered to direct-play apps; remuxed playback (web and mobile) offers external subtitles only. The in-player stream switcher is Jellyfin Web only.

## Troubleshooting

- **Server logs:** `docker logs aiofin --tail 200`. Add `LOG_LEVEL: "debug"` to the compose file for more detail.
- **Did the container restart?** `docker ps` shows the uptime; `docker inspect -f '{{.RestartCount}}' aiofin` counts restarts.
- **Jellyfin Web problems:** open the browser's developer console (F12) on the page that misbehaves. Messages starting `failed to load alternate version item` are expected and harmless.
- **After updating,** reload Jellyfin Web with Ctrl+Shift+R so it picks up the new page script.

## Development

```sh
node test/mock-aiostreams.js   # fake AIOStreams on :7001 (needs test videos, see below)
DATA_DIR=./data node src/index.js
node test/e2e.js               # 121 end-to-end checks against the running server
```

The e2e test expects three sample files in `test/`. Generate them with ffmpeg:

```sh
ffmpeg -f lavfi -i testsrc2=size=1280x720:rate=24 -f lavfi -i sine -t 60 -c:v libx264 -c:a ac3 -ac 6 test/sample-h264-ac3.mkv
ffmpeg -f lavfi -i testsrc2=size=1920x1080:rate=24 -f lavfi -i sine -t 40 -c:v libx265 -c:a aac test/sample-hevc.mkv
ffmpeg -f lavfi -i testsrc2=size=1280x720:rate=24 -f lavfi -i sine=frequency=300 -f lavfi -i sine=frequency=600 -t 30 -map 0 -map 1 -map 2 \
  -c:v libx264 -c:a:0 aac -c:a:1 eac3 -ac:a:1 6 -metadata:s:a:0 language=spa -metadata:s:a:1 language=eng \
  -disposition:a:0 default -disposition:a:1 0 test/sample-multiaudio.mkv
```

Layout: `src/aio.js` (AIOStreams client and caches), `src/library.js` (Stremio metadata to Jellyfin items), `src/playback.js` (streams to versions, device decisions), `src/probe.js` (real track info), `src/transcode.js` (remux and conversion), `src/web.js` (Jellyfin Web, including the stream switcher), `src/routes/` (Jellyfin API), `admin/` (admin page).

## License

AGPL-3.0, the same as Remux, which this project is derived from. The admin page uses Remux's dashboard theme.
