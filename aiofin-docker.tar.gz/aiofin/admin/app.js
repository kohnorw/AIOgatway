(function () {
  'use strict';

  var TARGET_MS = 3000;
  var AUTH = 'MediaBrowser Client="AIOFin Admin", Device="Browser", DeviceId="aiofin-admin", Version="1.0.0"';
  var app = document.getElementById('app');
  var state = { token: load('aiofin_token'), status: null, page: location.hash.replace('#', '') || 'overview', catalogs: null, speed: null, busy: {}, error: '' };
  var poll = null;

  function load(k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }
  function store(k, v) { try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(sel) { return app.querySelector(sel); }
  function $$(sel) { return Array.prototype.slice.call(app.querySelectorAll(sel)); }

  function api(method, path, body) {
    var headers = { 'content-type': 'application/json', 'x-emby-authorization': AUTH + (state.token ? ', Token="' + state.token + '"' : '') };
    return fetch(path, { method: method, headers: headers, body: body ? JSON.stringify(body) : undefined }).then(function (r) {
      return r.text().then(function (t) {
        var j = null; try { j = t ? JSON.parse(t) : null; } catch (e) {}
        if (r.status === 401 && path !== '/Users/AuthenticateByName') { store('aiofin_token', ''); state.token = ''; }
        if (!r.ok) { var err = new Error((j && j.error) || ('Request failed (' + r.status + ')')); err.status = r.status; throw err; }
        return j;
      });
    });
  }

  function toast(msg, ok) {
    var old = document.querySelector('.toast'); if (old) old.remove();
    var el = document.createElement('div');
    el.className = 'toast ' + (ok === false ? 'alert-error' : 'alert-success');
    el.setAttribute('role', 'status');
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(function () { el.remove(); }, 3200);
  }

  function refresh() {
    return api('GET', '/admin/api/status').then(function (s) { state.status = s; state.error = ''; render(); })
      .catch(function (e) { state.status = null; state.error = e.status === 401 ? '' : e.message; render(); });
  }

  // ── Shared bits ──────────────────────────────────────────────────────
  function fmtMs(ms) { return ms >= 1000 ? (ms / 1000).toFixed(ms >= 10000 ? 0 : 1) + ' s' : Math.round(ms) + ' ms'; }
  function ago(ts) {
    var s = Math.round((Date.now() - ts) / 1000);
    return s < 60 ? s + 's ago' : s < 3600 ? Math.round(s / 60) + 'm ago' : Math.round(s / 3600) + 'h ago';
  }
  var REASONS = { open: 'title opened', 'open-series': 'series opened', play: 'play pressed', 'next-episode': 'next episode, during playback', 'resume-row': 'continue watching row', 'speed-test': 'speed test', prefetch: 'prefetch' };
  function switchHtml(key, on, label) {
    return '<button type="button" role="switch" class="switch" data-key="' + key + '" data-kind="bool" aria-checked="' + !!on + '" aria-label="' + esc(label) + '" data-state="' + (on ? 'checked' : 'unchecked') + '"><span class="switch-thumb"></span></button>';
  }

  // ── Setup + login ────────────────────────────────────────────────────
  function setupView() {
    return '<div class="login-page"><form class="login-card" data-form="setup">' +
      '<div class="login-header"><span class="login-brand-label">AIOFin</span><h1 class="login-title">Set up your server</h1>' +
      '<p class="login-subtitle">Create the admin account and connect AIOStreams.</p></div>' +
      '<div class="login-body">' +
      (state.error ? '<div class="alert-error">' + esc(state.error) + '</div>' : '') +
      '<div class="field"><label class="field-label" for="su-user">Username</label><input class="field-input" id="su-user" name="username" autocomplete="username" required></div>' +
      '<div class="field"><label class="field-label" for="su-pass">Password</label><input class="field-input" id="su-pass" name="password" type="password" autocomplete="new-password" required></div>' +
      '<div class="field"><label class="field-label" for="su-url">AIOStreams manifest URL</label><input class="field-input" id="su-url" name="aioUrl" placeholder="https://aiostreams.example.com/stremio/…/manifest.json">' +
      '<p class="field-hint">In AIOStreams, open your configuration and copy the install link. You can add this later.</p></div>' +
      '<button class="btn btn-primary login-btn" type="submit">Create account</button></div></form></div>';
  }
  function loginView() {
    return '<div class="login-page"><form class="login-card" data-form="login">' +
      '<div class="login-header"><span class="login-brand-label">AIOFin</span><h1 class="login-title">Sign in</h1>' +
      '<p class="login-subtitle">Use an administrator account.</p></div>' +
      '<div class="login-body">' +
      (state.error ? '<div class="alert-error">' + esc(state.error) + '</div>' : '') +
      '<div class="field"><label class="field-label" for="li-user">Username</label><input class="field-input" id="li-user" name="username" autocomplete="username" required></div>' +
      '<div class="field"><label class="field-label" for="li-pass">Password</label><input class="field-input" id="li-pass" name="password" type="password" autocomplete="current-password"></div>' +
      '<button class="btn btn-primary login-btn" type="submit">Sign in</button>' +
      '<a class="field-hint" href="/web/">Go to Jellyfin Web instead</a></div></form></div>';
  }

  // ── Layout ───────────────────────────────────────────────────────────
  var PAGES = [['overview', 'Overview'], ['libraries', 'Libraries'], ['playback', 'Playback'], ['users', 'Users'], ['plugins', 'Plugins'], ['appearance', 'Appearance']];
  function shell(inner) {
    var s = state.status;
    var nav = PAGES.map(function (p) {
      return '<button class="nav-item' + (state.page === p[0] ? ' nav-item-active' : '') + '" data-nav="' + p[0] + '"' + (state.page === p[0] ? ' aria-current="page"' : '') + '>' + p[1] + '</button>';
    }).join('');
    var title = (PAGES.filter(function (p) { return p[0] === state.page; })[0] || PAGES[0])[1];
    return '<div class="layout">' +
      '<aside class="sidebar' + (state.navOpen ? ' sidebar-open' : '') + '"><div class="sidebar-brand">' +
      '<span class="brand-label">AIOFin</span><p class="brand-title">' + esc(s.serverName) + '</p></div>' +
      '<nav class="sidebar-nav" aria-label="Admin">' + nav + '</nav>' +
      '<div class="sidebar-footer"><a class="nav-item" href="/web/">Open Jellyfin Web</a><button class="nav-item" data-action="logout">Sign out</button></div></aside>' +
      (state.navOpen ? '<div class="sidebar-overlay" data-action="nav-close"></div>' : '') +
      '<main class="main"><header class="main-header"><button class="hamburger" data-action="nav-open" aria-label="Open menu">☰</button><h1 class="main-title">' + title + '</h1></header>' +
      '<div class="content">' + inner + '</div></main></div>';
  }

  // ── Overview ─────────────────────────────────────────────────────────

  function overviewView() {
    var s = state.status;
    var conn = s.manifestError
      ? '<p><span class="status-dot bad"></span>Can\'t reach AIOStreams: ' + esc(s.manifestError) + '</p>'
      : s.manifest
        ? '<p><span class="status-dot ok"></span>Connected to <strong>' + esc(s.manifest.name || 'AIOStreams') + '</strong> ' + esc(s.manifest.version || '') + ', ' + s.manifest.catalogs + ' catalogs</p>'
        : '<p><span class="status-dot"></span>Not connected. Paste your AIOStreams manifest URL to get started.</p>';
    var sp = state.speed;
    var speedOut = '';
    if (sp && sp.ok) {
      speedOut = '<div class="speed-result"><div><div class="speed-num">' + fmtMs(sp.ms) + '</div><div class="speed-label">First lookup from AIOStreams</div></div>' +
        '<div><div class="speed-num">' + fmtMs(sp.cachedMs) + '</div><div class="speed-label">Same title, from cache</div></div>' +
        '<div><div class="speed-num">' + sp.count + '</div><div class="speed-label">Playable results</div></div></div>' +
        (sp.top.length ? '<ul class="result-list">' + sp.top.map(function (x) { return '<li>' + esc(x.name) + '</li>'; }).join('') + '</ul>' : '') +
        (sp.ms > TARGET_MS ? '<div class="alert-error">Over 3 s. The first lookup is set by AIOStreams: lower its scraper timeouts and turn on its result caching. Titles people open are looked up in advance, so Play stays instant either way.</div>' : '');
    } else if (sp && !sp.ok) {
      speedOut = '<div class="alert-error">Lookup failed after ' + fmtMs(sp.ms) + ': ' + esc(sp.error) + '</div>';
    }
    var streamsCache = (s.caches || []).filter(function (c) { return c.name === 'streams'; })[0] || {};
    var hitRate = streamsCache.hits + streamsCache.staleHits + streamsCache.misses
      ? Math.round(100 * (streamsCache.hits + streamsCache.staleHits) / (streamsCache.hits + streamsCache.staleHits + streamsCache.misses)) + '%' : 'n/a';
    var up = s.uptime > 86400 ? Math.floor(s.uptime / 86400) + 'd' : s.uptime > 3600 ? Math.floor(s.uptime / 3600) + 'h' : Math.floor(s.uptime / 60) + 'm';

    return '<section class="card"><div class="card-header"><h2 class="card-title">AIOStreams</h2></div><div class="card-body">' + conn +
      '<form class="inline" data-form="connect"><div class="field"><label class="field-label" for="aio-url">Manifest URL</label>' +
      '<input class="field-input" id="aio-url" name="url" value="' + esc(s.settings.aioUrl) + '" placeholder="https://…/manifest.json" spellcheck="false"></div>' +
      '<button class="btn btn-ghost" type="button" data-action="test-url">Test</button><button class="btn btn-primary" type="submit">Save</button></form>' +
      '<div id="test-out"></div></div></section>' +


      '<div class="grid-2"><section class="card"><div class="card-header"><h2 class="card-title">Speed test</h2></div><div class="card-body">' +
      '<p class="field-hint">Asks AIOStreams for one title with every cache skipped, then again from cache.</p>' +
      '<form class="inline" data-form="speed"><div class="field narrow"><label class="field-label" for="sp-type">Type</label><select class="select-input" id="sp-type" name="type"><option value="movie">Movie</option><option value="series">Episode</option></select></div>' +
      '<div class="field"><label class="field-label" for="sp-id">IMDb ID</label><input class="field-input" id="sp-id" name="id" placeholder="tt0111161" spellcheck="false"></div>' +
      '<button class="btn btn-primary" type="submit"' + (state.busy.speed ? ' disabled' : '') + '>' + (state.busy.speed ? 'Testing…' : 'Run test') + '</button></form>' +
      speedOut + '</div></section>' +

      '<section class="card"><div class="card-header"><h2 class="card-title">Server</h2></div><div class="card-body">' +
      '<div class="kv-row"><span class="kv-label">Uptime</span><span class="kv-value">' + up + '</span></div>' +
      '<div class="kv-row"><span class="kv-label">Stream lists cached</span><span class="kv-value">' + (streamsCache.size || 0) + '</span></div>' +
      '<div class="kv-row"><span class="kv-label">Served from cache</span><span class="kv-value">' + hitRate + '</span></div>' +
      '<div class="kv-row"><span class="kv-label">Browser fallback</span><span class="kv-value">' + (s.ffmpeg ? 'Ready' : 'Off (ffmpeg missing or disabled)') + '</span></div>' +
      '<div class="kv-row"><span class="kv-label">Active transcodes</span><span class="kv-value">' + (s.transcodes || []).length + '</span></div>' +
      '<div class="kv-row"><span class="kv-label">Address apps find</span><span class="kv-value">' + esc(s.discoveryAddress || '') + '</span></div>' +
      '<div class="form-actions"><button class="btn btn-ghost" data-action="clear-cache">Clear caches</button></div>' +
      '</div></section></div>';
  }

  // ── Libraries ────────────────────────────────────────────────────────
  function librariesView() {
    if (!state.status.configured) return '<div class="card"><div class="card-body"><div class="empty-state">Connect AIOStreams on the Overview page first.</div></div></div>';
    if (!state.catalogs) { loadCatalogs(); return '<div class="card"><div class="card-body"><p class="loading-text">Loading catalogs…</p></div></div>'; }
    var browse = state.catalogs.filter(function (c) { return c.browsable; });
    var search = state.catalogs.filter(function (c) { return !c.browsable && c.searchable; });
    function row(c, i, list) {
      return '<div class="cat-row' + (c.enabled ? '' : ' off') + '" data-cat="' + esc(c.key) + '">' +
        switchHtml('cat:' + c.key, c.enabled, 'Show ' + c.originalName) +
        '<div><label class="sr-only" for="n' + i + '">Library name</label><input class="field-input" id="n' + i + '" data-name="' + esc(c.key) + '" value="' + esc(c.name === c.originalName ? '' : c.name) + '" placeholder="' + esc(c.originalName) + '">' +
        '<div class="cat-sub">' + esc(c.type) + ' · ' + esc(c.id) + (c.searchable ? ' · searchable' : '') + '</div></div>' +
        (list ? '<div class="catalog-actions"><button class="btn btn-ghost icon-btn" data-move="-1" data-key="' + esc(c.key) + '" aria-label="Move up"' + (i === 0 ? ' disabled' : '') + '>↑</button>' +
          '<button class="btn btn-ghost icon-btn" data-move="1" data-key="' + esc(c.key) + '" aria-label="Move down"' + (i === list.length - 1 ? ' disabled' : '') + '>↓</button></div>' : '<span></span>') +
        '</div>';
    }
    return '<section class="card"><div class="card-header"><h2 class="card-title">Libraries</h2><span class="field-hint">Each AIOStreams catalog becomes a library, in this order</span></div>' +
      '<div class="card-body tight">' + (browse.length ? browse.map(function (c, i) { return row(c, i, browse); }).join('') : '<div class="empty-state">Your AIOStreams setup has no browsable catalogs.</div>') + '</div></section>' +
      (search.length ? '<section class="card"><div class="card-header"><h2 class="card-title">Search-only catalogs</h2><span class="field-hint">Used when someone searches</span></div><div class="card-body tight">' +
        search.map(function (c, i) { return row(c, 1000 + i, null); }).join('') + '</div></section>' : '') +
      '<div class="form-actions"><button class="btn btn-primary" data-action="save-catalogs">Save libraries</button></div>';
  }
  function loadCatalogs() {
    api('GET', '/admin/api/catalogs').then(function (c) { state.catalogs = c; render(); }).catch(function (e) { toast(e.message, false); });
  }

  // ── Playback settings ────────────────────────────────────────────────
  var GROUPS = [
    ['Speed', [
      ['prefetchOnOpen', 'bool', 'Look up streams when a title is opened', 'Off: streams are looked up only when Play is pressed or the version picker opens. On: also when a movie, series or Continue watching row is opened, so Play is instant.'],
      ['prewarmEpisodes', 'int', 'Episodes to prepare ahead', 'While an episode plays, look up the next ones in the background. 0 turns this off.'],
      ['streamWaitMs', 'int', 'Longest wait for streams (ms)', 'After this, the player is told there are no streams. The lookup still finishes and is cached.'],
      ['streamTtlSec', 'int', 'Reuse stream lists for (seconds)', 'Older lists are still served instantly and refreshed in the background.'],
      ['keepWarm', 'bool', 'Keep the connection to AIOStreams open', 'Skips the connection handshake on every lookup.'],
      ['warmCatalogs', 'bool', 'Preload libraries', 'Fetches the first page of every library at startup and on a schedule.'],
    ]],
    ['Streams', [
      ['maxSources', 'int', 'Versions per title', 'How many AIOStreams results appear in the version picker, in AIOStreams\' order.'],
      ['onlyCached', 'bool', 'Only show cached results', 'Hides results your debrid service would still have to download.'],
      ['checkMatches', 'bool', 'Check results are for the right title', 'Drops results whose file name is for a different show, episode or year, such as Fear the Walking Dead when you opened The Walking Dead.'],
      ['sourceNames', 'select:clean=Clean labels|aiostreams=AIOStreams formatter', 'Version names', 'Clean labels read like "4K DV · REMUX · TorBox ⚡". The formatter option uses your AIOStreams text.'],
      ['streamMode', 'select:redirect=Redirect (fastest)|proxy=Proxy through this server', 'Playback route', 'Redirect sends players straight to the link. Proxy passes all video through this server.'],
      ['fuse', 'bool', 'Play through FUSE files', 'When Play is pressed, the chosen stream becomes a local file (the AIOGateway mount) with a memory cache, read-ahead and automatic link repair, for fast starts and seeking. Video then passes through this server. Needs /dev/fuse in the container.'],
      ['fuseWaitMs', 'int', 'FUSE wait (ms)', 'Longest Play waits for the file before using the link directly.'],
      ['proxyInternal', 'bool', 'Proxy links on local addresses', 'For links on a LAN or Docker address that players outside your network can\'t reach.'],
      ['probe', 'bool', 'Read each stream\'s real tracks', 'Checks the actual audio and video in the top results when a title is opened, so the right audio track is picked and nothing plays silently.'],
    ]],
    ['Exclusions', [
      ['excludeKeywords', 'text', 'Exclude keywords', 'Comma-separated words or phrases, for example 3D, CAM, HDTS. Results whose file name or AIOStreams text contains one as a whole word are hidden. Not case-sensitive.'],
      ['excludeFileTypes', 'text', 'Exclude file types', 'Comma-separated file extensions, for example rar, zip, iso. Results for these files are hidden. Leave empty to allow every type.'],
    ]],
    ['Audio and subtitles', [
      ['defaultAudioLang', 'text', 'Audio language', 'Three-letter code, for example eng. This track is picked by default; commentary tracks are skipped.'],
      ['subtitles', 'bool', 'Subtitles', 'Adds subtitles from AIOStreams and the subtitle add-ons below.'],
      ['subtitleStyle', 'select:plex=Plex-like|jellyfin=Jellyfin default', 'Subtitle look in Jellyfin Web', 'Default for anyone who hasn\'t changed it in Jellyfin\'s own subtitle settings. Plex-like: smaller text with a crisp black outline, closer to the bottom. Applies to Jellyfin Web and the Jellyfin iOS/Android apps.'],
      ['subtitleAddons', 'text', 'Subtitle add-ons', 'Stremio subtitle add-on addresses, comma-separated. OpenSubtitles v3 is included by default.'],
      ['subtitleLanguages', 'text', 'Subtitle languages', 'Three-letter codes, comma-separated, for example eng,spa. Leave empty for every language.'],
      ['embeddedSubtitles', 'bool', 'Subtitles inside the file on web and phones', 'Offers the file\'s own text subtitle tracks, marked "(in file)", next to OpenSubtitles. Picking one reads them out of the file the first time.'],
      ['burnSubtitles', 'bool', 'Burn in picture subtitles', 'PGS and VobSub subtitles are drawn into the video for apps that can\'t show them (this converts the video while one is on).'],
      ['embeddedSubChunks', 'int', 'Parallel readers', 'How many parts of the file are read at once when pulling out its subtitles. More is faster, but debrid services may answer \'too many requests\' (429) above 2–3.'],
    ]],
    ['Upcoming episodes', [
      ['upcomingLibrary', 'bool', 'Upcoming library', 'Adds an "Upcoming" library and home-screen row with the next episodes of every series a person has favourited.'],
      ['upcomingDays', 'int', 'Look ahead (days)', 'Episodes airing today or within this many days are shown.'],
    ]],
    ['Remux and conversion', [
      ['transcode', 'bool', 'Remux and convert', 'Repackages streams for devices that can\'t play a file as-is. Video is copied when possible; audio becomes AAC, which every device plays.'],
      ['remuxDevices', 'text', 'Always remux on', 'Comma-separated: web (Jellyfin Web, Jellyfin iOS/Android apps), mobile, tv, desktop (native apps like Swiftfin, Streamyfin, Infuse). Native apps not listed play files directly when their player supports them, so in-file subtitles and audio work instantly.'],
      ['hwaccel', 'select:none=Off (CPU)|vaapi=Intel/AMD (VAAPI)|qsv=Intel Quick Sync|nvenc=NVIDIA (NVENC)', 'Hardware acceleration', 'Requires passing the GPU into the container.'],
      ['transcodeMaxHeight', 'int', 'Maximum height', 'Converted video is capped at this resolution.'],
      ['transcodeAheadSec', 'int', 'Convert ahead (seconds)', 'Conversion pauses once it is this far ahead of the viewer.'],
    ]],
  ];
  function control(key, kind, label, val) {
    if (kind === 'bool') return switchHtml(key, val, label);
    if (kind.indexOf('select:') === 0) {
      return '<select class="select-input" data-key="' + key + '" data-kind="text" aria-label="' + esc(label) + '">' + kind.slice(7).split('|').map(function (o) {
        var kv = o.split('='); return '<option value="' + kv[0] + '"' + (String(val) === kv[0] ? ' selected' : '') + '>' + esc(kv[1]) + '</option>';
      }).join('') + '</select>';
    }
    return '<input class="field-input" data-key="' + key + '" data-kind="' + kind + '" aria-label="' + esc(label) + '" value="' + esc(val) + '"' + (kind === 'int' ? ' inputmode="numeric"' : '') + '>';
  }
  function playbackView() {
    var st = state.status.settings;
    return GROUPS.map(function (g) {
      return '<section class="card"><div class="card-header"><h2 class="card-title">' + g[0] + '</h2></div><div class="card-body" style="gap:0">' +
        g[1].map(function (it) {
          return '<div class="setting-row"><div class="setting-text"><div class="setting-name">' + esc(it[2]) + '</div><div class="setting-desc">' + esc(it[3]) + '</div></div>' +
            '<div class="setting-control">' + control(it[0], it[1], it[2], st[it[0]]) + '</div></div>';
        }).join('') + '</div></section>';
    }).join('') + '<div class="form-actions"><button class="btn btn-primary" data-action="save-settings">Save settings</button></div>';
  }

  // ── Users ────────────────────────────────────────────────────────────
  function usersView() {
    var users = state.status.users;
    return '<section class="card"><div class="card-header"><h2 class="card-title">People who can sign in</h2></div><div class="card-body tight">' +
      users.map(function (u) {
        return '<div class="user-row"><div><div class="user-name">' + esc(u.name) + (u.isAdmin ? ' <span class="chip">Admin</span>' : '') + '</div>' +
          '<div class="user-meta">' + (u.lastLogin ? 'Last signed in ' + new Date(u.lastLogin).toLocaleString() : 'Never signed in') + '</div></div>' +
          '<div class="catalog-actions"><button class="btn btn-ghost" data-pw="' + u.id + '" data-uname="' + esc(u.name) + '">Change password</button>' +
          '<button class="btn btn-ghost" data-del="' + u.id + '" data-uname="' + esc(u.name) + '">Delete</button></div></div>';
      }).join('') + '</div></section>' +
      '<section class="card"><div class="card-header"><h2 class="card-title">Add a person</h2></div><div class="card-body">' +
      '<form class="inline" data-form="add-user"><div class="field"><label class="field-label" for="nu-name">Username</label><input class="field-input" id="nu-name" name="name" required autocomplete="off"></div>' +
      '<div class="field"><label class="field-label" for="nu-pass">Password</label><input class="field-input" id="nu-pass" name="password" type="password" autocomplete="new-password"></div>' +
      '<label class="check-row"><input type="checkbox" name="isAdmin"> Administrator</label>' +
      '<button class="btn btn-primary" type="submit">Add person</button></form>' +
      '<p class="field-hint">Each person gets their own Continue watching, favourites and stream choices.</p></div></section>';
  }

  // ── Plugins ──────────────────────────────────────────────────────────
  function pluginsView() {
    if (!state.plugins) { loadPlugins(); return '<section class="card"><div class="card-body"><p class="loading-text">Loading plugins…</p></div></section>'; }
    var list = state.plugins;
    var rows = list.length ? list.map(function (p, i) {
      var where = p.url ? '<a href="' + esc(p.url) + '" target="_blank" rel="noopener">' + esc(p.url) + '</a>' : 'Pasted code · ' + Math.max(1, Math.round((p.size || 0) / 1024)) + ' KB';
      return '<div class="plugin-row' + (p.enabled ? '' : ' off') + '">' +
        '<button type="button" role="switch" class="switch" data-plugin-toggle="' + p.id + '" aria-checked="' + !!p.enabled + '" data-state="' + (p.enabled ? 'checked' : 'unchecked') + '" aria-label="Enable ' + esc(p.name) + '"><span class="switch-thumb"></span></button>' +
        '<div class="plugin-main"><div class="user-name">' + esc(p.name) + ' <span class="chip">' + p.kind.toUpperCase() + '</span></div><div class="user-meta plugin-src">' + where + '</div></div>' +
        '<div class="catalog-actions">' +
        '<button class="btn btn-ghost" data-plugin-move="-1" data-pid="' + p.id + '" aria-label="Load earlier"' + (i === 0 ? ' disabled' : '') + '>↑</button>' +
        '<button class="btn btn-ghost" data-plugin-move="1" data-pid="' + p.id + '" aria-label="Load later"' + (i === list.length - 1 ? ' disabled' : '') + '>↓</button>' +
        '<button class="btn btn-ghost" data-plugin-del="' + p.id + '" data-pname="' + esc(p.name) + '">Remove</button></div></div>';
    }).join('') : '<div class="empty-state">No plugins installed. Add one below.</div>';
    return '<section class="card"><div class="card-header"><h2 class="card-title">Installed plugins</h2><span class="field-hint">Loaded into Jellyfin Web in this order</span></div>' +
      '<div class="card-body tight">' + rows + '</div></section>' +
      '<section class="card"><div class="card-header"><h2 class="card-title">Install a plugin</h2></div><div class="card-body">' +
      '<form data-form="add-plugin" class="plugin-form">' +
      '<div class="field"><label class="field-label" for="pl-url">Script or stylesheet URL</label><input class="field-input" id="pl-url" name="url" type="url" placeholder="https://cdn.jsdelivr.net/gh/user/repo@main/plugin.js" autocomplete="off"></div>' +
      '<div class="plugin-form-row"><div class="field"><label class="field-label" for="pl-name">Name (optional)</label><input class="field-input" id="pl-name" name="name" autocomplete="off"></div>' +
      '<div class="field narrow"><label class="field-label" for="pl-kind">Type</label><select class="select-input" id="pl-kind" name="kind"><option value="">Detect</option><option value="js">JavaScript</option><option value="css">CSS</option></select></div></div>' +
      '<details class="plugin-paste"><summary>Or paste the code instead</summary><div class="field"><label class="field-label" for="pl-code">Code</label><textarea class="field-input" id="pl-code" name="code" spellcheck="false" placeholder="// JavaScript or CSS"></textarea></div></details>' +
      '<div class="form-actions"><button class="btn btn-primary" type="submit">Install</button></div></form>' +
      '<p class="field-hint">Plugins run in Jellyfin Web: browsers and the Jellyfin iOS/Android apps. Native apps (Swiftfin, Infuse, TV apps) don\'t load them. After installing, reload Jellyfin Web (Ctrl+Shift+R). Only install code you trust: it runs with the signed-in person\'s access.</p>' +
      '<p class="field-hint">Server plugins from Jellyfin\'s catalog (.dll files) can\'t run here, because AIOFin isn\'t Jellyfin\'s .NET server. Many of them, themes especially, also publish their JavaScript or CSS, which works here.</p>' +
      '</div></section>';
  }
  function loadPlugins() {
    api('GET', '/admin/api/plugins').then(function (l) { state.plugins = l; render(); }).catch(function (e) { state.plugins = []; toast(e.message, false); render(); });
  }

  // ── Appearance ───────────────────────────────────────────────────────
  function appearanceView() {
    var st = state.status.settings;
    var theme = load('theme') || 'auto';
    return '<section class="card"><div class="card-header"><h2 class="card-title">Server</h2></div><div class="card-body">' +
      '<div class="field"><label class="field-label" for="ap-name">Server name</label><input class="field-input" id="ap-name" data-key="serverName" data-kind="text" value="' + esc(st.serverName) + '">' +
      '<p class="field-hint">Shown in Jellyfin apps when they find this server.</p></div>' +
      '<div class="field"><label class="field-label" for="ap-css">Jellyfin Web CSS</label><textarea class="field-input" id="ap-css" data-key="customCss" data-kind="text" spellcheck="false" placeholder="Empty uses ElegantFin, the same theme Remux ships with.">' + esc(st.customCss) + '</textarea>' +
      '<p class="field-hint">Leave empty for the ElegantFin theme. Anything here replaces it.</p></div>' +
      '<div class="form-actions"><button class="btn btn-primary" data-action="save-settings">Save appearance</button></div></div></section>' +
      '<section class="card"><div class="card-header"><h2 class="card-title">This admin page</h2></div><div class="card-body">' +
      '<div class="field narrow"><label class="field-label" for="ap-theme">Colour scheme</label><select class="select-input" id="ap-theme" data-action-change="theme">' +
      ['auto', 'light', 'dark'].map(function (t) { return '<option value="' + t + '"' + (theme === t ? ' selected' : '') + '>' + ({ auto: 'Match system', light: 'Light', dark: 'Dark' })[t] + '</option>'; }).join('') +
      '</select></div></div></section>';
  }

  // ── Render ───────────────────────────────────────────────────────────
  function render() {
    clearInterval(poll);
    var s = state.status;
    if (!s) { app.innerHTML = state.error ? '<div class="login-page"><div class="alert-error">' + esc(state.error) + '</div></div>' : loginView(); return; }
    if (s.setupNeeded) { app.innerHTML = setupView(); return; }
    var views = { overview: overviewView, libraries: librariesView, playback: playbackView, users: usersView, plugins: pluginsView, appearance: appearanceView };
    app.innerHTML = shell((views[state.page] || overviewView)());
  }

  // ── Events ───────────────────────────────────────────────────────────
  function collectSettings() {
    var patch = {};
    $$('[data-key]').forEach(function (el) {
      var k = el.getAttribute('data-key'); var kind = el.getAttribute('data-kind');
      if (!kind || k.indexOf('cat:') === 0) return;
      if (kind === 'bool') patch[k] = el.getAttribute('aria-checked') === 'true';
      else if (kind === 'int') patch[k] = parseInt(el.value, 10) || 0;
      else patch[k] = el.value;
    });
    return patch;
  }

  app.addEventListener('click', function (e) {
    var t = e.target.closest('button, [data-action]');
    if (!t) return;
    var nav = t.getAttribute('data-nav');
    if (nav) { state.page = nav; state.navOpen = false; history.replaceState(null, '', '#' + nav); if (nav === 'libraries') state.catalogs = null; if (nav === 'plugins') state.plugins = null; render(); return; }
    var ptog = t.getAttribute('data-plugin-toggle');
    if (ptog) {
      var pon = t.getAttribute('aria-checked') !== 'true';
      api('POST', '/admin/api/plugins/' + ptog, { enabled: pon }).then(function () { toast(pon ? 'Enabled. Reload Jellyfin Web to apply.' : 'Disabled. Reload Jellyfin Web to apply.'); loadPlugins(); }).catch(function (er) { toast(er.message, false); });
      return;
    }
    var pmove = t.getAttribute('data-plugin-move');
    if (pmove) { api('POST', '/admin/api/plugins/' + t.getAttribute('data-pid') + '/move', { dir: parseInt(pmove, 10) }).then(loadPlugins); return; }
    var pdel = t.getAttribute('data-plugin-del');
    if (pdel) {
      if (!confirm('Remove ' + t.getAttribute('data-pname') + '?')) return;
      api('DELETE', '/admin/api/plugins/' + pdel).then(function () { toast('Removed'); loadPlugins(); }).catch(function (er) { toast(er.message, false); });
      return;
    }
    if (t.getAttribute('role') === 'switch') {
      var on = t.getAttribute('aria-checked') !== 'true';
      t.setAttribute('aria-checked', on); t.setAttribute('data-state', on ? 'checked' : 'unchecked');
      var row = t.closest('.cat-row'); if (row) row.classList.toggle('off', !on);
      return;
    }
    var move = t.getAttribute('data-move');
    if (move) {
      var key = t.getAttribute('data-key');
      syncCatalogEdits();
      var browse = state.catalogs.filter(function (c) { return c.browsable; });
      var i = browse.findIndex(function (c) { return c.key === key; }); var j = i + parseInt(move, 10);
      if (j < 0 || j >= browse.length) return;
      var tmp = browse[i]; browse[i] = browse[j]; browse[j] = tmp;
      state.catalogs = browse.concat(state.catalogs.filter(function (c) { return !c.browsable; }));
      render(); var b = app.querySelector('[data-move="' + move + '"][data-key="' + CSS.escape(key) + '"]'); if (b && !b.disabled) b.focus();
      return;
    }
    var del = t.getAttribute('data-del');
    if (del) {
      if (!confirm('Delete ' + t.getAttribute('data-uname') + '? Their watch history is removed too.')) return;
      api('DELETE', '/admin/api/users/' + del).then(function () { toast('Deleted ' + t.getAttribute('data-uname')); refresh(); }).catch(function (er) { toast(er.message, false); });
      return;
    }
    var pw = t.getAttribute('data-pw');
    if (pw) {
      var np = prompt('New password for ' + t.getAttribute('data-uname') + ' (leave empty for none)');
      if (np === null) return;
      api('POST', '/admin/api/users/' + pw + '/password', { password: np }).then(function () { toast('Password changed'); }).catch(function (er) { toast(er.message, false); });
      return;
    }
    switch (t.getAttribute('data-action')) {
      case 'logout': api('POST', '/Sessions/Logout').catch(function () {}); store('aiofin_token', ''); state.token = ''; state.status = null; render(); break;
      case 'nav-open': state.navOpen = true; render(); break;
      case 'nav-close': state.navOpen = false; render(); break;
      case 'test-url': {
        var out = $('#test-out'); out.innerHTML = '<p class="loading-text">Testing…</p>';
        api('POST', '/admin/api/test-url', { url: $('#aio-url').value }).then(function (r) {
          out.innerHTML = r.ok
            ? '<div class="alert-success">Reached ' + esc(r.name || 'AIOStreams') + ' ' + esc(r.version || '') + ' in ' + fmtMs(r.ms) + '. ' + r.catalogs + ' catalogs, provides ' + esc(r.resources.join(', ')) + '.</div>'
            : '<div class="alert-error">Couldn\'t load the manifest: ' + esc(r.error) + '</div>';
        }).catch(function (er) { out.innerHTML = '<div class="alert-error">' + esc(er.message) + '</div>'; });
        break;
      }
      case 'clear-cache': api('POST', '/admin/api/cache/clear').then(function () { toast('Caches cleared'); refresh(); }); break;
      case 'save-settings':
        api('POST', '/admin/api/settings', collectSettings()).then(function () { toast('Saved'); refresh(); }).catch(function (er) { toast(er.message, false); });
        break;
      case 'save-catalogs': {
        syncCatalogEdits();
        var body = { order: state.catalogs.map(function (c) { return c.key; }), disabled: state.catalogs.filter(function (c) { return !c.enabled; }).map(function (c) { return c.key; }), names: {} };
        state.catalogs.forEach(function (c) { if (c.name && c.name !== c.originalName) body.names[c.key] = c.name; });
        api('POST', '/admin/api/catalogs', body).then(function () { toast('Libraries saved. Apps show the change on their next refresh.'); state.catalogs = null; render(); }).catch(function (er) { toast(er.message, false); });
        break;
      }
    }
  });

  function syncCatalogEdits() {
    if (!state.catalogs) return;
    state.catalogs.forEach(function (c) {
      var sw = app.querySelector('[data-key="cat:' + CSS.escape(c.key) + '"]');
      if (sw) c.enabled = sw.getAttribute('aria-checked') === 'true';
      var nm = app.querySelector('[data-name="' + CSS.escape(c.key) + '"]');
      if (nm) c.name = nm.value.trim() || c.originalName;
    });
  }

  app.addEventListener('change', function (e) {
    if (e.target.getAttribute('data-action-change') === 'theme') {
      var v = e.target.value; store('theme', v === 'auto' ? '' : v);
      if (v === 'auto') document.documentElement.removeAttribute('data-theme'); else document.documentElement.setAttribute('data-theme', v);
    }
  });

  app.addEventListener('submit', function (e) {
    e.preventDefault();
    var f = e.target; var kind = f.getAttribute('data-form');
    var data = {}; Array.prototype.forEach.call(f.elements, function (el) { if (el.name) data[el.name] = el.type === 'checkbox' ? el.checked : el.value; });
    if (kind === 'setup') {
      api('POST', '/admin/api/setup', data).then(function () { return signIn(data.username, data.password); })
        .catch(function (er) { state.error = er.message; render(); });
    } else if (kind === 'login') {
      signIn(data.username, data.password).catch(function (er) { state.error = er.status === 401 ? 'That username and password don\'t match.' : er.message; render(); });
    } else if (kind === 'connect') {
      api('POST', '/admin/api/settings', { aioUrl: data.url.trim() }).then(function () { toast('Saved. Loading your catalogs…'); setTimeout(refresh, 600); }).catch(function (er) { toast(er.message, false); });
    } else if (kind === 'speed') {
      state.busy.speed = true; render();
      api('POST', '/admin/api/speedtest', { type: data.type, id: data.id }).then(function (r) { state.speed = r; })
        .catch(function (er) { state.speed = { ok: false, ms: 0, error: er.message }; })
        .then(function () { state.busy.speed = false; refresh(); });
    } else if (kind === 'add-plugin') {
      api('POST', '/admin/api/plugins', data).then(function (p) { toast('Installed ' + p.name + '. Reload Jellyfin Web to load it.'); loadPlugins(); }).catch(function (er) { toast(er.message, false); });
    } else if (kind === 'add-user') {
      api('POST', '/admin/api/users', data).then(function () { toast('Added ' + data.name); refresh(); }).catch(function (er) { toast(er.message, false); });
    }
  });

  function signIn(username, password) {
    return api('POST', '/Users/AuthenticateByName', { Username: username, Pw: password }).then(function (r) {
      if (!r.User.Policy.IsAdministrator) { var er = new Error('This account isn\'t an administrator.'); throw er; }
      state.token = r.AccessToken; store('aiofin_token', r.AccessToken); state.error = ''; return refresh();
    });
  }

  refresh();
}());
