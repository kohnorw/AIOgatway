'use strict';
// External subtitles (AIOStreams + OpenSubtitles) in whatever format a player asks for.
//
// Jellyfin Web, and the iOS / Android apps built on it, never load the WebVTT
// file: they swap ".vtt" for ".js" in the address and expect Jellyfin's JSON
// format, { TrackEvents: [{ StartPositionTicks, EndPositionTicks, Text }] }.
// Other players ask for .vtt or .srt.
const { request } = require('./http');
const { SwrCache } = require('./cache');

const files = new SwrCache('subtitle-files', 300);

/** Subtitle files are often Windows-1252 rather than UTF-8; decode either. */
function decode(buf) {
  let b = buf;
  if (b[0] === 0xef && b[1] === 0xbb && b[2] === 0xbf) b = b.subarray(3); // UTF-8 BOM
  if (b[0] === 0xff && b[1] === 0xfe) return new TextDecoder('utf-16le').decode(b.subarray(2));
  if (b[0] === 0xfe && b[1] === 0xff) return new TextDecoder('utf-16be').decode(b.subarray(2));
  try { return new TextDecoder('utf-8', { fatal: true }).decode(b); } catch { return new TextDecoder('windows-1252').decode(b); }
}

const TIME = /(?:(\d+):)?(\d{1,2}):(\d{2})[,.](\d{1,3})/;
function seconds(t) {
  const m = t.match(TIME);
  if (!m) return null;
  return (parseInt(m[1] || '0', 10) * 3600) + (parseInt(m[2], 10) * 60) + parseInt(m[3], 10) + (parseInt(m[4].padEnd(3, '0'), 10) / 1000);
}

/** Keep basic emphasis; drop styling players can't show (ASS overrides, font tags, VTT voice tags). */
function cleanText(t) {
  return t
    .replace(/\{\\[^}]*\}/g, '')                  // {\an8}, {\i1}
    .replace(/<\/?(font|span|c|v|ruby|rt|lang)\b[^>]*>/gi, '') // styling wrappers
    .replace(/<(\/?)([ibu])\b[^>]*>/gi, '<$1$2>')  // keep <i> <b> <u>
    .replace(/<(?!\/?[ibu]>)[^>]*>/gi, '')         // anything else that looks like a tag
    .replace(/\\N/g, '\n')
    .split('\n').map((l) => l.trim()).filter(Boolean).join('\n')
    .trim();
}

/** Parse SRT or WebVTT into [{ start, end, text }] (seconds). */
function parse(text) {
  const blocks = text.replace(/\r\n?/g, '\n').split(/\n[ \t]*\n/);
  const out = [];
  for (const block of blocks) {
    const lines = block.split('\n');
    const i = lines.findIndex((l) => l.includes('-->'));
    if (i === -1) continue;
    const [a, b] = lines[i].split('-->');
    const start = seconds(a); const end = seconds(b || '');
    if (start === null || end === null || end < start) continue;
    const body = cleanText(lines.slice(i + 1).join('\n'));
    if (body) out.push({ start, end, text: body });
  }
  return out.sort((x, y) => x.start - y.start);
}

const TICKS = 10_000_000;
const pad = (n, w = 2) => String(n).padStart(w, '0');
function stamp(sec, sep) {
  const ms = Math.round(sec * 1000);
  return `${pad(Math.floor(ms / 3600000))}:${pad(Math.floor(ms / 60000) % 60)}:${pad(Math.floor(ms / 1000) % 60)}${sep}${pad(ms % 1000, 3)}`;
}

function toJson(events) {
  return { TrackEvents: events.map((e, i) => ({ Id: String(i + 1), Text: e.text, StartPositionTicks: Math.round(e.start * TICKS), EndPositionTicks: Math.round(e.end * TICKS) })) };
}
function toVtt(events) {
  return 'WEBVTT\n\n' + events.map((e) => `${stamp(e.start, '.')} --> ${stamp(e.end, '.')}\n${e.text}`).join('\n\n') + '\n';
}
function toSrt(events) {
  return events.map((e, i) => `${i + 1}\n${stamp(e.start, ',')} --> ${stamp(e.end, ',')}\n${e.text}`).join('\n\n') + '\n';
}

/** Download (cached) and parse one subtitle file. */
function load(url) {
  return files.get(url, async () => {
    const res = await request(url, { timeout: 15_000 });
    if (res.status >= 400) throw new Error(`subtitle download failed (HTTP ${res.status})`);
    const events = parse(decode(res.body));
    if (!events.length) throw new Error('subtitle file has no readable lines');
    return events;
  }, { ttl: 6 * 3600_000 });
}

module.exports = { decode, parse, toJson, toVtt, toSrt, load };
