'use strict';
// Jellyfin Web plugins: JavaScript and CSS add-ons loaded into every page of
// Jellyfin Web (browsers and the Jellyfin iOS/Android apps, which run Jellyfin
// Web inside). Each is a URL (loaded from where it lives) or code pasted on the
// admin page. Server plugins from Jellyfin's catalog are .NET DLLs and can't run
// here; AIOFin isn't Jellyfin's server.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { boot } = require('./config');

const FILE = path.join(boot.dataDir, 'plugins.json');
let list = [];
try { list = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { /* none yet */ }
let version = Date.now();

function save() {
  fs.writeFileSync(FILE + '.tmp', JSON.stringify(list, null, 2));
  fs.renameSync(FILE + '.tmp', FILE);
  version = Date.now();
}

const MAX_CODE = 2 * 1024 * 1024;
function clean(p, old = {}) {
  const kind = p.kind === 'css' ? 'css' : p.kind === 'js' ? 'js' : null;
  const url = String(p.url || '').trim();
  const code = String(p.code || '');
  if (url && !/^https?:\/\//i.test(url)) throw new Error('The URL must start with http:// or https://');
  if (!url && !code.trim()) throw new Error('Give a URL or paste the code');
  if (code.length > MAX_CODE) throw new Error('Code is larger than 2 MB');
  const guess = kind || (/\.css(\?|#|$)/i.test(url) ? 'css' : 'js');
  const name = String(p.name || '').trim().slice(0, 80)
    || (url ? decodeURIComponent(url.split(/[?#]/)[0].split('/').pop() || url) : `${guess.toUpperCase()} plugin`);
  return {
    id: old.id || crypto.randomBytes(6).toString('hex'),
    name, kind: guess, url: url || null, code: url ? null : code,
    enabled: p.enabled === undefined ? (old.enabled ?? true) : !!p.enabled,
    added: old.added || Date.now(),
  };
}

const all = () => list.map((p) => ({ ...p, size: p.code ? p.code.length : undefined }));
function add(p) { const x = clean(p); list.push(x); save(); return x; }
function update(id, p) {
  const i = list.findIndex((x) => x.id === id);
  if (i < 0) throw new Error('Plugin not found');
  const merged = { ...list[i], ...p };
  if (p.url !== undefined && p.url) merged.code = null;
  if (p.code !== undefined && p.code) merged.url = null;
  list[i] = clean(merged, list[i]); save(); return list[i];
}
function remove(id) { list = list.filter((x) => x.id !== id); save(); }
function move(id, dir) {
  const i = list.findIndex((x) => x.id === id); const j = i + (dir < 0 ? -1 : 1);
  if (i < 0 || j < 0 || j >= list.length) return;
  [list[i], list[j]] = [list[j], list[i]]; save();
}
function get(id) { return list.find((x) => x.id === id) || null; }

const attr = (s) => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
/** Tags for Jellyfin Web's index.html: CSS in <head>, scripts at the end of <body>, in list order. */
function tags() {
  const on = list.filter((p) => p.enabled);
  const tag = (p) => {
    const src = p.url ? attr(p.url) : `/aiofin/plugins/${p.id}.${p.kind}?v=${version}`;
    return p.kind === 'css'
      ? `<link rel="stylesheet" data-aiofin-plugin="${p.id}" href="${src}">`
      : `<script defer data-aiofin-plugin="${p.id}" src="${src}"></script>`;
  };
  return { head: on.filter((p) => p.kind === 'css').map(tag).join(''), body: on.filter((p) => p.kind === 'js').map(tag).join('') };
}

module.exports = { all, add, update, remove, move, get, tags, version: () => version };
