'use strict';
// Maps Stremio metadata onto Jellyfin's item model.
//
// Item keys (hashed into 32-hex Jellyfin ids by store.idFor):
//   m|<type>|<stremioId>                movie-like item
//   s|<type>|<stremioId>                series
//   S|<type>|<stremioId>|<season>       season
//   e|<type>|<stremioId>|<videoId>      episode
//   v|<catalogType>/<catalogId>         library view (one per catalog)
//   root                                user root folder
const aio = require('./aio');
const store = require('./store');
const { settings } = require('./config');
const { md5, parseRuntime, TICKS_PER_SEC, pMap, log } = require('./util');

const SERIES_TYPES = new Set(['series', 'anime']);
const ROOT_ID = store.idFor('root');

const serverId = () => store.serverId();
const tag = (url) => (url ? md5(url).slice(0, 16) : undefined);

// Small preview cache from catalog rows so lists don't need full meta calls.
const previews = new Map();
function rememberPreview(key, m) {
  const old = previews.get(key);
  previews.delete(key);
  previews.set(key, old ? { ...old, ...m } : m);
  if (previews.size > 60_000) previews.delete(previews.keys().next().value);
}

function parseKey(key) {
  if (!key) return null;
  if (key === 'root') return { kind: 'root' };
  const p = key.split('|');
  switch (p[0]) {
    case 'm': return { kind: 'movie', type: p[1], sid: p.slice(2).join('|') };
    case 's': return { kind: 'series', type: p[1], sid: p.slice(2).join('|') };
    case 'S': return { kind: 'season', type: p[1], sid: p[2], season: parseInt(p[3], 10) };
    case 'e': return { kind: 'episode', type: p[1], sid: p[2], videoId: p.slice(3).join('|') };
    case 'v': return { kind: 'view', catKey: p.slice(1).join('|') };
    default: return null;
  }
}
const resolve = (id) => { const key = store.keyFor(id); return key ? { key, ...parseKey(key) } : null; };

const itemKeyForMeta = (m, fallbackType) => {
  const type = m.type || fallbackType || 'movie';
  return SERIES_TYPES.has(type) ? `s|${type}|${m.id}` : `m|${type}|${m.id}`;
};

// ── Field helpers ──────────────────────────────────────────────────────
function yearOf(m) {
  const y = parseInt(String(m.year || m.releaseInfo || m.released || '').slice(0, 4), 10);
  return y > 1800 ? y : undefined;
}
function genresOf(m) {
  if (Array.isArray(m.genres) && m.genres.length) return m.genres;
  if (Array.isArray(m.genre) && m.genre.length) return m.genre;
  return (m.links || []).filter((l) => l.category === 'Genre').map((l) => l.name);
}
function peopleOf(m) {
  const out = [];
  const cast = (Array.isArray(m.cast) && m.cast.length) ? m.cast : (m.links || []).filter((l) => l.category === 'Cast').map((l) => l.name);
  const dirs = (Array.isArray(m.director) && m.director.length) ? m.director : (m.links || []).filter((l) => l.category === 'Directors').map((l) => l.name);
  for (const n of dirs.slice(0, 3)) out.push({ Name: n, Id: store.idFor(`p|${n}`), Type: 'Director' });
  for (const n of cast.slice(0, 15)) out.push({ Name: n, Id: store.idFor(`p|${n}`), Type: 'Actor', Role: '' });
  return out;
}
function providerIds(m) {
  const ids = {};
  const id = String(m.imdb_id || m.id || '');
  const imdb = id.match(/^tt\d+/); if (imdb) ids.Imdb = imdb[0];
  const tmdb = String(m.id || '').match(/^tmdb:(\d+)/) || (m.moviedb_id ? [0, m.moviedb_id] : null);
  if (tmdb) ids.Tmdb = String(tmdb[1]);
  const tvdb = String(m.id || '').match(/^tvdb:(\d+)/) || (m.tvdb_id ? [0, m.tvdb_id] : null);
  if (tvdb) ids.Tvdb = String(tvdb[1]);
  return ids;
}
function trailers(m) {
  const t = (m.trailerStreams || m.trailers || []).map((x) => x.ytId || x.source).filter(Boolean);
  return t.slice(0, 3).map((y) => ({ Url: `https://www.youtube.com/watch?v=${y}`, Name: 'Trailer' }));
}
const runtimeOf = (m) => parseRuntime(m.runtime);

function userDataFor(userId, itemId, runtimeTicks) {
  const d = (userId && store.userData.get(userId, itemId)) || {};
  const ud = {
    PlaybackPositionTicks: d.pos || 0,
    PlayCount: d.playCount || 0,
    IsFavorite: !!d.fav,
    Played: !!d.played,
    Key: itemId,
    ItemId: itemId,
  };
  if (d.lastPlayed) ud.LastPlayedDate = new Date(d.lastPlayed).toISOString();
  if (d.pos && runtimeTicks) ud.PlayedPercentage = Math.min(100, (d.pos / runtimeTicks) * 100);
  return ud;
}

function stubSource(itemId, runtime) {
  return {
    Protocol: 'Http', Id: itemId, Type: 'Default', Container: 'mkv', Name: 'Auto',
    IsRemote: true, ETag: itemId, RunTimeTicks: runtime || undefined, ReadAtNativeFramerate: false,
    IgnoreDts: false, IgnoreIndex: false, GenPtsInput: false, SupportsTranscoding: true,
    SupportsDirectStream: true, SupportsDirectPlay: true, IsInfiniteStream: false, RequiresOpening: false,
    RequiresClosing: false, RequiresLooping: false, SupportsProbing: false, VideoType: 'VideoFile',
    MediaStreams: [], MediaAttachments: [], Formats: [], RequiredHttpHeaders: {}, HasSegments: false,
  };
}

function common(id, name, type, m, extra = {}) {
  const dto = {
    Name: name, ServerId: serverId(), Id: id, Etag: tag(`${id}${name}`),
    DateCreated: m.released || '2000-01-01T00:00:00.0000000Z',
    CanDelete: false, CanDownload: false, SortName: (name || '').toLowerCase(),
    Type: type, ImageTags: {}, BackdropImageTags: [], LocationType: 'FileSystem',
    ...extra,
  };
  return dto;
}

// ── DTO builders ───────────────────────────────────────────────────────
function movieDto(key, m, userId, opts = {}) {
  const id = store.idFor(key);
  const runtime = runtimeOf(m);
  const dto = common(id, m.name, 'Movie', m, {
    IsFolder: false, MediaType: 'Video', VideoType: 'VideoFile', Container: 'mkv',
    Overview: m.description || '', ProductionYear: yearOf(m),
    PremiereDate: m.released || undefined, CommunityRating: m.imdbRating ? parseFloat(m.imdbRating) : undefined,
    OfficialRating: m.certification || undefined, RunTimeTicks: runtime || undefined,
    Genres: genresOf(m), GenreItems: genresOf(m).map((g) => ({ Name: g, Id: store.idFor(`g|${g}`) })),
    ProviderIds: providerIds(m), People: opts.full ? peopleOf(m) : undefined,
    RemoteTrailers: opts.full ? trailers(m) : undefined, Taglines: [], Studios: [],
    PrimaryImageAspectRatio: 0.6666666666666666, HasSubtitles: true,
    ExternalUrls: providerIds(m).Imdb ? [{ Name: 'IMDb', Url: `https://www.imdb.com/title/${providerIds(m).Imdb}` }] : [],
  });
  if (m.poster) dto.ImageTags.Primary = tag(m.poster);
  if (m.logo) dto.ImageTags.Logo = tag(m.logo);
  if (m.background) { dto.BackdropImageTags = [tag(m.background)]; dto.ImageTags.Thumb = tag(m.background); }
  if (opts.parentId) dto.ParentId = opts.parentId;
  dto.UserData = userDataFor(userId, id, runtime);
  if (opts.full) dto.MediaSources = [stubSource(id, runtime)];
  return dto;
}

function seasonsOf(m) {
  const map = new Map();
  for (const v of m.videos || []) {
    const s = Number.isFinite(+v.season) ? +v.season : 1;
    if (!map.has(s)) map.set(s, []);
    map.get(s).push(v);
  }
  const nums = [...map.keys()].sort((a, b) => (a === 0) - (b === 0) || a - b);
  return nums.map((n) => ({ n, videos: sortEps(map.get(n)) }));
}
function sortEps(vs) {
  return [...vs].sort((a, b) => (+a.episode || +a.number || 0) - (+b.episode || +b.number || 0));
}
const epNum = (v, i) => +v.episode || +v.number || i + 1;

function seriesDto(key, m, userId, opts = {}) {
  const id = store.idFor(key);
  const seasons = seasonsOf(m);
  const dto = common(id, m.name, 'Series', m, {
    IsFolder: true, Overview: m.description || '', ProductionYear: yearOf(m),
    PremiereDate: m.released || undefined, CommunityRating: m.imdbRating ? parseFloat(m.imdbRating) : undefined,
    RunTimeTicks: runtimeOf(m) || undefined, Genres: genresOf(m),
    GenreItems: genresOf(m).map((g) => ({ Name: g, Id: store.idFor(`g|${g}`) })),
    ProviderIds: providerIds(m), People: opts.full ? peopleOf(m) : undefined,
    RemoteTrailers: opts.full ? trailers(m) : undefined, Taglines: [], Studios: [],
    Status: /–\s*$|-\s*$/.test(m.releaseInfo || '') ? 'Continuing' : undefined,
    ChildCount: seasons.length || undefined, PrimaryImageAspectRatio: 0.6666666666666666,
    DisplayOrder: 'Aired',
  });
  if (m.poster) dto.ImageTags.Primary = tag(m.poster);
  if (m.logo) dto.ImageTags.Logo = tag(m.logo);
  if (m.background) { dto.BackdropImageTags = [tag(m.background)]; dto.ImageTags.Thumb = tag(m.background); }
  if (opts.parentId) dto.ParentId = opts.parentId;
  dto.UserData = userDataFor(userId, id);
  if (userId && seasons.length) {
    let unplayed = 0;
    for (const s of seasons) for (const v of s.videos) {
      const d = store.userData.get(userId, store.idFor(`e|${parseKey(key).type}|${m.id}|${v.id}`));
      if (!d || !d.played) unplayed++;
    }
    dto.UserData.UnplayedItemCount = unplayed;
  }
  return dto;
}

function seasonName(n) { return n === 0 ? 'Specials' : `Season ${n}`; }

function seasonDto(type, m, season, userId) {
  const seriesKey = `s|${type}|${m.id}`;
  const seriesId = store.idFor(seriesKey);
  const id = store.idFor(`S|${type}|${m.id}|${season.n}`);
  const firstThumb = null;
  const dto = common(id, seasonName(season.n), 'Season', m, {
    IsFolder: true, IndexNumber: season.n, SeriesId: seriesId, SeriesName: m.name, ParentId: seriesId,
    ChildCount: season.videos.length, ProductionYear: yearOf(season.videos[0] || {}) || yearOf(m),
    PremiereDate: season.videos[0]?.released || undefined, Overview: '',
    PrimaryImageAspectRatio: 0.6666666666666666,
  });
  if (m.poster) { dto.ImageTags.Primary = tag(m.poster); dto.SeriesPrimaryImageTag = tag(m.poster); }
  if (m.background) { dto.ParentBackdropItemId = seriesId; dto.ParentBackdropImageTags = [tag(m.background)]; }
  if (m.logo) { dto.ParentLogoItemId = seriesId; dto.ParentLogoImageTag = tag(m.logo); }
  void firstThumb;
  dto.UserData = userDataFor(userId, id);
  if (userId) {
    dto.UserData.UnplayedItemCount = season.videos.filter((v) => !store.userData.get(userId, store.idFor(`e|${type}|${m.id}|${v.id}`))?.played).length;
  }
  return dto;
}

function episodeDto(type, m, v, idx, userId, opts = {}) {
  const seriesId = store.idFor(`s|${type}|${m.id}`);
  const sNum = Number.isFinite(+v.season) ? +v.season : 1;
  const seasonId = store.idFor(`S|${type}|${m.id}|${sNum}`);
  const id = store.idFor(`e|${type}|${m.id}|${v.id}`);
  const runtime = parseRuntime(v.runtime) || runtimeOf(m);
  const name = v.name || v.title || `Episode ${epNum(v, idx)}`;
  const dto = common(id, name, 'Episode', m, {
    IsFolder: false, MediaType: 'Video', VideoType: 'VideoFile', Container: 'mkv',
    IndexNumber: epNum(v, idx), ParentIndexNumber: sNum,
    SeriesId: seriesId, SeriesName: m.name, SeasonId: seasonId, SeasonName: seasonName(sNum), ParentId: seasonId,
    Overview: v.overview || v.description || '', PremiereDate: v.released || v.firstAired || undefined,
    ProductionYear: yearOf(v) || undefined, RunTimeTicks: runtime || undefined,
    ProviderIds: {}, PrimaryImageAspectRatio: 1.7777777777777777, HasSubtitles: true,
  });
  if (v.thumbnail) dto.ImageTags.Primary = tag(v.thumbnail);
  if (m.poster) dto.SeriesPrimaryImageTag = tag(m.poster);
  if (m.background) {
    dto.ParentBackdropItemId = seriesId; dto.ParentBackdropImageTags = [tag(m.background)];
    dto.ParentThumbItemId = seriesId; dto.ParentThumbImageTag = tag(m.background);
  }
  if (m.logo) { dto.ParentLogoItemId = seriesId; dto.ParentLogoImageTag = tag(m.logo); }
  dto.UserData = userDataFor(userId, id, runtime);
  if (opts.full) dto.MediaSources = [stubSource(id, runtime)];
  return dto;
}

function viewDto(cat) {
  const id = store.idFor(`v|${cat.key}`);
  return {
    Name: cat.name, ServerId: serverId(), Id: id, Etag: tag(cat.key), DateCreated: '2000-01-01T00:00:00.0000000Z',
    CanDelete: false, CanDownload: false, SortName: cat.name.toLowerCase(), ExternalUrls: [], Path: `/catalogs/${cat.key}`,
    Taglines: [], Genres: [], PlayAccess: 'Full', RemoteTrailers: [], ProviderIds: {}, IsFolder: true,
    ParentId: ROOT_ID, Type: 'CollectionFolder', People: [], Studios: [], GenreItems: [], LocalTrailerCount: 0,
    UserData: { PlaybackPositionTicks: 0, PlayCount: 0, IsFavorite: false, Played: false, Key: id, ItemId: id },
    ChildCount: 100, SpecialFeatureCount: 0, DisplayPreferencesId: id, Tags: [],
    PrimaryImageAspectRatio: 1.7777777777777777,
    CollectionType: SERIES_TYPES.has(cat.type) ? 'tvshows' : 'movies',
    ImageTags: {}, BackdropImageTags: [], LocationType: 'FileSystem', LockedFields: [], LockData: false,
  };
}

function rootDto() {
  return {
    Name: 'Media Folders', ServerId: serverId(), Id: ROOT_ID, Type: 'UserRootFolder', IsFolder: true,
    CanDelete: false, CanDownload: false, ImageTags: {}, BackdropImageTags: [], LocationType: 'FileSystem',
    UserData: { PlaybackPositionTicks: 0, PlayCount: 0, IsFavorite: false, Played: false, Key: ROOT_ID, ItemId: ROOT_ID },
  };
}

// ── Queries ────────────────────────────────────────────────────────────
async function views() {
  if (!aio.configured()) return [];
  try {
    const cats = await aio.catalogs();
    return cats.filter((c) => c.enabled && c.browsable);
  } catch (e) {
    // Apps treat a failing views call as a broken server; show no libraries instead.
    log('warn', `can't load libraries from AIOStreams: ${e.message}`);
    return [];
  }
}

/** Build a list DTO from a catalog preview row (no extra network calls). */
function previewDto(m, catType, userId, parentId) {
  const key = itemKeyForMeta(m, catType);
  rememberPreview(key, m);
  const full = aio.peekMeta(parseKey(key).type, m.id);
  const src = full ? { ...m, ...full } : m;
  return parseKey(key).kind === 'series' ? seriesDto(key, src, userId, { parentId }) : movieDto(key, src, userId, { parentId });
}

async function catalogItems(catKey, start, limit, userId) {
  const cats = await aio.catalogs();
  const cat = cats.find((c) => c.key === catKey);
  if (!cat) return { items: [], total: 0 };
  const viewId = store.idFor(`v|${catKey}`);
  const { items, more } = await aio.catalogSlice(cat.type, cat.id, start, limit);
  const dtos = items.map((m) => previewDto(m, cat.type, userId, viewId));
  // Stremio catalogs don't report a total; advertise one more page while there is one.
  const total = start + dtos.length + (more ? limit : 0);
  return { items: dtos, total };
}

async function metaFor(parsed) {
  return aio.meta(parsed.type, parsed.sid);
}

/** Single item by Jellyfin id. `full` adds People/MediaSources etc. */
async function getItem(id, userId, { full = true } = {}) {
  if (id === ROOT_ID) return rootDto();
  const r = resolve(id);
  if (!r) return null;
  switch (r.kind) {
    case 'root': return rootDto();
    case 'view': {
      const cat = (await aio.catalogs()).find((c) => c.key === r.catKey);
      return cat ? viewDto(cat) : null;
    }
    case 'movie': {
      let m;
      try { m = await metaFor(r); } catch { m = previews.get(r.key); }
      if (!m) return null;
      return movieDto(r.key, { ...previews.get(r.key), ...m }, userId, { full });
    }
    case 'series': {
      let m;
      try { m = await metaFor(r); } catch { m = previews.get(r.key); }
      if (!m) return null;
      return seriesDto(r.key, { ...previews.get(r.key), ...m }, userId, { full });
    }
    case 'season': {
      const m = await metaFor(r);
      const s = seasonsOf(m).find((x) => x.n === r.season);
      return s ? seasonDto(r.type, m, s, userId) : null;
    }
    case 'episode': {
      const m = await metaFor(r);
      const vs = m.videos || [];
      const idx = vs.findIndex((v) => v.id === r.videoId);
      if (idx === -1) return null;
      return episodeDto(r.type, m, vs[idx], idx, userId, { full });
    }
    default: return null;
  }
}

/** Cheap DTO for list contexts: uses cached meta/preview, fetches meta only when unknown. */
async function getListItem(id, userId) {
  const r = resolve(id);
  if (!r) return null;
  if (r.kind === 'movie' || r.kind === 'series') {
    const m = aio.peekMeta(r.type, r.sid) || previews.get(r.key);
    if (m) return r.kind === 'series' ? seriesDto(r.key, m, userId) : movieDto(r.key, m, userId);
  }
  const snap = userId && store.userData.get(userId, id)?.snap;
  try { return await getItem(id, userId, { full: false }); } catch (e) {
    if (snap) return { ...snap, UserData: userDataFor(userId, id, snap.RunTimeTicks) };
    return null;
  }
}

async function seasons(seriesId, userId) {
  const r = resolve(seriesId);
  if (!r || r.kind !== 'series') return [];
  const m = await metaFor(r);
  return seasonsOf(m).map((s) => seasonDto(r.type, m, s, userId));
}

async function episodes(seriesOrSeasonId, userId, { seasonId, season } = {}) {
  let r = resolve(seriesOrSeasonId);
  if (!r) return [];
  if (r.kind === 'season') { season = r.season; }
  if (seasonId) { const sr = resolve(seasonId); if (sr && sr.kind === 'season') season = sr.season; }
  const m = await metaFor(r);
  const list = [];
  for (const s of seasonsOf(m)) {
    if (season !== undefined && season !== null && s.n !== season) continue;
    s.videos.forEach((v, i) => list.push(episodeDto(r.type, m, v, i, userId)));
  }
  return list;
}

/** Ordered list of playable episodes for a series (specials last). */
function orderedEpisodes(m) {
  return seasonsOf(m).filter((s) => s.n !== 0).flatMap((s) => s.videos);
}

/** Episodes after `videoId` (for prewarming / next up). */
async function nextEpisodes(type, sid, videoId, n = 1) {
  const m = await aio.meta(type, sid);
  const eps = orderedEpisodes(m);
  const i = eps.findIndex((v) => v.id === videoId);
  return { meta: m, next: i === -1 ? [] : eps.slice(i + 1, i + 1 + n) };
}

function resumeItems(userId, limit = 20) {
  const all = store.userData.all(userId);
  return Object.entries(all)
    .filter(([, d]) => d.pos > 0 && !d.played && d.snap)
    .sort((a, b) => (b[1].lastPlayed || 0) - (a[1].lastPlayed || 0))
    .slice(0, limit)
    .map(([id, d]) => ({ ...d.snap, UserData: userDataFor(userId, id, d.snap.RunTimeTicks) }));
}

async function nextUp(userId, { seriesId, limit = 20 } = {}) {
  const all = store.userData.all(userId);
  // latest activity per series
  const bySeries = new Map();
  for (const [id, d] of Object.entries(all)) {
    if (!d.lastPlayed) continue;
    const r = resolve(id);
    if (!r || r.kind !== 'episode') continue;
    const sKey = `${r.type}|${r.sid}`;
    const cur = bySeries.get(sKey);
    if (!cur || d.lastPlayed > cur.at) bySeries.set(sKey, { type: r.type, sid: r.sid, at: d.lastPlayed });
  }
  let series = [...bySeries.values()].sort((a, b) => b.at - a.at);
  if (seriesId) {
    const r = resolve(seriesId);
    series = r && r.kind === 'series' ? [{ type: r.type, sid: r.sid, at: 0 }] : [];
  }
  series = series.slice(0, Math.max(limit, 1) * 2);
  const out = await pMap(series, 8, async (s) => {
    const m = await aio.meta(s.type, s.sid);
    const eps = orderedEpisodes(m);
    // first unplayed episode after the furthest played one
    let last = -1;
    eps.forEach((v, i) => { if (all[store.idFor(`e|${s.type}|${m.id}|${v.id}`)]?.played) last = i; });
    for (let i = last + 1; i < eps.length; i++) {
      const v = eps[i];
      const d = all[store.idFor(`e|${s.type}|${m.id}|${v.id}`)];
      if (d?.played) continue;
      if (v.released && new Date(v.released) > new Date()) return null; // not aired yet
      return episodeDto(s.type, m, v, i, userId);
    }
    return null;
  });
  return out.filter(Boolean).slice(0, limit);
}

function favourites(userId) {
  const all = store.userData.all(userId);
  return Object.entries(all).filter(([, d]) => d.fav && d.snap)
    .sort((a, b) => (b[1].favAt || 0) - (a[1].favAt || 0))
    .map(([id, d]) => ({ ...d.snap, UserData: userDataFor(userId, id, d.snap.RunTimeTicks) }));
}

function played(userId) {
  const all = store.userData.all(userId);
  return Object.entries(all).filter(([, d]) => d.played && d.snap)
    .sort((a, b) => (b[1].lastPlayed || 0) - (a[1].lastPlayed || 0))
    .map(([id, d]) => ({ ...d.snap, UserData: userDataFor(userId, id, d.snap.RunTimeTicks) }));
}

/** Store a compact snapshot of an item so Resume/Favourites render without network. */
async function snapshot(userId, itemId) {
  try {
    const dto = await getItem(itemId, null, { full: false });
    if (!dto) return null;
    const { UserData, People, MediaSources, RemoteTrailers, ...snap } = dto;
    void UserData; void People; void MediaSources; void RemoteTrailers;
    return snap;
  } catch (e) { log('debug', `snapshot failed ${itemId}: ${e.message}`); return null; }
}

/** Image URL for an item id + Jellyfin image type. */
async function imageUrl(id, type) {
  const r = resolve(id);
  if (!r) return null;
  type = String(type).toLowerCase();
  if (r.kind === 'view') {
    const cats = await aio.catalogs();
    const cat = cats.find((c) => c.key === r.catKey);
    if (!cat) return null;
    const first = (await aio.catalogPage(cat.type, cat.id, 0))[0];
    return first ? first.background || first.poster : null;
  }
  if (r.kind === 'movie' || r.kind === 'series') {
    const m = aio.peekMeta(r.type, r.sid) || previews.get(r.key) || await aio.meta(r.type, r.sid).catch(() => null);
    if (!m) return null;
    if (type === 'primary') return m.poster || null;
    if (type === 'logo') return m.logo || null;
    if (type === 'backdrop' || type === 'thumb' || type === 'banner') return m.background || m.poster || null;
    return null;
  }
  const m = await aio.meta(r.type, r.sid).catch(() => null);
  if (!m) return null;
  if (r.kind === 'season') return type === 'primary' ? m.poster : (type === 'logo' ? m.logo : m.background);
  if (r.kind === 'episode') {
    const v = (m.videos || []).find((x) => x.id === r.videoId);
    if (type === 'primary' || type === 'thumb') return v?.thumbnail || m.background || null;
    if (type === 'logo') return m.logo || null;
    return m.background || null;
  }
  return null;
}

/** Stremio (type, id) used for /stream lookups for a playable Jellyfin item. */
function streamTarget(id) {
  const r = resolve(id);
  if (!r) return null;
  if (r.kind === 'movie') return { type: r.type, id: r.sid, r };
  if (r.kind === 'episode') return { type: r.type, id: r.videoId, r };
  return null;
}

/** When a series/season page is opened, warm the episode the user will most likely play. */
async function prefetchForSeries(id, userId) {
  const r = resolve(id);
  if (!r || (r.kind !== 'series' && r.kind !== 'season')) return;
  try {
    const m = await aio.meta(r.type, r.sid);
    const all = userId ? store.userData.all(userId) : {};
    let eps = orderedEpisodes(m);
    if (r.kind === 'season') eps = (seasonsOf(m).find((s) => s.n === r.season) || { videos: [] }).videos;
    let pick = eps.find((v) => { const d = all[store.idFor(`e|${r.type}|${m.id}|${v.id}`)]; return d && d.pos > 0 && !d.played; });
    if (!pick) {
      let last = -1;
      eps.forEach((v, i) => { if (all[store.idFor(`e|${r.type}|${m.id}|${v.id}`)]?.played) last = i; });
      pick = eps[last + 1];
    }
    if (pick) aio.prefetch(r.type, pick.id, 'open-series');
  } catch { /* best effort */ }
}

module.exports = {
  ROOT_ID, resolve, parseKey, views, viewDto, rootDto, catalogItems, getItem, getListItem, previewDto,
  seasons, episodes, nextEpisodes, resumeItems, nextUp, favourites, played, snapshot, imageUrl,
  streamTarget, prefetchForSeries, itemKeyForMeta, userDataFor, TICKS_PER_SEC, settings,
};
