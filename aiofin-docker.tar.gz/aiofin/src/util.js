'use strict';
const crypto = require('crypto');
const { boot } = require('./config');

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
const threshold = LEVELS[boot.logLevel] || 20;
function log(level, ...args) {
  if ((LEVELS[level] || 20) < threshold) return;
  const ts = new Date().toISOString().slice(11, 23);
  (level === 'error' || level === 'warn' ? console.error : console.log)(`${ts} ${level.toUpperCase().padEnd(5)}`, ...args);
}

const md5 = (s) => crypto.createHash('md5').update(String(s)).digest('hex');
const randomHex = (n = 16) => crypto.randomBytes(n).toString('hex');

// Jellyfin-style 32-hex ids. Clients also send dashed GUIDs; normalise both.
const normId = (s) => String(s || '').replace(/-/g, '').toLowerCase();

const TICKS_PER_SEC = 10_000_000;

function parseRuntime(rt) {
  if (rt === undefined || rt === null || rt === '') return null;
  if (typeof rt === 'number') return rt * 60 * TICKS_PER_SEC;
  const s = String(rt).toLowerCase();
  let mins = 0, matched = false;
  const h = s.match(/(\d+(?:\.\d+)?)\s*h/); if (h) { mins += parseFloat(h[1]) * 60; matched = true; }
  const m = s.match(/(\d+)\s*m/); if (m) { mins += parseInt(m[1], 10); matched = true; }
  if (!matched) { const n = s.match(/^(\d+)/); if (n) mins = parseInt(n[1], 10); }
  return mins > 0 ? Math.round(mins * 60 * TICKS_PER_SEC) : null;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Resolve with the promise's value, or `fallback` once `ms` elapses.
function withTimeout(promise, ms, fallback) {
  let t;
  return Promise.race([
    promise.finally(() => clearTimeout(t)),
    new Promise((r) => { t = setTimeout(() => r(fallback), ms); }),
  ]);
}

// Run async fn over items with bounded concurrency.
async function pMap(items, limit, fn) {
  const out = new Array(items.length);
  let i = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (i < items.length) {
      const idx = i++;
      try { out[idx] = await fn(items[idx], idx); } catch (e) { out[idx] = undefined; }
    }
  });
  await Promise.all(workers);
  return out;
}

const fmtBytes = (n) => {
  if (!n || n <= 0) return '';
  const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0; let v = n;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v >= 100 || i === 0 ? v.toFixed(0) : v.toFixed(1)} ${u[i]}`;
};

module.exports = { log, md5, randomHex, normId, TICKS_PER_SEC, parseRuntime, sleep, withTimeout, pMap, fmtBytes };
