'use strict';
// Serves Jellyfin Web (/web) and the admin page (/admin). Text assets are
// gzipped once and kept in memory; hashed bundles get long cache lifetimes.
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { boot } = require('./config');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.mjs': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.wasm': 'application/wasm', '.txt': 'text/plain; charset=utf-8',
  '.webmanifest': 'application/manifest+json', '.map': 'application/json', '.mp4': 'video/mp4', '.xml': 'application/xml',
};
const COMPRESSIBLE = new Set(['.html', '.js', '.mjs', '.css', '.json', '.svg', '.txt', '.webmanifest', '.map', '.xml']);

// Injected into Jellyfin Web's index.html (adapted from Remux's web patches).
const INJECT_CSS = `
  [aria-labelledby="plugins-subheader"] { display: none !important; }
  .cardOverlayButton-br { display: none !important; }
  @media (max-width: 768px) { .detailLogo { top: 27vh !important; } }
  .docspinner { top: 80px; right: 21px; left: unset; width: 46px; height: 46px; }
  .aiofinMenu { position: fixed; inset: 0; z-index: 10000; display: flex; align-items: flex-end; justify-content: center; background: rgba(0,0,0,.55); }
  .aiofinMenu-panel { width: min(640px, 100%); max-height: 70vh; overflow: auto; margin: 0 12px 96px; background: #1c1c1e; color: #fff;
    border: 1px solid rgba(255,255,255,.12); border-radius: 12px; padding: 8px; box-shadow: 0 20px 60px rgba(0,0,0,.6); }
  .aiofinMenu-title { font-size: .8rem; letter-spacing: .08em; text-transform: uppercase; opacity: .6; padding: 10px 12px 8px; }
  .aiofinMenu-item { display: flex; gap: 10px; align-items: center; width: 100%; text-align: left; background: none; border: 0; color: inherit;
    font: inherit; font-size: .95rem; padding: 12px; border-radius: 8px; cursor: pointer; line-height: 1.35; }
  .aiofinMenu-item:hover, .aiofinMenu-item:focus-visible { background: rgba(255,255,255,.09); outline: none; }
  .aiofinMenu-item[aria-current="true"] { color: #00b354; }
  .aiofinMenu-check { width: 1.2em; flex: none; }
  .aiofinMenu-note { padding: 12px; opacity: .7; }
  .aiofinSourcesNote { display: flex; align-items: center; justify-content: center; gap: .6em; width: 100%; padding: .6em 0; opacity: .65; font-size: .9em; }
  .aiofinSourcesNote .aiofinSpin { width: 1.1em; height: 1.1em; border: 2px solid rgba(255,255,255,.25); border-top-color: rgba(255,255,255,.85); border-radius: 50%; animation: aiofinSpin .7s linear infinite; }
  @keyframes aiofinSpin { to { transform: rotate(360deg); } }
  @media (prefers-reduced-motion: reduce) { .aiofinSourcesNote .aiofinSpin { animation: none; } }
`;
const INJECT_JS = `
(function () {
  var ADMIN = ['/wizard', '/dashboard'];
  function isAdmin(p) { for (var i = 0; i < ADMIN.length; i++) { var a = ADMIN[i]; if (p === a || p.indexOf(a + '/') === 0 || p.indexOf(a + '?') === 0) return true; } return false; }
  function check(url) {
    try {
      var u = new URL(String(url), location.href);
      if (isAdmin(u.pathname.replace(/^\\/web/, ''))) { location.replace('/admin'); return true; }
      if (u.hash) { var h = '/' + u.hash.replace(/^#\\/?/, ''); if (isAdmin(h)) { location.replace('/admin'); return true; } }
    } catch (e) {}
    return false;
  }
  if (check(location.href)) return;
  var push = history.pushState.bind(history), rep = history.replaceState.bind(history);
  history.pushState = function (s, t, url) { if (url && check(url)) return; return push(s, t, url); };
  history.replaceState = function (s, t, url) { if (url && check(url)) return; return rep(s, t, url); };
  window.addEventListener('popstate', function () { check(location.href); });
  window.addEventListener('hashchange', function () { check(location.href); });
}());
(function () {
  // Details page: the page renders instantly with a placeholder source; this
  // fetches the real AIOStreams sources in the background and places them in
  // the item Jellyfin Web is already showing, so its own Version / Video /
  // Audio / Subtitles dropdowns fill in and drive playback.
  // (Approach adapted from Remux's async source loader.)
  var sourceToItem = {};
  function visiblePage() {
    var pages = document.querySelectorAll('.itemDetailPage');
    for (var i = 0; i < pages.length; i++) {
      if (!pages[i].classList.contains('hide') && pages[i].offsetParent !== null) return pages[i];
    }
    return null;
  }
  function onPageFor(id) {
    var h = location.href;
    return h.indexOf(id) !== -1 || h.indexOf(id.replace(/-/g, '')) !== -1;
  }
  function setNote(page, text, spinning) {
    var form = page.querySelector('.trackSelections');
    if (!form) return;
    var note = form.querySelector('.aiofinSourcesNote');
    if (!text) { if (note) note.remove(); return; }
    if (!note) { note = document.createElement('div'); note.className = 'aiofinSourcesNote'; form.insertBefore(note, form.firstChild); }
    note.innerHTML = (spinning ? '<span class="aiofinSpin" aria-hidden="true"></span>' : '') + '<span></span>';
    note.lastChild.textContent = text;
    form.classList.remove('hide');
  }
  function whenPage(id, fn, tries) {
    if (!onPageFor(id)) return;
    var page = visiblePage();
    if (page && page.querySelector('.selectSource')) { fn(page); return; }
    if ((tries || 0) < 60) setTimeout(function () { whenPage(id, fn, (tries || 0) + 1); }, 50);
  }
  function esc(t) { var d = document.createElement('div'); d.textContent = String(t); return d.innerHTML; }
  function isPlaceholder(item) {
    var ms = item.MediaSources;
    return Array.isArray(ms) && ms.length === 1 && ms[0].Id === item.Id && !(ms[0].MediaStreams || []).length;
  }
  // Versions beyond the first few haven't had their tracks read yet. When one is
  // picked, read it and redraw, so the Audio menu lists the file's real tracks.
  var tried = {}; // "itemId:sourceId" already asked once on this page view; never ask again
  function ensureTracks(page, item, apiClient, sid) {
    try {
      var key = item.Id + ':' + sid;
      if (tried[key]) return;
      var arr = item.MediaSources;
      var i = -1;
      for (var k = 0; k < arr.length; k++) if (arr[k].Id === sid) { i = k; break; }
      if (i < 0 || arr[i].AiofinTracksKnown) return;
      tried[key] = true;
      var audio = page.querySelector('.selectAudio');
      if (audio) { audio.innerHTML = '<option>Reading tracks…</option>'; audio.setAttribute('disabled', 'disabled'); }
      apiClient.getJSON(apiClient.getUrl('aiofin/items/' + item.Id + '/sources/' + sid))
        .then(function (src) { if (src && src.Id === sid) { src.Name = arr[i].Name; arr[i] = src; } })
        .catch(function () { /* keep the tracks guessed from the name */ })
        .then(function () {
          // Redraw either way (real tracks, or the guess if they couldn't be read).
          var select = page.querySelector('.selectSource');
          if (select && select.value === sid) select.dispatchEvent(new Event('change'));
        });
    } catch (e) { /* never let this break the page */ }
  }
  function apply(page, item, apiClient) {
    setNote(page, null);
    var ms = item.MediaSources;
    var select = page.querySelector('.selectSource');
    select.innerHTML = ms.map(function (m) { return '<option value="' + esc(m.Id) + '">' + esc(m.Name) + '</option>'; }).join('');
    select.value = ms[0].Id;
    var box = page.querySelector('.selectSourceContainer');
    if (box) box.classList[ms.length > 1 ? 'remove' : 'add']('hide');
    // Let Jellyfin Web draw Video / Audio / Subtitles itself from the real sources.
    try { select.dispatchEvent(new Event('change')); } catch (e) {}
    if (!select._aiofinWatch) {
      select._aiofinWatch = true;
      select.addEventListener('change', function () { ensureTracks(page, item, apiClient, select.value); });
    }
    ensureTracks(page, item, apiClient, select.value);
  }
  function load(apiClient, userId, item) {
    var id = item.Id;
    whenPage(id, function (page) { if (isPlaceholder(item)) setNote(page, 'Finding streams…', true); });
    var url = apiClient.getUrl('Users/' + userId + '/Items/' + id, { Fields: 'MediaSources', aiofinWait: 1 });
    apiClient.getJSON(url).then(function (full) {
      var ms = full && full.MediaSources;
      var real = ms && ms.length && !(ms.length === 1 && ms[0].Id === id && !(ms[0].MediaStreams || []).length);
      if (!real) { whenPage(id, function (page) { setNote(page, 'No streams found', false); }); return; }
      ms.forEach(function (m) { sourceToItem[m.Id] = id; });
      // Same array object Jellyfin Web holds, so every later redraw uses real data.
      item.MediaSources.splice.apply(item.MediaSources, [0, item.MediaSources.length].concat(ms));
      whenPage(id, function (page) { apply(page, item, apiClient); });
    }).catch(function () { whenPage(id, function (page) { setNote(page, null); }); });
  }
  function patch(apiClient) {
    var proto = apiClient && Object.getPrototypeOf(apiClient);
    if (!proto || proto._aiofinGetItem) return;
    proto._aiofinGetItem = true;
    var original = proto.getItem;
    proto.getItem = function (userId, itemId) {
      var self = this;
      // Jellyfin Web treats a version id as an item id (e.g. the ⋮ menu); map it back.
      if (typeof itemId === 'string' && sourceToItem[itemId]) itemId = sourceToItem[itemId];
      var p = original.call(this, userId, itemId);
      if (typeof itemId === 'string' && p && p.then) {
        p.then(function (item) {
          if (item && (item.Type === 'Movie' || item.Type === 'Episode') && item.LocationType !== 'Virtual'
              && isPlaceholder(item) && onPageFor(item.Id)) load(self, userId, item);
        }).catch(function () {});
      }
      return p;
    };
  }
  var realApiClient = window.ApiClient || null;
  if (realApiClient) patch(realApiClient);
  try {
    Object.defineProperty(window, 'ApiClient', {
      configurable: true,
      get: function () { return realApiClient; },
      set: function (v) { realApiClient = v; if (v) patch(v); }
    });
  } catch (e) {
    (function poll() { if (window.ApiClient) patch(window.ApiClient); else setTimeout(poll, 100); }());
  }
}());
(function () {
  // In-player stream switcher: a button next to Audio that lists every
  // AIOStreams result and restarts playback on the chosen one at the same spot.
  var pm = null;
  function looks(o) { return o && typeof o.getCurrentPlayer === 'function' && typeof o.play === 'function' && typeof o.currentMediaSource === 'function'; }
  function scan(ex) { if (!ex) return null; if (looks(ex)) return ex; try { for (var k in ex) { if (looks(ex[k])) return ex[k]; } } catch (e) {} return null; }
  function playbackManager() {
    if (pm) return pm;
    // Jellyfin Web doesn't expose it globally; reach it through webpack's module registry.
    var key = Object.keys(window).filter(function (k) { return k.indexOf('webpackChunk') === 0; })[0];
    var chunk = key && window[key];
    if (!chunk || !chunk.push) return null;
    var req = null;
    try { chunk.push([['aiofin-' + Date.now()], {}, function (r) { req = r; }]); } catch (e) { return null; }
    if (!req) return null;
    if (req.c) for (var id in req.c) { var hit = scan(req.c[id] && req.c[id].exports); if (hit) return (pm = hit); }
    for (var mid in req.m) {
      var src = ''; try { src = Function.prototype.toString.call(req.m[mid]); } catch (e) { continue; }
      if (src.indexOf('getCurrentPlayer') !== -1 && src.indexOf('currentMediaSource') !== -1) {
        try { var found = scan(req(mid)); if (found) return (pm = found); } catch (e) {}
      }
    }
    return null;
  }
  function token() {
    try { if (window.ApiClient && window.ApiClient.accessToken) return window.ApiClient.accessToken(); } catch (e) {}
    try { var c = JSON.parse(localStorage.getItem('jellyfin_credentials') || '{}'); return (c.Servers && c.Servers[0] && c.Servers[0].AccessToken) || ''; } catch (e) { return ''; }
  }
  function esc(t) { var d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
  function close() { var m = document.querySelector('.aiofinMenu'); if (m) m.remove(); var b = document.querySelector('.aiofinSources'); if (b) b.focus(); }
  function openMenu() {
    var m = playbackManager();
    var player = m && m.getCurrentPlayer();
    var item = player && m.currentItem(player);
    if (!item) return;
    var current = (m.currentMediaSource(player) || {}).Id;
    var menu = document.createElement('div');
    menu.className = 'aiofinMenu';
    menu.innerHTML = '<div class="aiofinMenu-panel" role="dialog" aria-label="Streams"><div class="aiofinMenu-title">Streams</div><div class="aiofinMenu-note">Loading…</div></div>';
    menu.addEventListener('click', function (e) { if (e.target === menu) close(); });
    menu.addEventListener('keydown', function (e) { if (e.key === 'Escape' || e.key === 'Backspace') { e.preventDefault(); e.stopPropagation(); close(); } });
    document.body.appendChild(menu);
    fetch('/aiofin/items/' + item.Id + '/sources', { headers: { 'X-Emby-Token': token() } })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var panel = menu.querySelector('.aiofinMenu-panel');
        var list = (data && data.Sources) || [];
        if (!list.length) { panel.querySelector('.aiofinMenu-note').textContent = 'No other streams found.'; return; }
        panel.innerHTML = '<div class="aiofinMenu-title">Streams</div>' + list.map(function (s) {
          var on = s.Id === current;
          return '<button class="aiofinMenu-item" data-sid="' + s.Id + '" aria-current="' + on + '"><span class="aiofinMenu-check">' + (on ? '✓' : '') + '</span><span>' + esc(s.Name) + '</span></button>';
        }).join('');
        panel.addEventListener('click', function (e) {
          var btn = e.target.closest('[data-sid]');
          if (!btn) return;
          var sid = btn.getAttribute('data-sid');
          close();
          if (sid === current) return;
          var ms = m.currentTime(player) || 0;
          m.play({ items: [item], startPositionTicks: Math.floor(ms * 10000), mediaSourceId: sid, serverId: item.ServerId, fullscreen: true });
        });
        var first = panel.querySelector('[aria-current="true"]') || panel.querySelector('.aiofinMenu-item');
        if (first) first.focus();
      })
      .catch(function () { var n = menu.querySelector('.aiofinMenu-note'); if (n) n.textContent = "Couldn't load streams."; });
  }
  var queued = false;
  function addButton() {
    queued = false;
    var audio = document.querySelector('.btnAudio');
    if (!audio || audio.parentNode.querySelector('.aiofinSources')) return;
    var b = document.createElement('button', { is: 'paper-icon-button-light' });
    b.setAttribute('is', 'paper-icon-button-light');
    b.className = 'aiofinSources autoSize';
    b.title = 'Streams';
    b.setAttribute('aria-label', 'Switch stream');
    b.innerHTML = '<span class="xlargePaperIconButton material-icons video_library" aria-hidden="true"></span>';
    b.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); openMenu(); });
    audio.parentNode.insertBefore(b, audio.nextSibling);
  }
  new MutationObserver(function () { if (!queued) { queued = true; requestAnimationFrame(addButton); } })
    .observe(document.documentElement, { childList: true, subtree: true });
}());
(function () {
  // Default the web player's bitrate cap to "auto" (unlimited) — debrid links are not bandwidth-bound.
  var get = Storage.prototype.getItem;
  Storage.prototype.getItem = function (key) {
    var v = get.call(this, key);
    if (typeof key === 'string' && /maxbitrate-video-false/i.test(key) && (v === null || v === '15000')) return '0';
    return v;
  };
}());
`;

const memo = new Map(); // abs path → { mtime, raw, gz, type }
function load(abs) {
  let st;
  try { st = fs.statSync(abs); } catch { return null; }
  if (!st.isFile()) return null;
  const m = memo.get(abs);
  if (m && m.mtime === st.mtimeMs) return m;
  const ext = path.extname(abs).toLowerCase();
  let raw = fs.readFileSync(abs);
  if (ext === '.html' && abs.startsWith(path.resolve(boot.webPath))) {
    let html = raw.toString('utf8');
    html = html.replace('</head>', `<style data-aiofin>${INJECT_CSS}</style></head>`);
    html = html.replace('</body>', `<script data-aiofin>${INJECT_JS}</script></body>`);
    raw = Buffer.from(html);
  }
  const entry = { mtime: st.mtimeMs, raw, type: MIME[ext] || 'application/octet-stream', gz: null, ext };
  if (COMPRESSIBLE.has(ext) && raw.length > 1024) entry.gz = zlib.gzipSync(raw, { level: 6 });
  if (raw.length < 8 * 1024 * 1024) memo.set(abs, entry);
  return entry;
}

function serveFile(req, res, abs, { noCache = false } = {}) {
  const f = load(abs);
  if (!f) return false;
  const name = path.basename(abs);
  const hashed = /[.-][0-9a-f]{8,}\./i.test(name) || /\.chunk\./.test(name);
  const headers = {
    'content-type': f.type,
    'cache-control': noCache || f.ext === '.html' ? 'no-cache' : hashed ? 'public, max-age=31536000, immutable' : 'public, max-age=3600',
  };
  const gzipOk = f.gz && /\bgzip\b/.test(req.headers['accept-encoding'] || '');
  const body = gzipOk ? f.gz : f.raw;
  if (gzipOk) { headers['content-encoding'] = 'gzip'; headers.vary = 'Accept-Encoding'; }
  headers['content-length'] = body.length;
  res.writeHead(200, headers);
  res.end(req.method === 'HEAD' ? undefined : body);
  return true;
}

function safeJoin(root, rel) {
  const abs = path.resolve(root, '.' + path.sep + rel);
  return abs.startsWith(path.resolve(root)) ? abs : null;
}

const NO_WEB = `<!doctype html><meta charset="utf-8"><title>AIOFin</title>
<body style="font-family:system-ui;background:#121212;color:#f5f5f7;display:grid;place-items:center;min-height:100vh;margin:0">
<div style="max-width:32rem;padding:2rem"><h1 style="margin:0 0 .5rem">AIOFin is running</h1>
<p>The Jellyfin web client isn't bundled in this build. Connect with any Jellyfin app (Infuse, Swiftfin, Jellyfin for Android/TV, Streamyfin) using this server's address, or open <a style="color:#00b354" href="/admin">the admin page</a>.</p></div>`;

async function handleStatic(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return false;
  const lp = pathname.toLowerCase();
  if (lp === '/' || lp === '') { res.writeHead(302, { location: '/web/' }); res.end(); return true; }
  if (lp === '/web') { res.writeHead(302, { location: '/web/' }); res.end(); return true; }

  if (lp === '/admin' || (lp.startsWith('/admin/') && !lp.startsWith('/admin/api/'))) {
    const rel = decodeURIComponent(pathname.slice('/admin'.length)) || '/';
    const abs = safeJoin(boot.adminPath, rel === '/' ? 'index.html' : rel);
    if (abs && serveFile(req, res, abs, { noCache: true })) return true;
    return serveFile(req, res, path.join(boot.adminPath, 'index.html'), { noCache: true });
  }

  if (lp.startsWith('/web/')) {
    const rel = decodeURIComponent(pathname.slice('/web'.length));
    if (!fs.existsSync(boot.webPath)) {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); res.end(NO_WEB); return true;
    }
    const abs = safeJoin(boot.webPath, rel === '/' ? 'index.html' : rel);
    if (abs && serveFile(req, res, abs)) return true;
    if (!path.extname(rel)) return serveFile(req, res, path.join(boot.webPath, 'index.html')); // SPA route
    res.writeHead(404); res.end(); return true;
  }
  if (lp === '/favicon.ico') return serveFile(req, res, path.join(boot.adminPath, 'fav.png'));
  if (lp === '/serviceworker.js' || lp === '/robots.txt') { res.writeHead(404); res.end(); return true; }
  return false;
}

module.exports = { handleStatic };
