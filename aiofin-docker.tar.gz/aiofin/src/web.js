'use strict';
// Serves Jellyfin Web (/web) and the admin page (/admin). Text assets are
// gzipped once and kept in memory; hashed bundles get long cache lifetimes.
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { boot } = require('./config');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.mjs': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.wasm': 'application/wasm', '.txt': 'text/plain; charset=utf-8',
  '.webmanifest': 'application/manifest+json', '.map': 'application/json', '.mp4': 'video/mp4', '.xml': 'application/xml',
};
const COMPRESSIBLE = new Set(['.html', '.js', '.mjs', '.css', '.json', '.svg', '.txt', '.webmanifest', '.map', '.xml']);

// Injected into Jellyfin Web's index.html (adapted from Remux's web patches).
const INJECT_CSS = `
  [aria-labelledby="plugins-subheader"] { display: none !important; }
  .cardOverlayButton-br { display: none !important; }
  @media (max-width: 768px) { .detailLogo { top: 27vh !important; } }
  .docspinner { top: 80px; right: 21px; left: unset; width: 46px; height: 46px; }
`;
const INJECT_JS = `
(function () {
  var ADMIN = ['/wizard', '/dashboard'];
  function isAdmin(p) { for (var i = 0; i < ADMIN.length; i++) { var a = ADMIN[i]; if (p === a || p.indexOf(a + '/') === 0 || p.indexOf(a + '?') === 0) return true; } return false; }
  function check(url) {
    try {
      var u = new URL(String(url), location.href);
      if (isAdmin(u.pathname.replace(/^\\/web/, ''))) { location.replace('/admin'); return true; }
      if (u.hash) { var h = '/' + u.hash.replace(/^#\\/?/, ''); if (isAdmin(h)) { location.replace('/admin'); return true; } }
    } catch (e) {}
    return false;
  }
  if (check(location.href)) return;
  var push = history.pushState.bind(history), rep = history.replaceState.bind(history);
  history.pushState = function (s, t, url) { if (url && check(url)) return; return push(s, t, url); };
  history.replaceState = function (s, t, url) { if (url && check(url)) return; return rep(s, t, url); };
  window.addEventListener('popstate', function () { check(location.href); });
  window.addEventListener('hashchange', function () { check(location.href); });
}());
(function () {
  // Default the web player's bitrate cap to "auto" (unlimited) — debrid links are not bandwidth-bound.
  var get = Storage.prototype.getItem;
  Storage.prototype.getItem = function (key) {
    var v = get.call(this, key);
    if (typeof key === 'string' && /maxbitrate-video-false/i.test(key) && (v === null || v === '15000')) return '0';
    return v;
  };
}());
`;

const memo = new Map(); // abs path → { mtime, raw, gz, type }
function load(abs) {
  let st;
  try { st = fs.statSync(abs); } catch { return null; }
  if (!st.isFile()) return null;
  const m = memo.get(abs);
  if (m && m.mtime === st.mtimeMs) return m;
  const ext = path.extname(abs).toLowerCase();
  let raw = fs.readFileSync(abs);
  if (ext === '.html' && abs.startsWith(path.resolve(boot.webPath))) {
    let html = raw.toString('utf8');
    html = html.replace('</head>', `<style data-aiofin>${INJECT_CSS}</style></head>`);
    html = html.replace('</body>', `<script data-aiofin>${INJECT_JS}</script></body>`);
    raw = Buffer.from(html);
  }
  const entry = { mtime: st.mtimeMs, raw, type: MIME[ext] || 'application/octet-stream', gz: null, ext };
  if (COMPRESSIBLE.has(ext) && raw.length > 1024) entry.gz = zlib.gzipSync(raw, { level: 6 });
  if (raw.length < 8 * 1024 * 1024) memo.set(abs, entry);
  return entry;
}

function serveFile(req, res, abs, { noCache = false } = {}) {
  const f = load(abs);
  if (!f) return false;
  const name = path.basename(abs);
  const hashed = /[.-][0-9a-f]{8,}\./i.test(name) || /\.chunk\./.test(name);
  const headers = {
    'content-type': f.type,
    'cache-control': noCache || f.ext === '.html' ? 'no-cache' : hashed ? 'public, max-age=31536000, immutable' : 'public, max-age=3600',
  };
  const gzipOk = f.gz && /\bgzip\b/.test(req.headers['accept-encoding'] || '');
  const body = gzipOk ? f.gz : f.raw;
  if (gzipOk) { headers['content-encoding'] = 'gzip'; headers.vary = 'Accept-Encoding'; }
  headers['content-length'] = body.length;
  res.writeHead(200, headers);
  res.end(req.method === 'HEAD' ? undefined : body);
  return true;
}

function safeJoin(root, rel) {
  const abs = path.resolve(root, '.' + path.sep + rel);
  return abs.startsWith(path.resolve(root)) ? abs : null;
}

const NO_WEB = `<!doctype html><meta charset="utf-8"><title>AIOFin</title>
<body style="font-family:system-ui;background:#121212;color:#f5f5f7;display:grid;place-items:center;min-height:100vh;margin:0">
<div style="max-width:32rem;padding:2rem"><h1 style="margin:0 0 .5rem">AIOFin is running</h1>
<p>The Jellyfin web client isn't bundled in this build. Connect with any Jellyfin app (Infuse, Swiftfin, Jellyfin for Android/TV, Streamyfin) using this server's address, or open <a style="color:#00b354" href="/admin">the admin page</a>.</p></div>`;

async function handleStatic(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return false;
  const lp = pathname.toLowerCase();
  if (lp === '/' || lp === '') { res.writeHead(302, { location: '/web/' }); res.end(); return true; }
  if (lp === '/web') { res.writeHead(302, { location: '/web/' }); res.end(); return true; }

  if (lp === '/admin' || (lp.startsWith('/admin/') && !lp.startsWith('/admin/api/'))) {
    const rel = decodeURIComponent(pathname.slice('/admin'.length)) || '/';
    const abs = safeJoin(boot.adminPath, rel === '/' ? 'index.html' : rel);
    if (abs && serveFile(req, res, abs, { noCache: true })) return true;
    return serveFile(req, res, path.join(boot.adminPath, 'index.html'), { noCache: true });
  }

  if (lp.startsWith('/web/')) {
    const rel = decodeURIComponent(pathname.slice('/web'.length));
    if (!fs.existsSync(boot.webPath)) {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); res.end(NO_WEB); return true;
    }
    const abs = safeJoin(boot.webPath, rel === '/' ? 'index.html' : rel);
    if (abs && serveFile(req, res, abs)) return true;
    if (!path.extname(rel)) return serveFile(req, res, path.join(boot.webPath, 'index.html')); // SPA route
    res.writeHead(404); res.end(); return true;
  }
  if (lp === '/favicon.ico') return serveFile(req, res, path.join(boot.adminPath, 'fav.png'));
  if (lp === '/serviceworker.js' || lp === '/robots.txt') { res.writeHead(404); res.end(); return true; }
  return false;
}

module.exports = { handleStatic };
