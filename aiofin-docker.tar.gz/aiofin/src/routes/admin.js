'use strict';
const { route, HttpError } = require('../server');
const config = require('../config');
const { settings, DEFS, DEFAULT_CSS } = config;
const store = require('../store');
const aio = require('../aio');
const transcode = require('../transcode');
const playback = require('../playback');
const { getJson } = require('../http');
const { log } = require('../util');

const setupNeeded = () => store.users.list().length === 0;

route('GET', '/admin/api/status', async (ctx) => {
  if (setupNeeded()) return { setupNeeded: true, serverName: settings.serverName };
  if (!ctx.user || !ctx.user.isAdmin) throw new HttpError(401, 'Sign in as an administrator');
  let manifest = null; let manifestError = null;
  if (aio.configured()) {
    try { const m = await aio.manifest(); manifest = { name: m.name, version: m.version, description: m.description, catalogs: (m.catalogs || []).length, resources: (m.resources || []).map((r) => (typeof r === 'string' ? r : r.name)) }; } catch (e) { manifestError = e.message; }
  }
  const s = { ...settings };
  if (s.customCss === DEFAULT_CSS) s.customCss = '';
  return {
    setupNeeded: false, serverName: settings.serverName, configured: aio.configured(), manifest, manifestError,
    settings: s, keys: Object.keys(DEFS), ffmpeg: transcode.available(),
    users: store.users.list().map((u) => ({ id: u.id, name: u.name, isAdmin: u.isAdmin, lastLogin: u.lastLogin || null })),
    caches: aio.stats(), timings: aio.timings.slice(0, 30), transcodes: transcode.active(), uptime: process.uptime(),
  };
}, { auth: false });

route('POST', '/admin/api/setup', async (ctx) => {
  if (!setupNeeded()) throw new HttpError(409, 'Setup is already complete');
  const { username, password, aioUrl } = ctx.body || {};
  if (!username || !password) throw new HttpError(400, 'Choose a username and password');
  if (aioUrl) config.update({ aioUrl });
  const u = store.users.create(username, password, true);
  log('info', `admin user "${u.name}" created`);
  aio.warmCatalogs();
  return { ok: true };
}, { auth: false });

route('POST', '/admin/api/settings', (ctx) => {
  const patch = {};
  for (const [k, v] of Object.entries(ctx.body || {})) if (k in DEFS) patch[k] = v;
  if ('customCss' in patch && !patch.customCss) patch.customCss = null;
  config.update(patch);
  return { ok: true };
}, { admin: true });

route('POST', '/admin/api/test-url', async (ctx) => {
  let url = String(ctx.body.url || '').trim().replace(/^stremio:\/\//i, 'https://');
  if (!url) throw new HttpError(400, 'Paste your AIOStreams manifest URL');
  if (!/manifest\.json/i.test(url)) url = url.replace(/\/+$/, '') + '/manifest.json';
  const t0 = Date.now();
  try {
    const m = await getJson(url, { timeout: 15_000 });
    return { ok: true, ms: Date.now() - t0, name: m.name, version: m.version, catalogs: (m.catalogs || []).length, resources: (m.resources || []).map((r) => (typeof r === 'string' ? r : r.name)) };
  } catch (e) { return { ok: false, ms: Date.now() - t0, error: e.message }; }
}, { admin: true });

route('GET', '/admin/api/catalogs', async () => {
  if (!aio.configured()) return [];
  return aio.catalogs();
}, { admin: true });

route('POST', '/admin/api/catalogs', async (ctx) => {
  const { order, disabled, names } = ctx.body || {};
  aio.saveCatPrefs({
    ...(Array.isArray(order) ? { order } : {}), ...(Array.isArray(disabled) ? { disabled } : {}),
    ...(names && typeof names === 'object' ? { names } : {}),
  });
  aio.warmCatalogs();
  return { ok: true };
}, { admin: true });

// Measure a real stream lookup, bypassing every cache.
route('POST', '/admin/api/speedtest', async (ctx) => {
  const type = ctx.body.type === 'series' ? 'series' : 'movie';
  const id = String(ctx.body.id || (type === 'movie' ? 'tt0111161' : 'tt0903747:1:1')).trim();
  const t0 = Date.now();
  try {
    const list = await aio.streams(type, id, 'speed-test', { force: true });
    const ms = Date.now() - t0;
    const t1 = Date.now();
    await aio.streams(type, id); // cached path
    return {
      ok: true, ms, cachedMs: Date.now() - t1, count: list.length,
      top: list.slice(0, 8).map((s) => ({ name: playback.sourceName(s), cached: s.cached, service: s.service })),
    };
  } catch (e) { return { ok: false, ms: Date.now() - t0, error: e.message }; }
}, { admin: true });

route('POST', '/admin/api/cache/clear', () => { aio.clearCaches(); aio.warmCatalogs(); return { ok: true }; }, { admin: true });

route('POST', '/admin/api/users', (ctx) => {
  const { name, password, isAdmin } = ctx.body || {};
  if (!name) throw new HttpError(400, 'Enter a username');
  try { const u = store.users.create(name, password || '', !!isAdmin); return { id: u.id }; } catch (e) { throw new HttpError(409, e.message); }
}, { admin: true });
route('DELETE', '/admin/api/users/:id', (ctx) => {
  if (ctx.params.id === ctx.user.id) throw new HttpError(400, "You can't delete your own account");
  store.users.remove(ctx.params.id); return { ok: true };
}, { admin: true });
route('POST', '/admin/api/users/:id/password', (ctx) => { store.users.setPassword(ctx.params.id, ctx.body.password || ''); return { ok: true }; }, { admin: true });

module.exports = {};
