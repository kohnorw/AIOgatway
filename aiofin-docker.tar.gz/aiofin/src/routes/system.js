'use strict';
const os = require('os');
const { route, HttpError } = require('../server');
const { settings, boot } = require('../config');
const store = require('../store');
const library = require('../library');

const VERSION = '12.1.0';
const empty = () => ({ Items: [], TotalRecordCount: 0, StartIndex: 0 });

function publicInfo(ctx) {
  return {
    LocalAddress: ctx.origin, ServerName: settings.serverName, Version: VERSION,
    ProductName: 'Jellyfin Server', OperatingSystem: '', Id: store.serverId(), StartupWizardCompleted: true,
  };
}

// ── System ─────────────────────────────────────────────────────────────
route('GET', '/system/info/public', (ctx) => publicInfo(ctx), { auth: false });
route('GET', '/system/info', (ctx) => ({
  ...publicInfo(ctx), OperatingSystemDisplayName: os.type(), HasPendingRestart: false, IsShuttingDown: false,
  SupportsLibraryMonitor: false, WebSocketPortNumber: boot.port, CompletedInstallations: [], CanSelfRestart: false,
  CanLaunchWebBrowser: false, ProgramDataPath: boot.dataDir, WebPath: boot.webPath, ItemsByNamePath: boot.dataDir,
  CachePath: boot.dataDir, LogPath: boot.dataDir, InternalMetadataPath: boot.dataDir, TranscodingTempPath: boot.dataDir,
  CastReceiverApplications: [], HasUpdateAvailable: false, EncoderLocation: 'System', SystemArchitecture: os.arch() === 'arm64' ? 'Arm64' : 'X64',
}));
route('GET', '/system/ping', () => 'Jellyfin Server', { auth: false });
route('POST', '/system/ping', () => 'Jellyfin Server', { auth: false });
route('GET', '/system/endpoint', () => ({ IsLocal: true, IsInNetwork: true }));
route('GET', '/system/configuration', () => ({
  UICulture: 'en-US', ServerName: settings.serverName, EnableMetrics: false, IsStartupWizardCompleted: true,
  MetadataCountryCode: 'US', PreferredMetadataLanguage: 'en', QuickConnectAvailable: false, LibraryMonitorDelay: 60,
  EnableFolderView: false, EnableGroupingIntoCollections: false, DisplaySpecialsWithinSeasons: true,
  CastReceiverApplications: [], PluginRepositories: [], EnableExternalContentInSuggestions: false,
}));
route('GET', '/system/configuration/:key', () => ({}));
route('GET', '/health', () => 'Healthy', { auth: false });
route('GET', '/system/activitylog/entries', () => empty());
route('GET', '/system/logs', () => []);

// ── Branding (ElegantFin by default, same as Remux) ────────────────────
const branding = () => ({ LoginDisclaimer: '', CustomCss: settings.customCss || '', SplashscreenEnabled: false });
route('GET', '/branding/configuration', branding, { auth: false });
route('GET', '/system/configuration/branding', branding, { auth: false });
const cssHandler = (ctx) => {
  ctx.res.writeHead(200, { 'content-type': 'text/css; charset=utf-8', 'cache-control': 'no-cache' });
  ctx.res.end(settings.customCss || '');
};
route('GET', '/branding/css', cssHandler, { auth: false });
route('GET', '/branding/css.css', cssHandler, { auth: false });
route('POST', '/system/configuration/branding', (ctx) => {
  require('../config').update({ customCss: ctx.body.CustomCss ?? '' });
}, { admin: true });

// ── Users / auth ───────────────────────────────────────────────────────
function userDto(u) {
  return {
    Name: u.name, ServerId: store.serverId(), Id: u.id, HasPassword: !!u.pw, HasConfiguredPassword: !!u.pw,
    HasConfiguredEasyPassword: false, EnableAutoLogin: false, LastLoginDate: u.lastLogin || u.created,
    LastActivityDate: u.lastLogin || u.created,
    Configuration: {
      PlayDefaultAudioTrack: true, SubtitleLanguagePreference: '', DisplayMissingEpisodes: false, GroupedFolders: [],
      SubtitleMode: 'Default', DisplayCollectionsView: false, EnableLocalPassword: false, OrderedViews: [],
      LatestItemsExcludes: [], MyMediaExcludes: [], HidePlayedInLatest: true, RememberAudioSelections: true,
      RememberSubtitleSelections: true, EnableNextEpisodeAutoPlay: true, CastReceiverId: 'F007D354',
      ...(u.config || {}),
    },
    Policy: {
      IsAdministrator: !!u.isAdmin, IsHidden: true, EnableCollectionManagement: false, EnableSubtitleManagement: false,
      EnableLyricManagement: false, IsDisabled: false, BlockedTags: [], AllowedTags: [], EnableUserPreferenceAccess: true,
      AccessSchedules: [], BlockUnratedItems: [], EnableRemoteControlOfOtherUsers: false, EnableSharedDeviceControl: false,
      EnableRemoteAccess: true, EnableLiveTvManagement: false, EnableLiveTvAccess: false, EnableMediaPlayback: true,
      EnableAudioPlaybackTranscoding: true, EnableVideoPlaybackTranscoding: true, EnablePlaybackRemuxing: true,
      ForceRemoteSourceTranscoding: false, EnableContentDeletion: false, EnableContentDeletionFromFolders: [],
      EnableContentDownloading: false, EnableSyncTranscoding: false, EnableMediaConversion: false, EnabledDevices: [],
      EnableAllDevices: true, EnabledChannels: [], EnableAllChannels: true, EnabledFolders: [], EnableAllFolders: true,
      InvalidLoginAttemptCount: 0, LoginAttemptsBeforeLockout: -1, MaxActiveSessions: 0, EnablePublicSharing: false,
      BlockedMediaFolders: [], BlockedChannels: [], RemoteClientBitrateLimit: 0,
      AuthenticationProviderId: 'Jellyfin.Server.Implementations.Users.DefaultAuthenticationProvider',
      PasswordResetProviderId: 'Jellyfin.Server.Implementations.Users.DefaultPasswordResetProvider', SyncPlayAccess: 'None',
    },
  };
}

route('GET', '/users/public', () => [], { auth: false });
route('POST', '/users/authenticatebyname', (ctx) => {
  const name = ctx.body.Username || ctx.body.username;
  const pw = ctx.body.Pw ?? ctx.body.pw ?? ctx.body.Password ?? '';
  const u = store.users.byName(name);
  if (!u || !store.users.checkPassword(pw, u.pw)) throw new HttpError(401, 'Invalid username or password');
  const token = store.tokens.create(u.id, { client: ctx.auth.client, device: ctx.auth.device, deviceId: ctx.auth.deviceId, version: ctx.auth.version });
  store.users.update(u.id, { lastLogin: new Date().toISOString() });
  return {
    User: userDto(u),
    SessionInfo: {
      PlayState: { CanSeek: false, IsPaused: false, IsMuted: false, RepeatMode: 'RepeatNone' },
      AdditionalUsers: [], Capabilities: { PlayableMediaTypes: [], SupportedCommands: [], SupportsMediaControl: false },
      RemoteEndPoint: ctx.req.socket.remoteAddress, PlayableMediaTypes: [], Id: token.slice(0, 32), UserId: u.id,
      UserName: u.name, Client: ctx.auth.client, LastActivityDate: new Date().toISOString(), DeviceName: ctx.auth.device,
      DeviceId: ctx.auth.deviceId, ApplicationVersion: ctx.auth.version, IsActive: true, SupportsMediaControl: false,
      SupportsRemoteControl: false, HasCustomDeviceName: false, ServerId: store.serverId(), SupportedCommands: [],
    },
    AccessToken: token, ServerId: store.serverId(),
  };
}, { auth: false });
route('GET', '/users/me', (ctx) => userDto(ctx.user));
route('GET', '/users', () => store.users.list().map(userDto), { admin: true });
route('GET', '/users/:id', (ctx) => {
  const u = store.users.get(ctx.params.id);
  if (!u) throw new HttpError(404, 'User not found');
  return userDto(u);
});
route('POST', '/users/configuration', (ctx) => { store.users.update(ctx.user.id, { config: ctx.body || {} }); });
route('POST', '/users/:id/configuration', (ctx) => { store.users.update(ctx.user.id, { config: ctx.body || {} }); });
route('POST', '/users/password', (ctx) => changePw(ctx));
route('POST', '/users/:id/password', (ctx) => changePw(ctx));
function changePw(ctx) {
  const target = store.users.get(ctx.params.id || ctx.user.id) || ctx.user;
  if (target.id !== ctx.user.id && !ctx.user.isAdmin) throw new HttpError(403, 'Forbidden');
  if (!ctx.user.isAdmin && !store.users.checkPassword(ctx.body.CurrentPw || '', target.pw)) throw new HttpError(403, 'Current password is incorrect');
  store.users.setPassword(target.id, ctx.body.NewPw || '');
}
route('POST', '/sessions/logout', (ctx) => { if (ctx.auth.token) store.tokens.remove(ctx.auth.token); });
route('GET', '/quickconnect/enabled', () => false, { auth: false });
route('GET', '/auth/providers', () => []);
route('GET', '/auth/passwordresetproviders', () => []);

// ── Display preferences ────────────────────────────────────────────────
route('GET', '/displaypreferences/:id', (ctx) => {
  const client = ctx.query.client || 'emby';
  return store.displayPrefs.get(ctx.user.id, ctx.params.id, client) || {
    Id: ctx.params.id, SortBy: 'SortName', RememberIndexing: false, PrimaryImageHeight: 250, PrimaryImageWidth: 250,
    CustomPrefs: {}, ScrollDirection: 'Horizontal', ShowBackdrop: true, RememberSorting: false, SortOrder: 'Ascending',
    ShowSidebar: false, Client: client,
  };
});
route('POST', '/displaypreferences/:id', (ctx) => {
  store.displayPrefs.set(ctx.user.id, ctx.params.id, ctx.query.client || 'emby', ctx.body);
});

// ── Things a media server has but this one doesn't need ────────────────
for (const p of ['/localization/cultures', '/localization/countries', '/localization/parentalratings', '/localization/options',
  '/plugins', '/packages', '/repositories', '/scheduledtasks', '/sessions', '/syncplay/list', '/devices/options',
  '/library/virtualfolders', '/notifications/types', '/web/configurationpages', '/items/:id/specialfeatures',
  '/items/:id/localtrailers', '/users/:uid/items/:id/specialfeatures', '/users/:uid/items/:id/localtrailers',
  '/items/:id/ancestors', '/items/:id/criticreviews', '/livetv/channels/:id', '/items/:id/externalidinfos']) {
  route('GET', p, () => []);
}
for (const p of ['/genres', '/studios', '/persons', '/artists', '/musicgenres', '/items/:id/similar', '/movies/:id/similar',
  '/shows/:id/similar', '/livetv/programs', '/livetv/programs/recommended', '/livetv/channels', '/livetv/recordings',
  '/playlists', '/collections', '/items/:id/intros', '/users/:uid/items/:id/intros', '/trailers', '/devices',
  '/system/activitylog/entries', '/mediasegments/:id', '/items/:id/thememedia/songs', '/items/:id/themesongs',
  '/items/:id/themevideos']) {
  route('GET', p, () => empty());
}
route('GET', '/livetv/info', () => ({ Services: [], IsEnabled: false, EnabledUsers: [] }));
route('GET', '/items/:id/thememedia', () => ({
  ThemeVideosResult: { ...empty(), OwnerId: '' }, ThemeSongsResult: { ...empty(), OwnerId: '' },
  SoundtrackSongsResult: { ...empty(), OwnerId: '' },
}));
route('GET', '/items/filters', () => ({ Genres: [], Tags: [], OfficialRatings: [], Years: [] }));
route('GET', '/items/filters2', () => ({ Genres: [], Tags: [] }));
route('GET', '/movies/recommendations', () => []);
route('POST', '/sessions/capabilities', () => undefined);
route('POST', '/sessions/capabilities/full', () => undefined);
route('POST', '/clientlog/document', () => ({ FileName: 'log.txt' }));
route('GET', '/library/mediafolders', async () => {
  const v = await library.views();
  return { Items: v.map(library.viewDto), TotalRecordCount: v.length, StartIndex: 0 };
});

module.exports = { userDto, VERSION };
