'use strict';
const fs = require('fs');
const { route, HttpError } = require('../server');
const { settings } = require('../config');
const aio = require('../aio');
const library = require('../library');
const playback = require('../playback');
const transcode = require('../transcode');
const store = require('../store');
const { openStream, request } = require('../http');
const { log, TICKS_PER_SEC } = require('../util');

// ── PlaybackInfo ───────────────────────────────────────────────────────
async function playbackInfo(ctx) {
  const id = ctx.params.id.replace(/-/g, '').toLowerCase();
  const b = ctx.body || {};
  const info = await playback.playbackInfo(id, {
    profile: b.DeviceProfile || null,
    mediaSourceId: (ctx.query.mediasourceid || b.MediaSourceId || '').replace(/-/g, '').toLowerCase() || null,
    audioStreamIndex: ctx.query.audiostreamindex ?? b.AudioStreamIndex ?? null,
    auth: ctx.auth, token: ctx.auth.token, origin: ctx.origin, userId: ctx.user.id,
  });
  if (!info) throw new HttpError(404, 'Item is not playable');
  return info;
}
route('POST', '/items/:id/playbackinfo', playbackInfo);
route('GET', '/items/:id/playbackinfo', playbackInfo);

// ── Stream: 302 to the source (fast path) or proxy when required ───────
async function stream(ctx) {
  const id = ctx.params.id.replace(/-/g, '').toLowerCase();
  if (ctx.params.file && !/^stream(\.|$)/i.test(ctx.params.file)) throw new HttpError(404, 'Not found');
  const msid = (ctx.query.mediasourceid || '').replace(/-/g, '').toLowerCase();
  const src = await playback.resolveSource(id, msid);
  if (!src) throw new HttpError(404, 'No stream available');
  const mustProxy = settings.streamMode === 'proxy' || !!src.headers || (settings.proxyInternal && playback.isInternalHost(src.url));
  if (!mustProxy) {
    ctx.res.writeHead(302, { location: src.url, 'cache-control': 'no-store' });
    return ctx.res.end();
  }
  const headers = { ...(src.headers || {}) };
  if (ctx.req.headers.range) headers.range = ctx.req.headers.range;
  const up = await openStream(src.url, headers);
  const pass = {};
  for (const h of ['content-type', 'content-length', 'content-range', 'accept-ranges', 'last-modified', 'etag']) if (up.headers[h]) pass[h] = up.headers[h];
  if (!pass['accept-ranges']) pass['accept-ranges'] = 'bytes';
  ctx.res.writeHead(up.statusCode, pass);
  if (ctx.req.method === 'HEAD') { up.destroy(); return ctx.res.end(); }
  up.pipe(ctx.res);
  ctx.res.on('close', () => up.destroy());
}
route('GET', '/videos/:id/stream', stream, { auth: false });
route('GET', '/videos/:id/:file', stream, { auth: false });
route('GET', '/items/:id/download', stream, { auth: false });

// ── HLS fallback ───────────────────────────────────────────────────────
route('GET', '/videos/:id/hls/:sess/:file', async (ctx) => {
  if (!transcode.available()) throw new HttpError(404, 'Transcoding disabled');
  const sess = ctx.params.sess;
  if (!/^[a-f0-9]{32}\.[a-f0-9]{32}$/.test(sess)) throw new HttpError(400, 'bad session');
  const sid = sess.split('.')[1];
  const src = await playback.resolveSource(ctx.params.id.replace(/-/g, '').toLowerCase(), sid);
  if (!src) throw new HttpError(404, 'Source not found');
  const vcodecs = String(ctx.query.vcodecs || 'h264').toLowerCase().split(',');
  const audioIndex = ctx.query.audio !== undefined ? parseInt(ctx.query.audio, 10) : null;
  let s = null; let lastErr = null;
  // If the chosen stream won't open (dead link, bad file), quietly move on to the next one.
  const candidates = [src, ...(await playback.fallbacks(ctx.params.id.replace(/-/g, '').toLowerCase(), src.sid))];
  for (const cand of candidates) {
    try {
      s = await transcode.getSession(sess, cand, vcodecs, cand === src ? audioIndex : null);
      if (cand !== src) log('warn', `stream ${src.sid.slice(0, 8)} failed (${lastErr && lastErr.message}); playing ${cand.sid.slice(0, 8)} instead`);
      break;
    } catch (e) { lastErr = e; }
  }
  if (!s) throw new HttpError(502, `Could not open any stream: ${lastErr && lastErr.message}`);
  const file = ctx.params.file;
  if (/\.m3u8$/i.test(file)) {
    const body = transcode.playlist(s, '');
    ctx.res.writeHead(200, { 'content-type': 'application/vnd.apple.mpegurl', 'cache-control': 'no-cache' });
    return ctx.res.end(body);
  }
  const n = parseInt(file, 10);
  if (!Number.isFinite(n) || n < 0 || n >= s.segments) throw new HttpError(404, 'segment out of range');
  const p = await transcode.segment(s, n);
  const st = fs.statSync(p);
  ctx.res.writeHead(200, { 'content-type': 'video/mp2t', 'content-length': st.size, 'cache-control': 'no-cache' });
  fs.createReadStream(p).pipe(ctx.res);
}, { auth: false });
route('DELETE', '/videos/activeencodings', (ctx) => { transcode.stopByPlaySession(ctx.query.playsessionid); }, { auth: false });

// ── In-player stream switcher (used by the button injected into Jellyfin Web) ──
route('GET', '/aiofin/items/:id/sources', async (ctx) => {
  const r = await playback.sourceList(ctx.params.id.replace(/-/g, '').toLowerCase(), ctx.user.id);
  if (!r) throw new HttpError(404, 'Item is not playable');
  return r;
});

// ── External subtitles (from AIOStreams' subtitle add-ons) ─────────────
function srtToVtt(text) {
  const body = text.replace(/\r+/g, '').replace(/^\uFEFF/, '').replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2');
  return `WEBVTT\n\n${body.replace(/^\d+\n(?=\d{2}:\d{2})/gm, '')}`;
}
async function subtitle(ctx) {
  const key = `${ctx.params.sid.replace(/-/g, '').toLowerCase()}:${ctx.params.index}`;
  const url = playback.subtitleUrls.get(key);
  if (!url) throw new HttpError(404, 'Subtitle not found');
  const res = await request(url, { timeout: 15_000 });
  if (res.status >= 400) throw new HttpError(502, 'Subtitle download failed');
  let text = res.body.toString('utf8');
  const wantVtt = /\.vtt$/i.test(ctx.params.file || '');
  if (wantVtt && !/^\uFEFF?WEBVTT/.test(text)) text = srtToVtt(text);
  ctx.res.writeHead(200, { 'content-type': wantVtt ? 'text/vtt; charset=utf-8' : 'application/x-subrip; charset=utf-8', 'cache-control': 'public, max-age=86400' });
  ctx.res.end(text);
}
route('GET', '/videos/:id/:sid/subtitles/:index/:ticks/:file', subtitle, { auth: false });
route('GET', '/videos/:id/:sid/subtitles/:index/:file', subtitle, { auth: false });

// ── Playback reporting + next-episode prewarm ──────────────────────────
const nearEndFired = new Map();

async function prewarmNext(itemId, count) {
  const t = library.streamTarget(itemId);
  if (!t || t.r.kind !== 'episode' || count <= 0) return;
  try {
    const { next } = await library.nextEpisodes(t.r.type, t.r.sid, t.r.videoId, count);
    for (const v of next) aio.prefetch(t.r.type, v.id, 'next-episode');
  } catch (e) { log('debug', `prewarm failed: ${e.message}`); }
}

async function report(ctx, phase) {
  const b = ctx.body || {};
  const id = String(b.ItemId || ctx.params.id || '').replace(/-/g, '').toLowerCase();
  if (!id) return;
  const uid = ctx.user.id;
  const pos = Number(b.PositionTicks ?? ctx.query.positionticks ?? 0) || 0;
  const cur = store.userData.get(uid, id) || {};
  let snap = cur.snap;
  if (!snap) snap = await library.snapshot(uid, id);
  const runtime = snap?.RunTimeTicks || 0;
  const patch = { pos, lastPlayed: Date.now(), ...(snap ? { snap } : {}) };

  if (phase === 'start') {
    store.userData.upsert(uid, id, patch);
    prewarmNext(id, settings.prewarmEpisodes);
  } else if (phase === 'progress') {
    store.userData.upsert(uid, id, patch);
    // Last 5 minutes: refresh the very next episode so autoplay is instant.
    if (runtime && runtime - pos < 5 * 60 * TICKS_PER_SEC && !nearEndFired.has(id)) {
      nearEndFired.set(id, Date.now());
      if (nearEndFired.size > 500) nearEndFired.delete(nearEndFired.keys().next().value);
      prewarmNext(id, 1);
    }
  } else if (phase === 'stop') {
    const finished = runtime ? pos >= runtime * 0.9 : false;
    store.userData.upsert(uid, id, finished
      ? { ...patch, pos: 0, played: true, playCount: (cur.playCount || 0) + 1 }
      : patch);
    if (b.PlaySessionId) transcode.stopByPlaySession(b.PlaySessionId);
  }
}
route('POST', '/sessions/playing', (ctx) => report(ctx, 'start'));
route('POST', '/sessions/playing/progress', (ctx) => report(ctx, 'progress'));
route('POST', '/sessions/playing/stopped', (ctx) => report(ctx, 'stop'));
route('POST', '/sessions/playing/ping', () => undefined);
route('POST', '/users/:uid/playingitems/:id', (ctx) => report(ctx, 'start'));
route('POST', '/users/:uid/playingitems/:id/progress', (ctx) => report(ctx, 'progress'));
route('DELETE', '/users/:uid/playingitems/:id', (ctx) => report(ctx, 'stop'));
route('POST', '/playingitems/:id', (ctx) => report(ctx, 'start'));
route('POST', '/playingitems/:id/progress', (ctx) => report(ctx, 'progress'));
route('DELETE', '/playingitems/:id', (ctx) => report(ctx, 'stop'));

module.exports = {};
