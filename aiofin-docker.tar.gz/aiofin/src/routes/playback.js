'use strict';
const fs = require('fs');
const { route, HttpError } = require('../server');
const { settings } = require('../config');
const aio = require('../aio');
const library = require('../library');
const playback = require('../playback');
const transcode = require('../transcode');
const subtitles = require('../subtitles');
const embedsubs = require('../embedsubs');
const attachments = require('../attachments');
const probe = require('../probe');
const store = require('../store');
const { openStream, request } = require('../http');
const { log, TICKS_PER_SEC } = require('../util');

// ── PlaybackInfo ───────────────────────────────────────────────────────
async function playbackInfo(ctx) {
  let id = ctx.params.id.replace(/-/g, '').toLowerCase();
  // A version id used as the item id: play that version of its title.
  const owner = !library.streamTarget(id) && library.ownerOf(id);
  if (owner) { if (!ctx.query.mediasourceid) ctx.query.mediasourceid = id; id = owner; }
  const b = ctx.body || {};
  const info = await playback.playbackInfo(id, {
    profile: b.DeviceProfile || null,
    mediaSourceId: (ctx.query.mediasourceid || b.MediaSourceId || '').replace(/-/g, '').toLowerCase() || null,
    audioStreamIndex: ctx.query.audiostreamindex ?? b.AudioStreamIndex ?? null,
    subtitleStreamIndex: ctx.query.subtitlestreamindex ?? b.SubtitleStreamIndex ?? null,
    auth: ctx.auth, token: ctx.auth.token, origin: ctx.origin, userId: ctx.user.id,
  });
  if (!info) throw new HttpError(404, 'Item is not playable');
  return info;
}
route('POST', '/items/:id/playbackinfo', playbackInfo);
route('GET', '/items/:id/playbackinfo', playbackInfo);

// ── Stream: 302 to the source (fast path) or proxy when required ───────
async function stream(ctx) {
  const id = ctx.params.id.replace(/-/g, '').toLowerCase();
  if (ctx.params.file && !/^stream(\.|$)/i.test(ctx.params.file)) throw new HttpError(404, 'Not found');
  const msid = (ctx.query.mediasourceid || '').replace(/-/g, '').toLowerCase();
  const src = await playback.resolveSource(id, msid);
  if (!src) throw new HttpError(404, 'No stream available');
  const mustProxy = settings.streamMode === 'proxy' || !!src.headers || (settings.proxyInternal && playback.isInternalHost(src.url));
  if (!mustProxy) {
    ctx.res.writeHead(302, { location: src.url, 'cache-control': 'no-store' });
    return ctx.res.end();
  }
  const headers = { ...(src.headers || {}) };
  if (ctx.req.headers.range) headers.range = ctx.req.headers.range;
  const up = await openStream(src.url, headers);
  const pass = {};
  for (const h of ['content-type', 'content-length', 'content-range', 'accept-ranges', 'last-modified', 'etag']) if (up.headers[h]) pass[h] = up.headers[h];
  if (!pass['accept-ranges']) pass['accept-ranges'] = 'bytes';
  ctx.res.writeHead(up.statusCode, pass);
  if (ctx.req.method === 'HEAD') { up.destroy(); return ctx.res.end(); }
  // A dropped upstream or viewer must only end this response, never the server.
  up.on('error', (e) => { log('debug', `proxy upstream error: ${e.message}`); ctx.res.destroy(); });
  ctx.res.on('error', () => up.destroy());
  ctx.res.on('close', () => up.destroy());
  up.pipe(ctx.res);
}
route('GET', '/videos/:id/stream', stream, { auth: false });
route('GET', '/videos/:id/:file', stream, { auth: false });
route('GET', '/items/:id/download', stream, { auth: false });

// ── HLS fallback ───────────────────────────────────────────────────────
route('GET', '/videos/:id/hls/:sess/:file', async (ctx) => {
  if (!transcode.available()) throw new HttpError(404, 'Transcoding disabled');
  const sess = ctx.params.sess;
  if (!/^[a-f0-9]{32}\.[a-f0-9]{32}$/.test(sess)) throw new HttpError(400, 'bad session');
  const sid = sess.split('.')[1];
  const src = await playback.resolveSource(ctx.params.id.replace(/-/g, '').toLowerCase(), sid);
  if (!src) throw new HttpError(404, 'Source not found');
  const vcodecs = String(ctx.query.vcodecs || 'h264').toLowerCase().split(',');
  if (ctx.auth.deviceId) playback.deviceCodecs.set(ctx.auth.deviceId, vcodecs);
  const audioIndex = ctx.query.audio !== undefined ? parseInt(ctx.query.audio, 10) : null;
  const burnIndex = ctx.query.burn !== undefined ? parseInt(ctx.query.burn, 10) : null;
  let s = null; let lastErr = null;
  // If the chosen stream won't open (dead link, bad file), quietly move on to the next one.
  const candidates = [src, ...(await playback.fallbacks(ctx.params.id.replace(/-/g, '').toLowerCase(), src.sid))];
  for (const cand of candidates) {
    try {
      s = await transcode.getSession(sess, cand, vcodecs, cand === src ? audioIndex : null, cand === src ? burnIndex : null);
      if (cand !== src) log('warn', `stream ${src.sid.slice(0, 8)} failed (${lastErr && lastErr.message}); playing ${cand.sid.slice(0, 8)} instead`);
      break;
    } catch (e) { lastErr = e; }
  }
  if (!s) throw new HttpError(502, `Could not open any stream: ${lastErr && lastErr.message}`);
  const file = ctx.params.file;
  if (/\.m3u8$/i.test(file)) {
    const body = transcode.playlist(s, '');
    ctx.res.writeHead(200, { 'content-type': 'application/vnd.apple.mpegurl', 'cache-control': 'no-cache' });
    return ctx.res.end(body);
  }
  const n = parseInt(file, 10);
  if (!Number.isFinite(n) || n < 0 || n >= s.segments) throw new HttpError(404, 'segment out of range');
  const p = await transcode.segment(s, n).catch((e) => { throw new HttpError(e.status || 504, e.message); });
  // Read it whole: segments are small, and a session can be torn down (stream
  // switch, stop) between here and the end of a streamed read.
  let data;
  try { data = await fs.promises.readFile(p); } catch { throw new HttpError(410, 'segment no longer available'); }
  ctx.res.writeHead(200, { 'content-type': 'video/mp2t', 'content-length': data.length, 'cache-control': 'no-cache' });
  ctx.res.end(data);
}, { auth: false });
route('DELETE', '/videos/activeencodings', (ctx) => { transcode.stopByPlaySession(ctx.query.playsessionid); }, { auth: false });

// ── In-player stream switcher (used by the button injected into Jellyfin Web) ──
route('GET', '/aiofin/items/:id/sources', async (ctx) => {
  const r = await playback.sourceList(ctx.params.id.replace(/-/g, '').toLowerCase(), ctx.user.id);
  if (!r) throw new HttpError(404, 'Item is not playable');
  return r;
});

// Details page: one stream's real tracks, read on demand when someone picks that
// version. Doesn't count as choosing it (that happens when they press Play).
route('GET', '/aiofin/items/:id/sources/:sid', async (ctx) => {
  const info = await playback.playbackInfo(ctx.params.id.replace(/-/g, '').toLowerCase(), {
    profile: null, mediaSourceId: ctx.params.sid.toLowerCase(), auth: ctx.auth, token: ctx.auth.token,
    origin: ctx.origin, userId: ctx.user.id, remember: false, forceProbe: true,
  });
  const src = info && info.MediaSources && info.MediaSources[0];
  if (!src) throw new HttpError(404, 'Stream not found');
  return src;
});

// ── External subtitles (from AIOStreams' subtitle add-ons) ─────────────
async function subtitle(ctx) {
  const key = `${ctx.params.sid.replace(/-/g, '').toLowerCase()}:${ctx.params.index}`;
  const url = playback.subtitleUrls.get(key);
  if (!url) throw new HttpError(404, 'Subtitle not found');
  const file = String(ctx.params.file || '').toLowerCase();
  const head = { 'cache-control': 'public, max-age=86400' };
  let events;
  try {
    if (url.startsWith('embedded:')) {
      // A track inside the video file: read it out of the file (first time only).
      const sid = ctx.params.sid.replace(/-/g, '').toLowerCase();
      const src = await playback.resolveSource(ctx.params.id.replace(/-/g, '').toLowerCase(), sid);
      if (!src) throw new Error('stream not found');
      const info = await probe.probe(src);
      const index = parseInt(url.slice(9), 10);
      // Native formats for players that draw them: styled ASS, PGS pictures.
      if (file.endsWith('.ass') || file.endsWith('.ssa')) {
        const text = await embedsubs.ass(src, info, index);
        ctx.res.writeHead(200, { ...head, 'content-type': 'text/x-ssa; charset=utf-8' });
        return ctx.res.end(text);
      }
      if (file.endsWith('.sup')) {
        const buf = await embedsubs.sup(src, info, index);
        ctx.res.writeHead(200, { ...head, 'content-type': 'application/octet-stream', 'content-length': buf.length });
        return ctx.res.end(buf);
      }
      if (ctx.query.live) {
        // Progressive: answer at once with what's known; the page script asks
        // again for more until the reply says the track is complete.
        let cur = embedsubs.current(src, info, index);
        for (let waited = 0; !cur.complete && !cur.events.length && waited < 6000; waited += 250) {
          await new Promise((r) => setTimeout(r, 250));
          cur = embedsubs.current(src, info, index);
        }
        const done = cur.complete ? '1' : '0';
        if (file.endsWith('.js') || file.endsWith('.json')) {
          ctx.res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-aiofin-complete': done });
          return ctx.res.end(JSON.stringify(subtitles.toJson(cur.events)));
        }
        ctx.res.writeHead(200, { 'content-type': 'text/vtt; charset=utf-8', 'cache-control': 'no-store', 'x-aiofin-complete': done });
        return ctx.res.end(subtitles.toVtt(cur.events));
      }
      events = await embedsubs.events(src, info, index);
    } else {
      events = await subtitles.load(url);
    }
  } catch (e) { throw new HttpError(502, e.message); }
  // Jellyfin Web (and the iOS/Android apps built on it) asks for .js: Jellyfin's JSON caption format.
  if (file.endsWith('.js') || file.endsWith('.json')) {
    ctx.res.writeHead(200, { ...head, 'content-type': 'application/json; charset=utf-8' });
    return ctx.res.end(JSON.stringify(subtitles.toJson(events)));
  }
  if (file.endsWith('.srt')) {
    ctx.res.writeHead(200, { ...head, 'content-type': 'application/x-subrip; charset=utf-8' });
    return ctx.res.end(subtitles.toSrt(events));
  }
  ctx.res.writeHead(200, { ...head, 'content-type': 'text/vtt; charset=utf-8' });
  ctx.res.end(subtitles.toVtt(events));
}
route('GET', '/videos/:id/:sid/subtitles/:index/:ticks/:file', subtitle, { auth: false });
route('GET', '/videos/:id/:sid/subtitles/:index/:file', subtitle, { auth: false });

// ── Attachments inside the file (fonts for styled subtitles) ───────────
route('GET', '/videos/:id/:sid/attachments/:index', async (ctx) => {
  const sid = ctx.params.sid.replace(/-/g, '').toLowerCase();
  const src = await playback.resolveSource(ctx.params.id.replace(/-/g, '').toLowerCase(), sid);
  if (!src) throw new HttpError(404, 'Stream not found');
  const info = await probe.probe(src).catch(() => null);
  const att = info && (info.attachments || []).find((a) => a.index === parseInt(ctx.params.index, 10));
  if (!att) throw new HttpError(404, 'Attachment not found');
  const data = await attachments.get(src, att).catch((e) => { throw new HttpError(502, e.message); });
  ctx.res.writeHead(200, { 'content-type': att.mimetype, 'content-length': data.length, 'cache-control': 'public, max-age=604800' });
  ctx.res.end(data);
}, { auth: false });

// ── Playback reporting + next-episode prewarm ──────────────────────────
const nearEndFired = new Map();

async function prewarmNext(itemId, count) {
  const t = library.streamTarget(itemId);
  if (!t || t.r.kind !== 'episode' || count <= 0) return;
  try {
    const { next } = await library.nextEpisodes(t.r.type, t.r.sid, t.r.videoId, count);
    for (const v of next) aio.prefetch(t.r.type, v.id, 'next-episode');
  } catch (e) { log('debug', `prewarm failed: ${e.message}`); }
}

async function report(ctx, phase) {
  const b = ctx.body || {};
  const id = String(b.ItemId || ctx.params.id || '').replace(/-/g, '').toLowerCase();
  if (!id) return;
  const uid = ctx.user.id;
  const pos = Number(b.PositionTicks ?? ctx.query.positionticks ?? 0) || 0;
  const cur = store.userData.get(uid, id) || {};
  let snap = cur.snap;
  if (!snap) snap = await library.snapshot(uid, id);
  const runtime = snap?.RunTimeTicks || 0;
  const patch = { pos, lastPlayed: Date.now(), ...(snap ? { snap } : {}) };

  if (phase === 'start') {
    store.userData.upsert(uid, id, patch);
    prewarmNext(id, settings.prewarmEpisodes);
  } else if (phase === 'progress') {
    store.userData.upsert(uid, id, patch);
    // Last 5 minutes: refresh the very next episode so autoplay is instant.
    if (runtime && runtime - pos < 5 * 60 * TICKS_PER_SEC && !nearEndFired.has(id)) {
      nearEndFired.set(id, Date.now());
      if (nearEndFired.size > 500) nearEndFired.delete(nearEndFired.keys().next().value);
      prewarmNext(id, 1);
    }
  } else if (phase === 'stop') {
    const finished = runtime ? pos >= runtime * 0.9 : false;
    store.userData.upsert(uid, id, finished
      ? { ...patch, pos: 0, played: true, playCount: (cur.playCount || 0) + 1 }
      : patch);
    if (b.PlaySessionId) transcode.stopByPlaySession(b.PlaySessionId);
  }
}
route('POST', '/sessions/playing', (ctx) => report(ctx, 'start'));
route('POST', '/sessions/playing/progress', (ctx) => report(ctx, 'progress'));
route('POST', '/sessions/playing/stopped', (ctx) => report(ctx, 'stop'));
route('POST', '/sessions/playing/ping', () => undefined);
route('POST', '/users/:uid/playingitems/:id', (ctx) => report(ctx, 'start'));
route('POST', '/users/:uid/playingitems/:id/progress', (ctx) => report(ctx, 'progress'));
route('DELETE', '/users/:uid/playingitems/:id', (ctx) => report(ctx, 'stop'));
route('POST', '/playingitems/:id', (ctx) => report(ctx, 'start'));
route('POST', '/playingitems/:id/progress', (ctx) => report(ctx, 'progress'));
route('DELETE', '/playingitems/:id', (ctx) => report(ctx, 'stop'));

module.exports = {};
