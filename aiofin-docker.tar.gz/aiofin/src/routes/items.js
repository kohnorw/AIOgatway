'use strict';
const { route, redirect, HttpError } = require('../server');
const { settings } = require('../config');
const aio = require('../aio');
const library = require('../library');
const coll = require('../collections');
const playback = require('../playback');
const store = require('../store');
const { openStream } = require('../http');
const { pMap, withTimeout, log } = require('../util');

const runsJellyfinWeb = (auth) => playback.runsJellyfinWeb(auth);

const list = (s) => String(s || '').split(',').map((x) => x.trim()).filter(Boolean);
const lower = (s) => list(s).map((x) => x.toLowerCase());
const qr = (items, total, start = 0) => ({ Items: items, TotalRecordCount: total ?? items.length, StartIndex: start });
const page = (items, start, limit) => qr(items.slice(start, start + limit), items.length, start);

const TYPE_MAP = { movie: ['movie'], series: ['series', 'anime'] };
function stremioTypes(types) {
  if (!types.length) return null;
  const out = types.flatMap((t) => TYPE_MAP[t] || []);
  return out.length ? out : [];
}
const typeOk = (dto, types) => !types.length || types.includes(dto.Type.toLowerCase());
// Everything AIOFin serves is video. Jellyfin Web's "Continue Listening" and
// "Continue Reading" rows ask for MediaTypes=Audio / Book: they must come back empty.
const videoWanted = (q) => { const mt = lower(q.mediatypes); return !mt.length || mt.includes('video'); };

// ── Views ──────────────────────────────────────────────────────────────
async function userViews() {
  const v = await library.views();
  const out = v.map(library.viewDto);
  if (coll.list().length) out.push(coll.viewDto());
  return qr(out);
}
route('GET', '/userviews', userViews);
route('GET', '/users/:uid/views', userViews);
route('GET', '/userviews/groupingoptions', () => []);
route('GET', '/users/:uid/groupingoptions', () => []);

// ── Library-wide episodes and genres (live-TV apps like NostalgiaTV) ───
// These apps build channels from "every episode in the TV library" or "every
// show in a genre". Stremio catalogs have no such query, so the series in the
// library's first catalog pages are expanded into their episodes (metadata is
// cached, so this is slow only the first time).
const POOL_SERIES = 40;
const poolCache = new Map(); // key → { at, items }
async function catalogPool(views, uid) {
  const key = views.map((v) => v.key).join(',');
  const hit = poolCache.get(key);
  if (hit && Date.now() - hit.at < 30 * 60_000) return hit.items;
  const out = [];
  for (const v of views) {
    const res = await library.catalogItems(v.key, 0, POOL_SERIES, uid).catch(() => ({ items: [] }));
    out.push(...res.items);
  }
  // Catalog listings often leave genres out; fill them in from the full
  // details (cached metadata) so genre channels work.
  await pMap(out.filter((d) => !(d.Genres && d.Genres.length)), 2, async (d) => {
    const full = await library.getItem(d.Id, uid, { full: false }).catch(() => null);
    if (full && full.Genres && full.Genres.length) { d.Genres = full.Genres; d.GenreItems = full.GenreItems; }
  });
  poolCache.set(key, { at: Date.now(), items: out });
  return out;
}
async function viewsFor(parentId, kinds) {
  const all = (await library.views()).filter((c) => !c.virtual);
  if (parentId) {
    const r = library.resolve(parentId);
    if (r && r.kind === 'view') return all.filter((c) => c.key === r.catKey);
  }
  return all.filter((c) => kinds.includes(c.type === 'movie' ? 'movie' : 'series'));
}
const epCache = new Map(); // series id → { at, eps }
async function seriesEpisodes(seriesId, uid) {
  const hit = epCache.get(seriesId);
  if (hit && Date.now() - hit.at < 30 * 60_000) return hit.eps;
  const eps = (await library.episodes(seriesId, uid).catch(() => [])).filter((e) => e.LocationType !== 'Virtual');
  epCache.set(seriesId, { at: Date.now(), eps });
  return eps;
}
function genreFilter(q) {
  const names = String(q.genres || '').split('|').map((x) => x.trim().toLowerCase()).filter(Boolean);
  const ids = lower(q.genreids).map((x) => x.replace(/-/g, ''));
  if (!names.length && !ids.length) return null;
  return (dto) => (dto.Genres || []).some((g) => names.includes(String(g).toLowerCase()))
    || (dto.GenreItems || []).some((g) => ids.includes(String(g.Id).replace(/-/g, '')));
}
async function libraryEpisodes(q, uid) {
  const series = (await catalogPool(await viewsFor(q.parentid, ['series']), uid)).filter((d) => d.Type === 'Series');
  const gf = genreFilter(q);
  const picked = gf ? series.filter(gf) : series;
  const lists = await pMap(picked, 2, (d) => seriesEpisodes(d.Id, uid));
  return lists.flat();
}
route('GET', '/genres', async (ctx) => {
  const types = lower(ctx.query.includeitemtypes);
  const kinds = types.includes('movie') && !types.some((t) => t === 'series' || t === 'episode') ? ['movie']
    : types.some((t) => t === 'series' || t === 'episode') && !types.includes('movie') ? ['series'] : ['movie', 'series'];
  const pool = await catalogPool(await viewsFor(ctx.query.parentid, kinds), ctx.user.id);
  const counts = new Map();
  for (const d of pool) for (const g of d.Genres || []) counts.set(g, (counts.get(g) || 0) + 1);
  const items = [...counts.keys()].sort((a, b) => a.localeCompare(b)).map((g) => ({
    Name: g, Id: store.idFor(`g|${g}`), ServerId: store.serverId(), Type: 'Genre', IsFolder: true,
    ImageTags: {}, BackdropImageTags: [], ChildCount: counts.get(g),
  }));
  const start = Math.max(0, parseInt(ctx.query.startindex, 10) || 0);
  const limit = Math.min(Math.max(1, parseInt(ctx.query.limit, 10) || 500), 1000);
  return page(items, start, limit);
});

// ── /Items query ───────────────────────────────────────────────────────
async function itemsQuery(ctx) {
  const q = ctx.query;
  const uid = ctx.user.id;
  const start = Math.max(0, parseInt(q.startindex, 10) || 0);
  const limit = Math.min(Math.max(1, parseInt(q.limit, 10) || 100), 300);
  const types = lower(q.includeitemtypes);
  const filters = lower(q.filters);
  // Collections: listing them, opening one, or several ids that include one.
  if (types.includes('boxset') && !types.some((t) => t === 'movie' || t === 'series' || t === 'episode')) {
    return page(coll.list(uid), start, limit);
  }
  if (q.parentid && coll.isView(q.parentid)) return page(coll.list(uid), start, limit);
  if (q.parentid && coll.isCollection(q.parentid)) {
    return page((await coll.children(q.parentid, uid)).filter((d) => typeOk(d, types.filter((t) => t !== 'boxset'))), start, limit);
  }
  if (q.ids && list(q.ids).some((id) => coll.isCollection(id) || coll.isView(id))) {
    const items = await pMap(list(q.ids), 8, (id) => (coll.isCollection(id) ? coll.get(id, uid) : coll.isView(id) ? coll.viewDto() : library.getListItem(id, uid)));
    return qr(items.filter(Boolean));
  }
  if (!videoWanted(q)) return qr([], 0, start);

  if (q.ids) {
    const ids = list(q.ids);
    // One item by id is how some apps open a details page (Streamyfin does
    // this twice: once fast, then again asking for MediaSources in the
    // background). Treat it like opening the title, and when MediaSources are
    // asked for, return the real versions as Jellyfin would.
    if (ids.length === 1) {
      const dto = await library.getItem(ids[0], uid, { full: true }).catch(() => null);
      if (!dto) return qr([]);
      prefetchFor(dto, uid);
      const fields = lower(q.fields);
      if (isPlayableDto(dto) && fields.includes('mediasources')) await attachSources(ctx, dto, Math.min(settings.streamWaitMs, 8000));
      else if (!fields.includes('mediasources')) delete dto.MediaSources;
      return qr([dto]);
    }
    const items = (await pMap(ids, 8, (id) => library.getListItem(id, uid))).filter(Boolean);
    return qr(items);
  }
  if (q.searchterm) {
    const st = stremioTypes(types);
    if (st && !st.length) return qr([]);
    const metas = await aio.search(q.searchterm, st);
    const dtos = metas.map((m) => library.previewDto(m, m.type, uid)).filter((d) => typeOk(d, types));
    return page(dtos, start, limit);
  }
  if (filters.includes('isresumable')) return page(library.resumeItems(uid, 100).filter((d) => typeOk(d, types)), start, limit);
  if (filters.includes('isfavorite') || q.isfavorite === 'true') return page(library.favourites(uid).filter((d) => typeOk(d, types)), start, limit);
  if (filters.includes('isplayed') || q.isplayed === 'true') return page(library.played(uid).filter((d) => typeOk(d, types)), start, limit);

  if (q.parentid) {
    if (library.ROOT_ID === q.parentid.replace(/-/g, '')) return userViews();
    const r = library.resolve(q.parentid);
    if (!r) return qr([]);
    if (r.kind === 'view' && r.catKey === library.UPCOMING_KEY) {
      // Shows tab asks for Series; everything else gets the episodes themselves.
      const list = types.includes('series') ? await library.upcomingSeries(uid) : await library.upcoming(uid);
      return page(list.filter((d) => typeOk(d, types)), start, limit);
    }
    if (r.kind === 'view') {
      if (types.includes('episode') && !types.some((t) => t === 'movie' || t === 'series')) {
        return page(await libraryEpisodes(q, uid), start, limit);
      }
      if (types.length && !types.some((t) => t === 'movie' || t === 'series')) return qr([], 0, start);
      const gf = genreFilter(q);
      if (gf) {
        const pool = await catalogPool(await viewsFor(q.parentid, ['movie', 'series']), uid);
        return page(pool.filter((d) => gf(d) && typeOk(d, types)), start, limit);
      }
      const res = await library.catalogItems(r.catKey, start, limit, uid);
      return qr(res.items, res.total, start);
    }
    if (r.kind === 'series') {
      if (types.includes('episode')) return page(await library.episodes(q.parentid, uid), start, limit);
      return page(await library.seasons(q.parentid, uid), start, limit);
    }
    if (r.kind === 'season') return page(await library.episodes(q.parentid, uid), start, limit);
    return qr([]);
  }

  // No parent, episodes or a genre: library-wide.
  if (types.includes('episode') && !types.some((t) => t === 'movie' || t === 'series')) {
    return page(await libraryEpisodes(q, uid), start, limit);
  }
  if (genreFilter(q)) {
    const kinds = types.includes('movie') && !types.includes('series') ? ['movie'] : types.includes('series') && !types.includes('movie') ? ['series'] : ['movie', 'series'];
    const pool = await catalogPool(await viewsFor(null, kinds), uid);
    return page(pool.filter((d) => genreFilter(q)(d) && typeOk(d, types)), start, limit);
  }
  // No parent: library-wide browse (e.g. a client's "All movies"): use the first catalog of that type.
  if (types.some((t) => t === 'movie' || t === 'series') && q.recursive !== 'false') {
    const st = stremioTypes(types);
    const cat = (await library.views()).find((c) => !c.virtual && st.includes(c.type));
    if (cat) {
      const res = await library.catalogItems(cat.key, start, limit, uid);
      return qr(res.items.filter((d) => typeOk(d, types)), res.total, start);
    }
  }
  return qr([]);
}
route('GET', '/items', itemsQuery);
route('GET', '/users/:uid/items', itemsQuery);

async function latest(ctx) {
  const limit = Math.min(parseInt(ctx.query.limit, 10) || 16, 60);
  if (!videoWanted(ctx.query)) return [];
  let catKey;
  if (ctx.query.parentid) { const r = library.resolve(ctx.query.parentid); if (r && r.kind === 'view') catKey = r.catKey; }
  if (!catKey) catKey = (await library.views()).find((c) => !c.virtual)?.key;
  if (!catKey) return [];
  // Home row for the Upcoming library: air date in front of each episode name.
  if (catKey === library.UPCOMING_KEY) return (await library.upcoming(ctx.user.id, { dated: true })).slice(0, limit);
  return (await library.catalogItems(catKey, 0, limit, ctx.user.id)).items;
}
route('GET', '/items/latest', latest);
route('GET', '/users/:uid/items/latest', latest);

const resume = (ctx) => {
  if (!videoWanted(ctx.query)) return qr([]);
  const types = lower(ctx.query.includeitemtypes);
  const limit = parseInt(ctx.query.limit, 10) || 24;
  const items = library.resumeItems(ctx.user.id, 100).filter((d) => typeOk(d, types));
  // People about to hit play on a resume row: have their streams ready.
  if (settings.prefetchOnOpen) for (const d of items.slice(0, 2)) { const t = library.streamTarget(d.Id); if (t) aio.prefetch(t.type, t.id, 'resume-row'); }
  return page(items, parseInt(ctx.query.startindex, 10) || 0, limit);
};
route('GET', '/useritems/resume', resume);
route('GET', '/users/:uid/items/resume', resume);

route('GET', '/items/root', () => library.rootDto());
route('GET', '/users/:uid/items/root', () => library.rootDto());
route('GET', '/items/counts', async () => {
  const v = await library.views();
  return { MovieCount: v.filter((c) => c.type === 'movie').length * 100, SeriesCount: v.filter((c) => c.type !== 'movie').length * 100, EpisodeCount: 0, ArtistCount: 0, ProgramCount: 0, TrailerCount: 0, SongCount: 0, AlbumCount: 0, MusicVideoCount: 0, BoxSetCount: 0, BookCount: 0, ItemCount: 0 };
});

/**
 * Put the real versions (with real tracks) on a movie/episode DTO, waiting at
 * most `wait` ms for AIOStreams. Leaves the DTO alone if they don't arrive.
 */
async function attachSources(ctx, dto, wait) {
  const info = await withTimeout(playback.playbackInfo(dto.Id, { profile: null, auth: ctx.auth, token: ctx.auth.token, origin: ctx.origin, userId: ctx.user.id, remember: false }), wait, null).catch(() => null);
  if (info && info.MediaSources.length) {
    dto.MediaSources = info.MediaSources;
    dto.MediaSourceCount = info.MediaSources.length;
    dto.MediaStreams = info.MediaSources[0].MediaStreams;
  }
}
const isPlayableDto = (dto) => (dto.Type === 'Movie' || dto.Type === 'Episode') && dto.LocationType !== 'Virtual';

/** Start finding streams for a title someone just opened, so Play is instant. */
function prefetchFor(dto, uid) {
  if (!settings.prefetchOnOpen || !dto) return;
  const t = library.streamTarget(dto.Id);
  if (t) aio.prefetch(t.type, t.id, 'open');
  else if (dto.Type === 'Series' || dto.Type === 'Season') library.prefetchForSeries(dto.Id, uid);
}

// ── Single item ────────────────────────────────────────────────────────
async function itemDetail(ctx) {
  const id = ctx.params.id;
  const uid = ctx.user.id;
  if (coll.isCollection(id)) return coll.get(id, uid);
  if (coll.isView(id)) return coll.viewDto();
  const dto = await library.getItem(id, uid, { full: true });
  if (!dto) throw new HttpError(404, 'Item not found');
  // The speed trick: start resolving streams the moment a title is opened.
  prefetchFor(dto, uid);
  // Real Jellyfin includes every version in a single-item response. Apps that
  // run Jellyfin Web (browser, Jellyfin iOS/Android, Jellyfin Media Player)
  // get an instant placeholder and AIOFin's page script fills the versions in
  // the background. Every other app (Swiftfin, Android TV, Infuse…) builds its
  // own details screen from this response, so it gets the real versions now.
  const fields = lower(ctx.query.fields);
  const wantSources = isPlayableDto(dto) && (fields.includes('mediasources') || !runsJellyfinWeb(ctx.auth));
  if (wantSources) {
    // The page script's background request may take the full stream timeout;
    // an app waiting on its details screen is capped so it never hangs.
    const wait = ctx.query.aiofinwait ? settings.streamWaitMs : Math.min(settings.streamWaitMs, 8000);
    await attachSources(ctx, dto, wait);
  }
  return dto;
}
route('GET', '/items/:id', itemDetail);
route('GET', '/users/:uid/items/:id', itemDetail);

// ── Shows ──────────────────────────────────────────────────────────────
route('GET', '/shows/:id/seasons', async (ctx) => qr(await library.seasons(ctx.params.id, ctx.user.id)));
route('GET', '/shows/:id/episodes', async (ctx) => {
  const season = ctx.query.season !== undefined ? parseInt(ctx.query.season, 10) : undefined;
  let eps = await library.episodes(ctx.params.id, ctx.user.id, { seasonId: ctx.query.seasonid, season });
  if (ctx.query.startitemid) {
    const i = eps.findIndex((e) => e.Id === ctx.query.startitemid.replace(/-/g, ''));
    if (i > 0) eps = eps.slice(i);
  }
  const start = parseInt(ctx.query.startindex, 10) || 0;
  const limit = parseInt(ctx.query.limit, 10) || 1000;
  return page(eps, start, limit);
});
// Next up is turned off: an empty answer makes every Jellyfin app hide the row.
route('GET', '/shows/nextup', () => qr([]));
// Jellyfin Web's "Upcoming" tab: favourited series' episodes airing soon. It groups them by date itself.
route('GET', '/shows/upcoming', async (ctx) => {
  const list = await library.upcoming(ctx.user.id);
  return page(list, parseInt(ctx.query.startindex, 10) || 0, parseInt(ctx.query.limit, 10) || 100);
});

// ── Search hints ───────────────────────────────────────────────────────
route('GET', '/search/hints', async (ctx) => {
  const term = ctx.query.searchterm;
  if (!term || !videoWanted(ctx.query)) return { SearchHints: [], TotalRecordCount: 0 };
  const types = lower(ctx.query.includeitemtypes);
  const st = stremioTypes(types);
  if (st && !st.length) return { SearchHints: [], TotalRecordCount: 0 };
  const metas = await aio.search(term, st);
  const limit = parseInt(ctx.query.limit, 10) || 30;
  const hints = metas.map((m) => library.previewDto(m, m.type, ctx.user.id)).filter((d) => typeOk(d, types)).slice(0, limit).map((d) => ({
    ItemId: d.Id, Id: d.Id, Name: d.Name, Type: d.Type, ProductionYear: d.ProductionYear, PrimaryImageTag: d.ImageTags.Primary,
    ThumbImageTag: d.ImageTags.Thumb, BackdropImageTag: d.BackdropImageTags[0], IsFolder: d.IsFolder, MediaType: d.MediaType,
    RunTimeTicks: d.RunTimeTicks, Album: null, AlbumArtist: null, Artists: [], ChannelId: null,
  }));
  return { SearchHints: hints, TotalRecordCount: hints.length };
});

// ── Images ─────────────────────────────────────────────────────────────
function sizedUrl(url, q) {
  const w = parseInt(q.maxwidth || q.fillwidth || q.width, 10) || 0;
  // TMDB serves pre-sized renditions; asking for a smaller one loads much faster.
  if (/image\.tmdb\.org\/t\/p\/original\//.test(url) && w) {
    const size = w <= 342 ? 'w342' : w <= 500 ? 'w500' : w <= 780 ? 'w780' : w <= 1280 ? 'w1280' : 'original';
    return url.replace('/t/p/original/', `/t/p/${size}/`);
  }
  return url;
}
async function image(ctx) {
  const url = coll.isCollection(ctx.params.id) ? await coll.imageUrl(ctx.params.id, ctx.params.type) : await library.imageUrl(ctx.params.id, ctx.params.type);
  if (!url) throw new HttpError(404, 'No image');
  const target = sizedUrl(url, ctx.query);
  if (settings.imageMode === 'proxy') {
    const up = await openStream(target).catch(() => null);
    if (!up || up.statusCode >= 400) { if (up) up.resume(); throw new HttpError(404, 'Image unavailable'); }
    ctx.res.writeHead(200, { 'content-type': up.headers['content-type'] || 'image/jpeg', 'cache-control': 'public, max-age=2592000', ...(up.headers['content-length'] ? { 'content-length': up.headers['content-length'] } : {}) });
    up.on('error', () => ctx.res.destroy());
    ctx.res.on('close', () => up.destroy());
    up.pipe(ctx.res);
    return;
  }
  ctx.res.writeHead(302, { location: target, 'cache-control': 'public, max-age=86400' });
  ctx.res.end();
}
route('GET', '/items/:id/images/:type', image, { auth: false });
route('GET', '/items/:id/images/:type/:index', image, { auth: false });
route('GET', '/items/:id/images', async (ctx) => {
  const dto = coll.isCollection(ctx.params.id) ? coll.get(ctx.params.id) : await library.getListItem(ctx.params.id, null);
  if (!dto) return [];
  return Object.keys(dto.ImageTags || {}).map((t) => ({ ImageType: t, ImageIndex: 0, ImageTag: dto.ImageTags[t], Size: 0 }))
    .concat((dto.BackdropImageTags || []).map((tg, i) => ({ ImageType: 'Backdrop', ImageIndex: i, ImageTag: tg, Size: 0 })));
});
route('GET', '/users/:uid/images/:type', () => { throw new HttpError(404, 'No image'); }, { auth: false });

// ── User data: played / favourite ──────────────────────────────────────
async function setPlayed(ctx, value) {
  const uid = ctx.user.id;
  const id = ctx.params.id.replace(/-/g, '').toLowerCase();
  const r = library.resolve(id);
  if (r && (r.kind === 'series' || r.kind === 'season')) {
    const eps = await library.episodes(id, uid);
    for (const e of eps) {
      const { UserData, ...snap } = e; void UserData;
      store.userData.upsert(uid, e.Id, value ? { played: true, pos: 0, playCount: 1, lastPlayed: Date.now(), snap } : { played: false, pos: 0 });
    }
  } else {
    const snap = await library.snapshot(uid, id);
    const cur = store.userData.get(uid, id) || {};
    store.userData.upsert(uid, id, value
      ? { played: true, pos: 0, playCount: (cur.playCount || 0) + 1, lastPlayed: Date.now(), ...(snap ? { snap } : {}) }
      : { played: false, pos: 0 });
  }
  return library.userDataFor(uid, id);
}
async function setFav(ctx, value) {
  const uid = ctx.user.id;
  const id = ctx.params.id.replace(/-/g, '').toLowerCase();
  const snap = value ? await library.snapshot(uid, id) : null;
  store.userData.upsert(uid, id, { fav: value, favAt: Date.now(), ...(snap ? { snap } : {}) });
  return library.userDataFor(uid, id);
}
for (const base of ['/userplayeditems/:id', '/users/:uid/playeditems/:id']) {
  route('POST', base, (ctx) => setPlayed(ctx, true));
  route('DELETE', base, (ctx) => setPlayed(ctx, false));
}
for (const base of ['/userfavoriteitems/:id', '/users/:uid/favoriteitems/:id']) {
  route('POST', base, (ctx) => setFav(ctx, true));
  route('DELETE', base, (ctx) => setFav(ctx, false));
}
const getUD = (ctx) => library.userDataFor(ctx.user.id, ctx.params.id.replace(/-/g, '').toLowerCase());
route('GET', '/useritems/:id/userdata', getUD);
route('GET', '/users/:uid/items/:id/userdata', getUD);
async function postUD(ctx) {
  const id = ctx.params.id.replace(/-/g, '').toLowerCase();
  const b = ctx.body || {};
  const patch = {};
  if (b.Played !== undefined) patch.played = !!b.Played;
  if (b.IsFavorite !== undefined) patch.fav = !!b.IsFavorite;
  if (b.PlaybackPositionTicks !== undefined) patch.pos = Number(b.PlaybackPositionTicks) || 0;
  const snap = await library.snapshot(ctx.user.id, id);
  store.userData.upsert(ctx.user.id, id, { ...patch, ...(snap ? { snap } : {}) });
  return library.userDataFor(ctx.user.id, id);
}
route('POST', '/useritems/:id/userdata', postUD);
route('POST', '/users/:uid/items/:id/userdata', postUD);

void log;
module.exports = {};


// ── Collections ────────────────────────────────────────────────────────
// Jellyfin Web: "Add to collection" → "New collection", or the Collections
// tab's "New collection" button.
route('POST', '/collections', (ctx) => {
  const q = ctx.query;
  const name = String(q.name || (ctx.body && ctx.body.Name) || '').trim() || 'New collection';
  const c = coll.create(name, q.ids || (ctx.body && ctx.body.Ids && [].concat(ctx.body.Ids).join(',')), ctx.user.id);
  log('info', `collection "${c.name}" created (${c.items.length} item(s))`);
  return { Id: c.id };
});
route('POST', '/collections/:id/items', (ctx) => {
  if (!coll.add(ctx.params.id, ctx.query.ids)) throw new HttpError(404, 'Collection not found');
});
route('DELETE', '/collections/:id/items', (ctx) => {
  if (!coll.removeItems(ctx.params.id, ctx.query.ids)) throw new HttpError(404, 'Collection not found');
});
// Delete a collection (titles themselves can't be deleted).
async function deleteItems(ids) {
  let any = false;
  for (const id of ids) if (coll.isCollection(id)) { coll.remove(id); any = true; }
  if (!any) throw new HttpError(403, 'Only collections can be deleted');
}
route('DELETE', '/items/:id', (ctx) => deleteItems([ctx.params.id]));
route('DELETE', '/items', (ctx) => deleteItems(list(ctx.query.ids)));
// Rename a collection (Jellyfin Web's metadata editor saves the whole item).
route('POST', '/items/:id', (ctx) => {
  if (!coll.isCollection(ctx.params.id)) return undefined;
  const name = ctx.body && String(ctx.body.Name || '').trim();
  if (name) require('../store').collections.update(ctx.params.id.replace(/-/g, '').toLowerCase(), { name });
  return undefined;
});
