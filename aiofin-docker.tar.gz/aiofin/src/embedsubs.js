'use strict';
// Subtitle tracks that are inside the video file itself ("in file"), for
// players that get the remux (web, phones). Apps that play the file directly
// read these tracks themselves.
//
// Subtitle lines are spread through the whole file, so getting them means
// reading it all. To keep that quick, the film is split into time ranges that
// are read in parallel (each ffmpeg seeks to its range), every text track is
// pulled out in the same pass, and the result is kept for the stream.
// Runs only when someone picks an in-file subtitle.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { settings, boot } = require('./config');
const { SwrCache } = require('./cache');
const { parse } = require('./subtitles');
const { log } = require('./util');

const TEXT = new Set(['subrip', 'srt', 'ass', 'ssa', 'webvtt', 'mov_text', 'text']);
const isText = (s) => TEXT.has(String(s.codec || '').toLowerCase());
const isAss = (s) => ['ass', 'ssa'].includes(String(s.codec || '').toLowerCase());
const isPgs = (s) => String(s.codec || '').toLowerCase() === 'hdmv_pgs_subtitle';

/** Merge ASS files from several ranges: one header, every Dialogue line once, in time order. */
function mergeAss(parts) {
  let header = null; const lines = []; const seen = new Set();
  const t = (line) => { const m = line.match(/^Dialogue:\s*[^,]*,(\d+):(\d+):(\d+(?:\.\d+)?)/); return m ? (+m[1]) * 3600 + (+m[2]) * 60 + parseFloat(m[3]) : 0; };
  for (const text of parts) {
    if (!text) continue;
    const at = text.indexOf('[Events]');
    if (at === -1) continue;
    const rest = text.slice(at).split(/\r?\n/);
    const fmt = rest.findIndex((l) => /^Format:/i.test(l));
    if (header === null) header = text.slice(0, at) + rest.slice(0, fmt + 1).join('\n');
    for (const l of rest.slice(fmt + 1)) if (/^Dialogue:/i.test(l) && !seen.has(l)) { seen.add(l); lines.push(l); }
  }
  if (header === null) return null;
  lines.sort((a, b) => t(a) - t(b));
  return `${header}\n${lines.join('\n')}\n`;
}

/** PGS display sets (segments up to and including an END segment) with their start time. */
function pgsSets(buf) {
  const sets = []; let cur = []; let start = null; let p = 0;
  while (p + 13 <= buf.length && buf[p] === 0x50 && buf[p + 1] === 0x47) {
    const size = buf.readUInt16BE(p + 11); const end = p + 13 + size;
    if (end > buf.length) break;
    if (start === null) start = buf.readUInt32BE(p + 2) / 90000;
    cur.push(buf.subarray(p, end));
    if (buf[p + 10] === 0x80) { sets.push({ start, data: Buffer.concat(cur) }); cur = []; start = null; }
    p = end;
  }
  return sets;
}

const DIR = path.join(boot.dataDir, 'embedded-subs');
fs.rmSync(DIR, { recursive: true, force: true });
const results = new SwrCache('embedded-subs', 300); // sid → { [streamIndex]: events }

// At most two files being read at once (each with several parallel readers).
let active = 0; const waiting = [];
const acquire = () => new Promise((r) => { if (active < 2) { active++; r(); } else waiting.push(r); });
const release = () => { const next = waiting.shift(); if (next) next(); else active--; };

function runChunk(src, tracks, from, to, dir, i) {
  return new Promise((resolve) => {
    const a = ['-v', 'error', '-y', '-nostdin'];
    if (/^https?:/i.test(src.url)) a.push('-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_on_network_error', '1', '-reconnect_delay_max', '10');
    if (src.headers) a.push('-headers', Object.entries(src.headers).map(([k, v]) => `${k}: ${v}`).join('\r\n') + '\r\n');
    if (from > 0) a.push('-ss', from.toFixed(3));
    a.push('-i', src.url, '-copyts', '-start_at_zero');
    const out = (t, codec, fmt, ext) => {
      a.push('-map', `0:${t.index}`, '-c:s', codec);
      if (to !== null) a.push('-to', to.toFixed(3));
      a.push('-f', fmt, path.join(dir, `c${i}-${t.index}.${ext}`));
    };
    for (const t of tracks) {
      if (isText(t)) out(t, 'srt', 'srt', 'srt');
      if (isAss(t)) out(t, 'copy', 'ass', 'ass');     // native ASS, styling intact
      if (isPgs(t)) out(t, 'copy', 'sup', 'sup');     // PGS pictures for players that draw them
    }
    const p = spawn(boot.ffmpeg, a, { stdio: ['ignore', 'ignore', 'pipe'] });
    let err = '';
    p.stderr.on('data', (d) => { err = (err + d).slice(-500); });
    p.on('error', (e) => resolve({ ok: false, err: e.message }));
    p.on('close', (code) => resolve({ ok: code === 0, err: err.trim().split('\n').pop() }));
  });
}

/** All text subtitle tracks of a stream: { [streamIndex]: [{ start, end, text }] }. */
function extract(src, info) {
  return results.get(src.sid, async () => {
    const tracks = (info.subs || []).filter((t) => isText(t) || isPgs(t));
    if (!tracks.length) return {};
    await acquire();
    const dir = path.join(DIR, src.sid);
    const t0 = Date.now();
    try {
      fs.mkdirSync(dir, { recursive: true });
      const dur = info.duration || 0;
      const n = dur > 120 ? Math.max(1, Math.min(16, settings.embeddedSubChunks)) : 1;
      const bounds = Array.from({ length: n + 1 }, (_, i) => (i === n ? null : (dur * i) / n));
      const runs = await Promise.all(bounds.slice(0, n).map((from, i) => runChunk(src, tracks, from, bounds[i + 1], dir, i)));
      if (!runs.some((r) => r.ok)) throw new Error(runs[0].err || 'could not read the file');
      const out = {};
      const read = (i, t, ext, enc) => { try { return fs.readFileSync(path.join(dir, `c${i}-${t.index}.${ext}`), enc); } catch { return null; } };
      for (const t of tracks) {
        const entry = {};
        if (isText(t)) {
          const all = [];
          for (let i = 0; i < n; i++) { const txt = read(i, t, 'srt', 'utf8'); if (txt) all.push(...parse(txt)); }
          // Ranges overlap slightly at their edges: drop repeats.
          const seen = new Set();
          entry.events = all.filter((e) => { const k = `${e.start.toFixed(2)}|${e.text}`; if (seen.has(k)) return false; seen.add(k); return true; })
            .sort((x, y) => x.start - y.start);
        }
        if (isAss(t)) entry.ass = mergeAss(Array.from({ length: n }, (_, i) => read(i, t, 'ass', 'utf8')));
        if (isPgs(t)) {
          // Keep each range's display sets that start inside that range.
          const parts = [];
          for (let i = 0; i < n; i++) {
            const buf = read(i, t, 'sup', null); if (!buf) continue;
            const lo = bounds[i] || 0; const hi = bounds[i + 1];
            for (const set of pgsSets(buf)) if (set.start >= lo - 0.001 && (hi === null || set.start < hi)) parts.push(set);
          }
          parts.sort((x, y) => x.start - y.start);
          entry.sup = parts.length ? Buffer.concat(parts.map((x) => x.data)) : null;
        }
        out[t.index] = entry;
      }
      log('info', `in-file subtitles ${src.sid.slice(0, 8)}: ${tracks.length} track(s) read in ${Date.now() - t0}ms using ${n} parallel reader(s)`);
      return out;
    } finally {
      release();
      fs.rmSync(dir, { recursive: true, force: true });
    }
  }, { ttl: 24 * 3600_000 });
}

async function track(src, info, streamIndex) {
  const all = await extract(src, info);
  const t = all[streamIndex];
  if (!t) throw new Error('subtitle track not found in the file');
  return t;
}
/** Lines of one in-file text subtitle track. */
async function events(src, info, streamIndex) {
  const t = await track(src, info, streamIndex);
  if (!t.events || !t.events.length) throw new Error('this subtitle track has no text lines');
  return t.events;
}
/** The track as a styled ASS file (ASS/SSA tracks only). */
async function ass(src, info, streamIndex) {
  const t = await track(src, info, streamIndex);
  if (!t.ass) throw new Error('this subtitle track is not ASS');
  return t.ass;
}
/** The track as PGS pictures (.sup). */
async function sup(src, info, streamIndex) {
  const t = await track(src, info, streamIndex);
  if (!t.sup) throw new Error('this subtitle track has no pictures');
  return t.sup;
}

module.exports = { events, ass, sup, isText, isAss, isPgs, extract, mergeAss, pgsSets };
