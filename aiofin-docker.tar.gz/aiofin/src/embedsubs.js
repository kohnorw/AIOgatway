'use strict';
// Subtitle tracks that are inside the video file itself ("in file"), for
// players that get the remux (web, phones). Apps that play the file directly
// read these tracks themselves.
//
// Subtitle lines are spread through the whole file, so getting them means
// reading it all. To keep that quick, the film is split into time ranges that
// are read in parallel (each ffmpeg seeks to its range), every text track is
// pulled out in the same pass, and the result is kept for the stream.
// Runs only when someone picks an in-file subtitle.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { settings, boot } = require('./config');
const { SwrCache } = require('./cache');
const { parse } = require('./subtitles');
const { log } = require('./util');

const TEXT = new Set(['subrip', 'srt', 'ass', 'ssa', 'webvtt', 'mov_text', 'text']);
const isText = (s) => TEXT.has(String(s.codec || '').toLowerCase());

const DIR = path.join(boot.dataDir, 'embedded-subs');
fs.rmSync(DIR, { recursive: true, force: true });
const results = new SwrCache('embedded-subs', 300); // sid → { [streamIndex]: events }

// At most two files being read at once (each with several parallel readers).
let active = 0; const waiting = [];
const acquire = () => new Promise((r) => { if (active < 2) { active++; r(); } else waiting.push(r); });
const release = () => { const next = waiting.shift(); if (next) next(); else active--; };

function runChunk(src, tracks, from, to, dir, i) {
  return new Promise((resolve) => {
    const a = ['-v', 'error', '-y', '-nostdin'];
    if (/^https?:/i.test(src.url)) a.push('-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_on_network_error', '1', '-reconnect_delay_max', '10');
    if (src.headers) a.push('-headers', Object.entries(src.headers).map(([k, v]) => `${k}: ${v}`).join('\r\n') + '\r\n');
    if (from > 0) a.push('-ss', from.toFixed(3));
    a.push('-i', src.url, '-copyts', '-start_at_zero');
    for (const t of tracks) {
      a.push('-map', `0:${t.index}`, '-c:s', 'srt');
      if (to !== null) a.push('-to', to.toFixed(3));
      a.push('-f', 'srt', path.join(dir, `c${i}-${t.index}.srt`));
    }
    const p = spawn(boot.ffmpeg, a, { stdio: ['ignore', 'ignore', 'pipe'] });
    let err = '';
    p.stderr.on('data', (d) => { err = (err + d).slice(-500); });
    p.on('error', (e) => resolve({ ok: false, err: e.message }));
    p.on('close', (code) => resolve({ ok: code === 0, err: err.trim().split('\n').pop() }));
  });
}

/** All text subtitle tracks of a stream: { [streamIndex]: [{ start, end, text }] }. */
function extract(src, info) {
  return results.get(src.sid, async () => {
    const tracks = (info.subs || []).filter(isText);
    if (!tracks.length) return {};
    await acquire();
    const dir = path.join(DIR, src.sid);
    const t0 = Date.now();
    try {
      fs.mkdirSync(dir, { recursive: true });
      const dur = info.duration || 0;
      const n = dur > 120 ? Math.max(1, Math.min(16, settings.embeddedSubChunks)) : 1;
      const bounds = Array.from({ length: n + 1 }, (_, i) => (i === n ? null : (dur * i) / n));
      const runs = await Promise.all(bounds.slice(0, n).map((from, i) => runChunk(src, tracks, from, bounds[i + 1], dir, i)));
      if (!runs.some((r) => r.ok)) throw new Error(runs[0].err || 'could not read the file');
      const out = {};
      for (const t of tracks) {
        const all = [];
        for (let i = 0; i < n; i++) {
          try { all.push(...parse(fs.readFileSync(path.join(dir, `c${i}-${t.index}.srt`), 'utf8'))); } catch { /* chunk had no lines */ }
        }
        // Ranges overlap slightly at their edges: drop repeats.
        const seen = new Set();
        out[t.index] = all.filter((e) => { const k = `${e.start.toFixed(2)}|${e.text}`; if (seen.has(k)) return false; seen.add(k); return true; })
          .sort((x, y) => x.start - y.start);
      }
      log('info', `in-file subtitles ${src.sid.slice(0, 8)}: ${tracks.length} track(s) read in ${Date.now() - t0}ms using ${n} parallel reader(s)`);
      return out;
    } finally {
      release();
      fs.rmSync(dir, { recursive: true, force: true });
    }
  }, { ttl: 24 * 3600_000 });
}

/** Lines of one in-file subtitle track. */
async function events(src, info, streamIndex) {
  const all = await extract(src, info);
  const ev = all[streamIndex];
  if (!ev) throw new Error('subtitle track not found in the file');
  if (!ev.length) throw new Error('this subtitle track has no text lines');
  return ev;
}

module.exports = { events, isText, extract };
