'use strict';
const { settings, boot } = require('./config');
const server = require('./server');
const store = require('./store');
const aio = require('./aio');
const { handleStatic } = require('./web');
const { log } = require('./util');

require('./routes/system');
require('./routes/items');
require('./routes/playback');
require('./routes/admin');

server.setStatic(handleStatic);

// Seed an admin account from env on first boot (optional).
if (!store.users.list().length && boot.adminUser && boot.adminPassword) {
  store.users.create(boot.adminUser, boot.adminPassword, true);
  log('info', `created admin user "${boot.adminUser}" from environment`);
}

// Check for ffmpeg now (a blocking call) rather than on someone's first Play.
require('./transcode').available();

server.listen();
aio.startKeepWarm();

if (!store.users.list().length) log('info', `first run: open http://<this-host>:${boot.port}/admin to create your account`);
if (!aio.configured()) log('info', 'AIOStreams is not configured yet — add your manifest URL on the admin page');
else {
  aio.manifest().then((m) => log('info', `connected to ${m.name || 'AIOStreams'} ${m.version || ''} (${(m.catalogs || []).length} catalogs)`))
    .catch((e) => log('warn', `could not reach AIOStreams: ${e.message}`));
  aio.warmCatalogs();
}
// Refresh catalog warm-up periodically so library rows open instantly.
setInterval(() => aio.warmCatalogs(), Math.max(300, settings.catalogTtlSec) * 1000).unref();

process.on('unhandledRejection', (e) => log('error', 'unhandled rejection', e && e.stack ? e.stack : e));
// Last resort: one broken connection or child process must never take the
// whole server down. Requests are independent, so it's safe to keep serving.
process.on('uncaughtException', (e) => log('error', 'unexpected error (server kept running):', e && e.stack ? e.stack : e));
