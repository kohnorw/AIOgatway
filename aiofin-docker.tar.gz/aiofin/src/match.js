'use strict';
// Makes sure each stream is for the title that was opened.
//
// AIOFin asks AIOStreams by IMDb id (tt1520211:1:1), but many indexers can
// only search by text, so a lookup for "The Walking Dead S01E01" can bring
// back "Fear the Walking Dead S01E01", a spin-off, or the wrong episode.
// Each result's file name is checked against the show's name, season,
// episode and year; results that clearly belong to something else are
// dropped. Anything that can't be judged (no file name, a title in another
// language, anime numbering) is kept.
const { settings } = require('./config');
const { withTimeout, log } = require('./util');

// Words that don't distinguish titles: articles, "and", country tags.
const IGNORE = new Set(['the', 'a', 'an', 'and', 'of', 'us', 'uk', 'au', 'ca', 'nz']);

function norm(s) {
  return String(s || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
    .replace(/&/g, ' and ').replace(/['’`]/g, '')
    .replace(/(\d)[-.:](?=\d)/g, '$1') // 9-1-1 → 911
    .replace(/[^a-z0-9]+/g, ' ').trim();
}

/** Significant words of a title. Runs of single letters merge: S.W.A.T. → swat. */
function words(s) {
  const out = []; let buf = '';
  for (const w of norm(s).split(' ').filter(Boolean)) {
    if (w.length === 1 && /[a-z]/.test(w)) { buf += w; continue; }
    if (buf) { out.push(buf); buf = ''; }
    out.push(w);
  }
  if (buf) out.push(buf);
  return [...new Set(out.filter((w) => !IGNORE.has(w)))].sort();
}
const same = (a, b) => a.length === b.length && a.every((w, i) => w === b[i]);

/** The same title with any run of 2+ words written as initials: Special Victims Unit → SVU, The Walking Dead → TWD. */
function abbreviations(title) {
  const seq = norm(title).split(' ').filter(Boolean);
  const out = [];
  for (let i = 0; i < seq.length; i++) {
    for (let j = i + 2; j <= Math.min(seq.length, i + 6); j++) {
      const initials = seq.slice(i, j).map((w) => w[0]).join('');
      out.push([...seq.slice(0, i), initials, ...seq.slice(j)].join(' '));
    }
  }
  return out;
}

/** Names a release may legitimately use for this title. */
function titleVariants(name) {
  const base = String(name || '').replace(/\s*\((?:19|20)\d{2}\)\s*$/, '').trim();
  const names = [base];
  const poss = base.match(/^[^:]*?['’]s\s+(.+)$/); // "Marvel's Agents of S.H.I.E.L.D." → "Agents of S.H.I.E.L.D."
  if (poss) names.push(poss[1]);
  const colon = base.match(/^[^:]+:\s*(.+)$/); // "The Walking Dead: Daryl Dixon" → "Daryl Dixon" (never the part before)
  if (colon) names.push(colon[1]);
  const all = [...names, ...names.flatMap(abbreviations)];
  return all.map(words).filter((w) => w.length);
}

/** true = same title, false = a different title, null = can't tell (e.g. another language). */
function titleMatches(releaseTitle, variants) {
  const got = words(releaseTitle);
  if (!got.length || !variants.length) return null;
  if (variants.some((v) => same(v, got))) return true;
  const overlap = variants.some((v) => v.some((w) => got.includes(w)));
  return overlap ? false : null;
}

function strip(filename) {
  return String(filename || '').replace(/\.[a-z0-9]{2,4}$/i, '')
    .replace(/^\[[^\]]*\][\s._-]*/, '')                                   // [group] prefix
    .replace(/^(?:www\.)?[a-z0-9-]+\.(?:com|org|net|to|tv|me|cc|io)[\s._-]+-?[\s._-]*/i, ''); // site prefix
}

/** Episode release name → { title, year, season, episodes: [from, to] | null, pack }. null if no episode marker. */
function parseEpisodeName(filename) {
  const f = strip(filename);
  let m; let idx; let season = null; let episodes = null; let pack = false;
  if ((m = f.match(/S(\d{1,2})[\s._-]?E(\d{1,3})((?:[\s._-]?(?:-[\s._-]?E?|E)\d{1,3}(?!\d))*)/i))) {
    season = +m[1];
    const nums = [+m[2], ...((m[3] || '').match(/\d{1,3}/g) || []).map(Number)];
    episodes = [Math.min(...nums), Math.max(...nums)];
    idx = m.index;
  } else if ((m = f.match(/(?:^|[\s._-])Season[\s._-]?(\d{1,2})[\s._-]+Episode[\s._-]?(\d{1,3})(?!\d)/i))) {
    season = +m[1]; episodes = [+m[2], +m[2]]; idx = m.index;
  } else if ((m = f.match(/(?:^|[\s._-])(\d{1,2})x(\d{2,3})(?!\d)/i))) {
    season = +m[1]; episodes = [+m[2], +m[2]]; idx = m.index;
  } else if ((m = f.match(/(?:^|[\s._-])S(\d{1,2})(?![\s._-]?E\d)(?!\d)/i)) || (m = f.match(/(?:^|[\s._-])Season[\s._-]?(\d{1,2})(?!\d)/i))) {
    season = +m[1]; pack = true; idx = m.index;
  }
  if (idx === undefined) return null;
  let title = f.slice(0, idx);
  let year = null;
  const ym = title.match(/[\s._(\[-]\(?((?:19|20)\d{2})\)?[\])]?[\s._-]*$/);
  if (ym && ym.index > 0) { year = +ym[1]; title = title.slice(0, ym.index); }
  title = title.replace(/[\s._-]+$/, '').replace(/[\s._]+/g, ' ').trim();
  return { title, year, season, episodes, pack };
}

/** A movie release's year: the last year before the quality tags, never the first word (e.g. "1917"). */
function movieYear(filename) {
  const f = strip(filename);
  const q = f.search(/[\s._(\[-](?:2160p|1080p|720p|576p|480p|4k|uhd|bluray|blu-ray|bdrip|brrip|web-?dl|webrip|web|hdtv|remux|dvdrip|hdrip|x26[45]|h\.?26[45]|hevc)(?![a-z0-9])/i);
  const head = q > 0 ? f.slice(0, q) : f;
  const max = new Date().getFullYear() + 1;
  const ys = [...head.matchAll(/(?:^|[\s._(\[-])((?:19|20)\d{2})(?=[\s._)\]-]|$)/g)].filter((m) => m.index > 0 && +m[1] <= max);
  return ys.length ? +ys[ys.length - 1][1] : null;
}

const yearOf = (meta) => { const y = parseInt(String(meta.year || meta.releaseInfo || meta.released || '').slice(0, 4), 10); return y > 1800 ? y : null; };

/** 'ok' or a reason the stream belongs to something else. */
function verdict(stream, expect) {
  if (!stream.filename) return 'ok';
  if (expect.kind === 'movie') {
    const y = movieYear(stream.filename);
    return y && expect.year && Math.abs(y - expect.year) > 1 ? `year ${y}, not ${expect.year}` : 'ok';
  }
  const p = parseEpisodeName(stream.filename);
  if (!p) return 'ok'; // daily shows, odd naming: can't judge
  if (p.title && titleMatches(p.title, expect.titles) === false) return `title "${p.title}"`;
  if (p.year && expect.year && Math.abs(p.year - expect.year) > 1) return `year ${p.year}, not ${expect.year}`;
  if (p.season !== null && p.season !== expect.season) return `season ${p.season}, not ${expect.season}`;
  if (p.episodes && !(expect.episode >= p.episodes[0] && expect.episode <= p.episodes[1])) {
    return `episode ${p.episodes[0]}${p.episodes[1] !== p.episodes[0] ? `-${p.episodes[1]}` : ''}, not ${expect.episode}`;
  }
  return 'ok';
}

/**
 * Drop streams that belong to a different title/episode. `getMeta` returns
 * the opened title's metadata. If every stream fails, all are kept and marked
 * as suspect rather than leaving nothing to play.
 */
async function filter(type, id, list, getMeta) {
  if (!settings.checkMatches || !list.length) return { list, removed: [] };
  const m = String(id).match(/^(tt\d+)(?::(\d+):(\d+))?$/);
  if (!m || type === 'anime') return { list, removed: [] }; // anime numbering is often absolute
  const meta = await withTimeout(Promise.resolve().then(getMeta), 2500, null).catch(() => null);
  if (!meta || !meta.name) return { list, removed: [] };
  const expect = m[2] !== undefined
    ? { kind: 'episode', titles: titleVariants(meta.name), year: yearOf(meta), season: +m[2], episode: +m[3] }
    : { kind: 'movie', year: yearOf(meta) };
  const keep = []; const removed = [];
  for (const s of list) {
    const v = verdict(s, expect);
    if (v === 'ok') keep.push(s); else removed.push({ s, why: v });
  }
  if (removed.length) {
    log('info', `match check ${id} (${meta.name}): dropped ${removed.length} — ${removed.slice(0, 4).map((r) => `${r.s.filename} [${r.why}]`).join('; ')}${removed.length > 4 ? '; …' : ''}`);
  }
  if (!keep.length) {
    for (const s of list) s.suspect = true;
    log('warn', `match check ${id}: every result looked like a different title; keeping them, marked ⚠`);
    return { list, removed: [] };
  }
  return { list: keep, removed };
}

module.exports = { filter, verdict, parseEpisodeName, movieYear, titleMatches, titleVariants, words };
