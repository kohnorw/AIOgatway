'use strict';
// Collections (Jellyfin "BoxSets"), created from Jellyfin Web: "Add to
// collection" on any title, or "New collection" in a library's Collections
// tab. Stored in data/db.json; each one is a list of item ids.
const store = require('./store');
const library = require('./library');
const { md5, pMap } = require('./util');

const VIEW_KEY = 'v|aiofin-collections';
const viewId = () => store.idFor(VIEW_KEY);
const norm = (id) => String(id || '').replace(/-/g, '').toLowerCase();
const split = (s) => String(s || '').split(',').map(norm).filter(Boolean);

const isCollection = (id) => !!store.collections.get(id);
const isView = (id) => norm(id) === viewId();

function create(name, ids, ownerId) {
  const c = store.collections.create(name, ownerId);
  if (ids) add(c.id, ids);
  return c;
}
function add(id, ids) {
  const c = store.collections.get(id);
  if (!c) return null;
  const set = new Set(c.items);
  for (const x of split(ids)) if (x !== c.id) set.add(x);
  return store.collections.update(c.id, { items: [...set] });
}
function removeItems(id, ids) {
  const c = store.collections.get(id);
  if (!c) return null;
  const drop = new Set(split(ids));
  return store.collections.update(c.id, { items: c.items.filter((x) => !drop.has(x)) });
}
const remove = (id) => store.collections.remove(id);

async function children(id, userId) {
  const c = store.collections.get(id);
  if (!c) return [];
  const items = await pMap(c.items, 6, (x) => library.getListItem(x, userId).catch(() => null));
  return items.filter(Boolean).map((d) => ({ ...d, ParentId: c.id }));
}

function dto(c, userId) {
  const first = c.items[0];
  const d = {
    Name: c.name, ServerId: store.serverId(), Id: c.id, Etag: md5(`${c.id}${c.name}${c.items.join(',')}`).slice(0, 16),
    DateCreated: c.created, CanDelete: true, CanDownload: false, SortName: c.name.toLowerCase(),
    Type: 'BoxSet', IsFolder: true, CollectionType: 'boxsets', LocationType: 'FileSystem', MediaType: 'Unknown',
    ChildCount: c.items.length, RecursiveItemCount: c.items.length, ParentId: viewId(),
    ImageTags: {}, BackdropImageTags: [], PrimaryImageAspectRatio: 0.6666666666666666,
    Overview: '', Genres: [], GenreItems: [], People: [], Studios: [], Taglines: [], ProviderIds: {}, LockedFields: [], LockData: false,
    UserData: { PlaybackPositionTicks: 0, PlayCount: 0, IsFavorite: false, Played: false, Key: c.id, ItemId: c.id },
  };
  // Pictures come from the first title in the collection.
  if (first) { d.ImageTags.Primary = md5(`p${first}`).slice(0, 16); d.BackdropImageTags = [md5(`b${first}`).slice(0, 16)]; }
  return d;
}
const list = (userId) => store.collections.list().sort((a, b) => a.name.localeCompare(b.name)).map((c) => dto(c, userId));
const get = (id, userId) => { const c = store.collections.get(id); return c ? dto(c, userId) : null; };

/** Image of a collection: the first title's. */
async function imageUrl(id, type) {
  const c = store.collections.get(id);
  if (!c || !c.items.length) return null;
  return library.imageUrl(c.items[0], /^backdrop|thumb$/i.test(type) ? type : 'Primary');
}

function viewDto() {
  const id = viewId();
  return {
    Name: 'Collections', ServerId: store.serverId(), Id: id, Etag: md5(VIEW_KEY).slice(0, 16), DateCreated: '2000-01-01T00:00:00.0000000Z',
    CanDelete: false, CanDownload: false, SortName: 'collections', Type: 'CollectionFolder', CollectionType: 'boxsets',
    IsFolder: true, LocationType: 'FileSystem', ImageTags: {}, BackdropImageTags: [], ChildCount: store.collections.list().length,
    ParentId: library.ROOT_ID, UserData: { PlaybackPositionTicks: 0, PlayCount: 0, IsFavorite: false, Played: false, Key: id, ItemId: id },
  };
}

module.exports = { create, add, removeItems, remove, children, list, get, isCollection, isView, viewDto, viewId, imageUrl };
