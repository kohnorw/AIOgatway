'use strict';
// Reads where a file's keyframes are without downloading it, using a few
// small HTTP range requests:
//   • MKV: the Cues index (normally at the end of the file)
//   • MP4: the sync-sample table (stss) inside the moov box
// The remux cuts segments exactly on these keyframes, so every segment starts
// exactly where the playlist says it does. That keeps the player's clock (and
// therefore subtitles) exact even when playback starts mid-file (resume/seek).
//
// The same requests give the file size and the OpenSubtitles hash (first and
// last 64 KiB), which lets subtitle add-ons return subtitles timed for this
// exact release.
const { openStream } = require('./http');

const HEAD = 256 * 1024;
const MAX_INDEX = 24 * 1024 * 1024;

/** Fetch bytes [start, end] (inclusive). Returns { buf, size }. */
function range(url, start, end, headers = {}) {
  return new Promise((resolve, reject) => {
    openStream(url, { ...headers, range: `bytes=${start}-${end}` }).then((res) => {
      const want = end - start + 1;
      const partial = res.statusCode === 206;
      if (!partial && !(res.statusCode === 200 && start === 0)) { res.destroy(); return reject(new Error(`range not supported (HTTP ${res.statusCode})`)); }
      const total = partial ? parseInt(String(res.headers['content-range'] || '').split('/')[1], 10) : parseInt(res.headers['content-length'], 10);
      const chunks = []; let got = 0; let done = false;
      const finish = () => { if (done) return; done = true; resolve({ buf: Buffer.concat(chunks).subarray(0, want), size: Number.isFinite(total) ? total : null }); };
      res.on('data', (c) => { chunks.push(c); got += c.length; if (got >= want) { finish(); res.destroy(); } });
      res.on('end', finish);
      res.on('error', (e) => { if (!done) { done = true; reject(e); } });
    }, reject);
  });
}

// ── Matroska (EBML) ────────────────────────────────────────────────────
function vint(buf, pos) {
  const b = buf[pos]; if (b === undefined) return null;
  let len = 1; let mask = 0x80;
  while (len <= 8 && !(b & mask)) { mask >>= 1; len++; }
  if (len > 8 || pos + len > buf.length) return null;
  let value = b & (mask - 1);
  let allOnes = value === mask - 1;
  for (let i = 1; i < len; i++) { value = value * 256 + buf[pos + i]; if (buf[pos + i] !== 0xff) allOnes = false; }
  return { value, length: len, unknown: allOnes };
}
function ebmlId(buf, pos) {
  const b = buf[pos]; if (b === undefined) return null;
  let len = 1; let mask = 0x80;
  while (len <= 4 && !(b & mask)) { mask >>= 1; len++; }
  if (len > 4 || pos + len > buf.length) return null;
  let id = 0; for (let i = 0; i < len; i++) id = id * 256 + buf[pos + i];
  return { id, length: len };
}
const uint = (buf, s, e) => { let v = 0; for (let i = s; i < e; i++) v = v * 256 + buf[i]; return v; };
function* children(buf, start, end) {
  let p = start;
  while (p < end) {
    const id = ebmlId(buf, p); if (!id) return;
    const sz = vint(buf, p + id.length); if (!sz) return;
    const dataStart = p + id.length + sz.length;
    const dataEnd = sz.unknown ? end : Math.min(end, dataStart + sz.value);
    yield { id: id.id, start: dataStart, end: dataEnd, size: sz.unknown ? null : sz.value };
    if (sz.unknown) return;
    p = dataStart + sz.value;
  }
}
const ID = { EBML: 0x1A45DFA3, Segment: 0x18538067, SeekHead: 0x114D9B74, Seek: 0x4DBB, SeekID: 0x53AB, SeekPosition: 0x53AC, Info: 0x1549A966, TimecodeScale: 0x2AD7B1, Tracks: 0x1654AE6B, TrackEntry: 0xAE, TrackNumber: 0xD7, TrackType: 0x83, Cues: 0x1C53BB6B, CuePoint: 0xBB, CueTime: 0xB3, CueTrackPositions: 0xB7, CueTrack: 0xF7, Cluster: 0x1F43B675 };

async function mkvKeyframes(url, head, headers) {
  const top = [...children(head, 0, head.length)];
  const seg = top.find((c) => c.id === ID.Segment);
  if (!seg) return null;
  let scale = 1e6; let videoTrack = null; let cuesPos = null;
  const readInfo = (b, s, e) => { for (const c of children(b, s, e)) if (c.id === ID.TimecodeScale) scale = uint(b, c.start, c.end); };
  const readTracks = (b, s, e) => {
    for (const t of children(b, s, e)) if (t.id === ID.TrackEntry) {
      let num = null; let type = null;
      for (const f of children(b, t.start, t.end)) { if (f.id === ID.TrackNumber) num = uint(b, f.start, f.end); if (f.id === ID.TrackType) type = uint(b, f.start, f.end); }
      if (type === 1 && videoTrack === null) videoTrack = num;
    }
  };
  for (const c of children(head, seg.start, head.length)) {
    if (c.id === ID.Cluster) break;
    if (c.id === ID.Info && c.end <= head.length) readInfo(head, c.start, c.end);
    if (c.id === ID.Tracks && c.end <= head.length) readTracks(head, c.start, c.end);
    if (c.id === ID.Cues) cuesPos = c.start - seg.start; // rare: cues up front
    if (c.id === ID.SeekHead) {
      for (const s of children(head, c.start, c.end)) if (s.id === ID.Seek) {
        let sid = null; let pos = null;
        for (const f of children(head, s.start, s.end)) { if (f.id === ID.SeekID) sid = uint(head, f.start, f.end); if (f.id === ID.SeekPosition) pos = uint(head, f.start, f.end); }
        if (sid === ID.Cues && pos !== null && cuesPos === null) cuesPos = pos;
      }
    }
  }
  if (cuesPos === null) return null;
  const abs = seg.start + cuesPos;
  // Element header first (id + size), then the whole Cues element.
  const hdr = (await range(url, abs, abs + 15, headers)).buf;
  const id = ebmlId(hdr, 0); const sz = id && vint(hdr, id.length);
  if (!id || id.id !== ID.Cues || !sz || sz.unknown || sz.value > MAX_INDEX) return null;
  const dataAt = abs + id.length + sz.length;
  const cues = (await range(url, dataAt, dataAt + sz.value - 1, headers)).buf;
  const times = [];
  for (const cp of children(cues, 0, cues.length)) {
    if (cp.id !== ID.CuePoint) continue;
    let t = null; let forVideo = videoTrack === null;
    for (const f of children(cues, cp.start, cp.end)) {
      if (f.id === ID.CueTime) t = uint(cues, f.start, f.end);
      if (f.id === ID.CueTrackPositions && videoTrack !== null) {
        for (const g of children(cues, f.start, f.end)) if (g.id === ID.CueTrack && uint(cues, g.start, g.end) === videoTrack) forVideo = true;
      }
    }
    if (t !== null && forVideo) times.push((t * scale) / 1e9);
  }
  return times;
}

// ── MP4 / MOV ──────────────────────────────────────────────────────────
function boxes(buf, start, end) {
  const out = []; let p = start;
  while (p + 8 <= end) {
    let size = buf.readUInt32BE(p); const type = buf.toString('latin1', p + 4, p + 8); let hdr = 8;
    if (size === 1) { if (p + 16 > end) break; size = Number(buf.readBigUInt64BE(p + 8)); hdr = 16; }
    else if (size === 0) size = end - p;
    if (size < hdr) break;
    out.push({ type, start: p + hdr, end: Math.min(end, p + size) });
    p += size;
  }
  return out;
}
const find = (buf, list, type) => list.find((b) => b.type === type);

async function mp4Keyframes(url, head, headers, size) {
  // Find moov among top-level boxes (it may sit after a huge mdat).
  let p = 0; let moov = null;
  for (let i = 0; i < 64 && (size === null || p < size); i++) {
    let h = p + 16 <= head.length ? head.subarray(p, p + 16) : (await range(url, p, p + 15, headers)).buf;
    if (h.length < 8) break;
    let bsize = h.readUInt32BE(0); const type = h.toString('latin1', 4, 8);
    if (bsize === 1) bsize = Number(h.readBigUInt64BE(8)); else if (bsize === 0 && size) bsize = size - p;
    if (bsize < 8) break;
    if (type === 'moov') { moov = { at: p, size: bsize }; break; }
    p += bsize;
  }
  if (!moov || moov.size > MAX_INDEX) return null;
  const mb = moov.at + moov.size <= head.length ? head.subarray(moov.at, moov.at + moov.size) : (await range(url, moov.at, moov.at + moov.size - 1, headers)).buf;
  for (const trak of boxes(mb, 8, mb.length).filter((b) => b.type === 'trak')) {
    const tk = boxes(mb, trak.start, trak.end);
    const mdia = find(mb, tk, 'mdia'); if (!mdia) continue;
    const md = boxes(mb, mdia.start, mdia.end);
    const hdlr = find(mb, md, 'hdlr');
    if (!hdlr || mb.toString('latin1', hdlr.start + 8, hdlr.start + 12) !== 'vide') continue;
    const mdhd = find(mb, md, 'mdhd');
    const timescale = mb[mdhd.start] === 1 ? mb.readUInt32BE(mdhd.start + 20) : mb.readUInt32BE(mdhd.start + 12);
    const minf = find(mb, md, 'minf'); const stbl = minf && find(mb, boxes(mb, minf.start, minf.end), 'stbl');
    if (!stbl) return null;
    const st = boxes(mb, stbl.start, stbl.end);
    const stss = find(mb, st, 'stss'); const stts = find(mb, st, 'stts'); const ctts = find(mb, st, 'ctts');
    if (!stss || !stts) return null; // no sync table: every frame is a keyframe, nothing useful
    // Edit list: the presentation starts at media_time.
    let shift = 0;
    const edts = find(mb, tk, 'edts'); const elst = edts && find(mb, boxes(mb, edts.start, edts.end), 'elst');
    if (elst) {
      const v = mb[elst.start]; const n = mb.readUInt32BE(elst.start + 4);
      for (let i = 0; i < n; i++) {
        const at = elst.start + 8 + i * (v === 1 ? 20 : 12);
        const mt = v === 1 ? Number(mb.readBigInt64BE(at + 8)) : mb.readInt32BE(at + 4);
        if (mt >= 0) { shift = mt; break; }
      }
    }
    const sync = new Set(); const ns = mb.readUInt32BE(stss.start + 4);
    for (let i = 0; i < ns; i++) sync.add(mb.readUInt32BE(stss.start + 8 + i * 4));
    const cto = [];
    if (ctts) {
      const v = mb[ctts.start]; const n = mb.readUInt32BE(ctts.start + 4);
      for (let i = 0; i < n; i++) { const c = mb.readUInt32BE(ctts.start + 8 + i * 8); const o = v === 1 ? mb.readInt32BE(ctts.start + 12 + i * 8) : mb.readUInt32BE(ctts.start + 12 + i * 8); cto.push([c, o]); }
    }
    const times = []; let sample = 1; let dts = 0; let ci = 0; let cLeft = cto.length ? cto[0][0] : 0;
    const n = mb.readUInt32BE(stts.start + 4);
    for (let i = 0; i < n; i++) {
      const count = mb.readUInt32BE(stts.start + 8 + i * 8); const delta = mb.readUInt32BE(stts.start + 12 + i * 8);
      for (let k = 0; k < count; k++, sample++) {
        let off = 0;
        if (cto.length) { while (cLeft === 0 && ci < cto.length - 1) { ci++; cLeft = cto[ci][0]; } off = cto[ci][1]; cLeft--; }
        if (sync.has(sample)) times.push((dts + off - shift) / timescale);
        dts += delta;
      }
    }
    return times;
  }
  return null;
}

// ── OpenSubtitles hash: size + 64-bit sums of the first and last 64 KiB ──
function osHash(head, tail, size) {
  let h = BigInt(size);
  const add = (b) => { for (let i = 0; i + 8 <= b.length; i += 8) h = (h + b.readBigUInt64LE(i)) & 0xFFFFFFFFFFFFFFFFn; };
  add(head.subarray(0, 65536)); add(tail);
  return h.toString(16).padStart(16, '0');
}

/**
 * { keyframes: [seconds…] | null, size, hash } for a stream URL.
 * Never throws; anything unreadable just comes back null.
 */
async function read(url, headers) {
  const out = { keyframes: null, size: null, hash: null };
  let head;
  try { const r = await range(url, 0, HEAD - 1, headers); head = r.buf; out.size = r.size; } catch { return out; }
  const tasks = [];
  if (out.size && out.size >= 131072 && head.length >= 65536) {
    tasks.push(range(url, out.size - 65536, out.size - 1, headers).then((t) => { if (t.buf.length === 65536) out.hash = osHash(head, t.buf, out.size); }).catch(() => {}));
  }
  const isMkv = head.length >= 4 && head.readUInt32BE(0) === ID.EBML;
  const isMp4 = head.length >= 8 && /^(ftyp|moov|free|skip|wide|mdat)$/.test(head.toString('latin1', 4, 8));
  tasks.push((isMkv ? mkvKeyframes(url, head, headers) : isMp4 ? mp4Keyframes(url, head, headers, out.size) : Promise.resolve(null))
    .then((k) => {
      if (k && k.length >= 2) out.keyframes = [...new Set(k.map((x) => Math.round(x * 1e6) / 1e6))].sort((a, b) => a - b);
    }).catch(() => {}));
  await Promise.all(tasks);
  return out;
}

module.exports = { read, osHash, range };
