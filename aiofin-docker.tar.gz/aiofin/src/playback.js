'use strict';
// Turns AIOStreams results into Jellyfin MediaSources.
//
// • Web and mobile clients (configurable) always get an HLS remux: video is
//   copied when the device can decode it, audio becomes stereo AAC. That
//   guarantees sound on every device.
// • Other clients direct play via a 302 to the AIOStreams/debrid link,
//   unless the file contains something their device profile rules out.
// • Track info comes from ffprobe (see probe.js), not guesses, so the
//   English audio track is the default and players list the real tracks.
const aio = require('./aio');
const library = require('./library');
const store = require('./store');
const probe = require('./probe');
const { settings } = require('./config');
const { resLabel, LANG_NAMES } = require('./parse');
const { withTimeout, fmtBytes, randomHex, TICKS_PER_SEC, log } = require('./util');
const transcode = require('./transcode');

const subtitleUrls = new Map(); // `${sid}:${index}` → upstream subtitle URL
function rememberSub(key, url) {
  subtitleUrls.delete(key); subtitleUrls.set(key, url);
  if (subtitleUrls.size > 20_000) subtitleUrls.delete(subtitleUrls.keys().next().value);
}

const split = (s) => String(s || '').toLowerCase().split(',').map((x) => x.trim()).filter(Boolean);
const CONTAINER_ALIASES = { mkv: ['mkv', 'matroska'], mp4: ['mp4', 'm4v', 'mov'], m4v: ['mp4', 'm4v'], webm: ['webm', 'mkv'], ts: ['ts', 'mpegts'], m2ts: ['m2ts', 'ts'], avi: ['avi'], mov: ['mov', 'mp4'] };
const AUDIO_NAMES = { aac: 'AAC', ac3: 'Dolby Digital', eac3: 'Dolby Digital+', truehd: 'TrueHD', dts: 'DTS', flac: 'FLAC', opus: 'Opus', mp3: 'MP3', vorbis: 'Vorbis', pcm_s16le: 'PCM', pcm_s24le: 'PCM' };
const GUESSED_INDEX = 900; // track numbers for guessed (not yet read) tracks
const TEXT_SUBS = new Set(['subrip', 'srt', 'ass', 'ssa', 'webvtt', 'mov_text', 'text']);

function isInternalHost(url) {
  try {
    const h = new URL(url).hostname;
    if (h === 'localhost' || !h.includes('.')) return true;
    return /^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(h);
  } catch { return false; }
}

// ── Device classes ─────────────────────────────────────────────────────
/** 'web' | 'mobile' | 'tv' | 'desktop', from the client's auth header. */
function deviceClass(auth = {}) {
  const c = `${auth.client || ''}`.toLowerCase();
  const d = `${auth.device || ''}`.toLowerCase();
  const both = `${c} ${d}`;
  if (/android ?tv|androidtv|apple ?tv|tvos|shield|fire ?tv|firetv|aft[a-z]|roku|webos|tizen|kodi|xbox|chromecast|google tv|bravia/.test(both)) return 'tv';
  if (/iphone|ipad|ipod|\bios\b|android|mobile|phone|streamyfin|findroid|swiftfin/.test(both)) return 'mobile';
  if (/jellyfin web|\bweb\b|browser|chrome|firefox|safari|edge|opera|vivaldi/.test(both)) return 'web';
  return 'desktop';
}
const remuxClasses = () => split(settings.remuxDevices);
const mustRemux = (auth) => transcode.available() && remuxClasses().includes(deviceClass(auth));

// ── Facts about a source: probed if we have them, parsed from the name if not ──
function facts(src, audioIndex) {
  const p = probe.peek(src.sid);
  if (p) {
    const a = probe.pickAudio(p, audioIndex);
    return {
      probed: p, container: p.container || src.container || 'mkv', vcodec: p.video?.codec || null,
      bitDepth: p.video?.bitDepth || 8, height: p.video?.height || src.info.height,
      acodec: a ? a.codec : null, audio: a, noAudio: p.audios.length === 0,
    };
  }
  return { probed: null, container: src.container || 'mkv', vcodec: src.info.vcodec || null, bitDepth: src.info.bitDepth || 8, height: src.info.height, acodec: src.info.acodec || null, audio: null, noAudio: false };
}

/**
 * Whether the client can play the file as-is. Anything we can't confirm is
 * assumed to be the hardest plausible case, so the answer is never "yes" for
 * a file that would play silently.
 */
function canDirectPlay(profile, src, auth, f) {
  if (mustRemux(auth)) return false;
  if (deviceClass(auth) === 'web') {
    if (src.notWebReady) return false;
    if (f.vcodec === 'h264' && f.bitDepth === 10) return false;
  }
  if (!profile || !Array.isArray(profile.DirectPlayProfiles)) return true;
  const containers = CONTAINER_ALIASES[f.container] || [f.container];
  const vNeed = f.vcodec ? [f.vcodec] : ['h264', 'hevc'];
  const aNeed = f.noAudio ? [] : f.acodec ? [f.acodec] : ['aac', 'ac3', 'eac3', 'dts', 'truehd'];
  for (const p of profile.DirectPlayProfiles) {
    if (p.Type && p.Type !== 'Video') continue;
    const cs = split(p.Container);
    if (cs.length && !containers.some((c) => cs.includes(c))) continue;
    const vc = split(p.VideoCodec).map((x) => (x === 'h265' ? 'hevc' : x));
    if (vc.length && !vNeed.every((v) => vc.includes(v))) continue;
    const ac = split(p.AudioCodec);
    if (ac.length && !aNeed.every((a) => ac.includes(a) || (a === 'dts' && ac.includes('dca')))) continue;
    return true;
  }
  return false;
}

function transcodeVideoCodecs(profile, auth) {
  const tps = (profile && profile.TranscodingProfiles) || [];
  const hls = tps.find((p) => (p.Type === 'Video' || !p.Type) && /hls/i.test(p.Protocol || '')) || tps.find((p) => p.Type === 'Video');
  const list = split(hls && hls.VideoCodec).map((x) => (x === 'h265' ? 'hevc' : x));
  if (list.length) return list;
  // No profile: Apple and Android devices decode HEVC in hardware; browsers may not.
  return deviceClass(auth) === 'mobile' ? ['h264', 'hevc'] : ['h264'];
}

// ── Labels ─────────────────────────────────────────────────────────────
function sourceName(src) {
  if (settings.sourceNames === 'aiostreams' && (src.aioName || src.aioDesc.length)) {
    return [src.aioName, ...src.aioDesc].join(' ').replace(/\s+/g, ' ').slice(0, 160);
  }
  const i = src.info;
  const parts = [];
  const head = [resLabel(i.height), i.hdrLabel].filter(Boolean).join(' ');
  if (head) parts.push(head);
  if (i.quality) parts.push(i.quality);
  if (i.vcodec && i.vcodec !== 'h264') parts.push(i.vcodec.toUpperCase());
  // Audio: the real track when probed (names often omit it), else what the name says.
  const pr = probe.peek(src.sid);
  const pa = pr && probe.pickAudio(pr);
  const audio = pa
    ? [SHORT_AUDIO[pa.codec] || (pa.codec || '').toUpperCase(), layoutName(pa.channels, pa.layout).replace('Stereo', '2.0'),
      i.atmos && (pa.codec === 'truehd' || pa.codec === 'eac3') ? 'Atmos' : ''].filter(Boolean).join(' ')
    : [i.aLabel, i.layout, i.atmos ? 'Atmos' : ''].filter(Boolean).join(' ');
  if (audio) parts.push(audio);
  const langs = pr ? new Set(pr.audios.map((a) => a.lang).filter((l) => l && l !== 'und')).size : 0;
  if (langs > 1 || i.multi) parts.push('MULTi');
  if (src.size) parts.push(fmtBytes(src.size));
  if (src.service) parts.push(`${src.service}${src.cached === true ? ' ⚡' : src.cached === false ? ' ⏳' : ''}`);
  else if (src.usenet) parts.push('Usenet');
  const origin = src.indexer || src.addon;
  if (origin) parts.push(origin);
  if (!parts.length) return (src.filename || src.aioName || 'Stream').slice(0, 120);
  return parts.join(' · ');
}

/** Labels for a list, made unique: duplicates get their release group (or a number). */
function labelAll(list) {
  const names = list.map(sourceName);
  const count = new Map();
  for (const n of names) count.set(n, (count.get(n) || 0) + 1);
  const seen = new Map();
  return names.map((n, i) => {
    if (count.get(n) < 2) return n;
    const group = (list[i].filename || '').replace(/\.[a-z0-9]{2,4}$/i, '').match(/-([A-Za-z0-9]+)$/);
    seen.set(n, (seen.get(n) || 0) + 1);
    return `${n} · ${group ? group[1] : `#${seen.get(n)}`}`;
  });
}

const SHORT_AUDIO = { aac: 'AAC', ac3: 'DD', eac3: 'DD+', truehd: 'TrueHD', dts: 'DTS', flac: 'FLAC', opus: 'Opus', mp3: 'MP3' };
const SHORT_LANGS = { en: 'English', es: 'Spanish', fr: 'French', de: 'German', it: 'Italian', pt: 'Portuguese', ja: 'Japanese', ko: 'Korean' };
function langName(code) {
  const c = String(code || '').toLowerCase();
  if (!c || c === 'und') return '';
  return LANG_NAMES[c] || SHORT_LANGS[c] || c.toUpperCase();
}
const layoutName = (ch, layout) => (ch >= 8 ? '7.1' : ch >= 6 ? '5.1' : ch === 2 ? 'Stereo' : ch === 1 ? 'Mono' : (layout || ''));

// ── MediaStreams ───────────────────────────────────────────────────────
function mediaStreams(src, f, subs, ctx, remux) {
  const { itemId, token } = ctx;
  const out = [];
  const p = f.probed;
  if (p) {
    if (p.video) {
      const v = p.video;
      out.push({
        Codec: v.codec, Type: 'Video', Index: v.index, IsDefault: true, IsForced: false, IsExternal: false,
        Height: v.height, Width: v.width, BitDepth: v.bitDepth, VideoRange: v.range, VideoRangeType: v.rangeType,
        DisplayTitle: [resLabel(v.height), (v.codec || '').toUpperCase(), v.rangeType === 'SDR' ? '' : v.rangeType.replace('DOVIWithHDR10', 'DV HDR10').replace('DOVI', 'DV')].filter(Boolean).join(' '),
        Profile: v.profile, PixelFormat: v.pixFmt, IsInterlaced: false, IsAVC: v.codec === 'h264', AspectRatio: '16:9', Level: 0,
        IsAnamorphic: false, SupportsExternalStream: false, IsTextSubtitleStream: false,
      });
    }
    for (const a of p.audios) {
      const title = [langName(a.lang), AUDIO_NAMES[a.codec] || (a.codec || '').toUpperCase(), layoutName(a.channels, a.layout), a.title && /commentary/i.test(a.title) ? '(Commentary)' : ''].filter(Boolean).join(' ');
      out.push({
        Codec: a.codec, Type: 'Audio', Index: a.index, IsDefault: f.audio && a.index === f.audio.index, IsForced: false, IsExternal: false,
        Language: a.lang || undefined, Title: a.title || undefined, Channels: a.channels, ChannelLayout: a.layout, Profile: a.profile,
        DisplayTitle: title || 'Audio', SupportsExternalStream: false, IsTextSubtitleStream: false, Level: 0,
      });
    }
    // Embedded subtitles only make sense when the player reads the file itself.
    if (!remux) {
      for (const s of p.subs) {
        out.push({
          Codec: s.codec, Type: 'Subtitle', Index: s.index, IsDefault: s.isDefault, IsForced: s.forced, IsExternal: false,
          Language: s.lang || undefined, Title: s.title || undefined, DeliveryMethod: 'Embed',
          DisplayTitle: [langName(s.lang) || 'Unknown', s.forced ? '(Forced)' : '', s.title && !/^(english|forced|full|sdh)$/i.test(s.title) ? `- ${s.title}` : ''].filter(Boolean).join(' '),
          IsTextSubtitleStream: TEXT_SUBS.has(s.codec), SupportsExternalStream: false, Level: 0,
        });
      }
    }
  } else {
    // Not read yet: these tracks are guesses from the release name. They get
    // track numbers no real file uses, so a guess sent back as "play track N"
    // can never select the wrong real track (the server then picks by language).
    const i = src.info;
    out.push({
      Codec: i.vcodec || 'h264', Type: 'Video', Index: GUESSED_INDEX, IsDefault: true, IsForced: false, IsExternal: false,
      Height: i.height || undefined, Width: i.width || undefined, BitDepth: i.bitDepth || (i.range === 'HDR' ? 10 : 8),
      VideoRange: i.range || 'SDR', VideoRangeType: i.rangeType || 'SDR',
      DisplayTitle: [resLabel(i.height), (i.vcodec || '').toUpperCase(), i.hdrLabel].filter(Boolean).join(' ') || 'Video',
      IsInterlaced: false, IsAVC: i.vcodec === 'h264', AspectRatio: '16:9', Level: 0, IsAnamorphic: false,
      SupportsExternalStream: false, IsTextSubtitleStream: false,
    });
    const lang = i.languages[0] || null;
    out.push({
      Codec: i.acodec || 'aac', Type: 'Audio', Index: GUESSED_INDEX + 1, IsDefault: true, IsForced: false, IsExternal: false,
      Language: lang || undefined, Channels: i.channels || 2, ChannelLayout: i.layout === '7.1' ? '7.1' : i.layout === '5.1' ? '5.1' : 'stereo',
      DisplayTitle: [lang ? LANG_NAMES[lang] : '', i.aLabel, i.layout, i.atmos ? 'Atmos' : ''].filter(Boolean).join(' ') || 'Audio',
      SupportsExternalStream: false, IsTextSubtitleStream: false, Level: 0,
    });
  }
  // External subtitles (AIOStreams + OpenSubtitles) get indexes after the file's own tracks.
  let next = out.reduce((m, s) => Math.max(m, s.Index), -1) + 1;
  for (const s of subs || []) {
    const index = next++;
    const isVtt = /\.vtt(\?|$)/i.test(s.url);
    rememberSub(`${src.sid}:${index}`, s.url);
    out.push({
      Codec: isVtt ? 'webvtt' : 'subrip', Type: 'Subtitle', Index: index, IsDefault: false, IsForced: false,
      IsExternal: true, IsTextSubtitleStream: true, SupportsExternalStream: true, DeliveryMethod: 'External',
      Language: s.lang || undefined,
      DisplayTitle: `${langName(s.lang) || 'Unknown'}${/strem\.io|opensubtitles/i.test(s.url) ? ' (OpenSubtitles)' : ''}`,
      DeliveryUrl: `/Videos/${itemId}/${src.sid}/Subtitles/${index}/0/Stream.vtt?api_key=${token || ''}`,
      Path: s.url, Level: 0,
    });
  }
  return out;
}

function toMediaSource(src, ctx) {
  const { itemId, runtime, profile, auth, token, origin, playSessionId, subs, audioStreamIndex } = ctx;
  const f = facts(src, audioStreamIndex);
  const remux = mustRemux(auth);
  const direct = canDirectPlay(profile, src, auth, f);
  const mustProxy = settings.streamMode === 'proxy' || !!src.headers || (settings.proxyInternal && isInternalHost(src.url));
  const localUrl = `${origin}/Videos/${itemId}/stream.${src.container || 'mkv'}?static=true&MediaSourceId=${src.sid}&api_key=${token || ''}`;
  const seconds = runtime ? runtime / TICKS_PER_SEC : (f.probed?.duration || 0);
  const ms = {
    Protocol: 'Http', Id: src.sid, Path: mustProxy ? localUrl : src.url, Type: 'Default',
    Container: f.container, Size: src.size || undefined, Name: (ctx.labels && ctx.labels.get(src.sid)) || sourceName(src), IsRemote: true,
    ETag: src.sid, RunTimeTicks: runtime || (f.probed?.duration ? Math.round(f.probed.duration * TICKS_PER_SEC) : undefined),
    ReadAtNativeFramerate: false, IgnoreDts: false, IgnoreIndex: false, GenPtsInput: false,
    SupportsTranscoding: transcode.available(), SupportsDirectStream: direct, SupportsDirectPlay: direct,
    IsInfiniteStream: false, UseMostCompatibleTranscodingProfile: false, RequiresOpening: false, RequiresClosing: false,
    RequiresLooping: false, SupportsProbing: false, VideoType: 'VideoFile', MediaAttachments: [], Formats: [],
    RequiredHttpHeaders: {}, HasSegments: false,
    Bitrate: f.probed?.bitrate || (src.size && seconds ? Math.round((src.size * 8) / seconds) : undefined),
    DefaultAudioStreamIndex: f.audio ? f.audio.index : GUESSED_INDEX + 1, DefaultSubtitleStreamIndex: -1,
    AiofinTracksKnown: !!f.probed,
    MediaStreams: mediaStreams(src, f, subs, ctx, remux || !direct),
  };
  if (!direct && transcode.available()) {
    const vc = transcodeVideoCodecs(profile, auth).join(',');
    const audioQ = f.audio ? `&audio=${f.audio.index}` : '';
    ms.TranscodingUrl = `/Videos/${itemId}/hls/${playSessionId}.${src.sid}/main.m3u8?vcodecs=${encodeURIComponent(vc)}${audioQ}&api_key=${token || ''}`;
    ms.TranscodingSubProtocol = 'hls';
    ms.TranscodingContainer = 'ts';
    ms.TranscodeReasons = remux ? ['DirectPlayError'] : ['AudioCodecNotSupported'];
  }
  return ms;
}

// ── Remembered stream choice per user + title ──────────────────────────
const prefKey = (itemId) => `src:${itemId}`;
function preferredSource(userId, itemId) { return (userId && store.userData.get(userId, prefKey(itemId))?.sid) || null; }
function rememberSource(userId, itemId, sid) { if (userId && sid) store.userData.upsert(userId, prefKey(itemId), { sid, at: Date.now() }); }

/**
 * Jellyfin PlaybackInfo. Waits up to STREAM_WAIT_MS for AIOStreams; if the
 * title was opened a moment earlier the list (and its track info) is cached
 * and this returns in a few milliseconds.
 */
async function playbackInfo(itemId, { profile, mediaSourceId, audioStreamIndex, auth = {}, token, origin, userId, remember = true, forceProbe = false }) {
  const target = library.streamTarget(itemId);
  if (!target) return null;
  const t0 = Date.now();
  const state = aio.streamState(target.type, target.id);
  const subsP = settings.subtitles ? aio.subtitles(target.type, target.id).catch(() => []) : Promise.resolve([]);
  const list = await withTimeout(aio.streams(target.type, target.id, 'play'), settings.streamWaitMs, null).catch((e) => {
    log('warn', `stream lookup failed for ${target.id}: ${e.message}`);
    return [];
  });
  const playSessionId = randomHex(16);
  if (!list || !list.length) {
    log('info', `PlaybackInfo ${target.id}: no streams (${list === null ? 'timed out' : 'empty'}) after ${Date.now() - t0}ms`);
    return { MediaSources: [], PlaySessionId: playSessionId, ErrorCode: 'NoCompatibleStream' };
  }

  // Order: an explicitly requested stream, else the one this person picked last time, else AIOStreams' order.
  let ordered = list.slice(0, Math.max(1, settings.maxSources));
  const explicit = mediaSourceId && mediaSourceId !== itemId ? list.find((s) => s.sid === mediaSourceId) : null;
  if (explicit) {
    if (remember) rememberSource(userId, itemId, explicit.sid);
    ordered = [explicit];
  } else {
    const pref = preferredSource(userId, itemId);
    const hit = pref && ordered.find((s) => s.sid === pref);
    if (hit) ordered = [hit, ...ordered.filter((s) => s !== hit)];
  }

  // Real track info for the stream that will play. Remux clients wait for it
  // (the remux needs it anyway, so it costs no extra time overall); others
  // wait only if the release name left the codecs unknown.
  probe.warm(ordered);
  const primary = ordered[0];
  const remux = mustRemux(auth);
  if (probe.enabled() && !probe.peek(primary.sid) && primary.cached !== false) {
    const mustKnow = forceProbe || remux || (profile && (!primary.info.acodec || !primary.info.vcodec));
    if (mustKnow) {
      const budget = Math.max(0, settings.probeWaitMs - (Date.now() - t0));
      await withTimeout(probe.probe(primary).catch(() => null), budget, null);
    } else if (probe.loading(primary.sid)) {
      // Already being read since the title was opened: a short wait gets the
      // real track list (so the right language is the default) at little cost.
      await withTimeout(probe.probe(primary).catch(() => null), 1500, null);
    }
  }

  const subs = settings.subtitles ? ((await withTimeout(subsP, 400, null)) || aio.peekSubtitles(target.type, target.id) || []) : [];
  let runtime = null;
  try { runtime = (await withTimeout(library.getItem(itemId, null, { full: false }), 1500, null))?.RunTimeTicks || null; } catch { /* ignore */ }

  const shown = list.slice(0, Math.max(1, settings.maxSources));
  const labels = new Map(labelAll(shown).map((n, i) => [shown[i].sid, n]));
  const ctx = { itemId, runtime, profile, auth, token, origin, playSessionId, subs, audioStreamIndex, labels };
  const sources = ordered.map((s) => toMediaSource(s, ctx));
  log('info', `PlaybackInfo ${target.id}: ${sources.length} sources in ${Date.now() - t0}ms (cache: ${state}, ${deviceClass(auth)}${remux ? ', remux' : ''})`);
  return { MediaSources: sources, PlaySessionId: playSessionId };
}

/** Resolve the upstream source for /Videos/{id}/stream and the HLS remux. */
async function resolveSource(itemId, mediaSourceId) {
  let src = mediaSourceId && aio.getSource(mediaSourceId);
  if (src) return src;
  const target = library.streamTarget(itemId);
  if (!target) return null;
  const list = await withTimeout(aio.streams(target.type, target.id, 'play'), settings.streamWaitMs, []);
  src = (mediaSourceId && list.find((s) => s.sid === mediaSourceId)) || list[0];
  return src || null;
}

/** Streams after `sid` for the same title, for automatic fallback. */
async function fallbacks(itemId, sid, n = 3) {
  const target = library.streamTarget(itemId);
  if (!target) return [];
  const list = await withTimeout(aio.streams(target.type, target.id, 'play'), settings.streamWaitMs, []);
  const i = list.findIndex((s) => s.sid === sid);
  return list.slice(i + 1).filter((s) => s.cached !== false).slice(0, n);
}

/** Compact list for the in-player stream switcher. */
async function sourceList(itemId, userId) {
  const target = library.streamTarget(itemId);
  if (!target) return null;
  const list = await withTimeout(aio.streams(target.type, target.id, 'play'), settings.streamWaitMs, []);
  return {
    Preferred: preferredSource(userId, itemId),
    Sources: (() => { const shown = list.slice(0, Math.max(1, settings.maxSources)); const names = labelAll(shown); return shown.map((s, i) => ({ Id: s.sid, Name: names[i], Cached: s.cached })); })(),
  };
}

module.exports = {
  playbackInfo, resolveSource, fallbacks, sourceList, subtitleUrls, canDirectPlay, sourceName,
  isInternalHost, deviceClass, mustRemux, rememberSource,
};
