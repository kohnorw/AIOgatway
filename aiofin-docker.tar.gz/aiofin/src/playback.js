'use strict';
// Turns AIOStreams results into Jellyfin MediaSources.
//
// Native clients (Infuse, Swiftfin, Jellyfin Android/TV, Streamyfin…) direct
// play: /Videos/{id}/stream answers with a 302 to the AIOStreams/debrid URL,
// so the server is out of the data path and playback starts immediately.
// Browsers that can't decode a file get an HLS fallback (see transcode.js).
const aio = require('./aio');
const library = require('./library');
const { settings } = require('./config');
const { resLabel, LANG_NAMES } = require('./parse');
const { withTimeout, fmtBytes, randomHex, TICKS_PER_SEC, log } = require('./util');
const transcode = require('./transcode');

const subtitleUrls = new Map(); // `${sid}:${index}` → upstream subtitle URL
function rememberSub(key, url) {
  subtitleUrls.delete(key); subtitleUrls.set(key, url);
  if (subtitleUrls.size > 20_000) subtitleUrls.delete(subtitleUrls.keys().next().value);
}

const split = (s) => String(s || '').toLowerCase().split(',').map((x) => x.trim()).filter(Boolean);
const CONTAINER_ALIASES = { mkv: ['mkv', 'matroska'], mp4: ['mp4', 'm4v', 'mov'], m4v: ['mp4', 'm4v'], webm: ['webm', 'mkv'], ts: ['ts', 'mpegts'], m2ts: ['m2ts', 'ts'], avi: ['avi'], mov: ['mov', 'mp4'] };

function isInternalHost(url) {
  try {
    const h = new URL(url).hostname;
    if (h === 'localhost' || !h.includes('.')) return true;
    return /^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(h);
  } catch { return false; }
}

function isBrowser(auth) {
  return /web|browser|chrome|firefox|safari|edge/i.test(`${auth.client || ''} ${auth.device || ''}`) && !/android|ios|tvos|swiftfin|infuse|kodi|findroid|streamyfin|mpv/i.test(auth.client || '');
}

function canDirectPlay(profile, src, auth) {
  if (isBrowser(auth)) {
    if (src.notWebReady) return false;
    if (src.info.vcodec === 'h264' && src.info.bitDepth === 10) return false;
  }
  if (!profile || !Array.isArray(profile.DirectPlayProfiles)) return true;
  const container = (src.container || 'mkv').toLowerCase();
  const aliases = CONTAINER_ALIASES[container] || [container];
  for (const p of profile.DirectPlayProfiles) {
    if (p.Type && p.Type !== 'Video') continue;
    const cs = split(p.Container);
    if (cs.length && !aliases.some((a) => cs.includes(a))) continue;
    const vc = split(p.VideoCodec);
    if (vc.length && src.info.vcodec && !vc.includes(src.info.vcodec) && !(src.info.vcodec === 'hevc' && vc.includes('h265'))) continue;
    const ac = split(p.AudioCodec);
    if (ac.length && src.info.acodec && !ac.includes(src.info.acodec)) continue;
    return true;
  }
  return false;
}

function transcodeVideoCodecs(profile) {
  const tps = (profile && profile.TranscodingProfiles) || [];
  const hls = tps.find((p) => (p.Type === 'Video' || !p.Type) && /hls/i.test(p.Protocol || '')) || tps.find((p) => p.Type === 'Video');
  const list = split(hls && hls.VideoCodec);
  return list.length ? list : ['h264'];
}

function sourceName(src) {
  if (settings.sourceNames === 'aiostreams' && (src.aioName || src.aioDesc.length)) {
    return [src.aioName, ...src.aioDesc].join(' ').replace(/\s+/g, ' ').slice(0, 160);
  }
  const i = src.info;
  const parts = [];
  const head = [resLabel(i.height), i.hdrLabel].filter(Boolean).join(' ');
  if (head) parts.push(head);
  if (i.quality) parts.push(i.quality);
  if (i.vcodec && i.vcodec !== 'h264') parts.push(i.vcodec.toUpperCase());
  const audio = [i.aLabel, i.layout, i.atmos ? 'Atmos' : ''].filter(Boolean).join(' ');
  if (audio) parts.push(audio);
  if (src.size) parts.push(fmtBytes(src.size));
  if (src.service) parts.push(`${src.service}${src.cached === true ? ' ⚡' : src.cached === false ? ' ⏳' : ''}`);
  else if (src.usenet) parts.push('Usenet');
  const origin = src.indexer || src.addon;
  if (origin) parts.push(origin);
  if (!parts.length) return (src.filename || src.aioName || 'Stream').slice(0, 120);
  return parts.join(' · ');
}

function mediaStreams(src, subs, itemId, token) {
  const i = src.info;
  const out = [];
  const vTitle = [resLabel(i.height), (i.vcodec || '').toUpperCase(), i.hdrLabel].filter(Boolean).join(' ') || 'Video';
  out.push({
    Codec: i.vcodec || 'h264', Type: 'Video', Index: 0, IsDefault: true, IsForced: false, IsExternal: false,
    Height: i.height || undefined, Width: i.width || undefined, BitDepth: i.bitDepth || (i.range === 'HDR' ? 10 : 8),
    VideoRange: i.range || 'SDR', VideoRangeType: i.rangeType || 'SDR', DisplayTitle: vTitle,
    IsInterlaced: false, IsAVC: i.vcodec === 'h264', AspectRatio: '16:9', PixelFormat: i.range === 'HDR' ? 'yuv420p10le' : 'yuv420p',
    Level: 0, IsAnamorphic: false, SupportsExternalStream: false, IsTextSubtitleStream: false,
  });
  const langs = i.languages.length ? i.languages : [null];
  langs.slice(0, 4).forEach((lang, k) => {
    const title = [lang ? LANG_NAMES[lang] : '', i.aLabel, i.layout, i.atmos ? 'Atmos' : ''].filter(Boolean).join(' ') || 'Audio';
    out.push({
      Codec: i.acodec || 'aac', Type: 'Audio', Index: out.length, IsDefault: k === 0, IsForced: false, IsExternal: false,
      Language: lang || undefined, Channels: i.channels || 2, ChannelLayout: i.layout === '7.1' ? '7.1' : i.layout === '5.1' ? '5.1' : 'stereo',
      DisplayTitle: title, SupportsExternalStream: false, IsTextSubtitleStream: false, Level: 0,
    });
  });
  for (const s of subs || []) {
    const index = out.length;
    const lang = String(s.lang || '').toLowerCase().slice(0, 3);
    const isVtt = /\.vtt(\?|$)/i.test(s.url);
    rememberSub(`${src.sid}:${index}`, s.url);
    out.push({
      Codec: isVtt ? 'webvtt' : 'subrip', Type: 'Subtitle', Index: index, IsDefault: false, IsForced: false,
      IsExternal: true, IsTextSubtitleStream: true, SupportsExternalStream: true, DeliveryMethod: 'External',
      Language: lang || undefined, DisplayTitle: `${LANG_NAMES[lang] || s.lang || 'Unknown'}${s.id ? '' : ''}`,
      DeliveryUrl: `/Videos/${itemId}/${src.sid}/Subtitles/${index}/0/Stream.vtt?api_key=${token || ''}`,
      Path: s.url, Level: 0,
    });
  }
  return out;
}

function toMediaSource(src, ctx) {
  const { itemId, runtime, profile, auth, token, origin, playSessionId, subs } = ctx;
  const direct = canDirectPlay(profile, src, auth);
  const mustProxy = settings.streamMode === 'proxy' || !!src.headers || (settings.proxyInternal && isInternalHost(src.url));
  const localUrl = `${origin}/Videos/${itemId}/stream.${src.container || 'mkv'}?static=true&MediaSourceId=${src.sid}&api_key=${token || ''}`;
  const seconds = runtime ? runtime / TICKS_PER_SEC : 0;
  const ms = {
    Protocol: 'Http', Id: src.sid, Path: mustProxy ? localUrl : src.url, Type: 'Default',
    Container: src.container || 'mkv', Size: src.size || undefined, Name: sourceName(src), IsRemote: true,
    ETag: src.sid, RunTimeTicks: runtime || undefined, ReadAtNativeFramerate: false, IgnoreDts: false,
    IgnoreIndex: false, GenPtsInput: false, SupportsTranscoding: transcode.available(), SupportsDirectStream: direct,
    SupportsDirectPlay: direct, IsInfiniteStream: false, UseMostCompatibleTranscodingProfile: false,
    RequiresOpening: false, RequiresClosing: false, RequiresLooping: false, SupportsProbing: false,
    VideoType: 'VideoFile', MediaAttachments: [], Formats: [], RequiredHttpHeaders: {}, HasSegments: false,
    Bitrate: src.size && seconds ? Math.round((src.size * 8) / seconds) : undefined,
    DefaultAudioStreamIndex: 1, DefaultSubtitleStreamIndex: -1,
    MediaStreams: mediaStreams(src, subs, itemId, token),
  };
  if (!direct && transcode.available()) {
    const vc = transcodeVideoCodecs(profile).join(',');
    ms.TranscodingUrl = `/Videos/${itemId}/hls/${playSessionId}.${src.sid}/main.m3u8?vcodecs=${encodeURIComponent(vc)}&api_key=${token || ''}`;
    ms.TranscodingSubProtocol = 'hls';
    ms.TranscodingContainer = 'ts';
    ms.TranscodeReasons = ['ContainerNotSupported'];
  }
  return ms;
}

/**
 * Jellyfin PlaybackInfo. Waits up to STREAM_WAIT_MS for AIOStreams; if the
 * title was opened a moment earlier the list is already cached and this
 * returns in a few milliseconds.
 */
async function playbackInfo(itemId, { profile, mediaSourceId, auth, token, origin }) {
  const target = library.streamTarget(itemId);
  if (!target) return null;
  const t0 = Date.now();
  const state = aio.streamState(target.type, target.id);
  const subsP = settings.subtitles ? aio.subtitles(target.type, target.id).catch(() => []) : Promise.resolve([]);
  const list = await withTimeout(aio.streams(target.type, target.id, 'play'), settings.streamWaitMs, null).catch((e) => {
    log('warn', `stream lookup failed for ${target.id}: ${e.message}`);
    return [];
  });
  const playSessionId = randomHex(16);
  if (!list || !list.length) {
    log('info', `PlaybackInfo ${target.id}: no streams (${list === null ? 'timed out' : 'empty'}) after ${Date.now() - t0}ms`);
    return { MediaSources: [], PlaySessionId: playSessionId, ErrorCode: 'NoCompatibleStream' };
  }
  // Subtitles get a short grace period; they never hold playback hostage.
  const subs = settings.subtitles ? ((await withTimeout(subsP, 400, null)) || aio.peekSubtitles(target.type, target.id) || []) : [];

  let runtime = null;
  try { runtime = (await withTimeout(library.getItem(itemId, null, { full: false }), 1500, null))?.RunTimeTicks || null; } catch { /* ignore */ }

  const ctx = { itemId, runtime, profile, auth, token, origin, playSessionId, subs };
  let chosen = list.slice(0, Math.max(1, settings.maxSources));
  if (mediaSourceId && mediaSourceId !== itemId) {
    const hit = list.find((s) => s.sid === mediaSourceId);
    if (hit) chosen = [hit];
  }
  const sources = chosen.map((s) => toMediaSource(s, ctx));
  log('info', `PlaybackInfo ${target.id}: ${sources.length} sources in ${Date.now() - t0}ms (cache: ${state})`);
  return { MediaSources: sources, PlaySessionId: playSessionId };
}

/** Resolve the upstream URL for /Videos/{id}/stream. */
async function resolveSource(itemId, mediaSourceId) {
  let src = mediaSourceId && aio.getSource(mediaSourceId);
  if (src) return src;
  const target = library.streamTarget(itemId);
  if (!target) return null;
  const list = await withTimeout(aio.streams(target.type, target.id, 'play'), settings.streamWaitMs, []);
  src = (mediaSourceId && list.find((s) => s.sid === mediaSourceId)) || list[0];
  return src || null;
}

module.exports = { playbackInfo, resolveSource, subtitleUrls, canDirectPlay, sourceName, isInternalHost };
