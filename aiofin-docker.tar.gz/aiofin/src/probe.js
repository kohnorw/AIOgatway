'use strict';
// Reads a stream's real tracks (codecs, languages, channels) with ffprobe.
//
// Release names often don't say what audio a file has, and guessing wrong
// means silent playback. Probing reads only the first few MB, runs in the
// background as soon as a title is opened, and is cached per stream.
const { spawn } = require('child_process');
const { boot, settings } = require('./config');
const { SwrCache } = require('./cache');
const { log, withTimeout } = require('./util');

const cache = new SwrCache('probe', 8000);
const MAX_PARALLEL = 4;
let running = 0;
const queue = [];

function runFfprobe(url, headers) {
  return new Promise((resolve, reject) => {
    const start = () => {
      running++;
      const args = ['-v', 'error', '-print_format', 'json', '-show_format', '-show_streams',
        '-probesize', '6000000', '-analyzeduration', '4000000'];
      if (/^https?:/i.test(url)) args.push('-reconnect', '1', '-rw_timeout', '15000000');
      if (headers) args.push('-headers', Object.entries(headers).map(([k, v]) => `${k}: ${v}`).join('\r\n') + '\r\n');
      args.push(url);
      const p = spawn(boot.ffprobe, args);
      let out = ''; let err = '';
      const timer = setTimeout(() => p.kill('SIGKILL'), 20_000);
      p.stdout.on('data', (d) => { out += d; });
      p.stderr.on('data', (d) => { err = (err + d).slice(-500); });
      const done = () => { running--; clearTimeout(timer); const next = queue.shift(); if (next) next(); };
      p.on('close', (code) => {
        done();
        try {
          const j = JSON.parse(out);
          if (!j.streams || !j.streams.length) throw new Error('no streams');
          resolve(j);
        } catch { reject(new Error(err.trim().split('\n').pop() || `ffprobe exited ${code}`)); }
      });
      p.on('error', (e) => { done(); reject(e); });
    };
    if (running < MAX_PARALLEL) start(); else queue.push(start);
  });
}

const isCommentary = (s) => /commentary|director'?s? comments|descriptive|audio description/i.test(`${s.title || ''}`);
const LANG_ALIASES = { eng: ['eng', 'en', 'english'], spa: ['spa', 'es', 'spanish'], fre: ['fre', 'fra', 'fr', 'french'], ger: ['ger', 'deu', 'de', 'german'] };
function langMatches(track, want) {
  if (!want) return false;
  const aliases = LANG_ALIASES[want] || [want];
  const lang = String(track.lang || '').toLowerCase();
  if (aliases.includes(lang)) return true;
  const title = String(track.title || '').toLowerCase();
  return aliases.slice(2).some((a) => title.includes(a)) || (want === 'eng' && /\benglish\b/.test(title));
}

/** Turn ffprobe JSON into the compact shape the rest of the server uses. */
function summarize(j) {
  const streams = j.streams || [];
  const fmt = String(j.format?.format_name || '');
  const container = /matroska|webm/.test(fmt) ? 'mkv' : /mp4|mov/.test(fmt) ? 'mp4' : /mpegts/.test(fmt) ? 'ts' : /avi/.test(fmt) ? 'avi' : fmt.split(',')[0] || null;
  const v = streams.find((s) => s.codec_type === 'video' && !s.disposition?.attached_pic);
  const trc = String(v?.color_transfer || '');
  const dovi = (v?.side_data_list || []).some((d) => /dovi|dolby vision/i.test(d.side_data_type || ''));
  const hdr = /smpte2084/.test(trc); const hlg = /arib-std-b67/.test(trc);
  const video = v ? {
    index: v.index, codec: v.codec_name === 'h265' ? 'hevc' : v.codec_name, width: v.width, height: v.height,
    bitDepth: /10|12/.test(v.pix_fmt || '') ? 10 : 8, pixFmt: v.pix_fmt, profile: v.profile,
    range: dovi || hdr || hlg ? 'HDR' : 'SDR', rangeType: dovi ? (hdr ? 'DOVIWithHDR10' : 'DOVI') : hdr ? 'HDR10' : hlg ? 'HLG' : 'SDR',
  } : null;
  const audios = streams.filter((s) => s.codec_type === 'audio').map((s) => ({
    index: s.index, codec: s.codec_name, profile: s.profile, channels: s.channels, layout: s.channel_layout,
    lang: s.tags?.language || null, title: s.tags?.title || null, isDefault: !!s.disposition?.default,
  }));
  const subs = streams.filter((s) => s.codec_type === 'subtitle').map((s) => ({
    index: s.index, codec: s.codec_name, lang: s.tags?.language || null, title: s.tags?.title || null,
    isDefault: !!s.disposition?.default, forced: !!s.disposition?.forced,
  }));
  return { container, duration: parseFloat(j.format?.duration) || 0, startTime: parseFloat(j.format?.start_time) || 0, bitrate: parseInt(j.format?.bit_rate, 10) || 0, video, audios, subs };
}

/** The audio track to play: preferred language (not commentary), else the file's default, else first. */
function pickAudio(info, explicitIndex) {
  if (!info || !info.audios.length) return null;
  if (explicitIndex !== undefined && explicitIndex !== null) {
    const hit = info.audios.find((a) => a.index === Number(explicitIndex));
    if (hit) return hit;
  }
  const want = String(settings.defaultAudioLang || '').toLowerCase().trim();
  const normal = info.audios.filter((a) => !isCommentary(a));
  return normal.find((a) => langMatches(a, want))
    || normal.find((a) => a.isDefault) || normal[0] || info.audios[0];
}

function enabled() { return settings.probe && require('./transcode').available(); }

// Streams that couldn't be read are remembered for a while, so repeated asks
// fail fast instead of piling up ffprobe processes.
const failed = new Map(); // sid → time of failure
const FAIL_TTL = 5 * 60_000;

/** Probe a source (cached). Resolves with summary, rejects on failure. */
function probe(src) {
  const f = failed.get(src.sid);
  if (f && Date.now() - f < FAIL_TTL) return Promise.reject(new Error('could not read this stream recently'));
  return cache.get(src.sid, async () => {
    const t0 = Date.now();
    // Tracks (ffprobe) and the keyframe index + OpenSubtitles hash (range reads) in parallel.
    const [json, idx] = await Promise.all([
      runFfprobe(src.url, src.headers),
      withTimeout(require('./keyframes').read(src.url, src.headers || {}), 8000, { keyframes: null, size: null, hash: null }),
    ]);
    const info = summarize(json);
    info.keyframes = idx.keyframes; info.size = idx.size; info.osHash = idx.hash;
    log('debug', `probe ${src.sid.slice(0, 8)}: ${info.video?.codec} ${info.video?.height}p, audio ${info.audios.map((a) => `${a.codec}/${a.lang || '?'}`).join(' ')}, ${info.keyframes ? info.keyframes.length + ' keyframes' : 'no keyframe index'} in ${Date.now() - t0}ms`);
    return info;
  }, { ttl: 24 * 3600_000 }).catch((e) => {
    failed.set(src.sid, Date.now());
    if (failed.size > 5000) failed.delete(failed.keys().next().value);
    throw e;
  });
}
const peek = (sid) => cache.peek(sid)?.value;
const loading = (sid) => cache.isLoading(sid);

/** Start probing the first few cached sources in the background. */
function warm(list) {
  if (!enabled() || !Array.isArray(list)) return;
  // Only cached/ready results: probing an uncached one could start a debrid download.
  const picks = list.filter((s) => s.cached !== false).slice(0, Math.max(0, settings.probeTop));
  for (const s of picks) if (!peek(s.sid) && !loading(s.sid)) probe(s).catch((e) => log('debug', `probe failed ${s.sid.slice(0, 8)}: ${e.message}`));
}

module.exports = { probe, peek, loading, warm, pickAudio, summarize, enabled, langMatches, stats: () => cache.stats() };
