'use strict';
// HLS fallback for clients (mostly browsers) that can't direct play a file.
//
// • Full VOD playlist up front so seeking works everywhere.
// • Video is copied when the client can decode it, otherwise re-encoded
//   (capped at TRANSCODE_MAX_HEIGHT, HDR tone-mapped). Audio → stereo AAC.
// • Seeking far ahead restarts ffmpeg at the requested segment.
// • ffmpeg is paused (SIGSTOP) once it is TRANSCODE_AHEAD_SECS ahead of the
//   player, freeing CPU for other viewers (ported idea from Lumen).
const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');
const { settings, boot } = require('./config');
const { log, sleep } = require('./util');

const DIR = path.join(boot.dataDir, 'transcodes');
fs.rmSync(DIR, { recursive: true, force: true });
fs.mkdirSync(DIR, { recursive: true });

let ffmpegOk = null;
function available() {
  if (!settings.transcode) return false;
  if (ffmpegOk === null) {
    try { ffmpegOk = spawnSync(boot.ffmpeg, ['-version'], { timeout: 5000 }).status === 0; } catch { ffmpegOk = false; }
    if (!ffmpegOk) log('warn', `ffmpeg not found at "${boot.ffmpeg}" — browser fallback transcoding disabled`);
  }
  return ffmpegOk;
}

const sessions = new Map(); // name → session

function probe(url, headers) {
  return new Promise((resolve) => {
    const args = ['-v', 'error', '-print_format', 'json', '-show_format', '-show_streams',
      '-analyzeduration', '3000000', '-probesize', '8000000'];
    if (headers) args.push('-headers', Object.entries(headers).map(([k, v]) => `${k}: ${v}`).join('\r\n') + '\r\n');
    args.push(url);
    const p = spawn(boot.ffprobe, args);
    let out = '';
    const timer = setTimeout(() => p.kill('SIGKILL'), 20_000);
    p.stdout.on('data', (d) => { out += d; });
    p.on('close', () => { clearTimeout(timer); try { resolve(JSON.parse(out)); } catch { resolve(null); } });
    p.on('error', () => { clearTimeout(timer); resolve(null); });
  });
}

function pickAudio(streams) {
  const audio = streams.filter((s) => s.codec_type === 'audio');
  if (!audio.length) return null;
  const want = (settings.defaultAudioLang || '').toLowerCase();
  const lang = (s) => String(s.tags?.language || '').toLowerCase();
  return (want && audio.find((s) => lang(s) === want || lang(s).startsWith(want.slice(0, 2))))
    || audio.find((s) => s.disposition?.default) || audio[0];
}

async function getSession(name, src, vcodecs) {
  let s = sessions.get(name);
  if (s) { s.lastAccess = Date.now(); return s; }
  const seg = Math.max(1, settings.segmentSec);
  s = { name, src, seg, dir: path.join(DIR, name), proc: null, startSeg: 0, lastAccess: Date.now(), lastRequested: 0, paused: false, ready: null };
  sessions.set(name, s);
  s.ready = (async () => {
    fs.mkdirSync(s.dir, { recursive: true });
    const info = await probe(src.url, src.headers);
    if (!info) throw new Error('could not read the stream');
    const streams = info.streams || [];
    const v = streams.find((x) => x.codec_type === 'video' && !x.disposition?.attached_pic);
    s.duration = parseFloat(info.format?.duration) || 0;
    s.video = v;
    s.audio = pickAudio(streams);
    const codec = v && v.codec_name === 'h265' ? 'hevc' : v && v.codec_name;
    const tenBitH264 = codec === 'h264' && /10/.test(v.pix_fmt || '');
    s.copyVideo = !!v && !settings.forceEncode && vcodecs.includes(codec) && !tenBitH264 && (v.height || 0) <= Math.max(settings.transcodeMaxHeight, 2160);
    s.hdr = !!v && /smpte2084|arib-std-b67/.test(v.color_transfer || '');
    s.tonemap = s.hdr && !s.copyVideo;
    if (!s.duration) s.duration = 2 * 3600;
    s.segments = Math.ceil(s.duration / seg);
    log('info', `transcode ${name}: ${codec} ${v?.height || '?'}p → ${s.copyVideo ? 'copy' : 'h264'}, audio ${s.audio?.codec_name || 'none'} → aac 2ch, ${Math.round(s.duration)}s`);
  })();
  s.ready.catch(() => sessions.delete(name));
  await s.ready;
  return s;
}

function playlist(s, query) {
  const lines = ['#EXTM3U', '#EXT-X-PLAYLIST-TYPE:VOD', '#EXT-X-VERSION:3', `#EXT-X-TARGETDURATION:${s.seg + 1}`, '#EXT-X-MEDIA-SEQUENCE:0'];
  for (let i = 0; i < s.segments; i++) {
    const d = i === s.segments - 1 ? Math.max(0.1, s.duration - i * s.seg) : s.seg;
    lines.push(`#EXTINF:${d.toFixed(6)},`, `${i}.ts${query ? `?${query}` : ''}`);
  }
  lines.push('#EXT-X-ENDLIST');
  return lines.join('\n') + '\n';
}

function buildArgs(s, startSeg, tonemap) {
  const start = startSeg * s.seg;
  const a = ['-hide_banner', '-loglevel', 'error', '-nostdin', '-y'];
  const hw = settings.hwaccel;
  if (!s.copyVideo && hw === 'vaapi') a.push('-vaapi_device', settings.vaapiDevice);
  if (/^https?:/i.test(s.src.url)) a.push('-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_on_network_error', '1', '-reconnect_delay_max', '10');
  if (s.src.headers) a.push('-headers', Object.entries(s.src.headers).map(([k, v]) => `${k}: ${v}`).join('\r\n') + '\r\n');
  if (start > 0) a.push('-ss', String(start));
  a.push('-i', s.src.url);
  a.push('-map', `0:${s.video.index}`);
  if (s.audio) a.push('-map', `0:${s.audio.index}`);
  if (s.copyVideo) {
    a.push('-c:v', 'copy');
  } else {
    const maxH = settings.transcodeMaxHeight;
    const filters = [];
    if (tonemap) filters.push('zscale=t=linear:npl=100', 'format=gbrpf32le', 'zscale=p=bt709', 'tonemap=tonemap=hable:desat=0', 'zscale=t=bt709:m=bt709:r=tv');
    if (hw === 'vaapi') {
      filters.push('format=nv12', 'hwupload', `scale_vaapi=w=-2:h='min(ih,${maxH})'`);
      a.push('-vf', filters.join(','), '-c:v', 'h264_vaapi', '-qp', '23');
    } else {
      filters.push(`scale=w=-2:h='min(ih,${maxH})'`, hw === 'qsv' ? 'format=nv12' : 'format=yuv420p');
      a.push('-vf', filters.join(','));
      if (hw === 'nvenc') a.push('-c:v', 'h264_nvenc', '-preset', 'p4', '-cq', '23', '-b:v', '0');
      else if (hw === 'qsv') a.push('-c:v', 'h264_qsv', '-global_quality', '23');
      else a.push('-c:v', 'libx264', '-preset', 'veryfast', '-crf', '22', '-maxrate', '14M', '-bufsize', '28M', '-profile:v', 'high');
    }
    a.push('-force_key_frames', `expr:gte(t,n_forced*${s.seg})`, '-sc_threshold', '0');
  }
  if (s.audio) a.push('-c:a', 'aac', '-ac', '2', '-b:a', '192k');
  if (start > 0) a.push('-output_ts_offset', String(start));
  a.push('-max_muxing_queue_size', '2048', '-f', 'hls', '-hls_time', String(s.seg), '-hls_list_size', '0',
    '-hls_segment_type', 'mpegts', '-start_number', String(startSeg), '-hls_flags', 'temp_file',
    '-hls_segment_filename', path.join(s.dir, '%d.ts'), path.join(s.dir, 'ff.m3u8'));
  return a;
}

function stopProc(s) {
  if (s.proc) {
    try { if (s.paused) s.proc.kill('SIGCONT'); s.proc.kill('SIGKILL'); } catch { /* gone */ }
    s.proc = null; s.paused = false;
  }
}

function startAt(s, startSeg, tonemap = s.tonemap) {
  stopProc(s);
  s.startSeg = startSeg;
  s.exited = false;
  const args = buildArgs(s, startSeg, tonemap);
  log('debug', 'ffmpeg', args.join(' '));
  const p = spawn(boot.ffmpeg, args, { stdio: ['ignore', 'ignore', 'pipe'] });
  let err = '';
  p.stderr.on('data', (d) => { err = (err + d).slice(-2000); });
  const startedAt = Date.now();
  p.on('close', (code) => {
    if (s.proc !== p) return;
    s.proc = null; s.exited = true;
    if (code && tonemap && !fs.existsSync(path.join(s.dir, `${startSeg}.ts`)) && Date.now() - startedAt < 20_000) {
      log('warn', `ffmpeg tone-mapping failed, retrying without it: ${err.trim().split('\n').pop()}`);
      s.tonemap = false;
      startAt(s, startSeg, false);
    } else if (code) {
      log('warn', `ffmpeg exited ${code}: ${err.trim().split('\n').pop()}`);
    }
  });
  s.proc = p;
}

const segPath = (s, n) => path.join(s.dir, `${n}.ts`);

/** Highest contiguous produced segment from startSeg (or startSeg-1). */
function frontier(s) {
  let n = s.startSeg;
  while (fs.existsSync(segPath(s, n))) n++;
  return n - 1;
}

async function segment(s, n) {
  s.lastAccess = Date.now();
  s.lastRequested = n;
  if (s.paused && s.proc) { s.proc.kill('SIGCONT'); s.paused = false; }
  const file = segPath(s, n);
  if (fs.existsSync(file)) return file;
  const front = frontier(s);
  const running = !!s.proc;
  if (!running || n < s.startSeg || n > front + 4) {
    // Clear old segments of the abandoned run so `frontier` stays meaningful.
    startAt(s, n);
  }
  const deadline = Date.now() + 45_000;
  while (Date.now() < deadline) {
    if (fs.existsSync(file)) return file;
    if (s.exited && !s.proc) {
      if (fs.existsSync(file)) return file;
      throw new Error('transcoder stopped');
    }
    await sleep(80);
  }
  throw new Error('segment timed out');
}

// Throttle + cleanup loop.
setInterval(() => {
  const now = Date.now();
  for (const [name, s] of sessions) {
    if (now - s.lastAccess > 90_000) {
      stopProc(s);
      fs.rmSync(s.dir, { recursive: true, force: true });
      sessions.delete(name);
      log('debug', `transcode ${name} cleaned up`);
      continue;
    }
    if (!s.proc) continue;
    const aheadSegs = Math.ceil(settings.transcodeAheadSec / s.seg);
    const farEnough = fs.existsSync(segPath(s, s.lastRequested + aheadSegs));
    if (farEnough && !s.paused) { s.proc.kill('SIGSTOP'); s.paused = true; }
    else if (!farEnough && s.paused) { s.proc.kill('SIGCONT'); s.paused = false; }
  }
}, 2000).unref();

function stopByPlaySession(playSessionId) {
  for (const [name, s] of sessions) {
    if (!playSessionId || name.startsWith(`${playSessionId}.`)) {
      stopProc(s);
      fs.rmSync(s.dir, { recursive: true, force: true });
      sessions.delete(name);
    }
  }
}

function active() {
  return [...sessions.values()].map((s) => ({ name: s.name, copyVideo: s.copyVideo, paused: s.paused, running: !!s.proc, lastRequested: s.lastRequested, segments: s.segments }));
}

module.exports = { available, getSession, playlist, segment, stopByPlaySession, active };
