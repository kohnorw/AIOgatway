'use strict';
// HLS fallback for clients (mostly browsers) that can't direct play a file.
//
// • Full VOD playlist up front so seeking works everywhere.
// • Video is copied when the client can decode it, otherwise re-encoded
//   (capped at TRANSCODE_MAX_HEIGHT, HDR tone-mapped). Audio → stereo AAC.
// • Seeking far ahead restarts ffmpeg at the requested segment.
// • ffmpeg is paused (SIGSTOP) once it is TRANSCODE_AHEAD_SECS ahead of the
//   player, freeing CPU for other viewers (ported idea from Lumen).
const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');
const { settings, boot } = require('./config');
const { log, sleep } = require('./util');

const DIR = path.join(boot.dataDir, 'transcodes');
fs.rmSync(DIR, { recursive: true, force: true });
fs.mkdirSync(DIR, { recursive: true });

let ffmpegOk = null;
function available() {
  if (!settings.transcode) return false;
  if (ffmpegOk === null) {
    try { ffmpegOk = spawnSync(boot.ffmpeg, ['-version'], { timeout: 5000 }).status === 0; } catch { ffmpegOk = false; }
    if (!ffmpegOk) log('warn', `ffmpeg not found at "${boot.ffmpeg}" — browser fallback transcoding disabled`);
  }
  return ffmpegOk;
}

const sessions = new Map(); // name → session

// ── Timeline ───────────────────────────────────────────────────────────
// Every segment must start exactly where the playlist says, or the player's
// clock (and the subtitles that follow it) shifts when playback starts
// mid-file. With video copied, segments can only start on keyframes, so the
// boundaries are the file's own keyframes, read from its index. When video is
// converted, keyframes are forced onto a fixed grid instead.
function planBoundaries(s, info) {
  const seg = s.seg; const dur = s.duration;
  if (s.copyVideo) {
    const kf = (info.keyframes || []).filter((k) => k >= 0 && k < dur);
    const b = [0];
    for (const k of kf) if (k - b[b.length - 1] >= seg - 0.001 && dur - k >= 0.5) b.push(k);
    s.keyframes = kf;
    return b;
  }
  const b = []; for (let t = 0; t < dur - 0.25; t += seg) b.push(+t.toFixed(6));
  return b;
}
const segStart = (s, n) => s.bounds[n];
const segEnd = (s, n) => (n + 1 < s.bounds.length ? s.bounds[n + 1] : s.duration);

/** Margin so a cut/seek aimed at keyframe k can't land on its neighbour. */
function margin(s, k, side) {
  if (!s.copyVideo) return 0.01;
  const kf = s.keyframes;
  const i = kf.findIndex((x) => Math.abs(x - k) < 0.002);
  const gap = side === 'before' ? (i > 0 ? k - kf[i - 1] : 1) : (i >= 0 && i + 1 < kf.length ? kf[i + 1] - k : 1);
  return Math.min(0.05, gap / 3);
}

/**
 * Session for one play of one source. Track info and the keyframe index come
 * from probe.js (cached from when the title was opened, so usually instant).
 * `audioIndex` is the file's audio stream index the viewer chose (or null).
 */
const wouldCopy = (v, vcodecs) => !settings.forceEncode && vcodecs.includes(v.codec) && !(v.codec === 'h264' && v.bitDepth === 10)
  && (v.height || 0) <= Math.max(settings.transcodeMaxHeight, 2160);

/** A pre-rendered session for this stream that matches what Play asks for: take it over. */
async function adoptWarm(name, src, vcodecs, audioIndex, burnIndex) {
  if (burnIndex !== null && burnIndex !== undefined) return null;
  const w = sessions.get(`warm.${src.sid}`);
  if (!w || w.stopped) return null;
  try { await w.ready; } catch { return null; }
  const info = require('./probe').peek(src.sid);
  if (!info || !info.video) return null;
  const audio = require('./probe').pickAudio(info, audioIndex);
  if ((audio ? audio.index : null) !== (w.audio ? w.audio.index : null)) return null;
  if (wouldCopy(info.video, vcodecs) !== w.copyVideo || w.burn) return null;
  sessions.delete(w.name);
  w.name = name; w.warm = false; w.lastAccess = Date.now();
  sessions.set(name, w);
  log('info', `play ${name.slice(0, 8)}…: using the pre-rendered remux (${[...w.done].length} segment(s) ready)`);
  return w;
}

async function getSession(name, src, vcodecs, audioIndex, burnIndex = null) {
  let s = sessions.get(name);
  if (s) { s.lastAccess = Date.now(); return s; }
  const adopted = await adoptWarm(name, src, vcodecs, audioIndex, burnIndex);
  if (adopted) return adopted;
  const seg = Math.max(1, settings.segmentSec);
  s = { name, src, seg, dir: path.join(DIR, name), proc: null, startSeg: 0, lastAccess: Date.now(), lastRequested: 0, paused: false, ready: null, done: new Set() };
  sessions.set(name, s);
  s.ready = (async () => {
    fs.mkdirSync(s.dir, { recursive: true });
    const info = await require('./probe').probe(src);
    if (!info.video) throw new Error('no video track');
    s.duration = info.duration || 2 * 3600;
    s.startTime = info.startTime || 0;
    s.video = info.video;
    s.audio = require('./probe').pickAudio(info, audioIndex);
    const v = info.video;
    s.copyVideo = !settings.forceEncode && vcodecs.includes(v.codec) && !(v.codec === 'h264' && v.bitDepth === 10)
      && (v.height || 0) <= Math.max(settings.transcodeMaxHeight, 2160);
    let why = '';
    // A picture subtitle to burn in: drawing on the video means converting it.
    if (burnIndex !== null && burnIndex !== undefined) {
      s.burn = (info.subs || []).find((x) => x.index === Number(burnIndex)) || null;
      if (s.burn) { s.copyVideo = false; why = ` (burning in subtitle #${s.burn.index})`; }
    }
    if (s.copyVideo && !(info.keyframes && info.keyframes.length >= 2) && settings.exactSync) {
      // Without a keyframe index, copied segments can't be placed exactly;
      // converting the video keeps the timeline (and subtitles) exact.
      s.copyVideo = false; why = ' (no keyframe index, converting for exact timing)';
    }
    s.hdr = v.range === 'HDR';
    s.tonemap = s.hdr && !s.copyVideo;
    s.bounds = planBoundaries(s, info);
    // In-file text subtitles are written out live while the remux reads the
    // file, so players get lines near the playback position within seconds.
    const TEXT = ['subrip', 'srt', 'ass', 'ssa', 'webvtt', 'mov_text', 'text'];
    s.liveSubs = settings.embeddedSubtitles ? (info.subs || []).filter((x) => TEXT.includes(String(x.codec || '').toLowerCase())) : [];
    s.segments = s.bounds.length;
    log('info', `remux ${name.slice(0, 8)}…: ${v.codec} ${v.height || '?'}p → ${s.copyVideo ? `copy on ${s.segments} keyframe-aligned segments` : 'h264'}${why}, audio #${s.audio ? s.audio.index : '-'} ${s.audio ? `${s.audio.codec}/${s.audio.lang || '?'}` : 'none'} → aac 2ch, ${Math.round(s.duration)}s`);
  })();
  s.ready.catch(() => { sessions.delete(name); fs.rmSync(s.dir, { recursive: true, force: true }); });
  await s.ready;
  return s;
}

function playlist(s, query) {
  let max = 1;
  for (let i = 0; i < s.segments; i++) max = Math.max(max, segEnd(s, i) - segStart(s, i));
  const lines = ['#EXTM3U', '#EXT-X-PLAYLIST-TYPE:VOD', '#EXT-X-VERSION:3', `#EXT-X-TARGETDURATION:${Math.ceil(max)}`, '#EXT-X-MEDIA-SEQUENCE:0'];
  for (let i = 0; i < s.segments; i++) {
    const d = Math.max(0.05, segEnd(s, i) - segStart(s, i));
    lines.push(`#EXTINF:${d.toFixed(6)},`, `${i}.ts${query ? `?${query}` : ''}`);
  }
  lines.push('#EXT-X-ENDLIST');
  return lines.join('\n') + '\n';
}

function buildArgs(s, startSeg, tonemap) {
  const start = segStart(s, startSeg);
  const a = ['-hide_banner', '-loglevel', 'error', '-nostdin', '-y'];
  const hw = settings.hwaccel;
  if (!s.copyVideo && hw === 'vaapi') a.push('-vaapi_device', settings.vaapiDevice);
  if (/^https?:/i.test(s.src.url)) a.push('-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_on_network_error', '1', '-reconnect_delay_max', '10');
  if (s.src.headers) a.push('-headers', Object.entries(s.src.headers).map(([k, v]) => `${k}: ${v}`).join('\r\n') + '\r\n');
  // Burning in after a seek: a subtitle picture already on screen started
  // before the seek point, so read a little earlier and trim to the boundary.
  const preroll = s.burn && startSeg > 0 ? Math.min(10, start) : 0;
  if (startSeg > 0) {
    // -ss counts from the file's start time. Copy: land exactly on the boundary
    // keyframe. Convert: decoding is frame-accurate, so aim at the boundary.
    const ss = start - preroll - s.startTime + (s.copyVideo ? margin(s, start, 'after') : 0);
    a.push('-ss', ss.toFixed(6));
  }
  a.push('-i', s.src.url);
  if (s.copyVideo) a.push('-map', `0:${s.video.index}`);
  if (s.audio) a.push('-map', `0:${s.audio.index}`);
  // Keep the file's own timestamps: every run, from the start or after a
  // seek, then puts each moment at the same time.
  a.push('-copyts', '-start_at_zero');
  if (s.copyVideo) {
    a.push('-c:v', 'copy');
  } else {
    const maxH = settings.transcodeMaxHeight;
    const filters = [];
    if (tonemap) filters.push('zscale=t=linear:npl=100', 'format=gbrpf32le', 'zscale=p=bt709', 'tonemap=tonemap=hable:desat=0', 'zscale=t=bt709:m=bt709:r=tv');
    // Video filters, as a graph so a burned-in subtitle can be overlaid first:
    // [video → tone-map] + [subtitle pictures scaled to the video] → overlay → scale → encode.
    const tm = filters.splice(0);
    const tail = hw === 'vaapi'
      ? ['format=nv12', 'hwupload', `scale_vaapi=w=-2:h='min(ih,${maxH})'`]
      : [`scale=w=-2:h='min(ih,${maxH})'`, hw === 'qsv' ? 'format=nv12' : 'format=yuv420p'];
    const graph = s.burn
      ? `[0:${s.video.index}]${tm.length ? tm.join(',') : 'null'}[base];[0:${s.burn.index}][base]scale2ref[sub][base2];[base2][sub]overlay=eof_action=pass${preroll ? `,trim=start=${start.toFixed(6)}` : ''},${tail.join(',')}[vout]`
      : `[0:${s.video.index}]${[...tm, ...tail].join(',')}[vout]`;
    a.push('-filter_complex', graph, '-map', '[vout]');
    if (hw === 'vaapi') {
      a.push('-c:v', 'h264_vaapi', '-qp', '23');
    } else {
      if (hw === 'nvenc') a.push('-c:v', 'h264_nvenc', '-preset', 'p4', '-cq', '23', '-b:v', '0');
      else if (hw === 'qsv') a.push('-c:v', 'h264_qsv', '-global_quality', '23');
      else a.push('-c:v', 'libx264', '-preset', 'veryfast', '-crf', '22', '-maxrate', '14M', '-bufsize', '28M', '-profile:v', 'high');
    }
    // Keyframes exactly on the grid, counted from this run's start.
    a.push('-force_key_frames', `expr:gte(t,${start.toFixed(6)}+n_forced*${s.seg})`, '-sc_threshold', '0');
  }
  if (s.audio) {
    if (preroll) a.push('-af', `atrim=start=${start.toFixed(6)}`);
    a.push('-c:a', 'aac', '-ac', '2', '-b:a', '192k');
  }
  // Cut times are measured from this run's first timestamp; aim just before
  // each boundary keyframe so the cut lands on it and not the next one.
  const cuts = [];
  for (let i = startSeg + 1; i < s.segments; i++) {
    const b = segStart(s, i);
    cuts.push(Math.max(0.001, b - start - margin(s, b, 'before')).toFixed(6));
  }
  a.push('-muxdelay', '0', '-muxpreload', '0', '-max_muxing_queue_size', '2048',
    '-f', 'segment', '-segment_format', 'mpegts',
    ...(cuts.length ? ['-segment_times', cuts.join(',')] : ['-segment_time', String(1e7)]),
    '-segment_start_number', String(startSeg),
    '-segment_list', path.join(s.dir, `list-${startSeg}.csv`), '-segment_list_type', 'csv',
    path.join(s.dir, '%d.ts'));
  for (const t of s.liveSubs || []) {
    a.push('-map', `0:${t.index}`, '-c:s', 'srt', '-flush_packets', '1', '-f', 'srt', path.join(s.dir, `live-${startSeg}-${t.index}.srt`));
  }
  return a;
}

function stopProc(s) {
  if (s.proc) {
    try { if (s.paused) s.proc.kill('SIGCONT'); s.proc.kill('SIGKILL'); } catch { /* gone */ }
    s.proc = null; s.paused = false;
  }
}

function startAt(s, startSeg, tonemap = s.tonemap) {
  stopProc(s);
  s.startSeg = startSeg;
  s.exited = false;
  const args = buildArgs(s, startSeg, tonemap);
  log('debug', 'ffmpeg', args.join(' '));
  const p = spawn(boot.ffmpeg, args, { stdio: ['ignore', 'ignore', 'pipe'] });
  p.on('error', (e) => { log('error', `ffmpeg failed to start: ${e.message}`); if (s.proc === p) { s.proc = null; s.exited = true; } });
  let err = '';
  p.stderr.on('data', (d) => { err = (err + d).slice(-2000); });
  const startedAt = Date.now();
  p.on('close', (code) => {
    if (s.proc !== p) return;
    refreshDone(s);
    s.proc = null; s.exited = true;
    if (code && tonemap && !s.done.has(startSeg) && Date.now() - startedAt < 20_000) {
      log('warn', `ffmpeg tone-mapping failed, retrying without it: ${err.trim().split('\n').pop()}`);
      s.tonemap = false;
      startAt(s, startSeg, false);
    } else if (code) {
      log('warn', `ffmpeg exited ${code}: ${err.trim().split('\n').pop()}`);
    }
  });
  s.proc = p;
}

const segPath = (s, n) => path.join(s.dir, `${n}.ts`);

/** Finished segments, as reported by ffmpeg's segment list (a file on disk may still be being written). */
function refreshDone(s) {
  try {
    for (const f of fs.readdirSync(s.dir)) {
      if (!f.startsWith('list-')) continue;
      for (const line of fs.readFileSync(path.join(s.dir, f), 'utf8').split('\n')) {
        const m = line.match(/^(\d+)\.ts,/);
        if (m) s.done.add(parseInt(m[1], 10));
      }
    }
  } catch { /* dir gone */ }
}

/** Highest contiguous finished segment from startSeg (or startSeg-1). */
function frontier(s) {
  let n = s.startSeg;
  while (s.done.has(n)) n++;
  return n - 1;
}

async function segment(s, n) {
  s.lastAccess = Date.now();
  s.lastRequested = n;
  if (s.paused && s.proc) { s.proc.kill('SIGCONT'); s.paused = false; }
  refreshDone(s);
  if (s.done.has(n)) return segPath(s, n);
  const front = frontier(s);
  const running = !!s.proc;
  if (!running || n < s.startSeg || n > front + 4) startAt(s, n);
  const deadline = Date.now() + 45_000;
  while (Date.now() < deadline) {
    if (s.stopped) { const e = new Error('playback was stopped'); e.status = 410; throw e; }
    refreshDone(s);
    if (s.done.has(n)) return segPath(s, n);
    if (s.exited && !s.proc) {
      refreshDone(s);
      if (s.done.has(n)) return segPath(s, n);
      // The last segment is only listed when ffmpeg finishes cleanly.
      if (n === s.segments - 1 && fs.existsSync(segPath(s, n))) return segPath(s, n);
      throw new Error('transcoder stopped');
    }
    await sleep(80);
  }
  throw new Error('segment timed out');
}

// Throttle + cleanup loop.
setInterval(() => {
  const now = Date.now();
  for (const [name, s] of sessions) {
    if (now - s.lastAccess > (s.warm ? 5 * 60_000 : 90_000)) {
      s.stopped = true;
      stopProc(s);
      fs.rmSync(s.dir, { recursive: true, force: true });
      sessions.delete(name);
      log('debug', `transcode ${name} cleaned up`);
      continue;
    }
    if (!s.proc) continue;
    if (s.warm) {
      // Pre-rendered: stop once the first few seconds are ready, until Play.
      refreshDone(s);
      if (!s.paused && s.done.has(s.warmUntil)) { s.proc.kill('SIGSTOP'); s.paused = true; }
      continue;
    }
    const aheadSegs = Math.ceil(settings.transcodeAheadSec / s.seg);
    refreshDone(s);
    const farEnough = s.done.has(s.lastRequested + aheadSegs);
    if (farEnough && !s.paused) { s.proc.kill('SIGSTOP'); s.paused = true; }
    else if (!farEnough && s.paused) { s.proc.kill('SIGCONT'); s.paused = false; }
  }
}, 2000).unref();

// On shutdown, stop every ffmpeg this server started (a paused one would
// otherwise outlive the server).
function stopAll() { for (const s of sessions.values()) { s.stopped = true; stopProc(s); } }
process.on('exit', stopAll);
for (const sig of ['SIGINT', 'SIGTERM']) process.prependListener(sig, stopAll);

function stopByPlaySession(playSessionId) {
  for (const [name, s] of sessions) {
    if (!playSessionId || name.startsWith(`${playSessionId}.`)) {
      s.stopped = true; // anyone waiting on a segment gets an answer right away
      stopProc(s);
      fs.rmSync(s.dir, { recursive: true, force: true });
      sessions.delete(name);
    }
  }
}

/**
 * Pre-render: start remuxing `src` at `startSec` in the background and stop
 * after about PRERENDER_SECS, so pressing Play finds the first segments ready.
 */
async function prerender(src, vcodecs, startSec = 0) {
  const name = `warm.${src.sid}`;
  const existing = sessions.get(name);
  if (existing) { existing.lastAccess = Date.now(); return existing; }
  const s = await getSession(name, src, vcodecs, null, null);
  s.warm = true;
  let n = 0;
  while (n + 1 < s.segments && segStart(s, n + 1) <= startSec) n++;
  let until = n;
  while (until + 1 < s.segments && segEnd(s, until) - segStart(s, n) < settings.prerenderSec) until++;
  s.warmUntil = until; s.lastRequested = n;
  startAt(s, n);
  log('info', `pre-render ${src.sid.slice(0, 8)}: segments ${n}-${until} from ${Math.round(segStart(s, n))}s`);
  return s;
}

/** Live subtitle files written by remuxes of this stream (any session, any restart point). */
function liveSubtitleFiles(sid, index) {
  const out = [];
  for (const s of sessions.values()) {
    if (!s.src || s.src.sid !== sid) continue;
    try { for (const f of fs.readdirSync(s.dir)) if (f.startsWith('live-') && f.endsWith(`-${index}.srt`)) out.push(path.join(s.dir, f)); } catch { /* gone */ }
  }
  return out;
}

function active() {
  return [...sessions.values()].map((s) => ({ name: s.name, copyVideo: s.copyVideo, paused: s.paused, running: !!s.proc, lastRequested: s.lastRequested, segments: s.segments }));
}

module.exports = { prerender, available, getSession, playlist, segment, stopByPlaySession, active, liveSubtitleFiles };
