'use strict';
const http = require('http');
const crypto = require('crypto');
const dgram = require('dgram');
const os = require('os');
const { settings, boot } = require('./config');
const store = require('./store');
const { log } = require('./util');

// ── Router ─────────────────────────────────────────────────────────────
const routes = [];
/** route('GET', '/items/:id', handler). Paths match case-insensitively. */
function route(method, pattern, handler, opts = {}) {
  const parts = pattern.toLowerCase().split('/').filter(Boolean);
  routes.push({ method, parts, handler, auth: opts.auth !== false, admin: !!opts.admin });
}
function match(method, segs) {
  const lower = segs.map((s) => s.toLowerCase());
  for (const r of routes) {
    if (r.method !== method && !(method === 'HEAD' && r.method === 'GET')) continue;
    if (r.parts.length !== segs.length) {
      // trailing wildcard support: '*' as last part
      if (!(r.parts[r.parts.length - 1] === '*' && segs.length >= r.parts.length - 1)) continue;
    }
    const params = {};
    let ok = true;
    for (let i = 0; i < r.parts.length; i++) {
      const p = r.parts[i];
      if (p === '*') { params.rest = segs.slice(i).join('/'); break; }
      if (p.startsWith(':')) params[p.slice(1)] = decodeURIComponent(segs[i]);
      else if (p !== lower[i]) { ok = false; break; }
    }
    if (ok) return { r, params };
  }
  return null;
}

// ── Response helpers ───────────────────────────────────────────────────
function send(res, status, body, headers = {}) {
  if (res.headersSent) return;
  const isBuf = Buffer.isBuffer(body);
  const payload = body === undefined || body === null ? '' : (isBuf || typeof body === 'string') ? body : JSON.stringify(body);
  const type = isBuf || typeof body === 'string' ? (headers['content-type'] || 'text/plain; charset=utf-8') : 'application/json; charset=utf-8';
  res.writeHead(status, { 'content-type': type, 'content-length': Buffer.byteLength(payload), ...headers });
  res.end(res.req.method === 'HEAD' ? undefined : payload);
}
const json = (res, obj, status = 200) => send(res, status, obj ?? null);
const noContent = (res) => { res.writeHead(204); res.end(); };
const redirect = (res, url, status = 302) => { res.writeHead(status, { location: url, 'cache-control': 'no-store' }); res.end(); };

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }

// ── Auth ───────────────────────────────────────────────────────────────
function parseAuth(req, query) {
  const h = req.headers['authorization'] || req.headers['x-emby-authorization'] || '';
  const a = {};
  for (const m of String(h).matchAll(/(\w+)="([^"]*)"/g)) {
    try { a[m[1].toLowerCase()] = decodeURIComponent(m[2]); } catch { a[m[1].toLowerCase()] = m[2]; }
  }
  return {
    token: a.token || req.headers['x-emby-token'] || req.headers['x-mediabrowser-token'] || query.api_key || query.apikey || null,
    client: a.client || req.headers['x-emby-client'] || '',
    device: a.device || req.headers['x-emby-device-name'] || '',
    deviceId: a.deviceid || req.headers['x-emby-device-id'] || '',
    version: a.version || '',
  };
}

// ── The address devices on the network use to reach this server ────────
// Inside Docker the server only knows its container address, which other
// devices can't reach. Learn the real one from the requests devices make.
const ownAddresses = new Set(['localhost', '127.0.0.1', '::1', ...Object.values(os.networkInterfaces()).flat().filter(Boolean).map((i) => i.address)]);
const isPrivate = (h) => /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(h) || /\.(local|lan|home)$/i.test(h);
function learnAddress(req) {
  if (settings.publicUrl) return;
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
  if (!host) return;
  const name = host.replace(/^\[|\](:\d+)?$/g, '').replace(/:\d+$/, '');
  if (ownAddresses.has(name)) return;
  const proto = (req.headers['x-forwarded-proto'] || 'http').split(',')[0].trim();
  const url = `${proto}://${host}`;
  // A LAN address is best for discovery; otherwise keep any external one.
  if (isPrivate(name) || !store.meta.get('lanAddress')) {
    if (store.meta.get('lanAddress') !== url) log('info', `devices reach this server at ${url} (used for LAN discovery)`);
    store.meta.set('lanAddress', url);
  }
}
function discoveryAddress() {
  if (settings.publicUrl) return settings.publicUrl.replace(/\/+$/, '');
  const learned = store.meta.get('lanAddress');
  if (learned) return learned;
  const ip = Object.values(os.networkInterfaces()).flat().find((i) => i && i.family === 'IPv4' && !i.internal);
  return `http://${ip ? ip.address : '127.0.0.1'}:${boot.port}`;
}

function origin(req) {
  if (settings.publicUrl) return settings.publicUrl.replace(/\/+$/, '');
  const proto = (req.headers['x-forwarded-proto'] || (req.socket.encrypted ? 'https' : 'http')).split(',')[0].trim();
  const host = (req.headers['x-forwarded-host'] || req.headers.host || `localhost:${boot.port}`).split(',')[0].trim();
  return `${proto}://${host}`;
}

/**
 * Jellyfin reads JSON field names case-insensitively, and apps rely on it
 * (Streamyfin sends "mediaSourceId", others "MediaSourceId"). Add the
 * PascalCase spelling for every key, at every depth, without removing any.
 */
function pascalize(v, depth = 0) {
  if (depth > 8 || v === null || typeof v !== 'object') return v;
  if (Array.isArray(v)) return v.map((x) => pascalize(x, depth + 1));
  const out = {};
  for (const [k, val] of Object.entries(v)) {
    const p = pascalize(val, depth + 1);
    out[k] = p;
    const pk = k.charAt(0).toUpperCase() + k.slice(1);
    if (!(pk in v)) out[pk] = p;
  }
  return out;
}

async function readBody(req) {
  if (req.method === 'GET' || req.method === 'HEAD') return {};
  const chunks = []; let size = 0;
  for await (const c of req) { size += c.length; if (size > 2_000_000) throw new HttpError(413, 'body too large'); chunks.push(c); }
  const raw = Buffer.concat(chunks).toString('utf8');
  if (!raw) return {};
  try { return pascalize(JSON.parse(raw)); } catch {
    const params = new URLSearchParams(raw); const o = {}; for (const [k, v] of params) o[k] = v; return o;
  }
}

const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-methods': 'GET, POST, PUT, DELETE, OPTIONS, HEAD',
  'access-control-allow-headers': 'Accept, Accept-Language, Authorization, Cache-Control, Content-Encoding, Content-Language, Content-Length, Content-MD5, Content-Range, Content-Type, Date, Host, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, Origin, OriginToken, Pragma, Range, Slug, Transfer-Encoding, Want-Digest, X-MediaBrowser-Token, X-Emby-Authorization, X-Emby-Token, X-Emby-Client, X-Emby-Device-Id, X-Emby-Device-Name',
  'access-control-expose-headers': 'Content-Length, Content-Range, Accept-Ranges, X-AIOFin-Complete',
};

let staticHandler = null;
function setStatic(fn) { staticHandler = fn; }

async function handle(req, res) {
  const t0 = Date.now();
  for (const [k, v] of Object.entries(CORS)) res.setHeader(k, v);
  learnAddress(req);
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  const u = new URL(req.url, 'http://x');
  let pathname = u.pathname.replace(/\/{2,}/g, '/');
  pathname = pathname.replace(/^\/(emby|jellyfin|mediabrowser)(?=\/)/i, '');
  const rawPath = pathname; // static files care about the trailing slash (/web vs /web/)
  if (pathname.length > 1) pathname = pathname.replace(/\/+$/, '');
  const query = {};
  for (const [k, v] of u.searchParams) query[k.toLowerCase()] = v;

  try {
    if (staticHandler && await staticHandler(req, res, rawPath, query)) return;
    const segs = pathname.split('/').filter(Boolean);
    const m = match(req.method, segs);
    if (!m) {
      log('debug', `404 ${req.method} ${pathname}`);
      return json(res, { error: 'Not found' }, 404);
    }
    const auth = parseAuth(req, query);
    let session = auth.token ? store.tokens.get(auth.token) : null;
    let user = session ? store.users.get(session.userId) : null;
    // Requests that carry only a token (api_key, X-Emby-Token) still belong to
    // the app that signed in with it: fill in its name and device.
    if (session) {
      if (!auth.client && session.client) auth.client = session.client;
      if (!auth.device && session.device) auth.device = session.device;
      if (!auth.deviceId && session.deviceId) auth.deviceId = session.deviceId;
    }
    if (m.r.auth && !user) return json(res, { error: 'Unauthorized' }, 401);
    if (m.r.admin && !(user && user.isAdmin)) return json(res, { error: 'Forbidden' }, 403);
    const body = await readBody(req);
    const ctx = { req, res, query, params: m.params, body, auth, user, session, origin: origin(req), path: pathname };
    const out = await m.r.handler(ctx);
    if (out !== undefined && !res.headersSent) json(res, out);
    else if (!res.headersSent && !res.writableEnded) noContent(res);
  } catch (e) {
    const status = e.status || 500;
    if (status >= 500) log('error', `${req.method} ${pathname}: ${e.stack || e.message}`);
    if (!res.headersSent) json(res, { error: e.message }, status);
    else res.destroy();
  } finally {
    const ms = Date.now() - t0;
    if (ms > 1500) log('debug', `slow ${req.method} ${pathname} ${ms}ms`);
  }
}

// ── WebSocket (/socket): just enough for Jellyfin keep-alives ──────────
function wsFrame(obj) {
  // Every server message carries a MessageId (required by the Android TV SDK).
  const data = Buffer.from(JSON.stringify({ ...obj, MessageId: obj.MessageId || crypto.randomUUID() }));
  const len = data.length;
  const head = len < 126 ? Buffer.from([0x81, len]) : len < 65536 ? Buffer.from([0x81, 126, len >> 8, len & 255]) : null;
  if (!head) return null;
  return Buffer.concat([head, data]);
}
function onUpgrade(req, socket) {
  const u = new URL(req.url, 'http://x');
  if (!/\/socket$/i.test(u.pathname)) return socket.destroy();
  const key = req.headers['sec-websocket-key'];
  if (!key) return socket.destroy();
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`);
  socket.write(wsFrame({ MessageType: 'ForceKeepAlive', Data: 60 }));
  let buf = Buffer.alloc(0);
  socket.on('data', (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 2) {
      const op = buf[0] & 0x0f;
      let len = buf[1] & 0x7f; let off = 2;
      if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
      const masked = buf[1] & 0x80;
      const total = off + (masked ? 4 : 0) + len;
      if (buf.length < total) return;
      let payload = buf.subarray(off + (masked ? 4 : 0), total);
      if (masked) { const mask = buf.subarray(off, off + 4); payload = Buffer.from(payload.map((b, i) => b ^ mask[i % 4])); }
      buf = buf.subarray(total);
      if (op === 0x8) { socket.end(Buffer.from([0x88, 0])); return; }
      if (op === 0x9) { socket.write(Buffer.from([0x8a, 0])); continue; }
      if (op === 0x1) {
        try {
          const msg = JSON.parse(payload.toString('utf8'));
          if (msg.MessageType === 'KeepAlive') socket.write(wsFrame({ MessageType: 'KeepAlive' }));
        } catch { /* ignore */ }
      }
    }
  });
  socket.on('error', () => socket.destroy());
  socket.setTimeout(0);
}

// ── LAN discovery (UDP 7359, "who is JellyfinServer?") ─────────────────
function startDiscovery() {
  if (!boot.discovery) return;
  const sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
  sock.on('message', (msg, rinfo) => {
    if (!/who is jellyfinserver\?/i.test(msg.toString())) return;
    const reply = Buffer.from(JSON.stringify({ Address: discoveryAddress(), Id: store.serverId(), Name: settings.serverName, EndpointAddress: null }));
    sock.send(reply, rinfo.port, rinfo.address);
  });
  sock.on('error', (e) => { log('warn', `discovery disabled: ${e.message}`); try { sock.close(); } catch { /* */ } });
  sock.bind(7359, () => log('info', 'LAN discovery listening on udp/7359'));
}

function listen() {
  const server = http.createServer(handle);
  server.keepAliveTimeout = 65_000;
  server.headersTimeout = 66_000;
  server.requestTimeout = 0; // long-lived media/proxy responses
  server.on('upgrade', onUpgrade);
  server.listen(boot.port, () => log('info', `AIOFin listening on :${boot.port}`));
  startDiscovery();
  return server;
}

module.exports = { discoveryAddress, route, listen, send, json, noContent, redirect, HttpError, setStatic };
