'use strict';
// FUSE-mapped playback files (the mount from AIOGateway).
//
// When someone presses Play or picks a version, the chosen stream is
// registered with the FUSE sidecar (fusefs/aiofuse.py), which creates a local
// read-only file for it at <FUSE_MOUNT>/<sid>.<ext>. The file is backed by the
// debrid link through an in-memory block cache with read-ahead and live link
// repair. Direct play, the HLS remux (ffmpeg), in-file subtitles and fonts
// then all read that one local file: seeking is a cache lookup or a single
// range request, every reader shares the same cached blocks, and a link that
// expires mid-play is replaced without the player noticing.
//
// If FUSE isn't available (no /dev/fuse, no SYS_ADMIN, no python3), every
// caller silently falls back to the link itself, exactly as before.
const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');
const http = require('http');
const { settings, boot } = require('./config');
const { log } = require('./util');

const SCRIPT = path.resolve(__dirname, '..', 'fusefs', 'aiofuse.py');
const files = new Map();    // sid → { path, size, at }
const pending = new Map();  // sid → Promise<path|null>
let proc = null;
let ready = false;
let failures = 0;
let disabledReason = '';

function enabled() { return !!settings.fuse && ready; }

function control(method, p, body, timeout = 15_000) {
  return new Promise((resolve, reject) => {
    const data = body ? Buffer.from(JSON.stringify(body)) : null;
    const req = http.request({ host: '127.0.0.1', port: boot.fuseControlPort, path: p, method, timeout,
      headers: data ? { 'content-type': 'application/json', 'content-length': data.length } : {} }, (res) => {
      let out = '';
      res.on('data', (d) => { out += d; });
      res.on('end', () => {
        let j = {}; try { j = JSON.parse(out || '{}'); } catch { /* ignore */ }
        if (res.statusCode >= 400) reject(new Error(j.error || `HTTP ${res.statusCode}`)); else resolve(j);
      });
    });
    req.on('timeout', () => req.destroy(new Error('fuse control timed out')));
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

// fusepy finds libfuse with ctypes' find_library, which fails in some slim
// images. Point it at the library directly when we can find it.
function pyEnv() {
  const env = { ...process.env };
  if (!env.FUSE_LIBRARY_PATH) {
    const dirs = ['/usr/lib', '/lib', '/usr/lib64', '/lib64'];
    for (const d of dirs) {
      let subs = [d];
      try { subs = subs.concat(fs.readdirSync(d).filter((x) => x.endsWith('-linux-gnu')).map((x) => path.join(d, x))); } catch { continue; }
      const hit = subs.map((x) => path.join(x, 'libfuse.so.2')).find((f) => fs.existsSync(f));
      if (hit) { env.FUSE_LIBRARY_PATH = hit; break; }
    }
  }
  return env;
}

function canRun() {
  if (!fs.existsSync('/dev/fuse')) return 'no /dev/fuse in the container (add devices: /dev/fuse and cap_add: SYS_ADMIN)';
  if (!fs.existsSync(SCRIPT)) return `${SCRIPT} is missing`;
  try {
    const r = spawnSync(boot.python, ['-c', 'import fuse, requests'], { timeout: 20000, cwd: '/', env: pyEnv(), encoding: 'utf8' });
    if (r.error) return `could not run ${boot.python}: ${r.error.message}`;
    if (r.status !== 0) {
      const why = String(r.stderr || '').trim().split('\n').pop() || `exit ${r.status}`;
      return `python3 can't load fusepy + requests (${why})`;
    }
  } catch (e) { return `python3 not found (${e.message})`; }
  return '';
}

/** Start the sidecar (and restart it if it dies). */
function start() {
  if (!settings.fuse || proc) return;
  disabledReason = canRun();
  if (disabledReason) { log('warn', `FUSE playback disabled: ${disabledReason}`); return; }
  ready = false;
  files.clear(); pending.clear();
  const p = spawn(boot.python, ['-u', SCRIPT, '--mount', boot.fuseMount, '--port', String(boot.fuseControlPort)], {
    stdio: ['ignore', 'pipe', 'pipe'], env: pyEnv(),
  });
  proc = p;
  const relay = (d) => { for (const line of String(d).split('\n')) if (line.trim()) log(/ (WARNING|ERROR) /.test(line) ? 'warn' : 'debug', line.trim()); };
  p.stdout.on('data', relay); p.stderr.on('data', relay);
  p.on('error', (e) => log('warn', `FUSE sidecar failed to start: ${e.message}`));
  p.on('close', (code) => {
    if (proc !== p) return;
    proc = null; ready = false; files.clear(); pending.clear();
    failures++;
    const wait = Math.min(60, 2 ** Math.min(failures, 6));
    log('warn', `FUSE sidecar exited (${code}); restarting in ${wait}s — playback uses direct links meanwhile`);
    setTimeout(start, wait * 1000).unref();
  });
  // Wait for the mount and the control API.
  (async () => {
    for (let i = 0; i < 50 && proc === p; i++) {
      await new Promise((r) => setTimeout(r, 200));
      try {
        await control('GET', '/health', null, 1000);
        // The control API comes up just before FUSE finishes mounting.
        if (isMounted()) { ready = true; failures = 0; log('info', `FUSE playback ready at ${boot.fuseMount}`); return; }
      } catch { /* not yet */ }
    }
    if (proc === p && !ready) log('warn', 'FUSE sidecar did not come up; playback uses direct links');
  })();
}

function isMounted() {
  try { return fs.readFileSync('/proc/mounts', 'utf8').split('\n').some((l) => l.split(' ')[1] === boot.fuseMount); } catch { return false; }
}

// Turning the setting on or off on the admin page takes effect at once.
require('./config').onChange((s) => {
  if (s.fuse && !proc) { failures = 0; start(); } else if (!s.fuse && proc) { stop(); ready = false; files.clear(); }
});

function stop() { if (proc) { const p = proc; proc = null; try { p.kill('SIGTERM'); } catch { /* gone */ } } }
process.on('exit', stop);
for (const sig of ['SIGTERM', 'SIGINT']) process.once(sig, () => { stop(); process.exit(0); });

function mappable(src) {
  return src && src.sid && /^https?:/i.test(src.url || '') && src.cached !== false;
}

/**
 * Create (or reuse) the FUSE file for a source. Resolves with its local path,
 * or null to use the link directly. Concurrent calls share one registration.
 */
function prepare(src) {
  if (!enabled() || !mappable(src)) return Promise.resolve(null);
  const have = files.get(src.sid);
  if (have) { have.at = Date.now(); return Promise.resolve(have.path); }
  if (pending.has(src.sid)) return pending.get(src.sid);
  const ext = String(src.container || (src.filename || '').split('.').pop() || 'mkv').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 5) || 'mkv';
  const t0 = Date.now();
  const job = control('PUT', `/files/${src.sid}`, { url: src.url, headers: src.headers || null, size: src.size || null, ext })
    .then((r) => {
      files.set(src.sid, { path: r.path, size: r.size, at: Date.now() });
      if (files.size > 2000) files.delete(files.keys().next().value);
      log('info', `FUSE file for ${src.sid.slice(0, 8)} ready in ${Date.now() - t0}ms (${(r.size / 1e9).toFixed(2)} GB)`);
      return r.path;
    })
    .catch((e) => { log('warn', `FUSE file for ${src.sid.slice(0, 8)} failed (${e.message}); using the link directly`); return null; })
    .finally(() => pending.delete(src.sid));
  pending.set(src.sid, job);
  return job;
}

/** prepare(), but never waits longer than `ms` (the link is used meanwhile). */
function ensure(src, ms = settings.fuseWaitMs) {
  const t = new Promise((r) => setTimeout(() => r(null), Math.max(0, ms)).unref());
  return Promise.race([prepare(src), t]);
}

/** Local path if this source already has a FUSE file, else null. */
function pathFor(src) {
  if (!enabled() || !src) return null;
  const f = files.get(src.sid);
  if (!f) return null;
  f.at = Date.now();
  return f.path;
}

/**
 * What ffmpeg/ffprobe should open: { input, local, args }. `args` are the
 * extra input options (reconnect/headers) a remote link needs; a FUSE file needs none.
 */
function inputFor(src, { reconnect = true } = {}) {
  const local = pathFor(src);
  if (local) return { input: local, local: true, args: [] };
  const args = [];
  if (reconnect && /^https?:/i.test(src.url)) args.push('-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_on_network_error', '1', '-reconnect_delay_max', '10');
  if (src.headers) args.push('-headers', Object.entries(src.headers).map(([k, v]) => `${k}: ${v}`).join('\r\n') + '\r\n');
  return { input: src.url, local: false, args };
}

async function status() {
  const base = { enabled: !!settings.fuse, ready, mount: boot.fuseMount, reason: disabledReason || undefined };
  if (!ready) return base;
  try { return { ...base, ...(await control('GET', '/files', null, 2000)) }; } catch (e) { return { ...base, error: e.message }; }
}

module.exports = { start, stop, prepare, ensure, pathFor, inputFor, enabled, status };
