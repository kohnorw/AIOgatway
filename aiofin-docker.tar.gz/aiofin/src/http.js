'use strict';
// Tiny keep-alive HTTP client. Reusing warm TCP/TLS connections to AIOStreams
// saves a full handshake (often 100-300 ms) on every lookup.
const http = require('http');
const https = require('https');
const zlib = require('zlib');

const agentOpts = { keepAlive: true, keepAliveMsecs: 30_000, maxSockets: 128, maxFreeSockets: 32, scheduling: 'lifo' };
const agents = { 'http:': new http.Agent(agentOpts), 'https:': new https.Agent(agentOpts) };

const UA = 'AIOFin/1.0';

function decode(res, buf) {
  const enc = (res.headers['content-encoding'] || '').toLowerCase();
  try {
    if (enc === 'gzip') return zlib.gunzipSync(buf);
    if (enc === 'br') return zlib.brotliDecompressSync(buf);
    if (enc === 'deflate') return zlib.inflateSync(buf);
  } catch { /* fall through with raw */ }
  return buf;
}

/**
 * request(url, opts) → { status, headers, body: Buffer, url }
 * Follows up to 5 redirects. `timeout` bounds the whole exchange.
 */
function request(url, { method = 'GET', headers = {}, timeout = 15_000, body = null, redirects = 5 } = {}) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(url); } catch (e) { return reject(new Error(`bad url: ${url}`)); }
    const mod = u.protocol === 'https:' ? https : http;
    const req = mod.request(u, {
      method,
      agent: agents[u.protocol],
      headers: { 'user-agent': UA, 'accept-encoding': 'gzip, br', accept: 'application/json, */*', ...headers },
    }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects > 0) {
        res.resume();
        clearTimeout(timer);
        const next = new URL(res.headers.location, u).toString();
        return request(next, { method: res.statusCode === 303 ? 'GET' : method, headers, timeout, body, redirects: redirects - 1 })
          .then(resolve, reject);
      }
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        clearTimeout(timer);
        resolve({ status: res.statusCode, headers: res.headers, body: decode(res, Buffer.concat(chunks)), url });
      });
      res.on('error', (e) => { clearTimeout(timer); reject(e); });
    });
    const timer = setTimeout(() => req.destroy(new Error(`timeout after ${timeout}ms: ${u.host}${u.pathname.slice(0, 60)}`)), timeout);
    req.on('error', (e) => { clearTimeout(timer); reject(e); });
    if (body) req.write(body);
    req.end();
  });
}

async function getJson(url, opts = {}) {
  const res = await request(url, opts);
  if (res.status >= 400) {
    const err = new Error(`HTTP ${res.status} from ${new URL(url).host}`);
    err.status = res.status;
    throw err;
  }
  try { return JSON.parse(res.body.toString('utf8')); } catch (e) {
    throw new Error(`invalid JSON from ${new URL(url).host}`);
  }
}

/**
 * Open a streaming GET (for proxying media/images). Resolves with the
 * upstream IncomingMessage after following redirects. Caller pipes it.
 */
function openStream(url, headers = {}, redirects = 6) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const mod = u.protocol === 'https:' ? https : http;
    const req = mod.request(u, { method: 'GET', agent: agents[u.protocol], headers: { 'user-agent': UA, ...headers } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects > 0) {
        res.resume();
        return openStream(new URL(res.headers.location, u).toString(), headers, redirects - 1).then(resolve, reject);
      }
      resolve(res);
    });
    req.setTimeout(20_000, () => req.destroy(new Error('upstream connect timeout')));
    req.on('error', reject);
    req.end();
  });
}

module.exports = { request, getJson, openStream, agents };
