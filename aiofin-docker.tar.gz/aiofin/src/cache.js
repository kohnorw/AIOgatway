'use strict';
// LRU cache with stale-while-revalidate and single-flight loading.
//
//  fresh  → returned immediately
//  stale  → returned immediately, refreshed in the background
//  miss   → one shared upstream call; concurrent callers await the same promise
const { log } = require('./util');

class SwrCache {
  constructor(name, max = 5000) {
    this.name = name;
    this.max = max;
    this.map = new Map();      // key → { value, freshUntil, staleUntil }
    this.inflight = new Map(); // key → Promise
    this.hits = 0; this.misses = 0; this.staleHits = 0;
  }

  peek(key) {
    const e = this.map.get(key);
    if (!e) return undefined;
    if (Date.now() > e.staleUntil) { this.map.delete(key); return undefined; }
    return e;
  }

  set(key, value, ttlMs, staleMs = 0) {
    const now = Date.now();
    this.map.delete(key);
    this.map.set(key, { value, freshUntil: now + ttlMs, staleUntil: now + ttlMs + staleMs });
    if (this.map.size > this.max) this.map.delete(this.map.keys().next().value);
  }

  delete(key) { this.map.delete(key); }
  clear() { this.map.clear(); }
  isLoading(key) { return this.inflight.has(key); }

  /**
   * get(key, loader, { ttl, stale, ttlFor }) — ttlFor(value) may shorten ttl
   * (e.g. empty stream lists) and returns [ttlMs, staleMs].
   */
  get(key, loader, { ttl, stale = 0, ttlFor, force = false } = {}) {
    const e = force ? undefined : this.peek(key);
    if (e) {
      // touch for LRU
      this.map.delete(key); this.map.set(key, e);
      if (Date.now() <= e.freshUntil) { this.hits++; return Promise.resolve(e.value); }
      this.staleHits++;
      this._load(key, loader, ttl, stale, ttlFor).catch(() => {});
      return Promise.resolve(e.value);
    }
    this.misses++;
    return this._load(key, loader, ttl, stale, ttlFor);
  }

  _load(key, loader, ttl, stale, ttlFor) {
    let p = this.inflight.get(key);
    if (p) return p;
    p = (async () => {
      try {
        const value = await loader();
        const [t, s] = ttlFor ? ttlFor(value) : [ttl, stale];
        if (t > 0) this.set(key, value, t, s);
        return value;
      } catch (err) {
        log('debug', `[cache:${this.name}] load failed for ${key}: ${err.message}`);
        throw err;
      } finally {
        this.inflight.delete(key);
      }
    })();
    this.inflight.set(key, p);
    return p;
  }

  stats() {
    return { name: this.name, size: this.map.size, inflight: this.inflight.size, hits: this.hits, staleHits: this.staleHits, misses: this.misses };
  }
}

module.exports = { SwrCache };
