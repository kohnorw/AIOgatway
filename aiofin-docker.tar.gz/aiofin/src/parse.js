'use strict';
// Pulls technical details out of a release name / AIOStreams description so
// clients get a readable version name and sensible track metadata without
// probing the file (probing would cost seconds per source).

const LANGS = [
  ['eng', 'English', /\b(english|eng)\b|🇬🇧|🇺🇸/i],
  ['fre', 'French', /\b(french|fran[cç]ais|vff|vfq|truefrench)\b|🇫🇷/i],
  ['ger', 'German', /\b(german|deutsch)\b|🇩🇪/i],
  ['spa', 'Spanish', /\b(spanish|espa[nñ]ol|castellano|latino)\b|🇪🇸|🇲🇽/i],
  ['ita', 'Italian', /\b(italian|ita)\b|🇮🇹/i],
  ['por', 'Portuguese', /\b(portuguese|portugu[eê]s|dublado)\b|🇵🇹|🇧🇷/i],
  ['rus', 'Russian', /\b(russian|rus)\b|🇷🇺/i],
  ['jpn', 'Japanese', /\b(japanese|jpn)\b|🇯🇵/i],
  ['kor', 'Korean', /\b(korean|kor)\b|🇰🇷/i],
  ['hin', 'Hindi', /\b(hindi)\b|🇮🇳/i],
  ['dut', 'Dutch', /\b(dutch|nederlands)\b|🇳🇱/i],
  ['pol', 'Polish', /\b(polish|pl)\b|🇵🇱/i],
  ['tur', 'Turkish', /\b(turkish)\b|🇹🇷/i],
  ['ara', 'Arabic', /\b(arabic)\b|🇸🇦/i],
  ['chi', 'Chinese', /\b(chinese|mandarin|cantonese)\b|🇨🇳/i],
];
const LANG_NAMES = Object.fromEntries(LANGS.map(([c, n]) => [c, n]));
const LANG_BY_NAME = Object.fromEntries(LANGS.map(([c, n]) => [n.toLowerCase(), c]));

const SERVICES = [
  [/\b(realdebrid|real-debrid)\b|\[RD[+⚡]?\]|\bRD\b/i, 'Real-Debrid'],
  [/\b(torbox)\b|\[TB[+⚡]?\]|\bTB\b/i, 'TorBox'],
  [/\b(alldebrid)\b|\[AD[+⚡]?\]|\bAD\b/i, 'AllDebrid'],
  [/\b(premiumize)\b|\[PM[+⚡]?\]|\bPM\b/i, 'Premiumize'],
  [/\b(debridlink|debrid-link)\b|\[DL[+⚡]?\]/i, 'Debrid-Link'],
  [/\b(easydebrid)\b|\[ED[+⚡]?\]/i, 'EasyDebrid'],
  [/\b(offcloud)\b|\[OC[+⚡]?\]/i, 'Offcloud'],
  [/\b(putio|put\.io)\b/i, 'put.io'],
  [/\b(easynews)\b/i, 'Easynews'],
  [/\b(stremthru)\b/i, 'StremThru'],
];
const SERVICE_IDS = {
  realdebrid: 'Real-Debrid', torbox: 'TorBox', alldebrid: 'AllDebrid', premiumize: 'Premiumize',
  debridlink: 'Debrid-Link', easydebrid: 'EasyDebrid', offcloud: 'Offcloud', putio: 'put.io',
  easynews: 'Easynews', nzbdav: 'NzbDAV', altmount: 'AltMount', stremthru: 'StremThru', pikpak: 'PikPak', seedr: 'Seedr',
};

function parseSize(text) {
  const m = String(text).match(/(\d+(?:[.,]\d+)?)\s*(TB|GB|MB|GiB|MiB|TiB)\b/i);
  if (!m) return null;
  const n = parseFloat(m[1].replace(',', '.'));
  const unit = m[2].toUpperCase().replace('I', '');
  const mult = unit.startsWith('T') ? 1024 ** 4 : unit.startsWith('G') ? 1024 ** 3 : 1024 ** 2;
  return Math.round(n * mult);
}

function parseRelease(text, hint = {}) {
  const t = String(text || '');
  const info = {};

  // Resolution
  if (/\b(2160p|4k|uhd)\b/i.test(t)) info.height = 2160;
  else if (/\b1440p\b/i.test(t)) info.height = 1440;
  else if (/\b(1080p|1080i|fhd)\b/i.test(t)) info.height = 1080;
  else if (/\b720p\b/i.test(t)) info.height = 720;
  else if (/\b(576p|480p|sd|dvdrip)\b/i.test(t)) info.height = 480;
  if (hint.resolution) { const r = parseInt(String(hint.resolution), 10); if (r) info.height = r === 4 ? 2160 : r; }
  info.width = info.height ? ({ 2160: 3840, 1440: 2560, 1080: 1920, 720: 1280, 480: 854 }[info.height]) : undefined;

  // Video codec
  if (/\b(x265|h\.?265|hevc)\b/i.test(t)) info.vcodec = 'hevc';
  else if (/\bav1\b/i.test(t)) info.vcodec = 'av1';
  else if (/\b(x264|h\.?264|avc)\b/i.test(t)) info.vcodec = 'h264';
  else if (/\bvp9\b/i.test(t)) info.vcodec = 'vp9';
  else if (/\b(xvid|divx)\b/i.test(t)) info.vcodec = 'mpeg4';
  if (/\b(10bit|10-bit|hi10)\b/i.test(t)) info.bitDepth = 10;

  // HDR
  const visual = (hint.visualTags || []).join(' ');
  const vt = `${t} ${visual}`;
  const dv = /\b(dv|dovi|dolby[ .-]?vision)\b/i.test(vt);
  const hdr10p = /\bhdr10(\+|plus)/i.test(vt);
  const hdr = /\bhdr(10)?\b/i.test(vt) || hdr10p;
  const hlg = /\bhlg\b/i.test(vt);
  info.range = dv || hdr || hlg ? 'HDR' : 'SDR';
  info.rangeType = dv ? (hdr ? 'DOVIWithHDR10' : 'DOVI') : hdr10p ? 'HDR10Plus' : hdr ? 'HDR10' : hlg ? 'HLG' : 'SDR';
  info.hdrLabel = dv && hdr ? 'DV HDR' : dv ? 'DV' : hdr10p ? 'HDR10+' : hdr ? 'HDR' : hlg ? 'HLG' : '';

  // Audio
  const at = `${t} ${(hint.audioTags || []).join(' ')}`;
  if (/\batmos\b/i.test(at)) info.atmos = true;
  // Tags are often glued to channel counts ("DDP5.1", "DTS-HD.MA.7.1"), so end on a non-letter, not \b.
  const E = '(?![a-z])';
  const has = (re) => new RegExp(re, 'i').test(at);
  if (has(`\\btrue[ .-]?hd${E}`)) { info.acodec = 'truehd'; info.aLabel = 'TrueHD'; }
  else if (has(`\\bdts[ .-]?(hd[ .-]?)?ma${E}|\\bdts[ .-]?x${E}`)) { info.acodec = 'dts'; info.aLabel = 'DTS-HD MA'; }
  else if (has(`\\bdts${E}`)) { info.acodec = 'dts'; info.aLabel = 'DTS'; }
  else if (has(`\\b(ddp|dd\\+|e-?ac-?3|dolby digital plus)${E}`)) { info.acodec = 'eac3'; info.aLabel = 'DD+'; }
  else if (has(`\\b(dd|ac-?3|dolby digital)${E}`)) { info.acodec = 'ac3'; info.aLabel = 'DD'; }
  else if (has(`\\bflac${E}`)) { info.acodec = 'flac'; info.aLabel = 'FLAC'; }
  else if (has(`\\bopus${E}`)) { info.acodec = 'opus'; info.aLabel = 'Opus'; }
  else if (has(`\\baac${E}`)) { info.acodec = 'aac'; info.aLabel = 'AAC'; }
  const chMatch = at.match(/(?<!\d)([2578])[ .]([01])(?![\d])(?!\s*(?:GB|MB|GiB|MiB|TB))/i);
  const ch = (hint.audioChannels || [])[0] || (chMatch && chMatch[0]);
  if (ch) {
    const m = String(ch).match(/([2578])[ .]([01])/);
    if (m) { info.channels = parseInt(m[1], 10) + parseInt(m[2], 10); info.layout = `${m[1]}.${m[2]}`; }
  }

  // Source quality
  const q = t.match(/\b(remux)\b/i) || t.match(/\b(bluray|blu-ray|bdrip|brrip|web-?dl|webrip|web|hdtv|dvdrip|hdrip|cam|ts|telesync)\b/i);
  if (q) info.quality = q[1].replace(/blu-ray/i, 'BluRay').replace(/web-?dl/i, 'WEB-DL').replace(/^web$/i, 'WEB')
    .replace(/^remux$/i, 'REMUX').replace(/^webrip$/i, 'WEBRip').replace(/^bluray$/i, 'BluRay').replace(/^hdtv$/i, 'HDTV');
  if (hint.quality) info.quality = hint.quality;

  // Languages
  const langs = new Set();
  for (const l of hint.languages || []) { const c = LANG_BY_NAME[String(l).toLowerCase()]; if (c) langs.add(c); }
  if (!langs.size) for (const [code, , re] of LANGS) if (re.test(t)) langs.add(code);
  if (/\bmulti\b/i.test(t)) info.multi = true;
  info.languages = [...langs];

  // Container
  const ext = (t.match(/\.(mkv|mp4|m4v|avi|ts|m2ts|webm|mov|wmv)\b/i) || [])[1];
  if (ext) info.container = ext.toLowerCase();
  if (hint.container) info.container = String(hint.container).toLowerCase();

  // Service / cached
  if (/⚡|\[\+\]|cached/i.test(t)) info.cached = true;
  if (/⏳|uncached|not cached/i.test(t)) info.cached = false;
  for (const [re, name] of SERVICES) if (re.test(t)) { info.service = name; break; }
  if (/\b(usenet|nzb)\b/i.test(t)) info.usenet = true;

  if (!info.size) info.size = parseSize(t) || undefined;
  return info;
}

const resLabel = (h) => (h >= 2160 ? '4K' : h ? `${h}p` : '');

module.exports = { parseRelease, parseSize, resLabel, LANG_NAMES, SERVICE_IDS };
