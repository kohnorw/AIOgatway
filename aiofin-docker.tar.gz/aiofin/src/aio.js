'use strict';
// AIOStreams (Stremio add-on protocol) client.
//
// Speed levers used here:
//  • keep-alive pooled connections (see http.js) + a keep-warm ping
//  • single-flight: N clients asking for the same title share one upstream call
//  • stale-while-revalidate caches for manifest, catalogs, meta and streams
//  • `prefetch()` lets the API layer start resolving streams the moment a
//    title is opened, so pressing Play finds them already cached
const fs = require('fs');
const path = require('path');
const { settings, boot, onChange } = require('./config');
const { getJson, request } = require('./http');
const { SwrCache } = require('./cache');
const { parseRelease, SERVICE_IDS } = require('./parse');
const { log, md5 } = require('./util');

const manifestCache = new SwrCache('manifest', 4);
const catalogCache = new SwrCache('catalog', 3000);
const metaCache = new SwrCache('meta', 8000);
const streamCache = new SwrCache('streams', 4000);
const subsCache = new SwrCache('subtitles', 2000);

// Stremio protocol: ids keep their ':' separators in the path.
const encId = (s) => encodeURIComponent(String(s)).replace(/%3A/gi, ':');

function baseUrl() {
  let u = (settings.aioUrl || '').trim();
  if (!u) return '';
  u = u.replace(/^stremio:\/\//i, 'https://');
  return u.replace(/\/manifest\.json(\?.*)?$/i, '').replace(/\/+$/, '');
}
const configured = () => !!baseUrl();

// ── Manifest ───────────────────────────────────────────────────────────
async function manifest(force = false) {
  const base = baseUrl();
  if (!base) throw new Error('AIOStreams is not configured yet. Add your manifest URL on the admin page.');
  return manifestCache.get(base, () => getJson(`${base}/manifest.json`, { timeout: 15_000 }), { ttl: 10 * 60_000, stale: 24 * 3600_000, force });
}

function supports(m, resource, type, id) {
  for (const r of m.resources || []) {
    const name = typeof r === 'string' ? r : r.name;
    if (name !== resource) continue;
    const types = (typeof r === 'object' && r.types) || m.types || [];
    const prefixes = (typeof r === 'object' && r.idPrefixes) || m.idPrefixes;
    if (type && types.length && !types.includes(type)) continue;
    if (id && prefixes && prefixes.length && !prefixes.some((p) => String(id).startsWith(p))) continue;
    return true;
  }
  return false;
}

// ── Catalog preferences (order / enabled / rename) ─────────────────────
const PREFS_FILE = path.join(boot.dataDir, 'catalogs.json');
let catPrefs = { order: [], disabled: [], names: {} };
try { catPrefs = { ...catPrefs, ...JSON.parse(fs.readFileSync(PREFS_FILE, 'utf8')) }; } catch { /* default */ }
function saveCatPrefs(p) {
  catPrefs = { ...catPrefs, ...p };
  fs.writeFileSync(PREFS_FILE, JSON.stringify(catPrefs, null, 2));
}

const extraList = (c) => (c.extra || (c.extraSupported || []).map((name) => ({ name, isRequired: (c.extraRequired || []).includes(name) })));

/** All catalogs from the manifest, annotated for browsing/search. */
async function catalogs() {
  const m = await manifest();
  const list = (m.catalogs || []).map((c) => {
    const extras = extraList(c);
    const required = extras.filter((e) => e.isRequired).map((e) => e.name);
    const key = `${c.type}/${c.id}`;
    return {
      key, type: c.type, id: c.id,
      name: catPrefs.names[key] || c.name || c.id,
      originalName: c.name || c.id,
      browsable: required.every((r) => r === 'skip'),
      searchable: extras.some((e) => e.name === 'search'),
      enabled: !catPrefs.disabled.includes(key),
    };
  });
  const order = catPrefs.order;
  list.sort((a, b) => {
    const ia = order.indexOf(a.key), ib = order.indexOf(b.key);
    return (ia === -1 ? 1e6 : ia) - (ib === -1 ? 1e6 : ib);
  });
  return list;
}

function catalogUrl(type, id, extra = {}) {
  const parts = Object.entries(extra).filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${k}=${encodeURIComponent(v)}`);
  return `${baseUrl()}/catalog/${type}/${encId(id)}${parts.length ? '/' + parts.join('&') : ''}.json`;
}

async function catalogPage(type, id, skip = 0) {
  const url = catalogUrl(type, id, skip ? { skip } : {});
  const ttl = settings.catalogTtlSec * 1000;
  return catalogCache.get(url, async () => {
    const t0 = Date.now();
    const j = await getJson(url, { timeout: 20_000 });
    log('debug', `catalog ${type}/${id} skip=${skip} → ${(j.metas || []).length} in ${Date.now() - t0}ms`);
    return (j.metas || []).filter((x) => x && x.id);
  }, { ttl, stale: ttl * 24 });
}

/** Return items [start, start+limit) of a catalog, walking Stremio skip-pages as needed. */
async function catalogSlice(type, id, start, limit) {
  const need = start + limit;
  const out = []; const seen = new Set();
  let skip = 0; let done = false;
  for (let page = 0; page < 30 && out.length < need; page++) {
    const metas = await catalogPage(type, id, skip);
    if (!metas.length) { done = true; break; }
    let added = 0;
    for (const m of metas) if (!seen.has(m.id)) { seen.add(m.id); out.push(m); added++; }
    if (!added) { done = true; break; }
    skip += metas.length;
  }
  return { items: out.slice(start, need), more: !done || out.length > need, total: out.length };
}

async function search(query, types) {
  const cats = (await catalogs()).filter((c) => c.searchable && c.enabled && (!types || types.includes(c.type)));
  const results = await Promise.allSettled(cats.map(async (c) => {
    const url = catalogUrl(c.type, c.id, { search: query });
    return catalogCache.get(url, async () => ((await getJson(url, { timeout: 8000 })).metas || []).filter((x) => x && x.id),
      { ttl: 15 * 60_000 }).then((metas) => metas.map((m) => ({ ...m, type: m.type || c.type })));
  }));
  // interleave results across catalogs, dedupe by id
  const lists = results.filter((r) => r.status === 'fulfilled').map((r) => r.value);
  const out = []; const seen = new Set();
  for (let i = 0; lists.some((l) => i < l.length); i++) {
    for (const l of lists) { const m = l[i]; if (m && !seen.has(m.id)) { seen.add(m.id); out.push(m); } }
  }
  return out;
}

// ── Meta ───────────────────────────────────────────────────────────────
async function meta(type, id) {
  const key = `${type}/${id}`;
  const ttl = settings.metaTtlSec * 1000;
  return metaCache.get(key, async () => {
    let m = null;
    try {
      const man = await manifest();
      if (supports(man, 'meta', type, id)) {
        m = (await getJson(`${baseUrl()}/meta/${type}/${encId(id)}.json`, { timeout: 10_000 })).meta || null;
      }
    } catch (e) { log('debug', `aio meta ${key} failed: ${e.message}`); }
    if ((!m || !m.name) && settings.metaFallbackUrl && /^tt\d+/.test(id)) {
      const fbType = type === 'movie' ? 'movie' : 'series';
      const fb = settings.metaFallbackUrl.replace(/\/manifest\.json$/, '').replace(/\/+$/, '');
      try { m = (await getJson(`${fb}/meta/${fbType}/${encId(id)}.json`, { timeout: 10_000 })).meta || m; } catch (e) {
        log('debug', `fallback meta ${key} failed: ${e.message}`);
      }
    }
    if (!m) throw new Error(`no metadata for ${key}`);
    return m;
  }, { ttl, stale: ttl * 14 });
}
const peekMeta = (type, id) => metaCache.peek(`${type}/${id}`)?.value;

// ── Streams ────────────────────────────────────────────────────────────
const sources = new Map(); // sid → source (bounded)
function rememberSource(src) {
  sources.delete(src.sid); sources.set(src.sid, src);
  if (sources.size > 30_000) sources.delete(sources.keys().next().value);
}
const getSource = (sid) => sources.get(String(sid || '').toLowerCase());

const timings = []; // recent lookups for the admin page
function recordTiming(t) { timings.unshift(t); if (timings.length > 60) timings.pop(); }

// AIOStreams running in Docker sometimes hands out links on its internal
// hostname (http://aiostreams:3000/...). If the manifest itself is on a public
// host, rewrite those links to it so clients can reach them (as Remux does).
function rewriteInternal(url) {
  try {
    const u = new URL(url);
    if (u.hostname.includes('.') || u.hostname === 'localhost') return url;
    const b = new URL(baseUrl());
    if (!b.hostname.includes('.') || /^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(b.hostname)) return url;
    return `${b.origin}${u.pathname}${u.search}`;
  } catch { return url; }
}

function normalizeStream(s, idx) {
  const url = rewriteInternal(s.url || '');
  if (!/^https?:\/\//i.test(url)) return null; // P2P/infoHash-only results need a debrid service in AIOStreams
  const hints = s.behaviorHints || {};
  const data = s.streamData || {};
  const pf = s.parsedFile || data.parsedFile || {};
  const filename = hints.filename || data.filename || s.filename || '';
  const text = [s.name, s.title, s.description, filename].filter(Boolean).join('\n');
  const info = parseRelease(text, pf);
  const size = hints.videoSize || data.size || s.size || info.size || undefined;
  let cached = data.service?.cached;
  if (cached === undefined) cached = hints.cached;
  if (cached === undefined) cached = info.cached;
  const service = SERVICE_IDS[String(data.service?.id || '').toLowerCase()] || info.service || null;
  const container = (filename.match(/\.(mkv|mp4|m4v|avi|ts|m2ts|webm|mov)$/i) || [])[1]?.toLowerCase() || info.container || null;
  return {
    sid: md5(url),
    url,
    rank: idx,
    filename,
    size: size ? Number(size) : undefined,
    container,
    info,
    cached: cached === undefined ? null : !!cached,
    service,
    addon: data.addon || s.addon || null,
    indexer: data.indexer || s.indexer || null,
    usenet: data.type === 'usenet' || info.usenet || false,
    headers: hints.proxyHeaders?.request || null,
    notWebReady: !!hints.notWebReady,
    bingeGroup: hints.bingeGroup || null,
    aioName: (s.name || '').replace(/\s+/g, ' ').trim(),
    aioDesc: (s.description || s.title || '').split('\n').map((l) => l.trim()).filter(Boolean),
  };
}

async function fetchStreams(type, id, reason) {
  const base = baseUrl();
  if (!base) throw new Error('AIOStreams is not configured');
  const url = `${base}/stream/${type}/${encId(id)}.json`;
  const t0 = Date.now();
  // AIOStreams returns extra `streamData` (service, cached, indexer…) to this UA.
  const j = await getJson(url, { timeout: Math.max(settings.streamWaitMs, 3000) + 30_000, headers: { 'user-agent': 'AIOStreams/1.0' } });
  const ms = Date.now() - t0;
  const raw = j.streams || [];
  let list = raw.map(normalizeStream).filter(Boolean);
  if (settings.onlyCached) list = list.filter((s) => s.cached !== false);
  for (const s of list) rememberSource(s);
  recordTiming({ at: Date.now(), type, id, ms, count: list.length, raw: raw.length, reason });
  log('info', `streams ${type} ${id}: ${list.length} usable of ${raw.length} in ${ms}ms (${reason})`);
  return list;
}

function streamKey(type, id) { return `${type}/${id}`; }

/** Resolve streams. Cached lists come back instantly. */
function streams(type, id, reason = 'play', { force = false } = {}) {
  const ttl = settings.streamTtlSec * 1000;
  return streamCache.get(streamKey(type, id), () => fetchStreams(type, id, reason), {
    force,
    ttlFor: (list) => (list.length ? [ttl, settings.streamStaleSec * 1000] : [settings.emptyStreamTtlSec * 1000, 0]),
  });
}
function streamState(type, id) {
  const e = streamCache.peek(streamKey(type, id));
  if (e) return Date.now() <= e.freshUntil ? 'fresh' : 'stale';
  return streamCache.isLoading(streamKey(type, id)) ? 'loading' : 'none';
}
/** Fire-and-forget warm-up. */
function prefetch(type, id, reason = 'prefetch') {
  if (!configured()) return;
  const st = streamState(type, id);
  if (st === 'fresh' || st === 'loading') return;
  streams(type, id, reason).catch((e) => log('debug', `prefetch ${type}/${id} failed: ${e.message}`));
  if (settings.subtitles) subtitles(type, id).catch(() => {});
}

// ── Subtitles ──────────────────────────────────────────────────────────
async function subtitles(type, id) {
  return subsCache.get(`${type}/${id}`, async () => {
    const man = await manifest();
    if (!supports(man, 'subtitles', type, id)) return [];
    const j = await getJson(`${baseUrl()}/subtitles/${type}/${encId(id)}.json`, { timeout: 8000 });
    return (j.subtitles || []).filter((s) => s && s.url).slice(0, 40);
  }, { ttl: 6 * 3600_000, stale: 24 * 3600_000 });
}
const peekSubtitles = (type, id) => subsCache.peek(`${type}/${id}`)?.value;

// ── Keep-warm + catalog warm-up ────────────────────────────────────────
let warmTimer = null;
function startKeepWarm() {
  clearInterval(warmTimer);
  warmTimer = setInterval(() => {
    if (!settings.keepWarm || !configured()) return;
    request(`${baseUrl()}/manifest.json`, { timeout: 10_000 }).catch(() => {});
  }, 20_000);
  warmTimer.unref();
}
async function warmCatalogs() {
  if (!settings.warmCatalogs || !configured()) return;
  try {
    const cats = (await catalogs()).filter((c) => c.enabled && c.browsable);
    const t0 = Date.now();
    await Promise.allSettled(cats.map((c) => catalogPage(c.type, c.id, 0)));
    log('info', `warmed ${cats.length} catalogs in ${Date.now() - t0}ms`);
  } catch (e) { log('warn', `catalog warm-up failed: ${e.message}`); }
}

onChange((s, beforeUrl) => {
  if (s.aioUrl !== beforeUrl) {
    for (const c of [manifestCache, catalogCache, metaCache, streamCache, subsCache]) c.clear();
    sources.clear();
    warmCatalogs();
  }
});

function clearCaches() { for (const c of [catalogCache, metaCache, streamCache, subsCache, manifestCache]) c.clear(); }
function stats() { return [manifestCache, catalogCache, metaCache, streamCache, subsCache].map((c) => c.stats()); }

module.exports = {
  baseUrl, configured, manifest, catalogs, catalogSlice, catalogPage, search, meta, peekMeta,
  streams, streamState, prefetch, fetchStreams, getSource, subtitles, peekSubtitles,
  startKeepWarm, warmCatalogs, clearCaches, stats, timings, catPrefs: () => catPrefs, saveCatPrefs, supports,
};
