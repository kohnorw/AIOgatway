'use strict';
// AIOStreams (Stremio add-on protocol) client.
//
// Speed levers used here:
//  • keep-alive pooled connections (see http.js) + a keep-warm ping
//  • single-flight: N clients asking for the same title share one upstream call
//  • stale-while-revalidate caches for manifest, catalogs, meta and streams
//  • `prefetch()` lets the API layer start resolving streams the moment a
//    title is opened, so pressing Play finds them already cached
const fs = require('fs');
const path = require('path');
const { settings, boot, onChange } = require('./config');
const { getJson, request } = require('./http');
const { SwrCache } = require('./cache');
const { parseRelease, SERVICE_IDS } = require('./parse');
const { log, md5 } = require('./util');

const manifestCache = new SwrCache('manifest', 4);
const catalogCache = new SwrCache('catalog', 3000);
const metaCache = new SwrCache('meta', 8000);
const streamCache = new SwrCache('streams', 4000);
const subsCache = new SwrCache('subtitles', 2000);

// Stremio protocol: ids keep their ':' separators in the path.
const encId = (s) => encodeURIComponent(String(s)).replace(/%3A/gi, ':');

function baseUrl() {
  let u = (settings.aioUrl || '').trim();
  if (!u) return '';
  u = u.replace(/^stremio:\/\//i, 'https://');
  return u.replace(/\/manifest\.json(\?.*)?$/i, '').replace(/\/+$/, '');
}
const configured = () => !!baseUrl();

// ── Manifest ───────────────────────────────────────────────────────────
async function manifest(force = false) {
  const base = baseUrl();
  if (!base) throw new Error('AIOStreams is not configured yet. Add your manifest URL on the admin page.');
  return manifestCache.get(base, () => getJson(`${base}/manifest.json`, { timeout: 15_000 }), { ttl: 10 * 60_000, stale: 24 * 3600_000, force });
}

function supports(m, resource, type, id) {
  for (const r of m.resources || []) {
    const name = typeof r === 'string' ? r : r.name;
    if (name !== resource) continue;
    const types = (typeof r === 'object' && r.types) || m.types || [];
    const prefixes = (typeof r === 'object' && r.idPrefixes) || m.idPrefixes;
    if (type && types.length && !types.includes(type)) continue;
    if (id && prefixes && prefixes.length && !prefixes.some((p) => String(id).startsWith(p))) continue;
    return true;
  }
  return false;
}

// ── Catalog preferences (order / enabled / rename) ─────────────────────
const PREFS_FILE = path.join(boot.dataDir, 'catalogs.json');
let catPrefs = { order: [], disabled: [], names: {} };
try { catPrefs = { ...catPrefs, ...JSON.parse(fs.readFileSync(PREFS_FILE, 'utf8')) }; } catch { /* default */ }
function saveCatPrefs(p) {
  catPrefs = { ...catPrefs, ...p };
  fs.writeFileSync(PREFS_FILE, JSON.stringify(catPrefs, null, 2));
}

const extraList = (c) => (c.extra || (c.extraSupported || []).map((name) => ({ name, isRequired: (c.extraRequired || []).includes(name) })));

/** All catalogs from the manifest, annotated for browsing/search. */
async function catalogs() {
  const m = await manifest();
  const list = (m.catalogs || []).map((c) => {
    const extras = extraList(c);
    const required = extras.filter((e) => e.isRequired).map((e) => e.name);
    const key = `${c.type}/${c.id}`;
    return {
      key, type: c.type, id: c.id,
      name: catPrefs.names[key] || c.name || c.id,
      originalName: c.name || c.id,
      browsable: required.every((r) => r === 'skip'),
      searchable: extras.some((e) => e.name === 'search'),
      enabled: !catPrefs.disabled.includes(key),
    };
  });
  const order = catPrefs.order;
  list.sort((a, b) => {
    const ia = order.indexOf(a.key), ib = order.indexOf(b.key);
    return (ia === -1 ? 1e6 : ia) - (ib === -1 ? 1e6 : ib);
  });
  return list;
}

function catalogUrl(type, id, extra = {}) {
  const parts = Object.entries(extra).filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${k}=${encodeURIComponent(v)}`);
  return `${baseUrl()}/catalog/${type}/${encId(id)}${parts.length ? '/' + parts.join('&') : ''}.json`;
}

async function catalogPage(type, id, skip = 0) {
  const url = catalogUrl(type, id, skip ? { skip } : {});
  const ttl = settings.catalogTtlSec * 1000;
  return catalogCache.get(url, async () => {
    const t0 = Date.now();
    const j = await getJson(url, { timeout: 20_000 });
    log('debug', `catalog ${type}/${id} skip=${skip} → ${(j.metas || []).length} in ${Date.now() - t0}ms`);
    return (j.metas || []).filter((x) => x && x.id);
  }, { ttl, stale: ttl * 24 });
}

/** Return items [start, start+limit) of a catalog, walking Stremio skip-pages as needed. */
async function catalogSlice(type, id, start, limit) {
  const need = start + limit;
  const out = []; const seen = new Set();
  let skip = 0; let done = false;
  for (let page = 0; page < 30 && out.length < need; page++) {
    const metas = await catalogPage(type, id, skip);
    if (!metas.length) { done = true; break; }
    let added = 0;
    for (const m of metas) if (!seen.has(m.id)) { seen.add(m.id); out.push(m); added++; }
    if (!added) { done = true; break; }
    skip += metas.length;
  }
  return { items: out.slice(start, need), more: !done || out.length > need, total: out.length };
}

async function search(query, types) {
  const cats = (await catalogs()).filter((c) => c.searchable && c.enabled && (!types || types.includes(c.type)));
  const results = await Promise.allSettled(cats.map(async (c) => {
    const url = catalogUrl(c.type, c.id, { search: query });
    return catalogCache.get(url, async () => ((await getJson(url, { timeout: 8000 })).metas || []).filter((x) => x && x.id),
      { ttl: 15 * 60_000 }).then((metas) => metas.map((m) => ({ ...m, type: m.type || c.type })));
  }));
  // interleave results across catalogs, dedupe by id
  const lists = results.filter((r) => r.status === 'fulfilled').map((r) => r.value);
  const out = []; const seen = new Set();
  for (let i = 0; lists.some((l) => i < l.length); i++) {
    for (const l of lists) { const m = l[i]; if (m && !seen.has(m.id)) { seen.add(m.id); out.push(m); } }
  }
  return out;
}

// ── Meta ───────────────────────────────────────────────────────────────
async function meta(type, id) {
  const key = `${type}/${id}`;
  const ttl = settings.metaTtlSec * 1000;
  return metaCache.get(key, async () => {
    let m = null;
    try {
      const man = await manifest();
      if (supports(man, 'meta', type, id)) {
        m = (await getJson(`${baseUrl()}/meta/${type}/${encId(id)}.json`, { timeout: 10_000 })).meta || null;
      }
    } catch (e) { log('debug', `aio meta ${key} failed: ${e.message}`); }
    if ((!m || !m.name) && settings.metaFallbackUrl && /^tt\d+/.test(id)) {
      const fbType = type === 'movie' ? 'movie' : 'series';
      const fb = settings.metaFallbackUrl.replace(/\/manifest\.json$/, '').replace(/\/+$/, '');
      try { m = (await getJson(`${fb}/meta/${fbType}/${encId(id)}.json`, { timeout: 10_000 })).meta || m; } catch (e) {
        log('debug', `fallback meta ${key} failed: ${e.message}`);
      }
    }
    if (!m) throw new Error(`no metadata for ${key}`);
    return m;
  }, { ttl, stale: ttl * 14 });
}
const peekMeta = (type, id) => metaCache.peek(`${type}/${id}`)?.value;

// ── Streams ────────────────────────────────────────────────────────────
const sources = new Map(); // sid → source (bounded)
function rememberSource(src) {
  sources.delete(src.sid); sources.set(src.sid, src);
  if (sources.size > 30_000) sources.delete(sources.keys().next().value);
}
const getSource = (sid) => sources.get(String(sid || '').toLowerCase());

const timings = []; // recent lookups for the admin page
function recordTiming(t) { timings.unshift(t); if (timings.length > 60) timings.pop(); }

// AIOStreams running in Docker sometimes hands out links on its internal
// hostname (http://aiostreams:3000/...). If the manifest itself is on a public
// host, rewrite those links to it so clients can reach them (as Remux does).
function rewriteInternal(url) {
  try {
    const u = new URL(url);
    if (u.hostname.includes('.') || u.hostname === 'localhost') return url;
    const b = new URL(baseUrl());
    if (!b.hostname.includes('.') || /^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(b.hostname)) return url;
    return `${b.origin}${u.pathname}${u.search}`;
  } catch { return url; }
}

function normalizeStream(s, idx) {
  const url = rewriteInternal(s.url || '');
  if (!/^https?:\/\//i.test(url)) return null; // P2P/infoHash-only results need a debrid service in AIOStreams
  const hints = s.behaviorHints || {};
  const data = s.streamData || {};
  const pf = s.parsedFile || data.parsedFile || {};
  const filename = hints.filename || data.filename || s.filename || '';
  const text = [s.name, s.title, s.description, filename].filter(Boolean).join('\n');
  const info = parseRelease(text, pf);
  const size = hints.videoSize || data.size || s.size || info.size || undefined;
  let cached = data.service?.cached;
  if (cached === undefined) cached = hints.cached;
  if (cached === undefined) cached = info.cached;
  const service = SERVICE_IDS[String(data.service?.id || '').toLowerCase()] || info.service || null;
  const container = (filename.match(/\.(mkv|mp4|m4v|avi|ts|m2ts|webm|mov)$/i) || [])[1]?.toLowerCase() || info.container || null;
  return {
    sid: md5(url),
    url,
    rank: idx,
    filename,
    size: size ? Number(size) : undefined,
    container,
    info,
    cached: cached === undefined ? null : !!cached,
    service,
    addon: data.addon || s.addon || null,
    indexer: data.indexer || s.indexer || null,
    usenet: data.type === 'usenet' || info.usenet || false,
    headers: hints.proxyHeaders?.request || null,
    notWebReady: !!hints.notWebReady,
    bingeGroup: hints.bingeGroup || null,
    aioName: (s.name || '').replace(/\s+/g, ' ').trim(),
    aioDesc: (s.description || s.title || '').split('\n').map((l) => l.trim()).filter(Boolean),
  };
}

async function fetchStreams(type, id, reason) {
  const base = baseUrl();
  if (!base) throw new Error('AIOStreams is not configured');
  const url = `${base}/stream/${type}/${encId(id)}.json`;
  const t0 = Date.now();
  // AIOStreams returns extra `streamData` (service, cached, indexer…) to this UA.
  const j = await getJson(url, { timeout: Math.max(settings.streamWaitMs, 3000) + 30_000, headers: { 'user-agent': 'AIOStreams/1.0' } });
  const ms = Date.now() - t0;
  const raw = j.streams || [];
  let list = raw.map(normalizeStream).filter(Boolean);
  if (settings.onlyCached) list = list.filter((s) => s.cached !== false);
  // Make sure each result is for this title and episode (indexers that search
  // by text can return "Fear the Walking Dead" for "The Walking Dead").
  const sid = String(id).split(':')[0];
  const checked = await require('./match').filter(type, id, list, () => meta(type === 'movie' ? 'movie' : type, sid));
  list = checked.list;
  for (const s of list) rememberSource(s);
  recordTiming({ at: Date.now(), type, id, ms, count: list.length, raw: raw.length, removed: checked.removed.length, reason });
  log('info', `streams ${type} ${id}: ${list.length} usable of ${raw.length}${checked.removed.length ? ` (${checked.removed.length} for a different title/episode)` : ''} in ${ms}ms (${reason})`);
  return list;
}

function streamKey(type, id) { return `${type}/${id}`; }

/** Resolve streams. Cached lists come back instantly. */
function streams(type, id, reason = 'play', { force = false } = {}) {
  const ttl = settings.streamTtlSec * 1000;
  return streamCache.get(streamKey(type, id), () => fetchStreams(type, id, reason), {
    force,
    ttlFor: (list) => (list.length ? [ttl, settings.streamStaleSec * 1000] : [settings.emptyStreamTtlSec * 1000, 0]),
  });
}
function streamState(type, id) {
  const e = streamCache.peek(streamKey(type, id));
  if (e) return Date.now() <= e.freshUntil ? 'fresh' : 'stale';
  return streamCache.isLoading(streamKey(type, id)) ? 'loading' : 'none';
}
/** Fire-and-forget warm-up: streams, then real track info, then subtitles. */
function prefetch(type, id, reason = 'prefetch') {
  if (!configured()) return;
  const st = streamState(type, id);
  if (st === 'loading') return;
  // A fresh list comes straight from cache; probing then starts on it right away.
  streams(type, id, reason)
    .then((list) => {
      const probe = require('./probe');
      probe.warm(list);
      // Once the top stream's file is identified, fetch subtitles made for it.
      const top = list.find((x) => x.cached !== false);
      if (top && settings.subtitles && probe.enabled()) {
        probe.probe(top).then(() => { const ex = subtitleExtras(top); if (ex) subtitles(type, id, ex).catch(() => {}); }).catch(() => {});
      }
    })
    .catch((e) => log('debug', `prefetch ${type}/${id} failed: ${e.message}`));
  if (settings.subtitles) subtitles(type, id).catch(() => {});
}

// ── Subtitles ──────────────────────────────────────────────────────────
// Merged from AIOStreams' own subtitle add-ons and extra Stremio subtitle
// add-ons (OpenSubtitles v3 by default), filtered to the chosen languages.
const SUB_LANG_ALIASES = { eng: ['eng', 'en', 'english'], spa: ['spa', 'es', 'spanish', 'spl', 'spn'], fre: ['fre', 'fra', 'fr', 'french'], ger: ['ger', 'deu', 'de', 'german'], por: ['por', 'pt', 'pob', 'portuguese'], ita: ['ita', 'it', 'italian'], dut: ['dut', 'nld', 'nl', 'dutch'] };
function subLangCode(lang) {
  const l = String(lang || '').toLowerCase().trim();
  for (const [code, aliases] of Object.entries(SUB_LANG_ALIASES)) if (aliases.includes(l)) return code;
  return l.slice(0, 3);
}
const subAddonBases = () => String(settings.subtitleAddons || '').split(',').map((u) => u.trim().replace(/\/manifest\.json$/i, '').replace(/\/+$/, '')).filter(Boolean);

/**
 * `extras` ({ videoHash, videoSize, filename }) identify the exact file being
 * played, as Stremio does: OpenSubtitles then puts subtitles made for that
 * release (same cut, same frame rate) first, so they stay in sync.
 */
function extrasPath(extras) {
  if (!extras) return '';
  const parts = [];
  if (extras.filename) parts.push(`filename=${encodeURIComponent(extras.filename)}`);
  if (extras.videoHash) parts.push(`videoHash=${encodeURIComponent(extras.videoHash)}`);
  if (extras.videoSize) parts.push(`videoSize=${encodeURIComponent(extras.videoSize)}`);
  return parts.length ? `/${parts.join('&')}` : '';
}

// Each subtitle add-on's display name, from its manifest ("OpenSubtitles v3").
const addonNames = new Map();
async function addonLabel(base) {
  if (addonNames.has(base)) return addonNames.get(base);
  let label;
  try {
    const m = await getJson(`${base}/manifest.json`, { timeout: 4000 });
    label = /opensubtitles/i.test(m.name || '') ? 'OpenSubtitles' : (m.name || '').replace(/\s+v?\d+(\.\d+)*$/i, '').trim();
  } catch { /* fall back to the host name */ }
  if (!label) { try { label = /opensubtitles/i.test(base) ? 'OpenSubtitles' : new URL(base).hostname; } catch { label = 'Subtitles'; } }
  addonNames.set(base, label);
  return label;
}

// Compare release names ignoring case, extension and separators.
const releaseStem = (name) => String(name || '').split(/[\\/]/).pop().replace(/\.(srt|vtt|ass|ssa|sub|idx|mkv|mp4|avi|m4v|ts|webm)$/i, '').toLowerCase().replace(/[^a-z0-9]+/g, '');

/** What kind of subtitle this is, from the add-on's flags and its name/file name. */
function subtitleTraits(sub, videoFilename) {
  const hint = [sub.filename, sub.fileName, sub.SubFileName, sub.title, sub.name, sub.label].filter(Boolean).join(' ');
  const file = sub.filename || sub.fileName || sub.SubFileName || '';
  return {
    releaseMatch: !!(file && videoFilename && releaseStem(file) && releaseStem(file) === releaseStem(videoFilename)),
    forced: sub.forced === true || sub.isForced === true || /(^|[^a-z])forced([^a-z]|$)/i.test(hint),
    hi: sub.hearing_impaired === true || sub.hearingImpaired === true || sub.hi === true || sub.sdh === true || /(^|[^a-z])(sdh|hi|cc|hearing[ ._-]?impaired)([^a-z]|$)/i.test(hint),
    ai: sub.ai_translated === true || sub.machine_translated === true || sub.aiTranslated === true || /(^|[^a-z])(ai|machine)[ ._-]?translat/i.test(hint),
  };
}

const kindRank = (x) => (x.forced ? 4 : 0) + (x.ai ? 2 : 0) + (x.hi ? 1 : 0);

async function subtitles(type, id, extras = null) {
  const ex = extrasPath(extras);
  return subsCache.get(`${type}/${id}${ex}`, async () => {
    const jobs = [];
    try {
      const man = await manifest();
      if (supports(man, 'subtitles', type, id)) jobs.push(getJson(`${baseUrl()}/subtitles/${type}/${encId(id)}${ex}.json`, { timeout: 8000 }).then((j) => (j.subtitles || []).map((x) => ({ ...x, source: 'AIOStreams' }))));
    } catch { /* AIOStreams subtitles are optional */ }
    for (const b of subAddonBases()) {
      jobs.push(Promise.all([getJson(`${b}/subtitles/${type}/${encId(id)}${ex}.json`, { timeout: 8000 }), addonLabel(b)])
        .then(([j, label]) => (j.subtitles || []).map((x) => ({ ...x, source: label }))));
    }
    const results = await Promise.allSettled(jobs);
    const want = String(settings.subtitleLanguages || '').split(',').map((x) => subLangCode(x)).filter(Boolean);
    const seen = new Set(); const all = [];
    for (const r of results) {
      if (r.status !== 'fulfilled') continue;
      for (const sub of r.value) {
        if (!sub || !sub.url || seen.has(sub.url)) continue;
        const lang = subLangCode(sub.lang);
        if (want.length && !want.includes(lang)) continue;
        seen.add(sub.url);
        all.push({ ...sub, lang, ...subtitleTraits(sub, extras && extras.filename), order: all.length });
      }
    }
    // Per language (preferred languages first): made for this release first,
    // then regular, SDH, AI-translated, and Forced last (forced tracks only
    // translate foreign-language bits); otherwise keep the add-on's order
    // (OpenSubtitles puts hash matches first).
    all.sort((a, b) => ((want.indexOf(a.lang) + 1 || 99) - (want.indexOf(b.lang) + 1 || 99)) || a.lang.localeCompare(b.lang)
      || (b.releaseMatch - a.releaseMatch) || (kindRank(a) - kindRank(b)) || (a.order - b.order));
    const perLang = new Map(); const out = [];
    for (const sub of all) {
      const n = perLang.get(sub.lang) || 0;
      if (n >= 8) continue; // a handful per language is plenty in a player menu
      perLang.set(sub.lang, n + 1);
      out.push(sub);
    }
    return out.slice(0, 40);
  }, { ttl: 6 * 3600_000, stale: 24 * 3600_000 });
}
const peekSubtitles = (type, id, extras = null) => subsCache.peek(`${type}/${id}${extrasPath(extras)}`)?.value;

/** Identify a stream's file for subtitle add-ons, once its hash is known. */
function subtitleExtras(src) {
  const info = require('./probe').peek(src.sid);
  if (!info || !info.osHash) return null;
  return { videoHash: info.osHash, videoSize: info.size || src.size, filename: src.filename || undefined };
}

// ── Keep-warm + catalog warm-up ────────────────────────────────────────
let warmTimer = null;
function startKeepWarm() {
  clearInterval(warmTimer);
  warmTimer = setInterval(() => {
    if (!settings.keepWarm || !configured()) return;
    request(`${baseUrl()}/manifest.json`, { timeout: 10_000 }).catch(() => {});
  }, 20_000);
  warmTimer.unref();
}
async function warmCatalogs() {
  if (!settings.warmCatalogs || !configured()) return;
  try {
    const cats = (await catalogs()).filter((c) => c.enabled && c.browsable);
    const t0 = Date.now();
    await Promise.allSettled(cats.map((c) => catalogPage(c.type, c.id, 0)));
    log('info', `warmed ${cats.length} catalogs in ${Date.now() - t0}ms`);
  } catch (e) { log('warn', `catalog warm-up failed: ${e.message}`); }
}

onChange((s, beforeUrl) => {
  if (s.aioUrl !== beforeUrl) {
    for (const c of [manifestCache, catalogCache, metaCache, streamCache, subsCache]) c.clear();
    sources.clear();
    warmCatalogs();
  }
});

function clearCaches() { for (const c of [catalogCache, metaCache, streamCache, subsCache, manifestCache]) c.clear(); }
function stats() { return [manifestCache, catalogCache, metaCache, streamCache, subsCache].map((c) => c.stats()); }

module.exports = {
  baseUrl, configured, manifest, catalogs, catalogSlice, catalogPage, search, meta, peekMeta,
  streams, streamState, prefetch, fetchStreams, getSource, subtitles, peekSubtitles, subtitleExtras, subtitleTraits,
  startKeepWarm, warmCatalogs, clearCaches, stats, timings, catPrefs: () => catPrefs, saveCatPrefs, supports,
};
