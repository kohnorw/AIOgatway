'use strict';
// Files attached inside a video (mostly fonts for styled ASS subtitles).
// Attachments sit at the start of an MKV, so ffmpeg only reads the header.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { boot } = require('./config');
const { SwrCache } = require('./cache');

const DIR = path.join(boot.dataDir, 'attachments');
fs.rmSync(DIR, { recursive: true, force: true });
const cache = new SwrCache('attachments', 500);

function dump(src, index, out) {
  return new Promise((resolve, reject) => {
    const a = ['-v', 'error', '-y', '-nostdin'];
    if (src.headers) a.push('-headers', Object.entries(src.headers).map(([k, v]) => `${k}: ${v}`).join('\r\n') + '\r\n');
    a.push(`-dump_attachment:${index}`, out, '-i', src.url, '-t', '0', '-f', 'null', '-');
    const p = spawn(boot.ffmpeg, a, { stdio: ['ignore', 'ignore', 'pipe'] });
    let err = '';
    const timer = setTimeout(() => p.kill('SIGKILL'), 30_000);
    p.stderr.on('data', (d) => { err = (err + d).slice(-400); });
    p.on('error', (e) => { clearTimeout(timer); reject(e); });
    // ffmpeg may exit non-zero after dumping (no real output); the file is what matters.
    p.on('close', () => { clearTimeout(timer); fs.existsSync(out) && fs.statSync(out).size > 0 ? resolve() : reject(new Error(err.trim().split('\n').pop() || 'attachment not found')); });
  });
}

function get(src, att) {
  return cache.get(`${src.sid}:${att.index}`, async () => {
    const dir = path.join(DIR, src.sid);
    fs.mkdirSync(dir, { recursive: true });
    const out = path.join(dir, String(att.index));
    if (!fs.existsSync(out)) await dump(src, att.index, out);
    return fs.readFileSync(out);
  }, { ttl: 7 * 24 * 3600_000 });
}

module.exports = { get };
