'use strict';
// All operator settings live here. Env vars set the defaults; anything saved
// from the admin page (data/settings.json) overrides them at runtime.
const fs = require('fs');
const path = require('path');

const bool = (v) => /^(1|true|yes|on)$/i.test(String(v).trim());

// key: [ENV_NAME, default, type]
const DEFS = {
  aioUrl:            ['AIOSTREAMS_URL', '', 'str'],      // full manifest URL
  serverName:        ['SERVER_NAME', 'AIOFin', 'str'],
  publicUrl:         ['PUBLIC_URL', '', 'str'],          // optional, for discovery replies

  // ── Speed ──────────────────────────────────────────────────────────
  streamWaitMs:      ['STREAM_WAIT_MS', 12000, 'int'],   // hard cap waiting on AIOStreams
  streamTtlSec:      ['STREAM_TTL_SEC', 1200, 'int'],    // fresh stream list
  streamStaleSec:    ['STREAM_STALE_SEC', 21600, 'int'], // served instantly while refreshing
  emptyStreamTtlSec: ['EMPTY_STREAM_TTL_SEC', 60, 'int'],
  prefetchOnOpen:    ['PREFETCH_ON_OPEN', true, 'bool'], // resolve streams when a title is opened
  prewarmEpisodes:   ['PREWARM_EPISODES', 2, 'int'],     // next N episodes during playback
  keepWarm:          ['KEEP_WARM', true, 'bool'],        // keep the TLS connection to AIOStreams hot
  upcomingLibrary:   ['UPCOMING_LIBRARY', true, 'bool'], // "Upcoming" library: next episodes of favourited series
  upcomingDays:      ['UPCOMING_DAYS', 60, 'int'],      // how far ahead to look
  catalogTtlSec:     ['CATALOG_TTL_SEC', 1800, 'int'],
  metaTtlSec:        ['META_TTL_SEC', 43200, 'int'],
  warmCatalogs:      ['WARM_CATALOGS', true, 'bool'],    // pre-load first page of every library

  // ── Streams ────────────────────────────────────────────────────────
  maxSources:        ['MAX_SOURCES', 25, 'int'],
  onlyCached:        ['ONLY_CACHED', false, 'bool'],
  checkMatches:      ['CHECK_MATCHES', true, 'bool'],    // drop results for a different show/episode/year
  sourceNames:       ['SOURCE_NAMES', 'clean', 'str'],  // clean | aiostreams
  streamMode:        ['STREAM_MODE', 'redirect', 'str'], // redirect | proxy
  proxyInternal:     ['PROXY_INTERNAL_HOSTS', true, 'bool'], // proxy links on LAN/Docker hosts clients may not reach
  subtitles:         ['SUBTITLES', true, 'bool'],
  subtitleAddons:    ['SUBTITLE_ADDONS', 'https://opensubtitles-v3.strem.io', 'str'], // comma-separated Stremio subtitle add-ons
  subtitleLanguages: ['SUBTITLE_LANGUAGES', 'eng', 'str'], // 3-letter codes, comma-separated; empty = all
  probe:             ['PROBE', true, 'bool'],             // read real tracks with ffprobe
  probeTop:          ['PROBE_TOP', 3, 'int'],             // results probed when a title is opened
  probeWaitMs:       ['PROBE_WAIT_MS', 4000, 'int'],      // remux clients wait this long for real track info
  metaFallbackUrl:   ['META_FALLBACK_URL', 'https://v3-cinemeta.strem.io', 'str'],
  imageMode:         ['IMAGE_MODE', 'redirect', 'str'],  // redirect | proxy

  // ── Transcoding (browser fallback only) ────────────────────────────
  transcode:         ['TRANSCODE', true, 'bool'],
  remuxDevices:      ['REMUX_DEVICES', 'web,mobile', 'str'], // always remux for: web, mobile, tv, desktop
  hwaccel:           ['HWACCEL', 'none', 'str'],         // none | vaapi | qsv | nvenc
  vaapiDevice:       ['VAAPI_DEVICE', '/dev/dri/renderD128', 'str'],
  transcodeMaxHeight:['TRANSCODE_MAX_HEIGHT', 1080, 'int'],
  transcodeAheadSec: ['TRANSCODE_AHEAD_SECS', 90, 'int'],
  segmentSec:        ['HLS_SEGMENT_SECS', 3, 'int'],
  defaultAudioLang:  ['DEFAULT_AUDIO_LANGUAGE', 'eng', 'str'],
  forceEncode:       ['TRANSCODE_FORCE_ENCODE', false, 'bool'],

  // ── Look ───────────────────────────────────────────────────────────
  customCss:         ['CUSTOM_CSS', null, 'str'],        // null = ElegantFin default
};

const DEFAULT_CSS = [
  '/* Main ElegantFin CSS */',
  '@import url("https://cdn.jsdelivr.net/gh/lscambo13/ElegantFin@main/Theme/ElegantFin-jellyfin-theme-build-latest-minified.css");',
  '/* ElegantFin 12 Companion CSS */',
  '@import url("https://cdn.jsdelivr.net/gh/mihaif7/elegantfin-jf12@main/Theme/ElegantFin-jf12-modern-latest.css");',
].join('\n');

const env = process.env;
const boot = {
  port: parseInt(env.PORT || '8096', 10),
  dataDir: env.DATA_DIR || path.resolve('data'),
  webPath: env.WEB_PATH || '/app/jellyfin-web',
  adminPath: env.ADMIN_PATH || path.resolve(__dirname, '..', 'admin'),
  ffmpeg: env.FFMPEG_PATH || 'ffmpeg',
  ffprobe: env.FFPROBE_PATH || 'ffprobe',
  logLevel: env.LOG_LEVEL || 'info',
  discovery: env.DISCOVERY === undefined ? true : bool(env.DISCOVERY),
  adminUser: env.ADMIN_USERNAME || '',
  adminPassword: env.ADMIN_PASSWORD || '',
};
fs.mkdirSync(boot.dataDir, { recursive: true });

function coerce(type, v) {
  if (v === null || v === undefined) return v;
  if (type === 'int') { const n = parseInt(v, 10); return Number.isFinite(n) ? n : undefined; }
  if (type === 'bool') return typeof v === 'boolean' ? v : bool(v);
  return String(v);
}

const SETTINGS_FILE = path.join(boot.dataDir, 'settings.json');
let saved = {};
try { saved = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')); } catch { /* first run */ }

const settings = {};
function rebuild() {
  for (const [key, [envName, def, type]] of Object.entries(DEFS)) {
    let v = def;
    if (env[envName] !== undefined && env[envName] !== '') v = coerce(type, env[envName]);
    if (saved[key] !== undefined) v = coerce(type, saved[key]);
    settings[key] = v;
  }
  if (settings.customCss === null || settings.customCss === undefined) settings.customCss = DEFAULT_CSS;
}
rebuild();

const listeners = [];
function update(patch) {
  for (const [k, v] of Object.entries(patch || {})) {
    if (!(k in DEFS)) continue;
    saved[k] = coerce(DEFS[k][2], v);
  }
  fs.writeFileSync(SETTINGS_FILE + '.tmp', JSON.stringify(saved, null, 2));
  fs.renameSync(SETTINGS_FILE + '.tmp', SETTINGS_FILE);
  const before = settings.aioUrl;
  rebuild();
  for (const fn of listeners) { try { fn(settings, before); } catch { /* ignore */ } }
}
function onChange(fn) { listeners.push(fn); }

module.exports = { settings, boot, update, onChange, DEFS, DEFAULT_CSS };
