'use strict';
// Small JSON persistence layer. Everything is held in memory and flushed to
// disk with a debounce, so request handlers never wait on I/O.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { boot } = require('./config');
const { md5, randomHex, log } = require('./util');

const DB_FILE = path.join(boot.dataDir, 'db.json');
const IDS_FILE = path.join(boot.dataDir, 'ids.log');

const fixedId = String(process.env.SERVER_ID || '').replace(/-/g, '').toLowerCase();
let db = { serverId: /^[0-9a-f]{32}$/.test(fixedId) ? fixedId : randomHex(16), users: {}, tokens: {}, userData: {}, displayPrefs: {}, meta: {} };
try { db = { ...db, ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) }; } catch { /* fresh */ }
if (/^[0-9a-f]{32}$/.test(fixedId)) db.serverId = fixedId; // SERVER_ID always wins

let flushTimer = null;
function save() {
  if (flushTimer) return;
  flushTimer = setTimeout(flush, 1500);
}
function flush() {
  clearTimeout(flushTimer); flushTimer = null;
  try {
    fs.writeFileSync(DB_FILE + '.tmp', JSON.stringify(db));
    fs.renameSync(DB_FILE + '.tmp', DB_FILE);
  } catch (e) { log('error', 'failed to save db', e.message); }
}
save(); // persist the generated serverId on first boot

// ── Id registry ────────────────────────────────────────────────────────
// Jellyfin clients want 32-hex ids. We hash a semantic key and remember the
// reverse mapping (append-only log) so ids survive restarts.
const idToKey = new Map();
try {
  for (const line of fs.readFileSync(IDS_FILE, 'utf8').split('\n')) {
    const tab = line.indexOf('\t');
    if (tab > 0) idToKey.set(line.slice(0, tab), line.slice(tab + 1));
  }
} catch { /* fresh */ }
let pendingIds = [];
let idTimer = null;
function idFor(key) {
  const id = md5(key);
  if (!idToKey.has(id)) {
    idToKey.set(id, key);
    pendingIds.push(`${id}\t${key}\n`);
    if (!idTimer) idTimer = setTimeout(flushIds, 1000);
  }
  return id;
}
function flushIds() {
  clearTimeout(idTimer); idTimer = null;
  if (!pendingIds.length) return;
  const chunk = pendingIds.join(''); pendingIds = [];
  try { fs.appendFileSync(IDS_FILE, chunk); } catch (e) { log('error', 'failed to append ids', e.message); }
}
const keyFor = (id) => idToKey.get(String(id || '').replace(/-/g, '').toLowerCase());

// ── Users ──────────────────────────────────────────────────────────────
function hashPassword(pw, salt = randomHex(16)) {
  const h = crypto.scryptSync(String(pw), salt, 32).toString('hex');
  return `${salt}:${h}`;
}
function checkPassword(pw, stored) {
  if (!stored) return pw === '' || pw === undefined || pw === null;
  const [salt, h] = stored.split(':');
  const test = crypto.scryptSync(String(pw || ''), salt, 32).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(h, 'hex'), Buffer.from(test, 'hex'));
}

const users = {
  list: () => Object.values(db.users),
  get: (id) => db.users[String(id || '').replace(/-/g, '').toLowerCase()],
  byName: (name) => Object.values(db.users).find((u) => u.name.toLowerCase() === String(name || '').toLowerCase()),
  create(name, password, isAdmin = false) {
    if (users.byName(name)) throw new Error('A user with that name already exists');
    const id = randomHex(16);
    db.users[id] = { id, name: String(name), pw: password ? hashPassword(password) : '', isAdmin: !!isAdmin, created: new Date().toISOString(), config: {} };
    save();
    return db.users[id];
  },
  setPassword(id, password) { const u = users.get(id); if (u) { u.pw = password ? hashPassword(password) : ''; save(); } },
  remove(id) {
    delete db.users[id];
    delete db.userData[id];
    for (const [t, s] of Object.entries(db.tokens)) if (s.userId === id) delete db.tokens[t];
    save();
  },
  update(id, patch) { const u = users.get(id); if (u) { Object.assign(u, patch); save(); } return u; },
  checkPassword,
};

// ── Sessions / tokens ──────────────────────────────────────────────────
const tokens = {
  create(userId, info = {}) {
    const token = randomHex(16);
    db.tokens[token] = { userId, created: Date.now(), lastSeen: Date.now(), ...info };
    save();
    return token;
  },
  get(token) {
    const s = db.tokens[token];
    if (s) s.lastSeen = Date.now();
    return s;
  },
  remove(token) { delete db.tokens[token]; save(); },
};

// ── Per-user item data (progress, played, favourites) ─────────────────
const userData = {
  all(userId) { return db.userData[userId] || (db.userData[userId] = {}); },
  get(userId, itemId) { return (db.userData[userId] || {})[itemId]; },
  upsert(userId, itemId, patch) {
    const all = userData.all(userId);
    const cur = all[itemId] || { pos: 0, played: false, playCount: 0, fav: false };
    all[itemId] = { ...cur, ...patch };
    save();
    return all[itemId];
  },
};

const displayPrefs = {
  get: (userId, id, client) => (db.displayPrefs[`${userId}:${id}:${client}`]),
  set: (userId, id, client, val) => { db.displayPrefs[`${userId}:${id}:${client}`] = val; save(); },
};

process.on('exit', () => { flush(); flushIds(); });
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { flush(); flushIds(); process.exit(0); });

const meta = {
  get: (k) => (db.meta || {})[k],
  set: (k, v) => { if (!db.meta) db.meta = {}; if (db.meta[k] !== v) { db.meta[k] = v; save(); } },
};

module.exports = {
  meta,
  serverId: () => db.serverId,
  idFor, keyFor, users, tokens, userData, displayPrefs, flush,
};
