#!/bin/sh
# Builds the AIOFin image and saves it as a Docker image tarball you can copy
# to another machine and load with:  docker load -i aiofin-image.tar.gz
set -e
cd "$(dirname "$0")"
# DOCKERFILE=docker/Dockerfile.web-source ./build-image.sh  builds Jellyfin Web from source.
docker build -t aiofin:latest -f "${DOCKERFILE:-docker/Dockerfile}" "$@" .
docker save aiofin:latest | gzip > aiofin-image.tar.gz
echo "Saved aiofin-image.tar.gz ($(du -h aiofin-image.tar.gz | cut -f1)). Load it with: docker load -i aiofin-image.tar.gz"
