#!/usr/bin/env python3
"""
fusefs/aiofuse.py — the FUSE mount from AIOGateway, for AIOFin.

AIOFin registers a stream here the moment someone presses Play or picks a
version. That creates a read-only file at

    <mountpoint>/<sid>.<ext>

backed by the debrid/AIOStreams link: no bytes are written to disk. Reads are
served with HTTP range requests through an in-memory LRU block cache, with
read-ahead prefetching, de-duplicated in-flight fetches, rejection of error
pages served as 200, and real-time repair of a link that dies mid-play
(re-resolving the original AIOStreams URL and checking it's the same file).

Registering is quick: one tiny range request learns the real size and the
final CDN address (AIOStreams links redirect), then the first and last blocks
are fetched in the background, so the player's opening reads and the
container index (MKV Cues / MP4 moov, often at the end) are already in memory
by the time it asks.

Control API (127.0.0.1 only):
    PUT    /files/<sid>   {"url", "headers"?, "size"?, "ext"?}  → {"path", "size"}
    DELETE /files/<sid>
    GET    /files          → list + stats
    GET    /health
"""
from __future__ import annotations

import argparse
import errno
import json
import logging
import os
import re
import signal
import stat
import subprocess
import sys
import threading
import time
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Optional

import requests
import urllib3

# fusepy finds libfuse via ctypes.util.find_library("fuse"), which needs the
# unversioned libfuse.so. Point it at the versioned library if that's all there is.
if not os.environ.get("FUSE_LIBRARY_PATH"):
    for _p in ("/usr/lib/x86_64-linux-gnu/libfuse.so.2", "/usr/lib/aarch64-linux-gnu/libfuse.so.2",
               "/lib/x86_64-linux-gnu/libfuse.so.2", "/lib/aarch64-linux-gnu/libfuse.so.2"):
        if os.path.exists(_p):
            os.environ["FUSE_LIBRARY_PATH"] = _p
            break

from fuse import FUSE, FuseOSError, Operations  # noqa: E402

log = logging.getLogger("aiofuse")

# ── Tuning (same knobs as AIOGateway) ─────────────────────────────────────────
_env = os.environ.get
BLOCK_MB          = int(_env("FUSE_BLOCK_MB", "4"))
BLOCK_SIZE        = BLOCK_MB * 1024 * 1024
CACHE_BLOCKS      = int(_env("FUSE_CACHE_BLOCKS", "64"))
PREFETCH_AHEAD    = int(_env("FUSE_PREFETCH_AHEAD", "3"))
READ_TIMEOUT      = int(_env("FUSE_READ_TIMEOUT", "15"))
READ_MAX_ATTEMPTS = max(1, int(_env("FUSE_READ_ATTEMPTS", "3")))
REPAIR_TIMEOUT    = float(_env("FUSE_REPAIR_TIMEOUT", "30"))
MAX_INFLIGHT      = int(_env("FUSE_MAX_INFLIGHT", "8"))
POOL_CONNECTIONS  = int(_env("FUSE_POOL_CONNECTIONS", "10"))
POOL_MAXSIZE      = int(_env("FUSE_POOL_MAXSIZE", "24"))
IDLE_TTL          = float(_env("FUSE_IDLE_TTL_SECONDS", "21600"))   # drop files unused this long
LINK_REFRESH_S    = float(_env("FUSE_LINK_REFRESH_HOURS", "6")) * 3600
ATTR_TIMEOUT      = float(_env("FUSE_ATTR_TIMEOUT", "30"))
READ_BACKOFF_BASE = 0.5
READ_BACKOFF_CAP  = 2.0
USER_AGENT = _env("STREAM_USER_AGENT",
                  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

_OK, _EOF, _DEAD, _FAIL = "ok", "eof", "dead", "fail"


# ── LRU block cache ───────────────────────────────────────────────────────────
class BlockCache:
    def __init__(self, max_blocks: int):
        self._max = max_blocks
        self._lock = threading.Lock()
        self._store: OrderedDict = OrderedDict()

    def get(self, key):
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        return None

    def put(self, key, data: bytes):
        with self._lock:
            self._store[key] = data
            self._store.move_to_end(key)
            while len(self._store) > self._max:
                self._store.popitem(last=False)

    def drop(self, sid: str):
        with self._lock:
            for k in [k for k in self._store if k[0] == sid]:
                del self._store[k]

    def __len__(self):
        return len(self._store)


# Cache keyed by (sid, generation, block): a link swapped for the same file
# keeps its blocks; a different file bumps the generation.
cache = BlockCache(CACHE_BLOCKS)

# ── Shared HTTP session with a pool that actually blocks when full ────────────
http = requests.Session()
http.headers["User-Agent"] = USER_AGENT
_adapter = requests.adapters.HTTPAdapter(pool_connections=POOL_CONNECTIONS, pool_maxsize=POOL_MAXSIZE,
                                         max_retries=0, pool_block=True)
http.mount("https://", _adapter)
http.mount("http://", _adapter)
inflight_sem = threading.Semaphore(MAX_INFLIGHT)
_inflight_lock = threading.Lock()
_inflight: dict = {}           # key -> (Event, [status, data])
_prefetching: set = set()
_prefetch_paused_until = 0.0


def _parse_total(content_range: str) -> Optional[int]:
    if not content_range or "/" not in content_range:
        return None
    total = content_range.rsplit("/", 1)[1].strip()
    return int(total) if total.isdigit() else None


def _looks_like_error(resp, data: bytes, near_eof: bool) -> bool:
    ctype = (resp.headers.get("Content-Type") or "").lower()
    return ("json" in ctype or "text/html" in ctype or "text/plain" in ctype
            or (len(data) < 4096 and not near_eof))


# ── Registered files ──────────────────────────────────────────────────────────
class Entry:
    def __init__(self, sid: str, origin: str, headers: dict, ext: str):
        self.sid = sid
        self.origin = origin          # the AIOStreams link (may redirect)
        self.url = origin             # final CDN address once known
        self.headers = headers or {}
        self.ext = ext
        self.size: Optional[int] = None
        self.gen = 0
        self.created = time.time()
        self.resolved_at = 0.0
        self.last_access = time.time()
        self.open_handles = 0
        self.lock = threading.Lock()
        self.repairing: Optional[threading.Event] = None
        self.bytes_served = 0

    @property
    def name(self):
        return f"{self.sid}.{self.ext}"


def probe_link(url: str, headers: dict) -> tuple[str, Optional[int]]:
    """One 1-byte range request: final address (after redirects) and total size."""
    r = http.get(url, headers={**headers, "Range": "bytes=0-0"}, timeout=READ_TIMEOUT,
                 stream=True, allow_redirects=True)
    try:
        if r.status_code not in (200, 206):
            raise IOError(f"HTTP {r.status_code}")
        ctype = (r.headers.get("Content-Type") or "").lower()
        if "json" in ctype or "text/html" in ctype:
            raise IOError(f"not media ({ctype})")
        size = _parse_total(r.headers.get("Content-Range", ""))
        if size is None and r.status_code == 200:
            cl = r.headers.get("Content-Length")
            size = int(cl) if cl and cl.isdigit() else None
        if r.status_code == 200:
            raise IOError("server ignores Range (can't seek)") if size and size > 1 else IOError("no size")
        return r.url, size
    finally:
        r.close()


class Registry:
    def __init__(self):
        self.lock = threading.Lock()
        self.files: dict[str, Entry] = {}

    def by_path(self, path: str) -> Optional[Entry]:
        name = path.lstrip("/")
        sid = name.split(".", 1)[0]
        e = self.files.get(sid)
        return e if e and e.name == name else None

    def register(self, sid: str, url: str, headers: dict, size: Optional[int], ext: str) -> Entry:
        with self.lock:
            e = self.files.get(sid)
            if e and e.origin == url and e.size:
                e.last_access = time.time()
                return e
            if not e:
                e = Entry(sid, url, headers, ext)
                self.files[sid] = e
            else:
                e.origin, e.url, e.headers = url, url, headers or {}
        with e.lock:
            if not e.size or e.url == e.origin:
                final, real = probe_link(url, e.headers)
                e.url, e.resolved_at = final, time.time()
                e.size = real or size
                if not e.size:
                    raise IOError("size unknown")
        # Warm the opening and the end (container index) in the background.
        warm = [0]
        last = (e.size - 1) // BLOCK_SIZE
        if last > 0:
            warm.append(last)
        if PREFETCH_AHEAD and last > 1:
            warm.append(1)
        for b in warm:
            prefetch(e, b)
        log.info("[%s] ready: %s (%.2f GB)", sid[:8], e.name, e.size / 1e9)
        return e

    def remove(self, sid: str):
        with self.lock:
            e = self.files.pop(sid, None)
        if e:
            cache.drop(sid)

    def sweep(self):
        now = time.time()
        with self.lock:
            stale = [s for s, e in self.files.items() if e.open_handles == 0 and now - e.last_access > IDLE_TTL]
        for s in stale:
            log.info("[%s] idle, removed", s[:8])
            self.remove(s)


reg = Registry()


# ── Fetching ──────────────────────────────────────────────────────────────────
def _fetch_uncached(e: Entry, url: str, gen: int, idx: int) -> tuple[str, Optional[bytes]]:
    start = idx * BLOCK_SIZE
    end = min(start + BLOCK_SIZE, e.size or start + BLOCK_SIZE) - 1
    if not inflight_sem.acquire(timeout=READ_TIMEOUT + 2):
        return _FAIL, None
    try:
        for attempt in range(READ_MAX_ATTEMPTS):
            r = None
            try:
                r = http.get(url, headers={**e.headers, "Range": f"bytes={start}-{end}"},
                             timeout=READ_TIMEOUT, stream=True)
                if r.status_code == 200 and start > 0:
                    log.warning("[%s] block %d: CDN ignored Range", e.sid[:8], idx)
                    return _DEAD, None
                if r.status_code in (200, 206):
                    data = r.raw.read(end - start + 1, decode_content=True) or b""
                    near_eof = bool(e.size and start + len(data) >= e.size - 1)
                    if _looks_like_error(r, data, near_eof):
                        log.warning("[%s] block %d: non-media response (%s, %d bytes)",
                                    e.sid[:8], idx, r.headers.get("Content-Type"), len(data))
                        return _DEAD, None
                    cache.put((e.sid, gen, idx), data)
                    return _OK, data
                if r.status_code == 416:
                    return _EOF, None
                if r.status_code in (401, 403, 404, 410, 451):
                    log.warning("[%s] link rejected (%d) at block %d", e.sid[:8], r.status_code, idx)
                    return _DEAD, None
                log.warning("[%s] HTTP %d for block %d (%d/%d)", e.sid[:8], r.status_code, idx,
                            attempt + 1, READ_MAX_ATTEMPTS)
            except (requests.RequestException, urllib3.exceptions.HTTPError, OSError) as exc:
                if "Too many open files" in str(exc):
                    global _prefetch_paused_until
                    _prefetch_paused_until = time.time() + 5
                    time.sleep(2)
                log.warning("[%s] block %d attempt %d/%d: %s", e.sid[:8], idx, attempt + 1,
                            READ_MAX_ATTEMPTS, exc)
            finally:
                if r is not None:
                    r.close()
            if attempt < READ_MAX_ATTEMPTS - 1:
                time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))
        return _FAIL, None
    finally:
        inflight_sem.release()


def fetch(e: Entry, idx: int) -> tuple[str, Optional[bytes]]:
    """De-duplicated: concurrent readers of one block share a single download."""
    url, gen = e.url, e.gen
    key = (e.sid, gen, idx)
    hit = cache.get(key)
    if hit is not None:
        return _OK, hit
    with _inflight_lock:
        slot = _inflight.get(key)
        owner = slot is None
        if owner:
            slot = (threading.Event(), [_FAIL, None])
            _inflight[key] = slot
    ev, holder = slot
    if not owner:
        ev.wait(READ_TIMEOUT * READ_MAX_ATTEMPTS + 5)
        hit = cache.get(key)
        return (_OK, hit) if hit is not None else (holder[0], holder[1]) if ev.is_set() else (_FAIL, None)
    try:
        holder[0], holder[1] = _fetch_uncached(e, url, gen, idx)
        return holder[0], holder[1]
    finally:
        with _inflight_lock:
            _inflight.pop(key, None)
        ev.set()


def prefetch(e: Entry, idx: int):
    if time.time() < _prefetch_paused_until or (e.size and idx * BLOCK_SIZE >= e.size):
        return
    key = (e.sid, e.gen, idx)
    if cache.get(key) is not None:
        return
    with _inflight_lock:
        if key in _prefetching or key in _inflight:
            return
        _prefetching.add(key)

    def run():
        try:
            status, _ = fetch(e, idx)
            if status in (_DEAD, _FAIL):
                threading.Thread(target=repair, args=(e, e.url), daemon=True).start()
        finally:
            with _inflight_lock:
                _prefetching.discard(key)

    threading.Thread(target=run, daemon=True, name=f"prefetch-{idx}").start()


def repair(e: Entry, failed_url: str) -> str:
    """
    Replace a dead link by re-resolving the original AIOStreams link.
    'same_file' when the new link serves the same bytes (same size) → reads
    carry on seamlessly; 'new_file' when it's a different file; 'failed'.
    """
    with e.lock:
        if e.url != failed_url:
            return "same_file"              # someone else already fixed it
        if e.repairing:
            ev = e.repairing
        else:
            ev = None
            e.repairing = threading.Event()
    if ev:
        ev.wait(REPAIR_TIMEOUT)
        return "same_file" if e.url != failed_url else "failed"
    outcome = "failed"
    try:
        deadline = time.time() + REPAIR_TIMEOUT
        while time.time() < deadline:
            try:
                final, size = probe_link(e.origin, e.headers)
            except Exception as exc:          # noqa: BLE001
                log.warning("[%s] repair attempt failed: %s", e.sid[:8], exc)
                time.sleep(2)
                continue
            if size and e.size and size != e.size:
                log.warning("[%s] link now serves a different file (%d ≠ %d)", e.sid[:8], size, e.size)
                with e.lock:
                    e.url, e.size, e.gen, e.resolved_at = final, size, e.gen + 1, time.time()
                outcome = "new_file"
            else:
                with e.lock:
                    e.url, e.resolved_at = final, time.time()
                outcome = "same_file"
            log.info("[%s] link repaired (%s)", e.sid[:8], outcome)
            break
    finally:
        with e.lock:
            done, e.repairing = e.repairing, None
        done.set()
    return outcome


# ── Filesystem ────────────────────────────────────────────────────────────────
class AIOFinFS(Operations):
    def __init__(self):
        self._t = time.time()
        self._fh_lock = threading.Lock()
        self._fh_next = 1
        self._fh: dict[int, list] = {}    # fh -> [entry, gen_at_first_read or None]

    def getattr(self, path, fh=None):
        base = {"st_uid": os.getuid(), "st_gid": os.getgid(), "st_atime": self._t,
                "st_mtime": self._t, "st_ctime": self._t}
        if path == "/":
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_nlink": 2, "st_size": 0}
        e = reg.by_path(path)
        if not e:
            raise FuseOSError(errno.ENOENT)
        return {**base, "st_mode": stat.S_IFREG | 0o444, "st_nlink": 1, "st_size": e.size or 0,
                "st_mtime": e.created, "st_ctime": e.created}

    def readdir(self, path, fh):
        if path != "/":
            raise FuseOSError(errno.ENOENT)
        return [".", ".."] + [e.name for e in list(reg.files.values())]

    def open(self, path, flags):
        if flags & (os.O_WRONLY | os.O_RDWR):
            raise FuseOSError(errno.EROFS)
        e = reg.by_path(path)
        if not e:
            raise FuseOSError(errno.ENOENT)
        with self._fh_lock:
            fh = self._fh_next
            self._fh_next += 1
            self._fh[fh] = [e, None]
            e.open_handles += 1
        e.last_access = time.time()
        return fh

    def release(self, path, fh):
        with self._fh_lock:
            slot = self._fh.pop(fh, None)
        if slot:
            slot[0].open_handles = max(0, slot[0].open_handles - 1)
            slot[0].last_access = time.time()
        return 0

    def read(self, path, size, offset, fh):
        try:
            return self._read(path, size, offset, fh)
        except FuseOSError:
            raise
        except Exception as exc:              # noqa: BLE001
            log.warning("read(%s): %s", path, exc, exc_info=True)
            raise FuseOSError(errno.EIO)

    def _block(self, e: Entry, idx: int, slot) -> Optional[bytes]:
        for _ in range(3):
            if slot[1] is not None and slot[1] != e.gen:
                raise FuseOSError(errno.EIO)  # file changed under a running playback
            url = e.url
            status, data = fetch(e, idx)
            if status == _OK:
                if slot[1] is None:
                    slot[1] = e.gen
                return data
            if status == _EOF:
                return None
            if e.url != url:
                continue
            outcome = repair(e, url)
            if outcome == "same_file" or (outcome == "new_file" and slot[1] is None):
                continue
            raise FuseOSError(errno.EIO)
        raise FuseOSError(errno.EIO)

    def _read(self, path, size, offset, fh):
        slot = self._fh.get(fh)
        e = slot[0] if slot else reg.by_path(path)
        if not e:
            raise FuseOSError(errno.ENOENT)
        if slot is None:
            slot = [e, None]
        e.last_access = time.time()
        if e.size and offset >= e.size:
            return b""
        if LINK_REFRESH_S and e.resolved_at and time.time() - e.resolved_at > LINK_REFRESH_S and not e.repairing:
            e.resolved_at = time.time()
            threading.Thread(target=repair, args=(e, e.url), daemon=True).start()

        idx = offset // BLOCK_SIZE
        first = self._block(e, idx, slot)
        if first is None:
            return b""
        rel = offset - idx * BLOCK_SIZE
        out = first[rel:rel + size]
        for a in range(1, PREFETCH_AHEAD + 1):
            prefetch(e, idx + a)
        nb = idx + 1
        while len(out) < size and len(first) == BLOCK_SIZE:
            if e.size and nb * BLOCK_SIZE >= e.size:
                break
            first = self._block(e, nb, slot)
            if first is None:
                break
            out += first[:size - len(out)]
            nb += 1
        e.bytes_served += len(out)
        return out

    def write(self, *a): raise FuseOSError(errno.EROFS)
    def create(self, *a): raise FuseOSError(errno.EROFS)
    def mkdir(self, *a): raise FuseOSError(errno.EROFS)
    def rename(self, *a): raise FuseOSError(errno.EROFS)
    def unlink(self, *a): raise FuseOSError(errno.EROFS)
    def rmdir(self, *a): raise FuseOSError(errno.EROFS)
    def truncate(self, *a): raise FuseOSError(errno.EROFS)


# ── Control API ───────────────────────────────────────────────────────────────
SID_RE = re.compile(r"^[a-z0-9]{6,64}$")
EXT_RE = re.compile(r"^[a-z0-9]{2,5}$")


def make_handler(mountpoint: str):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code, obj):
            body = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path == "/health":
                return self._send(200, {"ok": True, "mount": mountpoint})
            if self.path == "/files":
                return self._send(200, {
                    "blockMb": BLOCK_MB, "cachedBlocks": len(cache), "maxBlocks": CACHE_BLOCKS,
                    "files": [{"sid": e.sid, "path": os.path.join(mountpoint, e.name), "size": e.size,
                               "open": e.open_handles, "served": e.bytes_served,
                               "idle": round(time.time() - e.last_access)} for e in list(reg.files.values())],
                })
            self._send(404, {"error": "not found"})

        def do_PUT(self):
            m = re.match(r"^/files/([^/?]+)$", self.path)
            if not m or not SID_RE.match(m.group(1)):
                return self._send(400, {"error": "bad sid"})
            try:
                body = json.loads(self.rfile.read(int(self.headers.get("content-length") or 0)) or b"{}")
                url = body["url"]
                if not re.match(r"^https?://", url):
                    raise ValueError("url must be http(s)")
                ext = str(body.get("ext") or "mkv").lower()
                ext = ext if EXT_RE.match(ext) else "mkv"
                headers = {str(k): str(v) for k, v in (body.get("headers") or {}).items()}
                t0 = time.time()
                e = reg.register(m.group(1), url, headers, body.get("size"), ext)
                self._send(200, {"path": os.path.join(mountpoint, e.name), "size": e.size,
                                 "ms": round((time.time() - t0) * 1000)})
            except Exception as exc:          # noqa: BLE001
                log.warning("register %s failed: %s", m.group(1)[:8], exc)
                self._send(502, {"error": str(exc)})

        def do_DELETE(self):
            m = re.match(r"^/files/([^/?]+)$", self.path)
            if m:
                reg.remove(m.group(1))
            self._send(200, {"ok": True})

    return Handler


def unmount(mountpoint: str):
    for cmd in (["fusermount", "-uz", mountpoint], ["umount", "-l", mountpoint]):
        try:
            if subprocess.run(cmd, capture_output=True, timeout=5).returncode == 0:
                return
        except Exception:                     # noqa: BLE001
            pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mount", default=_env("FUSE_MOUNT", "/mnt/aiofin"))
    ap.add_argument("--port", type=int, default=int(_env("FUSE_CONTROL_PORT", "7878")))
    args = ap.parse_args()
    logging.basicConfig(level=getattr(logging, _env("LOG_LEVEL", "info").upper(), logging.INFO),
                        format="%(asctime)s fuse %(levelname)s %(message)s", stream=sys.stdout)

    unmount(args.mount)                       # stale mount from a crash
    os.makedirs(args.mount, exist_ok=True)

    srv = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(args.mount))
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True, name="control").start()

    def sweeper():
        while True:
            time.sleep(60)
            reg.sweep()
    threading.Thread(target=sweeper, daemon=True, name="sweeper").start()

    def stop(*_):
        unmount(args.mount)
        os._exit(0)
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    log.info("mounting at %s (block %d MB, cache %d blocks, prefetch %d), control on 127.0.0.1:%d",
             args.mount, BLOCK_MB, CACHE_BLOCKS, PREFETCH_AHEAD, args.port)
    FUSE(AIOFinFS(), args.mount, foreground=True, nothreads=False, ro=True, allow_other=True,
         attr_timeout=ATTR_TIMEOUT, entry_timeout=ATTR_TIMEOUT, auto_cache=True, fsname="aiofin")
    unmount(args.mount)


if __name__ == "__main__":
    main()
