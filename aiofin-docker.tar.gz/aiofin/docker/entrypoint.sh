#!/bin/sh
# Clean up a stale FUSE mount left by a previous crash, then start AIOFin
# (same approach as AIOGateway's entrypoint).
MOUNTPOINT="${FUSE_MOUNT:-/mnt/aiofin}"
if grep -qs " $MOUNTPOINT " /proc/mounts; then
    echo "Stale FUSE mount detected at $MOUNTPOINT - unmounting..."
    fusermount -uz "$MOUNTPOINT" 2>/dev/null || umount -l "$MOUNTPOINT" 2>/dev/null || true
    sleep 0.5
fi
mkdir -p "$MOUNTPOINT"
exec "$@"
