'use strict';
const { execSync: execSyncTop } = require('child_process');
// End-to-end test. Expects AIOFin on BASE and the mock AIOStreams running.
//   node test/e2e.js
const BASE = process.env.BASE || 'http://127.0.0.1:8096';
const USER = process.env.TEST_USER || 'admin';
const PASS = process.env.TEST_PASS || 'pw';
// Default identity: a TV box, which direct plays. Web and mobile are tested separately below.
const AUTH = 'MediaBrowser Client="Jellyfin Android TV", Device="SHIELD Android TV", DeviceId="e2e", Version="0.18.0"';
const WEB_AUTH = 'MediaBrowser Client="Jellyfin Web", Device="Chrome", DeviceId="e2e-web", Version="12.1.0"';
const PHONE_AUTH = 'MediaBrowser Client="Jellyfin Android", Device="Pixel 8", DeviceId="e2e-phone", Version="2.6.0"';

let token = '';
let failures = 0;
const results = [];

async function call(method, path, body, extraHeaders = {}) {
  const t0 = performance.now();
  const res = await fetch(BASE + path, {
    method, redirect: 'manual',
    headers: { 'content-type': 'application/json', 'x-emby-authorization': token ? `${AUTH}, Token="${token}"` : AUTH, ...extraHeaders },
    body: body ? JSON.stringify(body) : undefined,
  });
  const ms = performance.now() - t0;
  const text = await res.text();
  let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
  return { status: res.status, json, text, ms, headers: res.headers };
}
function check(name, cond, detail = '') {
  results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? `  (${detail})` : ''}`);
  if (!cond) failures++;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ms = (n) => `${n.toFixed(0)}ms`;

// Chrome-like device profile: no AC3/DTS/TrueHD audio, no HEVC.
const CHROME = {
  DirectPlayProfiles: [
    { Container: 'webm', Type: 'Video', VideoCodec: 'vp8,vp9,av1', AudioCodec: 'vorbis,opus' },
    { Container: 'mp4,m4v', Type: 'Video', VideoCodec: 'h264,vp9,av1', AudioCodec: 'aac,mp3,opus,flac' },
    { Container: 'mkv', Type: 'Video', VideoCodec: 'h264,vp9,av1', AudioCodec: 'aac,mp3,opus,flac' },
  ],
  TranscodingProfiles: [{ Container: 'ts', Type: 'Video', AudioCodec: 'aac', VideoCodec: 'h264', Protocol: 'hls' }],
};

(async () => {
  // ── first-run setup ──
  let r0 = await call('GET', '/admin/api/status');
  if (r0.json.setupNeeded) {
    r0 = await call('POST', '/admin/api/setup', { username: USER, password: PASS, aioUrl: process.env.AIO_URL || 'http://127.0.0.1:7001/stremio/abc/def/manifest.json' });
    check('first-run setup', r0.json.ok === true);
    await sleep(300);
  }
  const subAddon = process.env.SUB_ADDON || 'http://127.0.0.1:7001/os/manifest.json';
  // ── auth ──
  let r = await call('POST', '/Users/AuthenticateByName', { Username: USER, Pw: PASS });
  check('login', r.status === 200 && r.json.AccessToken, `${r.status}`);
  token = r.json.AccessToken;
  const uid = r.json.User.Id;
  await call('POST', '/admin/api/settings', { subtitleAddons: subAddon, subtitleLanguages: 'eng' });
  r = await call('POST', '/Users/AuthenticateByName', { Username: USER, Pw: 'wrong' });
  check('bad password rejected', r.status === 401);
  r = await call('GET', '/System/Info/Public');
  check('public info reports 12.1.0', r.json.Version === '12.1.0');

  // ── libraries ──
  r = await call('GET', `/Users/${uid}/Views`);
  const views = r.json.Items;
  check('Upcoming library first, then one per browsable catalog', views.length === 3 && views[0].Name === 'Upcoming', views.map((v) => `${v.Name}:${v.CollectionType}`).join(', '));
  const upcomingView = views[0];
  const movieView = views.find((v) => v.CollectionType === 'movies');
  const showView = views.find((v) => v.CollectionType === 'tvshows' && v.Id !== upcomingView.Id);

  r = await call('GET', `/Users/${uid}/Items?ParentId=${movieView.Id}&StartIndex=0&Limit=20&IncludeItemTypes=Movie&Recursive=true`);
  check('library page 1', r.json.Items.length === 20 && r.json.TotalRecordCount > 20, `${r.json.Items.length} items, total ${r.json.TotalRecordCount}, ${ms(r.ms)}`);
  r = await call('GET', `/Items?ParentId=${movieView.Id}&StartIndex=20&Limit=20`);
  check('library page 2 walks Stremio skip', r.json.Items[0].Name === 'Test Movie 21', r.json.Items[0].Name);
  r = await call('GET', `/Items?ParentId=${movieView.Id}&StartIndex=40&Limit=20`);
  check('last page ends the listing', r.json.Items.length === 5 && r.json.TotalRecordCount === 45, `${r.json.Items.length} items, total ${r.json.TotalRecordCount}`);
  r = await call('GET', `/Items?ParentId=${movieView.Id}&IncludeItemTypes=BoxSet`);
  check('collections tab is empty, not an error', r.status === 200 && r.json.Items.length === 0);
  r = await call('GET', `/Users/${uid}/Items/Latest?ParentId=${showView.Id}&Limit=5`);
  check('home rows (Latest) is a plain array', Array.isArray(r.json) && r.json.length === 5 && r.json[0].Type === 'Series', ms(r.ms));

  // ── search ──
  r = await call('GET', '/Items?searchTerm=movie%2012&IncludeItemTypes=Movie&Recursive=true&Limit=10');
  check('search', r.json.Items.some((i) => i.Name === 'Test Movie 12'), r.json.Items.map((i) => i.Name).join(', '));
  r = await call('GET', '/Search/Hints?searchTerm=show');
  check('search hints', r.json.SearchHints.length > 0, `${r.json.SearchHints.length} hints`);

  // Jellyfin Web identity (gets the instant placeholder; its page script loads versions).
  const webLogin = await (await fetch(BASE + '/Users/AuthenticateByName', { method: 'POST', headers: { 'content-type': 'application/json', 'x-emby-authorization': WEB_AUTH }, body: JSON.stringify({ Username: USER, Pw: PASS }) })).json();
  const asWeb = async (path) => { const t0 = performance.now(); const res = await fetch(BASE + path, { headers: { 'x-emby-authorization': `${WEB_AUTH}, Token="${webLogin.AccessToken}"` } }); return { status: res.status, json: await res.json(), ms: performance.now() - t0 }; };

  // ── movie: open → prefetch → play ──
  r = await call('GET', `/Items?ParentId=${movieView.Id}&Limit=3`);
  const movie = r.json.Items[2];
  r = await asWeb(`/Users/${uid}/Items/${movie.Id}`);
  check('item detail returns fast (does not wait for streams)', r.status === 200 && r.ms < 300, ms(r.ms));
  check('detail has metadata', r.json.RunTimeTicks > 0 && r.json.People.length > 0 && r.json.ImageTags.Primary && r.json.ProviderIds.Imdb, `runtime ${r.json.RunTimeTicks}`);
  await sleep(3000); // the user reads the overview for a moment (mock AIOStreams takes 1.2s, then tracks are read)
  r = await call('POST', `/Items/${movie.Id}/PlaybackInfo?UserId=${uid}`, { DeviceProfile: null });
  check('PlaybackInfo after opening a title is instant', r.ms < 100, ms(r.ms));
  const sources = r.json.MediaSources;
  check('P2P-only results are dropped', sources.length === 4, `${sources.length} sources`);
  check('clean version names', /4K DV/.test(sources[0].Name) && /TorBox ⚡/.test(sources[0].Name), sources[0].Name);
  check('second version name', /1080p/.test(sources[1].Name), sources[1].Name);
  const vs = sources[0].MediaStreams.find((s) => s.Type === 'Video');
  const as = sources[0].MediaStreams.find((s) => s.Type === 'Audio');
  const ss = sources[0].MediaStreams.find((s) => s.Type === 'Subtitle');
  // The release name claims TrueHD 7.1; the file really has AAC. Players must be told the truth.
  check('video track read from the file', vs.Codec === 'hevc' && vs.Height === 1080, `${vs.DisplayTitle}`);
  check('audio track read from the file, not guessed from the name', as.Codec === 'aac', `${as.DisplayTitle}`);
  const allSubs = sources[0].MediaStreams.filter((x) => x.Type === 'Subtitle');
  check('external subtitles', ss && ss.DeliveryMethod === 'External', ss && ss.DisplayTitle);
  check('OpenSubtitles merged with AIOStreams subtitles', allSubs.some((x) => /OpenSubtitles/.test(x.DisplayTitle) || x.Path.includes('/subs/en.srt?os=')), `${allSubs.length} subtitles`);
  check('only OpenSubtitles and in-file subtitles are listed (no AIOStreams ones)', !allSubs.some((x) => /\(AIOStreams\)/.test(x.DisplayTitle)), allSubs.map((x) => x.DisplayTitle).slice(0, 2).join(' | '));
  check('subtitles limited to chosen language, 8 max', allSubs.length === 8 && allSubs.every((x) => x.Language === 'eng'), allSubs.map((x) => x.Language).join(','));

  // cold lookup for comparison
  r = await call('GET', `/Items?ParentId=${movieView.Id}&StartIndex=10&Limit=1`);
  const cold = r.json.Items[0];
  r = await call('POST', `/Items/${cold.Id}/PlaybackInfo`, {});
  check('cold PlaybackInfo waits only for AIOStreams', r.json.MediaSources.length === 4 && r.ms < 1700, ms(r.ms));

  // LAN/internal source → proxied, with byte ranges for seeking
  r = await call('GET', `/Videos/${movie.Id}/stream.mkv?static=true&MediaSourceId=${sources[1].Id}`, null, { range: 'bytes=0-1023' });
  check('internal-host source is proxied with ranges', r.status === 206 && /^bytes 0-1023\//.test(r.headers.get('content-range')), `${r.status} ${r.headers.get('content-range')}`);
  // native client: direct play via redirect
  await call('POST', '/admin/api/settings', { proxyInternal: false });
  r = await call('GET', `/Videos/${movie.Id}/stream.mkv?static=true&MediaSourceId=${sources[1].Id}&api_key=${token}`);
  check('stream endpoint 302s to the source', r.status === 302 && /sample-h264/.test(r.headers.get('location')), `${r.status} ${ms(r.ms)}`);
  r = await call('GET', `/Videos/${movie.Id}/stream?static=true&MediaSourceId=${movie.Id}`);
  check('stub source id falls back to best stream', r.status === 302, `${r.status}`);

  // browser: direct play h264+aac impossible here (AC3) → HLS fallback
  r = await call('POST', `/Items/${movie.Id}/PlaybackInfo`, { DeviceProfile: CHROME });
  const web = r.json.MediaSources;
  check('browser: unsupported audio gets an HLS fallback', !web[1].SupportsDirectPlay && /main\.m3u8/.test(web[1].TranscodingUrl), web[1].TranscodingUrl);
  r = await call('POST', `/Items/${movie.Id}/PlaybackInfo?MediaSourceId=${sources[1].Id}`, { DeviceProfile: CHROME });
  check('requesting one MediaSourceId returns just that one', r.json.MediaSources.length === 1 && r.json.MediaSources[0].Id === sources[1].Id);

  // subtitles
  // Exactly what Jellyfin Web's player does: swap .vtt for .js and read the JSON.
  const enSub = allSubs.find((x) => x.Path.includes('/subs/en.srt'));
  r = await call('GET', enSub.DeliveryUrl.replace('.vtt', '.js'));
  check('subtitles in the JSON format Jellyfin Web and the iOS app load', r.status === 200 && r.json && r.json.TrackEvents.length === 2
    && r.json.TrackEvents[0].StartPositionTicks === 10_000_000 && r.json.TrackEvents[0].Text === 'Hello there', r.json && JSON.stringify(r.json.TrackEvents[0]));
  r = await call('GET', enSub.DeliveryUrl);
  check('subtitles as WebVTT for other players', r.status === 200 && r.text.startsWith('WEBVTT') && r.text.includes('00:00:01.000 --> 00:00:04.000'), r.text.split('\n')[2]);
  r = await call('GET', enSub.DeliveryUrl.replace('.vtt', '.srt'));
  check('subtitles as SRT', r.status === 200 && r.text.startsWith('1\n00:00:01,000 --> 00:00:04,000'));
  const oldSub = allSubs.find((x) => x.Path.includes('latin1'));
  r = await call('GET', oldSub.DeliveryUrl.replace('.vtt', '.js'));
  check('old Windows-1252 subtitle files show accents correctly', r.json && r.json.TrackEvents[0].Text === 'Café naïve', r.json && r.json.TrackEvents[0].Text);
  r = await call('GET', ss.DeliveryUrl.replace('.vtt', '.js'), null, { 'x-emby-authorization': '' });
  check('subtitle fetch needs no auth header (the player uses plain fetch)', r.status === 200);

  // HLS transcode
  const hlsUrl = web[1].TranscodingUrl;
  let t0 = performance.now();
  r = await call('GET', hlsUrl);
  check('HLS playlist', r.status === 200 && r.text.includes('#EXT-X-ENDLIST') && r.text.includes('0.ts'), `${(r.text.match(/\.ts/g) || []).length} segments, ${ms(r.ms)}`);
  const segBase = hlsUrl.replace(/main\.m3u8.*$/, '');
  r = await call('GET', `${segBase}0.ts`);
  check('first HLS segment', r.status === 200 && r.text.length > 10000, `${r.text.length} bytes, ${ms(performance.now() - t0)} from playlist request`);
  const segCount = (await call('GET', hlsUrl)).text.match(/#EXTINF/g).length;
  t0 = performance.now();
  r = await call('GET', `${segBase}${segCount - 2}.ts`);
  check('seek far ahead restarts the transcoder', r.status === 200 && r.text.length > 10000, `segment ${segCount - 2} of ${segCount}, ${ms(performance.now() - t0)}`);
  r = await call('DELETE', `/Videos/ActiveEncodings?PlaySessionId=${hlsUrl.match(/hls\/([a-f0-9]{32})\./)[1]}`);
  check('stop transcode', r.status === 204);

  // ── series ──
  r = await call('GET', `/Items/Latest?ParentId=${showView.Id}&Limit=1`);
  const show = r.json[0];
  r = await call('GET', `/Users/${uid}/Items/${show.Id}`);
  check('series detail', r.json.Type === 'Series' && r.json.ChildCount === 2, `${r.json.ChildCount} seasons`);
  r = await call('GET', `/Shows/${show.Id}/Seasons?UserId=${uid}`);
  const seasons = r.json.Items;
  check('seasons', seasons.length === 2 && seasons[0].Name === 'Season 1');
  r = await call('GET', `/Shows/${show.Id}/Episodes?SeasonId=${seasons[1].Id}&UserId=${uid}`);
  const eps = r.json.Items;
  check('episodes of season 2', eps.length === 5 && eps[0].ParentIndexNumber === 2 && eps[0].IndexNumber === 1, eps[0].Name);
  r = await call('GET', `/Users/${uid}/Items?ParentId=${seasons[0].Id}`);
  check('Items?ParentId=season lists episodes (Swiftfin style)', r.json.Items.length === 5 && r.json.Items[0].Type === 'Episode');

  // opening the series warmed S1E1
  await sleep(1400);
  r = await call('GET', `/Shows/${show.Id}/Episodes?Season=1`);
  const s1e1 = r.json.Items[0];
  r = await call('POST', `/Items/${s1e1.Id}/PlaybackInfo`, {});
  check('opening a series warms its first episode', r.ms < 100 && r.json.MediaSources.length === 4, ms(r.ms));

  // playback reporting → resume → next episode prewarm
  const runtime = r.json.MediaSources[0].RunTimeTicks;
  await call('POST', '/Sessions/Playing', { ItemId: s1e1.Id, PositionTicks: 0 });
  await call('POST', '/Sessions/Playing/Progress', { ItemId: s1e1.Id, PositionTicks: 6e9 });
  await sleep(1400);
  const s1e2 = (await call('GET', `/Shows/${show.Id}/Episodes?Season=1`)).json.Items[1];
  r = await call('POST', `/Items/${s1e2.Id}/PlaybackInfo`, {});
  check('next episode is prewarmed while watching', r.ms < 100, ms(r.ms));
  await call('POST', '/Sessions/Playing/Stopped', { ItemId: s1e1.Id, PositionTicks: 6e9 });
  r = await call('GET', `/UserItems/Resume?UserId=${uid}`);
  check('continue watching', r.json.Items.length === 1 && r.json.Items[0].UserData.PlaybackPositionTicks === 6e9, r.json.Items[0] && r.json.Items[0].Name);
  r = await call('GET', `/UserItems/Resume?userId=${uid}&Limit=12&MediaTypes=Video`);
  check('Continue Watching row (MediaTypes=Video)', r.json.Items.length === 1);
  r = await call('GET', `/UserItems/Resume?userId=${uid}&Limit=12&MediaTypes=Audio`);
  check('Continue Listening row is empty', r.json.Items.length === 0, `${r.json.Items.length} items`);
  r = await call('GET', `/UserItems/Resume?userId=${uid}&Limit=12&MediaTypes=Book`);
  check('Continue Reading row is empty', r.json.Items.length === 0, `${r.json.Items.length} items`);
  r = await call('GET', `/Items?Filters=IsResumable&Recursive=true&MediaTypes=Audio`);
  check('resumable audio via /Items is empty', r.json.Items.length === 0);
  r = await call('GET', `/Items/Latest?ParentId=${movieView.Id}&MediaTypes=Audio`);
  check('latest audio is empty', Array.isArray(r.json) && r.json.length === 0);
  await call('POST', '/Sessions/Playing/Stopped', { ItemId: s1e1.Id, PositionTicks: Math.round(runtime * 0.95) });
  r = await call('GET', `/Shows/NextUp?UserId=${uid}`);
  check('Next up is turned off', r.json.Items.length === 0, `${r.json.Items.length} items`);
  r = await call('GET', `/Shows/NextUp?SeriesId=${show.Id}`);
  check('Next up on a series page is empty too', r.json.Items.length === 0);
  r = await call('GET', `/UserItems/Resume?UserId=${uid}`);
  check('finished episode leaves continue watching', r.json.Items.length === 0);

  // favourites / played
  r = await call('POST', `/UserFavoriteItems/${movie.Id}`);
  check('favourite', r.json.IsFavorite === true);
  r = await call('GET', `/Items?Filters=IsFavorite&Recursive=true`);
  check('favourites list', r.json.Items.length === 1 && r.json.Items[0].Id === movie.Id);
  r = await call('POST', `/UserPlayedItems/${seasons[1].Id}`);
  r = await call('GET', `/Shows/${show.Id}/Episodes?SeasonId=${seasons[1].Id}`);
  check('mark a season watched', r.json.Items.every((e) => e.UserData.Played));

  // ── upcoming episodes of favourited series ──
  r = await call('GET', `/Shows/Upcoming?UserId=${uid}`);
  check('nothing upcoming without favourited series', r.json.Items.length === 0);
  const show2 = (await call('GET', `/Items/Latest?ParentId=${showView.Id}&Limit=2`)).json[1];
  await call('POST', `/UserFavoriteItems/${show.Id}`);
  await call('POST', `/UserFavoriteItems/${show2.Id}`);
  r = await call('GET', `/Shows/Upcoming?UserId=${uid}&Limit=48&Fields=AirTime`);
  const up = r.json.Items;
  check('Upcoming tab: favourited series, soonest first', up.length === 3
    && up.map((e) => `${e.SeriesName} S${e.ParentIndexNumber}E${e.IndexNumber}`).join(',') === 'Test Show 1 S2E3,Test Show 2 S2E5,Test Show 1 S2E4',
    up.map((e) => `${e.SeriesName} S${e.ParentIndexNumber}E${e.IndexNumber} ${String(e.PremiereDate).slice(0, 10)}`).join(' | '));
  check('episodes beyond 60 days are left out', !up.some((e) => e.SeriesName === 'Test Show 1' && e.IndexNumber === 5));
  check('dates ascending', up.every((e, i) => i === 0 || e.PremiereDate >= up[i - 1].PremiereDate));
  r = await call('GET', `/Items/Latest?ParentId=${upcomingView.Id}&Limit=16`);
  check('home row shows the air date on each card', /^Today · /.test(r.json[0].Name) && /^[A-Z][a-z]{2}, [A-Z][a-z]{2} \d{1,2} · /.test(r.json[1].Name), r.json.map((e) => e.Name).join(' | '));
  r = await call('GET', `/Items?ParentId=${upcomingView.Id}&IncludeItemTypes=Series&Recursive=true`);
  check('Upcoming library lists the series in air order', r.json.Items.length === 2 && r.json.Items[0].Name === 'Test Show 1' && r.json.Items[1].Name === 'Test Show 2', r.json.Items.map((x) => x.Name).join(', '));
  r = await call('GET', `/Users/${uid}/Items/${upcomingView.Id}`);
  check('Upcoming library opens', r.status === 200 && r.json.CollectionType === 'tvshows');
  const unaired = up[2];
  r = await call('GET', `/Users/${uid}/Items/${unaired.Id}`);
  check('unaired episode is marked unaired, no Play', r.json.LocationType === 'Virtual' && !r.json.MediaSources, `${r.json.LocationType}`);
  r = await call('POST', `/Items/${unaired.Id}/PlaybackInfo`, {});
  check('no stream lookup for an unaired episode', r.status === 404);
  r = await call('GET', `/Users/${uid}/Items/${up[0].Id}`);
  check('episode airing today is playable', r.json.LocationType === 'FileSystem' && r.json.MediaSources.length >= 1);
  r = await call('GET', `/Shows/${show.Id}/Episodes?SeasonId=${seasons[1].Id}`);
  check('season list marks unaired episodes', r.json.Items.filter((e) => e.LocationType === 'Virtual').map((e) => e.IndexNumber).join(',') === '4,5');
  await call('DELETE', `/UserFavoriteItems/${show2.Id}`);
  r = await call('GET', `/Shows/Upcoming?UserId=${uid}`);
  check('unfavouriting removes a series from Upcoming', r.json.Items.length === 2 && r.json.Items.every((e) => e.SeriesName === 'Test Show 1'));
  r = await call('GET', `/Items?Recursive=true&IncludeItemTypes=Series&Limit=5`);
  check('library-wide browse skips the Upcoming library', r.json.Items.length > 0 && r.json.Items.every((x) => x.Type === 'Series' && /^Test Show/.test(x.Name)));

  // images
  r = await call('GET', `/Items/${movie.Id}/Images/Primary?maxWidth=400&tag=x`);
  check('poster redirect picks a smaller TMDB size', r.status === 302 && /\/w500\//.test(r.headers.get('location')), r.headers.get('location'));
  r = await call('GET', `/Items/${eps[0].Id}/Images/Primary`);
  check('episode thumbnail', r.status === 302 && /thumb21/.test(r.headers.get('location')));

  // misc client calls that must not 404
  for (const p of ['/Branding/Configuration', '/Branding/Css', `/DisplayPreferences/usersettings?userId=${uid}&client=emby`, '/Users/Me',
    '/Localization/Cultures', '/QuickConnect/Enabled', `/Users/${uid}/Items/Root`, '/System/Info', '/Plugins', '/Sessions',
    `/Items/${movie.Id}/Similar`, `/Items/${movie.Id}/ThemeMedia`, `/MediaSegments/${movie.Id}`, '/Shows/Upcoming',
    `/Items/${movie.Id}/Intros`, '/LiveTv/Info', `/Users/${uid}/Items/${movie.Id}/SpecialFeatures`, '/emby/System/Info/Public']) {
    r = await call('GET', p);
    check(`GET ${p.split('?')[0]}`, r.status === 200, `${r.status}`);
  }
  r = await call('GET', '/Branding/Configuration');
  check('ElegantFin is the default theme', /ElegantFin/.test(r.json.CustomCss));

  // ── sound everywhere: web + mobile always remux, English audio by default ──
  const asClient = async (auth, path, body) => {
    const saved = token;
    const lr = await fetch(BASE + '/Users/AuthenticateByName', { method: 'POST', headers: { 'content-type': 'application/json', 'x-emby-authorization': auth }, body: JSON.stringify({ Username: USER, Pw: PASS }) });
    const t = (await lr.json()).AccessToken;
    const t0 = performance.now();
    const res = await fetch(BASE + path, { method: 'POST', headers: { 'content-type': 'application/json', 'x-emby-authorization': `${auth}, Token="${t}"` }, body: JSON.stringify(body || {}) });
    token = saved;
    return { json: await res.json(), ms: performance.now() - t0 };
  };
  r = await asClient(WEB_AUTH, `/Items/${movie.Id}/PlaybackInfo`, { DeviceProfile: CHROME });
  check('web: every stream is remuxed (AAC audio guaranteed)', r.json.MediaSources.every((x) => !x.SupportsDirectPlay && /main\.m3u8/.test(x.TranscodingUrl)), `${r.json.MediaSources.length} sources`);
  check('web: embedded subtitles hidden when remuxing', r.json.MediaSources.every((x) => x.MediaStreams.filter((t) => t.Type === 'Subtitle').every((t) => t.IsExternal)));
  r = await asClient(PHONE_AUTH, `/Items/${movie.Id}/PlaybackInfo`, { DeviceProfile: { DirectPlayProfiles: [{ Type: 'Video', Container: 'mkv,mp4', VideoCodec: 'h264,hevc', AudioCodec: 'aac,ac3,eac3' }] } });
  check('mobile: every stream is remuxed even when the phone claims support', r.json.MediaSources.every((x) => !x.SupportsDirectPlay && x.TranscodingUrl));
  const multi = sources[3];
  r = await asClient(WEB_AUTH, `/Items/${movie.Id}/PlaybackInfo?MediaSourceId=${multi.Id}`, { DeviceProfile: CHROME });
  const mSrc = r.json.MediaSources[0];
  const eng = mSrc.MediaStreams.find((x) => x.Type === 'Audio' && x.Language === 'eng');
  check('English audio is the default (file marks Spanish as default)', eng && mSrc.DefaultAudioStreamIndex === eng.Index, `default #${mSrc.DefaultAudioStreamIndex}`);
  check('remux plays the English track', eng && new RegExp(`audio=${eng.Index}\\b`).test(mSrc.TranscodingUrl), mSrc.TranscodingUrl.split('?')[1]);
  const spa = mSrc.MediaStreams.find((x) => x.Type === 'Audio' && x.Language === 'spa');
  r = await asClient(WEB_AUTH, `/Items/${movie.Id}/PlaybackInfo?MediaSourceId=${multi.Id}&AudioStreamIndex=${spa.Index}`, { DeviceProfile: CHROME, AudioStreamIndex: spa.Index });
  check('switching audio to Spanish mid-play', new RegExp(`audio=${spa.Index}\\b`).test(r.json.MediaSources[0].TranscodingUrl));
  r = await call('POST', `/Items/${movie.Id}/PlaybackInfo?MediaSourceId=${multi.Id}`, {});
  check('TV direct play is told English is the default track', r.json.MediaSources[0].DefaultAudioStreamIndex === eng.Index && r.json.MediaSources[0].SupportsDirectPlay);
  r = await call('POST', `/Items/${movie.Id}/PlaybackInfo`, { DeviceProfile: { DirectPlayProfiles: [{ Type: 'Video', Container: 'mkv', VideoCodec: 'h264,hevc', AudioCodec: 'aac,mp3' }] } });
  check('TV that lacks Dolby support gets AC3 streams remuxed, not silent', !r.json.MediaSources.find((x) => /1080p/.test(x.Name)).SupportsDirectPlay);

  // ── details page: real sources load in the background ──
  r = await asWeb(`/Users/${uid}/Items/${movie.Id}`);
  check('details answer instantly with a placeholder source', r.json.MediaSources.length === 1 && r.json.MediaSources[0].Id === movie.Id && r.ms < 300, ms(r.ms));
  r = await call('GET', `/Users/${uid}/Items/${movie.Id}?Fields=MediaSources&aiofinWait=1`);
  check('background request returns every real source', r.json.MediaSources.length === 4 && r.json.MediaSources.every((x) => x.Id !== movie.Id));
  r = await call('GET', `/aiofin/items/${movie.Id}/sources/${multi.Id}`);
  check('one version\'s real tracks on demand', r.json.AiofinTracksKnown === true && r.json.MediaStreams.filter((x) => x.Type === 'Audio').length === 2, r.json.MediaStreams.filter((x) => x.Type === 'Audio').map((x) => x.DisplayTitle).join(' | '));
  const prefBefore = (await call('GET', `/aiofin/items/${movie.Id}/sources`)).json.Preferred;
  await call('GET', `/aiofin/items/${cold.Id}/sources/${sources[1].Id}`);
  check('looking at a version does not count as choosing it', (await call('GET', `/aiofin/items/${cold.Id}/sources`)).json.Preferred === null && prefBefore !== undefined);
  r = await asClient(WEB_AUTH, `/Items/${movie.Id}/PlaybackInfo?MediaSourceId=${multi.Id}&AudioStreamIndex=901`, { DeviceProfile: CHROME, AudioStreamIndex: 901 });
  check('a guessed track number falls back to English, never a wrong real track', new RegExp(`audio=${eng.Index}\\b`).test(r.json.MediaSources[0].TranscodingUrl), r.json.MediaSources[0].TranscodingUrl.split('?')[1].split('&api')[0]);
  r = await call('POST', `/Items/${cold.Id}/PlaybackInfo`, {});
  const guessed = r.json.MediaSources.find((x) => !x.AiofinTracksKnown);
  check('guessed tracks use track numbers no file has', !guessed || guessed.MediaStreams.filter((x) => !x.IsExternal).every((x) => x.Index >= 900), guessed ? guessed.MediaStreams.filter((x) => !x.IsExternal).map((x) => x.Index).join(',') : 'all known');

  // ── switching streams ──
  r = await call('GET', `/aiofin/items/${movie.Id}/sources`);
  check('stream switcher lists every stream', r.json.Sources.length === 4, r.json.Sources.map((x) => x.Name.split(' · ')[0]).join(', '));
  check('stream labels are distinct', new Set(r.json.Sources.map((x) => x.Name)).size === 4, r.json.Sources.slice(2).map((x) => x.Name).join(' | '));
  check('the stream picked last time is remembered', r.json.Preferred === multi.Id);
  r = await call('POST', `/Items/${movie.Id}/PlaybackInfo`, {});
  check('...and offered first next time', r.json.MediaSources[0].Id === multi.Id, r.json.MediaSources[0].Name);

  // ── native apps: the details response carries every version (Swiftfin) ──
  const SWIFTFIN_AUTH = 'MediaBrowser Client="Swiftfin iOS", Device="iPhone", DeviceId="e2e-swiftfin", Version="1.4.0"';
  const asGet = async (auth, path) => {
    const lr = await fetch(BASE + '/Users/AuthenticateByName', { method: 'POST', headers: { 'content-type': 'application/json', 'x-emby-authorization': auth }, body: JSON.stringify({ Username: USER, Pw: PASS }) });
    const t = (await lr.json()).AccessToken;
    const t0 = performance.now();
    const res = await fetch(BASE + path, { headers: { 'x-emby-authorization': `${auth}, Token="${t}"` } });
    return { json: await res.json(), ms: performance.now() - t0, token: t };
  };
  r = await asGet(SWIFTFIN_AUTH, `/Items/${movie.Id}?userId=${uid}`);
  const sfSources = r.json.MediaSources || [];
  check('Swiftfin details list every version (its picker shows them)', sfSources.length === 4 && sfSources.every((x) => x.Name && x.ETag === x.Id), `${sfSources.length} versions: ${sfSources.map((x) => x.Name.split(' · ')[0]).join(', ')}`);
  check('Swiftfin details carry real audio tracks for its audio picker', sfSources[0] && sfSources[0].MediaStreams.some((x) => x.Type === 'Audio') && r.json.MediaStreams && r.json.MediaSourceCount === 4);
  check('cached title: Swiftfin details still open fast', r.ms < 300, ms(r.ms));
  const sfToken = r.token;
  const sfPick = sfSources[1];
  const sfPi = await (await fetch(`${BASE}/Items/${movie.Id}/PlaybackInfo`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-emby-authorization': `${SWIFTFIN_AUTH}, Token="${sfToken}"` }, body: JSON.stringify({ MediaSourceId: sfPick.Id, UserId: uid, IsAutoOpenLiveStream: true, DeviceProfile: { DirectPlayProfiles: [] } }) })).json();
  check('Swiftfin plays the version picked on its details screen', sfPi.MediaSources.length === 1 && sfPi.MediaSources[0].ETag === sfPick.ETag, sfPi.MediaSources[0] && sfPi.MediaSources[0].Name);
  r = await asGet(WEB_AUTH, `/Items/${movie.Id}?userId=${uid}`);
  check('Jellyfin Web still gets the instant placeholder (its page script fills versions)', r.json.MediaSources.length === 1 && r.json.MediaSources[0].Id === movie.Id);
  r = await asGet('MediaBrowser Client="Jellyfin iOS", Device="iPhone", DeviceId="e2e-jfios", Version="1.0"', `/Items/${movie.Id}?userId=${uid}`);
  check('Jellyfin iOS app (Jellyfin Web inside) gets the placeholder too', r.json.MediaSources.length === 1);
  r = await asGet(AUTH, `/Items/${movie.Id}?userId=${uid}`);
  check('Jellyfin Android TV (native) gets every version', r.json.MediaSources.length === 4);
  const coldShow = (await call('GET', `/Items?ParentId=${movieView.Id}&StartIndex=25&Limit=1`)).json.Items[0];
  r = await asGet(SWIFTFIN_AUTH, `/Items/${coldShow.Id}?userId=${uid}`);
  check('title never opened: Swiftfin details wait only for AIOStreams + reading tracks', r.json.MediaSources.length === 4 && r.ms < 6000, ms(r.ms));
  r = await asGet(SWIFTFIN_AUTH, `/Items/${up[2] ? up[2].Id : movie.Id}?userId=${uid}`);
  check('unaired episode: no stream lookup on Swiftfin details', !up[2] || !r.json.MediaSources);

  // ── Streamyfin: details via /Items?ids=…, then again with every field in the background ──
  const SY_AUTH = 'MediaBrowser Client="Streamyfin", Device="iPhone", DeviceId="e2e-streamyfin", Version="0.40.0"';
  const syLogin = await (await fetch(BASE + '/Users/AuthenticateByName', { method: 'POST', headers: { 'content-type': 'application/json', 'x-emby-authorization': SY_AUTH }, body: JSON.stringify({ Username: USER, Pw: PASS }) })).json();
  const syH = { 'content-type': 'application/json', 'x-emby-authorization': `${SY_AUTH}, Token="${syLogin.AccessToken}"` };
  const ALL_FIELDS = ['AirTime', 'CanDelete', 'CanDownload', 'ChannelInfo', 'Chapters', 'Trickplay', 'ChildCount', 'CumulativeRunTimeTicks', 'CustomRating', 'DateCreated', 'DateLastMediaAdded', 'DisplayPreferencesId', 'Etag', 'ExternalUrls', 'Genres', 'ItemCounts', 'MediaSourceCount', 'MediaSources', 'OriginalTitle', 'Overview', 'ParentId', 'Path', 'People', 'PlayAccess', 'ProductionLocations', 'ProviderIds', 'PrimaryImageAspectRatio', 'RecursiveItemCount', 'Settings', 'SeriesStudio', 'SortName', 'SpecialEpisodeNumbers', 'Studios', 'Taglines', 'Tags', 'RemoteTrailers', 'MediaStreams', 'SeasonUserData', 'DateLastRefreshed', 'DateLastSaved', 'RefreshState', 'ChannelImage', 'EnableMediaSourceDisplay', 'Width', 'Height', 'ExtraIds', 'LocalTrailerCount', 'IsHD', 'SpecialFeatureCount'];
  const fastFields = ALL_FIELDS.filter((f) => !['MediaSources', 'MediaSourceCount', 'MediaStreams'].includes(f));
  const syMovie = (await call('GET', `/Items?ParentId=${movieView.Id}&StartIndex=33&Limit=1`)).json.Items[0];
  let st0 = performance.now();
  let sr = await (await fetch(`${BASE}/Items?ids=${syMovie.Id}&userId=${uid}&fields=${fastFields.join(',')}`, { headers: syH })).json();
  const fastMs = performance.now() - st0;
  check('Streamyfin: details page loads fast, without versions', sr.Items.length === 1 && !sr.Items[0].MediaSources && fastMs < 400, ms(fastMs));
  await sleep(3000); // the person looks at the page
  st0 = performance.now();
  sr = await (await fetch(`${BASE}/Items?ids=${syMovie.Id}&userId=${uid}&fields=${ALL_FIELDS.join(',')}`, { headers: syH })).json();
  const syItem = sr.Items[0];
  check('Streamyfin: background request lists every version (Version menu appears)', syItem.MediaSources && syItem.MediaSources.length === 4 && syItem.MediaSourceCount === 4, `${syItem.MediaSources ? syItem.MediaSources.length : 0} versions in ${ms(performance.now() - st0)}`);
  check('Streamyfin: opening the page already found the streams (prefetch)', performance.now() - st0 < 300, ms(performance.now() - st0));
  const syMulti = syItem.MediaSources.find((x) => /MULTi/.test(x.Name));
  check('Streamyfin: versions carry tracks for its Audio/Subtitle menus', syItem.MediaSources[0].MediaStreams.some((x) => x.Type === 'Audio') && syItem.MediaSources[0].MediaStreams.some((x) => x.Type === 'Subtitle'));
  // Streamyfin's PlaybackInfo body is camelCase.
  const syMultiTracks = (await call('GET', `/aiofin/items/${syMovie.Id}/sources/${syMulti.Id}`)).json.MediaStreams;
  const syEng = syMultiTracks.find((x) => x.Type === 'Audio' && x.Language === 'eng');
  const sySpa = syMultiTracks.find((x) => x.Type === 'Audio' && x.Language === 'spa');
  st0 = performance.now();
  const syPi = await (await fetch(`${BASE}/Items/${syMovie.Id}/PlaybackInfo`, { method: 'POST', headers: syH, body: JSON.stringify({ userId: uid, deviceProfile: { DirectPlayProfiles: [], TranscodingProfiles: [{ Type: 'Video', Protocol: 'hls', Container: 'ts', VideoCodec: 'h264,hevc', AudioCodec: 'aac' }] }, subtitleStreamIndex: -1, startTimeTicks: 0, isPlayback: true, autoOpenLiveStream: true, audioStreamIndex: sySpa.Index, mediaSourceId: syMulti.Id }) })).json();
  check('Streamyfin: plays the version picked in its menu (camelCase request)', syPi.MediaSources.length === 1 && syPi.MediaSources[0].Id === syMulti.Id, `${syPi.MediaSources[0] && syPi.MediaSources[0].Name} in ${ms(performance.now() - st0)}`);
  check('Streamyfin: plays the audio track picked in its menu', new RegExp(`audio=${sySpa.Index}\\b`).test(syPi.MediaSources[0].TranscodingUrl), syPi.MediaSources[0].TranscodingUrl.split('?')[1].split('&api')[0]);
  const syDefault = await (await fetch(`${BASE}/Items/${syMovie.Id}/PlaybackInfo`, { method: 'POST', headers: syH, body: JSON.stringify({ userId: uid, deviceProfile: { DirectPlayProfiles: [], TranscodingProfiles: [{ Type: 'Video', Protocol: 'hls', Container: 'ts', VideoCodec: 'h264', AudioCodec: 'aac' }] }, audioStreamIndex: 0, mediaSourceId: syMulti.Id }) })).json();
  check('Streamyfin: its default "track 0" still gets English audio', new RegExp(`audio=${syEng.Index}\\b`).test(syDefault.MediaSources[0].TranscodingUrl));
  const prog = await fetch(`${BASE}/Sessions/Playing/Progress`, { method: 'POST', headers: syH, body: JSON.stringify({ itemId: syMovie.Id, positionTicks: 12_000_000_000 }) });
  check('Streamyfin: camelCase progress reports are saved', prog.status === 204 && (await call('GET', `/UserItems/${syMovie.Id}/UserData`)).json.PlaybackPositionTicks === 12_000_000_000);

  // ── right show, right episode: The Walking Dead vs Fear the Walking Dead ──
  await call('POST', '/admin/api/settings', { sourceNames: 'aiostreams' }); // labels show the raw file names
  const findShow = async (q, name) => (await call('GET', `/Items?searchTerm=${encodeURIComponent(q)}&IncludeItemTypes=Series&Recursive=true`)).json.Items.find((x) => x.Name === name);
  const firstEp = async (show, n = 0) => (await call('GET', `/Shows/${show.Id}/Episodes?Season=1`)).json.Items[n];
  const filesFor = async (episode) => (await call('POST', `/Items/${episode.Id}/PlaybackInfo`, {})).json.MediaSources.map((x) => x.Name.replace(/^\[RD⚡\] AIOStreams /, ''));
  const twd = await findShow('walking dead', 'The Walking Dead');
  const ftwd = await findShow('walking dead', 'Fear the Walking Dead');
  check('search finds both shows separately', twd && ftwd && twd.Id !== ftwd.Id);
  let files = await filesFor(await firstEp(twd));
  check('The Walking Dead S1E1: wrong show, spin-off and wrong episode removed',
    files.length === 3 && files.every((f) => !/Fear|Daryl|S01E10/.test(f)) && files.some((f) => /^The\.Walking\.Dead\.S01E01/.test(f)), files.join(' | '));
  check('...abbreviations and season packs are kept', files.some((f) => /^TWD\.S01E01/.test(f)) && files.some((f) => /S01\.COMPLETE/.test(f)));
  files = await filesFor(await firstEp(ftwd));
  check('Fear the Walking Dead S1E1: only Fear the Walking Dead', files.length === 1 && /^Fear\.the\.Walking\.Dead\.S01E01/.test(files[0]), files.join(' | '));
  const dw = await findShow('doctor who', 'Doctor Who');
  files = await filesFor(await firstEp(dw));
  check('Doctor Who (2005): the 1963 series is removed by year', files.length === 2 && !files.some((f) => /1963/.test(f)), files.join(' | '));
  files = await filesFor(await firstEp(dw, 1));
  check('when every result is wrong, they are kept but marked ⚠', files.length === 1 && files[0].startsWith('⚠'), files.join(' | '));
  r = await call('GET', '/admin/api/status');
  const twdTiming = r.json.timings.find((x) => x.id === 'tt1520211:1:1');
  check('admin timeline counts the removed results', twdTiming && twdTiming.removed === 3, twdTiming && `${twdTiming.count} kept, ${twdTiming.removed} removed`);
  await call('POST', '/admin/api/settings', { checkMatches: false });
  await call('POST', '/admin/api/cache/clear');
  files = await filesFor(await firstEp(twd));
  check('the check can be turned off', files.length === 6, `${files.length} results`);
  await call('POST', '/admin/api/settings', { checkMatches: true, sourceNames: 'clean' });
  await call('POST', '/admin/api/cache/clear');

  // ── subtitles stay in sync ──
  // 1. Subtitles made for the exact file: AIOFin sends its OpenSubtitles hash, size and name.
  const hashMovie = (await call('GET', `/Items?ParentId=${movieView.Id}&StartIndex=40&Limit=1`)).json.Items[0];
  await call('GET', `/Users/${uid}/Items/${hashMovie.Id}`);
  await sleep(3500);
  const hpi = (await call('POST', `/Items/${hashMovie.Id}/PlaybackInfo`, {})).json;
  const firstSub = hpi.MediaSources[0].MediaStreams.find((x) => x.Type === 'Subtitle');
  const calls = await (await fetch('http://127.0.0.1:7001/_calls')).json();
  check('subtitle add-ons are told the exact file (hash, size, name)', calls.lastSubExtras && /^[0-9a-f]{16}$/.test(calls.lastSubExtras.videoHash) && +calls.lastSubExtras.videoSize > 0 && /\.mkv$/.test(calls.lastSubExtras.filename), JSON.stringify(calls.lastSubExtras));
  check('a subtitle made for this exact file is offered first', firstSub && /os=(hash-[0-9a-f]{16}|release)/.test(firstSub.Path), firstSub && firstSub.Path.split('?')[1]);
  const hashSub = hpi.MediaSources[0].MediaStreams.filter((x) => x.Type === 'Subtitle').findIndex((x) => /os=hash-/.test(x.Path || ''));
  check('...and the hash-matched one right after the release-named one', hashSub === 1, `position ${hashSub}`);
  // 2. The remux timeline is exact, playing from the start and when resuming mid-file.
  const { execSync } = require('child_process');
  const firstPts = (buf) => { require('fs').writeFileSync('/tmp/e2e-seg.ts', buf); return Math.min(...execSync('ffprobe -v error -show_entries packet=pts_time -of csv=p=0 /tmp/e2e-seg.ts').toString().split('\n').map(parseFloat).filter((x) => !isNaN(x))); };
  for (const [label, order] of [['from the start', [0, 1, 2, 3]], ['resuming mid-file', [10, 11, 12]]]) {
    const tpi = await asClient(WEB_AUTH, `/Items/${hashMovie.Id}/PlaybackInfo?MediaSourceId=${hpi.MediaSources.find((x) => /1080p/.test(x.Name)).Id}`, { DeviceProfile: CHROME });
    const turl = BASE + tpi.json.MediaSources[0].TranscodingUrl;
    const pl = await (await fetch(turl)).text();
    const durs = [...pl.matchAll(/#EXTINF:([\d.]+)/g)].map((x) => +x[1]);
    let acc = 0; const starts = durs.map((d) => { const v = acc; acc += d; return v; });
    const offs = [];
    for (const n of order) offs.push(firstPts(Buffer.from(await (await fetch(turl.replace(/main\.m3u8.*$/, `${n}.ts`))).arrayBuffer())) - starts[n]);
    const worst = Math.max(...offs.map(Math.abs));
    check(`remux timeline exact ${label} (subtitles stay in sync)`, worst < 0.05, `worst ${worst.toFixed(3)}s over segments ${order.join(',')}`);
  }

  // ── subtitles inside the file, next to OpenSubtitles ──
  const stm = (await call('GET', '/Items?searchTerm=subtitle%20test&IncludeItemTypes=Movie&Recursive=true')).json.Items[0];
  await call('GET', `/Users/${uid}/Items/${stm.Id}`);
  await sleep(2500);
  let spi = await asClient(WEB_AUTH, `/Items/${stm.Id}/PlaybackInfo`, { DeviceProfile: CHROME });
  const webSubs = spi.json.MediaSources[0].MediaStreams.filter((x) => x.Type === 'Subtitle');
  const inFile = webSubs.filter((x) => /\(in file\)$/.test(x.DisplayTitle));
  const osSubs = webSubs.filter((x) => /\(OpenSubtitles\)$/.test(x.DisplayTitle));
  check('web: subtitles inside the file are offered', inFile.length === 2 && inFile.every((x) => x.DeliveryMethod === 'External'), inFile.map((x) => x.DisplayTitle).join(' | '));
  check('web: ...next to OpenSubtitles, listed separately', osSubs.length > 0 && webSubs.indexOf(inFile[1]) < webSubs.indexOf(osSubs[0]), `${inFile.length} in file, then ${osSubs.length} OpenSubtitles`);
  const engIn = inFile.find((x) => x.Language === 'eng'); const spaIn = inFile.find((x) => x.Language === 'spa');
  check('in-file track labels', engIn.DisplayTitle === 'English SDH (in file)' && spaIn.DisplayTitle === 'Spanish (in file)', `${engIn.DisplayTitle} | ${spaIn.DisplayTitle}`);
  let ef0 = performance.now();
  r = await call('GET', engIn.DeliveryUrl.replace('.vtt', '.js'));
  const firstRead = performance.now() - ef0;
  check('picking it reads every line out of the file', r.json && r.json.TrackEvents.length === 12 && r.json.TrackEvents[0].StartPositionTicks === 25_000_000 && r.json.TrackEvents[0].Text === 'Line 1' && r.json.TrackEvents[11].StartPositionTicks === 575_000_000, `${r.json && r.json.TrackEvents.length} lines in ${ms(firstRead)}`);
  ef0 = performance.now();
  r = await call('GET', spaIn.DeliveryUrl.replace('.vtt', '.js'));
  check('...every track comes from the same read (second track instant)', r.json && r.json.TrackEvents.length === 12 && r.json.TrackEvents[0].Text === 'Línea 1' && performance.now() - ef0 < 200, ms(performance.now() - ef0));
  r = await call('GET', engIn.DeliveryUrl);
  check('in-file subtitles as WebVTT too', r.status === 200 && r.text.startsWith('WEBVTT') && r.text.includes('00:00:02.500 --> 00:00:05.250'));
  spi = await call('POST', `/Items/${stm.Id}/PlaybackInfo`, {});
  const tvIn = spi.json.MediaSources[0].MediaStreams.filter((x) => x.Type === 'Subtitle' && /\(in file\)/.test(x.DisplayTitle));
  check('TV apps read in-file subtitles themselves', tvIn.length === 2 && tvIn.every((x) => x.DeliveryMethod === 'Embed'));
  await call('POST', '/admin/api/settings', { embeddedSubtitles: false });
  spi = await asClient(WEB_AUTH, `/Items/${stm.Id}/PlaybackInfo`, { DeviceProfile: CHROME });
  check('in-file subtitles on web can be turned off', !spi.json.MediaSources[0].MediaStreams.some((x) => /\(in file\)/.test(x.DisplayTitle || '')));
  await call('POST', '/admin/api/settings', { embeddedSubtitles: true });

  // ── every kind of in-file subtitle, per app ──
  const asm = (await call('GET', '/Items?searchTerm=all%20subtitles&IncludeItemTypes=Movie&Recursive=true')).json.Items[0];
  await call('GET', `/Users/${uid}/Items/${asm.Id}`);
  await sleep(3000);
  const subsOf = (pi) => pi.MediaSources[0].MediaStreams.filter((x) => x.Type === 'Subtitle');
  const webPi = (await asClient(WEB_AUTH, `/Items/${asm.Id}/PlaybackInfo`, { DeviceProfile: CHROME })).json;
  const ws = subsOf(webPi);
  const wAss = ws.find((x) => x.Index === 3); const wPgs = ws.find((x) => x.Index === 4); const wVob = ws.find((x) => x.Index === 5);
  check('Jellyfin Web: styled ASS delivered as ASS', wAss && wAss.Codec === 'ass' && /Stream\.ass/.test(wAss.DeliveryUrl), wAss && `${wAss.DisplayTitle} → ${wAss.Codec}`);
  check('Jellyfin Web: PGS delivered as pictures it draws itself', wPgs && wPgs.Codec === 'pgssub' && wPgs.DeliveryMethod === 'External' && /Stream\.sup/.test(wPgs.DeliveryUrl), wPgs && wPgs.DisplayTitle);
  check('Jellyfin Web: VobSub offered as burned in', wVob && wVob.DeliveryMethod === 'Encode' && /burned in/.test(wVob.DisplayTitle), wVob && wVob.DisplayTitle);
  const fonts = webPi.MediaSources[0].MediaAttachments || [];
  check('the file\'s fonts are offered for styled subtitles', fonts.length === 1 && fonts[0].FileName === 'DejaVuSans.ttf', fonts.map((f) => f.FileName).join(','));
  r = await call('GET', wAss.DeliveryUrl);
  check('ASS keeps its styles and positioning', r.status === 200 && r.text.includes('Style: Sign,DejaVu Serif') && r.text.includes('{\\pos(640,100)}') && (r.text.match(/^Dialogue:/gm) || []).length === 4, r.text.split('\n').find((l) => l.startsWith('Style: Sign')));
  const supRes = await fetch(BASE + wPgs.DeliveryUrl); const supBuf = Buffer.from(await supRes.arrayBuffer());
  require('fs').writeFileSync('/tmp/e2e.sup', supBuf);
  const supCheck = execSyncTop('ffmpeg -v verbose -i /tmp/e2e.sup -map 0 -c:s dvdsub -f null - 2>&1 | grep -o "[0-9]* frames decoded; [0-9]* decode errors"').toString().trim();
  check('PGS served as a valid .sup', supRes.status === 200 && /^8 frames decoded; 0 decode errors/.test(supCheck), supCheck);
  const fontRes = await fetch(BASE + fonts[0].DeliveryUrl); const fontBuf = Buffer.from(await fontRes.arrayBuffer());
  check('font served from the file', fontRes.status === 200 && fontBuf.length === require('fs').statSync('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf').size, `${fontBuf.length} bytes`);
  const webBurn = (await asClient(WEB_AUTH, `/Items/${asm.Id}/PlaybackInfo?SubtitleStreamIndex=5`, { DeviceProfile: CHROME, SubtitleStreamIndex: 5 })).json;
  check('picking VobSub on web burns it in', /burn=5\b/.test(webBurn.MediaSources[0].TranscodingUrl));
  const sfAll = (await asClient(SWIFTFIN_AUTH, `/Items/${asm.Id}/PlaybackInfo`, { DeviceProfile: { DirectPlayProfiles: [], TranscodingProfiles: [{ Type: 'Video', Protocol: 'hls', Container: 'ts', VideoCodec: 'h264' }] } })).json;
  const ss2 = subsOf(sfAll);
  check('Swiftfin (remux): ASS as plain text, PGS burned in', ss2.find((x) => x.Index === 3).Codec === 'subrip' && ss2.find((x) => x.Index === 4).DeliveryMethod === 'Encode', ss2.map((x) => `${x.Index}:${x.DeliveryMethod}`).join(' '));
  const sfBurn = (await asClient(SWIFTFIN_AUTH, `/Items/${asm.Id}/PlaybackInfo`, { subtitleStreamIndex: 4, deviceProfile: { DirectPlayProfiles: [], TranscodingProfiles: [{ Type: 'Video', Protocol: 'hls', Container: 'ts', VideoCodec: 'h264' }] } })).json;
  const burnUrl = BASE + sfBurn.MediaSources[0].TranscodingUrl;
  check('picking PGS in Swiftfin burns it in', /burn=4\b/.test(burnUrl));
  const bpl = await (await fetch(burnUrl)).text();
  const bd = [...bpl.matchAll(/#EXTINF:([\d.]+)/g)].map((x) => +x[1]);
  let bacc = 0; const bseg = bd.findIndex((d) => { const hit = 6 >= bacc && 6 < bacc + d; bacc += d; return hit; });
  require('fs').writeFileSync('/tmp/e2e-burn.ts', Buffer.from(await (await fetch(burnUrl.replace(/main\.m3u8.*$/, `${bseg}.ts`))).arrayBuffer()));
  execSyncTop(`ffmpeg -v error -y -copyts -i /tmp/e2e-burn.ts -vf "select='gte(t\\,6)'" -frames:v 1 -update 1 /tmp/e2e-burn.png`);
  const lum = execSyncTop('python3 -c "from PIL import Image; print(Image.open(\'/tmp/e2e-burn.png\').convert(\'L\').getpixel((640,630)))"').toString().trim();
  check('the burned-in subtitle is in the video picture, even when playback starts mid-caption', +lum > 200, `brightness ${lum} where the subtitle is drawn (segment ${bseg}, caption began at 5 s)`);
  // ...and the timeline stays exact for that restarted, burned-in segment.
  const burnFirst = Math.min(...execSyncTop('ffprobe -v error -show_entries packet=pts_time -of csv=p=0 /tmp/e2e-burn.ts').toString().split('\n').map(parseFloat).filter((x) => !isNaN(x)));
  const burnStart = bd.slice(0, bseg).reduce((x, y) => x + y, 0);
  check('burned-in restart keeps the exact timeline', Math.abs(burnFirst - burnStart) < 0.05, `segment starts ${burnFirst.toFixed(3)}s, declared ${burnStart.toFixed(3)}s`);
  const tvPi = (await call('POST', `/Items/${asm.Id}/PlaybackInfo`, {})).json;
  check('TV apps read all four in-file tracks themselves', subsOf(tvPi).filter((x) => x.DeliveryMethod === 'Embed').length === 4);
  // External subtitles: made-for-this-release first, then regular before SDH, Forced and AI.
  const ext = ws.filter((x) => x.IsExternal && !/in file/.test(x.DisplayTitle));
  const order = ext.map((x) => (x.Path.match(/os=([a-z]+)/) || [])[1] || 'other');
  check('external subtitles: release-named, hash match, regular, SDH, AI-translated, Forced last', order.join(',') === 'release,hash,plain,sdh,ai,forced', order.join(','));
  check('labels say what each external subtitle is', ext[0].DisplayTitle === 'English (OpenSubtitles, made for this release)' && ext.some((x) => x.DisplayTitle === 'English SDH (OpenSubtitles)') && ext.some((x) => /\(AI translated\)/.test(x.DisplayTitle)), ext[0].DisplayTitle);

  // ── like Nuvio: native apps play the file directly and read in-file subtitles themselves ──
  const VLC_PROFILE = { DirectPlayProfiles: [{ Type: 'Video', Container: 'mkv,mp4,avi,ts', VideoCodec: 'h264,hevc,av1,vp9', AudioCodec: 'aac,ac3,eac3,dts,truehd,flac,mp3,opus' }], TranscodingProfiles: [{ Type: 'Video', Protocol: 'hls', Container: 'ts', VideoCodec: 'h264', AudioCodec: 'aac' }] };
  let nat = (await asClient(SWIFTFIN_AUTH, `/Items/${asm.Id}/PlaybackInfo`, { DeviceProfile: VLC_PROFILE })).json.MediaSources[0];
  check('Swiftfin plays the file directly when its player supports it', nat.SupportsDirectPlay === true && !nat.TranscodingUrl);
  check('...and reads every in-file subtitle itself (instant, always in sync)', nat.MediaStreams.filter((x) => x.Type === 'Subtitle' && x.DeliveryMethod === 'Embed').length === 4);
  nat = (await asClient(SY_AUTH, `/Items/${asm.Id}/PlaybackInfo`, { deviceProfile: VLC_PROFILE })).json.MediaSources[0];
  check('Streamyfin too (camelCase profile)', nat.SupportsDirectPlay === true);
  nat = (await asClient(SWIFTFIN_AUTH, `/Items/${asm.Id}/PlaybackInfo`, { DeviceProfile: { DirectPlayProfiles: [{ Type: 'Video', Container: 'mp4', VideoCodec: 'h264', AudioCodec: 'aac' }], TranscodingProfiles: VLC_PROFILE.TranscodingProfiles } })).json.MediaSources[0];
  check('...but gets the remux when its player can\'t handle the file', !nat.SupportsDirectPlay && /main\.m3u8/.test(nat.TranscodingUrl));
  nat = (await asClient(PHONE_AUTH, `/Items/${asm.Id}/PlaybackInfo`, { DeviceProfile: VLC_PROFILE })).json.MediaSources[0];
  check('Jellyfin iOS/Android apps (Jellyfin Web inside) always get the remux', !nat.SupportsDirectPlay && nat.TranscodingUrl);

  // ── in-file subtitles on Jellyfin Web: available at once, filled in progressively ──
  const lm = (await call('GET', '/Items?searchTerm=subtitle%20test&IncludeItemTypes=Movie&Recursive=true')).json.Items[0];
  const lpi = (await asClient(WEB_AUTH, `/Items/${lm.Id}/PlaybackInfo`, { DeviceProfile: CHROME })).json.MediaSources[0];
  const lsub = lpi.MediaStreams.find((x) => x.Type === 'Subtitle' && /in file/.test(x.DisplayTitle) && x.Language === 'eng');
  check('Jellyfin Web gets in-file text subtitles progressively', /[?&]live=1\b/.test(lsub.DeliveryUrl), lsub.DeliveryUrl.split('?')[1].split('&api')[0] + '…');
  await fetch(BASE + lpi.TranscodingUrl).then((x) => x.text());
  await fetch(BASE + lpi.TranscodingUrl.replace(/main\.m3u8.*$/, '0.ts')).then((x) => x.arrayBuffer());
  let lt0 = performance.now();
  let lres = await fetch(BASE + lsub.DeliveryUrl.replace('.vtt', '.js'));
  let ljs = await lres.json();
  check('live subtitle reply comes back at once with lines and a completeness flag', lres.status === 200 && ljs.TrackEvents.length > 0 && ['0', '1'].includes(lres.headers.get('x-aiofin-complete')), `${ljs.TrackEvents.length} lines in ${ms(performance.now() - lt0)}, complete=${lres.headers.get('x-aiofin-complete')}`);
  for (let i = 0; i < 40 && lres.headers.get('x-aiofin-complete') !== '1'; i++) { await sleep(500); lres = await fetch(BASE + lsub.DeliveryUrl.replace('.vtt', '.js')); ljs = await lres.json(); }
  check('...and reaches the complete track, every line at its exact time', lres.headers.get('x-aiofin-complete') === '1' && ljs.TrackEvents.length === 12 && ljs.TrackEvents.every((e, i) => e.StartPositionTicks === (25 + i * 50) * 1_000_000), `${ljs.TrackEvents.length} lines`);

  // ── pre-render: opening a title on Jellyfin Web prepares the first seconds of video ──
  {
    const pm = (await call('GET', '/Items?searchTerm=slow%20link&IncludeItemTypes=Movie&Recursive=true')).json.Items[0];
    await asClient(WEB_AUTH, `/Items/${pm.Id}?userId=${uid}`, null).catch(() => {});
    const wl = await (await fetch(BASE + '/Users/AuthenticateByName', { method: 'POST', headers: { 'content-type': 'application/json', 'x-emby-authorization': WEB_AUTH }, body: JSON.stringify({ Username: USER, Pw: PASS }) })).json();
    const wh = { 'content-type': 'application/json', 'x-emby-authorization': `${WEB_AUTH}, Token="${wl.AccessToken}"` };
    await fetch(`${BASE}/Users/${uid}/Items/${pm.Id}`, { headers: wh }).then((x) => x.text());
    await sleep(6000);
    const st = (await call('GET', '/admin/api/status')).json;
    const warm = st.transcodes.find((x) => x.name.startsWith('warm.'));
    check('opening a title pre-renders it, then pauses', warm && warm.paused === true, warm ? `${warm.name.slice(0, 13)}… paused=${warm.paused}` : 'no pre-render');
    const pt0 = performance.now();
    const ppi = await (await fetch(`${BASE}/Items/${pm.Id}/PlaybackInfo`, { method: 'POST', headers: wh, body: JSON.stringify({ DeviceProfile: CHROME }) })).json();
    const purl = BASE + ppi.MediaSources[0].TranscodingUrl;
    await (await fetch(purl)).text();
    const pseg = await fetch(purl.replace(/main\.m3u8.*$/, '0.ts')); await pseg.arrayBuffer();
    const pms = performance.now() - pt0;
    check('Play → first segment is instant on a slow link (pre-rendered)', pseg.status === 200 && pms < 400, ms(pms));
  }

  // ── like Remux: version ids work as items, list placeholders, "No streams found" ──
  {
    const vMovie = (await call('GET', `/Items?ParentId=${movieView.Id}&StartIndex=5&Limit=1`)).json.Items[0];
    const vers = (await call('POST', `/Items/${vMovie.Id}/PlaybackInfo`, {})).json.MediaSources;
    const pick = vers[1];
    r = await call('GET', `/Users/${uid}/Items/${pick.Id}`);
    check('a version id opens as an item (that version only)', r.status === 200 && r.json.Name === vMovie.Name && r.json.MediaSources.length === 1 && r.json.MediaSources[0].Id === pick.Id, r.status === 200 ? r.json.MediaSources[0].Name : `HTTP ${r.status}`);
    r = await call('GET', `/Items/${pick.Id}?userId=${uid}`);
    check('...on the newer path too', r.status === 200 && r.json.MediaSources[0].Id === pick.Id);
    r = await call('POST', `/Items/${pick.Id}/PlaybackInfo`, {});
    check('PlaybackInfo by version id plays that version', r.status === 200 && r.json.MediaSources.length === 1 && r.json.MediaSources[0].Id === pick.Id);
    r = await call('GET', `/Users/${uid}/Items?ParentId=${movieView.Id}&Limit=5&Fields=MediaSources,Overview`);
    const li = r.json.Items.find((x) => x.Id !== vMovie.Id && x.MediaSources && x.MediaSources.length === 2);
    check('list replies asking for versions get two placeholders', !!li && li.MediaSources[0].Id === li.Id, li ? li.MediaSources.map((x) => x.Name).join(' | ') : 'none');
    r = await call('POST', `/Items/${li.Id}/PlaybackInfo?MediaSourceId=${li.MediaSources[1].Id}`, {});
    check('playing the second placeholder plays the title', r.status === 200 && r.json.MediaSources.length >= 1 && r.json.MediaSources[0].Id !== li.MediaSources[1].Id);
    r = await call('GET', `/Users/${uid}/Items?ParentId=${movieView.Id}&Limit=3`);
    check('lists that don\'t ask for versions stay light', r.json.Items.every((x) => !x.MediaSources));
    const none = (await call('GET', '/Items?searchTerm=no%20streams&IncludeItemTypes=Movie&Recursive=true')).json.Items[0];
    r = await call('GET', `/Users/${uid}/Items/${none.Id}`);
    check('no streams → a "No streams found" entry', r.json.MediaSources && r.json.MediaSources.length === 1 && r.json.MediaSources[0].Name === 'No streams found', r.json.MediaSources && r.json.MediaSources[0].Name);
  }

  // concurrency: 20 clients ask for the same cold title at once → one upstream call
  const before = (await (await fetch('http://127.0.0.1:7001/_calls')).json()).streamCalls;
  r = await call('GET', `/Items?ParentId=${movieView.Id}&StartIndex=30&Limit=1`);
  const dupe = r.json.Items[0];
  await Promise.all(Array.from({ length: 20 }, () => call('POST', `/Items/${dupe.Id}/PlaybackInfo`, {})));
  const after = (await (await fetch('http://127.0.0.1:7001/_calls')).json()).streamCalls;
  check('20 simultaneous requests share one AIOStreams call', after - before === 1, `${after - before} upstream call(s)`);

  // admin API
  r = await call('GET', '/admin/api/status');
  check('admin status', r.json.configured && r.json.manifest.name === 'AIOStreams (mock)' && r.json.timings.length > 0, `${r.json.timings.length} timings`);
  r = await call('POST', '/admin/api/speedtest', { type: 'movie', id: 'tt1000040' });
  check('speed test', r.json.ok && r.json.count === 4 && r.json.cachedMs < 20, `${r.json.ms}ms upstream, ${r.json.cachedMs}ms cached`);
  r = await call('GET', '/admin/api/status', null, { 'x-emby-authorization': AUTH });
  check('admin status requires sign-in', r.status === 401);

  await call('POST', '/admin/api/settings', { proxyInternal: true });
  console.log(results.join('\n'));
  console.log(failures ? `\n${failures} FAILED` : '\nall passed');
  process.exit(failures ? 1 : 0);
})().catch((e) => { console.log(results.join('\n')); console.error(e); process.exit(1); });
