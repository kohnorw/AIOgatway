'use strict';
// End-to-end test. Expects AIOFin on BASE and the mock AIOStreams running.
//   node test/e2e.js
const BASE = process.env.BASE || 'http://127.0.0.1:8096';
const USER = process.env.TEST_USER || 'admin';
const PASS = process.env.TEST_PASS || 'pw';
const AUTH = 'MediaBrowser Client="Jellyfin Web", Device="Chrome", DeviceId="e2e", Version="12.1.0"';

let token = '';
let failures = 0;
const results = [];

async function call(method, path, body, extraHeaders = {}) {
  const t0 = performance.now();
  const res = await fetch(BASE + path, {
    method, redirect: 'manual',
    headers: { 'content-type': 'application/json', 'x-emby-authorization': token ? `${AUTH}, Token="${token}"` : AUTH, ...extraHeaders },
    body: body ? JSON.stringify(body) : undefined,
  });
  const ms = performance.now() - t0;
  const text = await res.text();
  let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
  return { status: res.status, json, text, ms, headers: res.headers };
}
function check(name, cond, detail = '') {
  results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? `  (${detail})` : ''}`);
  if (!cond) failures++;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ms = (n) => `${n.toFixed(0)}ms`;

// Chrome-like device profile: no AC3/DTS/TrueHD audio, no HEVC.
const CHROME = {
  DirectPlayProfiles: [
    { Container: 'webm', Type: 'Video', VideoCodec: 'vp8,vp9,av1', AudioCodec: 'vorbis,opus' },
    { Container: 'mp4,m4v', Type: 'Video', VideoCodec: 'h264,vp9,av1', AudioCodec: 'aac,mp3,opus,flac' },
    { Container: 'mkv', Type: 'Video', VideoCodec: 'h264,vp9,av1', AudioCodec: 'aac,mp3,opus,flac' },
  ],
  TranscodingProfiles: [{ Container: 'ts', Type: 'Video', AudioCodec: 'aac', VideoCodec: 'h264', Protocol: 'hls' }],
};

(async () => {
  // ── first-run setup ──
  let r0 = await call('GET', '/admin/api/status');
  if (r0.json.setupNeeded) {
    r0 = await call('POST', '/admin/api/setup', { username: USER, password: PASS, aioUrl: process.env.AIO_URL || 'http://127.0.0.1:7001/stremio/abc/def/manifest.json' });
    check('first-run setup', r0.json.ok === true);
    await sleep(300);
  }
  // ── auth ──
  let r = await call('POST', '/Users/AuthenticateByName', { Username: USER, Pw: PASS });
  check('login', r.status === 200 && r.json.AccessToken, `${r.status}`);
  token = r.json.AccessToken;
  const uid = r.json.User.Id;
  r = await call('POST', '/Users/AuthenticateByName', { Username: USER, Pw: 'wrong' });
  check('bad password rejected', r.status === 401);
  r = await call('GET', '/System/Info/Public');
  check('public info reports 12.1.0', r.json.Version === '12.1.0');

  // ── libraries ──
  r = await call('GET', `/Users/${uid}/Views`);
  const views = r.json.Items;
  check('one library per browsable catalog', views.length === 2, views.map((v) => `${v.Name}:${v.CollectionType}`).join(', '));
  const movieView = views.find((v) => v.CollectionType === 'movies');
  const showView = views.find((v) => v.CollectionType === 'tvshows');

  r = await call('GET', `/Users/${uid}/Items?ParentId=${movieView.Id}&StartIndex=0&Limit=20&IncludeItemTypes=Movie&Recursive=true`);
  check('library page 1', r.json.Items.length === 20 && r.json.TotalRecordCount > 20, `${r.json.Items.length} items, total ${r.json.TotalRecordCount}, ${ms(r.ms)}`);
  r = await call('GET', `/Items?ParentId=${movieView.Id}&StartIndex=20&Limit=20`);
  check('library page 2 walks Stremio skip', r.json.Items[0].Name === 'Test Movie 21', r.json.Items[0].Name);
  r = await call('GET', `/Items?ParentId=${movieView.Id}&StartIndex=40&Limit=20`);
  check('last page ends the listing', r.json.Items.length === 5 && r.json.TotalRecordCount === 45, `${r.json.Items.length} items, total ${r.json.TotalRecordCount}`);
  r = await call('GET', `/Items?ParentId=${movieView.Id}&IncludeItemTypes=BoxSet`);
  check('collections tab is empty, not an error', r.status === 200 && r.json.Items.length === 0);
  r = await call('GET', `/Users/${uid}/Items/Latest?ParentId=${showView.Id}&Limit=5`);
  check('home rows (Latest) is a plain array', Array.isArray(r.json) && r.json.length === 5 && r.json[0].Type === 'Series', ms(r.ms));

  // ── search ──
  r = await call('GET', '/Items?searchTerm=movie%2012&IncludeItemTypes=Movie&Recursive=true&Limit=10');
  check('search', r.json.Items.some((i) => i.Name === 'Test Movie 12'), r.json.Items.map((i) => i.Name).join(', '));
  r = await call('GET', '/Search/Hints?searchTerm=show');
  check('search hints', r.json.SearchHints.length > 0, `${r.json.SearchHints.length} hints`);

  // ── movie: open → prefetch → play ──
  r = await call('GET', `/Items?ParentId=${movieView.Id}&Limit=3`);
  const movie = r.json.Items[2];
  r = await call('GET', `/Users/${uid}/Items/${movie.Id}`);
  check('item detail returns fast (does not wait for streams)', r.status === 200 && r.ms < 300, ms(r.ms));
  check('detail has metadata', r.json.RunTimeTicks > 0 && r.json.People.length > 0 && r.json.ImageTags.Primary && r.json.ProviderIds.Imdb, `runtime ${r.json.RunTimeTicks}`);
  await sleep(1500); // the user reads the overview for a moment (mock AIOStreams takes 1.2s)
  r = await call('POST', `/Items/${movie.Id}/PlaybackInfo?UserId=${uid}`, { DeviceProfile: null });
  check('PlaybackInfo after opening a title is instant', r.ms < 100, ms(r.ms));
  const sources = r.json.MediaSources;
  check('P2P-only results are dropped', sources.length === 2, `${sources.length} sources`);
  check('clean version names', /4K DV/.test(sources[0].Name) && /TorBox ⚡/.test(sources[0].Name), sources[0].Name);
  check('second version name', /1080p/.test(sources[1].Name), sources[1].Name);
  const vs = sources[0].MediaStreams.find((s) => s.Type === 'Video');
  const as = sources[0].MediaStreams.find((s) => s.Type === 'Audio');
  const ss = sources[0].MediaStreams.find((s) => s.Type === 'Subtitle');
  check('synthesized video track', vs.Codec === 'hevc' && vs.Height === 2160 && vs.VideoRangeType.startsWith('DOVI'), `${vs.DisplayTitle}`);
  check('synthesized audio track', as.Codec === 'truehd' && as.Channels === 8, `${as.DisplayTitle}`);
  check('external subtitle from AIOStreams', ss && ss.DeliveryMethod === 'External', ss && ss.DisplayTitle);

  // cold lookup for comparison
  r = await call('GET', `/Items?ParentId=${movieView.Id}&StartIndex=10&Limit=1`);
  const cold = r.json.Items[0];
  r = await call('POST', `/Items/${cold.Id}/PlaybackInfo`, {});
  check('cold PlaybackInfo waits only for AIOStreams', r.json.MediaSources.length === 2 && r.ms < 1700, ms(r.ms));

  // LAN/internal source → proxied, with byte ranges for seeking
  r = await call('GET', `/Videos/${movie.Id}/stream.mkv?static=true&MediaSourceId=${sources[1].Id}`, null, { range: 'bytes=0-1023' });
  check('internal-host source is proxied with ranges', r.status === 206 && /^bytes 0-1023\//.test(r.headers.get('content-range')), `${r.status} ${r.headers.get('content-range')}`);
  // native client: direct play via redirect
  await call('POST', '/admin/api/settings', { proxyInternal: false });
  r = await call('GET', `/Videos/${movie.Id}/stream.mkv?static=true&MediaSourceId=${sources[1].Id}&api_key=${token}`);
  check('stream endpoint 302s to the source', r.status === 302 && /sample-h264/.test(r.headers.get('location')), `${r.status} ${ms(r.ms)}`);
  r = await call('GET', `/Videos/${movie.Id}/stream?static=true&MediaSourceId=${movie.Id}`);
  check('stub source id falls back to best stream', r.status === 302, `${r.status}`);

  // browser: direct play h264+aac impossible here (AC3) → HLS fallback
  r = await call('POST', `/Items/${movie.Id}/PlaybackInfo`, { DeviceProfile: CHROME });
  const web = r.json.MediaSources;
  check('browser: unsupported audio gets an HLS fallback', !web[1].SupportsDirectPlay && /main\.m3u8/.test(web[1].TranscodingUrl), web[1].TranscodingUrl);
  r = await call('POST', `/Items/${movie.Id}/PlaybackInfo?MediaSourceId=${sources[1].Id}`, { DeviceProfile: CHROME });
  check('requesting one MediaSourceId returns just that one', r.json.MediaSources.length === 1 && r.json.MediaSources[0].Id === sources[1].Id);

  // subtitles
  r = await call('GET', ss.DeliveryUrl);
  check('subtitle converted to WebVTT', r.status === 200 && r.text.startsWith('WEBVTT') && r.text.includes('00:00:01.000'), r.text.split('\n')[2]);

  // HLS transcode
  const hlsUrl = web[1].TranscodingUrl;
  let t0 = performance.now();
  r = await call('GET', hlsUrl);
  check('HLS playlist', r.status === 200 && r.text.includes('#EXT-X-ENDLIST') && r.text.includes('0.ts'), `${(r.text.match(/\.ts/g) || []).length} segments, ${ms(r.ms)}`);
  const segBase = hlsUrl.replace(/main\.m3u8.*$/, '');
  r = await call('GET', `${segBase}0.ts`);
  check('first HLS segment', r.status === 200 && r.text.length > 10000, `${r.text.length} bytes, ${ms(performance.now() - t0)} from playlist request`);
  t0 = performance.now();
  r = await call('GET', `${segBase}15.ts`);
  check('seek far ahead restarts the transcoder', r.status === 200, `${ms(performance.now() - t0)}`);
  r = await call('DELETE', `/Videos/ActiveEncodings?PlaySessionId=${hlsUrl.match(/hls\/([a-f0-9]{32})\./)[1]}`);
  check('stop transcode', r.status === 204);

  // ── series ──
  r = await call('GET', `/Items/Latest?ParentId=${showView.Id}&Limit=1`);
  const show = r.json[0];
  r = await call('GET', `/Users/${uid}/Items/${show.Id}`);
  check('series detail', r.json.Type === 'Series' && r.json.ChildCount === 2, `${r.json.ChildCount} seasons`);
  r = await call('GET', `/Shows/${show.Id}/Seasons?UserId=${uid}`);
  const seasons = r.json.Items;
  check('seasons', seasons.length === 2 && seasons[0].Name === 'Season 1');
  r = await call('GET', `/Shows/${show.Id}/Episodes?SeasonId=${seasons[1].Id}&UserId=${uid}`);
  const eps = r.json.Items;
  check('episodes of season 2', eps.length === 5 && eps[0].ParentIndexNumber === 2 && eps[0].IndexNumber === 1, eps[0].Name);
  r = await call('GET', `/Users/${uid}/Items?ParentId=${seasons[0].Id}`);
  check('Items?ParentId=season lists episodes (Swiftfin style)', r.json.Items.length === 5 && r.json.Items[0].Type === 'Episode');

  // opening the series warmed S1E1
  await sleep(1400);
  r = await call('GET', `/Shows/${show.Id}/Episodes?Season=1`);
  const s1e1 = r.json.Items[0];
  r = await call('POST', `/Items/${s1e1.Id}/PlaybackInfo`, {});
  check('opening a series warms its first episode', r.ms < 100 && r.json.MediaSources.length === 2, ms(r.ms));

  // playback reporting → resume → next episode prewarm
  const runtime = r.json.MediaSources[0].RunTimeTicks;
  await call('POST', '/Sessions/Playing', { ItemId: s1e1.Id, PositionTicks: 0 });
  await call('POST', '/Sessions/Playing/Progress', { ItemId: s1e1.Id, PositionTicks: 6e9 });
  await sleep(1400);
  const s1e2 = (await call('GET', `/Shows/${show.Id}/Episodes?Season=1`)).json.Items[1];
  r = await call('POST', `/Items/${s1e2.Id}/PlaybackInfo`, {});
  check('next episode is prewarmed while watching', r.ms < 100, ms(r.ms));
  await call('POST', '/Sessions/Playing/Stopped', { ItemId: s1e1.Id, PositionTicks: 6e9 });
  r = await call('GET', `/UserItems/Resume?UserId=${uid}`);
  check('continue watching', r.json.Items.length === 1 && r.json.Items[0].UserData.PlaybackPositionTicks === 6e9, r.json.Items[0] && r.json.Items[0].Name);
  r = await call('GET', `/UserItems/Resume?userId=${uid}&Limit=12&MediaTypes=Video`);
  check('Continue Watching row (MediaTypes=Video)', r.json.Items.length === 1);
  r = await call('GET', `/UserItems/Resume?userId=${uid}&Limit=12&MediaTypes=Audio`);
  check('Continue Listening row is empty', r.json.Items.length === 0, `${r.json.Items.length} items`);
  r = await call('GET', `/UserItems/Resume?userId=${uid}&Limit=12&MediaTypes=Book`);
  check('Continue Reading row is empty', r.json.Items.length === 0, `${r.json.Items.length} items`);
  r = await call('GET', `/Items?Filters=IsResumable&Recursive=true&MediaTypes=Audio`);
  check('resumable audio via /Items is empty', r.json.Items.length === 0);
  r = await call('GET', `/Items/Latest?ParentId=${movieView.Id}&MediaTypes=Audio`);
  check('latest audio is empty', Array.isArray(r.json) && r.json.length === 0);
  await call('POST', '/Sessions/Playing/Stopped', { ItemId: s1e1.Id, PositionTicks: Math.round(runtime * 0.95) });
  r = await call('GET', `/Shows/NextUp?UserId=${uid}`);
  check('next up after finishing an episode', r.json.Items.length === 1 && r.json.Items[0].Id === s1e2.Id, r.json.Items[0] && `${r.json.Items[0].SeriesName} ${r.json.Items[0].Name}`);
  r = await call('GET', `/UserItems/Resume?UserId=${uid}`);
  check('finished episode leaves continue watching', r.json.Items.length === 0);

  // favourites / played
  r = await call('POST', `/UserFavoriteItems/${movie.Id}`);
  check('favourite', r.json.IsFavorite === true);
  r = await call('GET', `/Items?Filters=IsFavorite&Recursive=true`);
  check('favourites list', r.json.Items.length === 1 && r.json.Items[0].Id === movie.Id);
  r = await call('POST', `/UserPlayedItems/${seasons[1].Id}`);
  r = await call('GET', `/Shows/${show.Id}/Episodes?SeasonId=${seasons[1].Id}`);
  check('mark a season watched', r.json.Items.every((e) => e.UserData.Played));

  // images
  r = await call('GET', `/Items/${movie.Id}/Images/Primary?maxWidth=400&tag=x`);
  check('poster redirect picks a smaller TMDB size', r.status === 302 && /\/w500\//.test(r.headers.get('location')), r.headers.get('location'));
  r = await call('GET', `/Items/${eps[0].Id}/Images/Primary`);
  check('episode thumbnail', r.status === 302 && /thumb21/.test(r.headers.get('location')));

  // misc client calls that must not 404
  for (const p of ['/Branding/Configuration', '/Branding/Css', `/DisplayPreferences/usersettings?userId=${uid}&client=emby`, '/Users/Me',
    '/Localization/Cultures', '/QuickConnect/Enabled', `/Users/${uid}/Items/Root`, '/System/Info', '/Plugins', '/Sessions',
    `/Items/${movie.Id}/Similar`, `/Items/${movie.Id}/ThemeMedia`, `/MediaSegments/${movie.Id}`, '/Shows/Upcoming',
    `/Items/${movie.Id}/Intros`, '/LiveTv/Info', `/Users/${uid}/Items/${movie.Id}/SpecialFeatures`, '/emby/System/Info/Public']) {
    r = await call('GET', p);
    check(`GET ${p.split('?')[0]}`, r.status === 200, `${r.status}`);
  }
  r = await call('GET', '/Branding/Configuration');
  check('ElegantFin is the default theme', /ElegantFin/.test(r.json.CustomCss));

  // concurrency: 20 clients ask for the same cold title at once → one upstream call
  const before = (await (await fetch('http://127.0.0.1:7001/_calls')).json()).streamCalls;
  r = await call('GET', `/Items?ParentId=${movieView.Id}&StartIndex=30&Limit=1`);
  const dupe = r.json.Items[0];
  await Promise.all(Array.from({ length: 20 }, () => call('POST', `/Items/${dupe.Id}/PlaybackInfo`, {})));
  const after = (await (await fetch('http://127.0.0.1:7001/_calls')).json()).streamCalls;
  check('20 simultaneous requests share one AIOStreams call', after - before === 1, `${after - before} upstream call(s)`);

  // admin API
  r = await call('GET', '/admin/api/status');
  check('admin status', r.json.configured && r.json.manifest.name === 'AIOStreams (mock)' && r.json.timings.length > 0, `${r.json.timings.length} timings`);
  r = await call('POST', '/admin/api/speedtest', { type: 'movie', id: 'tt1000040' });
  check('speed test', r.json.ok && r.json.count === 2 && r.json.cachedMs < 20, `${r.json.ms}ms upstream, ${r.json.cachedMs}ms cached`);
  r = await call('GET', '/admin/api/status', null, { 'x-emby-authorization': AUTH });
  check('admin status requires sign-in', r.status === 401);

  await call('POST', '/admin/api/settings', { proxyInternal: true });
  console.log(results.join('\n'));
  console.log(failures ? `\n${failures} FAILED` : '\nall passed');
  process.exit(failures ? 1 : 0);
})().catch((e) => { console.log(results.join('\n')); console.error(e); process.exit(1); });
