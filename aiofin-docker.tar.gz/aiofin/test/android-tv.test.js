'use strict';
// Checks that every response Jellyfin for Android TV reads parses with the
// Jellyfin Kotlin SDK it is built on. That SDK is strict: a required field
// that is missing, null or the wrong type makes the whole response fail
// (other apps are lenient, so problems show up only on Android TV).
//
//   node test/android-tv.test.js      (server on BASE, mock AIOStreams running)
//
// The schema is built from the SDK's generated models (fetched with git).
const { execSync } = require('child_process');
const fs = require('fs'); const path = require('path'); const os = require('os');
const SDK_TAG = process.env.SDK_TAG || 'v1.8.12'; // the version jellyfin-androidtv uses
const work = path.join(os.tmpdir(), `jellyfin-sdk-${SDK_TAG}`);
if (!fs.existsSync(path.join(work, 'jellyfin-model'))) {
  execSync(`git clone -q --depth 1 --branch ${SDK_TAG} https://github.com/jellyfin/jellyfin-sdk-kotlin.git ${work}`, { stdio: 'inherit' });
}
const modelDir = path.join(work, 'jellyfin-model/src/commonMain/kotlin-generated/org/jellyfin/sdk/model/api');
process.env.SDK_SCHEMA = path.join(os.tmpdir(), `sdk-schema-${SDK_TAG}.json`);
require('./sdk/schema').build(modelDir, process.env.SDK_SCHEMA);
require('./sdk/check');
