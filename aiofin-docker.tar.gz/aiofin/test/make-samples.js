'use strict';
// Builds the sample videos the tests use (needs ffmpeg and git).
//   node test/make-samples.js
const { execSync } = require('child_process');
const fs = require('fs'); const path = require('path'); const os = require('os');
const D = __dirname; const T = fs.mkdtempSync(path.join(os.tmpdir(), 'aiofin-samples-'));
const run = (c) => execSync(c, { stdio: ['ignore', 'ignore', 'inherit'], cwd: D });
const ff = 'ffmpeg -v error -y';

run(`${ff} -f lavfi -i testsrc2=size=1280x720:rate=24 -f lavfi -i sine=frequency=440:sample_rate=48000 -t 60 -c:v libx264 -preset ultrafast -g 48 -c:a ac3 -ac 6 -b:a 384k sample-h264-ac3.mkv`);
run(`${ff} -f lavfi -i testsrc2=size=1920x1080:rate=24 -f lavfi -i sine=frequency=330:sample_rate=48000 -t 40 -c:v libx265 -preset ultrafast -x265-params log-level=error -c:a aac sample-hevc.mkv`);
run(`${ff} -f lavfi -i testsrc2=size=1280x720:rate=24 -f lavfi -i sine=frequency=300:sample_rate=48000 -f lavfi -i sine=frequency=600:sample_rate=48000 -t 30 -map 0 -map 1 -map 2 -c:v libx264 -preset ultrafast -g 48 -c:a:0 aac -c:a:1 eac3 -ac:a:1 6 -metadata:s:a:0 language=spa -metadata:s:a:1 language=eng -disposition:a:0 default -disposition:a:1 0 sample-multiaudio.mkv`);

const srt = (word) => Array.from({ length: 12 }, (_, i) => { const s = 2 + i * 5; return `${i + 1}\n00:00:${String(s).padStart(2, '0')},500 --> 00:00:${String(s + 3).padStart(2, '0')},250\n${word} ${i + 1}\n`; }).join('\n');
fs.writeFileSync(path.join(T, 'en.srt'), srt('Line')); fs.writeFileSync(path.join(T, 'es.srt'), srt('Línea'));
run(`${ff} -i sample-h264-ac3.mkv -i ${T}/en.srt -i ${T}/es.srt -map 0:v -map 0:a -map 1 -map 2 -c:v copy -c:a copy -c:s srt -metadata:s:s:0 language=eng -metadata:s:s:0 title="English SDH" -metadata:s:s:1 language=spa sample-subs.mkv`);

// Styled ASS
fs.writeFileSync(path.join(T, 'styled.ass'), `[Script Info]
ScriptType: v4.00+
PlayResX: 1280
PlayResY: 720

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,DejaVu Sans,48,&H0000FFFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,3,0,2,10,10,40,1
Style: Sign,DejaVu Serif,36,&H00FF00FF,&H000000FF,&H00000000,&H00000000,0,1,0,0,100,100,0,0,1,2,0,8,10,10,30,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:02.50,0:00:05.25,Default,,0,0,0,,Styled line 1
Dialogue: 0,0:00:17.50,0:00:20.25,Sign,,0,0,0,,{\\pos(640,100)}Sign at top 2
Dialogue: 0,0:00:32.50,0:00:35.25,Default,,0,0,0,,Styled line 3
Dialogue: 0,0:00:47.50,0:00:50.25,Default,,0,0,0,,Styled line 4
`);

// PGS (.sup): a white bar shown at 5, 20, 35 and 50 s for 3 s each.
{
  const W = 1280, H = 720, OW = 400, OH = 60, X = 440, Y = 600;
  const seg = (type, pts, p) => { const h = Buffer.alloc(13); h.write('PG', 0, 'latin1'); h.writeUInt32BE(Math.round(pts * 90000), 2); h.writeUInt8(type, 10); h.writeUInt16BE(p.length, 11); return Buffer.concat([h, p]); };
  const pcs = (num, state, objs) => { const b = Buffer.alloc(11 + objs * 8); b.writeUInt16BE(W, 0); b.writeUInt16BE(H, 2); b.writeUInt8(0x10, 4); b.writeUInt16BE(num, 5); b.writeUInt8(state, 7); b.writeUInt8(objs, 10); if (objs) { b.writeUInt16BE(X, 15); b.writeUInt16BE(Y, 17); } return b; };
  const wds = () => { const b = Buffer.alloc(10); b.writeUInt8(1, 0); b.writeUInt16BE(X, 2); b.writeUInt16BE(Y, 4); b.writeUInt16BE(OW, 6); b.writeUInt16BE(OH, 8); return b; };
  const pds = () => Buffer.from([0, 0, 1, 235, 128, 128, 255]);
  const ods = () => { const rle = Buffer.concat(Array.from({ length: OH }, () => Buffer.from([0, 0xC0 | (OW >> 8), OW & 0xff, 1, 0, 0]))); const b = Buffer.alloc(11); b.writeUInt8(0xC0, 3); const len = rle.length + 4; b.writeUInt8((len >> 16) & 0xff, 4); b.writeUInt16BE(len & 0xffff, 5); b.writeUInt16BE(OW, 7); b.writeUInt16BE(OH, 9); return Buffer.concat([b, rle]); };
  const out = []; let n = 0;
  for (const t of [5, 20, 35, 50]) {
    out.push(seg(0x16, t, pcs(n++, 0x80, 1)), seg(0x17, t, wds()), seg(0x14, t, pds()), seg(0x15, t, ods()), seg(0x80, t, Buffer.alloc(0)));
    out.push(seg(0x16, t + 3, pcs(n++, 0, 0)), seg(0x17, t + 3, wds()), seg(0x80, t + 3, Buffer.alloc(0)));
  }
  fs.writeFileSync(path.join(T, 'test.sup'), Buffer.concat(out));
}

// VobSub sample from libbitsub's test files.
execSync(`git clone -q --depth 1 https://github.com/altqx/libbitsub.git ${T}/lbs`, { stdio: 'ignore' });
const font = ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'].find((f) => fs.existsSync(f));
run(`${ff} -i sample-subs.mkv -i ${T}/styled.ass -i ${T}/test.sup -i ${T}/lbs/src/testfiles/vobsub.idx -map 0:v -map 0:a -map 0:s:0 -map 1 -map 2 -map 3 -c copy -metadata:s:s:1 language=eng -metadata:s:s:1 title="Signs & Songs" -metadata:s:s:2 language=eng -metadata:s:s:2 title="PGS" -metadata:s:s:3 language=fre ${font ? `-attach ${font} -metadata:s:t mimetype=application/x-truetype-font` : ''} sample-allsubs.mkv`);
fs.rmSync(T, { recursive: true, force: true });
console.log('samples ready:', fs.readdirSync(D).filter((f) => f.startsWith('sample-')).join(', '));
