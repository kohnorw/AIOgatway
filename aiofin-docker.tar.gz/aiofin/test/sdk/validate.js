// Validate JSON against the Jellyfin Kotlin SDK models, with the SDK's own
// JSON rules (unknown keys ignored, unknown enum *properties* fall back to
// their default, everything else strict).
const schema = JSON.parse(require('fs').readFileSync(process.env.SDK_SCHEMA, 'utf8'));
const UUID_RE = /^[0-9a-f]{32}$|^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function splitGeneric(t) { // "Map<A, List<B>>" → ['A','List<B>']
  const out = []; let depth = 0; let cur = '';
  for (const ch of t) { if (ch === '<') depth++; if (ch === '>') depth--; if (ch === ',' && depth === 0) { out.push(cur.trim()); cur = ''; } else cur += ch; }
  out.push(cur.trim()); return out;
}
function check(type, v, p, errs, field) {
  type = type.replace(/@Serializable\([^)]*\)\s*/g, '').trim();
  const nullable = type.endsWith('?'); type = type.replace(/\?$/, '');
  if (v === null || v === undefined) { if (!nullable && !(field && (field.nullable || field.hasDefault))) errs.push(`${p}: null/missing but required (${type})`); return; }
  let m;
  if ((m = type.match(/^List<(.+)>$/s))) { if (!Array.isArray(v)) return errs.push(`${p}: expected list`); v.forEach((x, i) => check(m[1], x, `${p}[${i}]`, errs)); return; }
  if ((m = type.match(/^Map<(.+)>$/s))) {
    if (typeof v !== 'object' || Array.isArray(v)) return errs.push(`${p}: expected object/map`);
    const [k, val] = splitGeneric(m[1]);
    for (const [kk, vv] of Object.entries(v)) {
      if (schema.enums[k] && !schema.enums[k].includes(kk)) errs.push(`${p}: map key "${kk}" not a ${k}`);
      check(val, vv, `${p}.${kk}`, errs);
    }
    return;
  }
  if (/^(String)$/.test(type)) { if (typeof v !== 'string') errs.push(`${p}: expected string, got ${typeof v}`); return; }
  if (/^(Int|Long)$/.test(type)) { if (typeof v !== 'number' || !Number.isInteger(v)) errs.push(`${p}: expected integer, got ${JSON.stringify(v)}`); return; }
  if (/^(Double|Float)$/.test(type)) { if (typeof v !== 'number') errs.push(`${p}: expected number, got ${typeof v}`); return; }
  if (type === 'Boolean') { if (typeof v !== 'boolean') errs.push(`${p}: expected boolean, got ${JSON.stringify(v)}`); return; }
  if (/UUID/.test(type)) { if (typeof v !== 'string' || !UUID_RE.test(v)) errs.push(`${p}: invalid UUID ${JSON.stringify(v)}`); return; }
  if (/DateTime|Instant/.test(type)) { if (typeof v !== 'string' || isNaN(Date.parse(v))) errs.push(`${p}: invalid date ${JSON.stringify(v)}`); return; }
  if (schema.enums[type]) {
    if (typeof v !== 'string' || !schema.enums[type].includes(v)) {
      // coerceInputValues rescues an unknown enum only for a property with a default
      if (!(field && (field.nullable || field.hasDefault))) errs.push(`${p}: "${v}" is not a valid ${type}`);
    }
    return;
  }
  if (schema.classes[type]) {
    if (typeof v !== 'object' || Array.isArray(v)) return errs.push(`${p}: expected ${type} object`);
    for (const [name, f] of Object.entries(schema.classes[type])) {
      check(f.type + (f.nullable ? '?' : ''), v[name], `${p}.${name}`, errs, f);
    }
    return;
  }
  // JsonElement/Any/unknown: accept
}
function validate(type, value) { const errs = []; check(type, value, type, errs); return errs; }
module.exports = { validate, schema };
