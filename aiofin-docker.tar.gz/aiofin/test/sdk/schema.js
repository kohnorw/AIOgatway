// Build a schema from the Jellyfin Kotlin SDK's generated models.
const fs = require('fs'); const path = require('path');
function build(dir, outFile) {
const schema = { classes: {}, enums: {} };
for (const f of fs.readdirSync(dir).filter((n) => n.endsWith('.kt'))) {
  const src = fs.readFileSync(path.join(dir, f), 'utf8');
  let m;
  if ((m = src.match(/public enum class (\w+)\s*\(/))) {
    schema.enums[m[1]] = [...src.matchAll(/@SerialName\("([^"]*)"\)\s*\n\s*[A-Z_0-9]+\(/g)].map((x) => x[1]);
    continue;
  }
  if ((m = src.match(/public data class (\w+)\s*\(([\s\S]*?)\n\)(?:\s*:[^\n]*)?\s*(?:\{|$)/m))) {
    const fields = {};
    const body = m[2];
    const re = /@SerialName\("([^"]+)"\)\s*\n((?:\s*@[^\n]*\n)*)\s*(?:public|override) val `?\w+`?:\s*([^\n]+?)(\s*=\s*[^\n,]+)?,?\s*$/gm;
    let x;
    while ((x = re.exec(body))) {
      let type = x[3].trim().replace(/,$/, '');
      const nullable = type.endsWith('?');
      type = type.replace(/\?$/, '');
      fields[x[1]] = { type, nullable, hasDefault: !!x[4] };
    }
    schema.classes[m[1]] = fields;
  }
}
fs.writeFileSync(outFile, JSON.stringify(schema));
  return schema;
}
module.exports = { build };
