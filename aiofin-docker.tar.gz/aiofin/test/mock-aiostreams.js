'use strict';
// Minimal stand-in for an AIOStreams instance, for local testing.
//   node test/mock-aiostreams.js        (port 7001, STREAM_DELAY_MS=1200)
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = parseInt(process.env.MOCK_PORT || '7001', 10);
const DELAY = parseInt(process.env.STREAM_DELAY_MS || '1200', 10);
const BASE = `http://127.0.0.1:${PORT}/stremio/abc/def`;
let streamCalls = 0;
let lastSubExtras = null;

const movies = Array.from({ length: 45 }, (_, i) => ({
  id: `tt${String(1000000 + i)}`, type: 'movie', name: `Test Movie ${i + 1}`,
  poster: `https://image.tmdb.org/t/p/original/poster${i}.jpg`, background: `https://image.tmdb.org/t/p/original/bg${i}.jpg`,
  releaseInfo: String(2000 + (i % 25)), imdbRating: '7.4', description: `Overview for movie ${i + 1}`,
}));
const shows = Array.from({ length: 12 }, (_, i) => ({
  id: `tt${String(2000000 + i)}`, type: 'series', name: `Test Show ${i + 1}`,
  poster: `https://image.tmdb.org/t/p/original/sposter${i}.jpg`, background: `https://image.tmdb.org/t/p/original/sbg${i}.jpg`,
  releaseInfo: '2019–', imdbRating: '8.1', description: `Overview for show ${i + 1}`,
}));

// Shows with confusable names, reachable through search only. Their streams
// mimic text-searching indexers: right and wrong shows/episodes mixed together.
const extraShows = [
  { id: 'tt1520211', type: 'series', name: 'The Walking Dead', releaseInfo: '2010–2022', poster: 'https://image.tmdb.org/t/p/original/twd.jpg' },
  { id: 'tt3743822', type: 'series', name: 'Fear the Walking Dead', releaseInfo: '2015–2023', poster: 'https://image.tmdb.org/t/p/original/ftwd.jpg' },
  { id: 'tt0436992', type: 'series', name: 'Doctor Who', releaseInfo: '2005–2022', poster: 'https://image.tmdb.org/t/p/original/dw.jpg' },
];
// A movie whose file has subtitle tracks inside it (English SDH + Spanish).
const extraMovies = [
  { id: 'tt9000001', type: 'movie', name: 'Subtitle Test Movie', releaseInfo: '2024', poster: 'https://image.tmdb.org/t/p/original/stm.jpg' },
  // SRT + styled ASS (with an embedded font) + PGS + VobSub, all inside the file.
  { id: 'tt9000002', type: 'movie', name: 'All Subtitles Movie', releaseInfo: '2024', poster: 'https://image.tmdb.org/t/p/original/asm.jpg' },
  // Same file as tt9000001, served slowly (2 MB/s) like a slow debrid link.
  { id: 'tt9000003', type: 'movie', name: 'Slow Link Movie', releaseInfo: '2024', poster: 'https://image.tmdb.org/t/p/original/slm.jpg' },
];
const MIXED = {
  tt9000001: [{ fn: 'Subtitle.Test.Movie.2024.1080p.WEB-DL.mkv', file: 'sample-subs.mkv' }],
  tt9000002: [{ fn: 'All.Subtitles.Movie.2024.1080p.BluRay.x264-GRP.mkv', file: 'sample-allsubs.mkv' }],
  tt9000003: [{ fn: 'Slow.Link.Movie.2024.1080p.WEB-DL.mkv', file: 'sample-subs.mkv', slow: true }],
  'tt1520211:1:1': ['The.Walking.Dead.S01E01.1080p.BluRay.x264-GRP.mkv', 'Fear.the.Walking.Dead.S01E01.1080p.WEB-DL.mkv', 'The.Walking.Dead.Daryl.Dixon.S01E01.1080p.mkv', 'The.Walking.Dead.S01E10.1080p.mkv', 'TWD.S01E01.720p.mkv', 'The.Walking.Dead.S01.COMPLETE.1080p.mkv'],
  'tt3743822:1:1': ['Fear.the.Walking.Dead.S01E01.Pilot.1080p.mkv', 'The.Walking.Dead.S01E01.1080p.BluRay.mkv', 'Walking.Dead.S01E01.720p.mkv'],
  'tt0436992:1:1': ['Doctor.Who.2005.S01E01.Rose.1080p.mkv', 'Doctor.Who.1963.S01E01.An.Unearthly.Child.mkv', 'Doctor.Who.S01E01.720p.mkv'],
  // Only wrong results: they're kept (so there's something to play) but marked ⚠.
  'tt0436992:1:2': ['Doctor.Who.1963.S01E02.The.Cave.of.Skulls.mkv'],
};

const manifest = {
  id: 'com.aiostreams.mock', name: 'AIOStreams (mock)', version: '2.0.0', description: 'test',
  resources: ['catalog', 'meta', 'stream', 'subtitles'], types: ['movie', 'series'], idPrefixes: ['tt'],
  catalogs: [
    { type: 'movie', id: 'mock.popular', name: 'Popular Movies', extra: [{ name: 'skip' }, { name: 'search' }] },
    { type: 'series', id: 'mock.shows', name: 'Popular Shows', extra: [{ name: 'skip' }, { name: 'search' }] },
    { type: 'movie', id: 'mock.searchonly', name: 'Search', extra: [{ name: 'search', isRequired: true }] },
  ],
};

// Air dates relative to today (calendar dates at 00:00 UTC, like Stremio metadata).
const dayUtc = (offset) => { const d = new Date(); return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + offset)).toISOString(); };
const FUTURE = { 'tt2000000:2:3': 0, 'tt2000000:2:4': 7, 'tt2000000:2:5': 90, 'tt2000001:2:5': 3 };

function seriesMeta(s) {
  const videos = [];
  for (let season = 1; season <= 2; season++) for (let ep = 1; ep <= 5; ep++) {
    const id = `${s.id}:${season}:${ep}`;
    videos.push({ id, season, episode: ep, name: `S${season} Episode ${ep}`, released: id in FUTURE ? dayUtc(FUTURE[id]) : '2020-01-01T00:00:00.000Z', thumbnail: `https://image.tmdb.org/t/p/original/thumb${season}${ep}.jpg`, overview: 'An episode.' });
  }
  return { ...s, videos, runtime: '45 min', genres: ['Drama'], cast: ['A Person'], logo: 'https://example.com/logo.png' };
}

function send(res, obj) { const b = JSON.stringify(obj); res.writeHead(200, { 'content-type': 'application/json' }); res.end(b); }

// ?slow=1 serves at ~2 MB/s, like a slow debrid link.
function throttled(stream, res, slow) {
  if (!slow) return stream.pipe(res);
  const rate = 2 * 1024 * 1024; let sent = 0; const t0 = Date.now();
  stream.on('data', (chunk) => {
    sent += chunk.length;
    const ahead = sent / rate * 1000 - (Date.now() - t0);
    if (!res.write(chunk) || ahead > 0) { stream.pause(); setTimeout(() => stream.resume(), Math.max(ahead, 5)); }
  });
  stream.on('end', () => res.end());
  res.on('close', () => stream.destroy());
}

function serveFile(req, res, file, slow) {
  const st = fs.statSync(file);
  const range = req.headers.range;
  if (range) {
    const [s, e] = range.replace('bytes=', '').split('-');
    const start = parseInt(s, 10); const end = e ? parseInt(e, 10) : st.size - 1;
    res.writeHead(206, { 'content-type': 'video/x-matroska', 'content-range': `bytes ${start}-${end}/${st.size}`, 'accept-ranges': 'bytes', 'content-length': end - start + 1 });
    throttled(fs.createReadStream(file, { start, end, highWaterMark: 64 * 1024 }), res, slow);
  } else {
    res.writeHead(200, { 'content-type': 'video/x-matroska', 'content-length': st.size, 'accept-ranges': 'bytes' });
    throttled(fs.createReadStream(file, { highWaterMark: 64 * 1024 }), res, slow);
  }
}

http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  const p = decodeURIComponent(u.pathname);
  if (p.endsWith('/manifest.json') && !p.startsWith('/os/')) return send(res, manifest);
  let m;
  if ((m = p.match(/\/catalog\/(\w+)\/([^/]+?)(?:\/(.+))?\.json$/))) {
    const [, type, id, extra] = m;
    const ex = Object.fromEntries(new URLSearchParams(extra || ''));
    let list = type === 'movie' ? movies : shows;
    if (ex.search) list = (type === 'movie' ? [...movies, ...extraMovies] : [...shows, ...extraShows]).filter((x) => x.name.toLowerCase().includes(ex.search.toLowerCase()));
    else if (id === 'mock.searchonly') list = [];
    const skip = parseInt(ex.skip || '0', 10);
    return send(res, { metas: list.slice(skip, skip + 20) });
  }
  if ((m = p.match(/\/meta\/(\w+)\/([^/]+)\.json$/))) {
    const [, type, id] = m;
    if (type === 'movie') { const x = [...movies, ...extraMovies].find((y) => y.id === id); return send(res, { meta: x ? { ...x, runtime: '1h 2min', genres: ['Action'], cast: ['Someone'], director: ['Director X'], trailers: [{ source: 'abc' }] } : null }); }
    const s = [...shows, ...extraShows].find((y) => y.id === id); return send(res, { meta: s ? seriesMeta(s) : null });
  }
  if ((m = p.match(/\/stream\/(\w+)\/([^/]+)\.json$/)) && MIXED[decodeURIComponent(m[2])]) {
    streamCalls++;
    const names = MIXED[decodeURIComponent(m[2])];
    return setTimeout(() => send(res, { streams: names.map((e, i) => {
      const fn = typeof e === 'string' ? e : e.fn; const file = typeof e === 'string' ? 'sample-h264-ac3.mkv' : e.file;
      return { name: '[RD⚡] AIOStreams', description: fn, url: `http://127.0.0.1:${PORT}/files/${file}?mixed=${encodeURIComponent(m[2])}&i=${i}${e.slow ? '&slow=1' : ''}`, behaviorHints: { filename: fn, videoSize: 2_000_000_000 + i } };
    }) }), 200);
  }
  if ((m = p.match(/\/stream\/(\w+)\/([^/]+)\.json$/))) {
    streamCalls++;
    const ua = req.headers['user-agent'];
    setTimeout(() => send(res, { streams: [
      { name: '[TB⚡] AIOStreams\n2160p', description: 'Test.Movie.2160p.BluRay.REMUX.HEVC.DV.TrueHD.Atmos.7.1-GRP\n💾 58.2 GB 🇬🇧 English', url: `http://127.0.0.1:${PORT}/files/sample-hevc.mkv`,
        behaviorHints: { filename: 'Test.Movie.2160p.BluRay.REMUX.HEVC.DV.TrueHD.Atmos.7.1-GRP.mkv', videoSize: 62491234567, bingeGroup: 'x' },
        streamData: ua === 'AIOStreams/1.0' ? { type: 'debrid', addon: 'Comet', indexer: 'Torrentio', service: { id: 'torbox', cached: true } } : undefined },
      { name: '[RD⚡] 1080p', description: 'Test.Movie.1080p.WEB-DL.DDP5.1.H.264-GRP\n💾 6.1 GB', url: `http://127.0.0.1:${PORT}/files/sample-h264-ac3.mkv`,
        behaviorHints: { filename: 'Test.Movie.1080p.WEB-DL.DDP5.1.H.264-GRP.mkv', videoSize: 6543210000 } },
      // Names that say nothing about audio: the server has to find out for itself.
      { name: '[RD⚡] 720p', description: 'Test.Movie.720p.WEB.x264-NOAUDIOTAG', url: `http://127.0.0.1:${PORT}/files/sample-h264-ac3.mkv?n=3`,
        behaviorHints: { filename: 'Test.Movie.720p.WEB.x264-NOAUDIOTAG.mkv' } },
      { name: '[RD⚡] 720p MULTi', description: 'Test.Movie.720p.MULTi.WEB-GRP', url: `http://127.0.0.1:${PORT}/files/sample-multiaudio.mkv`,
        behaviorHints: { filename: 'Test.Movie.720p.MULTi.WEB-GRP.mkv' } },
      { name: 'P2P only', infoHash: 'abcdef0123456789abcdef0123456789abcdef01' },
    ] }), DELAY);
    return;
  }
  if (!p.startsWith('/os/') && (m = p.match(/\/subtitles\/(\w+)\/([^/]+)\.json$/))) {
    return send(res, { subtitles: [{ id: '1', url: `http://127.0.0.1:${PORT}/subs/en.srt`, lang: 'eng' }] });
  }
  // Stand-in for the OpenSubtitles v3 Stremio add-on (same response shape).
  if ((m = p.match(/^\/os\/subtitles\/(\w+)\/([^/]+?)(?:\/([^/]+))?\.json$/))) {
    const extra = Object.fromEntries(new URLSearchParams(m[3] || ''));
    if (m[3]) lastSubExtras = extra;
    const subs = [];
    // Like OpenSubtitles: a subtitle made for this exact file (by hash) comes first.
    if (extra.videoHash) subs.push({ id: 'os-hash', url: `http://127.0.0.1:${PORT}/subs/en.srt?os=hash-${extra.videoHash}`, lang: 'eng' });
    // Ranking test entries: an AI translation and an SDH one listed first, a forced one, and one made for the release.
    subs.push({ id: 'os-ai', url: `http://127.0.0.1:${PORT}/subs/en.srt?os=ai`, lang: 'eng', title: 'English (AI translated)', ai_translated: true });
    subs.push({ id: 'os-sdh', url: `http://127.0.0.1:${PORT}/subs/en.srt?os=sdh`, lang: 'eng', filename: 'Some.Other.Release.SDH.srt', hearing_impaired: true });
    subs.push({ id: 'os-forced', url: `http://127.0.0.1:${PORT}/subs/en.srt?os=forced`, lang: 'eng', filename: 'Some.Release.FORCED.srt' });
    if (extra.filename) subs.push({ id: 'os-release', url: `http://127.0.0.1:${PORT}/subs/en.srt?os=release`, lang: 'eng', filename: extra.filename.replace(/\.mkv$/i, '.srt') });
    if (m[2].startsWith('tt9000002')) {
      // Short list so every kind is visible under the 8-per-language cap.
      subs.push({ id: 'os-plain', url: `http://127.0.0.1:${PORT}/subs/en.srt?os=plain`, lang: 'eng' });
    } else {
      subs.push({ id: 'os-en-latin1', url: `http://127.0.0.1:${PORT}/subs/latin1.srt`, lang: 'eng', SubEncoding: 'CP1252' });
      for (let i = 0; i < 12; i++) subs.push({ id: `os-en-${i}`, url: `http://127.0.0.1:${PORT}/subs/en.srt?os=${i}`, lang: 'eng', SubEncoding: 'UTF-8' });
    }
    subs.push({ id: 'os-es', url: `http://127.0.0.1:${PORT}/subs/en.srt?os=es`, lang: 'spa' });
    subs.push({ id: 'os-pb', url: `http://127.0.0.1:${PORT}/subs/en.srt?os=pb`, lang: 'pob' });
    return send(res, { subtitles: subs });
  }
  if (p === '/os/manifest.json') return send(res, { id: 'org.stremio.opensubtitlesv3', name: 'OpenSubtitles v3', resources: ['subtitles'], types: ['movie', 'series'], catalogs: [] });
  // An old-style subtitle file: Windows-1252, CRLF, ASS position code, font tag.
  if (p === '/subs/latin1.srt') {
    res.writeHead(200, { 'content-type': 'application/octet-stream' });
    return res.end(Buffer.concat([Buffer.from('1\r\n00:00:01,000 --> 00:00:03,000\r\n{\\an8}<font color="#fff">Caf'), Buffer.from([0xe9]), Buffer.from(' na'), Buffer.from([0xef]), Buffer.from('ve</font>\r\n')]));
  }
  if (p === '/subs/en.srt') { res.writeHead(200, { 'content-type': 'text/plain' }); return res.end('1\n00:00:01,000 --> 00:00:04,000\nHello there\n\n2\n00:00:05,000 --> 00:00:07,500\nGeneral Kenobi\n'); }
  if (p.startsWith('/files/')) return serveFile(req, res, path.join(__dirname, path.basename(p)), u.searchParams.get('slow') === '1');
  if (p === '/_calls') return send(res, { streamCalls, lastSubExtras });
  res.writeHead(404); res.end();
}).listen(PORT, () => console.log(`mock AIOStreams on ${BASE}/manifest.json (stream delay ${DELAY}ms)`));
