'use strict';
// Minimal stand-in for an AIOStreams instance, for local testing.
//   node test/mock-aiostreams.js        (port 7001, STREAM_DELAY_MS=1200)
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = parseInt(process.env.MOCK_PORT || '7001', 10);
const DELAY = parseInt(process.env.STREAM_DELAY_MS || '1200', 10);
const BASE = `http://127.0.0.1:${PORT}/stremio/abc/def`;
let streamCalls = 0;

const movies = Array.from({ length: 45 }, (_, i) => ({
  id: `tt${String(1000000 + i)}`, type: 'movie', name: `Test Movie ${i + 1}`,
  poster: `https://image.tmdb.org/t/p/original/poster${i}.jpg`, background: `https://image.tmdb.org/t/p/original/bg${i}.jpg`,
  releaseInfo: String(2000 + (i % 25)), imdbRating: '7.4', description: `Overview for movie ${i + 1}`,
}));
const shows = Array.from({ length: 12 }, (_, i) => ({
  id: `tt${String(2000000 + i)}`, type: 'series', name: `Test Show ${i + 1}`,
  poster: `https://image.tmdb.org/t/p/original/sposter${i}.jpg`, background: `https://image.tmdb.org/t/p/original/sbg${i}.jpg`,
  releaseInfo: '2019–', imdbRating: '8.1', description: `Overview for show ${i + 1}`,
}));

const manifest = {
  id: 'com.aiostreams.mock', name: 'AIOStreams (mock)', version: '2.0.0', description: 'test',
  resources: ['catalog', 'meta', 'stream', 'subtitles'], types: ['movie', 'series'], idPrefixes: ['tt'],
  catalogs: [
    { type: 'movie', id: 'mock.popular', name: 'Popular Movies', extra: [{ name: 'skip' }, { name: 'search' }] },
    { type: 'series', id: 'mock.shows', name: 'Popular Shows', extra: [{ name: 'skip' }, { name: 'search' }] },
    { type: 'movie', id: 'mock.searchonly', name: 'Search', extra: [{ name: 'search', isRequired: true }] },
  ],
};

// Air dates relative to today (calendar dates at 00:00 UTC, like Stremio metadata).
const dayUtc = (offset) => { const d = new Date(); return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + offset)).toISOString(); };
const FUTURE = { 'tt2000000:2:3': 0, 'tt2000000:2:4': 7, 'tt2000000:2:5': 90, 'tt2000001:2:5': 3 };

function seriesMeta(s) {
  const videos = [];
  for (let season = 1; season <= 2; season++) for (let ep = 1; ep <= 5; ep++) {
    const id = `${s.id}:${season}:${ep}`;
    videos.push({ id, season, episode: ep, name: `S${season} Episode ${ep}`, released: id in FUTURE ? dayUtc(FUTURE[id]) : '2020-01-01T00:00:00.000Z', thumbnail: `https://image.tmdb.org/t/p/original/thumb${season}${ep}.jpg`, overview: 'An episode.' });
  }
  return { ...s, videos, runtime: '45 min', genres: ['Drama'], cast: ['A Person'], logo: 'https://example.com/logo.png' };
}

function send(res, obj) { const b = JSON.stringify(obj); res.writeHead(200, { 'content-type': 'application/json' }); res.end(b); }

function serveFile(req, res, file) {
  const st = fs.statSync(file);
  const range = req.headers.range;
  if (range) {
    const [s, e] = range.replace('bytes=', '').split('-');
    const start = parseInt(s, 10); const end = e ? parseInt(e, 10) : st.size - 1;
    res.writeHead(206, { 'content-type': 'video/x-matroska', 'content-range': `bytes ${start}-${end}/${st.size}`, 'accept-ranges': 'bytes', 'content-length': end - start + 1 });
    fs.createReadStream(file, { start, end }).pipe(res);
  } else {
    res.writeHead(200, { 'content-type': 'video/x-matroska', 'content-length': st.size, 'accept-ranges': 'bytes' });
    fs.createReadStream(file).pipe(res);
  }
}

http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  const p = decodeURIComponent(u.pathname);
  if (p.endsWith('/manifest.json') && !p.startsWith('/os/')) return send(res, manifest);
  let m;
  if ((m = p.match(/\/catalog\/(\w+)\/([^/]+?)(?:\/(.+))?\.json$/))) {
    const [, type, id, extra] = m;
    const ex = Object.fromEntries(new URLSearchParams(extra || ''));
    let list = type === 'movie' ? movies : shows;
    if (ex.search) list = list.filter((x) => x.name.toLowerCase().includes(ex.search.toLowerCase()));
    else if (id === 'mock.searchonly') list = [];
    const skip = parseInt(ex.skip || '0', 10);
    return send(res, { metas: list.slice(skip, skip + 20) });
  }
  if ((m = p.match(/\/meta\/(\w+)\/([^/]+)\.json$/))) {
    const [, type, id] = m;
    if (type === 'movie') { const x = movies.find((y) => y.id === id); return send(res, { meta: x ? { ...x, runtime: '1h 2min', genres: ['Action'], cast: ['Someone'], director: ['Director X'], trailers: [{ source: 'abc' }] } : null }); }
    const s = shows.find((y) => y.id === id); return send(res, { meta: s ? seriesMeta(s) : null });
  }
  if ((m = p.match(/\/stream\/(\w+)\/([^/]+)\.json$/))) {
    streamCalls++;
    const ua = req.headers['user-agent'];
    setTimeout(() => send(res, { streams: [
      { name: '[TB⚡] AIOStreams\n2160p', description: 'Test.Movie.2160p.BluRay.REMUX.HEVC.DV.TrueHD.Atmos.7.1-GRP\n💾 58.2 GB 🇬🇧 English', url: `http://127.0.0.1:${PORT}/files/sample-hevc.mkv`,
        behaviorHints: { filename: 'Test.Movie.2160p.BluRay.REMUX.HEVC.DV.TrueHD.Atmos.7.1-GRP.mkv', videoSize: 62491234567, bingeGroup: 'x' },
        streamData: ua === 'AIOStreams/1.0' ? { type: 'debrid', addon: 'Comet', indexer: 'Torrentio', service: { id: 'torbox', cached: true } } : undefined },
      { name: '[RD⚡] 1080p', description: 'Test.Movie.1080p.WEB-DL.DDP5.1.H.264-GRP\n💾 6.1 GB', url: `http://127.0.0.1:${PORT}/files/sample-h264-ac3.mkv`,
        behaviorHints: { filename: 'Test.Movie.1080p.WEB-DL.DDP5.1.H.264-GRP.mkv', videoSize: 6543210000 } },
      // Names that say nothing about audio: the server has to find out for itself.
      { name: '[RD⚡] 720p', description: 'Test.Movie.720p.WEB.x264-NOAUDIOTAG', url: `http://127.0.0.1:${PORT}/files/sample-h264-ac3.mkv?n=3`,
        behaviorHints: { filename: 'Test.Movie.720p.WEB.x264-NOAUDIOTAG.mkv' } },
      { name: '[RD⚡] 720p MULTi', description: 'Test.Movie.720p.MULTi.WEB-GRP', url: `http://127.0.0.1:${PORT}/files/sample-multiaudio.mkv`,
        behaviorHints: { filename: 'Test.Movie.720p.MULTi.WEB-GRP.mkv' } },
      { name: 'P2P only', infoHash: 'abcdef0123456789abcdef0123456789abcdef01' },
    ] }), DELAY);
    return;
  }
  if (!p.startsWith('/os/') && (m = p.match(/\/subtitles\/(\w+)\/([^/]+)\.json$/))) {
    return send(res, { subtitles: [{ id: '1', url: `http://127.0.0.1:${PORT}/subs/en.srt`, lang: 'eng' }] });
  }
  // Stand-in for the OpenSubtitles v3 Stremio add-on (same response shape).
  if ((m = p.match(/^\/os\/subtitles\/(\w+)\/([^/]+)\.json$/))) {
    const subs = [];
    subs.push({ id: 'os-en-latin1', url: `http://127.0.0.1:${PORT}/subs/latin1.srt`, lang: 'eng', SubEncoding: 'CP1252' });
    for (let i = 0; i < 12; i++) subs.push({ id: `os-en-${i}`, url: `http://127.0.0.1:${PORT}/subs/en.srt?os=${i}`, lang: 'eng', SubEncoding: 'UTF-8' });
    subs.push({ id: 'os-es', url: `http://127.0.0.1:${PORT}/subs/en.srt?os=es`, lang: 'spa' });
    subs.push({ id: 'os-pb', url: `http://127.0.0.1:${PORT}/subs/en.srt?os=pb`, lang: 'pob' });
    return send(res, { subtitles: subs });
  }
  if (p === '/os/manifest.json') return send(res, { id: 'org.stremio.opensubtitlesv3', name: 'OpenSubtitles v3', resources: ['subtitles'], types: ['movie', 'series'], catalogs: [] });
  // An old-style subtitle file: Windows-1252, CRLF, ASS position code, font tag.
  if (p === '/subs/latin1.srt') {
    res.writeHead(200, { 'content-type': 'application/octet-stream' });
    return res.end(Buffer.concat([Buffer.from('1\r\n00:00:01,000 --> 00:00:03,000\r\n{\\an8}<font color="#fff">Caf'), Buffer.from([0xe9]), Buffer.from(' na'), Buffer.from([0xef]), Buffer.from('ve</font>\r\n')]));
  }
  if (p === '/subs/en.srt') { res.writeHead(200, { 'content-type': 'text/plain' }); return res.end('1\n00:00:01,000 --> 00:00:04,000\nHello there\n\n2\n00:00:05,000 --> 00:00:07,500\nGeneral Kenobi\n'); }
  if (p.startsWith('/files/')) return serveFile(req, res, path.join(__dirname, path.basename(p)));
  if (p === '/_calls') return send(res, { streamCalls });
  res.writeHead(404); res.end();
}).listen(PORT, () => console.log(`mock AIOStreams on ${BASE}/manifest.json (stream delay ${DELAY}ms)`));
