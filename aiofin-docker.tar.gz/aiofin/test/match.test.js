'use strict';
// Unit tests for the match check. Run: node test/match.test.js
process.env.DATA_DIR = process.env.DATA_DIR || require('os').tmpdir() + '/aiofin-match-test';
const { verdict, titleVariants, movieYear } = require('../src/match');
const ep = (name, year, season, episode) => ({ kind: 'episode', titles: titleVariants(name), year, season, episode });
const TWD = ep('The Walking Dead', 2010, 1, 1);
const FTWD = ep('Fear the Walking Dead', 2015, 1, 1);
const cases = [
  // [expectation, file name, want ok?]
  [TWD, 'The.Walking.Dead.S01E01.Days.Gone.Bye.1080p.BluRay.x264-GRP.mkv', true],
  [TWD, 'Fear.the.Walking.Dead.S01E01.Pilot.1080p.WEB-DL.mkv', false],
  [TWD, 'The.Walking.Dead.Daryl.Dixon.S01E01.1080p.WEB.h264.mkv', false],
  [TWD, 'The.Walking.Dead.Dead.City.S01E01.720p.mkv', false],
  [TWD, 'The.Walking.Dead.World.Beyond.S01E01.mkv', false],
  [TWD, 'Tales.of.the.Walking.Dead.S01E01.mkv', false],
  [TWD, 'The.Walking.Dead.S01E10.1080p.mkv', false],
  [TWD, 'The.Walking.Dead.S02E01.1080p.mkv', false],
  [TWD, 'Walking.Dead.S01E01.720p.HDTV.mkv', true],
  [TWD, 'THE WALKING DEAD - S01E01 - Days Gone Bye (1080p).mkv', true],
  [TWD, 'The Walking Dead 1x01 Days Gone Bye.avi', true],
  [TWD, 'The.Walking.Dead.S01E01E02.1080p.mkv', true],
  [TWD, 'The.Walking.Dead.S01E01-E03.1080p.mkv', true],
  [TWD, 'The.Walking.Dead.S01.COMPLETE.1080p.BluRay.mkv', true],
  [TWD, 'The Walking Dead Season 1 Episode 1.mp4', true],
  [TWD, '[TGx] The.Walking.Dead.S01E01.1080p.mkv', true],
  [TWD, 'www.Torrenting.com - The.Walking.Dead.S01E01.1080p.mkv', true],
  [TWD, 'Los.Muertos.Vivientes.S01E01.Spanish.mkv', true], // another language: can't judge, kept
  [TWD, 'The.Walking.Dead.2010.S01E01.1080p.mkv', true],
  [TWD, 'The.Walking.Dead.S01E01.720p.x264.mkv', true],  // 720p must not read as episode 720
  [TWD, 'The.Walking.Dead.S01E11.720p.x264.mkv', false],
  [FTWD, 'Fear.the.Walking.Dead.S01E01.1080p.mkv', true],
  [FTWD, 'Fear.The.Walking.Dead.S01E01.Pilot.mkv', true],
  [FTWD, 'The.Walking.Dead.S01E01.1080p.mkv', false],
  [FTWD, 'Walking.Dead.S01E01.mkv', false],
  [ep('The Walking Dead: Daryl Dixon', 2023, 1, 1), 'The.Walking.Dead.Daryl.Dixon.S01E01.1080p.mkv', true],
  [ep('The Walking Dead: Daryl Dixon', 2023, 1, 1), 'Daryl.Dixon.S01E01.1080p.mkv', true],
  [ep('The Walking Dead: Daryl Dixon', 2023, 1, 1), 'The.Walking.Dead.S01E01.1080p.mkv', false],
  [ep('Doctor Who', 2005, 1, 1), 'Doctor.Who.2005.S01E01.Rose.1080p.mkv', true],
  [ep('Doctor Who', 2005, 1, 1), 'Doctor.Who.1963.S01E01.An.Unearthly.Child.mkv', false],
  [ep('Doctor Who', 2005, 1, 1), 'Doctor.Who.S01E01.Rose.mkv', true],
  [ep("Marvel's Agents of S.H.I.E.L.D.", 2013, 1, 1), 'Marvels.Agents.of.S.H.I.E.L.D.S01E01.mkv', true],
  [ep("Marvel's Agents of S.H.I.E.L.D.", 2013, 1, 1), 'Agents.of.SHIELD.S01E01.720p.mkv', true],
  [ep('9-1-1', 2018, 1, 1), '9-1-1.S01E01.1080p.mkv', true],
  [ep('9-1-1', 2018, 1, 1), '9-1-1.Lone.Star.S01E01.1080p.mkv', false],
  [ep('Law & Order: Special Victims Unit', 1999, 1, 1), 'Law.and.Order.SVU.S01E01.mkv', true],
  [ep('The Walking Dead: Daryl Dixon', 2023, 1, 1), 'TWD.Daryl.Dixon.S01E01.1080p.mkv', true],
  [TWD, 'TWD.S01E01.1080p.mkv', true],
  [FTWD, 'TWD.S01E01.1080p.mkv', false],
  [FTWD, 'FTWD.S01E01.1080p.mkv', true],
  [ep('NCIS: Los Angeles', 2009, 1, 1), 'NCIS.LA.S01E01.mkv', true],
  [ep('NCIS: Los Angeles', 2009, 1, 1), 'NCIS.S01E01.mkv', false],
  [ep('NCIS', 2003, 1, 1), 'NCIS.Los.Angeles.S01E01.mkv', false],
  [ep('NCIS', 2003, 1, 1), 'NCIS.S01E01.mkv', true],
  [ep('Law & Order: Special Victims Unit', 1999, 1, 1), 'Law.and.Order.Special.Victims.Unit.S01E01.mkv', true],
  [ep('Law & Order', 1990, 1, 1), 'Law.and.Order.Special.Victims.Unit.S01E01.mkv', false],
  [ep('S.W.A.T.', 2017, 1, 1), 'S.W.A.T.2017.S01E01.1080p.mkv', true],
  [ep('Shameless', 2011, 1, 1), 'Shameless.US.S01E01.720p.mkv', true],
  [ep('The Office', 2005, 1, 1), 'The.Office.US.S01E01.mkv', true],
  [TWD, 'Some.Daily.Show.2024.10.06.1080p.mkv', true], // no episode marker: can't judge
  [TWD, '', true],                                     // no file name: kept
];
let fail = 0;
for (const [exp, name, want] of cases) {
  const v = verdict({ filename: name }, exp);
  const ok = (v === 'ok') === want;
  if (!ok) fail++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${want ? 'keep' : 'drop'}  ${name || '(no file name)'}${v !== 'ok' ? `   → ${v}` : ''}`);
}
const movies = [
  ['Dune.Part.Two.2024.2160p.WEB-DL.mkv', 2024, true],
  ['Dune.2021.2160p.WEB-DL.mkv', 2024, false],
  ['The.Lion.King.1994.1080p.BluRay.mkv', 2019, false],
  ['The.Lion.King.2019.1080p.BluRay.mkv', 2019, true],
  ['Blade.Runner.2049.2017.1080p.mkv', 2017, true],
  ['2001.A.Space.Odyssey.1968.1080p.mkv', 1968, true],
  ['1917.2019.1080p.BluRay.mkv', 2019, true],
  ['1917.1080p.BluRay.mkv', 2019, true],
  ['Movie.Without.Year.1080p.mkv', 2019, true],
];
for (const [name, year, want] of movies) {
  const v = verdict({ filename: name }, { kind: 'movie', year });
  const ok = (v === 'ok') === want;
  if (!ok) fail++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${want ? 'keep' : 'drop'}  [movie ${year}] ${name}${v !== 'ok' ? `   → ${v}` : ''}  (read year: ${movieYear(name)})`);
}
console.log(fail ? `\n${fail} FAILED` : '\nall passed');
process.exit(fail ? 1 : 0);
