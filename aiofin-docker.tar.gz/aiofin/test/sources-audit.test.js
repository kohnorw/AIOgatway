'use strict';
// Audit: how streams (versions) appear and switch in every Jellyfin app.
// Each block replays the requests that app makes (from its source code) and
// checks: every version is listed, picking one works, Play plays that one.
//   node test/sources-audit.test.js    (server + mock AIOStreams running)
const BASE = process.env.BASE || 'http://127.0.0.1:8096';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rows = []; let fails = 0;
const check = (app, what, ok, detail = '') => { rows.push(`${ok ? 'PASS' : 'FAIL'}  ${app.padEnd(22)} ${what}${detail ? `  (${detail})` : ''}`); if (!ok) fails++; };
const client = (name, device) => ({ auth: `MediaBrowser Client="${name}", Device="${device}", DeviceId="audit-${name.replace(/\W/g, '')}", Version="1.0"` });
async function login(c) {
  const r = await fetch(BASE + '/Users/AuthenticateByName', { method: 'POST', headers: { 'content-type': 'application/json', 'x-emby-authorization': c.auth }, body: JSON.stringify({ Username: 'admin', Pw: 'pw' }) });
  const j = await r.json(); c.token = j.AccessToken; c.uid = j.User.Id; return c;
}
const call = async (c, method, path, body) => {
  const r = await fetch(BASE + path, { method, headers: { 'content-type': 'application/json', 'x-emby-authorization': `${c.auth}, Token="${c.token}"`, ...(c.script ? { 'x-aiofin-script': '1' } : {}) }, body: body ? JSON.stringify(body) : undefined, redirect: 'manual' });
  const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch { /* not json */ }
  return { status: r.status, json: j, headers: r.headers };
};
const ids = (list) => (list || []).map((x) => x.Id);
const HLS = { DirectPlayProfiles: [{ Type: 'Video', Container: 'mp4', VideoCodec: 'h264', AudioCodec: 'aac' }], TranscodingProfiles: [{ Type: 'Video', Protocol: 'hls', Container: 'ts', VideoCodec: 'h264', AudioCodec: 'aac' }] };
const VLC = { DirectPlayProfiles: [{ Type: 'Video', Container: 'mkv,mp4', VideoCodec: 'h264,hevc', AudioCodec: 'aac,ac3,eac3,dts,truehd' }], TranscodingProfiles: HLS.TranscodingProfiles };

(async () => {
  const st = await (await fetch(BASE + '/admin/api/status')).json();
  if (st.setupNeeded) await fetch(BASE + '/admin/api/setup', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: 'admin', password: 'pw', aioUrl: 'http://127.0.0.1:7001/stremio/abc/def/manifest.json' }) });
  const admin = await login(client('Audit', 'x'));
  const views = (await call(admin, 'GET', '/UserViews')).json.Items;
  const mv = views.find((v) => v.CollectionType === 'movies');
  const pickMovie = async (i) => (await call(admin, 'GET', `/Items?ParentId=${mv.Id}&StartIndex=${i}&Limit=1`)).json.Items[0];
  const truth = async (m) => ids((await call(admin, 'POST', `/Items/${m.Id}/PlaybackInfo`, {})).json.MediaSources);

  // ── Jellyfin Web (browser, Jellyfin iOS/Android, Jellyfin Media Player) ──
  for (const [app, dev] of [['Jellyfin Web', 'Chrome'], ['Jellyfin Mobile (iOS)', 'iPhone'], ['Jellyfin Android', 'Pixel']]) {
    const c = await login(client(app, dev)); c.script = true; // AIOFin's page script marks its requests
    const m = await pickMovie(1); const all = await truth(m);
    let r = await call(c, 'GET', `/Users/${c.uid}/Items/${m.Id}`);
    check(app, 'details open instantly with a placeholder', r.json.MediaSources.length === 1 && r.json.MediaSources[0].Id === m.Id);
    r = await call(c, 'GET', `/Users/${c.uid}/Items/${m.Id}?Fields=MediaSources&aiofinWait=1`); // page script
    let current = r.json;
    check(app, 'page script loads every version', JSON.stringify(ids(current.MediaSources)) === JSON.stringify(all), `${current.MediaSources.length} of ${all.length}`);
    // Pick versions in the menu: Jellyfin Web asks for /Items/{versionId} and redraws the page from it.
    for (const k of [2, 3, 0]) {
      const sel = all[k];
      r = await call(c, 'GET', `/Items/${sel}?userId=${c.uid}`);
      const ok = r.status === 200 && r.json.MediaSources.length === all.length && r.json.MediaSources[0].Id === sel && r.json.MediaSources.some((x) => x.Id === sel);
      check(app, `pick version ${k + 1}: menu keeps all versions, picked one selected`, ok, r.status === 200 ? `${r.json.MediaSources.length} versions, first=${r.json.MediaSources[0].Id === sel ? 'picked' : 'other'}` : `HTTP ${r.status}`);
      if (r.status === 200) current = r.json;
      const pi = await call(c, 'POST', `/Items/${current.Id}/PlaybackInfo?MediaSourceId=${sel}`, { DeviceProfile: HLS, MediaSourceId: sel });
      check(app, `Play after picking version ${k + 1} plays it`, pi.json.MediaSources.length === 1 && pi.json.MediaSources[0].Id === sel && !!pi.json.MediaSources[0].TranscodingUrl);
    }
    // In-player Streams button: GET the list, then play({ mediaSourceId }).
    r = await call(c, 'GET', `/aiofin/items/${m.Id}/sources`);
    check(app, 'in-player Streams button lists every version', r.json.Sources.length === all.length);
  }

  // ── Swiftfin (iOS/tvOS): GET /Items/{id}?userId, picker from MediaSources, PlaybackInfo with MediaSourceId ──
  { const c = await login(client('Swiftfin iOS', 'iPhone')); const m = await pickMovie(2); const all = await truth(m);
    const r = await call(c, 'GET', `/Items/${m.Id}?userId=${c.uid}`);
    check('Swiftfin', 'details list every version', JSON.stringify(ids(r.json.MediaSources)) === JSON.stringify(all));
    for (const sel of [all[1], all[3]]) {
      const pi = await call(c, 'POST', `/Items/${m.Id}/PlaybackInfo`, { UserId: c.uid, MediaSourceId: sel, DeviceProfile: VLC });
      check('Swiftfin', 'plays the picked version (direct)', pi.json.MediaSources[0].Id === sel && pi.json.MediaSources[0].SupportsDirectPlay);
    } }

  // ── Streamyfin: /Items?ids= twice (fast, then with every field), camelCase PlaybackInfo ──
  { const c = await login(client('Streamyfin', 'iPhone')); const m = await pickMovie(3); const all = await truth(m);
    let r = await call(c, 'GET', `/Items?ids=${m.Id}&userId=${c.uid}&fields=Overview,People`);
    check('Streamyfin', 'first details call is fast and light', !r.json.Items[0].MediaSources);
    r = await call(c, 'GET', `/Items?ids=${m.Id}&userId=${c.uid}&fields=MediaSources,MediaStreams,Overview`);
    check('Streamyfin', 'second call lists every version', JSON.stringify(ids(r.json.Items[0].MediaSources)) === JSON.stringify(all));
    const pi = await call(c, 'POST', `/Items/${m.Id}/PlaybackInfo`, { userId: c.uid, mediaSourceId: all[2], deviceProfile: VLC });
    check('Streamyfin', 'plays the picked version', pi.json.MediaSources[0].Id === all[2]); }

  // ── Jellyfin Android TV: details with fields, "Select version" from MediaSources, plays the chosen (or first) ──
  { const c = await login(client('Android TV', 'SHIELD Android TV')); const m = await pickMovie(4); const all = await truth(m);
    const r = await call(c, 'GET', `/Items/${m.Id}?userId=${c.uid}&fields=MediaSources,MediaStreams,Chapters`);
    check('Android TV', 'Select version lists every version', JSON.stringify(ids(r.json.MediaSources)) === JSON.stringify(all));
    let pi = await call(c, 'POST', `/Items/${m.Id}/PlaybackInfo?userId=${c.uid}`, { MediaSourceId: all[3], DeviceProfile: VLC });
    check('Android TV', 'plays the selected version', pi.json.MediaSources[0].Id === all[3]);
    const rv = await call(c, 'GET', `/Items/${all[3]}?userId=${c.uid}`);
    check('Android TV', 'a version opened as an item has it first (plays get(0))', rv.json.MediaSources[0].Id === all[3]);
    pi = await call(c, 'POST', `/Items/${all[3]}/PlaybackInfo?userId=${c.uid}`, { DeviceProfile: VLC });
    check('Android TV', 'PlaybackInfo by version id plays that version', pi.json.MediaSources[0].Id === all[3]); }

  // ── Infuse (no Fields, no profile; streams by /Videos/{id}/stream?MediaSourceId) ──
  { const c = await login(client('Infuse-Direct', 'Apple TV')); const m = await pickMovie(5); const all = await truth(m);
    const r = await call(c, 'GET', `/Users/${c.uid}/Items/${m.Id}`);
    check('Infuse', 'details list every version', JSON.stringify(ids(r.json.MediaSources)) === JSON.stringify(all));
    const s = await call(c, 'GET', `/Videos/${m.Id}/stream?static=true&MediaSourceId=${all[1]}`);
    check('Infuse', 'streams the picked version', [200, 206, 302].includes(s.status)); }

  // ── Kodi (Jellyfin for Kodi / JellyCon): Items?ids with Fields=MediaSources ──
  { const c = await login(client('Kodi', 'Kodi')); const m = await pickMovie(6); const all = await truth(m);
    const r = await call(c, 'GET', `/Users/${c.uid}/Items?Ids=${m.Id}&Fields=MediaSources,MediaStreams`);
    check('Kodi', 'details list every version', JSON.stringify(ids(r.json.Items[0].MediaSources)) === JSON.stringify(all)); }

  // ── Apps that look like Jellyfin Web but don't run AIOFin's page script ──
  // (Jellyfin Media Player / Jellyfin Desktop with their built-in web client,
  // Jellyfin Vue, Fladder on the web, any browser-based third-party app)
  for (const [app, dev] of [['Jellyfin Web', 'Chrome'], ['Jellyfin Media Player', 'Desktop'], ['Jellyfin Vue', 'Firefox'], ['Fladder', 'Chrome'], ['Findroid', 'Pixel'], ['Moonfin', 'Android TV'], ['Wholphin', 'Android TV']]) {
    const c = await login(client(app, dev)); const m = await pickMovie(7); const all = await truth(m);
    const r = await call(c, 'GET', `/Users/${c.uid}/Items/${m.Id}`);
    check(`${app} (no script)`, 'details list every version', JSON.stringify(ids(r.json.MediaSources)) === JSON.stringify(all), `${r.json.MediaSources.length} of ${all.length}`);
  }

  // ── Lists asking for versions (episode lists, home rows, libraries) ──
  { const c = await login(client('Android TV', 'SHIELD Android TV'));
    const known = await pickMovie(1); const knownAll = await truth(known);
    let r = await call(c, 'GET', `/Items?ParentId=${mv.Id}&StartIndex=0&Limit=10&Fields=MediaSources`);
    const row = r.json.Items.find((x) => x.Id === known.Id);
    check('All apps (lists)', 'a looked-up title shows its real versions in lists', row && JSON.stringify(ids(row.MediaSources)) === JSON.stringify(knownAll), row ? `${row.MediaSources.length} versions` : 'missing');
    const other = r.json.Items.find((x) => x.Id !== known.Id && x.MediaSources && x.MediaSources.length === 2 && /\(2\)$/.test(x.MediaSources[1].Name));
    check('All apps (lists)', 'titles not looked up yet get placeholders (no lookups)', !!other);
    const sv = views.filter((v) => v.CollectionType === 'tvshows').pop();
    const show = (await call(admin, 'GET', `/Items?ParentId=${sv.Id}&Limit=1`)).json.Items[0];
    const ep = (await call(admin, 'GET', `/Shows/${show.Id}/Episodes?Season=1`)).json.Items[0];
    const epAll = ids((await call(admin, 'POST', `/Items/${ep.Id}/PlaybackInfo`, {})).json.MediaSources);
    r = await call(c, 'GET', `/Shows/${show.Id}/Episodes?Season=1&Fields=MediaSources`);
    check('All apps (lists)', 'episode list shows real versions (Android TV/Findroid play from it)', JSON.stringify(ids(r.json.Items[0].MediaSources)) === JSON.stringify(epAll), `${r.json.Items[0].MediaSources.length} versions`);
    const t0 = performance.now(); await call(c, 'GET', `/Items?ParentId=${mv.Id}&StartIndex=20&Limit=20&Fields=MediaSources`);
    check('All apps (lists)', 'list replies stay fast (no lookups)', performance.now() - t0 < 500, `${Math.round(performance.now() - t0)}ms for 20 items`); }

  console.log(rows.join('\n'));
  console.log(fails ? `\n${fails} FAILED` : `\nall ${rows.length} checks passed`);
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.log(rows.join('\n')); console.error(e); process.exit(1); });
