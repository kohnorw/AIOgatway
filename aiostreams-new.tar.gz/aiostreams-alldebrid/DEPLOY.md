# Deploy: AIOStreams + AllDebrid cached-only

Upstream: https://github.com/Viren070/AIOStreams (commit 0a440cb, v2.34.1) plus the AllDebrid
changes described in FORK.md. Everything needed to build the image is in this folder.

## 1. Configure
    cp .env.sample .env
Edit `.env` and set at least:
- `BASE_URL`   your public URL, e.g. https://aiostreams.example.com (no trailing slash)
- `SECRET_KEY` 64 hex chars: `openssl rand -hex 32`. Do not change it after first run.

## 2. Build and run (needs Docker + the compose plugin)
    docker compose -f compose.fork.yaml up -d --build
The first build takes several minutes (it compiles from source). Then open
http://<host>:3000/stremio/configure

## 3. Set up in AIOStreams (no env vars needed)
1. Open `http://<host>:3000/stremio/configure` and pick the template **AllDebrid Cached-Only**.
2. Under **Services**, enable **AllDebrid** and paste your API key
   (https://alldebrid.com/apikeys). Every indexer in the template uses it automatically
   (they show up as "Knaben AD", "The Pirate Bay AD", ...).
3. Enter a free TMDB API key when prompted (https://www.themoviedb.org/settings/api). AIOStreams
   needs it to look up titles for title/year matching.
4. Save, then install the manifest URL in Stremio.

The template includes Knaben, The Pirate Bay, EZTV and TheRARBG (no setup needed) and also
excludes uncached AllDebrid results at the user level. To use your own indexers instead, add any
built-in addon (Torznab, Prowlarr, ...); with no service override it uses AllDebrid
automatically.

## 4. Optional: tune it from the dashboard
Dashboard -> Settings -> Built-ins -> Debrid (the dashboard needs the `admin` permission; see
OPERATOR AUTHENTICATION in `.env`). Settings: AllDebrid cached-only, check method
(`instant` / `upload`), max hashes (upload only), max requests per second, uncached TTL.
They are editable there as long as you have NOT also set the matching `BUILTIN_ALLDEBRID_*`
variable in `.env` or compose (an env-set value is locked/read-only in the dashboard).

## Verify it is working
    docker logs -f aiostreams
Search a title in Stremio, then check the log for `debrid:alldebrid` lines. If checks error or
everything shows uncached, set `BUILTIN_ALLDEBRID_CHECK_METHOD=upload` and restart.

## Update / rollback
Rebuild after changing source: `docker compose -f compose.fork.yaml up -d --build`.
Your data lives in `./data` (keep it, and keep the same SECRET_KEY).
