'use strict';
// Stand-ins for AIOStreams (port 7001) and Plex Media Server (port 7002).
//   node test/mock.js
// Media files are generated on the fly: byte i of a file is (i * 7 + seed) % 251.
const http = require('http');

const A_PORT = parseInt(process.env.MOCK_AIO_PORT || '7001', 10);
const P_PORT = parseInt(process.env.MOCK_PLEX_PORT || '7002', 10);
const BASE = `http://127.0.0.1:${A_PORT}/stremio/u/c`;
const MB = 1024 * 1024;

const movies = Array.from({ length: 6 }, (_, i) => ({ id: `tt100000${i}`, type: 'movie', name: `Test Movie ${i + 1}`, releaseInfo: String(2010 + i), poster: 'https://example.com/p.jpg' }));
const shows = Array.from({ length: 2 }, (_, i) => ({ id: `tt200000${i}`, type: 'series', name: `Test Show ${i + 1}`, releaseInfo: '2019–' }));
const searchOnly = [{ id: 'tt3000000', type: 'movie', name: 'Searchable Film', releaseInfo: '2021' }];
const future = new Date(Date.now() + 7 * 86400_000).toISOString();
const airOverride = new Map(); // "tt…:s:e" → ISO date (test hook /_air)
const noStreams = new Set();   // ids with no streams yet (test hook /_nostreams, /_streams)

const manifest = {
  id: 'mock.aio', name: 'AIOStreams (mock)', version: '2.0.0', resources: ['catalog', 'meta', 'stream'], types: ['movie', 'series'], idPrefixes: ['tt'],
  catalogs: [
    { type: 'movie', id: 'mock.movies', name: 'Popular Movies', extra: [{ name: 'skip' }, { name: 'search' }] },
    { type: 'series', id: 'mock.shows', name: 'Popular Shows', extra: [{ name: 'skip' }] },
    { type: 'movie', id: 'mock.search', name: 'Search', extra: [{ name: 'search', isRequired: true }] },
  ],
};

const files = new Map(); // name → { size, seed }
function file(name, size) { if (!files.has(name)) files.set(name, { size, seed: files.size % 97 }); return name; }
let playbackHits = 0;

function streamsFor(type, id) {
  const all = [...movies, ...shows, ...searchOnly];
  const base = all.find((m) => id.startsWith(m.id));
  if (!base) return [];
  const slug = base.name.replace(/\s+/g, '.');
  const ep = id.split(':').length === 3 ? `.S${id.split(':')[1].padStart(2, '0')}E${id.split(':')[2].padStart(2, '0')}` : `.${base.releaseInfo.slice(0, 4)}`;
  if (id === 'tt1000005' || noStreams.has(id)) return []; // nothing (yet)
  const out = [];
  // An uncached 4K result (must be skipped when ONLY_CACHED)
  out.push({ name: '[RD⏳] 4K', url: `${BASE}/playback/${file(`${slug}${ep}.2160p.UNCACHED.mkv`, 90 * MB)}`, behaviorHints: { filename: `${slug}${ep}.2160p.UNCACHED.mkv`, videoSize: 90 * MB }, streamData: { service: { id: 'realdebrid', cached: false } } });
  // A cached 4K whose link returns a tiny "error clip" (size mismatch): must be skipped
  out.push({ name: '[RD⚡] 4K', url: `${BASE}/playback/errorclip`, behaviorHints: { filename: `${slug}${ep}.2160p.BROKEN.mkv`, videoSize: 80 * MB }, streamData: { service: { id: 'realdebrid', cached: true } } });
  // Good 4K and 1080p
  const f4 = `${slug}${ep}.2160p.WEB-DL.DV.mkv`; const f1 = `${slug}${ep}.1080p.BluRay.x264.mkv`; const f1b = `${slug}${ep}.1080p.WEB.mp4`;
  out.push({ name: '[RD⚡] 4K', url: `${BASE}/playback/${file(f4, 70 * MB + 123)}`, behaviorHints: { filename: f4, videoSize: 70 * MB + 123 }, streamData: { service: { id: 'realdebrid', cached: true } } });
  out.push({ name: '[RD⚡] 1080p', url: `${BASE}/playback/${file(f1, 40 * MB + 7)}`, behaviorHints: { filename: f1, videoSize: 40 * MB + 7 }, streamData: { service: { id: 'realdebrid', cached: true } } });
  out.push({ name: '[TB⚡] 1080p', url: `${BASE}/playback/${file(f1b, 35 * MB)}`, behaviorHints: { filename: f1b, videoSize: 35 * MB }, streamData: { service: { id: 'torbox', cached: true } } });
  // Packs, listed after the single episodes: a 4K season pack and a 1080p complete-series pack.
  if (type === 'series') {
    const [, S, E] = id.split(':').map(Number);
    const p4 = `${slug}.S${String(S).padStart(2, '0')}.2160p.PACK--${slug}${ep}.2160p.mkv`;
    const p1 = `${slug}.Complete.1080p.PACK--${slug}${ep}.1080p.mkv`;
    out.push({ name: '[RD⚡] 4K', url: `${BASE}/playback/${file(p4, 60 * MB + E * 1000)}`, behaviorHints: { filename: `${slug}${ep}.2160p.mkv`, videoSize: 60 * MB + E * 1000 },
      streamData: { service: { id: 'realdebrid', cached: true }, torrent: { infoHash: `h4k${base.id}s${S}` }, folderName: `${slug}.S${String(S).padStart(2, '0')}.2160p.WEB-DL-GRP` } });
    out.push({ name: '[RD⚡] 1080p', url: `${BASE}/playback/${file(p1, 30 * MB + S * 100 + E)}`, behaviorHints: { filename: `${slug}${ep}.1080p.mkv`, videoSize: 30 * MB + S * 100 + E },
      description: `📁 ${slug}.Complete.Series.1080p.BluRay-GRP\n📄 ${slug}${ep}.1080p.mkv`, streamData: { service: { id: 'realdebrid', cached: true } } });
  }
  // A wrong-title result (match check drops it)
  if (type === 'series') out.push({ name: '[RD⚡] 1080p', url: `${BASE}/playback/${file(`Fear.the.${slug}${ep}.1080p.mkv`, 41 * MB)}`, behaviorHints: { filename: `Fear.the.${slug}${ep}.1080p.mkv`, videoSize: 41 * MB } });
  return out;
}

function send(res, obj) { const b = JSON.stringify(obj); res.writeHead(200, { 'content-type': 'application/json' }); res.end(b); }

const broken = new Set();
function serveBytes(req, res, name) {
  const f = files.get(name);
  if (!f || broken.has(name)) { res.writeHead(404); return res.end(); }
  let start = 0; let end = f.size - 1; let status = 200;
  const m = String(req.headers.range || '').match(/bytes=(\d*)-(\d*)/);
  if (m) { start = m[1] ? +m[1] : f.size - +m[2]; end = m[1] && m[2] ? Math.min(+m[2], f.size - 1) : f.size - 1; status = 206; }
  const h = { 'content-type': 'video/x-matroska', 'accept-ranges': 'bytes', 'content-length': end - start + 1 };
  if (status === 206) h['content-range'] = `bytes ${start}-${end}/${f.size}`;
  res.writeHead(status, h);
  if (req.method === 'HEAD') return res.end();
  let pos = start;
  const pump = () => {
    while (pos <= end) {
      const n = Math.min(256 * 1024, end - pos + 1);
      const buf = Buffer.allocUnsafe(n);
      for (let i = 0; i < n; i++) buf[i] = ((pos + i) * 7 + f.seed) % 251;
      pos += n;
      if (!res.write(buf)) return res.once('drain', pump);
    }
    res.end();
  };
  pump();
}

http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  const p = decodeURIComponent(u.pathname.replace(/^\/stremio\/u\/c/, ''));
  if (p === '/manifest.json') return send(res, manifest);
  let m;
  if ((m = p.match(/^\/catalog\/(\w+)\/([\w.]+)(?:\/(.*))?\.json$/))) {
    const extra = Object.fromEntries(new URLSearchParams(m[3] || ''));
    if (extra.search) return send(res, { metas: [...movies, ...searchOnly].filter((x) => x.name.toLowerCase().includes(extra.search.toLowerCase())) });
    if (+(extra.skip || 0) > 0) return send(res, { metas: [] });
    return send(res, { metas: m[1] === 'movie' ? (m[2] === 'mock.movies' ? movies : []) : shows });
  }
  if ((m = p.match(/^\/meta\/(\w+)\/([^/]+)\.json$/))) {
    const all = [...movies, ...shows, ...searchOnly];
    const base = all.find((x) => x.id === m[2]);
    if (!base) return send(res, { meta: null });
    if (base.type !== 'series') return send(res, { meta: base });
    const videos = [];
    for (let s = 0; s <= 2; s++) for (let e = 1; e <= 3; e++) {
      const vid = `${base.id}:${s}:${e}`;
      videos.push({ id: vid, season: s, episode: e, released: airOverride.get(vid) || (s === 2 && e === 3 ? future : '2020-01-01T00:00:00Z') });
    }
    return send(res, { meta: { ...base, videos } });
  }
  if ((m = p.match(/^\/stream\/(\w+)\/([^/]+)\.json$/))) return send(res, { streams: streamsFor(m[1], m[2]) });
  if ((m = p.match(/^\/playback\/(.+)$/))) {
    playbackHits++;
    if (m[1] === 'errorclip') { res.writeHead(302, { location: `http://127.0.0.1:${A_PORT}/files/${file('error.mp4', 2 * MB)}` }); return res.end(); }
    res.writeHead(302, { location: `http://127.0.0.1:${A_PORT}/files/${encodeURIComponent(m[1])}` }); return res.end();
  }
  if ((m = p.match(/^\/files\/(.+)$/))) return serveBytes(req, res, m[1]);
  if (p === '/_stats') return send(res, { playbackHits });
  if ((m = p.match(/^\/_air\/(.+)$/))) { airOverride.set(m[1], new Date(Date.now() - 60_000).toISOString()); return send(res, { ok: true }); }
  if ((m = p.match(/^\/_nostreams\/(.+)$/))) { noStreams.add(m[1]); return send(res, { ok: true }); }
  if ((m = p.match(/^\/_streams\/(.+)$/))) { noStreams.delete(m[1]); return send(res, { ok: true }); }
  if ((m = p.match(/^\/_break\/(.+)$/))) { broken.add(m[1]); return send(res, { ok: true }); }
  res.writeHead(404); res.end();
}).listen(A_PORT, () => console.log(`mock AIOStreams on ${BASE}/manifest.json`));

// ── Mock Plex Media Server ─────────────────────────────────────────────
const pmsState = { claimed: false, sections: [], prefs: {}, refreshes: [], emptied: [], nextKey: 1 };
http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  const p = u.pathname; const q = u.searchParams;
  const sendj = (o) => send(res, o);
  if (p === '/_state') return sendj(pmsState);
  if (p === '/identity') return sendj({ MediaContainer: { machineIdentifier: 'mockpms', claimed: pmsState.claimed, version: '1.41.0' } });
  if (p === '/myplex/claim' && req.method === 'POST') { pmsState.claimed = q.get('token') === 'claim-good'; res.writeHead(pmsState.claimed ? 200 : 400); return res.end(); }
  if (req.headers['x-plex-token'] !== 'tok') { res.writeHead(401); return res.end(); }
  if (p === '/') return sendj({ MediaContainer: { friendlyName: pmsState.prefs.FriendlyName || 'mock' } });
  if (p === '/:/prefs' && req.method === 'PUT') { for (const [k, v] of q) pmsState.prefs[k] = v; res.writeHead(200); return res.end(); }
  if (p === '/library/sections' && req.method === 'GET') return sendj({ MediaContainer: { Directory: pmsState.sections } });
  if (p === '/library/sections' && req.method === 'POST') {
    const d = { key: String(pmsState.nextKey++), title: q.get('name'), type: q.get('type'), agent: q.get('agent'), Location: [{ path: q.get('location') }] };
    pmsState.sections.push(d);
    return sendj({ MediaContainer: { Directory: [d] } });
  }
  let m;
  if ((m = p.match(/^\/library\/sections\/(\d+)\/refresh$/))) { pmsState.refreshes.push(m[1]); res.writeHead(200); return res.end(); }
  if ((m = p.match(/^\/library\/sections\/(\d+)\/emptyTrash$/))) { pmsState.emptied.push(m[1]); res.writeHead(200); return res.end(); }
  if ((m = p.match(/^\/library\/sections\/(\d+)\/prefs$/))) { res.writeHead(200); return res.end(); }
  if ((m = p.match(/^\/library\/sections\/(\d+)$/))) {
    const s = pmsState.sections.find((x) => x.key === m[1]);
    if (req.method === 'DELETE') { pmsState.sections = pmsState.sections.filter((x) => x !== s); res.writeHead(200); return res.end(); }
    if (req.method === 'PUT' && s) { s.title = q.get('name') || s.title; res.writeHead(200); return res.end(); }
  }
  res.writeHead(404); res.end();
}).listen(P_PORT, () => console.log(`mock Plex on http://127.0.0.1:${P_PORT}`));
