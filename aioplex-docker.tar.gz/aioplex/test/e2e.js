'use strict';
// End-to-end checks: starts the mocks and AIOPlex, then exercises catalogs →
// libraries, stream pinning, WebDAV listing and reads (redirect + proxy),
// search/add, Plex adoption + settings, healing a dead link, and (when an
// `rclone` binary is on PATH or in RCLONE) reading through rclone's WebDAV
// backend exactly as the Plex container's mount does.
const { spawn, execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

const ROOT = path.resolve(__dirname, '..');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'aioplex-unit-')); // for the few in-process checks
const PORT = 18097;
const BASE = `http://127.0.0.1:${PORT}`;
const MB = 1024 * 1024;
const procs = [];
let pass = 0; let fail = 0;
function ok(cond, msg) { if (cond) { pass++; console.log(`  ✓ ${msg}`); } else { fail++; console.log(`  ✗ ${msg}`); } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function req(method, url, { headers = {}, body } = {}) {
  return new Promise((resolve, reject) => {
    const r = http.request(url, { method, headers }, (res) => {
      const chunks = []; res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
    });
    r.on('error', reject);
    if (body) r.write(body);
    r.end();
  });
}
let token = '';
async function api(method, p, body) {
  const r = await req(method, BASE + p, { headers: { 'content-type': 'application/json', 'x-aioplex-token': token }, body: body ? JSON.stringify(body) : undefined });
  const j = r.body.length ? JSON.parse(r.body.toString()) : null;
  if (r.status >= 400) throw new Error(`${p}: ${r.status} ${j && j.error}`);
  return j;
}
const davList = async (p) => {
  const r = await req('PROPFIND', BASE + '/dav/' + p, { headers: { depth: '1' } });
  const xml = r.body.toString();
  const items = [...xml.matchAll(/<D:response><D:href>([^<]*)<\/D:href>.*?<D:displayname>([^<]*)<\/D:displayname>(.*?)<\/D:prop>/g)].slice(1)
    .map((m) => ({ name: m[2].replace(/&amp;/g, '&'), dir: m[3].includes('<D:collection/>'), size: Number((m[3].match(/getcontentlength>(\d+)/) || [])[1] || 0) }));
  return { status: r.status, items };
};
const enc = (...segs) => segs.map(encodeURIComponent).join('/');
const expectByte = (pos, seed) => ((pos * 7 + seed) % 251);
const mockState = async () => JSON.parse((await req('GET', 'http://127.0.0.1:7002/_state')).body.toString());

async function waitIdle() {
  for (let i = 0; i < 100; i++) {
    const s = await api('GET', '/admin/api/status');
    if (s.resolver.pending === 0 && s.resolver.running.length === 0) return s;
    await sleep(200);
  }
  throw new Error('resolver never went idle');
}

async function main() {
  const data = fs.mkdtempSync(path.join(os.tmpdir(), 'aioplex-'));
  procs.push(spawn(process.execPath, [path.join(ROOT, 'test/mock.js')], { stdio: 'ignore' }));
  await sleep(500);
  const env = {
    ...process.env, PORT: String(PORT), DATA_DIR: data, PLEX_URL: 'http://127.0.0.1:7002', PLEX_TOKEN: 'tok', PLEX_CONFIG_DIR: path.join(data, 'none'),
    AIOSTREAMS_URL: 'http://127.0.0.1:7001/stremio/u/c/manifest.json', CATALOGS: 'all', ADMIN_USERNAME: 'admin', ADMIN_PASSWORD: 'pw', LOG_LEVEL: process.env.LOG_LEVEL || 'warn',
  };
  const srv = spawn(process.execPath, [path.join(ROOT, 'src/index.js')], { env, stdio: ['ignore', 'inherit', 'inherit'] });
  procs.push(srv);
  for (let i = 0; i < 50; i++) { try { await req('GET', BASE + '/health'); break; } catch { await sleep(100); } }

  console.log('admin');
  token = (await api('POST', '/admin/api/login', { username: 'admin', password: 'pw' })).token;
  ok(!!token, 'signs in');
  let wrong = null; try { await api('POST', '/admin/api/login', { username: 'admin', password: 'nope' }); } catch (e) { wrong = e; }
  ok(wrong && /401/.test(wrong.message), 'rejects a wrong password');

  console.log('catalogs → libraries');
  await sleep(500);
  let st = await waitIdle();
  const libs = st.library.libs;
  ok(libs.length === 4, `4 libraries (2 catalogs + Added Movies/Shows): ${libs.map((l) => l.name).join(', ')}`);
  let ms = await mockState();
  ok(ms.sections.length === 4, 'Plex libraries created');
  ok(ms.sections.find((s) => s.title === 'Popular Shows')?.agent === 'tv.plex.agents.series', 'show library uses the Plex TV Series agent');
  const movieLib = libs.find((l) => l.name === 'Popular Movies'); const showLib = libs.find((l) => l.name === 'Popular Shows');
  ok(ms.sections.some((s) => s.Location[0].path === movieLib.path && movieLib.path.startsWith('/media/aioplex/')), 'library points at the mount path');

  console.log('WebDAV tree');
  const root = await davList('');
  ok(root.status === 207 && root.items.length === 4 && root.items.every((i) => i.dir), 'root lists the 4 library folders');
  const movies = await davList(movieLib.folder + '/');
  ok(movies.items.length === 5, `5 of 6 movies have a playable stream (got ${movies.items.length})`);
  ok(movies.items.some((i) => i.name === 'Test Movie 1 (2010) {imdb-tt1000000}'), 'movie folder named "Title (Year) {imdb-tt…}"');
  const m1 = await davList(enc(movieLib.folder, 'Test Movie 1 (2010) {imdb-tt1000000}') + '/');
  const names = m1.items.map((i) => i.name).sort();
  ok(names.length === 2 && names[0] === 'Test Movie 1 (2010) - 1080p.mkv' && names[1] === 'Test Movie 1 (2010) - 4K.mkv', `two versions, 4K + 1080p: ${names.join(' | ')}`);
  const f4k = m1.items.find((i) => i.name.includes('4K'));
  ok(f4k.size === 70 * MB + 123, 'uncached and broken (error clip) 4K results skipped; exact size reported');
  const show = await davList(enc(showLib.folder, 'Test Show 1 (2019) {imdb-tt2000000}') + '/');
  ok(show.items.map((i) => i.name).sort().join() === 'Season 01,Season 02', 'show has Season 01/02, no Specials');
  const s2 = await davList(enc(showLib.folder, 'Test Show 1 (2019) {imdb-tt2000000}', 'Season 02') + '/');
  ok(s2.items.length === 2 && s2.items[0].name === 'Test Show 1 (2019) - s02e01 - 4K.mkv', `unaired s02e03 left out; episode naming: ${s2.items[0] && s2.items[0].name}`);
  const depth0 = await req('PROPFIND', BASE + '/dav/' + enc(movieLib.folder) + '/', { headers: { depth: '0' } });
  ok((depth0.body.toString().match(/<D:response>/g) || []).length === 1, 'Depth: 0 returns only the folder itself');
  ok((await req('PROPFIND', BASE + '/dav/nope/', { headers: { depth: '1' } })).status === 404, 'unknown path → 404');

  console.log('season and series packs');
  const { packOf } = require(path.join(ROOT, 'src/aio.js'));
  ok(packOf('The.Bear.S02.1080p.WEB-DL-GRP') === 'season' && packOf('The Bear Season 2 Complete 1080p') === 'season', 'recognises season packs');
  ok(packOf('Breaking.Bad.S01-S05.1080p') === 'series' && packOf('The Office Complete Series 720p') === 'series' && packOf('Seasons 1-4 1080p') === 'series', 'recognises series packs');
  ok(packOf('The.Bear.S02E03.1080p') === null && packOf('Some.Movie.2010.1080p') === null, 'single episodes and movies are not packs');
  const s1 = await davList(enc(showLib.folder, 'Test Show 1 (2019) {imdb-tt2000000}', 'Season 01') + '/');
  ok(s1.items.length === 3 && s1.items.every((i, n) => i.size === 60 * MB + (n + 1) * 1000), 'episodes come from the 4K season pack, ahead of single-episode 4K results listed earlier');
  await sleep(1700); // library.json is saved with a short delay
  const saved = JSON.parse(fs.readFileSync(path.join(data, 'library.json'), 'utf8'));
  const trusted = Object.entries(saved.pins).filter(([k, ps]) => k.startsWith('tt2') && ps.some((p) => p.trusted));
  ok(trusted.length >= 1 && Object.keys(saved.packs).some((k) => k.startsWith('tt2000000:1:')), `later episodes of a checked pack skip the debrid check (${trusted.length} episodes)`);
  const [tKey] = trusted[0];
  const [, tS, tE] = tKey.split(':');
  const tShow = tKey.startsWith('tt2000000') ? 'Test Show 1' : 'Test Show 2';
  const tPath = '/dav/' + enc(showLib.folder, `${tShow} (2019) {imdb-${tKey.split(':')[0]}}`, `Season 0${tS}`, `${tShow} (2019) - s0${tS}e0${tE} - 4K.mkv`);
  const tr = await req('GET', BASE + tPath, { headers: { range: 'bytes=100-199' } });
  const tLoc = tr.headers.location || '';
  const tBody = tLoc ? await req('GET', tLoc, { headers: { range: 'bytes=0-0' } }) : null;
  const tSeed = tBody ? tBody.body[0] : -1;
  const tRead = tLoc ? await req('GET', tLoc, { headers: { range: 'bytes=100-199' } }) : null;
  ok(tr.status === 302 && tRead && tRead.body[50] === expectByte(150, tSeed), 'a file pinned without a check is checked on first read and plays');

  console.log('reading files');
  const filePath = '/dav/' + enc(movieLib.folder, 'Test Movie 1 (2010) {imdb-tt1000000}', 'Test Movie 1 (2010) - 1080p.mkv');
  let r = await req('GET', BASE + filePath, { headers: { range: 'bytes=1000-1999' } });
  ok(r.status === 302 && /\/files\//.test(r.headers.location), 'redirect mode sends the player to the resolved debrid link');
  const seedOf = async (loc) => { const x = await req('GET', loc, { headers: { range: 'bytes=0-0' } }); return (x.body[0] - 0 + 251) % 251; };
  const seed = await seedOf(r.headers.location);
  const up = await req('GET', r.headers.location, { headers: { range: 'bytes=1000-1999' } });
  ok(up.status === 206 && up.body.length === 1000 && up.body[5] === expectByte(1005, seed), 'redirect target serves the right bytes');
  const head = await req('HEAD', BASE + filePath);
  ok(head.status === 200 && Number(head.headers['content-length']) === 40 * MB + 7, 'HEAD reports the exact size');
  ok((await req('GET', BASE + filePath, { headers: { range: 'bytes=99999999999-' } })).status === 416, 'out-of-range read → 416');

  await api('POST', '/admin/api/settings', { streamMode: 'proxy' });
  r = await req('GET', BASE + filePath, { headers: { range: 'bytes=5000-5999' } });
  ok(r.status === 206 && r.body.length === 1000 && r.body[0] === expectByte(5000, seed) && /\/41943047$/.test(r.headers['content-range']), 'proxy mode relays the range with the right Content-Range');
  r = await req('GET', BASE + filePath, { headers: { range: 'bytes=-10' } });
  ok(r.status === 206 && r.body.length === 10 && r.body[9] === expectByte(40 * MB + 6, seed), 'suffix range (last 10 bytes)');
  await api('POST', '/admin/api/settings', { streamMode: 'redirect' });

  console.log('search and add');
  const found = await api('GET', '/admin/api/search?q=searchable');
  ok(found.some((x) => x.id === 'tt3000000'), 'search finds a title from a search-only catalog');
  await api('POST', '/admin/api/add', { id: 'tt3000000', type: 'movie' });
  await sleep(300); await waitIdle();
  const added = await davList('added-movies/');
  ok(added.items.some((i) => i.name === 'Searchable Film (2021) {imdb-tt3000000}'), 'added title appears in Added Movies');
  const list = await api('GET', '/admin/api/added');
  ok(list.length === 1 && list[0].pinned === 1, 'added list shows it as ready');
  await api('POST', '/admin/api/add', { id: 'tt2000001', type: 'series' });
  await sleep(300); await waitIdle();
  ok((await davList('added-shows/')).items.length === 1, 'a show can be added too (also stays in its catalog library)');

  console.log('Plex scans');
  await sleep(21_000);
  ms = await mockState();
  ok(ms.refreshes.length >= 2, `libraries rescanned after changes (${[...new Set(ms.refreshes)].join(',')})`);

  console.log('removing');
  await api('DELETE', '/admin/api/added/tt3000000');
  ok((await davList('added-movies/')).items.length === 0, 'removed title leaves the folder tree');

  console.log('adopting the server');
  let claimErr = null; try { await api('POST', '/admin/api/plex/claim', { claimToken: 'nope' }); } catch (e) { claimErr = e; }
  ok(claimErr && /claim-/.test(claimErr.message), 'rejects something that is not a claim token');
  const cl = await api('POST', '/admin/api/plex/claim', { claimToken: 'claim-good' });
  ok(cl.claimed === true, 'claims the server with a claim token');
  await sleep(4500);
  ms = await mockState();
  ok(ms.prefs.GenerateBIFBehavior === 'never' && ms.prefs.ButlerTaskDeepMediaAnalysis === '0' && ms.prefs.autoEmptyTrash === '0', 'switches off Plex features that would download whole files');
  ok(ms.prefs.FriendlyName === 'AIOPlex', 'sets the server name');
  st = await api('GET', '/admin/api/status');
  ok(st.plex.claimed && st.plex.authorized && st.plex.reachable, 'status shows Plex reachable, adopted and authorised');

  console.log('new episodes');
  const EP = 'tt2000000:2:3';
  const recentFor = async (key) => (await api('GET', '/admin/api/status')).resolver.recent.filter((x) => x.key === key).length;
  const s2path = enc(showLib.folder, 'Test Show 1 (2019) {imdb-tt2000000}', 'Season 02') + '/';
  await req('GET', `http://127.0.0.1:7001/_nostreams/${EP}`);
  await req('GET', `http://127.0.0.1:7001/_air/${EP}`); // its air date arrives
  let ac = await api('POST', '/admin/api/airing-check');
  ok(ac.shows >= 1 && ac.added === 1, `airing check notices the new episode (${ac.shows} airing shows, ${ac.added} new)`);
  await sleep(300); await waitIdle();
  ok(await recentFor(EP) === 1 && (await davList(s2path)).items.length === 2, 'looked up right away; no cached release yet, so not in Plex');
  const missOld = await recentFor('tt1000005');
  ac = await api('POST', '/admin/api/airing-check');
  await sleep(300); await waitIdle();
  ok(await recentFor(EP) === 1, 'not retried again before FRESH_RETRY_MIN');
  await req('GET', `http://127.0.0.1:7001/_streams/${EP}`); // a release shows up
  await api('POST', '/admin/api/settings', { freshRetryMin: 0 });
  await sleep(300); await waitIdle();
  const s2now = await davList(s2path);
  ok(s2now.items.some((i) => i.name === 'Test Show 1 (2019) - s02e03 - 4K.mkv'), 'retried with a fresh lookup and added once a release is cached');
  ok(await recentFor('tt1000005') === missOld, 'older titles without a stream still wait RETRY_MISSING_HOURS');
  await api('POST', '/admin/api/settings', { freshRetryMin: 30 });
  const lib = require(path.join(ROOT, 'src/library.js'));
  ok(lib.isFresh({ rel: Date.now() - 3600_000 }) && !lib.isFresh({ rel: Date.now() - 72 * 3600_000 }) && !lib.isFresh({ rel: null }), 'episodes count as new for FRESH_EPISODE_HOURS');

  console.log('seasons of catalog shows');
  await api('POST', '/admin/api/settings', { catalogShowSeasons: 1 });
  await sleep(1500); await waitIdle();
  ok((await davList(enc(showLib.folder, 'Test Show 1 (2019) {imdb-tt2000000}') + '/')).items.map((i) => i.name).join() === 'Season 02', 'keeps the latest season of a catalog show');
  ok((await davList(enc(showLib.folder, 'Test Show 2 (2019) {imdb-tt2000001}') + '/')).items.length === 2, 'a show you added keeps every season');
  await api('POST', '/admin/api/settings', { catalogShowSeasons: 0 });
  await sleep(1500); await waitIdle();
  ok((await davList(enc(showLib.folder, 'Test Show 1 (2019) {imdb-tt2000000}') + '/')).items.length === 2, 'setting it back to 0 brings the other seasons back');

  console.log('separate 4K libraries');
  await api('POST', '/admin/api/settings', { split4k: true });
  await sleep(500); await waitIdle(); await sleep(500);
  st = await api('GET', '/admin/api/status');
  ok(st.library.libs.some((l) => l.name === 'Movies 4K') && st.library.libs.some((l) => l.name === 'Series 4K'), 'Movies 4K and Series 4K libraries listed');
  ms = await mockState();
  ok(ms.sections.some((x) => x.title === 'Movies 4K' && x.type === 'movie') && ms.sections.some((x) => x.title === 'Series 4K' && x.type === 'show'), 'and created in Plex with the right types');
  const reg = await davList(enc(movieLib.folder, 'Test Movie 1 (2010) {imdb-tt1000000}') + '/');
  ok(reg.items.length === 1 && reg.items[0].name === 'Test Movie 1 (2010) - 1080p.mkv', `regular movie library has no 4K: ${reg.items.map((i) => i.name).join(' | ')}`);
  const m4 = await davList(enc('movies-4k', 'Test Movie 1 (2010) {imdb-tt1000000}') + '/');
  ok(m4.items.length === 1 && m4.items[0].name === 'Test Movie 1 (2010) - 4K.mkv' && m4.items[0].size === 70 * MB + 123, 'Movies 4K holds only the 4K version');
  ok((await davList('movies-4k/')).items.length === 5, 'every movie with a 4K release is in Movies 4K');
  const ep = await davList(enc(showLib.folder, 'Test Show 1 (2019) {imdb-tt2000000}', 'Season 01') + '/');
  ok(ep.items.length === 3 && ep.items.every((i) => / - 1080p\.mkv$/.test(i.name)), 'regular show library re-picked to 1080p episodes');
  ok(ep.items.every((i, n) => i.size === 30 * MB + 100 + n + 1), '1080p episodes come from the complete-series pack');
  const ep4 = await davList(enc('series-4k', 'Test Show 1 (2019) {imdb-tt2000000}', 'Season 01') + '/');
  ok(ep4.items.length === 3 && ep4.items.every((i) => / - 4K\.mkv$/.test(i.name)), 'Series 4K has the 4K episodes');
  const lib4 = st.library.libs.find((l) => l.name === 'Movies 4K');
  ok(lib4.titles === 5 && lib4.pinned === 5, 'admin page counts 4K titles');
  await api('POST', '/admin/api/settings', { split4k: false });
  await sleep(500); await waitIdle(); await sleep(800);
  ms = await mockState();
  ok(!ms.sections.some((x) => /4K$/.test(x.title)), 'turning it off removes the 4K libraries');
  const back = await davList(enc(movieLib.folder, 'Test Movie 1 (2010) {imdb-tt1000000}') + '/');
  ok(back.items.length === 2 && back.items.some((i) => i.name.includes('4K')), '4K goes back into the regular libraries');

  console.log('healing a dead link');
  await api('POST', '/admin/api/settings', { linkTtlSec: 0 });
  const m2 = await davList(enc(movieLib.folder, 'Test Movie 2 (2011) {imdb-tt1000001}') + '/');
  const p1080 = '/dav/' + enc(movieLib.folder, 'Test Movie 2 (2011) {imdb-tt1000001}', 'Test Movie 2 (2011) - 1080p.mkv');
  await req('GET', 'http://127.0.0.1:7001/_break/Test.Movie.2.2011.1080p.BluRay.x264.mkv');
  r = await req('GET', BASE + p1080, { headers: { range: 'bytes=0-9' } });
  ok(r.status === 503, 'a dead release answers 503 while a new one is picked');
  await sleep(300); await waitIdle();
  const m2b = await davList(enc(movieLib.folder, 'Test Movie 2 (2011) {imdb-tt1000001}') + '/');
  const new1080 = m2b.items.find((i) => i.name.includes('1080p'));
  ok(new1080 && new1080.size === 35 * MB && m2.items.find((i) => i.name.includes('1080p')).size === 40 * MB + 7, 're-pinned to the next 1080p result (new size)');
  await api('POST', '/admin/api/settings', { linkTtlSec: 3600 });

  const rclone = process.env.RCLONE || (() => { try { return execFileSync('which', ['rclone']).toString().trim(); } catch { return ''; } })();
  if (rclone) {
    console.log('rclone (the same WebDAV backend the Plex container mounts)');
    const remote = `:webdav,url='${BASE}/dav',vendor=other:`;
    const lsl = execFileSync(rclone, ['lsl', remote + movieLib.folder], { encoding: 'utf8' });
    ok(/41943047 .*Test Movie 1 \(2010\) - 1080p\.mkv/.test(lsl), 'rclone lists files with exact sizes');
    const buf = execFileSync(rclone, ['cat', '--offset', '123456', '--count', '64', remote + enc(movieLib.folder, 'Test Movie 1 (2010) {imdb-tt1000000}', 'Test Movie 1 (2010) - 1080p.mkv').split('/').map(decodeURIComponent).join('/')]);
    ok(buf.length === 64 && buf[0] === expectByte(123456, seed) && buf[63] === expectByte(123456 + 63, seed), 'rclone reads a range through the redirect');
  } else console.log('(rclone not found; set RCLONE=/path/to/rclone to include those checks)');

  console.log('turning a catalog off');
  const cats = await api('GET', '/admin/api/catalogs');
  await api('POST', '/admin/api/catalogs', { enabled: cats.filter((c) => c.enabled && c.type === 'movie').map((c) => c.key) });
  await sleep(1500);
  ms = await mockState();
  ok(!ms.sections.some((s) => s.title === 'Popular Shows'), 'its Plex library is removed');
  ok((await davList('')).items.length === 3, 'and its folder');
  ok((await davList('added-shows/')).items.length === 1, 'a show that was also added by hand stays in Added Shows');
}

main().catch((e) => { fail++; console.error(e); }).finally(() => {
  for (const p of procs) p.kill();
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
});
