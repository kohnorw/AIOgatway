(function () {
  'use strict';

  var app = document.getElementById('app');
  var state = { token: load('aioplex_token'), status: null, page: location.hash.replace('#', '') || 'overview', catalogs: null, results: null, query: '', added: null, busy: {}, error: '' };
  var poll = null;

  function load(k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }
  function store(k, v) { try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(sel) { return app.querySelector(sel); }
  function $$(sel) { return Array.prototype.slice.call(app.querySelectorAll(sel)); }

  function api(method, path, body) {
    return fetch(path, { method: method, headers: { 'content-type': 'application/json', 'x-aioplex-token': state.token || '' }, body: body ? JSON.stringify(body) : undefined }).then(function (r) {
      return r.text().then(function (t) {
        var j = null; try { j = t ? JSON.parse(t) : null; } catch (e) {}
        if (r.status === 401 && path !== '/admin/api/login') { store('aioplex_token', ''); state.token = ''; }
        if (!r.ok) { var err = new Error((j && j.error) || ('Request failed (' + r.status + ')')); err.status = r.status; throw err; }
        return j;
      });
    });
  }

  function toast(msg, ok) {
    var old = document.querySelector('.toast'); if (old) old.remove();
    var el = document.createElement('div');
    el.className = 'toast ' + (ok === false ? 'alert-error' : 'alert-success');
    el.setAttribute('role', 'status');
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(function () { el.remove(); }, 3600);
  }

  function refresh() {
    return api('GET', '/admin/api/status').then(function (s) { state.status = s; state.error = ''; render(); })
      .catch(function (e) { state.status = null; state.error = e.status === 401 ? '' : e.message; render(); });
  }

  function fmtMs(ms) { return ms >= 1000 ? (ms / 1000).toFixed(ms >= 10000 ? 0 : 1) + ' s' : Math.round(ms) + ' ms'; }
  function ago(ts) {
    var s = Math.round((Date.now() - ts) / 1000);
    return s < 60 ? s + 's ago' : s < 3600 ? Math.round(s / 60) + 'm ago' : Math.round(s / 3600) + 'h ago';
  }
  function switchHtml(key, on, label) {
    return '<button type="button" role="switch" class="switch" data-key="' + esc(key) + '" data-kind="bool" aria-checked="' + !!on + '" aria-label="' + esc(label) + '" data-state="' + (on ? 'checked' : 'unchecked') + '"><span class="switch-thumb"></span></button>';
  }
  function bar(done, total) {
    var pct = total ? Math.round(100 * done / total) : 0;
    return '<div class="progress" role="progressbar" aria-valuenow="' + pct + '" aria-valuemin="0" aria-valuemax="100"><div class="progress-fill" style="width:' + pct + '%"></div></div>';
  }

  // ── Setup + login ────────────────────────────────────────────────────
  function setupView() {
    return '<div class="login-page"><form class="login-card" data-form="setup">' +
      '<div class="login-header"><span class="login-brand-label">AIOPlex</span><h1 class="login-title">Set up</h1>' +
      '<p class="login-subtitle">Create an admin account for this page and connect AIOStreams. You\'ll adopt the Plex server next.</p></div>' +
      '<div class="login-body">' + (state.error ? '<div class="alert-error">' + esc(state.error) + '</div>' : '') +
      '<div class="field"><label class="field-label" for="su-user">Username</label><input class="field-input" id="su-user" name="username" autocomplete="username" required></div>' +
      '<div class="field"><label class="field-label" for="su-pass">Password</label><input class="field-input" id="su-pass" name="password" type="password" autocomplete="new-password" required></div>' +
      '<div class="field"><label class="field-label" for="su-url">AIOStreams manifest URL</label><input class="field-input" id="su-url" name="aioUrl" placeholder="https://aiostreams.example.com/stremio/…/manifest.json" spellcheck="false">' +
      '<p class="field-hint">In AIOStreams, open your configuration and copy the install link. You can add this later.</p></div>' +
      '<button class="btn btn-primary login-btn" type="submit">Create account</button></div></form></div>';
  }
  function loginView() {
    return '<div class="login-page"><form class="login-card" data-form="login">' +
      '<div class="login-header"><span class="login-brand-label">AIOPlex</span><h1 class="login-title">Sign in</h1></div>' +
      '<div class="login-body">' + (state.error ? '<div class="alert-error">' + esc(state.error) + '</div>' : '') +
      '<div class="field"><label class="field-label" for="li-user">Username</label><input class="field-input" id="li-user" name="username" autocomplete="username" required></div>' +
      '<div class="field"><label class="field-label" for="li-pass">Password</label><input class="field-input" id="li-pass" name="password" type="password" autocomplete="current-password" required></div>' +
      '<button class="btn btn-primary login-btn" type="submit">Sign in</button></div></form></div>';
  }

  // ── Layout ───────────────────────────────────────────────────────────
  var PAGES = [['overview', 'Overview'], ['libraries', 'Libraries'], ['search', 'Search & add'], ['settings', 'Settings'], ['admins', 'Admins']];
  function shell(inner) {
    var s = state.status;
    var nav = PAGES.map(function (p) {
      return '<button class="nav-item' + (state.page === p[0] ? ' nav-item-active' : '') + '" data-nav="' + p[0] + '"' + (state.page === p[0] ? ' aria-current="page"' : '') + '>' + p[1] + '</button>';
    }).join('');
    var title = (PAGES.filter(function (p) { return p[0] === state.page; })[0] || PAGES[0])[1];
    return '<div class="layout">' +
      '<aside class="sidebar' + (state.navOpen ? ' sidebar-open' : '') + '"><div class="sidebar-brand">' +
      '<span class="brand-label">AIOPlex</span><p class="brand-title">' + esc(s.settings.serverName) + '</p></div>' +
      '<nav class="sidebar-nav" aria-label="Admin">' + nav + '</nav>' +
      '<div class="sidebar-footer"><a class="nav-item" href="https://app.plex.tv/desktop" target="_blank" rel="noopener">Open Plex</a><button class="nav-item" data-action="logout">Sign out</button></div></aside>' +
      (state.navOpen ? '<div class="sidebar-overlay" data-action="nav-close"></div>' : '') +
      '<main class="main"><header class="main-header"><button class="hamburger" data-action="nav-open" aria-label="Open menu">☰</button><h1 class="main-title">' + title + '</h1></header>' +
      '<div class="content">' + inner + '</div></main></div>';
  }

  // ── Overview ─────────────────────────────────────────────────────────
  function plexCard() {
    var p = state.status.plex;
    var body;
    var signin = '<button class="btn btn-primary" data-action="plex-signin"' + (state.busy.signin ? ' disabled' : '') + '>' + (state.busy.signin ? 'Waiting for Plex…' : 'Sign in with Plex') + '</button>';
    if (!p.reachable) {
      body = '<p><span class="status-dot bad"></span>Can\'t reach Plex at <code>' + esc(p.url) + '</code>' + (p.error ? ': ' + esc(p.error) : '') + '</p>' +
        '<p class="field-hint">Is the <code>plex</code> container running? It can take a minute to start the first time. The address is the <em>Plex URL</em> setting.</p>';
    } else if (!p.claimed) {
      body = '<p><span class="status-dot"></span>Plex is running but not adopted yet. Adopting links it to your Plex account so it shows up in every Plex app.</p>' +
        '<div class="form-actions" style="justify-content:flex-start">' + (p.signedIn
          ? '<button class="btn btn-primary" data-action="plex-claim"' + (state.busy.claim ? ' disabled' : '') + '>' + (state.busy.claim ? 'Adopting…' : 'Adopt server as ' + esc(p.user)) + '</button>'
          : signin) + '</div>' +
        '<details class="more"><summary>Or use a claim token</summary>' +
        '<form class="inline" data-form="claim"><div class="field"><label class="field-label" for="claim-token">Claim token from <a href="https://plex.tv/claim" target="_blank" rel="noopener">plex.tv/claim</a> (valid 4 minutes)</label>' +
        '<input class="field-input" id="claim-token" name="claimToken" placeholder="claim-xxxxxxxxxxxxxxxxxxxx" spellcheck="false"></div><button class="btn btn-ghost" type="submit">Adopt</button></form></details>';
    } else if (!p.authorized) {
      body = '<p><span class="status-dot"></span>Adopted, but AIOPlex has no access to it yet' + (p.authError ? ' (' + esc(p.authError) + ')' : '') + '. Sign in with the Plex account that owns it.</p>' +
        '<div class="form-actions" style="justify-content:flex-start">' + signin + '</div>';
    } else {
      body = '<p><span class="status-dot ok"></span>Adopted: <strong>' + esc(p.friendlyName || 'Plex') + '</strong> · Plex ' + esc((p.version || '').split('-')[0]) + '</p>' +
        '<div class="kv-row"><span class="kv-label">Access</span><span class="kv-value">' + esc(p.tokenSource) + '</span></div>' +
        '<div class="kv-row"><span class="kv-label">Watchlist</span><span class="kv-value">' + (state.status.settings.watchlist ? 'Titles you add to your Plex Watchlist appear in Added Movies / Added Shows' : 'Off') + '</span></div>' +
        ((p.checks || []).length ? '<div class="alert-error"><strong>Change ' + (p.checks.length === 1 ? 'this Plex setting' : 'these Plex settings') + ':</strong><ul class="result-list">' +
          p.checks.map(function (c) { return '<li>' + esc(c.name) + ': ' + esc(c.why) + '</li>'; }).join('') + '</ul></div>' : '') +
        '<div class="form-actions"><a class="btn btn-ghost" href="https://app.plex.tv/desktop" target="_blank" rel="noopener">Open Plex</a>' +
        (p.signedIn ? '<button class="btn btn-ghost" data-action="plex-signout">Sign out of Plex</button>' : signin.replace('btn-primary', 'btn-ghost')) +
        '<button class="btn btn-primary" data-action="plex-sync">Rescan libraries</button></div>';
    }
    return '<section class="card"><div class="card-header"><h2 class="card-title">Plex server</h2></div><div class="card-body">' + body + '</div></section>';
  }

  function libraryCard() {
    var L = state.status.library; var R = state.status.resolver;
    var rows = L.libs.map(function (l) {
      return '<div class="lib-row"><div><div class="user-name">' + esc(l.name) + ' <span class="chip">' + (l.kind === 'show' ? 'Shows' : 'Movies') + '</span>' + (l.sectionId ? '' : ' <span class="chip">not in Plex yet</span>') + '</div>' +
        '<div class="user-meta">' + (l.key.indexOf('4k:') === 0
          ? l.titles + (l.kind === 'show' ? ' shows' : ' movies') + ' in 4K · ' + l.pinned + (l.kind === 'show' ? ' episodes' : '') + ' with a 4K version'
          : l.titles + ' titles · ' + l.pinned + ' of ' + l.units + (l.kind === 'show' ? ' episodes' : ' movies') + ' ready' + (l.missing ? ' · ' + l.missing + ' without a usable stream' : '')) + '</div></div>' +
        (l.key.indexOf('4k:') === 0 ? '<span></span>' :
        bar(l.pinned, l.units)) + '</div>';
    }).join('');
    var activity = (R.recent || []).slice(0, 10).map(function (x) {
      return '<li><span class="status-dot ' + (x.ok ? 'ok' : 'bad') + '"></span>' + esc(x.name) + ' <span class="muted">' + esc(x.key) + '</span> — ' + esc(x.what) + ' <span class="muted">' + ago(x.at) + '</span></li>';
    }).join('');
    return '<section class="card"><div class="card-header"><h2 class="card-title">Libraries</h2><span class="field-hint">' +
      (R.pending || R.running.length ? 'Finding streams: ' + (R.pending + R.running.length) + ' to go' : 'Up to date') + '</span></div>' +
      '<div class="card-body tight">' + rows + '</div>' +
      '<div class="card-body"><div class="inline" style="align-items:center;justify-content:space-between"><span class="field-hint">' + L.airing + ' airing show' + (L.airing === 1 ? '' : 's') + ' watched for new episodes' +
        (L.lastAiringCheck ? ', last checked ' + ago(L.lastAiringCheck) : '') + '</span><button class="btn btn-ghost" data-action="airing-check">Check for new episodes now</button></div></div>' +
      (activity ? '<div class="card-body"><ul class="result-list">' + activity + '</ul>' +
        (L.misses ? '<div class="form-actions"><button class="btn btn-ghost" data-action="retry">Retry ' + L.misses + ' without a stream now</button></div>' : '') + '</div>' : '') + '</section>';
  }

  function overviewView() {
    var s = state.status;
    var conn = s.manifestError
      ? '<p><span class="status-dot bad"></span>Can\'t reach AIOStreams: ' + esc(s.manifestError) + '</p>'
      : s.manifest
        ? '<p><span class="status-dot ok"></span>Connected to <strong>' + esc(s.manifest.name || 'AIOStreams') + '</strong> ' + esc(s.manifest.version || '') + ', ' + s.manifest.catalogs + ' catalogs</p>'
        : '<p><span class="status-dot"></span>Not connected. Paste your AIOStreams manifest URL to get started.</p>';
    var noCats = s.configured && !s.library.libs.some(function (l) { return l.key.indexOf('cat:') === 0; });
    return plexCard() +
      '<section class="card"><div class="card-header"><h2 class="card-title">AIOStreams</h2></div><div class="card-body">' + conn +
      '<form class="inline" data-form="connect"><div class="field"><label class="field-label" for="aio-url">Manifest URL</label>' +
      '<input class="field-input" id="aio-url" name="url" value="' + esc(s.settings.aioUrl) + '" placeholder="https://…/manifest.json" spellcheck="false"></div>' +
      '<button class="btn btn-ghost" type="button" data-action="test-url">Test</button><button class="btn btn-primary" type="submit">Save</button></form>' +
      '<div id="test-out"></div>' +
      (noCats ? '<div class="alert-success">Next: pick which catalogs become Plex libraries on the <a href="#libraries" data-nav="libraries">Libraries</a> page.</div>' : '') +
      '</div></section>' + libraryCard();
  }

  // ── Libraries (catalog picker) ───────────────────────────────────────
  function librariesView() {
    if (!state.status.configured) return '<div class="card"><div class="card-body"><div class="empty-state">Connect AIOStreams on the Overview page first.</div></div></div>';
    if (!state.catalogs) { loadCatalogs(); return '<div class="card"><div class="card-body"><p class="loading-text">Loading catalogs…</p></div></div>'; }
    var browse = state.catalogs.filter(function (c) { return c.browsable; });
    var other = state.catalogs.filter(function (c) { return !c.browsable; });
    function row(c, i) {
      return '<div class="cat-row' + (c.enabled ? '' : ' off') + '" data-cat="' + esc(c.key) + '">' +
        switchHtml('cat:' + c.key, c.enabled, 'Make ' + c.originalName + ' a Plex library') +
        '<div><label class="sr-only" for="n' + i + '">Library name</label><input class="field-input" id="n' + i + '" data-name="' + esc(c.key) + '" value="' + esc(c.name === c.originalName ? '' : c.name) + '" placeholder="' + esc(c.originalName) + '">' +
        '<div class="cat-sub">' + (c.kind === 'show' ? 'TV shows' : 'Movies') + ' · ' + esc(c.type) + '/' + esc(c.id) + '</div></div><span></span></div>';
    }
    var s = state.status.settings;
    return '<section class="card"><div class="card-header"><h2 class="card-title">Catalogs as Plex libraries</h2><span class="field-hint">Up to ' + s.catalogLimit + ' titles each, refreshed every ' + Math.round(s.catalogRefreshMin / 60 * 10) / 10 + ' h</span></div>' +
      '<div class="card-body tight">' + (browse.length ? browse.map(row).join('') : '<div class="empty-state">Your AIOStreams setup has no browsable movie or series catalogs.</div>') + '</div></section>' +
      '<div class="form-actions"><button class="btn btn-primary" data-action="save-catalogs">Save libraries</button></div>' +
      '<section class="card"><div class="card-body"><p class="field-hint">Every library you turn on is created in Plex for you. Streams are looked up for each movie and aired episode in the background, and titles appear in Plex as soon as a cached stream is found. ' +
      'Shows cost one AIOStreams lookup per episode, so big TV catalogs take a while to fill; <em>Seasons of catalog shows</em> in Settings can limit that. Titles you add yourself or put on your Plex Watchlist go in <strong>Added Movies</strong> and <strong>Added Shows</strong>.</p>' +
      (other.length ? '<p class="field-hint">Not usable as libraries (search-only or no Plex equivalent): ' + other.map(function (c) { return esc(c.originalName); }).join(', ') + '.</p>' : '') + '</div></section>';
  }
  function loadCatalogs() {
    api('GET', '/admin/api/catalogs').then(function (c) { state.catalogs = c; render(); }).catch(function (e) { toast(e.message, false); });
  }

  // ── Search & add ─────────────────────────────────────────────────────
  function searchView() {
    if (!state.added) { api('GET', '/admin/api/added').then(function (a) { state.added = a; render(); }).catch(function () {}); }
    var res = '';
    if (state.busy.search) res = '<p class="loading-text">Searching…</p>';
    else if (state.results && !state.results.length) res = '<div class="empty-state">Nothing found for “' + esc(state.query) + '”.</div>';
    else if (state.results) {
      res = '<div class="poster-grid">' + state.results.map(function (m) {
        var btn = m.added ? '<button class="btn btn-ghost" disabled>Added</button>'
          : '<button class="btn btn-primary" data-add="' + esc(m.id) + '" data-type="' + esc(m.type) + '"' + (state.busy['add:' + m.id] ? ' disabled' : '') + '>' + (state.busy['add:' + m.id] ? 'Adding…' : 'Add to Plex') + '</button>';
        return '<div class="poster-card">' + (m.poster ? '<img loading="lazy" alt="" src="' + esc(m.poster) + '">' : '<div class="poster-ph">' + esc(m.name) + '</div>') +
          '<div class="poster-meta"><div class="poster-title">' + esc(m.name) + '</div><div class="user-meta">' + (m.kind === 'show' ? 'Show' : 'Movie') + (m.year ? ' · ' + esc(m.year) : '') + (m.inLibrary && !m.added ? ' · in a library' : '') + '</div>' + btn + '</div></div>';
      }).join('') + '</div>';
    }
    var added = state.added;
    var addedHtml = !added ? '<p class="loading-text">Loading…</p>' : !added.length ? '<div class="empty-state">Nothing added yet. Search above, or add titles to your Plex Watchlist from any Plex app.</div>'
      : added.map(function (t) {
        var stateTxt = t.pinned ? (t.kind === 'show' ? t.pinned + ' of ' + t.units + ' episodes ready' : 'Ready in Plex') : t.missing ? 'No cached stream found yet' : 'Finding streams…';
        return '<div class="user-row"><div><div class="user-name">' + esc(t.name) + (t.year ? ' (' + t.year + ')' : '') + (t.watchlist ? ' <span class="chip">Watchlist</span>' : '') + '</div>' +
          '<div class="user-meta">' + (t.kind === 'show' ? 'Show' : 'Movie') + ' · ' + esc(t.id) + ' · ' + stateTxt + '</div></div>' +
          '<div class="catalog-actions"><button class="btn btn-ghost" data-remove="' + esc(t.id) + '" data-tname="' + esc(t.name) + '">Remove</button></div></div>';
      }).join('');
    return '<section class="card"><div class="card-header"><h2 class="card-title">Find a movie or show</h2></div><div class="card-body">' +
      '<form class="inline" data-form="search"><div class="field"><label class="field-label" for="q">Title or IMDb id</label><input class="field-input" id="q" name="q" value="' + esc(state.query) + '" placeholder="The Bear, Dune, tt0111161…" autocomplete="off"></div>' +
      '<button class="btn btn-primary" type="submit">Search</button></form>' + res +
      '<p class="field-hint">Searches your AIOStreams catalogs and Cinemeta. In Plex apps you can also search, open a title from <em>Movies &amp; Shows on Plex</em> and add it to your Watchlist; it shows up here within a minute.</p></div></section>' +
      '<section class="card"><div class="card-header"><h2 class="card-title">Added by you</h2><span class="field-hint">In Added Movies / Added Shows</span></div><div class="card-body tight">' + addedHtml + '</div></section>';
  }

  // ── Settings ─────────────────────────────────────────────────────────
  var GROUPS = [
    ['Plex', [
      ['plexShared', 'bool', 'Using my existing Plex server', 'Leaves server-wide Plex settings (and the server name) alone, so your other libraries are untouched. AIOPlex still configures its own libraries, and the Overview page lists any server setting worth changing.'],
      ['serverName', 'text', 'Server name', 'The name Plex apps show for this server (not changed on an existing server).'],
      ['plexUrl', 'text', 'Plex URL', 'How AIOPlex reaches Plex. With the included compose file: http://plex:32400.'],
      ['mountPath', 'text', 'Library path inside Plex', 'Where the rclone mount appears in the Plex container. Must match AIOPLEX_MOUNT there.'],
      ['libraryPrefix', 'text', 'Library name prefix', 'Optional text in front of every library name, e.g. "AIO · ".'],
      ['manageLibraries', 'bool', 'Manage Plex libraries', 'Create, rename and remove Plex libraries as you turn catalogs on and off.'],
      ['configurePlex', 'bool', 'Make Plex streaming-safe', 'Turns off preview thumbnails, intro/credit detection, loudness analysis and deep analysis. Those read whole files, which would download every title from your debrid service.'],
      ['watchlist', 'bool', 'Add titles from my Plex Watchlist', 'Search in any Plex app, add to Watchlist, and the title is added here.'],
      ['watchlistRemove', 'bool', 'Remove titles taken off the Watchlist', 'Off keeps them after you remove them from the Watchlist (handy once you start watching).'],
    ]],
    ['What goes in the libraries', [
      ['catalogLimit', 'int', 'Titles per catalog', 'How many titles each catalog library holds.'],
      ['catalogRefreshMin', 'int', 'Refresh catalogs every (minutes)', 'New titles come in, titles that left the catalog go.'],
      ['catalogShowSeasons', 'int', 'Seasons of catalog shows', '0 = every season. A number keeps only the latest seasons of catalog shows, so they keep up as new seasons start (titles you add yourself always get every season).'],
      ['includeSpecials', 'bool', 'Include specials (season 0)', ''],
      ['preferPacks', 'bool', 'Season and series packs first', 'For episodes, results from a complete-series pack, then a season pack, beat single episodes at the same resolution. The first episode of each season is looked up first; once its pack checks out, the rest of the season is pinned without a debrid check, all from the same release.'],
      ['split4k', 'bool', 'Separate 4K libraries', 'Puts every 4K version in two extra libraries (one for movies, one for shows) and keeps 4K out of all the others. Handy for sharing the regular libraries with people whose devices can\'t play 4K, or to stop Plex transcoding 4K. A title that only has a 4K release appears only in the 4K libraries.'],
      ['movies4kName', 'text', '4K movies library name', ''],
      ['series4kName', 'text', '4K shows library name', ''],
      ['movieVersions', 'int', 'Versions per movie', 'One per resolution (4K, 1080p, 720p…), in AIOStreams\' order. Plex shows them under "Play Version". With separate 4K libraries, this counts the non-4K versions; the best 4K version is added on top.'],
      ['episodeVersions', 'int', 'Versions per episode', 'Each version is a separate lookup when Plex reads the file, so 1 is usually right. With separate 4K libraries, the best 4K version is added on top.'],
    ]],
    ['New episodes', [
      ['airingCheckMin', 'int', 'Check airing shows every (minutes)', 'Shows with an episode in the last two weeks or the next eight days have their episode list re-read this often, so new episodes are noticed soon after they air.'],
      ['freshEpisodeHours', 'int', 'New for (hours)', 'For this long after its air date an episode jumps ahead of everything else waiting for a stream.'],
      ['freshRetryMin', 'int', 'Retry new episodes every (minutes)', 'Releases often appear hours after the air date. Until one is cached, new episodes are retried this often (older titles wait "Retry titles without a stream").'],
    ]],
    ['Streams', [
      ['onlyCached', 'bool', 'Only cached results', 'Strongly recommended: an uncached result would make your debrid service download the torrent when Plex scans the file.'],
      ['maxHeight', 'select:2160=4K|1080=1080p|720=720p', 'Highest resolution', ''],
      ['checkMatches', 'bool', 'Check results are for the right title', 'Drops results whose file name is for a different show, episode or year.'],
      ['streamMode', 'select:redirect=Redirect (fastest)|proxy=Proxy through AIOPlex', 'Playback route', 'Redirect sends Plex\'s mount straight to the debrid link. Proxy passes the video through this container.'],
      ['resolveConcurrency', 'int', 'Lookups at once', 'AIOStreams lookups while filling libraries. Keep it low to stay within debrid rate limits.'],
      ['retryMissingHours', 'int', 'Retry titles without a stream after (hours)', ''],
      ['linkTtlSec', 'int', 'Re-check links after (seconds)', 'A file\'s debrid link is checked again after this long; a dead one is replaced by the same release or a new one.'],
    ]],
  ];
  function control(key, kind, label, val) {
    if (kind === 'bool') return switchHtml(key, val, label);
    if (kind.indexOf('select:') === 0) {
      return '<select class="select-input" data-key="' + key + '" data-kind="' + (/^\d/.test(kind.slice(7)) ? 'int' : 'text') + '" aria-label="' + esc(label) + '">' + kind.slice(7).split('|').map(function (o) {
        var kv = o.split('='); return '<option value="' + kv[0] + '"' + (String(val) === kv[0] ? ' selected' : '') + '>' + esc(kv[1]) + '</option>';
      }).join('') + '</select>';
    }
    return '<input class="field-input" data-key="' + key + '" data-kind="' + kind + '" aria-label="' + esc(label) + '" value="' + esc(val) + '"' + (kind === 'int' ? ' inputmode="numeric"' : '') + '>';
  }
  function settingsView() {
    var st = state.status.settings;
    return GROUPS.map(function (g) {
      return '<section class="card"><div class="card-header"><h2 class="card-title">' + g[0] + '</h2></div><div class="card-body" style="gap:0">' +
        g[1].map(function (it) {
          return '<div class="setting-row"><div class="setting-text"><div class="setting-name">' + esc(it[2]) + '</div>' + (it[3] ? '<div class="setting-desc">' + esc(it[3]) + '</div>' : '') + '</div>' +
            '<div class="setting-control">' + control(it[0], it[1], it[2], st[it[0]]) + '</div></div>';
        }).join('') + '</div></section>';
    }).join('') + '<div class="form-actions"><button class="btn btn-ghost" data-action="clear-cache">Clear caches</button><button class="btn btn-primary" data-action="save-settings">Save settings</button></div>';
  }

  // ── Admins ───────────────────────────────────────────────────────────
  function adminsView() {
    var users = state.status.users;
    return '<section class="card"><div class="card-header"><h2 class="card-title">Who can use this page</h2></div><div class="card-body tight">' +
      users.map(function (u) {
        return '<div class="user-row"><div class="user-name">' + esc(u.name) + '</div>' +
          '<div class="catalog-actions"><button class="btn btn-ghost" data-pw="' + u.id + '" data-uname="' + esc(u.name) + '">Change password</button>' +
          '<button class="btn btn-ghost" data-del="' + u.id + '" data-uname="' + esc(u.name) + '">Delete</button></div></div>';
      }).join('') + '</div></section>' +
      '<section class="card"><div class="card-header"><h2 class="card-title">Add an admin</h2></div><div class="card-body">' +
      '<form class="inline" data-form="add-user"><div class="field"><label class="field-label" for="nu-name">Username</label><input class="field-input" id="nu-name" name="name" required autocomplete="off"></div>' +
      '<div class="field"><label class="field-label" for="nu-pass">Password</label><input class="field-input" id="nu-pass" name="password" type="password" required autocomplete="new-password"></div>' +
      '<button class="btn btn-primary" type="submit">Add</button></form>' +
      '<p class="field-hint">These accounts are only for this admin page. People watch with their Plex accounts: share the server from Plex\'s own settings.</p></div></section>';
  }

  // ── Render ───────────────────────────────────────────────────────────
  function render() {
    clearInterval(poll);
    var s = state.status;
    if (!s) { app.innerHTML = state.error ? '<div class="login-page"><div class="alert-error">' + esc(state.error) + '</div></div>' : loginView(); return; }
    if (s.setupNeeded) { app.innerHTML = setupView(); return; }
    var views = { overview: overviewView, libraries: librariesView, search: searchView, settings: settingsView, admins: adminsView };
    var focus = document.activeElement && document.activeElement.id;
    app.innerHTML = shell((views[state.page] || overviewView)());
    if (focus && document.getElementById(focus) && /^(q|aio-url|claim-token)$/.test(focus)) document.getElementById(focus).focus();
    if (state.page === 'overview') poll = setInterval(function () { if (!document.hidden && !state.busy.signin) refresh(); }, 5000);
    if (state.page === 'search' && state.added && state.added.some(function (t) { return !t.pinned && !t.missing; })) {
      poll = setInterval(function () { api('GET', '/admin/api/added').then(function (a) { state.added = a; render(); }).catch(function () {}); }, 4000);
    }
  }

  // ── Plex sign-in (PIN flow) ──────────────────────────────────────────
  function plexSignIn(thenClaim) {
    var win = window.open('about:blank', 'plexauth', 'width=600,height=700');
    state.busy.signin = true; render();
    api('POST', '/admin/api/plex/signin').then(function (r) {
      if (win) win.location.href = r.url; else location.href = r.url;
      var tries = 0;
      var t = setInterval(function () {
        if (++tries > 120) { clearInterval(t); state.busy.signin = false; toast('Plex sign-in timed out', false); refresh(); return; }
        api('GET', '/admin/api/plex/signin/' + r.id).then(function (x) {
          if (!x.done) return;
          clearInterval(t); state.busy.signin = false;
          try { if (win) win.close(); } catch (e) {}
          toast('Signed in to Plex as ' + x.user);
          refresh().then(function () { if (thenClaim && state.status && !state.status.plex.claimed) claim(); });
        }).catch(function () {});
      }, 2000);
    }).catch(function (er) { state.busy.signin = false; try { if (win) win.close(); } catch (e) {} toast(er.message, false); render(); });
  }
  function claim(token) {
    state.busy.claim = true; render();
    api('POST', '/admin/api/plex/claim', token ? { claimToken: token } : {}).then(function (r) {
      toast(r.claimed ? 'Server adopted. Creating your libraries…' : 'Plex is restarting; check again in a moment');
    }).catch(function (er) { toast(er.message, false); }).then(function () { state.busy.claim = false; refresh(); });
  }

  // ── Events ───────────────────────────────────────────────────────────
  function collectSettings() {
    var patch = {};
    $$('[data-key]').forEach(function (el) {
      var k = el.getAttribute('data-key'); var kind = el.getAttribute('data-kind');
      if (!kind || k.indexOf('cat:') === 0) return;
      if (kind === 'bool') patch[k] = el.getAttribute('aria-checked') === 'true';
      else if (kind === 'int') patch[k] = parseInt(el.value, 10) || 0;
      else patch[k] = el.value;
    });
    return patch;
  }
  function syncCatalogEdits() {
    if (!state.catalogs) return;
    state.catalogs.forEach(function (c) {
      var sw = app.querySelector('[data-key="cat:' + CSS.escape(c.key) + '"]');
      if (sw) c.enabled = sw.getAttribute('aria-checked') === 'true';
      var nm = app.querySelector('[data-name="' + CSS.escape(c.key) + '"]');
      if (nm) c.name = nm.value.trim() || c.originalName;
    });
  }

  app.addEventListener('click', function (e) {
    var t = e.target.closest('button, [data-action], [data-nav]');
    if (!t) return;
    var nav = t.getAttribute('data-nav');
    if (nav) { e.preventDefault(); state.page = nav; state.navOpen = false; history.replaceState(null, '', '#' + nav); if (nav === 'libraries') state.catalogs = null; if (nav === 'search') state.added = null; render(); return; }
    if (t.getAttribute('role') === 'switch') {
      var on = t.getAttribute('aria-checked') !== 'true';
      t.setAttribute('aria-checked', on); t.setAttribute('data-state', on ? 'checked' : 'unchecked');
      var row = t.closest('.cat-row'); if (row) row.classList.toggle('off', !on);
      return;
    }
    var add = t.getAttribute('data-add');
    if (add) {
      state.busy['add:' + add] = true; render();
      api('POST', '/admin/api/add', { id: add, type: t.getAttribute('data-type') }).then(function (r) {
        toast('Added ' + r.name + '. It appears in Plex once a stream is found.');
        (state.results || []).forEach(function (m) { if (m.id === add) m.added = true; });
        state.added = null;
      }).catch(function (er) { toast(er.message, false); }).then(function () { delete state.busy['add:' + add]; render(); });
      return;
    }
    var rm = t.getAttribute('data-remove');
    if (rm) {
      if (!confirm('Remove ' + t.getAttribute('data-tname') + ' from Added? (It stays in any catalog library it belongs to.)')) return;
      api('DELETE', '/admin/api/added/' + encodeURIComponent(rm)).then(function () { state.added = null; toast('Removed'); render(); }).catch(function (er) { toast(er.message, false); });
      return;
    }
    var del = t.getAttribute('data-del');
    if (del) {
      if (!confirm('Delete ' + t.getAttribute('data-uname') + '?')) return;
      api('DELETE', '/admin/api/users/' + del).then(function () { toast('Deleted'); refresh(); }).catch(function (er) { toast(er.message, false); });
      return;
    }
    var pw = t.getAttribute('data-pw');
    if (pw) {
      var np = prompt('New password for ' + t.getAttribute('data-uname'));
      if (!np) return;
      api('POST', '/admin/api/users/' + pw + '/password', { password: np }).then(function () { toast('Password changed'); }).catch(function (er) { toast(er.message, false); });
      return;
    }
    switch (t.getAttribute('data-action')) {
      case 'logout': api('POST', '/admin/api/logout').catch(function () {}); store('aioplex_token', ''); state.token = ''; state.status = null; render(); break;
      case 'nav-open': state.navOpen = true; render(); break;
      case 'nav-close': state.navOpen = false; render(); break;
      case 'plex-signin': plexSignIn(!state.status.plex.claimed); break;
      case 'plex-claim': claim(); break;
      case 'plex-signout': api('POST', '/admin/api/plex/signout').then(function () { toast('Signed out of Plex'); refresh(); }); break;
      case 'plex-sync': api('POST', '/admin/api/plex/sync').then(function () { toast('Libraries checked; Plex is rescanning'); refresh(); }).catch(function (er) { toast(er.message, false); }); break;
      case 'airing-check':
        toast('Checking airing shows…');
        api('POST', '/admin/api/airing-check').then(function (r) { toast(r.added ? r.added + ' new episode' + (r.added === 1 ? '' : 's') + ' found; looking up streams' : 'No new episodes (' + r.shows + ' airing shows checked)'); refresh(); }).catch(function (er) { toast(er.message, false); });
        break;
      case 'retry': api('POST', '/admin/api/retry').then(function (r) { toast(r.queued + ' queued'); refresh(); }); break;
      case 'test-url': {
        var out = $('#test-out'); out.innerHTML = '<p class="loading-text">Testing…</p>';
        api('POST', '/admin/api/test-url', { url: $('#aio-url').value }).then(function (r) {
          out.innerHTML = r.ok
            ? '<div class="alert-success">Reached ' + esc(r.name || 'AIOStreams') + ' ' + esc(r.version || '') + ' in ' + fmtMs(r.ms) + '. ' + r.catalogs + ' catalogs.</div>'
            : '<div class="alert-error">Couldn\'t load the manifest: ' + esc(r.error) + '</div>';
        }).catch(function (er) { out.innerHTML = '<div class="alert-error">' + esc(er.message) + '</div>'; });
        break;
      }
      case 'clear-cache': api('POST', '/admin/api/cache/clear').then(function () { toast('Caches cleared'); }); break;
      case 'save-settings':
        api('POST', '/admin/api/settings', collectSettings()).then(function () { toast('Saved'); refresh(); }).catch(function (er) { toast(er.message, false); });
        break;
      case 'save-catalogs': {
        syncCatalogEdits();
        var body = { enabled: state.catalogs.filter(function (c) { return c.enabled; }).map(function (c) { return c.key; }), names: {} };
        state.catalogs.forEach(function (c) { if (c.name && c.name !== c.originalName) body.names[c.key] = c.name; });
        api('POST', '/admin/api/catalogs', body).then(function () { toast('Saved. Plex libraries are being updated and filled in.'); state.catalogs = null; render(); }).catch(function (er) { toast(er.message, false); });
        break;
      }
    }
  });

  app.addEventListener('submit', function (e) {
    e.preventDefault();
    var f = e.target; var kind = f.getAttribute('data-form');
    var data = {}; Array.prototype.forEach.call(f.elements, function (el) { if (el.name) data[el.name] = el.type === 'checkbox' ? el.checked : el.value; });
    if (kind === 'setup') {
      api('POST', '/admin/api/setup', data).then(function (r) { state.token = r.token; store('aioplex_token', r.token); return refresh(); })
        .catch(function (er) { state.error = er.message; render(); });
    } else if (kind === 'login') {
      api('POST', '/admin/api/login', data).then(function (r) { state.token = r.token; store('aioplex_token', r.token); return refresh(); })
        .catch(function (er) { state.error = er.message; render(); });
    } else if (kind === 'connect') {
      api('POST', '/admin/api/settings', { aioUrl: data.url.trim() }).then(function () { toast('Saved. Loading your catalogs…'); setTimeout(refresh, 800); }).catch(function (er) { toast(er.message, false); });
    } else if (kind === 'claim') {
      claim(data.claimToken.trim());
    } else if (kind === 'search') {
      state.query = data.q.trim(); if (!state.query) return;
      state.busy.search = true; render();
      api('GET', '/admin/api/search?q=' + encodeURIComponent(state.query)).then(function (r) { state.results = r; })
        .catch(function (er) { toast(er.message, false); state.results = []; }).then(function () { state.busy.search = false; render(); });
    } else if (kind === 'add-user') {
      api('POST', '/admin/api/users', data).then(function () { toast('Added ' + data.name); refresh(); }).catch(function (er) { toast(er.message, false); });
    }
  });

  refresh();
}());
