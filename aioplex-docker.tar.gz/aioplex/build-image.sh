#!/bin/sh
# Builds the images and saves them as one tarball you can copy to another
# machine and load with:  docker load -i aioplex-images.tar.gz
#   aioplex:latest       app + FUSE mount, for your existing Plex (docker-compose.yml)
#   aioplex-core:latest  app only, for the bundled-Plex setup (docker/compose.yml)
#   aioplex-plex:latest  Plex + mount, for the bundled-Plex setup
set -e
cd "$(dirname "$0")"
docker build -t aioplex:latest .
docker build -t aioplex-core:latest -f docker/Dockerfile .
docker build -t aioplex-plex:latest -f docker/Dockerfile.plex .
docker save aioplex:latest aioplex-core:latest aioplex-plex:latest | gzip > aioplex-images.tar.gz
echo "Saved aioplex-images.tar.gz ($(du -h aioplex-images.tar.gz | cut -f1)). Load it with: docker load -i aioplex-images.tar.gz"
