#!/bin/sh
# Builds both images and saves them as one tarball you can copy to another
# machine and load with:  docker load -i aioplex-images.tar.gz
set -e
cd "$(dirname "$0")"
docker build -t aioplex:latest -f docker/Dockerfile .
docker build -t aioplex-plex:latest -f docker/Dockerfile.plex .
docker save aioplex:latest aioplex-plex:latest | gzip > aioplex-images.tar.gz
echo "Saved aioplex-images.tar.gz ($(du -h aioplex-images.tar.gz | cut -f1)). Load it with: docker load -i aioplex-images.tar.gz"
