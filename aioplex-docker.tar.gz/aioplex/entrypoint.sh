#!/bin/sh
# entrypoint.sh: start AIOPlex, then mount its library with FUSE.
#
#   AIOPlex (node)  serves the library as WebDAV on 127.0.0.1:$PORT/dav
#   rclone          mounts it at $FUSE_MOUNTPOINT (read-only)
#
# If either stops, the mount is cleaned up and the container exits so Docker
# restarts it. On docker stop, the mount is unmounted before exiting.

PORT="${PORT:-8097}"
MOUNTPOINT="${FUSE_MOUNTPOINT:-/docker/aioplex/mnt}"
CACHE_DIR="${FUSE_CACHE_DIR:-/docker/aioplex/cache}"

unmount() {
  fusermount3 -uz "$MOUNTPOINT" 2>/dev/null || fusermount -uz "$MOUNTPOINT" 2>/dev/null || umount -l "$MOUNTPOINT" 2>/dev/null || true
}

# Clean up a stale mount from a previous crash.
if grep -qs " $MOUNTPOINT " /proc/mounts; then
  echo "Stale FUSE mount at $MOUNTPOINT, unmounting..."
  unmount
  sleep 0.5
fi
mkdir -p "$MOUNTPOINT" "$CACHE_DIR" "${DATA_DIR:-/docker/aioplex/data}"

node src/index.js &
NODE_PID=$!
RCLONE_PID=""

stop() {
  echo "Stopping: unmounting $MOUNTPOINT"
  [ -n "$RCLONE_PID" ] && kill "$RCLONE_PID" 2>/dev/null
  unmount
  kill "$NODE_PID" 2>/dev/null
  wait "$NODE_PID" 2>/dev/null
  exit "${1:-0}"
}
trap 'stop 0' TERM INT

# Wait for AIOPlex before mounting.
i=0
until wget -q -O /dev/null "http://127.0.0.1:$PORT/health" 2>/dev/null; do
  kill -0 "$NODE_PID" 2>/dev/null || { echo "AIOPlex exited during start-up"; exit 1; }
  i=$((i + 1)); [ "$i" -gt 60 ] && { echo "AIOPlex did not start"; stop 1; }
  sleep 1
done

if [ -n "${DAV_PASSWORD:-}" ]; then
  RCLONE_WEBDAV_USER="${DAV_USER:-aioplex}"
  RCLONE_WEBDAV_PASS="$(rclone obscure "$DAV_PASSWORD")"
  export RCLONE_WEBDAV_USER RCLONE_WEBDAV_PASS
fi

echo "Mounting the library at $MOUNTPOINT"
# shellcheck disable=SC2086
rclone mount --config /dev/null ":webdav,url='http://127.0.0.1:$PORT/dav',vendor=other:" "$MOUNTPOINT" \
  --read-only --allow-other \
  --dir-cache-time 10s --attr-timeout 10s \
  --vfs-cache-mode "${FUSE_CACHE_MODE:-full}" \
  --vfs-cache-max-size "${FUSE_CACHE_MAX_SIZE:-20G}" \
  --vfs-cache-max-age "${FUSE_CACHE_MAX_AGE:-6h}" \
  --vfs-read-chunk-size "${FUSE_READ_CHUNK:-32M}" \
  --vfs-read-ahead "${FUSE_READ_AHEAD:-128M}" \
  --buffer-size "${FUSE_BUFFER:-32M}" \
  --cache-dir "$CACHE_DIR" \
  --log-level "${FUSE_LOG_LEVEL:-NOTICE}" \
  ${RCLONE_EXTRA_ARGS:-} &
RCLONE_PID=$!

# Supervise both; `wait` returns early when a signal arrives, so the trap runs promptly.
while kill -0 "$NODE_PID" 2>/dev/null && kill -0 "$RCLONE_PID" 2>/dev/null; do
  sleep 5 &
  wait $!
done
echo "AIOPlex or the FUSE mount stopped; exiting so Docker restarts the container"
stop 1
