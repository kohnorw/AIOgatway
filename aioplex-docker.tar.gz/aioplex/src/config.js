'use strict';
// All operator settings live here. Env vars set the defaults; anything saved
// from the admin page (data/settings.json) overrides them at runtime.
const fs = require('fs');
const path = require('path');

const bool = (v) => /^(1|true|yes|on)$/i.test(String(v).trim());

// key: [ENV_NAME, default, type]
const DEFS = {
  aioUrl:             ['AIOSTREAMS_URL', '', 'str'],          // full manifest URL
  serverName:         ['SERVER_NAME', 'AIOPlex', 'str'],      // Plex server's friendly name

  // ── Plex ───────────────────────────────────────────────────────────
  plexUrl:            ['PLEX_URL', 'http://plex:32400', 'str'],  // how this service reaches Plex
  plexToken:          ['PLEX_TOKEN', '', 'str'],              // optional; learned from sign-in / Preferences.xml otherwise
  mountPath:          ['MOUNT_PATH', '/media/aioplex', 'str'],// where Plex sees the virtual library
  libraryPrefix:      ['LIBRARY_PREFIX', '', 'str'],          // e.g. "AIO · " in front of every library name
  configurePlex:      ['CONFIGURE_PLEX', true, 'bool'],       // turn off Plex features that would download whole files
  plexShared:         ['PLEX_SHARED', false, 'bool'],         // your own existing Plex: leave server-wide settings alone
  manageLibraries:    ['MANAGE_LIBRARIES', true, 'bool'],     // create/rename/remove Plex libraries for catalogs

  // ── What goes in the libraries ──────────────────────────────────────
  catalogLimit:       ['CATALOG_LIMIT', 60, 'int'],           // titles taken from each catalog
  catalogRefreshMin:  ['CATALOG_REFRESH_MIN', 360, 'int'],    // re-read catalogs this often
  watchlist:          ['WATCHLIST', true, 'bool'],            // add titles on your Plex Watchlist
  watchlistPollSec:   ['WATCHLIST_POLL_SEC', 60, 'int'],
  watchlistRemove:    ['WATCHLIST_REMOVE', false, 'bool'],    // remove titles taken off the Watchlist
  includeSpecials:    ['INCLUDE_SPECIALS', false, 'bool'],    // season 0
  catalogShowSeasons: ['CATALOG_SHOW_SEASONS', 0, 'int'],     // 0 = all; N = only the latest N seasons of catalog shows

  // ── New episodes ───────────────────────────────────────────────────
  airingCheckMin:     ['AIRING_CHECK_MIN', 30, 'int'],        // re-read episode lists of airing shows this often
  freshEpisodeHours:  ['FRESH_EPISODE_HOURS', 48, 'int'],     // an episode counts as new this long after it airs
  freshRetryMin:      ['FRESH_RETRY_MIN', 30, 'int'],         // retry new episodes with no cached release this often
  movieVersions:      ['MOVIE_VERSIONS', 2, 'int'],           // versions per movie (one per resolution)
  episodeVersions:    ['EPISODE_VERSIONS', 1, 'int'],
  preferPacks:        ['PREFER_PACKS', true, 'bool'],         // episodes: series/season packs first, then single episodes
  split4k:            ['SPLIT_4K', false, 'bool'],            // 4K versions go to separate "Movies 4K" / "Series 4K" libraries
  movies4kName:       ['MOVIES_4K_NAME', 'Movies 4K', 'str'],
  series4kName:       ['SERIES_4K_NAME', 'Series 4K', 'str'],

  // ── Streams ────────────────────────────────────────────────────────
  resolveConcurrency: ['RESOLVE_CONCURRENCY', 3, 'int'],      // AIOStreams lookups at once while filling libraries
  retryMissingHours:  ['RETRY_MISSING_HOURS', 12, 'int'],     // retry titles with no usable stream
  onlyCached:         ['ONLY_CACHED', true, 'bool'],          // pick only results your debrid service has cached
  checkMatches:       ['CHECK_MATCHES', true, 'bool'],        // drop results for a different show/episode/year
  maxHeight:          ['MAX_RESOLUTION', 2160, 'int'],        // ignore results above this
  streamMode:         ['STREAM_MODE', 'redirect', 'str'],     // redirect | proxy
  linkTtlSec:         ['LINK_TTL_SEC', 3600, 'int'],          // reuse a resolved debrid link this long (proxy mode)
  streamWaitMs:       ['STREAM_WAIT_MS', 30000, 'int'],
  streamTtlSec:       ['STREAM_TTL_SEC', 1200, 'int'],
  streamStaleSec:     ['STREAM_STALE_SEC', 21600, 'int'],
  emptyStreamTtlSec:  ['EMPTY_STREAM_TTL_SEC', 60, 'int'],
  catalogTtlSec:      ['CATALOG_TTL_SEC', 1800, 'int'],
  metaTtlSec:         ['META_TTL_SEC', 43200, 'int'],
  metaFallbackUrl:    ['META_FALLBACK_URL', 'https://v3-cinemeta.strem.io', 'str'],

  // ── WebDAV (what the rclone mount inside the Plex container reads) ─
  davUser:            ['DAV_USER', 'aioplex', 'str'],
  davPassword:        ['DAV_PASSWORD', '', 'str'],            // empty = no auth on /dav
};

const env = process.env;
const boot = {
  port: parseInt(env.PORT || '8097', 10),
  dataDir: env.DATA_DIR || path.resolve('data'),
  adminPath: env.ADMIN_PATH || path.resolve(__dirname, '..', 'admin'),
  plexConfig: env.PLEX_CONFIG_DIR || '/plex-config',  // Plex's /config, mounted read-only (to read its token)
  logLevel: env.LOG_LEVEL || 'info',
  adminUser: env.ADMIN_USERNAME || '',
  adminPassword: env.ADMIN_PASSWORD || '',
};
fs.mkdirSync(boot.dataDir, { recursive: true });

function coerce(type, v) {
  if (v === null || v === undefined) return v;
  if (type === 'int') { const n = parseInt(v, 10); return Number.isFinite(n) ? n : undefined; }
  if (type === 'bool') return typeof v === 'boolean' ? v : bool(v);
  return String(v);
}

const SETTINGS_FILE = path.join(boot.dataDir, 'settings.json');
let saved = {};
try { saved = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')); } catch { /* first run */ }

const settings = {};
function rebuild() {
  for (const [key, [envName, def, type]] of Object.entries(DEFS)) {
    let v = def;
    if (env[envName] !== undefined && env[envName] !== '') v = coerce(type, env[envName]);
    if (saved[key] !== undefined) v = coerce(type, saved[key]);
    settings[key] = v;
  }
  settings.mountPath = settings.mountPath.replace(/\/+$/, '') || '/media/aioplex';
}
rebuild();

const listeners = [];
function update(patch) {
  const before = { ...settings };
  for (const [k, v] of Object.entries(patch || {})) {
    if (!(k in DEFS)) continue;
    saved[k] = coerce(DEFS[k][2], v);
  }
  fs.writeFileSync(SETTINGS_FILE + '.tmp', JSON.stringify(saved, null, 2));
  fs.renameSync(SETTINGS_FILE + '.tmp', SETTINGS_FILE);
  rebuild();
  for (const fn of listeners) { try { fn(settings, before); } catch { /* ignore */ } }
}
function onChange(fn) { listeners.push(fn); }

module.exports = { settings, boot, update, onChange, DEFS };
