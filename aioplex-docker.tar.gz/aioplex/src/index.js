'use strict';
const { settings, boot } = require('./config');
const store = require('./store');
const server = require('./server');
const aio = require('./aio');
const library = require('./library');
const resolver = require('./resolver');
const plex = require('./plex');
const { resync } = require('./routes/admin');
const { log } = require('./util');

store.meta.set('started', Date.now());

// Seed an admin account from env on first boot (optional).
if (!store.users.list().length && boot.adminUser && boot.adminPassword) {
  store.users.create(boot.adminUser, boot.adminPassword);
  log('info', `created admin user "${boot.adminUser}" from environment`);
}

server.listen();

if (!store.users.list().length) log('info', `first run: open http://<this-host>:${boot.port}/admin to set up`);
if (!aio.configured()) log('info', 'AIOStreams is not configured yet — add your manifest URL on the admin page');
else {
  aio.manifest().then((m) => log('info', `connected to ${m.name || 'AIOStreams'} ${m.version || ''} (${(m.catalogs || []).length} catalogs)`))
    .catch((e) => log('warn', `could not reach AIOStreams: ${e.message}`));
  resync().catch((e) => log('warn', `startup sync failed: ${e.message}`));
}

// Plex may start after us, or be adopted later: keep trying to finish setup.
const plexTick = () => plex.setup().catch((e) => log('debug', `plex setup: ${e.message}`));
setTimeout(plexTick, 5000);
setInterval(plexTick, 60_000).unref();
// One scan shortly after start, once the rclone mount inside Plex is up.
setTimeout(() => plex.scanAll(), 45_000).unref();

setInterval(() => { if (aio.configured()) resync().catch(() => {}); }, Math.max(15, settings.catalogRefreshMin) * 60_000).unref();
setInterval(() => resolver.fill(), 5 * 60_000).unref();
// New episodes: re-read the episode lists of shows that are on air, then look up anything new.
const airing = () => {
  if (aio.configured()) library.checkAiring().then(() => resolver.fill()).catch((e) => log('debug', `airing check: ${e.message}`));
  setTimeout(airing, Math.max(5, settings.airingCheckMin) * 60_000).unref();
};
setTimeout(airing, 2 * 60_000).unref();
const wl = () => { plex.pollWatchlist(); setTimeout(wl, Math.max(20, settings.watchlistPollSec) * 1000).unref(); };
setTimeout(wl, 8000);


process.on('unhandledRejection', (e) => log('error', 'unhandled rejection', e && e.stack ? e.stack : e));
process.on('uncaughtException', (e) => log('error', 'unexpected error (kept running):', e && e.stack ? e.stack : e));
