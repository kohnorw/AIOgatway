'use strict';
// Talks to plex.tv (sign-in, claiming, Watchlist) and to the Plex Media
// Server next door (libraries, scans, settings).
const fs = require('fs');
const path = require('path');
const { settings, boot } = require('./config');
const store = require('./store');
const library = require('./library');
const { request } = require('./http');
const { log, sleep } = require('./util');

const PRODUCT = 'AIOPlex';
function plexHeaders(token) {
  const h = {
    accept: 'application/json', 'x-plex-product': PRODUCT, 'x-plex-version': '1.0.0',
    'x-plex-client-identifier': store.clientId(), 'x-plex-platform': 'Node.js', 'x-plex-device-name': settings.serverName || PRODUCT,
  };
  if (token) h['x-plex-token'] = token;
  return h;
}

async function call(url, { method = 'GET', token, timeout = 20_000 } = {}) {
  const res = await request(url, { method, headers: plexHeaders(token), timeout, body: method === 'POST' || method === 'PUT' ? '' : null });
  const text = res.body.toString('utf8');
  if (res.status >= 400) {
    const err = new Error(`${method} ${new URL(url).host}${new URL(url).pathname} → HTTP ${res.status}${text && text.length < 200 ? `: ${text.replace(/<[^>]+>/g, ' ').trim()}` : ''}`);
    err.status = res.status;
    throw err;
  }
  if (!text) return {};
  try { return JSON.parse(text); } catch { return { raw: text }; }
}

// ── Token ──────────────────────────────────────────────────────────────
const PREFS_XML = () => path.join(boot.plexConfig, 'Library', 'Application Support', 'Plex Media Server', 'Preferences.xml');
function serverPrefsToken() {
  try { return (fs.readFileSync(PREFS_XML(), 'utf8').match(/\bPlexOnlineToken="([^"]+)"/) || [])[1] || ''; } catch { return ''; }
}
/** Which token to use and where it came from. */
function tokenInfo() {
  if (settings.plexToken) return { token: settings.plexToken, source: 'PLEX_TOKEN setting' };
  const user = store.meta.get('plexUserToken');
  if (user) return { token: user, source: `signed in as ${store.meta.get('plexUser') || 'your Plex account'}` };
  const t = serverPrefsToken();
  if (t) return { token: t, source: "Plex's Preferences.xml" };
  return { token: '', source: '' };
}
const token = () => tokenInfo().token;

// ── Sign in with Plex (PIN flow, like any Plex app) ────────────────────
async function startSignIn() {
  const pin = await call('https://plex.tv/api/v2/pins?strong=true', { method: 'POST' });
  const qs = new URLSearchParams({ clientID: store.clientId(), code: pin.code, 'context[device][product]': PRODUCT });
  return { id: pin.id, url: `https://app.plex.tv/auth#?${qs.toString()}` };
}
async function checkSignIn(id) {
  const pin = await call(`https://plex.tv/api/v2/pins/${encodeURIComponent(id)}`);
  if (!pin.authToken) return { done: false };
  store.meta.set('plexUserToken', pin.authToken);
  try {
    const u = await call('https://plex.tv/api/v2/user', { token: pin.authToken });
    store.meta.set('plexUser', u.username || u.title || u.email || 'Plex user');
  } catch { /* name is cosmetic */ }
  log('info', `signed in to Plex as ${store.meta.get('plexUser')}`);
  return { done: true, user: store.meta.get('plexUser') };
}
function signOut() { store.meta.set('plexUserToken', ''); store.meta.set('plexUser', ''); }

// ── Plex Media Server ──────────────────────────────────────────────────
const pmsBase = () => settings.plexUrl.replace(/\/+$/, '');
function pms(p, opts = {}) { return call(`${pmsBase()}${p}`, { token: token(), ...opts }); }

async function identity() {
  const j = await call(`${pmsBase()}/identity`, { timeout: 5000 });
  const mc = j.MediaContainer || {};
  return { machineIdentifier: mc.machineIdentifier, claimed: mc.claimed === true || mc.claimed === '1' || mc.claimed === 1, version: mc.version };
}

/** Adopt (claim) the server for a Plex account, with a claim-… token. */
async function claimWith(claimToken) {
  claimToken = String(claimToken || '').trim();
  if (!/^claim-/.test(claimToken)) throw Object.assign(new Error('A claim token starts with "claim-". Get one at https://plex.tv/claim'), { status: 400 });
  await call(`${pmsBase()}/myplex/claim?token=${encodeURIComponent(claimToken)}`, { method: 'POST', timeout: 30_000 });
  for (let i = 0; i < 20; i++) {
    await sleep(1500);
    try { if ((await identity()).claimed) break; } catch { /* restarting */ }
  }
  log('info', 'Plex server adopted');
  setTimeout(() => setup().catch((e) => log('warn', `Plex setup after adoption: ${e.message}`)), 3000);
  return identity();
}
/** Adopt with the signed-in account: get a claim token from plex.tv, then claim. */
async function claimWithAccount() {
  const user = store.meta.get('plexUserToken');
  if (!user) throw new Error('Sign in with Plex first');
  const j = await call('https://plex.tv/api/claim/token.json', { token: user });
  if (!j.token) throw new Error('plex.tv did not return a claim token');
  return claimWith(j.token);
}

// Plex features that read whole files. Over a streaming mount they'd download
// every title in full from your debrid service, so they're switched off.
const SAFE_PREFS = {
  GenerateBIFBehavior: 'never',            // video preview thumbnails
  GenerateChapterThumbBehavior: 'never',
  LoudnessAnalysisBehavior: 'never',
  GenerateIntroMarkerBehavior: 'never',
  GenerateCreditsMarkerBehavior: 'never',
  GenerateAdMarkerBehavior: 'never',
  GenerateVADBehavior: 'never',            // voice activity (subtitle sync)
  ButlerTaskDeepMediaAnalysis: '0',        // "extensive media analysis" during maintenance
  ButlerTaskGenerateMediaIndexFiles: '0',
  FSEventLibraryUpdatesEnabled: '0',       // FUSE has no change events; AIOPlex triggers scans
  ScheduledLibraryUpdatesEnabled: '0',
  autoEmptyTrash: '0',                     // a hiccup in the mount must never empty a library
};
async function configure() {
  if (!settings.configurePlex) return;
  if (settings.plexShared) {
    // An existing server: its other libraries keep their settings. AIOPlex's own
    // libraries get their per-library settings; the admin page flags the
    // server-wide ones that matter.
    log('info', 'shared Plex server: leaving server-wide settings alone (see the admin page for the ones to check)');
    return;
  }
  const prefs = { ...SAFE_PREFS };
  if (settings.serverName) prefs.FriendlyName = settings.serverName;
  let ok = 0;
  for (const [k, v] of Object.entries(prefs)) {
    try { await pms(`/:/prefs?${encodeURIComponent(k)}=${encodeURIComponent(v)}`, { method: 'PUT' }); ok++; } catch (e) { log('debug', `pref ${k}: ${e.message}`); }
  }
  log('info', `Plex settings applied (${ok}/${Object.keys(prefs).length})`);
}

const AGENTS = {
  movie: { type: 'movie', agent: 'tv.plex.agents.movie', scanner: 'Plex Movie' },
  show: { type: 'show', agent: 'tv.plex.agents.series', scanner: 'Plex TV Series' },
};
const libPrefsDone = new Set();
const LIB_PREFS = 'enableBIFGeneration=0&enableIntroMarkerGeneration=0&enableCreditsMarkerGeneration=0&enableAdMarkerGeneration=0&enableVoiceActivityGeneration=0';

async function sections() {
  const j = await pms('/library/sections');
  return (j.MediaContainer && j.MediaContainer.Directory) || [];
}

/** Make Plex libraries match the enabled catalogs (+ Added Movies/Shows). */
let libSync = null;
function syncLibraries() {
  if (libSync) return libSync;
  libSync = (async () => {
    if (!token() || !settings.manageLibraries) return;
    const desired = await library.libraries();
    const st = library.state();
    const existing = await sections();
    const byPath = new Map();
    for (const d of existing) for (const l of d.Location || []) byPath.set(String(l.path).replace(/\/+$/, ''), d);
    for (const lib of desired) {
      const a = AGENTS[lib.kind];
      let sec = byPath.get(lib.path);
      if (!sec) {
        const qs = new URLSearchParams({ name: lib.name, type: a.type, agent: a.agent, scanner: a.scanner, language: 'en-US', location: lib.path });
        try {
          const j = await pms(`/library/sections?${qs.toString()}`, { method: 'POST', timeout: 60_000 });
          sec = ((j.MediaContainer && j.MediaContainer.Directory) || [])[0] || (await sections()).find((d) => (d.Location || []).some((l) => l.path === lib.path));
          log('info', `created Plex library "${lib.name}"`);
          if (sec) libPrefsDone.delete(String(sec.key)); // applied below
        } catch (e) { log('warn', `could not create library "${lib.name}": ${e.message}`); continue; }
      } else if (sec.title !== lib.name) {
        await pms(`/library/sections/${sec.key}?${new URLSearchParams({ name: lib.name, agent: a.agent }).toString()}`, { method: 'PUT' })
          .then(() => log('info', `renamed Plex library "${sec.title}" → "${lib.name}"`)).catch((e) => log('debug', `rename: ${e.message}`));
      }
      if (sec) {
        st.libs[lib.key] = { sectionId: String(sec.key), path: lib.path, name: lib.name };
        // Per-library: no preview thumbnails, intro/credit/ad markers or voice detection (they read whole files).
        if (settings.configurePlex && !libPrefsDone.has(String(sec.key))) {
          await pms(`/library/sections/${sec.key}/prefs?${LIB_PREFS}`, { method: 'PUT' }).then(() => libPrefsDone.add(String(sec.key))).catch(() => {});
        }
      }
    }
    // Libraries for catalogs that were turned off.
    const want = new Set(desired.map((l) => l.key));
    for (const [key, rec] of Object.entries(st.libs)) {
      if (want.has(key)) continue;
      const sec = existing.find((d) => String(d.key) === rec.sectionId && (d.Location || []).some((l) => l.path === rec.path));
      if (sec) {
        await pms(`/library/sections/${sec.key}`, { method: 'DELETE' }).then(() => log('info', `removed Plex library "${sec.title}"`)).catch((e) => log('warn', `remove library: ${e.message}`));
      }
      delete st.libs[key];
    }
  })().catch((e) => log('warn', `library sync failed: ${e.message}`)).finally(() => { libSync = null; });
  return libSync;
}

// ── Scans ──────────────────────────────────────────────────────────────
// rclone re-lists folders every ~10 s; scans wait a little longer than that.
const dirty = new Map(); // sectionId → { removed }
let scanTimer = null;
function markChanged(libKeys, { removed = false } = {}) {
  const st = library.state();
  for (const k of libKeys) {
    const rec = st.libs[k];
    if (!rec) continue;
    const d = dirty.get(rec.sectionId) || { removed: false };
    d.removed = d.removed || removed;
    dirty.set(rec.sectionId, d);
  }
  if (dirty.size && !scanTimer) scanTimer = setTimeout(runScans, 20_000);
}
function scanAll() { markChanged(Object.keys(library.state().libs)); }
async function runScans() {
  scanTimer = null;
  if (!token()) { dirty.clear(); return; }
  const jobs = [...dirty.entries()]; dirty.clear();
  for (const [id, d] of jobs) {
    try {
      await pms(`/library/sections/${id}/refresh`);
      log('debug', `scanning Plex library ${id}`);
      if (d.removed) setTimeout(() => pms(`/library/sections/${id}/emptyTrash`, { method: 'PUT' }).catch(() => {}), 120_000).unref();
    } catch (e) { log('warn', `scan of library ${id} failed: ${e.message}`); }
  }
}

// ── Watchlist ──────────────────────────────────────────────────────────
// Search in any Plex app, add a movie or show to your Watchlist, and it shows
// up in "Added Movies"/"Added Shows" once a stream has been pinned.
function guidToId(guids) {
  const ids = (guids || []).map((g) => String(g.id || g));
  const imdb = ids.find((g) => g.startsWith('imdb://'));
  if (imdb) return imdb.slice(7);
  const tmdb = ids.find((g) => g.startsWith('tmdb://'));
  if (tmdb) return `tmdb:${tmdb.slice(7)}`;
  return null;
}
async function watchlistItems() {
  const tok = store.meta.get('plexUserToken') || token();
  if (!tok) return null;
  const items = []; let start = 0;
  for (let page = 0; page < 10; page++) {
    const j = await call(`https://discover.provider.plex.tv/library/sections/watchlist/all?includeGuids=1&X-Plex-Container-Start=${start}&X-Plex-Container-Size=100`, { token: tok });
    const mc = j.MediaContainer || {};
    const md = mc.Metadata || [];
    items.push(...md);
    start += md.length;
    if (!md.length || start >= (mc.totalSize || 0)) break;
  }
  const map = library.state().watchlistMap;
  const out = [];
  for (const it of items) {
    const stype = it.type === 'movie' ? 'movie' : it.type === 'show' ? 'series' : null;
    if (!stype) continue;
    let id = map[it.ratingKey] || guidToId(it.Guid);
    if (!id) {
      for (const host of ['https://metadata.provider.plex.tv', 'https://discover.provider.plex.tv']) {
        try {
          const j = await call(`${host}/library/metadata/${it.ratingKey}?includeGuids=1`, { token: tok });
          id = guidToId((((j.MediaContainer || {}).Metadata || [])[0] || {}).Guid);
          if (id) break;
        } catch { /* try the other host */ }
      }
    }
    if (!id) { log('debug', `watchlist: no IMDb/TMDB id for ${it.title}`); continue; }
    map[it.ratingKey] = id;
    out.push({ id, stype, name: it.title, year: it.year, poster: it.thumb || null });
  }
  return out;
}
let wlBusy = false;
async function pollWatchlist() {
  if (wlBusy || !settings.watchlist) return;
  wlBusy = true;
  try {
    const items = await watchlistItems();
    if (!items) return;
    const added = await library.applyWatchlist(items);
    if (added) { log('info', `watchlist: ${added} new title(s)`); require('./resolver').fill(); }
  } catch (e) { log('debug', `watchlist poll failed: ${e.message}`); } finally { wlBusy = false; }
}

// Server-wide settings that can hurt AIOPlex libraries. On a dedicated server
// AIOPlex sets them itself; on a shared one the admin page lists them.
const CHECKS = [
  { id: 'ButlerTaskDeepMediaAnalysis', bad: (v) => truthy(v), name: 'Settings → Scheduled Tasks → "Perform extensive media analysis during maintenance"', why: 'reads every file in full: AIOPlex titles would be downloaded from your debrid service each night. Turn it off.' },
  { id: 'autoEmptyTrash', bad: (v) => truthy(v), name: 'Settings → Library → "Empty trash automatically after every scan"', why: 'if the AIOPlex mount is ever down during a scan, Plex drops those titles (and possibly their watch history). Turn it off, or keep the mount reliable.' },
];
const truthy = (v) => v === true || v === 1 || v === '1' || v === 'true';
async function serverChecks() {
  const j = await pms('/:/prefs');
  const prefs = new Map(((j.MediaContainer || {}).Setting || []).map((x) => [x.id, x.value]));
  return CHECKS.filter((c) => prefs.has(c.id) && c.bad(prefs.get(c.id))).map((c) => ({ id: c.id, name: c.name, why: c.why }));
}

// ── Status / setup ─────────────────────────────────────────────────────
async function status() {
  const out = { url: pmsBase(), reachable: false, claimed: false, signedIn: !!store.meta.get('plexUserToken'), user: store.meta.get('plexUser') || null, tokenSource: tokenInfo().source };
  try { Object.assign(out, await identity(), { reachable: true }); } catch (e) { out.error = e.message; }
  if (out.reachable && token()) {
    try { const j = await pms('/'); out.friendlyName = (j.MediaContainer || {}).friendlyName; out.authorized = true; } catch (e) { out.authorized = false; out.authError = e.message; }
    if (out.authorized) out.checks = await serverChecks().catch(() => []);
  }
  out.shared = settings.plexShared;
  return out;
}

/** Everything that needs an adopted server and a token. Safe to call repeatedly. */
let configuredFor = null;
async function setup() {
  if (!token()) return;
  const id = await identity().catch(() => null);
  if (!id || !id.claimed) return;
  const want = `${id.machineIdentifier}|${settings.plexShared}|${settings.configurePlex}`;
  if (configuredFor !== want) { await configure(); configuredFor = want; }
  await syncLibraries();
}

library.onChange((keys, opts) => markChanged(keys, opts));

module.exports = { status, startSignIn, checkSignIn, signOut, claimWith, claimWithAccount, setup, syncLibraries, scanAll, pollWatchlist, token, identity };
