'use strict';
// AIOStreams (Stremio add-on protocol) client: manifest, catalogs, search,
// metadata and streams, with keep-alive connections, single-flight loading
// and stale-while-revalidate caches.
const fs = require('fs');
const path = require('path');
const { settings, boot, onChange } = require('./config');
const { getJson } = require('./http');
const { SwrCache } = require('./cache');
const { parseRelease, SERVICE_IDS } = require('./parse');
const { log, md5 } = require('./util');

const manifestCache = new SwrCache('manifest', 4);
const catalogCache = new SwrCache('catalog', 3000);
const metaCache = new SwrCache('meta', 20000);
const streamCache = new SwrCache('streams', 20000);

// Stremio protocol: ids keep their ':' separators in the path.
const encId = (s) => encodeURIComponent(String(s)).replace(/%3A/gi, ':');

function baseUrl() {
  let u = (settings.aioUrl || '').trim();
  if (!u) return '';
  u = u.replace(/^stremio:\/\//i, 'https://');
  return u.replace(/\/manifest\.json(\?.*)?$/i, '').replace(/\/+$/, '');
}
const configured = () => !!baseUrl();

async function manifest(force = false) {
  const base = baseUrl();
  if (!base) throw new Error('AIOStreams is not configured yet. Add your manifest URL on the admin page.');
  return manifestCache.get(base, () => getJson(`${base}/manifest.json`, { timeout: 15_000 }), { ttl: 10 * 60_000, stale: 24 * 3600_000, force });
}

function supports(m, resource, type, id) {
  for (const r of m.resources || []) {
    const name = typeof r === 'string' ? r : r.name;
    if (name !== resource) continue;
    const types = (typeof r === 'object' && r.types) || m.types || [];
    const prefixes = (typeof r === 'object' && r.idPrefixes) || m.idPrefixes;
    if (type && types.length && !types.includes(type)) continue;
    if (id && prefixes && prefixes.length && !prefixes.some((p) => String(id).startsWith(p))) continue;
    return true;
  }
  return false;
}

// ── Catalog preferences: which catalogs become Plex libraries ──────────
const PREFS_FILE = path.join(boot.dataDir, 'catalogs.json');
let catPrefs = { enabled: null, names: {} };
try { catPrefs = { ...catPrefs, ...JSON.parse(fs.readFileSync(PREFS_FILE, 'utf8')) }; } catch { /* default */ }
function saveCatPrefs(p) {
  catPrefs = { ...catPrefs, ...p };
  fs.writeFileSync(PREFS_FILE, JSON.stringify(catPrefs, null, 2));
}

const extraList = (c) => (c.extra || (c.extraSupported || []).map((name) => ({ name, isRequired: (c.extraRequired || []).includes(name) })));
/** Plex library kind for a Stremio catalog type, or null when Plex has no equivalent. */
const plexKind = (type) => (type === 'movie' ? 'movie' : (type === 'series' || type === 'anime') ? 'show' : null);

/** All catalogs from the manifest, annotated. */
async function catalogs() {
  const m = await manifest();
  // CATALOGS=all or a comma-separated list of type/id seeds the choice on first run.
  if (catPrefs.enabled === null && process.env.CATALOGS) {
    const want = process.env.CATALOGS.split(',').map((s) => s.trim()).filter(Boolean);
    catPrefs.enabled = want.includes('all') ? (m.catalogs || []).map((c) => `${c.type}/${c.id}`) : want;
  }
  const enabled = new Set(catPrefs.enabled || []);
  return (m.catalogs || []).map((c) => {
    const extras = extraList(c);
    const required = extras.filter((e) => e.isRequired).map((e) => e.name);
    const key = `${c.type}/${c.id}`;
    const kind = plexKind(c.type);
    const browsable = required.every((r) => r === 'skip') && !!kind;
    return {
      key, type: c.type, id: c.id, kind,
      name: catPrefs.names[key] || c.name || c.id,
      originalName: c.name || c.id,
      browsable,
      searchable: extras.some((e) => e.name === 'search'),
      enabled: browsable && enabled.has(key),
    };
  });
}

function catalogUrl(type, id, extra = {}) {
  const parts = Object.entries(extra).filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${k}=${encodeURIComponent(v)}`);
  return `${baseUrl()}/catalog/${type}/${encId(id)}${parts.length ? '/' + parts.join('&') : ''}.json`;
}

async function catalogPage(type, id, skip = 0) {
  const url = catalogUrl(type, id, skip ? { skip } : {});
  const ttl = settings.catalogTtlSec * 1000;
  return catalogCache.get(url, async () => {
    const j = await getJson(url, { timeout: 30_000 });
    return (j.metas || []).filter((x) => x && x.id);
  }, { ttl, stale: ttl * 24 });
}

/** First `limit` items of a catalog, walking Stremio skip-pages. */
async function catalogItems(type, id, limit) {
  const out = []; const seen = new Set();
  let skip = 0;
  for (let page = 0; page < 30 && out.length < limit; page++) {
    const metas = await catalogPage(type, id, skip);
    if (!metas.length) break;
    let added = 0;
    for (const m of metas) if (!seen.has(m.id)) { seen.add(m.id); out.push(m); added++; }
    if (!added) break;
    skip += metas.length;
  }
  return out.slice(0, limit);
}

/** Search every searchable catalog (AIOStreams), falling back to Cinemeta. */
async function search(query) {
  const jobs = [];
  if (configured()) {
    try {
      const cats = (await catalogs()).filter((c) => c.searchable && c.kind);
      for (const c of cats) {
        const url = catalogUrl(c.type, c.id, { search: query });
        jobs.push(catalogCache.get(url, async () => ((await getJson(url, { timeout: 10_000 })).metas || []).filter((x) => x && x.id), { ttl: 15 * 60_000 })
          .then((metas) => metas.map((m) => ({ ...m, type: m.type || c.type }))));
      }
    } catch (e) { log('debug', `search catalogs failed: ${e.message}`); }
  }
  if (settings.metaFallbackUrl) {
    const fb = settings.metaFallbackUrl.replace(/\/manifest\.json$/, '').replace(/\/+$/, '');
    for (const t of ['movie', 'series']) {
      jobs.push(getJson(`${fb}/catalog/${t}/top/search=${encodeURIComponent(query)}.json`, { timeout: 10_000 })
        .then((j) => (j.metas || []).map((m) => ({ ...m, type: m.type || t }))));
    }
  }
  const lists = (await Promise.allSettled(jobs)).filter((r) => r.status === 'fulfilled').map((r) => r.value);
  const out = []; const seen = new Set();
  for (let i = 0; lists.some((l) => i < l.length); i++) {
    for (const l of lists) {
      const m = l[i];
      if (!m || !plexKind(m.type) || seen.has(m.id) || !/^(tt\d+|tmdb:\d+)$/.test(m.id)) continue;
      seen.add(m.id); out.push(m);
    }
  }
  return out.slice(0, 40);
}

// ── Meta ───────────────────────────────────────────────────────────────
async function meta(type, id, { force = false } = {}) {
  const key = `${type}/${id}`;
  const ttl = settings.metaTtlSec * 1000;
  return metaCache.get(key, async () => {
    let m = null;
    try {
      const man = await manifest();
      if (supports(man, 'meta', type, id)) m = (await getJson(`${baseUrl()}/meta/${type}/${encId(id)}.json`, { timeout: 15_000 })).meta || null;
    } catch (e) { log('debug', `aio meta ${key} failed: ${e.message}`); }
    if ((!m || !m.name) && settings.metaFallbackUrl && /^tt\d+/.test(id)) {
      const fbType = type === 'movie' ? 'movie' : 'series';
      const fb = settings.metaFallbackUrl.replace(/\/manifest\.json$/, '').replace(/\/+$/, '');
      try { m = (await getJson(`${fb}/meta/${fbType}/${encId(id)}.json`, { timeout: 15_000 })).meta || m; } catch (e) {
        log('debug', `fallback meta ${key} failed: ${e.message}`);
      }
    }
    if (!m) throw new Error(`no metadata for ${key}`);
    return m;
  }, { ttl, stale: ttl * 14, force });
}

// ── Streams ────────────────────────────────────────────────────────────
const timings = []; // recent lookups for the admin page
function recordTiming(t) { timings.unshift(t); if (timings.length > 60) timings.pop(); }

// AIOStreams running in Docker sometimes hands out links on its internal
// hostname (http://aiostreams:3000/...). If the manifest itself is on a public
// host, rewrite those links to it.
function rewriteInternal(url) {
  try {
    const u = new URL(url);
    if (u.hostname.includes('.') || u.hostname === 'localhost') return url;
    const b = new URL(baseUrl());
    if (!b.hostname.includes('.') || /^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(b.hostname)) return url;
    return `${b.origin}${u.pathname}${u.search}`;
  } catch { return url; }
}

// ── Packs ─────────────────────────────────────────────────────────────
// A result is a season or series pack when the torrent folder it comes from
// is named for a whole season ("Show.S02.1080p…") or the whole show
// ("Complete Series", "S01-S05"). AIOStreams gives the folder in streamData,
// behaviorHints or (with most formatters) a 📁 line in the description.
const SERIES_RE = /complete[ ._-]*series|\bS\d{1,2}[ ._-]*-[ ._-]*S?\d{1,2}\b|\bseasons?[ ._-]*\d{1,2}[ ._-]*-[ ._-]*\d{1,2}\b|\bS\d{2}(?:[ ._-]*S\d{2}){1,}\b/i;
const SEASON_RE = /\bS\d{1,2}\b(?![ ._-]*E\d)|\bseason[ ._-]*\d{1,2}\b(?![ ._-]*(?:ep|episode)\b)/i;
const EPISODE_RE = /\bS\d{1,2}[ ._-]*E\d{1,3}\b|\b\d{1,2}x\d{2}\b/i;
function packOf(folder) {
  if (!folder || EPISODE_RE.test(folder)) return null;
  if (SERIES_RE.test(folder)) return 'series';
  if (SEASON_RE.test(folder)) return 'season';
  if (/\bcomplete\b/i.test(folder)) return 'series'; // "Show Complete 1080p" with no season named
  return null;
}
function folderOf(s, hints, data) {
  const f = data.folderName || hints.folderName || s.folderName || data.torrent?.folderName;
  if (f) return String(f);
  const line = String(s.description || s.title || '').split('\n').find((l) => /📁|📂/.test(l));
  return line ? line.replace(/^[^📁📂]*[📁📂]\s*/u, '').trim() : null;
}

function normalizeStream(s, idx) {
  const url = rewriteInternal(s.url || '');
  if (!/^https?:\/\//i.test(url)) return null; // P2P/infoHash-only results need a debrid service in AIOStreams
  const hints = s.behaviorHints || {};
  const data = s.streamData || {};
  const pf = s.parsedFile || data.parsedFile || {};
  const filename = hints.filename || data.filename || s.filename || '';
  const text = [s.name, s.title, s.description, filename].filter(Boolean).join('\n');
  const info = parseRelease(text, pf);
  const exact = Number(hints.videoSize || data.size || s.size || 0) || undefined; // byte-exact sizes only
  let cached = data.service?.cached;
  if (cached === undefined) cached = hints.cached;
  if (cached === undefined) cached = info.cached;
  const service = SERVICE_IDS[String(data.service?.id || '').toLowerCase()] || info.service || null;
  const infoHash = String(data.torrent?.infoHash || data.infoHash || s.infoHash || hints.infoHash || '').toLowerCase() || null;
  const folder = folderOf(s, hints, data);
  const pack = packOf(folder);
  const container = (filename.match(/\.(mkv|mp4|m4v|avi|ts|m2ts|webm|mov)$/i) || [])[1]?.toLowerCase() || info.container || null;
  return {
    sid: md5(url), url, rank: idx, filename,
    size: exact || info.size || undefined, exactSize: exact,
    container, info,
    cached: cached === undefined ? null : !!cached,
    service, usenet: data.type === 'usenet' || info.usenet || false,
    headers: hints.proxyHeaders?.request || null,
    infoHash, folder, pack,
    // Identifies the release a file belongs to, so other episodes can come from the same pack.
    packKey: pack ? (infoHash || `${service || ''}|${folder.toLowerCase()}`) : null,
  };
}

async function fetchStreams(type, id, reason) {
  const base = baseUrl();
  if (!base) throw new Error('AIOStreams is not configured');
  const url = `${base}/stream/${type}/${encId(id)}.json`;
  const t0 = Date.now();
  // AIOStreams returns extra `streamData` (service, cached, size…) to this UA.
  const j = await getJson(url, { timeout: settings.streamWaitMs + 30_000, headers: { 'user-agent': 'AIOStreams/1.0' } });
  const ms = Date.now() - t0;
  const raw = j.streams || [];
  let list = raw.map(normalizeStream).filter(Boolean);
  const sid = String(id).split(':').slice(0, String(id).startsWith('tmdb:') ? 2 : 1).join(':');
  const checked = await require('./match').filter(type, id, list, () => meta(type, sid));
  list = checked.list;
  recordTiming({ at: Date.now(), type, id, ms, count: list.length, raw: raw.length, removed: checked.removed.length, reason });
  log('info', `streams ${type} ${id}: ${list.length} usable of ${raw.length}${checked.removed.length ? ` (${checked.removed.length} for a different title/episode)` : ''} in ${ms}ms (${reason})`);
  return list;
}

function streams(type, id, reason = 'library', { force = false } = {}) {
  const ttl = settings.streamTtlSec * 1000;
  return streamCache.get(`${type}/${id}`, () => fetchStreams(type, id, reason), {
    force,
    ttlFor: (list) => (list.length ? [ttl, settings.streamStaleSec * 1000] : [settings.emptyStreamTtlSec * 1000, 0]),
  });
}

onChange((s, before) => {
  if (s.aioUrl !== before.aioUrl) for (const c of [manifestCache, catalogCache, metaCache, streamCache]) c.clear();
});

function clearCaches() { for (const c of [catalogCache, metaCache, streamCache, manifestCache]) c.clear(); }
function stats() { return [manifestCache, catalogCache, metaCache, streamCache].map((c) => c.stats()); }

module.exports = {
  baseUrl, configured, manifest, catalogs, catalogItems, search, meta, streams, fetchStreams,
  clearCaches, stats, timings, packOf, catPrefs: () => catPrefs, saveCatPrefs, supports, plexKind,
};
