'use strict';
// Read-only WebDAV view of the library, mounted inside the Plex container by
// rclone (FUSE) so Plex sees ordinary folders and files:
//
//   /dav/<library>/<Title (Year) {imdb-tt…}>/<Title (Year) - 1080p.mkv>
//   /dav/<library>/<Show (Year) {imdb-tt…}>/Season 01/<Show (Year) - s01e01 - 1080p.mkv>
//
// Listings and sizes come from memory. Reading a file sends rclone to the
// AIOStreams/debrid link (redirect) or relays it (proxy).
const http = require('http');
const https = require('https');
const { settings } = require('./config');
const library = require('./library');
const resolver = require('./resolver');
const { agents } = require('./http');
const { log } = require('./util');

const xmlEsc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[c]));
const hrefOf = (segs, dir) => '/dav/' + segs.map(encodeURIComponent).join('/') + (dir && segs.length ? '/' : '');
const MIME = { mkv: 'video/x-matroska', mp4: 'video/mp4', m4v: 'video/mp4', avi: 'video/x-msvideo', webm: 'video/webm', mov: 'video/quicktime', ts: 'video/mp2t' };
const mimeOf = (name) => MIME[(name.match(/\.([a-z0-9]+)$/i) || [])[1]?.toLowerCase()] || 'application/octet-stream';

function propXml(segs, node) {
  const name = segs.length ? segs[segs.length - 1] : '';
  const mod = new Date(node.mtime || Date.now()).toUTCString();
  const props = node.dir
    ? '<D:resourcetype><D:collection/></D:resourcetype>'
    : `<D:resourcetype/><D:getcontentlength>${node.size}</D:getcontentlength><D:getcontenttype>${mimeOf(name)}</D:getcontenttype><D:getetag>"${node.size}-${node.mtime}"</D:getetag>`;
  return `<D:response><D:href>${xmlEsc(hrefOf(segs, node.dir))}</D:href><D:propstat><D:prop><D:displayname>${xmlEsc(name)}</D:displayname>` +
    `<D:getlastmodified>${mod}</D:getlastmodified>${props}</D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>`;
}

function authorized(req) {
  if (!settings.davPassword) return true;
  const m = String(req.headers.authorization || '').match(/^Basic\s+(.+)$/i);
  if (!m) return false;
  const [u, ...rest] = Buffer.from(m[1], 'base64').toString('utf8').split(':');
  return u === settings.davUser && rest.join(':') === settings.davPassword;
}

function parseRange(h, size) {
  const m = String(h || '').match(/^bytes=(\d*)-(\d*)$/);
  if (!m) return null;
  let start; let end;
  if (m[1] === '') { const n = Number(m[2]); start = Math.max(0, size - n); end = size - 1; }
  else { start = Number(m[1]); end = m[2] === '' ? size - 1 : Math.min(Number(m[2]), size - 1); }
  if (start > end || start >= size) return 'bad';
  return [start, end];
}

/** Relay a range of the upstream file. */
function proxy(req, res, url, headers, range, node, name) {
  const u = new URL(url);
  const mod = u.protocol === 'https:' ? https : http;
  const h = { 'user-agent': 'AIOPlex/1.0', ...(headers || {}) };
  if (range) h.range = `bytes=${range[0]}-${range[1]}`;
  const up = mod.request(u, { method: 'GET', agent: agents[u.protocol], headers: h }, (ur) => {
    if ([301, 302, 303, 307, 308].includes(ur.statusCode) && ur.headers.location) {
      ur.resume();
      return proxy(req, res, new URL(ur.headers.location, u).toString(), headers, range, node, name);
    }
    if (ur.statusCode >= 400) { ur.resume(); res.writeHead(502); return res.end(); }
    const out = { 'content-type': mimeOf(name), 'accept-ranges': 'bytes' };
    if (ur.headers['content-length']) out['content-length'] = ur.headers['content-length'];
    if (ur.statusCode === 206 && ur.headers['content-range']) out['content-range'] = ur.headers['content-range'];
    res.writeHead(ur.statusCode === 206 ? 206 : 200, out);
    ur.pipe(res);
    ur.on('error', () => res.destroy());
  });
  up.on('error', (e) => { log('debug', `proxy ${name}: ${e.message}`); if (!res.headersSent) { res.writeHead(502); res.end(); } else res.destroy(); });
  req.on('close', () => up.destroy());
  up.end();
}

async function handle(req, res, pathname) {
  if (!authorized(req)) { res.writeHead(401, { 'www-authenticate': 'Basic realm="AIOPlex"' }); return res.end(); }
  const segs = pathname.replace(/^\/dav\/?/, '').split('/').filter(Boolean).map((s) => { try { return decodeURIComponent(s); } catch { return s; } });
  const method = req.method;

  if (method === 'OPTIONS') {
    res.writeHead(200, { dav: '1', allow: 'OPTIONS, GET, HEAD, PROPFIND', 'ms-author-via': 'DAV', 'content-length': 0 });
    return res.end();
  }
  const node = library.lookup(segs);
  if (!node) { res.writeHead(404, { 'content-length': 0 }); return res.end(); }

  if (method === 'PROPFIND') {
    req.resume();
    const depth = String(req.headers.depth ?? '1');
    let body = propXml(segs, node);
    if (node.dir && depth !== '0') for (const [name, child] of node.children) body += propXml([...segs, name], child);
    const xml = `<?xml version="1.0" encoding="utf-8"?><D:multistatus xmlns:D="DAV:">${body}</D:multistatus>`;
    res.writeHead(207, { 'content-type': 'application/xml; charset=utf-8', 'content-length': Buffer.byteLength(xml) });
    return res.end(xml);
  }

  if (method !== 'GET' && method !== 'HEAD') { res.writeHead(405, { allow: 'OPTIONS, GET, HEAD, PROPFIND' }); return res.end(); }

  if (node.dir) {
    const items = [...node.children.entries()].map(([n, c]) => `<li><a href="${xmlEsc(hrefOf([...segs, n], c.dir))}">${xmlEsc(n)}${c.dir ? '/' : ''}</a></li>`).join('');
    const html = `<!doctype html><meta charset="utf-8"><title>${xmlEsc(segs.join('/') || 'AIOPlex')}</title><ul>${items}</ul>`;
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'content-length': Buffer.byteLength(html) });
    return res.end(method === 'HEAD' ? undefined : html);
  }

  const name = segs[segs.length - 1];
  const range = parseRange(req.headers.range, node.size);
  if (range === 'bad') { res.writeHead(416, { 'content-range': `bytes */${node.size}` }); return res.end(); }
  if (method === 'HEAD') {
    res.writeHead(200, { 'content-type': mimeOf(name), 'content-length': node.size, 'accept-ranges': 'bytes', 'last-modified': new Date(node.mtime).toUTCString() });
    return res.end();
  }
  const { unit, pin } = node.file;
  const url = await resolver.link(unit, pin);
  if (!url) { res.writeHead(503, { 'retry-after': '30', 'content-length': 0 }); return res.end(); }
  if (settings.streamMode === 'proxy' || pin.headers) return proxy(req, res, url, pin.headers, range, node, name);
  res.writeHead(302, { location: url, 'cache-control': 'no-store', 'content-length': 0 });
  return res.end();
}

module.exports = { handle };
