'use strict';
// What should be in Plex.
//
// Every title has one or more *sources*: an AIOStreams catalog that's turned
// on, the Plex Watchlist, or a manual add from the admin page's search. A
// title's playable units (a movie, or each aired episode of a show) get
// "pinned" to specific AIOStreams results by the resolver; only pinned files
// show up in the virtual folder tree that Plex scans.
const { settings } = require('./config');
const store = require('./store');
const aio = require('./aio');
const { log, md5, pMap } = require('./util');

const state = store.doc('library.json', { titles: {}, pins: {}, misses: {}, libs: {}, watchlistMap: {}, packs: {} });
const S = () => state.data;

let version = 0; // bumped on any change that affects the folder tree
const bump = () => { version++; state.save(); };
const listeners = new Set();
const onChange = (fn) => listeners.add(fn);
let removedSince = false; // something left the tree since the last change event
function changed(libKeys) {
  bump();
  const opts = { removed: removedSince }; removedSince = false;
  for (const fn of listeners) { try { fn(libKeys, opts); } catch { /* */ } }
}

// ── Names ──────────────────────────────────────────────────────────────
const clean = (s) => String(s || '').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').replace(/^[.\s]+|[.\s]+$/g, '').trim() || 'Untitled';
const slug = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'library';
const yearOf = (m) => { const y = parseInt(String(m.year || m.releaseInfo || m.released || '').slice(0, 4), 10); return y > 1800 ? y : null; };
const idHint = (id) => (id.startsWith('tmdb:') ? `{tmdb-${id.slice(5)}}` : `{imdb-${id}}`);
const VALID_ID = /^(tt\d+|tmdb:\d+)$/;

function titleFolder(t) { return clean(`${t.name}${t.year ? ` (${t.year})` : ''}`) + ` ${idHint(t.id)}`; }
function fileBase(t) { return clean(`${t.name}${t.year ? ` (${t.year})` : ''}`); }
const pad = (n) => String(n).padStart(2, '0');

// ── Libraries (one per enabled catalog + "Added" movies/shows) ─────────
let catalogList = []; // last manifest read
async function libraries() {
  try { catalogList = aio.configured() ? await aio.catalogs() : []; } catch { /* keep last */ }
  return librariesSync();
}
function librariesSync() {
  const prefix = settings.libraryPrefix || '';
  const libs = catalogList.filter((c) => c.enabled).map((c) => ({
    key: `cat:${c.key}`, kind: c.kind, name: `${prefix}${c.name}`,
    folder: `${slug(c.originalName)}-${c.kind}-${md5(c.key).slice(0, 6)}`,
  }));
  libs.push({ key: 'added:movie', kind: 'movie', name: `${prefix}Added Movies`, folder: 'added-movies' });
  libs.push({ key: 'added:show', kind: 'show', name: `${prefix}Added Shows`, folder: 'added-shows' });
  if (settings.split4k) {
    // Every 4K version, from every catalog and every title you added, in its own pair of libraries.
    libs.push({ key: '4k:movie', kind: 'movie', name: `${prefix}${settings.movies4kName || 'Movies 4K'}`, folder: 'movies-4k' });
    libs.push({ key: '4k:show', kind: 'show', name: `${prefix}${settings.series4kName || 'Series 4K'}`, folder: 'series-4k' });
  }
  return libs.map((l) => ({ ...l, path: `${settings.mountPath}/${l.folder}` }));
}
/** Library keys a title appears in. */
function libKeysFor(t) {
  const keys = Object.keys(t.sources).filter((s) => s.startsWith('cat:'));
  if (t.sources.watchlist || t.sources.manual) keys.push(`added:${t.kind}`);
  if (settings.split4k) keys.push(`4k:${t.kind}`);
  return keys;
}
const is4k = (p) => p.bucket >= 2160;
/** The pins of a unit that belong in a library: 4K libraries hold only 4K, the others everything else (or everything when not split). */
function pinsForLib(libKey, pins) {
  if (!pins) return [];
  if (libKey.startsWith('4k:')) return pins.filter(is4k);
  return settings.split4k ? pins.filter((p) => !is4k(p)) : pins;
}

// ── Titles ─────────────────────────────────────────────────────────────
function upsertTitle(m, stype, source) {
  const id = String(m.id);
  if (!VALID_ID.test(id)) return null;
  const kind = aio.plexKind(stype);
  if (!kind) return null;
  let t = S().titles[id];
  if (!t) {
    t = S().titles[id] = { id, stype, kind, name: m.name || id, year: yearOf(m), poster: m.poster || null, sources: {}, added: Date.now(), episodes: kind === 'show' ? null : undefined };
    log('info', `+ ${kind} ${t.name}${t.year ? ` (${t.year})` : ''} [${id}] from ${source}`);
  }
  if (m.name && !t.name) t.name = m.name;
  if (!t.year && yearOf(m)) t.year = yearOf(m);
  if (!t.poster && m.poster) t.poster = m.poster;
  t.sources[source] = Date.now();
  return t;
}

/** Remove a source from titles not in `keep`; drop titles left with no sources. Returns affected lib keys. */
function pruneSource(source, keepIds) {
  const affected = new Set();
  for (const t of Object.values(S().titles)) {
    if (!t.sources[source] || (keepIds && keepIds.has(t.id))) continue;
    for (const k of libKeysFor(t)) affected.add(k);
    delete t.sources[source];
    if (!Object.keys(t.sources).length) removeTitle(t.id);
  }
  return affected;
}
function removeTitle(id) {
  const t = S().titles[id];
  if (!t) return;
  log('info', `- ${t.kind} ${t.name} [${id}]`);
  removedSince = true;
  delete S().titles[id];
  for (const k of Object.keys(S().pins)) if (k === id || k.startsWith(`${id}:`)) delete S().pins[k];
  for (const k of Object.keys(S().misses)) if (k === id || k.startsWith(`${id}:`)) delete S().misses[k];
  for (const k of Object.keys(S().packs)) if (k.startsWith(`${id}:`)) delete S().packs[k];
}

/** Read every enabled catalog and bring titles in line with it. */
let syncing = null;
function syncCatalogs() {
  if (syncing) return syncing;
  syncing = (async () => {
    const affected = new Set();
    if (!aio.configured()) return affected;
    await libraries();
    for (const c of catalogList) {
      const source = `cat:${c.key}`;
      if (!c.enabled) { for (const k of pruneSource(source, null)) affected.add(k); continue; }
      try {
        const items = await aio.catalogItems(c.type, c.id, settings.catalogLimit);
        const ids = new Set();
        for (const m of items) { const t = upsertTitle(m, c.type, source); if (t) { ids.add(t.id); affected.add(source); } }
        for (const k of pruneSource(source, ids)) affected.add(k);
        log('info', `catalog ${c.name}: ${ids.size} titles`);
      } catch (e) { log('warn', `catalog ${c.name} failed: ${e.message}`); }
    }
    await refreshEpisodes();
    changed([...affected]);
    return affected;
  })().finally(() => { syncing = null; });
  return syncing;
}

/** Load (or reload) episode lists for shows. */
/** Load (or reload) episode lists. `ids` limits it to some shows; `force` skips the metadata cache. Returns the number of new episodes seen. */
async function refreshEpisodes({ ids = null, force = false } = {}) {
  const shows = Object.values(S().titles).filter((t) => t.kind === 'show' && (!ids || ids.includes(t.id)));
  let added = 0; const shrunk = new Set();
  await pMap(shows, 4, async (t) => {
    try {
      const m = await aio.meta(t.stype, t.id, { force });
      if (m.name && t.name === t.id) t.name = m.name;
      if (!t.year && yearOf(m)) t.year = yearOf(m);
      const eps = [];
      for (const v of m.videos || []) {
        const s = Number(v.season); const e = Number(v.episode ?? v.number);
        if (!Number.isInteger(s) || !Number.isInteger(e) || e < 1) continue;
        const rel = Date.parse(v.released || v.firstAired || '') || null;
        eps.push([s, e, rel]);
      }
      eps.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
      if (!eps.length && (t.episodes || []).length) return; // a bad response must not wipe a show
      const before = new Set(unitsOf(t).map((u) => u.key));
      t.episodes = eps;
      t.episodesAt = Date.now();
      const after = new Set(unitsOf(t).map((u) => u.key));
      // e.g. a new season pushed the oldest out of CATALOG_SHOW_SEASONS
      if ([...before].some((k) => !after.has(k) && S().pins[k])) { removedSince = true; for (const k of libKeysFor(t)) shrunk.add(k); }
      const fresh = unitsOf(t).filter((u) => !before.has(u.key));
      if (fresh.length && before.size) {
        added += fresh.length;
        log('info', `new episode${fresh.length > 1 ? 's' : ''} of ${t.name}: ${fresh.map((u) => `S${pad(u.s)}E${pad(u.e)}`).join(', ')}`);
      }
    } catch (e) { log('debug', `episodes for ${t.name} failed: ${e.message}`); }
  });
  if (shrunk.size) changed([...shrunk]);
  return added;
}

// Shows "on air": an episode aired in the last two weeks or airs in the next
// eight days (or no list yet). Their episode lists are re-read every
// AIRING_CHECK_MIN, skipping the metadata cache, so new episodes are noticed
// within that time of their air date.
const DAY = 86_400_000;
function airingShows() {
  const now = Date.now();
  return Object.values(S().titles).filter((t) => t.kind === 'show'
    && (!t.episodes || t.episodes.some(([, , rel]) => rel && rel > now - 14 * DAY && rel < now + 8 * DAY)));
}
let airingBusy = null;
function checkAiring() {
  if (airingBusy) return airingBusy;
  airingBusy = (async () => {
    const shows = airingShows();
    if (!shows.length) return { shows: 0, added: 0 };
    const added = await refreshEpisodes({ ids: shows.map((t) => t.id), force: true });
    state.save();
    log(added ? 'info' : 'debug', `airing check: ${shows.length} shows, ${added} new episodes`);
    return { shows: shows.length, added };
  })().finally(() => { airingBusy = null; lastAiringCheck = Date.now(); });
  return airingBusy;
}
let lastAiringCheck = 0;
/** Aired within FRESH_EPISODE_HOURS? */
const isFresh = (u) => !!(u.rel && Date.now() - u.rel < settings.freshEpisodeHours * 3600_000);

/** The playable units of a title: [{ key, streamId, s, e, order }]. */
function unitsOf(t) {
  if (t.kind === 'movie') return [{ key: t.id, title: t, s: null, e: null, order: 0 }];
  const now = Date.now();
  const onlyCatalog = !t.sources.watchlist && !t.sources.manual;
  // Seasons with at least one aired episode; CATALOG_SHOW_SEASONS keeps the latest N of them.
  const aired = [...new Set((t.episodes || []).filter(([s, , rel]) => s > 0 && (!rel || rel <= now)).map((x) => x[0]))].sort((a, b) => a - b);
  const allowed = onlyCatalog && settings.catalogShowSeasons > 0 ? new Set(aired.slice(-settings.catalogShowSeasons)) : null;
  const out = [];
  for (const [s, e, rel] of t.episodes || []) {
    if (s === 0 && !settings.includeSpecials) continue;
    if (allowed && !allowed.has(s) && s !== 0) continue;
    if (rel && rel > now) continue; // not aired yet
    const first = !out.some((u) => u.s === s); // first aired episode of its season: finds the season's pack
    out.push({ key: `${t.id}:${s}:${e}`, title: t, s, e, rel, first, order: out.length });
  }
  return out;
}

// ── Manual adds / Watchlist ────────────────────────────────────────────
async function addManual(id, stype) {
  const m = await aio.meta(stype, id).catch(() => ({ id, name: id }));
  const t = upsertTitle({ ...m, id }, stype, 'manual');
  if (!t) throw new Error('Only IMDb (tt…) and TMDB ids can be added');
  if (t.kind === 'show') await refreshEpisodes({ ids: [t.id] });
  changed(libKeysFor(t));
  return t;
}
function removeManual(id) {
  const t = S().titles[id];
  if (!t) return;
  const keys = libKeysFor(t);
  delete t.sources.manual; delete t.sources.watchlist;
  removedSince = true;
  if (!Object.keys(t.sources).length) removeTitle(id);
  changed(keys);
}
/** items: [{ id, stype }] currently on the Watchlist. */
async function applyWatchlist(items) {
  const affected = new Set();
  const ids = new Set();
  const fresh = [];
  for (const it of items) {
    const known = S().titles[it.id];
    const had = known && known.sources.watchlist;
    const t = upsertTitle(it, it.stype, 'watchlist');
    if (!t) continue;
    ids.add(t.id);
    if (!had) { fresh.push(t); for (const k of libKeysFor(t)) affected.add(k); }
  }
  if (settings.watchlistRemove) for (const k of pruneSource('watchlist', ids)) affected.add(k);
  for (const t of fresh) if (t.kind === 'show') await refreshEpisodes({ ids: [t.id] });
  if (affected.size) changed([...affected]);
  return fresh.length;
}

// ── Pins (filled in by the resolver) ───────────────────────────────────
function setPins(unitKey, pins) {
  // A re-check that lands on the same file keeps its date, so Plex doesn't see a change.
  for (const p of pins) {
    const old = (S().pins[unitKey] || []).find((o) => o.url === p.url && o.size === p.size);
    if (old) p.pinnedAt = old.pinnedAt;
  }
  S().pins[unitKey] = pins; delete S().misses[unitKey];
  const t = S().titles[unitKey.split(':').slice(0, unitKey.startsWith('tmdb:') ? 2 : 1).join(':')];
  changed(t ? libKeysFor(t) : []);
}
function setMiss(unitKey, why) { S().misses[unitKey] = { at: Date.now(), why }; state.save(); }

// ── Virtual folder tree ────────────────────────────────────────────────
// node: { dir: true, children: Map(name → node), mtime } | { file: { unit, pin }, size, mtime }
let tree = null; let treeVersion = -1;
function dirNode(mtime = Date.now()) { return { dir: true, children: new Map(), mtime }; }
function buildTree() {
  const root = dirNode(store.meta.get('started') || Date.now());
  const libs = librariesSync();
  const byKey = new Map(libs.map((l) => [l.key, l]));
  for (const l of libs) root.children.set(l.folder, dirNode());
  for (const t of Object.values(S().titles)) {
    const units = unitsOf(t); // only what's allowed now (seasons limit, specials)
    const files = [];
    for (const u of units) {
      const pins = S().pins[u.key];
      if (!pins || !pins.length) continue;
      const used = new Set();
      for (const p of pins) {
        let label = p.label; let n = 2;
        while (used.has(label)) label = `${p.label} v${n++}`;
        used.add(label);
        const ep = u.s !== null ? ` - s${pad(u.s)}e${pad(u.e)}` : '';
        const name = `${fileBase(t)}${ep} - ${label}.${p.ext || 'mkv'}`;
        files.push({ season: u.s, name, pin: p, node: { file: { unit: u.key, pin: p }, size: p.size, mtime: p.pinnedAt } });
      }
    }
    if (!files.length) continue;
    for (const lk of libKeysFor(t)) {
      const lib = byKey.get(lk);
      if (!lib || lib.kind !== t.kind) continue;
      const mine = files.filter((f) => pinsForLib(lk, [f.pin]).length);
      if (!mine.length) continue;
      const tf = dirNode(t.added);
      root.children.get(lib.folder).children.set(titleFolder(t), tf);
      for (const f of mine) {
        let parent = tf;
        if (f.season !== null) {
          const sn = f.season === 0 ? 'Specials' : `Season ${pad(f.season)}`;
          if (!tf.children.has(sn)) tf.children.set(sn, dirNode(t.added));
          parent = tf.children.get(sn);
        }
        parent.children.set(f.name, f.node);
      }
    }
  }
  return root;
}
/** Look up a path (array of decoded segments) in the tree. */
function lookup(segs) {
  if (!tree || treeVersion !== version) { tree = buildTree(); treeVersion = version; }
  let node = tree;
  for (const s of segs) {
    if (!node.dir) return null;
    node = node.children.get(s);
    if (!node) return null;
  }
  return node;
}

// ── Stats for the admin page ───────────────────────────────────────────
function stats() {
  const titles = Object.values(S().titles);
  const libs = librariesSync().map((l) => {
    const ts = titles.filter((t) => libKeysFor(t).includes(l.key) && t.kind === l.kind);
    let units = 0; let pinned = 0; let missing = 0;
    let shown = 0;
    for (const t of ts) {
      let any = false;
      for (const u of unitsOf(t)) {
        units++;
        if (pinsForLib(l.key, S().pins[u.key]).length) { pinned++; any = true; } else if (S().misses[u.key] || S().pins[u.key]) missing++;
      }
      if (any) shown++;
    }
    return { ...l, titles: l.key.startsWith('4k:') ? shown : ts.length, units, pinned, missing, sectionId: (S().libs[l.key] || {}).sectionId || null };
  });
  return { libs, airing: airingShows().length, lastAiringCheck, titles: titles.length, pins: Object.keys(S().pins).length, misses: Object.keys(S().misses).length };
}

function listAdded() {
  return Object.values(S().titles).filter((t) => t.sources.manual || t.sources.watchlist)
    .sort((a, b) => b.added - a.added)
    .map((t) => {
      const units = unitsOf(t);
      return { id: t.id, kind: t.kind, name: t.name, year: t.year, poster: t.poster, watchlist: !!t.sources.watchlist, manual: !!t.sources.manual,
        units: units.length, pinned: units.filter((u) => S().pins[u.key]).length, missing: units.filter((u) => !S().pins[u.key] && S().misses[u.key]).length };
    });
}

function titleOfUnit(unitKey) {
  const parts = unitKey.split(':');
  return S().titles[parts.slice(0, unitKey.startsWith('tmdb:') ? 2 : 1).join(':')];
}

module.exports = {
  state: S, checkAiring, isFresh, libraries, librariesSync, libKeysFor, syncCatalogs, refreshEpisodes, unitsOf, addManual, removeManual,
  applyWatchlist, setPins, markRemoved: () => { removedSince = true; }, setMiss, lookup, stats, listAdded, onChange, titleOfUnit, changed, version: () => version,
};
