'use strict';
// Small JSON persistence layer. Everything is held in memory and flushed to
// disk with a debounce, so request handlers never wait on I/O.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { boot } = require('./config');
const { randomHex, log } = require('./util');

/** A JSON document on disk, loaded once and saved (debounced) on change. */
function doc(name, initial) {
  const file = path.join(boot.dataDir, name);
  let data = initial;
  try { data = { ...initial, ...JSON.parse(fs.readFileSync(file, 'utf8')) }; } catch { /* fresh */ }
  let timer = null;
  const flush = () => {
    clearTimeout(timer); timer = null;
    try {
      fs.writeFileSync(file + '.tmp', JSON.stringify(data));
      fs.renameSync(file + '.tmp', file);
    } catch (e) { log('error', `failed to save ${name}: ${e.message}`); }
  };
  const save = () => { if (!timer) timer = setTimeout(flush, 1500); };
  docs.push(flush);
  return { get data() { return data; }, save, flush };
}
const docs = [];

const db = doc('db.json', { clientId: randomHex(16), users: {}, sessions: {}, meta: {} });
db.save(); // persist the generated client id on first boot

// ── Admin accounts (for the AIOPlex admin page only) ───────────────────
function hashPassword(pw, salt = randomHex(16)) {
  return `${salt}:${crypto.scryptSync(String(pw), salt, 32).toString('hex')}`;
}
function checkPassword(pw, stored) {
  if (!stored) return false;
  const [salt, h] = stored.split(':');
  const test = crypto.scryptSync(String(pw || ''), salt, 32).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(h, 'hex'), Buffer.from(test, 'hex'));
}
const users = {
  list: () => Object.values(db.data.users),
  get: (id) => db.data.users[id],
  byName: (name) => Object.values(db.data.users).find((u) => u.name.toLowerCase() === String(name || '').toLowerCase()),
  create(name, password) {
    if (users.byName(name)) throw new Error('A user with that name already exists');
    const id = randomHex(8);
    db.data.users[id] = { id, name: String(name), pw: hashPassword(password), created: new Date().toISOString() };
    db.save();
    return db.data.users[id];
  },
  setPassword(id, password) { const u = users.get(id); if (u) { u.pw = hashPassword(password); db.save(); } },
  remove(id) { delete db.data.users[id]; for (const [t, s] of Object.entries(db.data.sessions)) if (s.userId === id) delete db.data.sessions[t]; db.save(); },
  checkPassword,
};

const sessions = {
  create(userId) { const t = randomHex(24); db.data.sessions[t] = { userId, created: Date.now() }; db.save(); return t; },
  get(t) { return t ? db.data.sessions[t] : null; },
  remove(t) { delete db.data.sessions[t]; db.save(); },
};

const meta = {
  get: (k) => db.data.meta[k],
  set: (k, v) => { if (db.data.meta[k] !== v) { db.data.meta[k] = v; db.save(); } },
};

const flushAll = () => { for (const f of docs) f(); };
process.on('exit', flushAll);
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { flushAll(); process.exit(0); });

module.exports = { doc, users, sessions, meta, clientId: () => db.data.clientId, flushAll };
