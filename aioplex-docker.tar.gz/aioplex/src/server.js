'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const { boot } = require('./config');
const store = require('./store');
const dav = require('./dav');
const { log } = require('./util');

// ── Router ─────────────────────────────────────────────────────────────
const routes = [];
/** route('GET', '/admin/api/x/:id', handler, { auth: true }) */
function route(method, pattern, handler, opts = {}) {
  routes.push({ method, parts: pattern.split('/').filter(Boolean), handler, auth: opts.auth !== false });
}
function match(method, segs) {
  for (const r of routes) {
    if (r.method !== method || r.parts.length !== segs.length) continue;
    const params = {}; let ok = true;
    for (let i = 0; i < r.parts.length; i++) {
      const p = r.parts[i];
      if (p.startsWith(':')) params[p.slice(1)] = decodeURIComponent(segs[i]);
      else if (p !== segs[i]) { ok = false; break; }
    }
    if (ok) return { r, params };
  }
  return null;
}

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }

function json(res, obj, status = 200) {
  const b = JSON.stringify(obj ?? null);
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(b), 'cache-control': 'no-store' });
  res.end(b);
}

async function readBody(req) {
  const chunks = []; let size = 0;
  for await (const c of req) { size += c.length; if (size > 1_000_000) throw new HttpError(413, 'body too large'); chunks.push(c); }
  const raw = Buffer.concat(chunks).toString('utf8');
  if (!raw) return {};
  try { return JSON.parse(raw); } catch { throw new HttpError(400, 'invalid JSON'); }
}

// ── Static admin page ──────────────────────────────────────────────────
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml' };
function serveAdmin(res, rel) {
  const file = path.join(boot.adminPath, rel === '' ? 'index.html' : rel);
  if (!file.startsWith(boot.adminPath) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) return false;
  const body = fs.readFileSync(file);
  res.writeHead(200, { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream', 'content-length': body.length, 'cache-control': 'no-cache' });
  res.end(body);
  return true;
}

async function handle(req, res) {
  const u = new URL(req.url, 'http://x');
  const pathname = u.pathname.replace(/\/{2,}/g, '/');
  try {
    if (pathname === '/dav' || pathname.startsWith('/dav/')) return await dav.handle(req, res, pathname);
    if (pathname === '/health') return json(res, { ok: true });
    if (pathname === '/' || pathname === '/admin') { res.writeHead(302, { location: '/admin/' }); return res.end(); }
    if (pathname.startsWith('/admin/') && !pathname.startsWith('/admin/api/') && req.method === 'GET') {
      if (serveAdmin(res, pathname.slice('/admin/'.length))) return;
    }
    const segs = pathname.split('/').filter(Boolean);
    const m = match(req.method, segs);
    if (!m) return json(res, { error: 'Not found' }, 404);
    const session = store.sessions.get(req.headers['x-aioplex-token']);
    const user = session ? store.users.get(session.userId) : null;
    if (m.r.auth && !user) return json(res, { error: 'Sign in first' }, 401);
    const body = req.method === 'GET' ? {} : await readBody(req);
    const query = Object.fromEntries(u.searchParams);
    const out = await m.r.handler({ req, res, query, params: m.params, body, user, token: req.headers['x-aioplex-token'] });
    if (!res.headersSent) json(res, out === undefined ? { ok: true } : out);
  } catch (e) {
    const status = e.status || 500;
    if (status >= 500) log('error', `${req.method} ${pathname}: ${e.stack || e.message}`);
    if (!res.headersSent) json(res, { error: e.message }, status); else res.destroy();
  }
}

function listen() {
  const server = http.createServer(handle);
  server.keepAliveTimeout = 65_000;
  server.headersTimeout = 66_000;
  server.requestTimeout = 0; // proxied video can be long-lived
  server.listen(boot.port, () => log('info', `AIOPlex listening on :${boot.port} (admin at /admin, library at /dav)`));
  return server;
}

module.exports = { route, listen, HttpError };
