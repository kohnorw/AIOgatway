'use strict';
const { route, HttpError } = require('../server');
const config = require('../config');
const { settings, DEFS } = config;
const store = require('../store');
const aio = require('../aio');
const library = require('../library');
const resolver = require('../resolver');
const plex = require('../plex');
const { getJson } = require('../http');
const { log } = require('../util');

const setupNeeded = () => store.users.list().length === 0;

/** Re-read catalogs, then bring Plex libraries and pins in line. */
async function resync() {
  await library.syncCatalogs();
  resolver.fill();
  await plex.syncLibraries();
}

route('GET', '/admin/api/status', async (ctx) => {
  if (setupNeeded()) return { setupNeeded: true };
  if (!ctx.user) throw new HttpError(401, 'Sign in first');
  let manifest = null; let manifestError = null;
  if (aio.configured()) {
    try { const m = await aio.manifest(); manifest = { name: m.name, version: m.version, catalogs: (m.catalogs || []).length }; } catch (e) { manifestError = e.message; }
  }
  const s = { ...settings };
  if (s.davPassword) s.davPassword = '••••••••';
  if (s.plexToken) s.plexToken = '••••••••';
  return {
    setupNeeded: false, user: ctx.user.name, configured: aio.configured(), manifest, manifestError,
    settings: s, plex: await plex.status(), library: library.stats(), resolver: resolver.stats(),
    timings: aio.timings.slice(0, 20), caches: aio.stats(), uptime: process.uptime(),
    users: store.users.list().map((u) => ({ id: u.id, name: u.name })),
  };
}, { auth: false });

route('POST', '/admin/api/setup', async (ctx) => {
  if (!setupNeeded()) throw new HttpError(409, 'Setup is already complete');
  const { username, password, aioUrl } = ctx.body || {};
  if (!username || !password) throw new HttpError(400, 'Choose a username and password');
  if (aioUrl) config.update({ aioUrl });
  const u = store.users.create(username, password);
  log('info', `admin user "${u.name}" created`);
  return { token: store.sessions.create(u.id) };
}, { auth: false });

route('POST', '/admin/api/login', (ctx) => {
  const u = store.users.byName(ctx.body.username);
  if (!u || !store.users.checkPassword(ctx.body.password, u.pw)) throw new HttpError(401, "That username and password don't match");
  return { token: store.sessions.create(u.id) };
}, { auth: false });
route('POST', '/admin/api/logout', (ctx) => { store.sessions.remove(ctx.token); });

route('POST', '/admin/api/settings', (ctx) => {
  const patch = {};
  for (const [k, v] of Object.entries(ctx.body || {})) {
    if (!(k in DEFS)) continue;
    if ((k === 'davPassword' || k === 'plexToken') && v === '••••••••') continue;
    patch[k] = v;
  }
  const before = { ...settings };
  config.update(patch);
  const changedKey = (k) => k in patch && patch[k] !== before[k];
  if (['catalogShowSeasons', 'includeSpecials'].some(changedKey)) library.markRemoved(); // seasons can leave Plex
  if (changedKey('aioUrl')) resync().catch(() => {});
  else if (['libraryPrefix', 'catalogLimit', 'catalogShowSeasons', 'includeSpecials'].some(changedKey)) resync().catch(() => {});
  if ('freshRetryMin' in patch || 'freshEpisodeHours' in patch) resolver.fill();
  const reshape = ['split4k', 'movieVersions', 'episodeVersions', 'maxHeight'].some((k) => k in patch && patch[k] !== before[k]);
  if (reshape) {
    // Which versions each title needs has changed: re-pick for everything (stream lists come from cache;
    // files that stay the same keep their dates, so Plex only rescans what really changed).
    library.markRemoved(); // files can leave a library (e.g. 4K moving out): let Plex drop them after its scan
    library.changed(Object.keys(library.state().libs));
    resolver.fill({ all: true });
  } else if ('onlyCached' in patch) resolver.fill();
  if (['split4k', 'movies4kName', 'series4kName'].some((k) => k in patch && patch[k] !== before[k])) plex.syncLibraries().catch(() => {});
  if ('serverName' in patch || 'configurePlex' in patch) plex.setup().catch(() => {});
});

route('POST', '/admin/api/test-url', async (ctx) => {
  let url = String(ctx.body.url || '').trim().replace(/^stremio:\/\//i, 'https://');
  if (!url) throw new HttpError(400, 'Paste your AIOStreams manifest URL');
  if (!/manifest\.json/i.test(url)) url = url.replace(/\/+$/, '') + '/manifest.json';
  const t0 = Date.now();
  try {
    const m = await getJson(url, { timeout: 15_000 });
    return { ok: true, ms: Date.now() - t0, name: m.name, version: m.version, catalogs: (m.catalogs || []).length };
  } catch (e) { return { ok: false, ms: Date.now() - t0, error: e.message }; }
});

// ── Catalogs → libraries ───────────────────────────────────────────────
route('GET', '/admin/api/catalogs', async () => (aio.configured() ? aio.catalogs() : []));
route('POST', '/admin/api/catalogs', async (ctx) => {
  const { enabled, names } = ctx.body || {};
  aio.saveCatPrefs({ ...(Array.isArray(enabled) ? { enabled } : {}), ...(names && typeof names === 'object' ? { names } : {}) });
  resync().catch((e) => log('warn', `resync failed: ${e.message}`));
});
route('POST', '/admin/api/sync', () => { resync().catch(() => {}); });
route('POST', '/admin/api/airing-check', async () => {
  const r = await library.checkAiring();
  return { ...r, queued: resolver.fill() };
});
route('POST', '/admin/api/retry', () => {
  const st = library.state();
  for (const k of Object.keys(st.misses)) delete st.misses[k];
  return { queued: resolver.fill() };
});
route('POST', '/admin/api/cache/clear', () => { aio.clearCaches(); });

// ── Search and add ─────────────────────────────────────────────────────
route('GET', '/admin/api/search', async (ctx) => {
  const q = String(ctx.query.q || '').trim();
  if (!q) return [];
  const st = library.state();
  let found;
  if (/^tt\d+$/.test(q)) {
    // An IMDb id: look it up directly as a movie, then as a series.
    found = [];
    for (const t of ['movie', 'series']) {
      try { const m = await aio.meta(t, q); if (m && m.name) { found.push({ ...m, id: q, type: m.type || t }); break; } } catch { /* try next */ }
    }
  } else found = await aio.search(q);
  return found.map((m) => {
    const t = st.titles[m.id];
    return { id: m.id, type: m.type, kind: aio.plexKind(m.type), name: m.name, year: m.releaseInfo || m.year || '', poster: m.poster || null,
      added: !!(t && (t.sources.manual || t.sources.watchlist)), inLibrary: !!t };
  });
});
route('POST', '/admin/api/add', async (ctx) => {
  const id = String(ctx.body.id || '').trim();
  const type = ctx.body.type === 'movie' ? 'movie' : ctx.body.type === 'anime' ? 'anime' : 'series';
  if (!/^(tt\d+|tmdb:\d+)$/.test(id)) throw new HttpError(400, 'Use an IMDb id like tt0111161');
  const t = await library.addManual(id, type);
  resolver.fill();
  return { id: t.id, name: t.name };
});
route('GET', '/admin/api/added', () => library.listAdded());
route('DELETE', '/admin/api/added/:id', (ctx) => { library.removeManual(ctx.params.id); });

// ── Plex ───────────────────────────────────────────────────────────────
route('POST', '/admin/api/plex/signin', () => plex.startSignIn());
route('GET', '/admin/api/plex/signin/:id', async (ctx) => {
  const r = await plex.checkSignIn(ctx.params.id);
  if (r.done) { plex.setup().catch(() => {}); plex.pollWatchlist(); }
  return r;
});
route('POST', '/admin/api/plex/signout', () => { plex.signOut(); });
route('POST', '/admin/api/plex/claim', async (ctx) => {
  const r = ctx.body.claimToken ? await plex.claimWith(ctx.body.claimToken) : await plex.claimWithAccount();
  return r;
});
route('POST', '/admin/api/plex/sync', async () => { await plex.setup(); plex.scanAll(); });

// ── Admin accounts ─────────────────────────────────────────────────────
route('POST', '/admin/api/users', (ctx) => {
  const { name, password } = ctx.body || {};
  if (!name || !password) throw new HttpError(400, 'Enter a username and password');
  try { return { id: store.users.create(name, password).id }; } catch (e) { throw new HttpError(409, e.message); }
});
route('DELETE', '/admin/api/users/:id', (ctx) => {
  if (ctx.params.id === ctx.user.id) throw new HttpError(400, "You can't delete your own account");
  store.users.remove(ctx.params.id);
});
route('POST', '/admin/api/users/:id/password', (ctx) => {
  if (!ctx.body.password) throw new HttpError(400, 'Enter a password');
  store.users.setPassword(ctx.params.id, ctx.body.password);
});

module.exports = { resync };
