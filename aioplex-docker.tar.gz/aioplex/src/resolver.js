'use strict';
// Turns library units (a movie, an episode) into pinned files.
//
// For each unit the resolver asks AIOStreams for streams (by IMDb/TMDB id),
// keeps results your debrid service has cached, picks up to N versions (one
// per resolution, in AIOStreams' own order) and checks each with a one-byte
// range request. That check gives the file's exact size (Plex and rclone
// need it before anything is read) and the final debrid link.
//
// Later, when Plex reads a file, `link()` hands back a recently checked link,
// re-checking it once it's older than LINK_TTL_SEC. If a link has died, the
// same release is looked for again (same size), and failing that the unit is
// re-pinned to a fresh result and Plex rescans it.
const http = require('http');
const https = require('https');
const { settings } = require('./config');
const aio = require('./aio');
const library = require('./library');
const { agents } = require('./http');
const { log, fmtBytes } = require('./util');
const { resLabel } = require('./parse');

// ── Probing: is this a seekable video, and how big is it? ──────────────
// Plex reads through rclone with range requests, so a result is only usable if
// its server honours them. A one-byte read (following redirects) answers that
// and gives the exact size and the final debrid link.
const MAX_BODY = 2048;
function probeOnce(url, headers, range, redirects = 8) {
  return new Promise((resolve) => {
    let u;
    try { u = new URL(url); } catch { return resolve({ error: 'bad url' }); }
    const mod = u.protocol === 'https:' ? https : http;
    const req = mod.request(u, { method: 'GET', agent: agents[u.protocol], headers: { 'user-agent': 'AIOPlex/1.0', ...headers, range } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects > 0) {
        res.resume(); clearTimeout(timer);
        return probeOnce(new URL(res.headers.location, u).toString(), headers, range, redirects - 1).then(resolve);
      }
      clearTimeout(timer);
      const type = String(res.headers['content-type'] || '');
      const out = {
        status: res.statusCode, type, url: u.toString(), host: u.host,
        total: Number((String(res.headers['content-range'] || '').match(/\/(\d+)\s*$/) || [])[1]) || null,
        length: Number(res.headers['content-length']) || null,
      };
      // Error pages: keep the start of the body so the reason can be shown.
      if (/text\/|json|xml/i.test(type) || res.statusCode >= 400) {
        const chunks = []; let n = 0;
        res.on('data', (c) => { chunks.push(c); n += c.length; if (n >= MAX_BODY) res.destroy(); });
        const done = () => resolve({ ...out, body: Buffer.concat(chunks).toString('utf8').slice(0, MAX_BODY) });
        res.on('end', done); res.on('close', done);
        return;
      }
      res.destroy(); // a video: the headers are all we need
      resolve(out);
    });
    const timer = setTimeout(() => { req.destroy(); resolve({ error: 'timed out' }); }, 25_000);
    req.on('error', (e) => { clearTimeout(timer); resolve({ error: e.message }); });
    req.end();
  });
}

/** Pull a readable message out of an error page (AIOStreams/debrid JSON or HTML). */
function errorMessage(body) {
  const b = String(body || '').trim();
  try {
    const j = JSON.parse(b);
    const m = j.error?.message || j.error?.description || (typeof j.error === 'string' && j.error) || j.message || j.detail || j.description;
    if (m) return String(m).slice(0, 140);
  } catch { /* not JSON */ }
  const title = (b.match(/<title[^>]*>([^<]+)<\/title>/i) || [])[1];
  return (title || b.replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim().slice(0, 140) || '(empty)';
}

async function probe(url, headers = {}) {
  let r = await probeOnce(url, headers, 'bytes=0-0');
  if (r.error) return { ok: false, why: r.error };
  if (r.body !== undefined) return { ok: false, why: `error from ${r.host}${r.status !== 200 ? ` (HTTP ${r.status})` : ''}: ${errorMessage(r.body)}` };
  if (r.status === 206 && r.total) return { ok: true, size: r.total, url: r.url, type: r.type };
  if (r.status === 200) {
    // Some servers ignore a one-byte range but honour real ones: ask again for 1 KB, at the final link.
    const r2 = await probeOnce(r.url, headers, 'bytes=1024-2047');
    if (r2.status === 206 && r2.total) return { ok: true, size: r2.total, url: r2.url, type: r2.type };
    if (r2.body !== undefined) return { ok: false, why: `error from ${r2.host}: ${errorMessage(r2.body)}` };
    return { ok: false, why: `${r.host} can't seek (sends the whole file, ignoring ranges)` };
  }
  return { ok: false, why: `HTTP ${r.status} from ${r.host}` };
}

const bucket = (h) => (h >= 2160 ? 2160 : h >= 1080 ? 1080 : h >= 720 ? 720 : h ? 480 : 0);
const extOf = (s) => (['mkv', 'mp4', 'm4v', 'avi', 'ts', 'webm', 'mov'].includes(s.container) ? s.container : 'mkv');

/** Does a probed file look like the release AIOStreams described (not an error clip)? */
function plausible(s, size) {
  if (s.exactSize) return size === s.exactSize;
  if (s.size) return Math.abs(size - s.size) / s.size < 0.15;
  return size > 30 * 1024 * 1024;
}

/** Pick and verify versions for one unit. */
async function resolveUnit(unit, force = false) {
  const t = unit.title;
  const want = t.kind === 'movie' ? settings.movieVersions : settings.episodeVersions;
  // A retry after "nothing cached" must ask AIOStreams again, not reuse the old list.
  const list = await aio.streams(t.stype, unit.key, 'library', { force: force || !!library.state().misses[unit.key] });
  let cands = list.filter((s) => (s.info.height || 0) <= settings.maxHeight);
  if (settings.onlyCached) cands = cands.filter((s) => s.cached !== false);
  // Within AIOStreams' order, results known to be cached go first.
  cands = [...cands.filter((s) => s.cached === true), ...cands.filter((s) => s.cached !== true)];
  if (!cands.length) return { pins: [], why: list.length ? `${list.length} results, none cached` : 'no results' };

  // Episodes: packs first. Keeping AIOStreams' preference between resolutions, a
  // release this season already uses comes first, then series packs, then
  // season packs, then single episodes. One pack means one torrent on your
  // debrid service for the whole season, every episode the same release, and
  // (once the pack has been checked) no debrid check per episode at all.
  const episode = unit.s !== null && unit.s !== undefined;
  const packs = library.state().packs;
  const packSlot = (pack, b) => `${t.id}:${pack === 'series' ? '*' : unit.s}:${b}`;
  const knownPack = (s) => {
    if (!s.packKey) return null;
    const b = bucket(s.info.height);
    const k = packs[packSlot(s.pack, b)];
    return k && k.key === s.packKey ? k : null;
  };
  if (episode && settings.preferPacks) {
    const bRank = new Map();
    for (const s of cands) { const b = bucket(s.info.height); if (!bRank.has(b)) bRank.set(b, bRank.size); }
    const pRank = (s) => (knownPack(s) ? 0 : s.pack === 'series' ? 1 : s.pack === 'season' ? 2 : 3);
    cands = cands.map((s, i) => ({ s, i })).sort((a, b) => ((a.s.cached === true ? 0 : 1) - (b.s.cached === true ? 0 : 1))
      || (bRank.get(bucket(a.s.info.height)) - bRank.get(bucket(b.s.info.height)))
      || (pRank(a.s) - pRank(b.s)) || (a.i - b.i)).map((x) => x.s);
  }

  // Split 4K: one 4K version for the 4K libraries, plus `want` others for the regular ones.
  const split = settings.split4k;
  const enough = () => (split
    ? pins.some((p) => p.bucket === 2160) && pins.filter((p) => p.bucket !== 2160).length >= Math.max(1, want)
    : pins.length >= Math.max(1, want));
  const pins = []; const tried = new Map();
  const reasons = new Map(); // why → count, for the activity list when nothing works
  const fail = (why) => reasons.set(why, (reasons.get(why) || 0) + 1);
  for (const s of cands) {
    if (enough()) break;
    const b = bucket(s.info.height);
    if (pins.some((p) => p.bucket === b)) continue;
    if (split && b !== 2160 && pins.filter((p) => p.bucket !== 2160).length >= Math.max(1, want)) continue;
    if ((tried.get(b) || 0) >= 4) continue;
    tried.set(b, (tried.get(b) || 0) + 1);
    // Already pinned and checked: no need to touch the debrid service again.
    const old = (library.state().pins[unit.key] || []).find((p) => p.url === s.url);
    if (old && !force) { pins.push({ ...old, bucket: b }); continue; }
    const base = { bucket: b, label: resLabel(s.info.height) || 'SD', url: s.url, filename: s.filename || null, ext: extOf(s), service: s.service || null,
      cached: s.cached, headers: s.headers || null, pack: s.pack || null, packKey: s.packKey || null, pinnedAt: Date.now() };
    // Another file from a pack that's already been checked, with an exact size from
    // AIOStreams: trust it. Its link is fetched the first time Plex reads it.
    if (episode && settings.preferPacks && !force && s.exactSize && knownPack(s)) {
      pins.push({ ...base, size: s.exactSize, link: null, linkAt: 0, trusted: true });
      continue;
    }
    const r = await probe(s.url, s.headers || {});
    if (!r.ok) { fail(r.why); log('info', `${unit.key}: skipped ${s.service ? `[${s.service}] ` : ''}${s.filename || s.url.slice(0, 80)}: ${r.why}`); continue; }
    if (!plausible(s, r.size)) { fail(`file is ${fmtBytes(r.size)}, not the ${fmtBytes(s.exactSize || s.size)} listed (an error clip?)`); continue; }
    pins.push({ ...base, size: r.size, link: r.url, linkAt: Date.now() });
    if (episode && s.packKey) packs[packSlot(s.pack, b)] = { key: s.packKey, folder: s.folder, pack: s.pack, at: Date.now() };
  }
  // Highest resolution first so Plex lists it first.
  pins.sort((a, b) => b.bucket - a.bucket);
  const tries = [...reasons.values()].reduce((a, b) => a + b, 0);
  const summary = [...reasons].map(([w, n]) => (n > 1 ? `${n}× ${w}` : w)).join('; ');
  return { pins, why: pins.length ? '' : (summary ? `${tries} result${tries === 1 ? '' : 's'} tried: ${summary}` : 'no playable result') };
}

// ── Queue ──────────────────────────────────────────────────────────────
const pending = new Map(); // key → { unit, prio, seq }
const running = new Set();
let seq = 0;
const recent = []; // last outcomes for the admin page
function note(o) { recent.unshift({ at: Date.now(), ...o }); if (recent.length > 40) recent.pop(); }

function priorityOf(unit) {
  const t = unit.title;
  if (library.isFresh(unit)) return -0.5; // a just-aired episode goes ahead of any backlog
  const base = (t.sources.manual || t.sources.watchlist) ? 0 : t.kind === 'movie' ? 1 : 2;
  // The first episode of every season goes first: it finds and checks the season's
  // pack, so the rest of the season can then be pinned without debrid checks.
  // Episode order interleaves shows, so every show gets its first episodes early.
  const scout = settings.preferPacks && unit.s !== null && unit.s !== undefined && !unit.first ? 1e5 : 0;
  return base * 1e6 + scout + unit.order;
}

function enqueue(unit, force = false) {
  if (running.has(unit.key)) return;
  if (!force && pending.has(unit.key)) return;
  pending.set(unit.key, { unit, prio: force ? -1 : priorityOf(unit), seq: seq++, force });
  pump();
}

/** Queue every unit that has no pin (and isn't waiting out a recent miss). `all` re-checks pinned units too. */
function fill({ all = false } = {}) {
  const st = library.state();
  const retryMs = settings.retryMissingHours * 3600_000;
  const freshRetryMs = settings.freshRetryMin * 60_000; // new episodes: releases appear hours after the air date
  let n = 0;
  for (const t of Object.values(st.titles)) {
    for (const u of library.unitsOf(t)) {
      if (st.pins[u.key] && !all) continue;
      const miss = st.misses[u.key];
      if (miss && !all && Date.now() - miss.at < (library.isFresh(u) ? freshRetryMs : retryMs)) continue;
      if (!pending.has(u.key) && !running.has(u.key)) { enqueue(u); n++; }
    }
  }
  if (n) log('info', `resolver: ${n} files queued (${pending.size} waiting)`);
  return n;
}

function pump() {
  while (running.size < Math.max(1, settings.resolveConcurrency) && pending.size && aio.configured()) {
    let best = null;
    for (const e of pending.values()) if (!best || e.prio < best.prio || (e.prio === best.prio && e.seq < best.seq)) best = e;
    pending.delete(best.unit.key);
    if (!library.state().titles[best.unit.title.id]) continue; // removed meanwhile
    running.add(best.unit.key);
    resolveUnit(best.unit, best.force)
      .then(({ pins, why }) => {
        if (pins.length) {
          library.setPins(best.unit.key, pins);
          note({ key: best.unit.key, name: best.unit.title.name, ok: true, what: pins.map((p) => `${p.label} ${fmtBytes(p.size)}${p.pack ? ` (${p.pack} pack${p.trusted ? ', no check needed' : ''})` : ''}`).join(', ') });
        } else {
          library.setMiss(best.unit.key, why);
          note({ key: best.unit.key, name: best.unit.title.name, ok: false, what: why });
          log('info', `resolver: nothing playable for ${best.unit.title.name} ${best.unit.key} (${why})`);
        }
      })
      .catch((e) => { library.setMiss(best.unit.key, e.message); note({ key: best.unit.key, name: best.unit.title.name, ok: false, what: e.message }); })
      .finally(() => { running.delete(best.unit.key); pump(); });
  }
}

// ── Links at read time ─────────────────────────────────────────────────
const checking = new Map();

/**
 * A working link for a pinned file, or null. Re-checks links older than
 * LINK_TTL_SEC; heals a dead link by finding the same release again.
 */
function link(unitKey, pin) {
  if (pin.link && Date.now() - pin.linkAt < settings.linkTtlSec * 1000) return Promise.resolve(pin.link);
  const k = `${unitKey}|${pin.url}`;
  if (checking.has(k)) return checking.get(k);
  const p = (async () => {
    let r = await probe(pin.url, pin.headers || {});
    if (r.ok && r.size === pin.size) { pin.link = r.url; pin.linkAt = Date.now(); return r.url; }
    log('warn', `link for ${unitKey} ${pin.label} failed (${r.ok ? `size changed to ${r.size}` : r.why}); looking for the same release`);
    const t = library.titleOfUnit(unitKey);
    if (!t) return null;
    const [s, e] = unitKey.slice(t.id.length + 1).split(':').map(Number);
    const unit = { key: unitKey, title: t, s: Number.isFinite(s) ? s : null, e: Number.isFinite(e) ? e : null, order: 0 };
    try {
      const list = await aio.streams(t.stype, unitKey, 'heal', { force: true });
      const same = list.filter((x) => (x.exactSize === pin.size) || (pin.filename && x.filename === pin.filename));
      for (const x of same.slice(0, 4)) {
        r = await probe(x.url, x.headers || {});
        if (r.ok && r.size === pin.size) {
          Object.assign(pin, { url: x.url, link: r.url, linkAt: Date.now(), headers: x.headers || null });
          library.changed([]); // pin was updated in place; persist it
          log('info', `link for ${unitKey} healed with the same release`);
          return r.url;
        }
      }
    } catch (err) { log('warn', `heal ${unitKey} failed: ${err.message}`); }
    // The release is gone: pick a new one. Plex rescans the title once it's pinned.
    log('warn', `release for ${unitKey} is gone; picking a new one`);
    if (pin.packKey) { // the pack is gone too: stop trusting its other files
      const packs = library.state().packs;
      for (const [k, v] of Object.entries(packs)) if (v.key === pin.packKey) delete packs[k];
    }
    delete library.state().pins[unitKey];
    library.markRemoved();
    library.changed(library.libKeysFor(t));
    enqueue(unit, true);
    return null;
  })().finally(() => checking.delete(k));
  checking.set(k, p);
  return p;
}

function stats() { return { pending: pending.size, running: [...running], recent: recent.slice(0, 25) }; }

library.onChange(() => setImmediate(pump));

module.exports = { fill, enqueue, link, probe, stats, resolveUnit };
