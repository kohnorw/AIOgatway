# AIOPlex

Turns your **AIOStreams** setup into a real **Plex** server: AIOStreams catalogs become Plex libraries, you can add any movie or show by searching (on the admin page or with your Plex Watchlist), and everything plays through AIOStreams and your debrid service. Any Plex app works, because it *is* Plex.

It's the Plex counterpart of AIOFin and reuses its AIOStreams client, caching and wrong-title checks.

## How it works

AIOPlex reads your catalogs, looks up streams by IMDb id, picks cached results, checks each one with a one-byte read (which gives the exact file size and the final debrid link), and serves the result as a read-only library. rclone mounts that library with FUSE, so Plex sees ordinary folders:

```
/docker/aioplex/mnt/popular-movies-movie-1a2b3c/Dune (2021) {imdb-tt1160419}/Dune (2021) - 4K.mkv
                                                                             Dune (2021) - 1080p.mkv
/docker/aioplex/mnt/added-shows/The Bear (2022) {imdb-tt14452776}/Season 01/The Bear (2022) - s01e01 - 1080p.mkv
```

The `{imdb-…}` hint makes Plex match every title correctly. When Plex reads a file, rclone is redirected straight to the AIOStreams/debrid link (or, in proxy mode, the video passes through AIOPlex). Plex does its own transcoding, subtitles, watch history and sharing. AIOPlex also manages Plex: libraries, scans, settings, your Watchlist and (for a new server) adoption. Admin page on port 8097.

There are two ways to run it:

- **With your existing Plex** (`docker-compose.yml`, below): one container holding AIOPlex and its FUSE mount, everything under `/docker/aioplex`. This is the same setup as AIOGateway.
- **With a new Plex server** (`docker/compose.yml`): AIOPlex plus the official Plex image with the mount built in, adopted to your account from the admin page. See [Bundled Plex server](#bundled-plex-server).

## Quick start (existing Plex)

Everything lives under `/docker/aioplex` on the host:

| Path | What |
|---|---|
| `/docker/aioplex/` | this project (the build context) |
| `/docker/aioplex/data/` | settings, admin accounts, library state |
| `/docker/aioplex/mnt/` | the library Plex reads (FUSE mount) |
| `/docker/aioplex/cache/` | rclone's read cache, up to `FUSE_CACHE_MAX_SIZE` (20 GB) |

1. Extract the project so this README is at `/docker/aioplex/README.md`.
2. Edit `/docker/aioplex/docker-compose.yml`: set `AIOSTREAMS_URL` (or paste it on the admin page later) and `PLEX_URL` to your Plex server's LAN address, e.g. `http://192.168.1.10:32400` (not `localhost`, which is the container itself). `PLEX_TOKEN` is optional; the one AIOGateway uses works.
3. Start it:

   ```sh
   cd /docker/aioplex && docker compose up -d --build
   ```

   In Portainer, create a stack from this compose file with `/docker/aioplex` as the build context. After a few seconds, `ls /docker/aioplex/mnt` on the host shows `added-movies` and `added-shows`.
4. Let Plex see the mount:
   - **Plex in Docker:** add `- /docker/aioplex/mnt:/docker/aioplex/mnt:rslave` to its volumes and recreate it. Skip this if Plex already has `/docker` (e.g. `- /docker:/docker:rslave`, the way it sees AIOGateway's `/docker/aiogateway/mnt`). `rslave` matters: without it Plex keeps seeing an empty folder after AIOPlex restarts.
   - **Plex installed directly on the host:** nothing to do.
   - If Plex sees the folder at a different path, set `MOUNT_PATH` to that path.
5. Open `http://<host>:8097/admin`, create the admin account and, unless you set `PLEX_TOKEN`, click **Sign in with Plex** with the account that owns the server.
6. Turn on catalogs on the Libraries page. AIOPlex creates the Plex libraries, pointing at `/docker/aioplex/mnt/…`, and starts filling them.

The container needs `/dev/fuse`, `CAP_SYS_ADMIN` and `apparmor:unconfined`, and `/docker/aioplex` is bind-mounted 1:1 with `:shared` so the mount made inside the container shows up on the host at the same path. If AIOPlex or the mount stops, the container unmounts and exits so Docker restarts it; a stale mount from a crash is cleaned up on start.

**Your Plex server's settings.** `PLEX_SHARED=true` (set in the compose file) means AIOPlex leaves your server's own settings, its name and your other libraries alone: it only creates, renames and removes libraries it made itself, and turns off thumbnails and intro/credit detection on those. The Overview page lists any server-wide setting worth changing:

- **Scheduled Tasks → "Perform extensive media analysis during maintenance"**: reads every file in full, which would download AIOPlex titles from your debrid service each night. Turn it off.
- **Library → "Empty trash automatically after every scan"**: if the mount is ever down during a scan, Plex drops AIOPlex titles. Turn it off, or keep the mount reliable.

**Running alongside AIOGateway.** They don't conflict: AIOGateway is on port 8001 with `/docker/aiogateway/mnt`, AIOPlex on 8097 with `/docker/aioplex/mnt`, and their Plex libraries are separate. If both serve the same catalog you'll get the same titles twice in Plex, so pick one per catalog, or use `LIBRARY_PREFIX` to tell them apart.

**Plex on another machine (or Windows/macOS):** run AIOPlex anywhere, and run the mount on the Plex machine with rclone itself (WinFsp on Windows, macFUSE on macOS):

```sh
rclone mount ":webdav,url='http://<aioplex-host>:8097/dav',vendor=other:" /mnt/aioplex \
  --read-only --allow-other --dir-cache-time 10s --vfs-cache-mode full --vfs-cache-max-size 20G
```

Set `MOUNT_PATH` to the path Plex uses there. If port 8097 is reachable by others, set `DAV_PASSWORD` and add `--webdav-user aioplex --webdav-pass $(rclone obscure '<password>')`.

### FUSE settings

| Variable | Default | What it does |
|---|---|---|
| `FUSE_MOUNTPOINT` | `/docker/aioplex/mnt` | Where the library is mounted (keep it inside the bind mount) |
| `FUSE_CACHE_DIR` | `/docker/aioplex/cache` | rclone's read cache |
| `FUSE_CACHE_MODE` | `full` | `full` caches what Plex reads on disk; `off` uses no disk |
| `FUSE_CACHE_MAX_SIZE` / `FUSE_CACHE_MAX_AGE` | `20G` / `6h` | Cache limits |
| `FUSE_READ_CHUNK` | `32M` | First range request size (doubles as playback continues) |
| `FUSE_READ_AHEAD` | `128M` | How far ahead of the player to read (full cache mode) |
| `FUSE_BUFFER` | `32M` | In-memory buffer per open file |
| `FUSE_LOG_LEVEL` | `NOTICE` | rclone log level (`INFO`/`DEBUG` to troubleshoot) |
| `RCLONE_EXTRA_ARGS` | | Extra `rclone mount` flags |

## Bundled Plex server

If you'd rather have a new Plex server just for this:

1. Edit `docker/compose.yml`: set `ADVERTISE_IP` to your server's LAN address (e.g. `http://192.168.1.10:32400/`) and `TZ`. Optionally set `AIOSTREAMS_URL`.
2. Start it: `docker compose -f docker/compose.yml up -d --build`
3. Open `http://<server>:8097/admin`, create the admin account and paste your AIOStreams install link.
4. **Adopt the server:** on the Overview page, click **Sign in with Plex**; AIOPlex claims the server for your account. (Or paste a token from <https://plex.tv/claim> under "Or use a claim token", or set `PLEX_CLAIM` before the first start.)
5. Turn on catalogs on the Libraries page.

Here the mount lives inside the Plex container at `/media/aioplex`, and AIOPlex sets the Plex settings itself.

To build all images for another machine, run `./build-image.sh` (load the result with `docker load -i aioplex-images.tar.gz`).

## Searching for movies and shows

- **Admin page → Search & add.** Searches your AIOStreams catalogs and Cinemeta (or paste an IMDb id). **Add to Plex** puts the title in the **Added Movies** or **Added Shows** library.
- **From any Plex app.** Search, open the title from Plex's *Movies & Shows* results, and add it to your **Watchlist**. AIOPlex checks your Watchlist every minute and adds it to Added Movies / Added Shows. Removing it from the Watchlist keeps it unless `WATCHLIST_REMOVE=true`.

Titles you add get every season; catalog shows can be limited (`CATALOG_SHOW_SEASONS`).

## Season and series packs

For episodes, AIOPlex prefers packs (`PREFER_PACKS`, on by default). AIOStreams answers per episode (that's how the Stremio protocol works), so there's still one lookup per episode; packs make everything after it quicker and more consistent:

1. **Each season's first episode is looked up first.** Among results at the resolution AIOStreams ranks highest, a complete-series pack beats a season pack, which beats a single episode. The chosen pack is checked once and remembered.
2. **The rest of the season** then takes its file from that same pack, without another debrid check (AIOStreams gives the exact file size); the link is fetched the first time Plex reads the file. One torrent on your debrid service per season (or show), every episode the same release.
3. If a pack disappears from your debrid service, AIOPlex forgets it and picks a new release for the affected episodes.

Packs are recognised from the torrent folder name (`Show.S02.1080p…` = season, `Complete Series` / `S01-S05` = series), taken from AIOStreams' `streamData`, `behaviorHints`, or a 📁 line in the result description (most AIOStreams formatters show it). If your formatter hides the folder name and AIOStreams doesn't send it, results are treated as single episodes.

## Separate 4K libraries

Turn on **Separate 4K libraries** in Settings (or `SPLIT_4K=true`) and every 4K version goes into two extra libraries, **Movies 4K** and **Series 4K**, collected from all your catalog libraries and everything you've added. All other libraries then hold no 4K at all.

- Each movie and episode gets its best 4K release (for the 4K libraries) plus `MOVIE_VERSIONS` / `EPISODE_VERSIONS` non-4K releases (for the others), so an episode has one 4K and one 1080p file by default.
- A title whose only cached release is 4K appears only in the 4K libraries.
- Typical uses: share only the regular libraries with people whose devices or connections can't handle 4K, or keep Plex from transcoding 4K down for them.
- Turning it on or off re-picks versions for everything. Stream lists come from cache and files that stay the same aren't touched, so Plex only rescans what changed. Turning it off removes the two 4K libraries from Plex, along with any watch history recorded in them.
- Rename them with `MOVIES_4K_NAME` / `SERIES_4K_NAME` (e.g. `Movies4K`, `Series4K`).
- `MAX_RESOLUTION` below 2160 leaves the 4K libraries empty.

## New episodes

- **Airing shows are watched closely.** Every 30 minutes (`AIRING_CHECK_MIN`), shows with an episode in the last two weeks or the next eight days have their episode list re-read, skipping the metadata cache. A new episode is noticed within that time of its air date. Other shows are refreshed with the catalogs every `CATALOG_REFRESH_MIN`.
- **New episodes go first.** For `FRESH_EPISODE_HOURS` (48) after airing, an episode jumps ahead of everything else waiting for a stream.
- **Quick retries.** Releases often appear hours after the air date. Until one is cached, a new episode is retried every `FRESH_RETRY_MIN` (30) with a fresh AIOStreams lookup, instead of waiting `RETRY_MISSING_HOURS`.
- Once a stream is pinned, Plex rescans about 20 seconds later; the episode shows up in Recently Added and On Deck. So expect a new episode within about an hour of a cached release existing.
- **Check for new episodes now** on the Overview page runs the airing check immediately.
- `CATALOG_SHOW_SEASONS` keeps the *latest* N seasons of catalog shows, so they move on to new seasons; the oldest season leaves Plex when a new one starts. Shows you add yourself always get every season.
- A show that is only in a catalog leaves when it drops out of that catalog, even mid-season. Add shows you follow via Search or your Watchlist to keep them.

## Things worth knowing

- **One lookup per episode.** Each movie and each aired episode is one AIOStreams lookup, done in the background (`RESOLVE_CONCURRENCY` at a time). A big TV catalog takes a while to fill the first time. `CATALOG_LIMIT` and `CATALOG_SHOW_SEASONS` keep it in check.
- **Cached results only (default).** Plex reads the start of each file when it scans it. An uncached result would make your debrid service download the torrent, so `ONLY_CACHED=true` is strongly recommended.
- **Plex features that read whole files are switched off** after adoption (`CONFIGURE_PLEX`): video preview thumbnails, chapter thumbnails, intro/credit/ad detection, loudness analysis, voice activity detection and "extensive media analysis". Scheduled and automatic library scans are off too, as is "empty trash automatically", so a hiccup in the mount can never empty a library; AIOPlex triggers scans itself. Don't turn these back on in Plex.
- **Versions.** Movies get up to `MOVIE_VERSIONS` files (one per resolution, in AIOStreams' order), shown under Plex's *Play Version*. Episodes get `EPISODE_VERSIONS` (1 by default).
- **Dead links heal themselves.** A file's debrid link is re-checked after `LINK_TTL_SEC`. If it fails, AIOPlex looks for the same release again; if that's gone, it pins a new result and Plex rescans the title. Playback that hits a dead link fails once; trying again a minute later works.
- **Titles leave** when they drop out of a catalog (and aren't added by you), and the Plex library's trash is emptied for them.
- **The Plex container needs FUSE:** `/dev/fuse`, `CAP_SYS_ADMIN` and `apparmor:unconfined` (all in the compose file). Linux hosts are the supported setup.
- **Disk:** rclone caches what Plex reads in `docker/plex/transcode/aioplex-rclone-cache` (up to `AIOPLEX_VFS_CACHE_MAX_SIZE`, 20 GB by default).

## Settings

Everything on the admin page's Settings page overrides the environment; environment variables set the defaults.

| Variable | Default | What it does |
|---|---|---|
| `AIOSTREAMS_URL` | | Your AIOStreams manifest URL |
| `CATALOGS` | | Catalogs to turn on at first start: `all`, or `type/id` pairs, comma-separated |
| `ADMIN_USERNAME`, `ADMIN_PASSWORD` | | Create the admin on first start (otherwise use `/admin`) |
| `SERVER_NAME` | `AIOPlex` | Plex server name |
| `PLEX_URL` | `http://plex:32400` | How AIOPlex reaches Plex |
| `PLEX_TOKEN` | | Optional; otherwise taken from "Sign in with Plex" or Plex's `Preferences.xml` |
| `MOUNT_PATH` | `/docker/aioplex/mnt` (`/media/aioplex` in the bundled setup) | The library path as Plex sees it |
| `LIBRARY_PREFIX` | | Text in front of every library name |
| `MANAGE_LIBRARIES` | `true` | Create/rename/remove Plex libraries |
| `CONFIGURE_PLEX` | `true` | Switch off Plex features that read whole files |
| `PLEX_SHARED` | `false` (`true` in `docker-compose.yml`) | Your own existing server: leave server-wide settings and the name alone |
| `CATALOG_LIMIT` | `60` | Titles per catalog library |
| `CATALOG_REFRESH_MIN` | `360` | Re-read catalogs this often |
| `CATALOG_SHOW_SEASONS` | `0` | 0 = all seasons; N = latest N seasons of catalog shows |
| `AIRING_CHECK_MIN` | `30` | Re-read episode lists of airing shows this often |
| `FRESH_EPISODE_HOURS` | `48` | How long after airing an episode counts as new (priority, quick retries) |
| `FRESH_RETRY_MIN` | `30` | Retry new episodes without a cached release this often |
| `INCLUDE_SPECIALS` | `false` | Include season 0 |
| `WATCHLIST` | `true` | Add titles from your Plex Watchlist |
| `WATCHLIST_POLL_SEC` | `60` | How often the Watchlist is checked |
| `WATCHLIST_REMOVE` | `false` | Remove titles taken off the Watchlist |
| `MOVIE_VERSIONS` / `EPISODE_VERSIONS` | `2` / `1` | Versions per title (non-4K versions when `SPLIT_4K` is on) |
| `PREFER_PACKS` | `true` | Episodes: series packs, then season packs, then single episodes |
| `SPLIT_4K` | `false` | Put 4K versions in separate Movies 4K / Series 4K libraries |
| `MOVIES_4K_NAME` / `SERIES_4K_NAME` | `Movies 4K` / `Series 4K` | Names of those libraries |
| `ONLY_CACHED` | `true` | Only pick results your debrid service has cached |
| `MAX_RESOLUTION` | `2160` | Ignore results above this |
| `CHECK_MATCHES` | `true` | Drop results for a different show, episode or year |
| `STREAM_MODE` | `redirect` | `redirect` or `proxy` |
| `RESOLVE_CONCURRENCY` | `3` | AIOStreams lookups at once while filling libraries |
| `RETRY_MISSING_HOURS` | `12` | Retry titles that had no usable stream |
| `LINK_TTL_SEC` | `3600` | Re-check a file's link after this long |
| `META_FALLBACK_URL` | Cinemeta | Metadata/search when AIOStreams has none |
| `DAV_USER`, `DAV_PASSWORD` | `aioplex`, empty | Protect `/dav` (set `AIOPLEX_DAV_PASSWORD` on the Plex container to match) |
| `PORT` | `8097` | HTTP port |

Plex container (on top of the usual `pms-docker` variables such as `PLEX_CLAIM`, `ADVERTISE_IP`, `TZ`, `PLEX_UID`/`PLEX_GID`):

| Variable | Default | What it does |
|---|---|---|
| `AIOPLEX_DAV_URL` | `http://aioplex:8097/dav` | Where the library is |
| `AIOPLEX_MOUNT` | `/media/aioplex` | Mount point |
| `AIOPLEX_DAV_USER` / `AIOPLEX_DAV_PASSWORD` | | WebDAV credentials, if set on AIOPlex |
| `AIOPLEX_VFS_CACHE_MODE` | `full` | rclone cache mode (`off` uses no disk) |
| `AIOPLEX_VFS_CACHE_MAX_SIZE` / `_MAX_AGE` | `20G` / `6h` | rclone cache limits |
| `AIOPLEX_RCLONE_ARGS` | | Extra `rclone mount` flags |

## Troubleshooting

- **The Overview says it can't reach Plex.** Plex takes a minute to start the first time. Check `docker logs plex`.
- **Adopting fails.** Try a claim token from <https://plex.tv/claim> (it expires after 4 minutes), or open `http://<server>:32400/web` from a computer on the same network and claim it there.
- **Libraries are empty in Plex.** Check the mount on the host: `ls /docker/aioplex/mnt` should list one folder per library (bundled setup: `docker exec plex ls /media/aioplex`). If it's empty on the host but not in `docker exec aioplex ls /docker/aioplex/mnt`, mount propagation isn't working: the volume needs `:shared`, and on some hosts `/docker` must be on a shared mount (`sudo mount --make-rshared /`). If Plex runs in Docker, its volume needs `:rslave`. `docker logs aioplex` shows the mount's messages; `fuse: device not found` or `permission denied` means the FUSE lines in the compose file are missing or the host blocks them. Then click **Rescan libraries** on the Overview page.
- **Apps can't connect, or only via "Indirect".** Set `ADVERTISE_IP` to your LAN address. For access away from home, forward port 32400 and turn on Remote Access in Plex.
- **A title never appears.** The Overview's activity list shows why, per result tried (e.g. "5 results, none cached", or the error message a debrid service returned). It's retried after `RETRY_MISSING_HOURS`, or click **Retry … now**.
- **"can't seek (sends the whole file, ignoring ranges)".** That result's server won't serve part of a file, which Plex needs to start and seek, so AIOPlex skips it and tries the next one (up to 4 per resolution). If a whole service does this, the host name in the message tells you which; turn it off for AIOPlex in AIOStreams, or check its proxy settings (some proxies drop range requests).
- **Logs:** `docker logs aioplex --tail 200`; add `LOG_LEVEL: "debug"` for more.

## Development

```sh
node test/mock.js                 # fake AIOStreams on :7001 and fake Plex on :7002
DATA_DIR=./data PLEX_URL=http://127.0.0.1:7002 PLEX_TOKEN=tok \
  AIOSTREAMS_URL=http://127.0.0.1:7001/stremio/u/c/manifest.json CATALOGS=all node src/index.js
node test/e2e.js                  # 69 end-to-end checks (set RCLONE=/path/to/rclone to include rclone)
```

Layout: `src/aio.js` (AIOStreams client), `src/library.js` (titles, sources, episodes, folder tree), `src/resolver.js` (picking and checking streams, healing links), `src/dav.js` (WebDAV), `src/plex.js` (plex.tv sign-in, adoption, libraries, scans, Watchlist), `src/routes/admin.js` (admin API), `admin/` (admin page), `docker/` (images, mount service, compose).

## License

AGPL-3.0, like AIOFin and Remux, which it derives from.
