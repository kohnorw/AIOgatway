# AIOPlex

Turns your **AIOStreams** setup into a real **Plex** server: AIOStreams catalogs become Plex libraries, you can add any movie or show by searching (on the admin page or with your Plex Watchlist), and everything plays through AIOStreams and your debrid service. Any Plex app works, because it *is* Plex.

It's the Plex counterpart of AIOFin and reuses its AIOStreams client, caching and wrong-title checks.

## How it works

Two containers:

- **`aioplex`** reads your catalogs, looks up streams by IMDb id, picks cached results, checks each one with a one-byte read (which gives the exact file size and the final debrid link), and serves the result as a read-only WebDAV library. It also manages Plex: adoption, libraries, scans, settings and your Watchlist. Admin page on port 8097.
- **`plex`** is the official `plexinc/pms-docker` image plus rclone. An extra startup service mounts the AIOPlex library at `/media/aioplex` with FUSE, so Plex sees ordinary folders:

```
/media/aioplex/popular-movies-movie-1a2b3c/Dune (2021) {imdb-tt1160419}/Dune (2021) - 4K.mkv
                                                                        Dune (2021) - 1080p.mkv
/media/aioplex/added-shows/The Bear (2022) {imdb-tt14452776}/Season 01/The Bear (2022) - s01e01 - 1080p.mkv
```

The `{imdb-…}` hint makes Plex match every title correctly. When Plex reads a file, rclone is redirected straight to the AIOStreams/debrid link (or, in proxy mode, the video passes through AIOPlex). Plex does its own transcoding, subtitles (including OpenSubtitles search), watch history and sharing.

## Quick start

1. Edit `docker/compose.yml`: set `ADVERTISE_IP` to your server's LAN address (e.g. `http://192.168.1.10:32400/`) and `TZ`. Optionally set `AIOSTREAMS_URL`.
2. Start it:

   ```sh
   docker compose -f docker/compose.yml up -d --build
   ```

3. Open `http://<server>:8097/admin`, create the admin account and paste your AIOStreams install link (the `…/manifest.json` URL).
4. **Adopt the server:** on the Overview page, click **Sign in with Plex**, sign in in the window that opens, and AIOPlex claims the server for your account. (Alternatives: paste a token from <https://plex.tv/claim> under "Or use a claim token", or set `PLEX_CLAIM` in the compose file before the first start.)
5. **Pick libraries:** on the Libraries page, turn on the catalogs you want and save. AIOPlex creates the Plex libraries and starts finding streams; titles appear in Plex as soon as one is ready. The Overview page shows progress per library.
6. Open Plex (<https://app.plex.tv> or any Plex app). The server is under your account.

To build images for another machine, run `./build-image.sh` (produces `aioplex-images.tar.gz`; load it with `docker load -i aioplex-images.tar.gz`).

## Searching for movies and shows

- **Admin page → Search & add.** Searches your AIOStreams catalogs and Cinemeta (or paste an IMDb id). **Add to Plex** puts the title in the **Added Movies** or **Added Shows** library.
- **From any Plex app.** Search, open the title from Plex's *Movies & Shows* results, and add it to your **Watchlist**. AIOPlex checks your Watchlist every minute and adds it to Added Movies / Added Shows. Removing it from the Watchlist keeps it unless `WATCHLIST_REMOVE=true`.

Titles you add get every season; catalog shows can be limited (`CATALOG_SHOW_SEASONS`).

## Season and series packs

For episodes, AIOPlex prefers packs (`PREFER_PACKS`, on by default). AIOStreams answers per episode (that's how the Stremio protocol works), so there's still one lookup per episode; packs make everything after it quicker and more consistent:

1. **Each season's first episode is looked up first.** Among results at the resolution AIOStreams ranks highest, a complete-series pack beats a season pack, which beats a single episode. The chosen pack is checked once and remembered.
2. **The rest of the season** then takes its file from that same pack, without another debrid check (AIOStreams gives the exact file size); the link is fetched the first time Plex reads the file. One torrent on your debrid service per season (or show), every episode the same release.
3. If a pack disappears from your debrid service, AIOPlex forgets it and picks a new release for the affected episodes.

Packs are recognised from the torrent folder name (`Show.S02.1080p…` = season, `Complete Series` / `S01-S05` = series), taken from AIOStreams' `streamData`, `behaviorHints`, or a 📁 line in the result description (most AIOStreams formatters show it). If your formatter hides the folder name and AIOStreams doesn't send it, results are treated as single episodes.

## Separate 4K libraries

Turn on **Separate 4K libraries** in Settings (or `SPLIT_4K=true`) and every 4K version goes into two extra libraries, **Movies 4K** and **Series 4K**, collected from all your catalog libraries and everything you've added. All other libraries then hold no 4K at all.

- Each movie and episode gets its best 4K release (for the 4K libraries) plus `MOVIE_VERSIONS` / `EPISODE_VERSIONS` non-4K releases (for the others), so an episode has one 4K and one 1080p file by default.
- A title whose only cached release is 4K appears only in the 4K libraries.
- Typical uses: share only the regular libraries with people whose devices or connections can't handle 4K, or keep Plex from transcoding 4K down for them.
- Turning it on or off re-picks versions for everything. Stream lists come from cache and files that stay the same aren't touched, so Plex only rescans what changed. Turning it off removes the two 4K libraries from Plex, along with any watch history recorded in them.
- Rename them with `MOVIES_4K_NAME` / `SERIES_4K_NAME` (e.g. `Movies4K`, `Series4K`).
- `MAX_RESOLUTION` below 2160 leaves the 4K libraries empty.

## New episodes

- **Airing shows are watched closely.** Every 30 minutes (`AIRING_CHECK_MIN`), shows with an episode in the last two weeks or the next eight days have their episode list re-read, skipping the metadata cache. A new episode is noticed within that time of its air date. Other shows are refreshed with the catalogs every `CATALOG_REFRESH_MIN`.
- **New episodes go first.** For `FRESH_EPISODE_HOURS` (48) after airing, an episode jumps ahead of everything else waiting for a stream.
- **Quick retries.** Releases often appear hours after the air date. Until one is cached, a new episode is retried every `FRESH_RETRY_MIN` (30) with a fresh AIOStreams lookup, instead of waiting `RETRY_MISSING_HOURS`.
- Once a stream is pinned, Plex rescans about 20 seconds later; the episode shows up in Recently Added and On Deck. So expect a new episode within about an hour of a cached release existing.
- **Check for new episodes now** on the Overview page runs the airing check immediately.
- `CATALOG_SHOW_SEASONS` keeps the *latest* N seasons of catalog shows, so they move on to new seasons; the oldest season leaves Plex when a new one starts. Shows you add yourself always get every season.
- A show that is only in a catalog leaves when it drops out of that catalog, even mid-season. Add shows you follow via Search or your Watchlist to keep them.

## Things worth knowing

- **One lookup per episode.** Each movie and each aired episode is one AIOStreams lookup, done in the background (`RESOLVE_CONCURRENCY` at a time). A big TV catalog takes a while to fill the first time. `CATALOG_LIMIT` and `CATALOG_SHOW_SEASONS` keep it in check.
- **Cached results only (default).** Plex reads the start of each file when it scans it. An uncached result would make your debrid service download the torrent, so `ONLY_CACHED=true` is strongly recommended.
- **Plex features that read whole files are switched off** after adoption (`CONFIGURE_PLEX`): video preview thumbnails, chapter thumbnails, intro/credit/ad detection, loudness analysis, voice activity detection and "extensive media analysis". Scheduled and automatic library scans are off too, as is "empty trash automatically", so a hiccup in the mount can never empty a library; AIOPlex triggers scans itself. Don't turn these back on in Plex.
- **Versions.** Movies get up to `MOVIE_VERSIONS` files (one per resolution, in AIOStreams' order), shown under Plex's *Play Version*. Episodes get `EPISODE_VERSIONS` (1 by default).
- **Dead links heal themselves.** A file's debrid link is re-checked after `LINK_TTL_SEC`. If it fails, AIOPlex looks for the same release again; if that's gone, it pins a new result and Plex rescans the title. Playback that hits a dead link fails once; trying again a minute later works.
- **Titles leave** when they drop out of a catalog (and aren't added by you), and the Plex library's trash is emptied for them.
- **The Plex container needs FUSE:** `/dev/fuse`, `CAP_SYS_ADMIN` and `apparmor:unconfined` (all in the compose file). Linux hosts are the supported setup.
- **Disk:** rclone caches what Plex reads in `docker/plex/transcode/aioplex-rclone-cache` (up to `AIOPLEX_VFS_CACHE_MAX_SIZE`, 20 GB by default).

## Settings

Everything on the admin page's Settings page overrides the environment; environment variables set the defaults.

| Variable | Default | What it does |
|---|---|---|
| `AIOSTREAMS_URL` | | Your AIOStreams manifest URL |
| `CATALOGS` | | Catalogs to turn on at first start: `all`, or `type/id` pairs, comma-separated |
| `ADMIN_USERNAME`, `ADMIN_PASSWORD` | | Create the admin on first start (otherwise use `/admin`) |
| `SERVER_NAME` | `AIOPlex` | Plex server name |
| `PLEX_URL` | `http://plex:32400` | How AIOPlex reaches Plex |
| `PLEX_TOKEN` | | Optional; otherwise taken from "Sign in with Plex" or Plex's `Preferences.xml` |
| `MOUNT_PATH` | `/media/aioplex` | Library path inside the Plex container (must match `AIOPLEX_MOUNT`) |
| `LIBRARY_PREFIX` | | Text in front of every library name |
| `MANAGE_LIBRARIES` | `true` | Create/rename/remove Plex libraries |
| `CONFIGURE_PLEX` | `true` | Switch off Plex features that read whole files |
| `CATALOG_LIMIT` | `60` | Titles per catalog library |
| `CATALOG_REFRESH_MIN` | `360` | Re-read catalogs this often |
| `CATALOG_SHOW_SEASONS` | `0` | 0 = all seasons; N = latest N seasons of catalog shows |
| `AIRING_CHECK_MIN` | `30` | Re-read episode lists of airing shows this often |
| `FRESH_EPISODE_HOURS` | `48` | How long after airing an episode counts as new (priority, quick retries) |
| `FRESH_RETRY_MIN` | `30` | Retry new episodes without a cached release this often |
| `INCLUDE_SPECIALS` | `false` | Include season 0 |
| `WATCHLIST` | `true` | Add titles from your Plex Watchlist |
| `WATCHLIST_POLL_SEC` | `60` | How often the Watchlist is checked |
| `WATCHLIST_REMOVE` | `false` | Remove titles taken off the Watchlist |
| `MOVIE_VERSIONS` / `EPISODE_VERSIONS` | `2` / `1` | Versions per title (non-4K versions when `SPLIT_4K` is on) |
| `PREFER_PACKS` | `true` | Episodes: series packs, then season packs, then single episodes |
| `SPLIT_4K` | `false` | Put 4K versions in separate Movies 4K / Series 4K libraries |
| `MOVIES_4K_NAME` / `SERIES_4K_NAME` | `Movies 4K` / `Series 4K` | Names of those libraries |
| `ONLY_CACHED` | `true` | Only pick results your debrid service has cached |
| `MAX_RESOLUTION` | `2160` | Ignore results above this |
| `CHECK_MATCHES` | `true` | Drop results for a different show, episode or year |
| `STREAM_MODE` | `redirect` | `redirect` or `proxy` |
| `RESOLVE_CONCURRENCY` | `3` | AIOStreams lookups at once while filling libraries |
| `RETRY_MISSING_HOURS` | `12` | Retry titles that had no usable stream |
| `LINK_TTL_SEC` | `3600` | Re-check a file's link after this long |
| `META_FALLBACK_URL` | Cinemeta | Metadata/search when AIOStreams has none |
| `DAV_USER`, `DAV_PASSWORD` | `aioplex`, empty | Protect `/dav` (set `AIOPLEX_DAV_PASSWORD` on the Plex container to match) |
| `PORT` | `8097` | HTTP port |

Plex container (on top of the usual `pms-docker` variables such as `PLEX_CLAIM`, `ADVERTISE_IP`, `TZ`, `PLEX_UID`/`PLEX_GID`):

| Variable | Default | What it does |
|---|---|---|
| `AIOPLEX_DAV_URL` | `http://aioplex:8097/dav` | Where the library is |
| `AIOPLEX_MOUNT` | `/media/aioplex` | Mount point |
| `AIOPLEX_DAV_USER` / `AIOPLEX_DAV_PASSWORD` | | WebDAV credentials, if set on AIOPlex |
| `AIOPLEX_VFS_CACHE_MODE` | `full` | rclone cache mode (`off` uses no disk) |
| `AIOPLEX_VFS_CACHE_MAX_SIZE` / `_MAX_AGE` | `20G` / `6h` | rclone cache limits |
| `AIOPLEX_RCLONE_ARGS` | | Extra `rclone mount` flags |

## Troubleshooting

- **The Overview says it can't reach Plex.** Plex takes a minute to start the first time. Check `docker logs plex`.
- **Adopting fails.** Try a claim token from <https://plex.tv/claim> (it expires after 4 minutes), or open `http://<server>:32400/web` from a computer on the same network and claim it there.
- **Libraries are empty in Plex.** Check the mount: `docker exec plex ls /media/aioplex` should list one folder per library, and `docker logs plex | grep aioplex-mount` shows the mount's messages. If it says `fuse: device not found` or `permission denied`, the FUSE lines in the compose file are missing or your host blocks them. Then click **Rescan libraries** on the Overview page.
- **Apps can't connect, or only via "Indirect".** Set `ADVERTISE_IP` to your LAN address. For access away from home, forward port 32400 and turn on Remote Access in Plex.
- **A title never appears.** The Overview's activity list shows why (e.g. "5 results, none cached"). It's retried after `RETRY_MISSING_HOURS`, or click **Retry … now**.
- **Logs:** `docker logs aioplex --tail 200`; add `LOG_LEVEL: "debug"` for more.

## Development

```sh
node test/mock.js                 # fake AIOStreams on :7001 and fake Plex on :7002
DATA_DIR=./data PLEX_URL=http://127.0.0.1:7002 PLEX_TOKEN=tok \
  AIOSTREAMS_URL=http://127.0.0.1:7001/stremio/u/c/manifest.json CATALOGS=all node src/index.js
node test/e2e.js                  # 65 end-to-end checks (set RCLONE=/path/to/rclone to include rclone)
```

Layout: `src/aio.js` (AIOStreams client), `src/library.js` (titles, sources, episodes, folder tree), `src/resolver.js` (picking and checking streams, healing links), `src/dav.js` (WebDAV), `src/plex.js` (plex.tv sign-in, adoption, libraries, scans, Watchlist), `src/routes/admin.js` (admin API), `admin/` (admin page), `docker/` (images, mount service, compose).

## License

AGPL-3.0, like AIOFin and Remux, which it derives from.
