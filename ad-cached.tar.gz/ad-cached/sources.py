"""Indexer fanout.

Three kinds of source, all optional, all queried in parallel and merged:

1. Stremio torrent addons  — Torrentio, Comet, MediaFusion, Jackettio...
2. Prowlarr                — one URL, but fans out to every indexer behind it
3. Torznab endpoints       — Jackett, NZBHydra, alldebrid-web's own /torznab

Everything is normalised to:
    {info_hash, name, size, seeders, file_idx, file_name, source}

De-duplication is by info_hash, keeping the richest record, because the same
release shows up across most indexers and we only want to spend one AllDebrid
cache probe on it.
"""

import logging
import os
import re
import threading
import time
import urllib.parse
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

log = logging.getLogger("sources")

# Must match the name addon.py checks for on inbound requests.
LOOP_HEADER = "X-AD-Cached-Loop"

# Each source is one blocking HTTP call, so the pool only needs to be as wide
# as the number of sources you've configured.
_pool = ThreadPoolExecutor(
    max_workers=int(os.environ.get("SOURCE_WORKERS", "12")),
    thread_name_prefix="src",
)
SOURCE_TIMEOUT = int(os.environ.get("SOURCE_TIMEOUT", "15"))
GATHER_TIMEOUT = int(os.environ.get("GATHER_TIMEOUT", "25"))

CINEMETA = "https://v3-cinemeta.strem.io"
_meta_cache: dict[str, tuple[dict, float]] = {}
_meta_lock = threading.Lock()
_META_TTL = 6 * 3600

# Torrentio and friends reject requests that don't look like a browser, so
# every outbound call goes through a session carrying a real User-Agent.
UA = os.environ.get(
    "USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
)
HTTP = requests.Session()
HTTP.headers.update({
    "User-Agent": UA,
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9",
    # Loop marker. If an upstream eventually routes a request back to us, this
    # header arrives on our own /stream endpoint and we can refuse it.
    LOOP_HEADER: "1",
})

HASH_RE = re.compile(r"\b([a-fA-F0-9]{40})\b")
BTIH_RE = re.compile(r"urn:btih:([a-zA-Z0-9]{32,40})", re.I)
SIZE_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(TB|GB|MB)", re.I)
SEED_RE = re.compile(r"(?:👤|seeders?[:\s]+)\s*(\d+)", re.I)
NS = {"tz": "http://torznab.com/schemas/2015/feed"}


# ── Metadata ─────────────────────────────────────────────────────────────────
def get_meta(type_: str, imdb_id: str) -> dict:
    """IMDb id → {name, year} via Cinemeta. Torznab indexers need a title."""
    ck = f"{type_}:{imdb_id}"
    now = time.time()
    with _meta_lock:
        hit = _meta_cache.get(ck)
        if hit and now < hit[1]:
            return hit[0]
    meta = {}
    try:
        r = HTTP.get(f"{CINEMETA}/meta/{type_}/{imdb_id}.json", timeout=10)
        if r.ok:
            d = r.json().get("meta", {}) or {}
            meta = {"name": d.get("name", ""), "year": str(d.get("year", ""))[:4]}
    except Exception as e:
        log.warning(f"[meta] {imdb_id}: {e}")
    with _meta_lock:
        for k, (_, exp) in list(_meta_cache.items()):
            if now >= exp:
                del _meta_cache[k]
        _meta_cache[ck] = (meta, now + _META_TTL)
    return meta


def parse_size(text: str) -> int:
    m = SIZE_RE.search(text or "")
    if not m:
        return 0
    val, unit = float(m.group(1)), m.group(2).upper()
    return int(val * {"MB": 1024**2, "GB": 1024**3, "TB": 1024**4}[unit])


def parse_seeders(text: str) -> int:
    m = SEED_RE.search(text or "")
    return int(m.group(1)) if m else 0


def _hash_from(*values) -> str:
    for v in values:
        s = str(v or "")
        m = BTIH_RE.search(s) or HASH_RE.search(s)
        if m and len(m.group(1)) == 40:
            return m.group(1).lower()
    return ""


# ── 1. Stremio torrent addons ────────────────────────────────────────────────
def _base(url: str) -> str:
    u = url.strip().rstrip("/")
    if u.endswith("/manifest.json"):
        u = u[: -len("/manifest.json")]
    return u if u.startswith("http") else "https://" + u


def fetch_addon(url: str, type_: str, id_: str) -> list[dict]:
    base = _base(url)
    host = urllib.parse.urlparse(base).netloc or base
    try:
        r = HTTP.get(f"{base}/stream/{type_}/{urllib.parse.quote(id_)}.json",
                         timeout=SOURCE_TIMEOUT)
        if not r.ok:
            hint = ""
            if r.status_code in (403, 429):
                hint = (" — this addon is blocking us (common on VPS/datacenter "
                        "IPs). Try a different source or self-host one.")
            log.warning(f"[addon:{host}] HTTP {r.status_code}{hint}")
            return []
        streams = r.json().get("streams", []) or []
    except Exception as e:
        log.warning(f"[addon:{host}] {e}")
        return []

    out = []
    for s in streams:
        h = (s.get("infoHash") or "").lower()
        if len(h) != 40:
            h = _hash_from(s.get("url"), s.get("externalUrl"))
        if not h:
            continue  # already-resolved debrid link, nothing to cache-check
        title = s.get("title") or s.get("name") or ""
        bh = s.get("behaviorHints") or {}
        blob = f"{s.get('name','')}\n{title}"
        out.append({
            "info_hash": h,
            "name": (title.splitlines() or [""])[0].strip() or h,
            "size": int(bh.get("videoSize") or 0) or parse_size(blob),
            "seeders": parse_seeders(blob),
            "file_idx": s.get("fileIdx"),
            "file_name": bh.get("filename") or "",
            "source": host,
        })
    log.info(f"[addon:{host}] {len(out)} hash(es)")
    return out


# ── 2. Prowlarr (fans out to every indexer it manages) ───────────────────────
def fetch_prowlarr(url: str, key: str, query: str, categories: list,
                   limit: int = 100) -> list[dict]:
    try:
        r = HTTP.get(
            f"{url.rstrip('/')}/api/v1/search",
            params={"query": query, "indexerIds": -2, "categories": categories,
                    "type": "search", "limit": limit},
            headers={"X-Api-Key": key}, timeout=SOURCE_TIMEOUT + 10,
        )
        if not r.ok:
            log.warning(f"[prowlarr] HTTP {r.status_code}: {r.text[:160]}")
            return []
        items = r.json()
    except Exception as e:
        log.warning(f"[prowlarr] {e}")
        return []

    out = []
    for it in items:
        h = _hash_from(it.get("infoHash"), it.get("guid"), it.get("magnetUrl"),
                       it.get("downloadUrl"), it.get("title"))
        if not h:
            continue
        out.append({
            "info_hash": h,
            "name": it.get("title", h),
            "size": int(it.get("size") or 0),
            "seeders": int(it.get("seeders") or 0),
            "file_idx": None,
            "file_name": "",
            "source": it.get("indexer", "prowlarr"),
        })
    log.info(f"[prowlarr] {len(out)} hash(es) for '{query}'")
    return out


# ── 3. Raw torznab endpoints (Jackett et al.) ────────────────────────────────
def fetch_torznab(url: str, key: str, query: str, cat: str = "",
                  limit: int = 100) -> list[dict]:
    host = urllib.parse.urlparse(url).netloc or "torznab"
    params = {"t": "search", "q": query, "limit": limit}
    if key:
        params["apikey"] = key
    if cat:
        params["cat"] = cat
    try:
        r = HTTP.get(url, params=params, timeout=SOURCE_TIMEOUT + 10)
        if not r.ok:
            log.warning(f"[torznab:{host}] HTTP {r.status_code}")
            return []
        root = ET.fromstring(r.text)
    except Exception as e:
        log.warning(f"[torznab:{host}] {e}")
        return []

    out = []
    for item in root.iter("item"):
        title = (item.findtext("title") or "").strip()
        attrs = {a.get("name"): a.get("value") for a in item.findall("tz:attr", NS)}
        h = _hash_from(attrs.get("infohash"), attrs.get("magneturl"),
                       item.findtext("guid"), item.findtext("link"), title)
        if not h:
            continue
        try:
            size = int(item.findtext("size") or 0)
        except ValueError:
            size = 0
        try:
            seeders = int(attrs.get("seeders") or 0)
        except ValueError:
            seeders = 0
        out.append({
            "info_hash": h,
            "name": title,
            "size": size or parse_size(title),
            "seeders": seeders,
            "file_idx": None,
            "file_name": "",
            "source": host,
        })
    log.info(f"[torznab:{host}] {len(out)} hash(es) for '{query}'")
    return out


# ── Query building ───────────────────────────────────────────────────────────
def _queries(type_: str, imdb_id: str, season, episode) -> list[tuple[str, list, str]]:
    """Return (query, prowlarr_cats, torznab_cat) tuples for text indexers."""
    meta = get_meta(type_, imdb_id)
    title = (meta.get("name") or "").strip()
    if not title:
        return []
    if season is not None and episode is not None:
        # Both the single episode and the season pack — packs are far more
        # likely to already be cached on AllDebrid.
        return [
            (f"{title} S{season:02d}E{episode:02d}", [5000], "5000"),
            (f"{title} S{season:02d}", [5000], "5000"),
        ]
    year = meta.get("year", "")
    return [(f"{title} {year}".strip(), [2000], "2000")]


# ── Aggregate ────────────────────────────────────────────────────────────────
def gather(cfg: dict, type_: str, id_: str) -> list[dict]:
    parts = id_.split(":")
    imdb_id = parts[0]
    season = int(parts[1]) if len(parts) > 2 else None
    episode = int(parts[2]) if len(parts) > 2 else None

    jobs = []

    for url in cfg.get("addons", []):
        jobs.append(_pool.submit(fetch_addon, url, type_, id_))

    text_sources = bool(cfg.get("prowlarr_url") and cfg.get("prowlarr_key")) \
        or bool(cfg.get("torznab"))
    if text_sources:
        for q, pcats, tcat in _queries(type_, imdb_id, season, episode):
            if cfg.get("prowlarr_url") and cfg.get("prowlarr_key"):
                jobs.append(_pool.submit(fetch_prowlarr, cfg["prowlarr_url"],
                                         cfg["prowlarr_key"], q, pcats))
            for entry in cfg.get("torznab", []):
                url, _, key = entry.partition("|")
                jobs.append(_pool.submit(fetch_torznab, url, key, q, tcat))

    if not jobs:
        log.warning("[gather] no sources configured")
        return []

    results: list[dict] = []
    try:
        for f in as_completed(jobs, timeout=GATHER_TIMEOUT):
            try:
                results.extend(f.result() or [])
            except Exception as e:
                log.warning(f"[gather] source failed: {e}")
    except TimeoutError:
        # One slow indexer must not hold up the whole search — take what the
        # others returned and move on.
        done = sum(1 for f in jobs if f.done())
        log.warning(f"[gather] timed out with {done}/{len(jobs)} source(s) in")

    merged: dict[str, dict] = {}
    for t in results:
        h = t["info_hash"]
        prev = merged.get(h)
        if not prev:
            merged[h] = t
            continue
        # Prefer the record carrying a fileIdx/filename — it makes picking the
        # right file out of a pack at playback time far more reliable.
        if prev.get("file_idx") is None and t.get("file_idx") is not None:
            t["size"] = t.get("size") or prev.get("size") or 0
            t["seeders"] = max(prev.get("seeders", 0), t.get("seeders", 0))
            t["source"] = f"{prev['source']}+{t['source']}"
            merged[h] = t
        else:
            prev["size"] = prev.get("size") or t.get("size") or 0
            prev["seeders"] = max(prev.get("seeders", 0), t.get("seeders", 0))
            if t["source"] not in prev["source"]:
                prev["source"] = f"{prev['source']}+{t['source']}"

    log.info(f"[gather] {len(results)} result(s) from {len(jobs)} source(s) "
             f"→ {len(merged)} unique hash(es)")
    return list(merged.values())
