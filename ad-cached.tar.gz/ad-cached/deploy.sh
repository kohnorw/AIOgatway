#!/bin/sh
# One-shot deploy. Usage: ./deploy.sh <alldebrid_api_key>
set -e
KEY="${1:-$ALLDEBRID_API_KEY}"
[ -n "$KEY" ] || { echo "usage: ./deploy.sh <alldebrid_api_key>"; exit 1; }
echo "ALLDEBRID_API_KEY=$KEY" > .env
docker compose up -d --build
echo "waiting for health..."
for i in $(seq 1 30); do
  sleep 2
  if curl -fsS http://localhost:7000/health >/dev/null 2>&1; then
    curl -s http://localhost:7000/health
    echo
    echo "Add this as a custom addon in AIOStreams:"
    echo "  http://$(hostname -I 2>/dev/null | awk '{print $1}'):7000/manifest.json"
    exit 0
  fi
done
echo "did not come up — check: docker compose logs ad-cached"
exit 1
