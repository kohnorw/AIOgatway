#!/bin/sh
# One-shot deploy. Usage: ./deploy.sh <alldebrid_api_key>
set -e

KEY="${1:-$ALLDEBRID_API_KEY}"
[ -n "$KEY" ] || { echo "usage: ./deploy.sh <alldebrid_api_key>"; exit 1; }

# Compose v2 is a docker plugin ("docker compose"); v1 is a separate binary
# ("docker-compose"). Pick whichever is actually present.
if docker compose version >/dev/null 2>&1; then
  DC="docker compose"
elif command -v docker-compose >/dev/null 2>&1; then
  DC="docker-compose"
else
  echo "No docker compose found. Install the plugin:"
  echo "  sudo apt install docker-compose-plugin"
  exit 1
fi
echo "using: $DC"

echo "ALLDEBRID_API_KEY=$KEY" > .env
$DC up -d --build

echo "waiting for health..."
for i in $(seq 1 30); do
  sleep 2
  if curl -fsS http://localhost:7000/health >/dev/null 2>&1; then
    curl -s http://localhost:7000/health; echo
    IP=$(hostname -I 2>/dev/null | awk '{print $1}')
    echo "Add this as a custom addon in AIOStreams:"
    echo "  http://${IP:-localhost}:7000/manifest.json"
    exit 0
  fi
done
echo "did not come up — check: $DC logs ad-cached"
exit 1
