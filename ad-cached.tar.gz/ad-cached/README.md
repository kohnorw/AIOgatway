# AllDebrid Cached — drop-in for AIOStreams

A Stremio addon that holds your AllDebrid key, checks what AllDebrid *actually*
has cached, and hands AIOStreams only those streams as finished links.

## Install

```bash
tar -xzf ad-cached.tar.gz && cd ad-cached
./deploy.sh your_alldebrid_key
```

Or manually:

```bash
echo "ALLDEBRID_API_KEY=your_key" >> .env
docker compose up -d --build
```

In AIOStreams → **Addons** → **Add custom addon**:

```
http://<this-host>:7000/manifest.json
```

(or `http://ad-cached:7000/manifest.json` if you joined the AIOStreams network)

That's it. Streams show up labelled `[AD+]`.

## One rule

**Leave AllDebrid switched off under AIOStreams → Services.**

This addon already resolved the links. If AIOStreams also has AllDebrid
enabled it will try to re-resolve them, and you'll pay twice the API budget for
a worse result. The key lives here and only here.

## Why not just use the Services toggle

AllDebrid deprecated real-time instant-availability lookups — `magnet/instant`
no longer reflects true cache state. The only reliable signal today is the
`ready` flag on the `magnet/upload` response, so this addon uploads the magnet,
reads `ready`, and deletes the probe right after. Searching never pollutes your
AllDebrid library. Verdicts are reused for 5 minutes, and every call goes
through a 250/min sliding window with a 240 ms spacing floor.

## Defaults

Torrentio as the indexer, cached-only on, 20 streams per search. To add more
indexers or change behaviour, uncomment the block in `docker-compose.yml`:

| Variable | Default | |
|---|---|---|
| `ADDONS` | `https://torrentio.strem.fun` | Comma-separated Stremio torrent addons |
| `PROWLARR_URL` + `PROWLARR_API_KEY` | — | Fans out to every indexer Prowlarr manages |
| `TORZNAB` | — | `url\|apikey`, comma-separated (Jackett etc.) |
| `CACHED_ONLY` | `true` | `false` = uncached shown as `[AD download]` below cached |
| `MAX_RESULTS` | `20` | Streams returned |
| `PUBLIC_URL` | — | Set if reached by a name other than `ad-cached:7000` |
| `CACHE_CHECK_TTL` | `300` | Seconds a cache verdict is reused |

Don't point `ADDONS` at your AIOStreams URL — AIOStreams would call this addon,
which would call AIOStreams, forever. The addon logs an error at startup if it
spots that.

`GET /health` shows the install URL, whether the key validated at startup, and
the live cache size.
