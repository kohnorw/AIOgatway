# AllDebrid Cached — drop-in for AIOStreams

A Stremio addon that holds your AllDebrid key, checks what AllDebrid *actually*
has cached, and hands AIOStreams only those streams as finished links.

## Install

```bash
tar -xzf ad-cached.tar.gz && cd ad-cached
./deploy.sh your_alldebrid_key
```

Or manually:

```bash
echo "ALLDEBRID_API_KEY=your_key" > .env
docker compose up -d --build      # or: docker-compose up -d --build
```

In AIOStreams → **Addons** → **Add custom addon**:

```
http://<this-host>:7000/manifest.json
```

(or `http://ad-cached:7000/manifest.json` if you joined the AIOStreams network)

That's it. Streams show up labelled `[AD+]`.

## One rule

**Leave AllDebrid switched off under AIOStreams → Services.**

This addon already resolved the links. If AIOStreams also has AllDebrid
enabled it will try to re-resolve them, and you'll pay twice the API budget for
a worse result. The key lives here and only here.

## Why not just use the Services toggle

AllDebrid deprecated real-time instant-availability lookups — `magnet/instant`
no longer reflects true cache state. The only reliable signal today is the
`ready` flag on the `magnet/upload` response, so this addon uploads the magnet,
reads `ready`, and deletes the probe right after. Searching never pollutes your
AllDebrid library. Verdicts are reused for 5 minutes, and every call goes
through a 250/min sliding window with a 240 ms spacing floor.

## Defaults

Torrentio as the indexer, cached-only on, 20 streams per search. To add more
indexers or change behaviour, uncomment the block in `docker-compose.yml`:

| Variable | Default | |
|---|---|---|
| `ADDONS` | `https://torrentio.strem.fun` | Comma-separated Stremio torrent addons |
| `PROWLARR_URL` + `PROWLARR_API_KEY` | — | Fans out to every indexer Prowlarr manages |
| `TORZNAB` | — | `url\|apikey`, comma-separated (Jackett etc.) |
| `CACHED_ONLY` | `true` | `false` = uncached shown as `[AD download]` below cached |
| `MAX_RESULTS` | `20` | Streams returned |
| `PUBLIC_URL` | — | Set if reached by a name other than `ad-cached:7000` |
| `CACHE_CHECK_TTL` | `300` | Seconds a cache verdict is reused |

Don't point `ADDONS` at your AIOStreams URL — AIOStreams would call this addon,
which would call AIOStreams, forever. The addon logs an error at startup if it
spots that.

## Using your other AIOStreams addons as the source

Two configs on the same AIOStreams instance. They are separate addon lists, so
this is not a loop as long as you keep them straight:

**Config A — "sources".** Every torrent addon you want (Torrentio, Comet,
MediaFusion, Jackettio). Every debrid service **off**. This addon is **not**
in it. Copy its Stremio URL, drop the trailing `/manifest.json`, and set:

```yaml
      - ADDONS=http://aiostreams:3000/stremio/<config-A-uuid>/<password>
      - PUBLIC_URL=http://ad-cached:7000
```

**Config B — the one you install in Stremio.** One custom addon: this one, at
`http://ad-cached:7000/manifest.json`. Debrid **off**. Do all your sorting,
formatting and filtering here — it sees the cached streams this addon returns.

Two rules, and both failure modes are quiet if you break them:

- Config A must not list this addon. If it does, every search recurses. The
  addon detects this and logs a `[loop] refusing ...` error rather than hanging,
  but it returns nothing until you fix the config.
- Every debrid service must be off in both configs. A config that resolves
  streams itself returns finished HTTP links with no `infoHash`, leaving nothing
  to cache-check — you'd get an empty list with no obvious cause.

This also sidesteps Torrentio blocking your server, since AIOStreams does the
fetching.

## If it only plays on the second click

The cache check deletes its probe magnets, so clicking re-uploads from
scratch — and AllDebrid needs a moment to re-register the magnet before
`magnet/files` returns anything. That gap is long enough for some players
(Nuvio among them) to give up. The second click works only because the link
is in the resolve cache by then.

Two changes fix it. The top few cached results are now resolved in the
background as soon as a search returns, so the link is usually waiting before
you click; and the resolve poll starts at 250ms and backs off, instead of a
flat 2s sleep that was itself most of the delay.

```yaml
      - PREWARM_COUNT=3     # 0 disables
```

Each prewarm costs an upload plus an unlock against your rate budget, whether
or not you click. 3 is a reasonable default; raise it if you often pick from
further down the list, lower it if you're near your API limit.

Look for `[prewarm] <hash>: ready` after each search, and `[resolve] <hash> in
0.00s` on the click — that timing means it was served from the prewarm.

## MAGNET_TOO_MANY / library full

AllDebrid caps the library at 1000 magnets. At the ceiling every upload fails,
so nothing can be cache-checked and searches return zero streams.

### Library reports 0 but uploads still fail

AllDebrid splits magnets into tabs (active, ready, expired, error), and
`status=all` does not reliably cover every one of them — expired and errored
entries still count toward the 1000 cap while being invisible to a naive
listing. The addon now queries each bucket explicitly and merges by id.

To see the raw per-bucket counts:

```bash
curl -s localhost:7000/debug/magnets
```

If every bucket genuinely reports 0 and uploads are still refused, the
remaining magnets aren't reachable through the API at all — clear them from
the AllDebrid website's Magnets page, checking every tab.

Free space now:

```bash
curl localhost:7000/library            # how many magnets you have
curl -X POST localhost:7000/purge      # starts in the background
curl localhost:7000/purge              # progress + ETA, poll this
```

The purge runs on a worker thread and returns immediately, because deletes go
through the same ~250/min rate limit — a badly overfilled library takes tens of
minutes, which no HTTP client would wait for. Progress shows `removed`,
`total`, `rate_per_min` and `eta_seconds`; the log prints a line every 250.
Starting a second purge while one runs is refused rather than doubling up.

`/purge` removes magnets oldest first and never touches `KEEP_HASHES`. It
deletes **everything else in the library**, including transfers you added
yourself outside this addon — put those in `KEEP_HASHES` first if you have any.

With `AUTO_PURGE=true` (the default) the addon recovers on its own: the first
MAGNET_TOO_MANY in a process run triggers a purge of `PURGE_LIMIT` magnets and
retries the batch. It does this once per run, so a genuinely stuck account
doesn't turn into a delete loop.

### Batched deletes

`magnet/upload` takes 20 magnets per call but `magnet/delete` is documented
with a single `id`, so cleanup used to cost one API call per magnet against
the same 250/min budget — 3 calls to probe 60 hashes, 60 calls to clean them
up. The queue could never drain faster than it filled.

The addon now tries the `id[]` batch form once, latches the answer for the
process, and falls back to single deletes if AllDebrid rejects it. Where it
works, cleanup drops to one call per 20 magnets. Look for one of these at the
first delete:

```
[delete] batch deletes supported (20 per call)
[delete] batch form rejected (BAD_PARAM) — falling back to one call per magnet
```

If it's supported, a full purge takes minutes instead of tens of minutes, and
routine probe cleanup stops being the bottleneck.

### Why it filled up

Probe deletes are issued off the response path so searches stay fast, but they
go through the same rate limiter — a search probing 60 hashes queues 60
deletes that take roughly 15 seconds to drain. Restarting the container mid
drain loses them permanently, and the leftovers accumulate.

`GET /health` now reports `cache.pending_deletes`. If that number is routinely
large, the delete queue isn't keeping up with your search volume: lower
`PROBE_MULTIPLIER` or raise `CACHE_CHECK_TTL` so fewer hashes get probed.
Startup logs the library count, and warns above 800.

## What gets cleaned up

Two kinds of magnet end up in your AllDebrid library, and both are removed:

- **Cache-check probes** — uploaded only to read the `ready` flag, deleted
  immediately after, fire-and-forget so searches aren't held up.
- **Prewarms** — deliberately left in place, since the link has to still exist
  when you click. A background reaper deletes any that go unclicked for
  `PREWARM_TTL` seconds (default 10 minutes).

A click *claims* its magnet, removing it from the reaper's list before the
resolve runs, so nothing you are actually streaming can be deleted out from
under you. A magnet is also spared while any other live prewarm still points
at it, which happens when one release covers several episodes. Anything in
`KEEP_HASHES` is never touched.

```yaml
      - PREWARM_TTL=600
```

`GET /health` reports `prewarm.unclaimed`; `POST /reap` clears them now
instead of waiting for the timer. Watch for `[reaper] removed N unclicked
prewarm(s)` in the logs.

Note the reaper only runs in-process, so magnets left behind by a container
killed mid-session stay until something re-prewarms and reaps them. `POST
/reap` won't find those either — clear them in the AllDebrid UI if it matters.

## Persistent cache

Cache-check verdicts are written to `/data/cache.json` and reloaded at
startup, so a restart costs no AllDebrid uploads for anything already checked.
This matters more than it sounds: each probe is one upload against a rolling
quota, and an in-memory-only cache means every rebuild re-probes every title
you look at — enough to exhaust the quota while merely tuning settings.

```yaml
    volumes:
      - ./data:/data
    environment:
      - CACHE_CHECK_TTL=86400
```

The volume is required for this to survive `docker compose up --build`.
Writes are atomic (temp file then rename), flushed every 60 seconds and on
shutdown, so a crash can't leave a truncated cache. Expired entries are
dropped on load.

A 24h TTL trades a little staleness for a large cut in uploads. A verdict can
go stale either way — AllDebrid may evict content or acquire it — and a stale
"cached" simply fails at resolve time with a 503, which is a far cheaper
failure than burning the quota.

```bash
curl -s localhost:7000/health          # cache.entries, cache.file
curl -X POST localhost:7000/cache/save # flush now
```

## Probe cap (MAX_PROBE)

```yaml
      - MAX_PROBE=5      # default
```

The most important setting in this addon. Each probe is one magnet upload, and
AllDebrid limits uploads over a rolling window — not just how many magnets you
store. An upstream that returns a thousand candidates per search will exhaust
that quota in hours without a cap.

It applies after `MAX_RESULTS x PROBE_MULTIPLIER` and always wins, so a busy
upstream can't widen it. With 1232 candidates and the default cap, a search
uploads 5 magnets instead of 60.

The trade-off is real: only probed releases can come back cached, so you see at
most `MAX_PROBE` streams. Probes are spread across resolutions, so a cap of 5
still returns a mix rather than five copies of the same quality. Raise it if
you have quota headroom and want more choice; `MAX_PROBE=0` removes the cap
entirely, which is how the quota was exhausted in the first place.

## Quality bounds

```yaml
      - MIN_QUALITY=720p
      - MAX_QUALITY=1080p
```

Inclusive, either can be left blank for unbounded. `1080p`, `1080`, `4k`,
`uhd`, `hd` and `sd` all parse.

The filter runs *before* the cache probe, so excluded resolutions cost no
AllDebrid API calls — capping at 1080p on a title with lots of 4K roughly
halves the probes per search.

Releases whose resolution can't be parsed from the name are kept, since an
odd naming scheme is usually still a real release. Set
`ALLOW_UNKNOWN_QUALITY=false` to drop them instead. An unrecognised bound is
ignored with an error logged at startup rather than silently filtering
everything out.

## If only 2160p comes back

Results are sorted best-first, so a title with many cached 2160p releases
would fill the whole list and no 1080p would ever appear. Both the probe set
and the returned streams are now spread across resolutions instead, so every
resolution present gets representation.

To go further and cap each one explicitly:

```yaml
      - MAX_PER_RESOLUTION=5
```

This matters for anything that asks for a specific quality — a consumer
filtering to non-4K sees an empty list if every stream returned is 2160p.

## If Torrentio returns 403

Torrentio blocks requests from datacenter and VPS IP ranges, and rate-limits
heavy users. The addon sends a browser User-Agent, which fixes the simple case,
but a hard IP block needs a different source. Any of these work:

```yaml
      - ADDONS=https://comet.elfhosted.com,https://mediafusion.elfhosted.com
```

The durable fix is to stop depending on a public scraper. Point it at Prowlarr,
which queries your own indexer accounts and can't be blocked:

```yaml
      - PROWLARR_URL=http://prowlarr:9696
      - PROWLARR_API_KEY=your_key
```

Watch the logs on the next search — each source reports its own hit count.

`GET /health` shows the install URL, whether the key validated at startup, and
the live cache size.
