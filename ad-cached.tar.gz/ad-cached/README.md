# AllDebrid Cached — drop-in for AIOStreams

A Stremio addon that holds your AllDebrid key, checks what AllDebrid *actually*
has cached, and hands AIOStreams only those streams as finished links.

## Install

```bash
tar -xzf ad-cached.tar.gz && cd ad-cached
./deploy.sh your_alldebrid_key
```

Or manually:

```bash
echo "ALLDEBRID_API_KEY=your_key" > .env
docker compose up -d --build      # or: docker-compose up -d --build
```

In AIOStreams → **Addons** → **Add custom addon**:

```
http://<this-host>:7000/manifest.json
```

(or `http://ad-cached:7000/manifest.json` if you joined the AIOStreams network)

That's it. Streams show up labelled `[AD+]`.

## One rule

**Leave AllDebrid switched off under AIOStreams → Services.**

This addon already resolved the links. If AIOStreams also has AllDebrid
enabled it will try to re-resolve them, and you'll pay twice the API budget for
a worse result. The key lives here and only here.

## Why not just use the Services toggle

AllDebrid deprecated real-time instant-availability lookups — `magnet/instant`
no longer reflects true cache state. The only reliable signal today is the
`ready` flag on the `magnet/upload` response, so this addon uploads the magnet,
reads `ready`, and deletes the probe right after. Searching never pollutes your
AllDebrid library. Verdicts are reused for 5 minutes, and every call goes
through a 250/min sliding window with a 240 ms spacing floor.

## Defaults

Torrentio as the indexer, cached-only on, 20 streams per search. To add more
indexers or change behaviour, uncomment the block in `docker-compose.yml`:

| Variable | Default | |
|---|---|---|
| `ADDONS` | `https://torrentio.strem.fun` | Comma-separated Stremio torrent addons |
| `PROWLARR_URL` + `PROWLARR_API_KEY` | — | Fans out to every indexer Prowlarr manages |
| `TORZNAB` | — | `url\|apikey`, comma-separated (Jackett etc.) |
| `CACHED_ONLY` | `true` | `false` = uncached shown as `[AD download]` below cached |
| `MAX_RESULTS` | `20` | Streams returned |
| `PUBLIC_URL` | — | Set if reached by a name other than `ad-cached:7000` |
| `CACHE_CHECK_TTL` | `300` | Seconds a cache verdict is reused |

Don't point `ADDONS` at your AIOStreams URL — AIOStreams would call this addon,
which would call AIOStreams, forever. The addon logs an error at startup if it
spots that.

## Using your other AIOStreams addons as the source

Two configs on the same AIOStreams instance. They are separate addon lists, so
this is not a loop as long as you keep them straight:

**Config A — "sources".** Every torrent addon you want (Torrentio, Comet,
MediaFusion, Jackettio). Every debrid service **off**. This addon is **not**
in it. Copy its Stremio URL, drop the trailing `/manifest.json`, and set:

```yaml
      - ADDONS=http://aiostreams:3000/stremio/<config-A-uuid>/<password>
      - PUBLIC_URL=http://ad-cached:7000
```

**Config B — the one you install in Stremio.** One custom addon: this one, at
`http://ad-cached:7000/manifest.json`. Debrid **off**. Do all your sorting,
formatting and filtering here — it sees the cached streams this addon returns.

Two rules, and both failure modes are quiet if you break them:

- Config A must not list this addon. If it does, every search recurses. The
  addon detects this and logs a `[loop] refusing ...` error rather than hanging,
  but it returns nothing until you fix the config.
- Every debrid service must be off in both configs. A config that resolves
  streams itself returns finished HTTP links with no `infoHash`, leaving nothing
  to cache-check — you'd get an empty list with no obvious cause.

This also sidesteps Torrentio blocking your server, since AIOStreams does the
fetching.

## Quality bounds

```yaml
      - MIN_QUALITY=720p
      - MAX_QUALITY=1080p
```

Inclusive, either can be left blank for unbounded. `1080p`, `1080`, `4k`,
`uhd`, `hd` and `sd` all parse.

The filter runs *before* the cache probe, so excluded resolutions cost no
AllDebrid API calls — capping at 1080p on a title with lots of 4K roughly
halves the probes per search.

Releases whose resolution can't be parsed from the name are kept, since an
odd naming scheme is usually still a real release. Set
`ALLOW_UNKNOWN_QUALITY=false` to drop them instead. An unrecognised bound is
ignored with an error logged at startup rather than silently filtering
everything out.

## If only 2160p comes back

Results are sorted best-first, so a title with many cached 2160p releases
would fill the whole list and no 1080p would ever appear. Both the probe set
and the returned streams are now spread across resolutions instead, so every
resolution present gets representation.

To go further and cap each one explicitly:

```yaml
      - MAX_PER_RESOLUTION=5
```

This matters for anything that asks for a specific quality — a consumer
filtering to non-4K sees an empty list if every stream returned is 2160p.

## If Torrentio returns 403

Torrentio blocks requests from datacenter and VPS IP ranges, and rate-limits
heavy users. The addon sends a browser User-Agent, which fixes the simple case,
but a hard IP block needs a different source. Any of these work:

```yaml
      - ADDONS=https://comet.elfhosted.com,https://mediafusion.elfhosted.com
```

The durable fix is to stop depending on a public scraper. Point it at Prowlarr,
which queries your own indexer accounts and can't be blocked:

```yaml
      - PROWLARR_URL=http://prowlarr:9696
      - PROWLARR_API_KEY=your_key
```

Watch the logs on the next search — each source reports its own hit count.

`GET /health` shows the install URL, whether the key validated at startup, and
the live cache size.
