"""AllDebrid client.

The cache-check method here is the same one used by alldebrid-web:
AllDebrid deprecated real-time instant-availability lookups (magnet/instant no
longer reflects true cache state), so the only reliable signal today is the
`ready` flag on the magnet/upload response itself. We upload the magnet, read
`ready`, and then delete anything we uploaded purely to probe — so the user's
AllDebrid library isn't polluted by searches.

Also ported: the 250 req/min sliding-window rate limiter with a minimum spacing
floor between request starts. AllDebrid's front-end enforces its own short
burst window independent of the per-minute total, so concurrent callers must
queue rather than fire together.
"""

import logging
import os
import threading
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

import requests

log = logging.getLogger("alldebrid")

# ── Endpoints ────────────────────────────────────────────────────────────────
AD_BASE   = "https://api.alldebrid.com/v4"
AD_UPLOAD = f"{AD_BASE}/magnet/upload"
AD_DELETE = f"{AD_BASE}/magnet/delete"
AD_FILES  = f"{AD_BASE}/magnet/files"
AD_UNLOCK = f"{AD_BASE}/link/unlock"
AD_USER   = f"{AD_BASE}/user"
AD_STATUS = "https://api.alldebrid.com/v4.1/magnet/status"

# AllDebrid requires an `agent` query parameter on EVERY v4 endpoint — it is
# marked required in their OpenAPI spec and AUTH_MISSING_AGENT is a real error
# code, so calls fail without it even with a valid apikey.
AD_AGENT = os.environ.get("ALLDEBRID_AGENT", "ad-cached-addon")

_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="ad-worker")

# ── Rate limiter ─────────────────────────────────────────────────────────────
_AD_RATE_LIMIT  = int(os.environ.get("AD_RATE_LIMIT", "250"))
_AD_RATE_WINDOW = 60.0
_AD_MIN_SPACING = float(os.environ.get("AD_MIN_SPACING_MS", "240")) / 1000.0

_ad_rate_lock = threading.Lock()
_ad_timestamps: list[float] = []
_ad_last_request_at = 0.0


def _ad_api_acquire():
    global _ad_last_request_at
    while True:
        now    = time.monotonic()
        cutoff = now - _AD_RATE_WINDOW
        with _ad_rate_lock:
            while _ad_timestamps and _ad_timestamps[0] < cutoff:
                _ad_timestamps.pop(0)
            since_last = now - _ad_last_request_at
            under_cap  = len(_ad_timestamps) < _AD_RATE_LIMIT
            spaced_out = since_last >= _AD_MIN_SPACING
            if under_cap and spaced_out:
                _ad_timestamps.append(now)
                _ad_last_request_at = now
                return
            wait_for_cap   = (_ad_timestamps[0] - cutoff) + 0.01 if not under_cap else 0.0
            wait_for_space = (_AD_MIN_SPACING - since_last) if not spaced_out else 0.0
            wait = max(wait_for_cap, wait_for_space)
        time.sleep(max(wait, 0.01))


# ── Low-level HTTP ───────────────────────────────────────────────────────────
def _headers(key: str) -> dict:
    return {"Authorization": f"Bearer {key}"}


def _params(params: dict | None = None) -> dict:
    merged = {"agent": AD_AGENT}
    if params:
        merged.update(params)
    return merged


def ad_get(key: str, url: str, params: dict | None = None) -> dict:
    _ad_api_acquire()
    try:
        r = requests.get(url, headers=_headers(key), params=_params(params), timeout=20)
        if r.status_code >= 400:
            # Surface the real AllDebrid error body — codes like
            # AUTH_MISSING_AGENT / AUTH_BAD_APIKEY are only visible here.
            try:
                body = r.json()
            except Exception:
                body = r.text[:200]
            log.warning(f"[ad-get] {url} -> HTTP {r.status_code}: {body}")
            return body if isinstance(body, dict) else {}
        return r.json()
    except Exception as e:
        log.warning(f"[ad-get] {url}: {e}")
        return {}


def ad_post_raw(key: str, url: str, pairs: list) -> dict:
    _ad_api_acquire()
    try:
        all_pairs = [("agent", AD_AGENT)] + list(pairs)
        r = requests.post(
            url,
            headers={**_headers(key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode(all_pairs),
            timeout=20,
        )
        if r.status_code >= 400:
            try:
                body = r.json()
            except Exception:
                body = r.text[:200]
            log.warning(f"[ad-post] {url} -> HTTP {r.status_code}: {body}")
            return body if isinstance(body, dict) else {}
        return r.json()
    except Exception as e:
        log.warning(f"[ad-post] {url}: {e}")
        return {}


def ad_upload_batch(key: str, magnets: list) -> dict:
    return ad_post_raw(key, AD_UPLOAD, [("magnets[]", m) for m in magnets])


def ad_delete(key: str, mid) -> None:
    if not key or not mid:
        return
    _ad_api_acquire()
    try:
        r = requests.post(
            AD_DELETE,
            headers={**_headers(key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode({"agent": AD_AGENT, "id": mid}),
            timeout=15,
        )
        if r.status_code >= 400:
            log.warning(f"[ad-delete] {mid} -> HTTP {r.status_code}: {r.text[:200]}")
    except Exception as e:
        log.warning(f"[ad-delete] {mid}: {e}")


def make_magnet(hash_: str, name: str = "") -> str:
    n = urllib.parse.quote(name, safe="")
    h = hash_.lower()
    return f"magnet:?xt=urn:btih:{h}&dn={n}" if n else f"magnet:?xt=urn:btih:{h}"


def check_key(key: str) -> tuple[bool, str]:
    """Validate an API key. Returns (ok, message)."""
    if not key:
        return False, "no api key"
    res = ad_get(key, AD_USER)
    if res.get("status") == "success":
        u = res.get("data", {}).get("user", {})
        prem = "premium" if u.get("isPremium") else "free"
        return True, f"{u.get('username', '?')} ({prem})"
    err = res.get("error", {})
    return False, f"{err.get('code', 'UNKNOWN')}: {err.get('message', 'invalid key')}"


# ── Cache check (upload → read ready → delete) ───────────────────────────────
_cc_results: dict[str, tuple[bool, float]] = {}
_cc_lock = threading.Lock()
_CC_TTL  = int(os.environ.get("CACHE_CHECK_TTL", "300"))
_CC_CHUNK = int(os.environ.get("CACHE_CHECK_CHUNK", "20"))


def check_cache_ad(key: str, torrents: list, keep_hashes: set | None = None) -> dict:
    """Return {hash: bool} — True means AllDebrid has the torrent cached.

    `torrents` is a list of dicts with at least `info_hash`, optionally `name`.
    `keep_hashes` are hashes that must NOT be deleted after probing (e.g. ones
    the user already has as a real transfer in their AllDebrid library).

    Costs 1 upload call per chunk plus 1 delete per probed magnet. Results are
    memoised in-process for CACHE_CHECK_TTL seconds so repeated searches for
    the same hashes don't re-hit the upstream API.
    """
    if not torrents or not key:
        return {}

    hashes = [t["info_hash"].lower() for t in torrents]
    now = time.time()
    with _cc_lock:
        stale = [h for h in hashes if h not in _cc_results or now >= _cc_results[h][1]]
    if not stale:
        with _cc_lock:
            return {h: _cc_results[h][0] for h in hashes if h in _cc_results}

    keep = {h.lower() for h in (keep_hashes or set())}
    name_by_hash = {t["info_hash"].lower(): t.get("name", "") for t in torrents}
    ready_map: dict[str, bool] = {}
    to_delete: list = []

    for i in range(0, len(stale), _CC_CHUNK):
        chunk = stale[i:i + _CC_CHUNK]
        magnets = [make_magnet(h, name_by_hash.get(h, "")) for h in chunk]
        try:
            resp = ad_upload_batch(key, magnets)
        except Exception as e:
            log.warning(f"[cache-check] upload failed: {e}")
            continue

        # A failed call can come back as a TOP-LEVEL error (bad apikey, rate
        # limited) with no "data" key at all — silently doing .get("data", {})
        # would make every hash look "not cached" with no sign anything broke.
        if resp.get("status") == "error":
            err = resp.get("error", {})
            log.warning(f"[cache-check] AllDebrid error {err.get('code')}: {err.get('message')}")
            continue

        items = resp.get("data", {}).get("magnets", [])
        if not items:
            log.warning(
                f"[cache-check] upload returned success but 0 magnets for "
                f"{len(chunk)} hash(es) — raw: {str(resp)[:300]}"
            )

        n_errors = 0
        for idx, m in enumerate(items):
            # AllDebrid normally echoes the hash back; fall back to request
            # order if it's ever missing so results aren't dropped silently.
            h = (m.get("hash") or "").lower()
            if not h and idx < len(chunk):
                h = chunk[idx]
            if not h:
                continue
            if m.get("error"):
                e = m["error"]
                log.warning(f"[cache-check] {h[:8]}: {e.get('code')} {e.get('message')}")
                ready_map[h] = False
                n_errors += 1
                continue
            ready_map[h] = bool(m.get("ready", False))
            ad_id = m.get("id")
            if ad_id and h not in keep:
                to_delete.append(ad_id)

        n_ready = sum(1 for m in items if not m.get("error") and m.get("ready"))
        log.info(
            f"[cache-check] batch of {len(chunk)}: {n_ready} ready, {n_errors} errored, "
            f"{len(items) - n_ready - n_errors} not-ready"
        )

    # Clean up the probe magnets — fire-and-forget so stream responses aren't
    # held up waiting on deletes.
    for ad_id in to_delete:
        try:
            _pool.submit(ad_delete, key, ad_id)
        except Exception:
            ad_delete(key, ad_id)

    exp = now + _CC_TTL
    with _cc_lock:
        for h in stale:
            _cc_results[h] = (ready_map.get(h, False), exp)
        return {h: _cc_results[h][0] for h in hashes if h in _cc_results}


def cache_stats() -> dict:
    with _cc_lock:
        now = time.time()
        live = {h: v for h, (v, exp) in _cc_results.items() if now < exp}
    return {"entries": len(live), "cached": sum(1 for v in live.values() if v), "ttl": _CC_TTL}


# ── Playback resolve ─────────────────────────────────────────────────────────
VIDEO_EXT = (".mkv", ".mp4", ".avi", ".m4v", ".mov", ".ts", ".wmv", ".mpg", ".mpeg", ".webm")


def _flatten_files(nodes: list, prefix: str = "") -> list[dict]:
    """magnet/files returns a nested tree: `n` name, `s` size, `l` link,
    `e` child entries for folders. Flatten to a list of leaf files."""
    out = []
    for n in nodes or []:
        name = n.get("n", "")
        path = f"{prefix}/{name}" if prefix else name
        if n.get("e"):
            out.extend(_flatten_files(n["e"], path))
        elif n.get("l"):
            out.append({"name": name, "path": path, "size": int(n.get("s") or 0), "link": n["l"]})
    return out


def list_files(key: str, ad_id) -> list[dict]:
    res = ad_post_raw(key, AD_FILES, [("id[]", ad_id)])
    mags = res.get("data", {}).get("magnets", [])
    if not mags:
        return []
    m = mags[0]
    if m.get("error"):
        log.warning(f"[files] {ad_id}: {m['error'].get('message')}")
        return []
    return _flatten_files(m.get("files", []))


def add_magnet(key: str, hash_: str, name: str = "") -> dict:
    """Upload one magnet and return its magnet object ({id, ready, ...})."""
    res = ad_upload_batch(key, [make_magnet(hash_, name)])
    if res.get("status") == "error":
        err = res.get("error", {})
        return {"error": err}
    mags = res.get("data", {}).get("magnets", [])
    return mags[0] if mags else {"error": {"message": "no magnets in response"}}


def unlock(key: str, link: str) -> str:
    res = ad_get(key, AD_UNLOCK, {"link": link})
    if res.get("status") != "success":
        err = res.get("error", {})
        log.warning(f"[unlock] {err.get('code')}: {err.get('message')}")
        return ""
    return res.get("data", {}).get("link", "") or ""
