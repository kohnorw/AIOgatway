"""AllDebrid client.

The cache-check method here is the same one used by alldebrid-web:
AllDebrid deprecated real-time instant-availability lookups (magnet/instant no
longer reflects true cache state), so the only reliable signal today is the
`ready` flag on the magnet/upload response itself. We upload the magnet, read
`ready`, and then delete anything we uploaded purely to probe — so the user's
AllDebrid library isn't polluted by searches.

Also ported: the 250 req/min sliding-window rate limiter with a minimum spacing
floor between request starts. AllDebrid's front-end enforces its own short
burst window independent of the per-minute total, so concurrent callers must
queue rather than fire together.
"""

import logging
import os
import threading
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

import requests

log = logging.getLogger("alldebrid")

# ── Endpoints ────────────────────────────────────────────────────────────────
AD_BASE   = "https://api.alldebrid.com/v4"
AD_UPLOAD = f"{AD_BASE}/magnet/upload"
AD_DELETE = f"{AD_BASE}/magnet/delete"
AD_FILES  = f"{AD_BASE}/magnet/files"
AD_UNLOCK = f"{AD_BASE}/link/unlock"
AD_USER   = f"{AD_BASE}/user"
AD_STATUS = "https://api.alldebrid.com/v4.1/magnet/status"

# AllDebrid requires an `agent` query parameter on EVERY v4 endpoint — it is
# marked required in their OpenAPI spec and AUTH_MISSING_AGENT is a real error
# code, so calls fail without it even with a valid apikey.
AD_AGENT = os.environ.get("ALLDEBRID_AGENT", "ad-cached-addon")

_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="ad-worker")

# ── Rate limiter ─────────────────────────────────────────────────────────────
_AD_RATE_LIMIT  = int(os.environ.get("AD_RATE_LIMIT", "250"))
_AD_RATE_WINDOW = 60.0
_AD_MIN_SPACING = float(os.environ.get("AD_MIN_SPACING_MS", "240")) / 1000.0

_ad_rate_lock = threading.Lock()
_ad_timestamps: list[float] = []
_ad_last_request_at = 0.0


def _ad_api_acquire():
    global _ad_last_request_at
    while True:
        now    = time.monotonic()
        cutoff = now - _AD_RATE_WINDOW
        with _ad_rate_lock:
            while _ad_timestamps and _ad_timestamps[0] < cutoff:
                _ad_timestamps.pop(0)
            since_last = now - _ad_last_request_at
            under_cap  = len(_ad_timestamps) < _AD_RATE_LIMIT
            spaced_out = since_last >= _AD_MIN_SPACING
            if under_cap and spaced_out:
                _ad_timestamps.append(now)
                _ad_last_request_at = now
                return
            wait_for_cap   = (_ad_timestamps[0] - cutoff) + 0.01 if not under_cap else 0.0
            wait_for_space = (_AD_MIN_SPACING - since_last) if not spaced_out else 0.0
            wait = max(wait_for_cap, wait_for_space)
        time.sleep(max(wait, 0.01))


# ── Low-level HTTP ───────────────────────────────────────────────────────────
def _headers(key: str) -> dict:
    return {"Authorization": f"Bearer {key}"}


def _params(params: dict | None = None) -> dict:
    merged = {"agent": AD_AGENT}
    if params:
        merged.update(params)
    return merged


def ad_get(key: str, url: str, params: dict | None = None) -> dict:
    _ad_api_acquire()
    try:
        r = requests.get(url, headers=_headers(key), params=_params(params), timeout=20)
        if r.status_code >= 400:
            # Surface the real AllDebrid error body — codes like
            # AUTH_MISSING_AGENT / AUTH_BAD_APIKEY are only visible here.
            try:
                body = r.json()
            except Exception:
                body = r.text[:200]
            log.warning(f"[ad-get] {url} -> HTTP {r.status_code}: {body}")
            return body if isinstance(body, dict) else {}
        return r.json()
    except Exception as e:
        log.warning(f"[ad-get] {url}: {e}")
        return {}


def ad_post_raw(key: str, url: str, pairs: list) -> dict:
    _ad_api_acquire()
    try:
        all_pairs = [("agent", AD_AGENT)] + list(pairs)
        r = requests.post(
            url,
            headers={**_headers(key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode(all_pairs),
            timeout=20,
        )
        if r.status_code >= 400:
            try:
                body = r.json()
            except Exception:
                body = r.text[:200]
            log.warning(f"[ad-post] {url} -> HTTP {r.status_code}: {body}")
            return body if isinstance(body, dict) else {}
        return r.json()
    except Exception as e:
        log.warning(f"[ad-post] {url}: {e}")
        return {}


def ad_upload_batch(key: str, magnets: list) -> dict:
    return ad_post_raw(key, AD_UPLOAD, [("magnets[]", m) for m in magnets])


# Batch delete support.
#
# magnet/upload takes magnets[] (20 per call), but magnet/delete is documented
# only with a single `id`. If it also accepts id[] the way upload does, probe
# cleanup drops from one call per magnet to one per 20 — the difference
# between the delete queue draining 20x faster than it fills and never
# catching up at all. It is not documented clearly enough to assume, so the
# first batch attempt is probed and the result latched for the process.
#   None = untested, True = supported, False = fall back to single deletes
_batch_delete_ok: bool | None = None
_batch_probe_lock = threading.Lock()
BATCH_DELETE_CHUNK = int(os.environ.get("BATCH_DELETE_CHUNK", "20"))


def _delete_batch_once(key: str, ids: list) -> bool:
    """Try one id[] delete. True if AllDebrid accepted it."""
    res = ad_post_raw(key, AD_DELETE, [("id[]", i) for i in ids])
    if res.get("status") == "success":
        return True
    # A per-magnet error list still means the batch form was understood.
    data = res.get("data") or {}
    if isinstance(data, dict) and data.get("magnets"):
        return True
    err = res.get("error", {})
    log.info(f"[delete] batch form rejected ({err.get('code')}) — "
             f"falling back to one call per magnet")
    return False


def delete_many(key: str, ids: list) -> int:
    """Delete a list of magnets, batching where the API allows it."""
    global _batch_delete_ok
    ids = [i for i in ids if i is not None and i != ""]
    if not key or not ids:
        return 0

    if _batch_delete_ok is None:
        with _batch_probe_lock:
            if _batch_delete_ok is None:
                probe = ids[:BATCH_DELETE_CHUNK]
                _batch_delete_ok = _delete_batch_once(key, probe)
                if _batch_delete_ok:
                    log.info(f"[delete] batch deletes supported "
                             f"({BATCH_DELETE_CHUNK} per call)")
                    ids = ids[len(probe):]
                    done = len(probe)
                else:
                    done = 0
        if _batch_delete_ok and not ids:
            return done
    else:
        done = 0

    if _batch_delete_ok:
        for i in range(0, len(ids), BATCH_DELETE_CHUNK):
            chunk = ids[i:i + BATCH_DELETE_CHUNK]
            if _delete_batch_once(key, chunk):
                done += len(chunk)
            else:
                for mid in chunk:
                    ad_delete(key, mid)
                    done += 1
    else:
        for mid in ids:
            ad_delete(key, mid)
            done += 1
    return done


def ad_delete(key: str, mid) -> None:
    if not key or not mid:
        return
    _ad_api_acquire()
    try:
        r = requests.post(
            AD_DELETE,
            headers={**_headers(key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode({"agent": AD_AGENT, "id": mid}),
            timeout=15,
        )
        if r.status_code >= 400:
            log.warning(f"[ad-delete] {mid} -> HTTP {r.status_code}: {r.text[:200]}")
    except Exception as e:
        log.warning(f"[ad-delete] {mid}: {e}")


def _extract_magnets(res: dict) -> list[dict]:
    """magnet/status shapes differ between versions: data.magnets may be a
    list, or a dict keyed by id, or (on v4 single-id calls) a lone object."""
    if res.get("status") != "success":
        return []
    mags = res.get("data", {}).get("magnets", [])
    if isinstance(mags, dict):
        # Either {id: {...}} or a single magnet object.
        mags = list(mags.values()) if not mags.get("id") else [mags]
    return [m for m in mags if isinstance(m, dict)]


def list_magnets(key: str) -> list[dict]:
    """Every magnet in the library, across every endpoint shape AllDebrid has
    used. Returns [] only if the account really is empty — a failure to list
    is logged loudly, because a silent empty result would make purge a no-op
    and leave a full library permanently stuck."""
    # v4.1 paginated
    out, page, ok = [], 0, False
    while page <= 20:
        res = ad_get(key, AD_STATUS, {"status": "all", "page": page})
        if res.get("status") != "success":
            err = res.get("error", {})
            if page == 0:
                log.warning(f"[list] v4.1 page {page}: {err.get('code')} "
                            f"{err.get('message')}")
            break
        ok = True
        mags = _extract_magnets(res)
        if not mags:
            break
        out.extend(mags)
        if len(mags) < 100:
            break
        page += 1
    if out:
        log.info(f"[list] {len(out)} magnet(s) via v4.1")
        return out

    # v4 unpaginated fallback
    res = ad_get(key, f"{AD_BASE}/magnet/status", {"status": "all"})
    mags = _extract_magnets(res)
    if mags:
        log.info(f"[list] {len(mags)} magnet(s) via v4")
        return mags

    err = res.get("error", {})
    if not ok and err:
        log.error(f"[list] could not list magnets: {err.get('code')} "
                  f"{err.get('message')} — purge cannot free space")
    return []


# Background purge state. A full library can hold many thousands of magnets,
# and the rate limiter caps deletes at ~250/min, so a purge can run for tens
# of minutes — far too long to hold an HTTP request open.
_purge_state = {"running": False, "total": 0, "removed": 0, "kept": 0,
                "started": 0.0, "finished": 0.0, "error": ""}
_purge_state_lock = threading.Lock()


def purge_status() -> dict:
    with _purge_state_lock:
        st = dict(_purge_state)
    if st["running"] and st["removed"]:
        elapsed = time.time() - st["started"]
        rate = st["removed"] / max(elapsed, 1)
        left = max(st["total"] - st["removed"] - st["kept"], 0)
        st["eta_seconds"] = int(left / rate) if rate else None
        st["rate_per_min"] = round(rate * 60, 1)
    return st


def purge_background(key: str, keep_hashes: set | None = None,
                     limit: int = 0) -> dict:
    """Start a purge on a worker thread. Returns immediately."""
    with _purge_state_lock:
        if _purge_state["running"]:
            return {"started": False, "reason": "already running"}
        _purge_state.update(running=True, total=0, removed=0, kept=0,
                            started=time.time(), finished=0.0, error="")

    def run():
        try:
            purge(key, keep_hashes, limit, _progress=True)
        except Exception as e:
            with _purge_state_lock:
                _purge_state["error"] = str(e)
            log.error(f"[purge] failed: {e}")
        finally:
            with _purge_state_lock:
                _purge_state["running"] = False
                _purge_state["finished"] = time.time()

    threading.Thread(target=run, daemon=True, name="purge").start()
    return {"started": True}


def purge(key: str, keep_hashes: set | None = None, limit: int = 0,
          _progress: bool = False) -> dict:
    """Delete magnets from the library, oldest first.

    This is the recovery path for MAGNET_TOO_MANY: once the library is at the
    1000-magnet ceiling every upload fails, so nothing can be cache-checked
    until space is freed. Hashes in keep_hashes are never removed.

    Deletes are issued serially and the result is checked, unlike the
    fire-and-forget probe cleanup — a purge that silently failed would leave
    the addon permanently stuck.
    """
    keep = {h.lower() for h in (keep_hashes or set())}
    mags = list_magnets(key)
    # Oldest first, so anything recently prewarmed survives longest.
    mags.sort(key=lambda m: m.get("uploadDate") or 0)
    if not mags:
        log.error("[purge] library listed as empty — nothing to remove. If "
                  "AllDebrid says the library is full, the listing call is "
                  "failing; check the log line from [list] above.")
        return {"library": 0, "removed": 0, "kept": 0}

    if _progress:
        with _purge_state_lock:
            _purge_state["total"] = len(mags)
    per_call = BATCH_DELETE_CHUNK if _batch_delete_ok is not False else 1
    est = len(mags) / per_call / max(_AD_RATE_LIMIT, 1)
    log.info(f"[purge] {len(mags)} magnet(s) to process, roughly "
             f"{max(est, 0.1):.1f} min at the current rate limit")

    targets, skipped = [], 0
    for m in mags:
        h = (m.get("hash") or "").lower()
        if h in keep:
            skipped += 1
            continue
        if m.get("id"):
            targets.append(m["id"])
        if limit and len(targets) >= limit:
            break

    removed = 0
    for i in range(0, len(targets), BATCH_DELETE_CHUNK):
        removed += delete_many(key, targets[i:i + BATCH_DELETE_CHUNK])
        if _progress:
            with _purge_state_lock:
                _purge_state["removed"] = removed
                _purge_state["kept"] = skipped
        if removed % 250 < BATCH_DELETE_CHUNK:
            log.info(f"[purge] {removed}/{len(targets)} removed")
    log.info(f"[purge] library had {len(mags)}, removed {removed}, kept {skipped}")
    return {"library": len(mags), "removed": removed, "kept": skipped}


_pending_deletes: set = set()
_pending_lock = threading.Lock()


def _tracked_delete(key: str, mid) -> None:
    try:
        ad_delete(key, mid)
    finally:
        with _pending_lock:
            _pending_deletes.discard(mid)


def _tracked_delete_many(key: str, ids: list) -> None:
    try:
        delete_many(key, ids)
    finally:
        with _pending_lock:
            _pending_deletes.difference_update(ids)


def pending_deletes() -> int:
    with _pending_lock:
        return len(_pending_deletes)


def make_magnet(hash_: str, name: str = "") -> str:
    n = urllib.parse.quote(name, safe="")
    h = hash_.lower()
    return f"magnet:?xt=urn:btih:{h}&dn={n}" if n else f"magnet:?xt=urn:btih:{h}"


def check_key(key: str) -> tuple[bool, str]:
    """Validate an API key. Returns (ok, message)."""
    if not key:
        return False, "no api key"
    res = ad_get(key, AD_USER)
    if res.get("status") == "success":
        u = res.get("data", {}).get("user", {})
        prem = "premium" if u.get("isPremium") else "free"
        return True, f"{u.get('username', '?')} ({prem})"
    err = res.get("error", {})
    return False, f"{err.get('code', 'UNKNOWN')}: {err.get('message', 'invalid key')}"


# ── Cache check (upload → read ready → delete) ───────────────────────────────
_cc_results: dict[str, tuple[bool, float]] = {}
_cc_lock = threading.Lock()
_CC_TTL  = int(os.environ.get("CACHE_CHECK_TTL", "300"))
_CC_CHUNK = int(os.environ.get("CACHE_CHECK_CHUNK", "20"))

# Recovery from a full library.
AUTO_PURGE   = os.environ.get("AUTO_PURGE", "true").lower() == "true"
PURGE_LIMIT  = int(os.environ.get("PURGE_LIMIT", "300"))
_purged_this_run = False


def check_cache_ad(key: str, torrents: list, keep_hashes: set | None = None) -> dict:
    """Return {hash: bool} — True means AllDebrid has the torrent cached.

    `torrents` is a list of dicts with at least `info_hash`, optionally `name`.
    `keep_hashes` are hashes that must NOT be deleted after probing (e.g. ones
    the user already has as a real transfer in their AllDebrid library).

    Costs 1 upload call per chunk plus 1 delete per probed magnet. Results are
    memoised in-process for CACHE_CHECK_TTL seconds so repeated searches for
    the same hashes don't re-hit the upstream API.
    """
    if not torrents or not key:
        return {}

    hashes = [t["info_hash"].lower() for t in torrents]
    now = time.time()
    with _cc_lock:
        stale = [h for h in hashes if h not in _cc_results or now >= _cc_results[h][1]]
    if not stale:
        with _cc_lock:
            return {h: _cc_results[h][0] for h in hashes if h in _cc_results}

    global _purged_this_run
    keep = {h.lower() for h in (keep_hashes or set())}
    name_by_hash = {t["info_hash"].lower(): t.get("name", "") for t in torrents}
    ready_map: dict[str, bool] = {}
    to_delete: list = []

    for i in range(0, len(stale), _CC_CHUNK):
        chunk = stale[i:i + _CC_CHUNK]
        magnets = [make_magnet(h, name_by_hash.get(h, "")) for h in chunk]
        try:
            resp = ad_upload_batch(key, magnets)
        except Exception as e:
            log.warning(f"[cache-check] upload failed: {e}")
            continue

        # A failed call can come back as a TOP-LEVEL error (bad apikey, rate
        # limited) with no "data" key at all — silently doing .get("data", {})
        # would make every hash look "not cached" with no sign anything broke.
        if resp.get("status") == "error":
            err = resp.get("error", {})
            code = err.get("code")
            log.warning(f"[cache-check] AllDebrid error {code}: {err.get('message')}")
            if code == "MAGNET_TOO_MANY" and AUTO_PURGE and not _purged_this_run:
                # The library is full, so every further upload fails too.
                # Free space once per process-run and retry this chunk.
                log.warning("[cache-check] library full — purging to recover")
                result = purge(key, keep_hashes=keep, limit=PURGE_LIMIT)
                if not result.get("removed"):
                    # Nothing was freed, so retrying is pointless and the
                    # flag stays clear: a later search can try again once
                    # whatever blocked the listing is fixed.
                    log.error("[cache-check] purge freed nothing — check "
                              "GET /library and the AllDebrid account")
                    continue
                _purged_this_run = True
                resp = ad_upload_batch(key, magnets)
                if resp.get("status") == "error":
                    continue
            else:
                continue

        items = resp.get("data", {}).get("magnets", [])
        if not items:
            log.warning(
                f"[cache-check] upload returned success but 0 magnets for "
                f"{len(chunk)} hash(es) — raw: {str(resp)[:300]}"
            )

        n_errors = 0
        for idx, m in enumerate(items):
            # AllDebrid normally echoes the hash back; fall back to request
            # order if it's ever missing so results aren't dropped silently.
            h = (m.get("hash") or "").lower()
            if not h and idx < len(chunk):
                h = chunk[idx]
            if not h:
                continue
            if m.get("error"):
                e = m["error"]
                log.warning(f"[cache-check] {h[:8]}: {e.get('code')} {e.get('message')}")
                ready_map[h] = False
                n_errors += 1
                continue
            ready_map[h] = bool(m.get("ready", False))
            ad_id = m.get("id")
            if ad_id and h not in keep:
                to_delete.append(ad_id)

        n_ready = sum(1 for m in items if not m.get("error") and m.get("ready"))
        log.info(
            f"[cache-check] batch of {len(chunk)}: {n_ready} ready, {n_errors} errored, "
            f"{len(items) - n_ready - n_errors} not-ready"
        )

    # Clean up the probe magnets. Off the response path so searches aren't
    # held up, but tracked: an unbounded backlog here is what fills the
    # library up to the 1000-magnet ceiling.
    with _pending_lock:
        _pending_deletes.update(to_delete)
    if to_delete:
        try:
            _pool.submit(_tracked_delete_many, key, list(to_delete))
        except Exception:
            _tracked_delete_many(key, list(to_delete))

    exp = now + _CC_TTL
    with _cc_lock:
        for h in stale:
            _cc_results[h] = (ready_map.get(h, False), exp)
        return {h: _cc_results[h][0] for h in hashes if h in _cc_results}


def cache_stats() -> dict:
    with _cc_lock:
        now = time.time()
        live = {h: v for h, (v, exp) in _cc_results.items() if now < exp}
    return {"entries": len(live), "cached": sum(1 for v in live.values() if v),
            "ttl": _CC_TTL, "pending_deletes": pending_deletes()}


# ── Playback resolve ─────────────────────────────────────────────────────────
VIDEO_EXT = (".mkv", ".mp4", ".avi", ".m4v", ".mov", ".ts", ".wmv", ".mpg", ".mpeg", ".webm")


def _flatten_files(nodes: list, prefix: str = "") -> list[dict]:
    """magnet/files returns a nested tree: `n` name, `s` size, `l` link,
    `e` child entries for folders. Flatten to a list of leaf files."""
    out = []
    for n in nodes or []:
        name = n.get("n", "")
        path = f"{prefix}/{name}" if prefix else name
        if n.get("e"):
            out.extend(_flatten_files(n["e"], path))
        elif n.get("l"):
            out.append({"name": name, "path": path, "size": int(n.get("s") or 0), "link": n["l"]})
    return out


def list_files(key: str, ad_id) -> list[dict]:
    res = ad_post_raw(key, AD_FILES, [("id[]", ad_id)])
    mags = res.get("data", {}).get("magnets", [])
    if not mags:
        return []
    m = mags[0]
    if m.get("error"):
        log.warning(f"[files] {ad_id}: {m['error'].get('message')}")
        return []
    return _flatten_files(m.get("files", []))


def add_magnet(key: str, hash_: str, name: str = "") -> dict:
    """Upload one magnet and return its magnet object ({id, ready, ...})."""
    res = ad_upload_batch(key, [make_magnet(hash_, name)])
    if res.get("status") == "error":
        err = res.get("error", {})
        return {"error": err}
    mags = res.get("data", {}).get("magnets", [])
    return mags[0] if mags else {"error": {"message": "no magnets in response"}}


def unlock(key: str, link: str) -> str:
    res = ad_get(key, AD_UNLOCK, {"link": link})
    if res.get("status") != "success":
        err = res.get("error", {})
        log.warning(f"[unlock] {err.get('code')}: {err.get('message')}")
        return ""
    return res.get("data", {}).get("link", "") or ""
