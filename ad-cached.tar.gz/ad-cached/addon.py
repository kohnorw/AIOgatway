"""AllDebrid cached-only Stremio addon — drop-in for an existing AIOStreams.

Configured entirely from the environment, so the install URL is just
    http://<host>:7000/manifest.json
with no config blob to generate. Add that as a custom addon in AIOStreams.

It queries every indexer you point it at, de-duplicates by info hash, runs the
survivors through the AllDebrid cache check (magnet/upload → ready → delete,
the same method alldebrid-web uses), and returns only what is already cached.
"""

import base64
import logging
import os
import re
import threading
import time
import urllib.parse

from flask import Flask, Response, jsonify, redirect, request

import alldebrid as ad
import release
import sources

logging.basicConfig(
    level=os.environ.get("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("addon")

app = Flask(__name__)

ADDON_ID      = "community.alldebrid.cached"
ADDON_NAME    = os.environ.get("ADDON_NAME", "AllDebrid Cached")
ADDON_VERSION = "2.0.0"
PUBLIC_URL    = os.environ.get("PUBLIC_URL", "").rstrip("/")

READY_WAIT_SECONDS   = int(os.environ.get("AD_READY_WAIT_SECONDS", "20"))
DELETE_AFTER_RESOLVE = os.environ.get("AD_DELETE_AFTER_RESOLVE", "false").lower() == "true"
RESOLVE_TTL          = int(os.environ.get("RESOLVE_TTL", "3600"))


def _csv(name: str, default: str = "") -> list[str]:
    return [v.strip() for v in os.environ.get(name, default).split(",") if v.strip()]


CFG = {
    "ad_key": os.environ.get("ALLDEBRID_API_KEY", ""),
    "ad_enabled": os.environ.get("ALLDEBRID_ENABLED", "true").lower() == "true",
    "cached_only": os.environ.get("CACHED_ONLY", "true").lower() == "true",
    # Indexer sources — any combination.
    "addons": _csv("ADDONS", "https://torrentio.strem.fun"),
    "prowlarr_url": os.environ.get("PROWLARR_URL", ""),
    "prowlarr_key": os.environ.get("PROWLARR_API_KEY", ""),
    # TORZNAB=https://jackett:9117/api/v2.0/indexers/all/results/torznab/api|apikey,...
    "torznab": _csv("TORZNAB"),
    "max_results": max(1, min(int(os.environ.get("MAX_RESULTS", "20")), 100)),
    "probe_multiplier": max(1, int(os.environ.get("PROBE_MULTIPLIER", "3"))),
    # 0 = no cap. Otherwise the most streams any one resolution may occupy.
    "max_per_resolution": int(os.environ.get("MAX_PER_RESOLUTION", "0")),
    "keep_hashes": [h.lower() for h in _csv("KEEP_HASHES")],
}


def base_url() -> str:
    return PUBLIC_URL or request.url_root.rstrip("/")


def _json(payload, status: int = 200) -> Response:
    r = jsonify(payload)
    r.status_code = status
    r.headers["Access-Control-Allow-Origin"] = "*"
    r.headers["Access-Control-Allow-Headers"] = "*"
    r.headers["Cache-Control"] = "no-store"
    return r


# ── Manifest ─────────────────────────────────────────────────────────────────
@app.route("/manifest.json")
def manifest():
    if CFG["ad_enabled"]:
        desc = ("Returns only streams AllDebrid already has cached, checked live "
                "against the AllDebrid API across every configured indexer.")
    else:
        desc = "AllDebrid provider disabled — torrents are returned unfiltered."
    return _json({
        "id": ADDON_ID,
        "version": ADDON_VERSION,
        "name": ADDON_NAME,
        "description": desc,
        "logo": "https://alldebrid.com/lib/images/default/logo_alldebrid.png",
        "resources": ["stream"],
        "types": ["movie", "series"],
        "idPrefixes": ["tt"],
        "catalogs": [],
        "behaviorHints": {"configurable": False, "configurationRequired": False},
    })


# ── Streams ──────────────────────────────────────────────────────────────────
# Loop detection. In topology A this addon reads from an AIOStreams config; if
# that config also lists this addon, every search recurses until something
# times out. Two independent guards, because neither alone is sufficient:
# the header only survives if the upstream forwards it, and the in-flight check
# only fires once the recursion has actually come back around.
_inflight: set[str] = set()
_inflight_lock = threading.Lock()


def _loop_detected(type_: str, sid: str) -> str:
    if request.headers.get(sources.LOOP_HEADER):
        return "request carries our own loop header"
    with _inflight_lock:
        if f"{type_}:{sid}" in _inflight:
            return "a search for this id is already in flight"
    return ""


@app.route("/stream/<type_>/<path:sid>.json")
def stream_route(type_: str, sid: str):
    t0 = time.time()
    sid = urllib.parse.unquote(sid)
    if type_ not in ("movie", "series") or not sid.startswith("tt"):
        return _json({"streams": []})

    why = _loop_detected(type_, sid)
    if why:
        log.error(
            f"[loop] refusing {type_}/{sid}: {why}. The AIOStreams config in "
            f"ADDONS almost certainly lists this addon — remove it from that "
            f"config (it belongs only in the config you install in Stremio)."
        )
        return _json({"streams": []})

    key = f"{type_}:{sid}"
    with _inflight_lock:
        _inflight.add(key)
    try:
        return _do_stream(type_, sid, t0)
    finally:
        with _inflight_lock:
            _inflight.discard(key)


def _do_stream(type_: str, sid: str, t0: float):
    candidates = sources.gather(CFG, type_, sid)
    if not candidates:
        return _json({"streams": []})

    candidates.sort(key=release.sort_key, reverse=True)

    if CFG["ad_enabled"] and CFG["ad_key"]:
        # Probe a multiple of what we'll show, since most of it won't be
        # cached. Each unseen hash costs one upload slot plus one delete.
        # Balanced across resolutions: taking the globally top N would probe
        # only 2160p on a well-seeded title, so no 1080p could ever come back
        # cached no matter how many were available.
        probe = release.balance(candidates,
                                CFG["max_results"] * CFG["probe_multiplier"])
        ready = ad.check_cache_ad(CFG["ad_key"], probe,
                                  keep_hashes=set(CFG["keep_hashes"]))
        for c in candidates:
            c["cached"] = bool(ready.get(c["info_hash"], False))
        if CFG["cached_only"]:
            candidates = [c for c in candidates if c["cached"]]
        else:
            candidates.sort(key=lambda c: (c["cached"], release.sort_key(c)),
                            reverse=True)
    else:
        for c in candidates:
            c["cached"] = False

    # Same reasoning as the probe set: spread the returned streams across
    # resolutions so a consumer asking for HD specifically isn't handed a
    # list that is entirely 2160p.
    candidates = release.balance(candidates, CFG["max_results"],
                                 per_res=CFG["max_per_resolution"])
    streams = [s for s in (_to_stream(c, type_, sid) for c in candidates) if s]
    log.info(f"[stream] {sid}: {len(streams)} stream(s) in {time.time()-t0:.1f}s")
    return _json({"streams": streams})


def _to_stream(c: dict, type_: str, sid: str) -> dict | None:
    res = release.resolution(c.get("name", "")) or "SD"
    tags = release.tags(c.get("name", ""))
    bits = [b for b in (release.human_size(c.get("size", 0)),
                        f"{c['seeders']}👤" if c.get("seeders") else "",
                        c.get("source", "")) if b]
    title = "\n".join([c.get("name", "")[:160], " · ".join(bits), " ".join(tags)]).strip()

    if not (CFG["ad_enabled"] and CFG["ad_key"]):
        out = {"name": f"[P2P] {res}", "title": title, "infoHash": c["info_hash"],
               "behaviorHints": {"bingeGroup": f"p2p-{res}"}}
        if isinstance(c.get("file_idx"), int):
            out["fileIdx"] = c["file_idx"]
        return out

    if not c.get("cached") and CFG["cached_only"]:
        return None

    parts = sid.split(":")
    sfx = f"{parts[1]}-{parts[2]}" if len(parts) > 2 else "0-0"
    fidx = c["file_idx"] if isinstance(c.get("file_idx"), int) else -1
    fname = base64.urlsafe_b64encode(
        (c.get("file_name") or "").encode()).decode().rstrip("=") or "-"
    return {
        "name": f"{'[AD+]' if c['cached'] else '[AD download]'} {res}",
        "title": title,
        "url": f"{base_url()}/resolve/{c['info_hash']}/{sfx}/{fidx}/{fname}",
        "behaviorHints": {
            "bingeGroup": f"ad-{res}-{'-'.join(tags[:2])}",
            "notWebReady": False,
            "filename": c.get("file_name") or c.get("name", ""),
            "videoSize": c.get("size") or None,
        },
    }


# ── Resolve ──────────────────────────────────────────────────────────────────
_resolve_cache: dict[str, tuple[str, float]] = {}
_resolve_lock = threading.Lock()


@app.route("/resolve/<hash_>/<sfx>/<int(signed=True):fidx>/<fname>")
def resolve_route(hash_: str, sfx: str, fidx: int, fname: str):
    hash_ = hash_.lower()
    if not re.fullmatch(r"[a-f0-9]{40}", hash_):
        return Response("bad hash", status=400)
    if not CFG["ad_key"]:
        return Response("no AllDebrid API key configured", status=503)

    ck = f"{hash_}:{sfx}:{fidx}:{fname}"
    now = time.time()
    with _resolve_lock:
        for k, (_, exp) in list(_resolve_cache.items()):
            if now >= exp:
                del _resolve_cache[k]
        hit = _resolve_cache.get(ck)
    if hit:
        return redirect(hit[0], code=302)

    season = episode = None
    s, _, e = sfx.partition("-")
    if s.isdigit() and e.isdigit() and int(s) > 0:
        season, episode = int(s), int(e)

    want_name = ""
    if fname and fname != "-":
        try:
            want_name = base64.urlsafe_b64decode(fname + "=" * (-len(fname) % 4)).decode()
        except Exception:
            pass

    key = CFG["ad_key"]
    m = ad.add_magnet(key, hash_)
    if m.get("error"):
        msg = m["error"].get("message", "upload failed")
        log.warning(f"[resolve] {hash_[:8]}: {msg}")
        return Response(f"AllDebrid: {msg}", status=502)

    ad_id = m.get("id")
    files = ad.list_files(key, ad_id) if m.get("ready") else []
    # A cache entry can lapse between the search and the click — give it a
    # short grace window before giving up.
    deadline = time.time() + READY_WAIT_SECONDS
    while not files and time.time() < deadline:
        time.sleep(2)
        files = ad.list_files(key, ad_id)
    if not files:
        return Response("Not cached on AllDebrid (it may still be downloading).",
                        status=503)

    chosen = release.pick_file(files, season, episode, want_name,
                               fidx if fidx >= 0 else None)
    if not chosen:
        return Response("No matching video file in this torrent.", status=404)

    direct = ad.unlock(key, chosen["link"])
    if not direct:
        return Response("AllDebrid could not unlock this link.", status=502)

    with _resolve_lock:
        _resolve_cache[ck] = (direct, time.time() + RESOLVE_TTL)
    if DELETE_AFTER_RESOLVE and ad_id and hash_ not in CFG["keep_hashes"]:
        ad._pool.submit(ad.ad_delete, key, ad_id)

    log.info(f"[resolve] {hash_[:8]} -> {chosen['name'][:60]}")
    return redirect(direct, code=302)


# ── Ops ──────────────────────────────────────────────────────────────────────
@app.route("/")
@app.route("/health")
def health():
    n_src = (len(CFG["addons"]) + len(CFG["torznab"])
             + (1 if CFG["prowlarr_url"] and CFG["prowlarr_key"] else 0))
    return _json({
        "status": "ok",
        "version": ADDON_VERSION,
        "install_url": f"{base_url()}/manifest.json",
        "alldebrid": {"enabled": CFG["ad_enabled"],
                      "key_set": bool(CFG["ad_key"]),
                      "cached_only": CFG["cached_only"]},
        "sources": n_src,
        "cache": ad.cache_stats(),
    })


@app.after_request
def cors(resp):
    resp.headers.setdefault("Access-Control-Allow-Origin", "*")
    return resp


def _startup_check():
    if CFG["ad_enabled"] and CFG["ad_key"]:
        ok, msg = ad.check_key(CFG["ad_key"])
        log.info(f"[startup] AllDebrid: {msg}") if ok else log.error(f"[startup] AllDebrid: {msg}")
    elif CFG["ad_enabled"]:
        log.warning("[startup] ALLDEBRID_ENABLED is true but no API key is set")
    # Guard against pointing this addon back at itself through AIOStreams.
    for a in CFG["addons"]:
        if PUBLIC_URL and PUBLIC_URL in a:
            log.error(f"[startup] {a} points at this addon — that is a request loop")
        if "/stremio/" in a:
            log.info(f"[startup] reading from an AIOStreams config: {a.split('/stremio/')[0]} "
                     "— make sure that config does NOT list this addon, and has "
                     "every debrid service switched off")
    log.info(f"[startup] addons={len(CFG['addons'])} torznab={len(CFG['torznab'])} "
             f"prowlarr={'yes' if CFG['prowlarr_url'] else 'no'}")


if __name__ == "__main__":
    _startup_check()
    port = int(os.environ.get("PORT", "7000"))
    from waitress import serve
    log.info(f"{ADDON_NAME} v{ADDON_VERSION} on :{port}")
    serve(app, host="0.0.0.0", port=port,
          threads=int(os.environ.get("SERVER_THREADS", "16")))
