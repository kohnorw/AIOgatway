"""AllDebrid cached-only Stremio addon — drop-in for an existing AIOStreams.

Configured entirely from the environment, so the install URL is just
    http://<host>:7000/manifest.json
with no config blob to generate. Add that as a custom addon in AIOStreams.

It queries every indexer you point it at, de-duplicates by info hash, runs the
survivors through the AllDebrid cache check (magnet/upload → ready → delete,
the same method alldebrid-web uses), and returns only what is already cached.
"""

import base64
import logging
import os
import re
import threading
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

from flask import Flask, Response, jsonify, redirect, request

import alldebrid as ad
import release
import sources

logging.basicConfig(
    level=os.environ.get("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("addon")

app = Flask(__name__)

ADDON_ID      = "community.alldebrid.cached"
ADDON_NAME    = os.environ.get("ADDON_NAME", "AllDebrid Cached")
ADDON_VERSION = "2.0.0"
PUBLIC_URL    = os.environ.get("PUBLIC_URL", "").rstrip("/")

READY_WAIT_SECONDS   = int(os.environ.get("AD_READY_WAIT_SECONDS", "20"))
DELETE_AFTER_RESOLVE = os.environ.get("AD_DELETE_AFTER_RESOLVE", "false").lower() == "true"
RESOLVE_TTL          = int(os.environ.get("RESOLVE_TTL", "3600"))


def _csv(name: str, default: str = "") -> list[str]:
    return [v.strip() for v in os.environ.get(name, default).split(",") if v.strip()]


CFG = {
    "ad_key": os.environ.get("ALLDEBRID_API_KEY", ""),
    "ad_enabled": os.environ.get("ALLDEBRID_ENABLED", "true").lower() == "true",
    "cached_only": os.environ.get("CACHED_ONLY", "true").lower() == "true",
    # Indexer sources — any combination.
    "addons": _csv("ADDONS", "https://torrentio.strem.fun"),
    "prowlarr_url": os.environ.get("PROWLARR_URL", ""),
    "prowlarr_key": os.environ.get("PROWLARR_API_KEY", ""),
    # TORZNAB=https://jackett:9117/api/v2.0/indexers/all/results/torznab/api|apikey,...
    "torznab": _csv("TORZNAB"),
    "max_results": max(1, min(int(os.environ.get("MAX_RESULTS", "20")), 100)),
    "probe_multiplier": max(1, int(os.environ.get("PROBE_MULTIPLIER", "3"))),
    # 0 = no cap. Otherwise the most streams any one resolution may occupy.
    "max_per_resolution": int(os.environ.get("MAX_PER_RESOLUTION", "0")),
    # Resolution bounds, inclusive. "" = unbounded. Accepts 1080p, 1080, 4k...
    "min_quality": os.environ.get("MIN_QUALITY", ""),
    "max_quality": os.environ.get("MAX_QUALITY", ""),
    "allow_unknown_quality": os.environ.get("ALLOW_UNKNOWN_QUALITY", "true").lower() == "true",
    "keep_hashes": [h.lower() for h in _csv("KEEP_HASHES")],
}


def base_url() -> str:
    return PUBLIC_URL or request.url_root.rstrip("/")


def _json(payload, status: int = 200) -> Response:
    r = jsonify(payload)
    r.status_code = status
    r.headers["Access-Control-Allow-Origin"] = "*"
    r.headers["Access-Control-Allow-Headers"] = "*"
    r.headers["Cache-Control"] = "no-store"
    return r


# ── Manifest ─────────────────────────────────────────────────────────────────
@app.route("/manifest.json")
def manifest():
    if CFG["ad_enabled"]:
        desc = ("Returns only streams AllDebrid already has cached, checked live "
                "against the AllDebrid API across every configured indexer.")
    else:
        desc = "AllDebrid provider disabled — torrents are returned unfiltered."
    return _json({
        "id": ADDON_ID,
        "version": ADDON_VERSION,
        "name": ADDON_NAME,
        "description": desc,
        "logo": "https://alldebrid.com/lib/images/default/logo_alldebrid.png",
        "resources": ["stream"],
        "types": ["movie", "series"],
        "idPrefixes": ["tt"],
        "catalogs": [],
        "behaviorHints": {"configurable": False, "configurationRequired": False},
    })


# ── Streams ──────────────────────────────────────────────────────────────────
# Loop detection. In topology A this addon reads from an AIOStreams config; if
# that config also lists this addon, every search recurses until something
# times out. Two independent guards, because neither alone is sufficient:
# the header only survives if the upstream forwards it, and the in-flight check
# only fires once the recursion has actually come back around.
_inflight: set[str] = set()
_inflight_lock = threading.Lock()


def _loop_detected(type_: str, sid: str) -> str:
    if request.headers.get(sources.LOOP_HEADER):
        return "request carries our own loop header"
    with _inflight_lock:
        if f"{type_}:{sid}" in _inflight:
            return "a search for this id is already in flight"
    return ""


@app.route("/stream/<type_>/<path:sid>.json")
def stream_route(type_: str, sid: str):
    t0 = time.time()
    sid = urllib.parse.unquote(sid)
    if type_ not in ("movie", "series") or not sid.startswith("tt"):
        return _json({"streams": []})

    why = _loop_detected(type_, sid)
    if why:
        log.error(
            f"[loop] refusing {type_}/{sid}: {why}. The AIOStreams config in "
            f"ADDONS almost certainly lists this addon — remove it from that "
            f"config (it belongs only in the config you install in Stremio)."
        )
        return _json({"streams": []})

    key = f"{type_}:{sid}"
    with _inflight_lock:
        _inflight.add(key)
    try:
        return _do_stream(type_, sid, t0)
    finally:
        with _inflight_lock:
            _inflight.discard(key)


def _do_stream(type_: str, sid: str, t0: float):
    candidates = sources.gather(CFG, type_, sid)
    if not candidates:
        return _json({"streams": []})

    if CFG["min_quality"] or CFG["max_quality"]:
        before = len(candidates)
        candidates = release.filter_quality(
            candidates, CFG["min_quality"], CFG["max_quality"],
            CFG["allow_unknown_quality"])
        log.info(f"[quality] {before} → {len(candidates)} within "
                 f"{CFG['min_quality'] or 'any'}..{CFG['max_quality'] or 'any'}")
        if not candidates:
            return _json({"streams": []})

    candidates.sort(key=release.sort_key, reverse=True)

    if CFG["ad_enabled"] and CFG["ad_key"]:
        # Probe a multiple of what we'll show, since most of it won't be
        # cached. Each unseen hash costs one upload slot plus one delete.
        # Balanced across resolutions: taking the globally top N would probe
        # only 2160p on a well-seeded title, so no 1080p could ever come back
        # cached no matter how many were available.
        probe = release.balance(candidates,
                                CFG["max_results"] * CFG["probe_multiplier"])
        ready = ad.check_cache_ad(CFG["ad_key"], probe,
                                  keep_hashes=set(CFG["keep_hashes"]))
        for c in candidates:
            c["cached"] = bool(ready.get(c["info_hash"], False))
        if CFG["cached_only"]:
            candidates = [c for c in candidates if c["cached"]]
        else:
            candidates.sort(key=lambda c: (c["cached"], release.sort_key(c)),
                            reverse=True)
    else:
        for c in candidates:
            c["cached"] = False

    # Same reasoning as the probe set: spread the returned streams across
    # resolutions so a consumer asking for HD specifically isn't handed a
    # list that is entirely 2160p.
    candidates = release.balance(candidates, CFG["max_results"],
                                 per_res=CFG["max_per_resolution"])
    streams = [s for s in (_to_stream(c, type_, sid) for c in candidates) if s]
    _queue_prewarm(candidates, sid)
    log.info(f"[stream] {sid}: {len(streams)} stream(s) in {time.time()-t0:.1f}s")
    return _json({"streams": streams})


def _to_stream(c: dict, type_: str, sid: str) -> dict | None:
    res = release.resolution(c.get("name", "")) or "SD"
    tags = release.tags(c.get("name", ""))
    bits = [b for b in (release.human_size(c.get("size", 0)),
                        f"{c['seeders']}👤" if c.get("seeders") else "",
                        c.get("source", "")) if b]
    title = "\n".join([c.get("name", "")[:160], " · ".join(bits), " ".join(tags)]).strip()

    if not (CFG["ad_enabled"] and CFG["ad_key"]):
        out = {"name": f"[P2P] {res}", "title": title, "infoHash": c["info_hash"],
               "behaviorHints": {"bingeGroup": f"p2p-{res}"}}
        if isinstance(c.get("file_idx"), int):
            out["fileIdx"] = c["file_idx"]
        return out

    if not c.get("cached") and CFG["cached_only"]:
        return None

    parts = sid.split(":")
    sfx = f"{parts[1]}-{parts[2]}" if len(parts) > 2 else "0-0"
    fidx = c["file_idx"] if isinstance(c.get("file_idx"), int) else -1
    fname = base64.urlsafe_b64encode(
        (c.get("file_name") or "").encode()).decode().rstrip("=") or "-"
    return {
        "name": f"{'[AD+]' if c['cached'] else '[AD download]'} {res}",
        "title": title,
        "url": f"{base_url()}/resolve/{c['info_hash']}/{sfx}/{fidx}/{fname}",
        "behaviorHints": {
            "bingeGroup": f"ad-{res}-{'-'.join(tags[:2])}",
            "notWebReady": False,
            "filename": c.get("file_name") or c.get("name", ""),
            "videoSize": c.get("size") or None,
        },
    }


# ── Resolve ──────────────────────────────────────────────────────────────────
_resolve_cache: dict[str, tuple[str, float]] = {}
_resolve_lock = threading.Lock()

# Prewarming. Resolving on click costs three sequential AllDebrid calls
# (upload, files, unlock) plus rate-limit spacing. The cache check deletes its
# probe magnets, so a click re-uploads from scratch and AllDebrid needs a
# moment to re-register the magnet before magnet/files returns anything —
# long enough that some players give up, and the stream then plays on the
# second try only because the link is cached by then. Resolving the top few
# cached results in the background as soon as the search returns means the
# link is usually already waiting when the user clicks.
PREWARM_COUNT = int(os.environ.get("PREWARM_COUNT", "3"))
_prewarm_pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="prewarm")
_prewarming: set[str] = set()

# Reaper for unclicked prewarms.
#
# The cache check deletes its own probe magnets, but a prewarm deliberately
# leaves its magnet in place — that is the whole point, the link has to still
# be there when the user clicks. Most prewarms are never clicked, so without
# this they accumulate in the AllDebrid library at PREWARM_COUNT per search.
#
# Entries live here only while unclaimed. A real click promotes the magnet out
# of the map, so the reaper can never delete something being streamed. A
# magnet is also left alone if any other prewarm still references it, which
# happens when the same release is offered for several episodes.
PREWARM_TTL = int(os.environ.get("PREWARM_TTL", "600"))
_REAP_INTERVAL = 60

# ck -> (ad_id, hash, added_at)
_prewarmed: dict[str, tuple[int, str, float]] = {}


def _claim_prewarm(ck: str) -> None:
    """Mark a prewarmed magnet as in use so the reaper leaves it alone."""
    with _resolve_lock:
        _prewarmed.pop(ck, None)


def _reap_prewarms() -> int:
    """Delete prewarmed magnets nobody clicked. Returns how many were removed."""
    if not (CFG["ad_enabled"] and CFG["ad_key"]):
        return 0
    now = time.time()
    with _resolve_lock:
        expired = [(ck, aid, h) for ck, (aid, h, at) in _prewarmed.items()
                   if now - at > PREWARM_TTL]
        for ck, _, _ in expired:
            _prewarmed.pop(ck, None)
        # Don't delete a magnet another live prewarm still points at.
        still_held = {h for (_, h, _) in _prewarmed.values()}
    removed = 0
    for ck, ad_id, h in expired:
        if h in still_held or h in CFG["keep_hashes"]:
            continue
        ad.ad_delete(CFG["ad_key"], ad_id)
        removed += 1
    if removed:
        log.info(f"[reaper] removed {removed} unclicked prewarm(s)")
    return removed


def _reaper_loop():
    while True:
        time.sleep(_REAP_INTERVAL)
        try:
            _reap_prewarms()
        except Exception as e:
            log.warning(f"[reaper] {e}")


def _resolve_key(hash_: str, season, episode, want_name: str, fidx: int) -> str:
    return f"{hash_}:{season}-{episode}:{fidx}:{want_name}"


def _resolve_link(hash_: str, season, episode, want_name: str, fidx: int,
                  track: bool = False):
    """Shared by the click path and the prewarmer. Returns (link, error).

    track=True records the magnet as an unclaimed prewarm, so the reaper can
    remove it later if it is never played.
    """
    ck = _resolve_key(hash_, season, episode, want_name, fidx)
    now = time.time()
    with _resolve_lock:
        hit = _resolve_cache.get(ck)
        if hit and now < hit[1]:
            return hit[0], None

    key = CFG["ad_key"]
    m = ad.add_magnet(key, hash_)
    if m.get("error"):
        return None, m["error"].get("message", "upload failed")

    ad_id = m.get("id")
    files = ad.list_files(key, ad_id)
    # Poll fast at first: this is almost always satisfied within a second,
    # and the old flat 2s sleep was itself most of the first-click delay.
    deadline = time.time() + READY_WAIT_SECONDS
    delay = 0.25
    while not files and time.time() < deadline:
        time.sleep(delay)
        delay = min(delay * 1.6, 2.0)
        files = ad.list_files(key, ad_id)
    if not files:
        return None, "not cached"

    chosen = release.pick_file(files, season, episode, want_name,
                               fidx if fidx >= 0 else None)
    if not chosen:
        return None, "no matching video file"

    direct = ad.unlock(key, chosen["link"])
    if not direct:
        return None, "unlock failed"

    with _resolve_lock:
        _resolve_cache[ck] = (direct, time.time() + RESOLVE_TTL)
        if track and ad_id:
            _prewarmed[ck] = (ad_id, hash_, time.time())
    if DELETE_AFTER_RESOLVE and ad_id and hash_ not in CFG["keep_hashes"]:
        ad._pool.submit(ad.ad_delete, key, ad_id)
    return direct, None


def _prewarm(ck: str, hash_: str, season, episode, want_name: str, fidx: int):
    try:
        link, err = _resolve_link(hash_, season, episode, want_name, fidx,
                                  track=True)
        log.info(f"[prewarm] {hash_[:8]}: {'ready' if link else err}")
    except Exception as e:
        log.debug(f"[prewarm] {hash_[:8]}: {e}")
    finally:
        with _resolve_lock:
            _prewarming.discard(ck)


def _queue_prewarm(candidates: list, sid: str):
    if PREWARM_COUNT <= 0 or not (CFG["ad_enabled"] and CFG["ad_key"]):
        return
    parts = sid.split(":")
    season = int(parts[1]) if len(parts) > 2 else None
    episode = int(parts[2]) if len(parts) > 2 else None
    for c in candidates[:PREWARM_COUNT]:
        if not c.get("cached"):
            continue
        fidx = c["file_idx"] if isinstance(c.get("file_idx"), int) else -1
        want = c.get("file_name") or ""
        ck = _resolve_key(c["info_hash"], season, episode, want, fidx)
        with _resolve_lock:
            hit = _resolve_cache.get(ck)
            if (hit and time.time() < hit[1]) or ck in _prewarming:
                continue
            _prewarming.add(ck)
        _prewarm_pool.submit(_prewarm, ck, c["info_hash"], season, episode,
                             want, fidx)


@app.route("/resolve/<hash_>/<sfx>/<int(signed=True):fidx>/<fname>")
def resolve_route(hash_: str, sfx: str, fidx: int, fname: str):
    hash_ = hash_.lower()
    if not re.fullmatch(r"[a-f0-9]{40}", hash_):
        return Response("bad hash", status=400)
    if not CFG["ad_key"]:
        return Response("no AllDebrid API key configured", status=503)

    season = episode = None
    s, _, e = sfx.partition("-")
    if s.isdigit() and e.isdigit() and int(s) > 0:
        season, episode = int(s), int(e)

    want_name = ""
    if fname and fname != "-":
        try:
            want_name = base64.urlsafe_b64decode(fname + "=" * (-len(fname) % 4)).decode()
        except Exception:
            pass

    t0 = time.time()
    # Claim before resolving: if this was prewarmed, the magnet is now in use
    # and must not be reaped while it is being streamed.
    _claim_prewarm(_resolve_key(hash_, season, episode, want_name, fidx))
    link, err = _resolve_link(hash_, season, episode, want_name, fidx)
    if not link:
        log.warning(f"[resolve] {hash_[:8]}: {err}")
        status = 503 if err == "not cached" else (404 if "no matching" in err else 502)
        return Response(f"AllDebrid: {err}", status=status)

    log.info(f"[resolve] {hash_[:8]} in {time.time()-t0:.2f}s")
    return redirect(link, code=302)


# ── Ops ──────────────────────────────────────────────────────────────────────
@app.route("/")
@app.route("/health")
def health():
    n_src = (len(CFG["addons"]) + len(CFG["torznab"])
             + (1 if CFG["prowlarr_url"] and CFG["prowlarr_key"] else 0))
    return _json({
        "status": "ok",
        "version": ADDON_VERSION,
        "install_url": f"{base_url()}/manifest.json",
        "alldebrid": {"enabled": CFG["ad_enabled"],
                      "key_set": bool(CFG["ad_key"]),
                      "cached_only": CFG["cached_only"]},
        "sources": n_src,
        "quality": {"min": CFG["min_quality"] or "any",
                    "max": CFG["max_quality"] or "any",
                    "allow_unknown": CFG["allow_unknown_quality"]},
        "cache": ad.cache_stats(),
        "prewarm": {"count": PREWARM_COUNT, "ttl": PREWARM_TTL,
                    "unclaimed": len(_prewarmed)},
    })


@app.after_request
def cors(resp):
    resp.headers.setdefault("Access-Control-Allow-Origin", "*")
    return resp


def _startup_check():
    if CFG["ad_enabled"] and CFG["ad_key"]:
        ok, msg = ad.check_key(CFG["ad_key"])
        log.info(f"[startup] AllDebrid: {msg}") if ok else log.error(f"[startup] AllDebrid: {msg}")
    elif CFG["ad_enabled"]:
        log.warning("[startup] ALLDEBRID_ENABLED is true but no API key is set")
    # Guard against pointing this addon back at itself through AIOStreams.
    for a in CFG["addons"]:
        if PUBLIC_URL and PUBLIC_URL in a:
            log.error(f"[startup] {a} points at this addon — that is a request loop")
        if "/stremio/" in a:
            log.info(f"[startup] reading from an AIOStreams config: {a.split('/stremio/')[0]} "
                     "— make sure that config does NOT list this addon, and has "
                     "every debrid service switched off")
    for k in ("min_quality", "max_quality"):
        if CFG[k] and not release.parse_quality(CFG[k]):
            log.error(f"[startup] {k.upper()}={CFG[k]!r} not recognised — "
                      f"ignored. Use one of {', '.join(release.QUALITY_ORDER)}")
    if CFG["ad_enabled"] and CFG["ad_key"]:
        try:
            n = len(ad.list_magnets(CFG["ad_key"]))
            msg = f"[startup] AllDebrid library: {n}/1000 magnets"
            log.warning(msg + " — near the ceiling, POST /purge to free space") \
                if n > 800 else log.info(msg)
        except Exception as e:
            log.debug(f"[startup] library check: {e}")
    log.info(f"[startup] addons={len(CFG['addons'])} torznab={len(CFG['torznab'])} "
             f"prowlarr={'yes' if CFG['prowlarr_url'] else 'no'}")


@app.route("/purge", methods=["POST"])
def purge_now():
    """Free space in a full AllDebrid library. ?limit=N caps how many go."""
    if not CFG["ad_key"]:
        return _json({"error": "no api key"}, 503)
    limit = request.args.get("limit", type=int) or 0
    return _json(ad.purge(CFG["ad_key"], keep_hashes=set(CFG["keep_hashes"]),
                          limit=limit))


@app.route("/library")
def library():
    if not CFG["ad_key"]:
        return _json({"error": "no api key"}, 503)
    mags = ad.list_magnets(CFG["ad_key"])
    return _json({"count": len(mags), "limit": 1000,
                  "pending_deletes": ad.pending_deletes()})


@app.route("/reap", methods=["POST"])
def reap_now():
    """Manually clear unclicked prewarms without waiting for the timer."""
    return _json({"removed": _reap_prewarms(), "unclaimed": len(_prewarmed)})


if __name__ == "__main__":
    _startup_check()
    if PREWARM_COUNT > 0:
        threading.Thread(target=_reaper_loop, daemon=True).start()
        log.info(f"[startup] reaper on: unclicked prewarms removed after {PREWARM_TTL}s")
    port = int(os.environ.get("PORT", "7000"))
    from waitress import serve
    log.info(f"{ADDON_NAME} v{ADDON_VERSION} on :{port}")
    serve(app, host="0.0.0.0", port=port,
          threads=int(os.environ.get("SERVER_THREADS", "16")))
