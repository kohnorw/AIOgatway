"""Release-name parsing: quality tags, sorting, and picking the right file
out of a season pack."""

import re

RES_PATTERNS = [
    ("2160p", r"\b(2160p|4k|uhd)\b"),
    ("1080p", r"\b1080[pi]\b"),
    ("720p",  r"\b720[pi]\b"),
    ("576p",  r"\b576[pi]\b"),
    ("480p",  r"\b480[pi]\b"),
]
RES_RANK = {"2160p": 5, "1080p": 4, "720p": 3, "576p": 2, "480p": 1, "": 0}

TAG_PATTERNS = [
    ("REMUX",     r"\bremux\b"),
    ("BluRay",    r"\b(blu-?ray|bdrip|brrip)\b"),
    ("WEB-DL",    r"\bweb[-. ]?dl\b"),
    ("WEBRip",    r"\bweb-?rip\b"),
    ("HDR10+",    r"\bhdr10\+\b"),
    ("HDR",       r"\bhdr\b"),
    ("DV",        r"\b(dolby[-. ]?vision|\bdv\b)\b"),
    ("HEVC",      r"\b(hevc|[hx]\.?265)\b"),
    ("H264",      r"\b([hx]\.?264|avc)\b"),
    ("Atmos",     r"\batmos\b"),
    ("TrueHD",    r"\btrue-?hd\b"),
    ("DTS-HD",    r"\bdts-?hd\b"),
    ("DDP",       r"\b(ddp|e-?ac-?3|dd\+)\b"),
    ("CAM",       r"\b(cam|ts|telesync|hdcam)\b"),
]

VIDEO_EXT = (".mkv", ".mp4", ".avi", ".m4v", ".mov", ".ts", ".wmv", ".mpg", ".mpeg", ".webm")
JUNK_RE = re.compile(r"\b(sample|trailer|extras?|featurette|behind\.?the\.?scenes|rarbg|proof)\b", re.I)


def resolution(name: str) -> str:
    n = name.lower()
    for label, pat in RES_PATTERNS:
        if re.search(pat, n):
            return label
    return ""


def tags(name: str) -> list[str]:
    n = name.lower()
    return [label for label, pat in TAG_PATTERNS if re.search(pat, n)]


def human_size(n: int) -> str:
    if not n:
        return ""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.2f} {unit}".replace(".00 ", " ")
        n /= 1024
    return ""


def episode_regexes(season: int, episode: int) -> list[re.Pattern]:
    s, e = season, episode
    return [
        re.compile(rf"s0*{s}\s*[.\-_ ]?\s*e0*{e}(?!\d)", re.I),
        re.compile(rf"(?<!\d)0*{s}x0*{e}(?!\d)", re.I),
        re.compile(rf"season\s*0*{s}.{{0,12}}episode\s*0*{e}(?!\d)", re.I),
        re.compile(rf"(?<!\d)e0*{e}(?!\d)", re.I),  # last resort, season dir implied
    ]


def matches_episode(name: str, season: int, episode: int) -> int:
    """Return a confidence score 0-4; 0 means no match."""
    for i, rx in enumerate(episode_regexes(season, episode)):
        if rx.search(name):
            return 4 - i
    return 0


def pick_file(files: list[dict], season=None, episode=None,
              want_name: str = "", file_idx=None) -> dict | None:
    """Choose the playable file from a magnet's file list.

    Order of preference: exact filename the upstream told us about → the
    upstream's fileIdx → the SxxEyy match → the largest video file.
    """
    vids = [f for f in files if f["name"].lower().endswith(VIDEO_EXT)
            and not JUNK_RE.search(f["name"])]
    if not vids:
        vids = [f for f in files if f["name"].lower().endswith(VIDEO_EXT)] or files
    if not vids:
        return None

    if want_name:
        wn = want_name.lower()
        for f in vids:
            if f["name"].lower() == wn or f["path"].lower().endswith(wn):
                return f

    if season is not None and episode is not None:
        scored = [(matches_episode(f["path"], season, episode), f["size"], f) for f in vids]
        scored = [s for s in scored if s[0] > 0]
        if scored:
            scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
            return scored[0][2]
        # A season pack with no episode match is the wrong torrent for this
        # episode — don't silently hand back episode 1.
        if len(vids) > 1:
            return None

    if isinstance(file_idx, int) and 0 <= file_idx < len(files):
        cand = files[file_idx]
        if cand in vids:
            return cand

    return max(vids, key=lambda f: f["size"])


def sort_key(t: dict) -> tuple:
    """Best first: resolution, then size, then seeders."""
    return (RES_RANK.get(resolution(t.get("name", "")), 0),
            t.get("size", 0),
            t.get("seeders", 0))
