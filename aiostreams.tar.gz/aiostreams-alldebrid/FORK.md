# AIOStreams: AllDebrid cached-only fork

Adds a native AllDebrid service (`packages/core/src/debrid/alldebrid.ts`) in place of the
StremThru route for AllDebrid.

## Why
Through StremThru, AIOStreams only sees a crowd-sourced approximation of AllDebrid's cache.
This service asks AllDebrid directly, using the same lookup as the original alldebrid-web
project (`GET /v4/magnet/instant`, `magnets[]` params).

## Check methods (`BUILTIN_ALLDEBRID_CHECK_METHOD`)
- `instant` (default): read-only. Nothing is added to your account. Hashes are checked in
  batches of 40; file lists come back in the same response, so the right episode is picked
  without extra calls.
- `upload` (opt-in fallback): for use only if `instant` stops working. Reads your library, uploads
  unknown hashes in chunks of 10, reads `ready`, fetches files, then deletes everything it
  added (in a `finally`, with retries). Your own library items are never uploaded or deleted.
  Capped by `BUILTIN_ALLDEBRID_CHECK_MAX_HASHES`.

Results are cached (cached: `BUILTIN_DEBRID_INSTANT_AVAILABILITY_CACHE_TTL`, uncached:
`BUILTIN_ALLDEBRID_UNCACHED_TTL`). API errors are never cached as "uncached" and surface as an
error stream.

## Cached-only (default on: `BUILTIN_ALLDEBRID_CACHED_ONLY=true`)
- Streams: anything not confirmed cached is dropped in `processTorrentsForDebridService`.
  A library item only counts if AllDebrid reports it ready.
- Playback: the magnet is added by hash only (no trackers or private-tracker passkeys). If it
  is not ready it is deleted immediately and playback fails with "Not cached on AllDebrid".
  It never waits for or queues a download, and `cacheAndPlay` is ignored for AllDebrid.

## Scope
Applies to the built-in addons (TPB, Knaben, Torznab, Prowlarr, ...) that AIOStreams checks
against your debrid account. External addons (Torrentio, Comet, ...) do their own checks and are
unchanged; AIOStreams still shows whatever cached flag they report.

## Caveats
- `instant` is the endpoint the original project uses. Some third-party clients report AllDebrid
  removed it; if your checks start failing or everything reports uncached, switch to `upload`.
- Not verified against the live AllDebrid API from where this was built; tests use a fake server.
- To play a cached torrent the magnet must still be added to your account (AllDebrid only issues
  links for account magnets). Cached magnets are ready instantly; use AIOStreams'
  auto-remove-downloads option if you don't want them left in your library.

## Configuring
Add the key in the configure page's Services section; nothing else is required. The optional
operator settings live in Dashboard -> Settings -> Built-ins -> Debrid. Env vars
(`BUILTIN_ALLDEBRID_*`) also work but lock the matching dashboard field.

## Build
    docker build -t aiostreams-alldebrid .
    docker compose -f compose.fork.yaml up -d --build

## Tests
    pnpm -F core test        # includes src/debrid/alldebrid.test.ts
