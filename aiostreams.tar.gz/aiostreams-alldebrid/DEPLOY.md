# Deploy: AIOStreams + AllDebrid cached-only

Upstream: https://github.com/Viren070/AIOStreams (commit 0a440cb, v2.34.1) plus the AllDebrid
changes described in FORK.md. Everything needed to build the image is in this folder.

## 1. Configure
    cp .env.sample .env
Edit `.env` and set at least:
- `BASE_URL`   your public URL, e.g. https://aiostreams.example.com (no trailing slash)
- `SECRET_KEY` 64 hex chars: `openssl rand -hex 32`. Do not change it after first run.

## 2. Build and run (needs Docker + the compose plugin)
    docker compose -f compose.fork.yaml up -d --build
The first build takes several minutes (it compiles from source). Then open
http://<host>:3000/stremio/configure

## 3. Set up in AIOStreams (no env vars needed)
1. Open `http://<host>:3000/stremio/configure` and pick the template **AllDebrid Cached-Only**.
2. Under **Services**, enable **AllDebrid** and paste your API key
   (https://alldebrid.com/apikeys). Every indexer in the template uses it automatically
   (they show up as "Knaben AD", "The Pirate Bay AD", ...).
3. Enter a free TMDB API key when prompted (https://www.themoviedb.org/settings/api). AIOStreams
   needs it to look up titles for title/year matching.
4. Save, then install the manifest URL in Stremio.

The template includes Knaben, The Pirate Bay, EZTV and TheRARBG (no setup needed) and also
excludes uncached AllDebrid results at the user level. To use your own indexers instead, add any
built-in addon (Torznab, Prowlarr, ...); with no service override it uses AllDebrid
automatically.

## 4. Optional: tune it from the dashboard
Dashboard -> Settings -> Built-ins -> Debrid (the dashboard needs the `admin` permission; see
OPERATOR AUTHENTICATION in `.env`). Settings: AllDebrid cached-only, check method
(`instant` / `upload`), max hashes (upload only), max requests per second, uncached TTL.
They are editable there as long as you have NOT also set the matching `BUILTIN_ALLDEBRID_*`
variable in `.env` or compose (an env-set value is locked/read-only in the dashboard).

## If searches come back blank the first few times, then work
This is expected under the old defaults, not random flakiness: checking hundreds of candidate
torrents against AllDebrid (upload, check, delete - one round trip per hash) can take longer
than a single addon fetch's timeout for a popular title. When that timeout fires, the *request*
gives up, but the check keeps running server-side in the background and warms a cache that a
later retry benefits from - which is why it eventually works, just not on the first try.

The template's built-in indexers now default to a 25s timeout instead of 7s, which should let a
cold-cache check finish in one pass. If you're on an older saved config, raise it yourself:
configure page -> each indexer (Knaben, The Pirate Bay, EZTV, TheRARBG) -> Timeout (ms) -> 20000
or higher. If large titles are still slow, also try lowering `BUILTIN_ALLDEBRID_CHECK_MAX_HASHES`
(default 50) to check fewer candidates, trading completeness for speed.

## Verify it is working
    docker logs -f aiostreams
Search a title in Stremio, then check the log for `debrid:alldebrid` lines. If checks error or
everything shows uncached, check the logs for AllDebrid API errors (rate limits, expired key).
`instant` is a legacy check method AllDebrid has removed from its API - leave the method on
`upload`, its default.

## Fast deploy (pre-built, for repeat/fleet deployments)
`aiostreams-alldebrid-fast-deploy.tar.gz` ships the same fork already built (frontend,
server, core) with production `node_modules` installed, so `docker build` skips
`pnpm install` and the TypeScript/frontend build entirely.
    tar -xzf aiostreams-alldebrid-fast-deploy.tar.gz && cd aiostreams-alldebrid
    cp .env.sample .env   # same as above: set BASE_URL and SECRET_KEY
    docker compose -f compose.fast.yaml up -d --build
The only thing `docker build` still compiles is one native module (`yencode`, used for
Usenet), which must match your server's exact Node version and needs outbound access to
nodejs.org during the build. See `prebuilt/BUILD_INFO.txt` for exactly what's pre-built.
This was built for linux/x86_64 (glibc) - it will not work on ARM or Alpine/musl hosts.

## Update / rollback
Rebuild after changing source: `docker compose -f compose.fork.yaml up -d --build`.
Your data lives in `./data` (keep it, and keep the same SECRET_KEY).
