"""
gateway/plex_scan.py
~~~~~~~~~~~~~~~~~~~~
Triggers scoped Plex partial scans for just the folders that changed (a new
entry was added, rebound to another torrent, or removed), so Plex notices
without waiting for its periodic full scan. Calls are debounced and
coalesced, so adding a whole season results in a single scan.

  GET /library/sections/{id}/refresh?path={folder}&X-Plex-Token={token}
"""
from __future__ import annotations

import logging
import os
import threading
import time
from typing import Optional

import requests

log = logging.getLogger("aiogateway.plexscan")

_REQUEST_TIMEOUT = 5

# Cache of {mount-prefix-path-on-plex : section_id} so we don't have to
# call /library/sections on every single resolution.
_section_cache: dict[str, int] = {}
_section_cache_lock = threading.Lock()
_section_cache_ttl = 300   # seconds
_section_cache_at: float = 0


def _plex_config() -> Optional[tuple[str, str]]:
    url   = os.environ.get("PLEX_URL", "").rstrip("/")
    token = os.environ.get("PLEX_TOKEN", "")
    if not url or not token:
        return None
    return url, token


def _refresh_section_cache(plex_url: str, token: str) -> None:
    """Populate _section_cache: library content-root path → section id."""
    global _section_cache_at
    try:
        r = requests.get(
            f"{plex_url}/library/sections",
            params={"X-Plex-Token": token},
            headers={"Accept": "application/json"},
            timeout=_REQUEST_TIMEOUT,
        )
        if r.status_code != 200:
            log.warning("plex /library/sections returned %d", r.status_code)
            return
        data = r.json()
        dirs = data.get("MediaContainer", {}).get("Directory", [])
        with _section_cache_lock:
            _section_cache.clear()
            for d in dirs:
                sid = d.get("key")
                for loc in d.get("Location", []):
                    path = loc.get("path")
                    if path and sid is not None:
                        _section_cache[path] = int(sid)
            _section_cache_at = time.time()
        log.info("Plex section cache refreshed: %s", _section_cache)
    except Exception as exc:
        log.warning("Could not refresh Plex section cache: %s", exc)


def _section_id_for_path(plex_url: str, token: str, folder: str) -> Optional[int]:
    """Find the library section whose content root is a prefix of `folder`."""
    global _section_cache_at
    with _section_cache_lock:
        stale = (time.time() - _section_cache_at) > _section_cache_ttl
        cache_snapshot = dict(_section_cache)
    if not cache_snapshot or stale:
        _refresh_section_cache(plex_url, token)
        with _section_cache_lock:
            cache_snapshot = dict(_section_cache)

    # Find the longest matching root prefix
    best_root, best_sid = None, None
    for root, sid in cache_snapshot.items():
        if folder.startswith(root.rstrip("/") + "/") or folder == root:
            if best_root is None or len(root) > len(best_root):
                best_root, best_sid = root, sid
    return best_sid


def folder_for_section_id(section_id: int) -> Optional[str]:
    """
    Reverse lookup: given a Plex librarySectionID (always present and
    reliable in webhook payloads, unlike Media/Part file paths or
    videoResolution metadata), return the content-root folder path for
    that section, e.g. "/docker/aiogateway/mnt/Movies4K".

    Used to disambiguate which quality tier (HD vs 4K) a play event is for,
    since the section a title lives in is unambiguous — far more reliable
    than inferring quality from Plex's self-reported videoResolution, which
    reflects the (always small, always similar) stub file's actual encoded
    resolution rather than the real quality tier, until the file resolves.
    """
    cfg = _plex_config()
    if not cfg:
        return None
    plex_url, token = cfg
    with _section_cache_lock:
        stale = (time.time() - _section_cache_at) > _section_cache_ttl
        cache_snapshot = dict(_section_cache)
    if not cache_snapshot or stale:
        _refresh_section_cache(plex_url, token)
        with _section_cache_lock:
            cache_snapshot = dict(_section_cache)
    for path, sid in cache_snapshot.items():
        if sid == section_id:
            return path
    return None


_pending_folders: set = set()
_pending_lock = threading.Lock()
_pending_timer: Optional[threading.Timer] = None
_DEBOUNCE_SECONDS = 5.0


def scan_folder_async(folder: str) -> None:
    """
    Fire-and-forget Plex partial scan of `folder`. Calls within a few
    seconds of each other are coalesced — adding a season binds many
    episodes back to back, and each would otherwise fire its own Plex
    section lookup + refresh.
    """
    global _pending_timer
    if not _plex_config():
        return
    with _pending_lock:
        _pending_folders.add(folder)
        if _pending_timer is None:
            _pending_timer = threading.Timer(_DEBOUNCE_SECONDS, _flush_scans)
            _pending_timer.daemon = True
            _pending_timer.start()


def _flush_scans() -> None:
    global _pending_timer
    with _pending_lock:
        folders = sorted(_pending_folders)
        _pending_folders.clear()
        _pending_timer = None
    # A season folder and its parent show folder: scanning the parent covers both.
    roots = [f for f in folders if not any(f != o and f.startswith(o + "/") for o in folders)]
    for f in roots:
        _scan_now(f)


def _scan_now(folder: str) -> None:
    cfg = _plex_config()
    if not cfg:
        return
    plex_url, token = cfg
    try:
        sid = _section_id_for_path(plex_url, token, folder)
        if sid is None:
            log.warning("No Plex library section found for %s — skipping scan", folder)
            return
        r = requests.get(
            f"{plex_url}/library/sections/{sid}/refresh",
            params={"path": folder, "X-Plex-Token": token},
            timeout=_REQUEST_TIMEOUT,
        )
        if r.status_code in (200, 0):
            log.info("Triggered Plex partial scan: section=%s path=%s", sid, folder)
        else:
            log.warning("Plex partial scan returned %d for %s", r.status_code, folder)
    except Exception as exc:
        log.warning("Plex partial scan failed for %s: %s", folder, exc)
